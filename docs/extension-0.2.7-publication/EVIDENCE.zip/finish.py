from pathlib import Path
import json,hashlib,zipfile,shutil
P=Path(__file__).resolve().parent;W=Path('D:/Development/Bosak/.worktrees/Bosak.Release18117Published');D=W/'docs/extension-0.2.7-publication'
read=lambda p:json.loads(p.read_bytes())
assert read(P/'MARKETPLACE-VERIFICATION.json')['byteIdentical'];assert len(read(P/'lsp-smoke.json')['packagedStdioChecks'])==3
D.mkdir(exist_ok=True)
for f in ['PREPARATION.json','PUBLISHER.json','MARKETPLACE-VERIFICATION.json','NONCE-QUERY.json','LEGAL-LINE-ENDING-REVIEW.json','lsp-smoke.json','LSP-SMOKE.json','LSP-SMOKE-VERIFIED.json','artifacts/release-manifest.json']:
 shutil.copy2(P/f,D/Path(f).name)
with zipfile.ZipFile(D/'EVIDENCE.zip','w',zipfile.ZIP_DEFLATED) as z:
 seen=set()
 for pattern in ['marketplace-query-*.json','lsp-*','LSP-*.log','*.py','RELEASE-NOTES.md']:
  for f in sorted(P.glob(pattern)):
   if f.is_file() and f.name not in seen:z.write(f,f.name);seen.add(f.name)
text='''# VS Code extension 0.2.7 publication — 16 November 2026

The owner approved source publication, tags and extension delivery. Extension **0.2.7**, bundling unchanged engine/server **1.81.17**, is publicly available on the [Marketplace](https://marketplace.visualstudio.com/items?itemName=fytala.vscode-bosak).

Preparation [43872832340](https://github.com/Fytala-Charles/Bosak/actions/runs/43872832340) passed compilation, highlighting/launch controls and 90 language-server tests. Exact-artifact publisher [43873325768](https://github.com/Fytala-Charles/Bosak/actions/runs/43873325768) succeeded without rebuilding. Source/tag: `6e183a7563009e1ce52a162354c117da0beb13e2` / `vscode-v0.2.7`. Reviewed manifest SHA-256: `66a9b1e5c1a59fa99e450b60d03637ce37223091453f6f760b8faf468c758cc3`.

The public Marketplace version is listed and its downloaded VSIX is byte-identical to the approved hosted artifact. The downloaded server starts over stdio, reports the expected source/version, and passes three packaged diagnostic checks. Ten bundled Bosak assemblies have the intended 1.81.17 dependency cohort. The initial local legal-byte comparison encountered Windows checkout line endings; comparison with exact source Git blobs passed before publication. No validator or artifact bytes were weakened or changed.

Core tag `v1.81.17` points to the original NuGet source `6a7618e9dcf70eb8a67d5d1789ff7b787133b52d`. The separately recorded [NuGet publication](../release-1.81.17-publication/README.md) remains immutable. Extension tag preparation creates a second artifact for validation only; the publisher used preparation run 43872832340.

An initial direct URL returned HTML, and an early smoke attempt refused the missing VSIX before launching the server. Both observations are retained separately. A fresh query bypassed an older cached listing; the listed download was then verified before the successful bounded LSP-SMOKE-VERIFIED run. No engine or artifact changes were needed.

Existing editor, experimental 4.0, numeric, schema/provider and conformance profile limits remain. This engine refresh adds no editor UI and makes no performance or complete-conformance claim. Live VS Code UI interaction is not claimed by the packaged stdio checks.

JSON receipts and source-only EVIDENCE.zip retain validation; binary VSIX files stay in the ignored local packet. Earlier release status entries are historical.
'''
(D/'README.md').write_text(text,encoding='utf-8')
for f in ['README.md','ROADMAP.md']:
 p=W/f;s=p.read_text(encoding='utf-8');s=s.replace('VS Code extension 0.2.6 remains available separately.','VS Code extension [0.2.7](docs/extension-0.2.7-publication/README.md) bundles engine/server 1.81.17.').replace('The separately published **VS Code extension 0.2.6** remains unchanged; its original delivery is recorded in the [1.81.2 publication record](docs/release-1.81.2-publication/README.md).','**VS Code extension 0.2.7** bundles engine/server 1.81.17; its [publication record](docs/extension-0.2.7-publication/README.md) records exact Marketplace verification.');p.write_text(s,encoding='utf-8')
p=W/'vscode-bosak/README.md';s=p.read_text(encoding='utf-8');s=s.replace('## Release candidate (0.2.7)','## Current release (0.2.7)').replace('Hosted VSIX preparation and exact-artifact Marketplace verification are required before claiming publication.','Hosted preparation and exact-artifact Marketplace verification passed. See the [publication receipt](../docs/extension-0.2.7-publication/README.md).');p.write_text(s,encoding='utf-8')
entry='## Extension 0.2.7 published — 16 November 2026\n\nThe [publication receipt](extension-0.2.7-publication/README.md) records hosted preparation, 90 language-server tests, exact-artifact publisher success, byte-identical Marketplace download and three packaged stdio diagnostic checks. Tags v1.81.17 and vscode-v0.2.7 identify the separate immutable Core/extension sources. Prior pending entries remain historical.\n\n'
for f in ['docs/IMPLEMENTATION_STATUS.md','docs/DEVELOPMENT_HISTORY.md','docs/AGENT_HANDOVER.md']:
 p=W/f;p.write_bytes(entry.encode()+p.read_bytes())
p=W/'docs/RELEASING.md';s=p.read_text(encoding='utf-8');s=s.replace('the VS Code extension candidate is **0.2.7**. Extension 0.2.6 remains the previous Marketplace baseline until verified publication.','VS Code extension **0.2.7** is Marketplace-published and byte-verified. See the [extension receipt](extension-0.2.7-publication/README.md).');p.write_text(s,encoding='utf-8')
p=W/'.gitattributes';p.write_bytes(p.read_bytes()+b'\n/docs/extension-0.2.7-publication/** -text whitespace=cr-at-eol\n')
m={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in D.iterdir() if f.is_file() and f.name!='MANIFEST.json'};(D/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8');print('Extension publication docs prepared.')
