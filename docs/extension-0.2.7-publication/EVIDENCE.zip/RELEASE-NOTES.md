Bosak 1.81.17 publishes the ten Core NuGet libraries, with VS Code extension 0.2.7 bundling engine/server 1.81.17.

- [XPath](https://www.nuget.org/packages/Bosak.XPath.Api/1.81.17), [XQuery](https://www.nuget.org/packages/Bosak.XQuery/1.81.17), [XSLT](https://www.nuget.org/packages/Bosak.Xslt/1.81.17)
- [VS Code extension](https://marketplace.visualstudio.com/items?itemName=fytala.vscode-bosak)

The release includes qualified compatibility fixes and allocation reductions since 1.81.2. Existing numeric, extended-year, experimental 4.0, editor and schema/provider profile limits remain. No new editor UI, complete-conformance claim or performance guarantee is introduced. Production Schema/XmlDb/Braid adoption remains separate work.

NuGet publication reused preparation run 43861115818 without rebuilding. All ten public payloads and signatures verify; a fresh NuGet.org-only consumer passed 53 checks. Hosted package preparation passed 26,488 solution tests and the frozen QT3 31,397/0/424 and gated qt4 8,941/0/1,918 gates, with existing skip reasons retained. Separately qualified source standalone XSLT remains 10,221/0/4,380 under the pinned basic, non-schema-aware profile; this is not a package-cohort standalone rerun.

Extension preparation run 43872832340 compiled/tested and sealed 0.2.7. Publisher run 43873325768 reused that exact reviewed VSIX without rebuilding. Core tag `v1.81.17` identifies `6a7618e9dcf70eb8a67d5d1789ff7b787133b52d`; extension tag `vscode-v0.2.7` identifies `6e183a7563009e1ce52a162354c117da0beb13e2`.

The immutable NuGet package READMEs retain the source's historical 1.81.2 installation example; install 1.81.17 explicitly. No package rebuild was performed to change that documentation.
