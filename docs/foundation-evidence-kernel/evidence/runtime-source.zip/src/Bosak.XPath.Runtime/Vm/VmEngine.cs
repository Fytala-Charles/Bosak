// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 19 mei 2026
// PURPOSE              : A register-based virtual machine that interprets <see cref="IrModule"/> instructions
// SPECIAL NOTES        : Part of the Bosak XPath 3.1 implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 19-05-2026     | Creation                                                                                 |
//                      | Charles Korthout | 0.2   | 19-05-2026     | Implemented string, sequence, and aggregate VM opcodes                                 |
//                      | Charles Korthout | 0.3   | 19-05-2026     | Added Intersect, Except, and SimpleMap VM handlers                                     |
//                      | Charles Korthout | 0.4   | 19-05-2026     | Added Map, Array, and Lookup VM handlers                                               |
//                      | Charles Korthout | 0.5   | 19-05-2026     | Added occurrence indicator support for InstanceOf, Cast, Castable, TreatAs             |
//                      | Charles Korthout | 0.6   | 22-05-2026     | Expanded TryCast with validation for xs: types, whitespace, Unicode, extended years      |
//                      | Charles Korthout | 0.6   | 19-05-2026     | Optimized Subscript, First, Last VM handlers to avoid full sequence materialization    |
//                      | Charles Korthout | 0.7   | 21-05-2026     | Divide opcode returns decimal for integer operands (XPath div semantics)               |
//                      | Charles Korthout | 0.8   | 21-05-2026     | MapAdd uses XdmValue keys with numeric promotion; fixed xs:boolean string cast         |
//                      | Charles Korthout | 0.9   | 22-05-2026     | ItemInstanceOf recognizes duration, dayTimeDuration, yearMonthDuration                 |
//                      | Charles Korthout | 1.0   | 23-05-2026     | Added TryCast support for many xs: types, duration normalization, boolean→numeric       |
//                      | Charles Korthout | 1.1   | 24-05-2026     | Range opcode uses lazy IntegerRangeSequence to avoid OOM on huge ranges                 |
//                      | Charles Korthout | 1.2   | 24-05-2026     | Added date/time value comparison type checking (XPTY0004 for cross-subtype)            |
//                      | Charles Korthout | 1.3   | 27-05-2026     | Added DocumentRoot VM handler for absolute XPath paths                                 |
//                      | Charles Korthout | 1.4   | 29-05-2026     | Fixed TryCast to return empty sequence for empty input (xs:type(()) semantics)         |
//                      | Charles Korthout | 1.5   | 30-05-2026     | Fixed Compare/CompareGeneral to return empty sequence for empty operands; added backwards-compatible coercion |
//                      | Charles Korthout | 1.6   | 30-05-2026     | Added PathStepMap opcode for per-context-item predicate evaluation on path steps        |
//                      | Charles Korthout | 1.7   | 30-05-2026     | Filter opcode treats double/decimal/float predicates as numeric position (fixes path-007/008) |
//                      | Charles Korthout | 1.8   | 30-05-2026     | IsSameNode unwraps singleton sequences; returns empty for empty-seq operand (fixes boolean-074/075) |
//                      | Charles Korthout | 1.9   | 31-05-2026     | Implemented PrecedesNode/FollowsNode (<< / >>) using DocumentOrder                          |
//                      | Charles Korthout | 2.0   | 01-06-2026     | Include XPST0017 error code in function-not-found exceptions                             |
//                      | Charles Korthout | 2.1   | 02-06-2026     | Numeric predicate uses exact equality, not Math.Round (XPath 2.0 §3.2.4)                 |
//                      | Charles Korthout | 2.2   | 03-06-2026     | MultiplyOrAddInteger: detect overflow, promote to decimal (fixes number-0111)            |
//                      | Charles Korthout | 2.3   | 01-06-2026     | Use module.MaxRegisterCount instead of hardcoded 256 for register array sizing           |
//                      | Charles Korthout | 2.4   | 05-06-2026     | Inline function sequence param validation; numeric promotion; node()/anyAtomicType matching |
//                      | Charles Korthout | 2.5   | 05-06-2026     | Removed global NormalizeSequence from Execute; path/union already normalize via opcodes     |
//                      | Charles Korthout | 2.6   | 05-06-2026     | Added function(*)/map(*)/array(*) support to ValueMatchesType for instance-of checks      |
//                      | Charles Korthout | 2.7   | 05-06-2026     | Added typed function signature matching (function(T...) as R) with contravariant params   |
//                      | Charles Korthout | 2.8   | 05-06-2026     | Node comparison operators raise XPTY0004 for non-node operands; XPathParseException XPST0003  |
//                      | Charles Korthout | 2.9   | 05-06-2026     | ResolveVariableName handles Q{uri}local; inline function params bind by expanded QName     |
//                      | Charles Korthout | 2.10  | 11-06-2026     | Apply opcode invokes map/array functions; date comparison casts untypedAtomic operands    |
//                      | Charles Korthout | 2.11  | 13-06-2026     | Empty-URI EQName support in ResolveVariableName (Q{}local)                              |
//                      | Charles Korthout | 2.12  | 13-06-2026     | Parameterized map(K,V) and array(T) matching in ValueMatchesType                         |
//                      | Charles Korthout | 2.13  | 13-06-2026     | Date/time comparison uses implicit timezone; time constructor avoids DateTimeOffset       |
//                      | Charles Korthout | 2.14  | 25-06-2026     | QName equality compares namespace URI + local name, ignoring prefix (fixes type-0129)   |
//                      | Charles Korthout | 2.15  | 25-06-2026     | Value comparison casts xs:untypedAtomic operands to xs:string before comparing (fixes type-0165)            |
//                      | Charles Korthout | 2.16  | 25-06-2026     | LoadContextItem raises XPDY0002 when the XPath context item is absent                      |
//                      | Charles Korthout | 2.17  | 25-06-2026     | InstanceOf applies default element namespace and reports unknown types (XPST0051)        |
//                      | Charles Korthout | 2.18  | 26-06-2026     | Subscript/First/Last return empty sequence instead of Undefined for out-of-range/missing items |
//                      | Charles Korthout | 2.29  | 09-07-2026     | StringConcat atomizes operands instead of using XdmValue.ToString()                    |
//                      | Charles Korthout | 2.18  | 26-06-2026     | InstanceOf recognises parameterised sequence type names and avoids spurious XPST0051   |
//                      | Charles Korthout | 2.19  | 26-06-2026     | CompareGeneral returns false (not empty sequence) for empty general-comparison operands |
//                      | Charles Korthout | 2.20  | 28-06-2026     | NormalizeSequence uses HashSet for duplicate removal; restores catalog self-test speed   |
//                      | Charles Korthout | 2.21  | 26-06-2026     | Integer/decimal division and modulo by zero raise FOAR0001 DynamicException            |
//                      | Charles Korthout | 2.22  | 30-06-2026     | Cast to xs:float parses via float.TryParse to preserve single-precision lexical form  |
//                      | Charles Korthout | 2.23  | 02-07-2026     | Root opcode handles parentless nodes and raises XPDY0050; Range atomizes operands       |
//                      | Charles Korthout | 2.24  | 03-07-2026     | Trim whitespace when casting strings to xs:integer (TVT function results)              |
//                      | Charles Korthout | 2.26  | 19-07-2026     | cbcl fixes: gDay/gMonthDay timezone-aware equality; duration*NaN raises FOCA0005          |
//                      | Charles Korthout | 2.26  | 26-06-2026     | LookupWildcard flattens map values and array members                                   |
//                      | Charles Korthout | 2.27  | 26-06-2026     | NormalizeSequence places document-rooted nodes before parentless nodes                 |
//                      | Charles Korthout | 2.28  | 26-06-2026     | Removed leftover debug output from CompareCore                                         |
//                      | Charles Korthout | 2.29  | 13-07-2026     | Honor FunctionSignature.DynamicImplementation for dynamic named-function calls         |
//                      | Charles Korthout | 2.30  | 13-07-2026     | HOF: closure capture, dynamic-call arity/conversion, coerced items, instance-of types  |
//                      | Charles Korthout | 2.31  | 14-07-2026     | Dynamic-call String conversion back to spec (untypedAtomic cast + URI promotion only)  |
//                      | Charles Korthout | 2.32   | 14-07-2026     | NamedFunctionItem carries defining context; fallback resolution across contexts        |
//                      | Charles Korthout | 2.33  | 14-07-2026     | CompareGeneral integer-set fast path (cached HashSet) for = / != on large sequences    |
//                      | Charles Korthout | 2.34  | 15-07-2026     | OverflowException during execution is surfaced as FOAR0002 (numeric range error)       |
//                      | Charles Korthout | 2.35  | 15-07-2026     | ConvertArgToKind passes empty sequences through for optional parameters (xs:T?/xs:T*)  |
//                      | Charles Korthout | 2.36  | 15-07-2026     | Lookup semantics: container-major multi-key, single-result unwrap, strict xs:integer array keys (FOAY0001 bounds/XPTY0004 type), array-as-function via shared ArrayLookup, CompareGeneral atomizes arrays |
//                      | Charles Korthout | 2.37  | 15-07-2026     | MapAdd raises XQDY0137 on duplicate keys in map constructors (serialize-xml-119/124/125) |
//                      | Charles Korthout | 2.38  | 15-07-2026     | Tier-2i: strict singleton map keys (XPTY0004); Exists/Empty opcodes count-based; parameterized map(K,V)/array(T)/function(A)-as-R instance-of routing; maps/arrays match function(*); map/array-as-function value rule; named-fn signature checks with context; structural function-family subtyping (MapTest-050..054); XPST0003/XPST0051 map-type validation |
//                      | Charles Korthout | 2.39  | 15-07-2026     | Tier-2j: For opcode binds optional positional variable (1-based); Atomize raises XPTY0004 on multi-item sequences; arithmetic operands validated numeric/untypedAtomic (XPTY0004) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.40  | 15-07-2026     | Tier-2k: annotation-aware instance-of (integer/string/duration supertype walks, nmtoken); 'to' operand validation (XPTY0004); value-comparison string-vs-numeric XPTY0004; general-comparison untypedAtomic rule-b casting via primitive base type; for/some/every bind namespace-qualified variables; duration casts keep subtype annotation |
//                      | Charles Korthout | 2.41  | 18-07-2026     | NamedFunctionItem dynamic calls use defining-context focus (fn:function-lookup base-uri) |
//                      | Charles Korthout | 2.42  | 19-07-2026     | Tier-2u: xs:numeric cast and xs:numeric#1 constructor                                  |
//                      | Charles Korthout | 2.43  | 19-07-2026     | Tier-2v: idiv NaN/INF and numeric-literal+keyword boundary checks                       |
//                      | Charles Korthout | 2.44  | 19-07-2026     | Tier-2x: floating-point mod by zero returns NaN instead of FOAR0001                     |
//                      | Charles Korthout | 2.45  | 19-07-2026     | Castable opcode catches overflow/cast errors; empty sequence only castable for ?/*    |
//                      | Charles Korthout | 2.46  | 19-07-2026     | xs:unsignedLong values above long.MaxValue stored as xs:decimal with subtype annotation; instance-of accepts decimal-backed integer subtypes |
//                      | Charles Korthout | 2.47  | 19-07-2026     | RangeExpr supports xs:integer operands that exceed long range via DecimalRangeSequence |
//                      | Charles Korthout | 2.48  | 19-07-2026     | CompareGeneral enumerates operands lazily to avoid materializing huge ranges |
//                      | Charles Korthout | 2.49  | 19-07-2026     | NormalizeSequence stable-sorts namespace nodes by owner element so namespace axis is document-ordered |
//                      | Charles Korthout | 2.50  | 19-07-2026     | Duration multiply/divide uses round-half-up for yearMonth and overflow-safe decimal for dayTime |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.51  | 19-07-2026     | Tier-2z: union/intersect/except require node sequences; added LoadNode VM opcode           |
//                      | Charles Korthout | 2.52  | 20-07-2026     | Cast/Castable pass EvaluationContext; xs:QName cast resolves prefixes and default namespace |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.52  | 19-07-2026     | Tier-2z: date/dayTime arithmetic zeroes time for xs:date; time +/- yearMonth raises XPTY0004 |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.53  | 19-07-2026     | Tier-2z: unary plus validates numeric operand and raises XPTY0004 for non-numeric        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.54  | 19-07-2026     | Tier-2z: arithmetic with xs:untypedAtomic now casts the result to xs:double                |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.55  | 19-07-2026     | Tier-2z: duration div by NaN/0 checked before zero-duration short-circuit               |
//                      | Charles Korthout | 2.153 | 21-09-2026     | API freeze stage C: internalized engine; conversion helpers exposed via XdmConversions  |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.56  | 20-07-2026     | PathStepMap raises XPTY0019 when context item is not a node (K2-Axes-50/53)            |
//                      | Charles Korthout | 2.57  | 20-07-2026     | Cast opcode raises XPTY0004 for empty input with occurrence One (K-SeqExprCast-67)     |
//                      | Charles Korthout | 2.58  | 20-07-2026     | Inline functions apply XPath function conversion rules to arguments (FunctionCall-010/011/025/026) |
//                      | Charles Korthout | 2.60  | 21-07-2026     | Added xs:dateTimeStamp cast, instance-of, and type hierarchy support                 |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.61  | 21-07-2026     | xs:NOTATION instance-of returns false; xs:QName name is case-sensitive (xs:qname raises XPST0051) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.62  | 21-07-2026     | ParseGDateTime uses regex to avoid IndexOutOfRangeException on gDay/gMonth/gMonthDay/gYearMonth |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.63  | 22-07-2026     | Added OrderBy and TupleBind VM handlers for XQuery FLWOR order by                       |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.59  | 21-07-2026     | Static function calls apply ParameterTypeNames conversion; URI promotion detects xs:anyURI annotation |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.64  | 25-07-2026     | Added GroupBy VM handler and grouping-key equality for XQuery FLWOR group by            |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.65  | 25-07-2026     | Added Window VM handler for XQuery FLWOR tumbling/sliding windows                       |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.66  | 25-07-2026     | Window end-pos/no-end fixes; EnforceType; NaN ordering; XQST0076; dateTime group keys   |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.67  | 25-07-2026     | Named-ref arity validation; group-by collation + g-date key ordering fixes             |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.68  | 25-07-2026     | Constructor opcodes; default-elem-ns tags; group-key atomization; predicate EBV; scoping |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.69  | 25-07-2026     | Attributes in content (XQTY0024); ctor-local ns; type-prefix resolution; array content  |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.70  | 25-07-2026     | Computed constructor execution with content accumulator and name resolution; window variable namespace binding |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.71  | 25-07-2026     | Literal-only attribute whitespace normalization; xml:id collapse normalization                                 |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.72  | 26-07-2026     | User-function semantics: absent focus; full variable-scope snapshot per call; attribute atomization; function coercion; order-by type families |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.73  | 27-07-2026     | TryCatch: code-pattern clause matching, err:* binding, static-error bypass; FORG0001/XPDY0050/XQDY0074 codes |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.74  | 28-07-2026     | NameTest XPST0081 for unbound prefixes; KindTestType opcode; instance-of prefixed-name ns check; attr type compat supertypes |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.75  | 29-07-2026     | EnforceType atomization for typed variable initializers; XPST0081 for unbound function/variable prefixes |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.76  | 29-07-2026     | Function-test annotation assertions stripped in InstanceOf; XQST0045 for reserved annotation namespaces |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.77  | 29-07-2026     | ApplyAxis raises XPTY0019 for atomic items in a path step's input sequence |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.78  | 21-08-2026     | FunctionItemInstanceOf avoids recursive ValueMatchesType fallback; arity-only for unresolved items |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.79  | 21-08-2026     | IsSchemaTypeSequenceSubtype breaks recursive IsSequenceTypeSubtype fallback for atomic types |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.78  | 29-07-2026     | Singleton-sequence unwrap for map/array/function-typed call parameters |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.79  | 29-07-2026     | Computed namespace prefix type check (XPTY0004); ns decls not XQTY0024 content; ns nodes atomize to xs:string |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.80  | 29-07-2026     | HOF: FOTY0013/XQTY0105 function items; Curry arity check; absent-focus named refs; base-URI capture; paren types |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.81  | 29-07-2026     | Plain xs:duration rejected in date/time arithmetic (XPTY0004, cbcl-plus/minus) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.82  | 29-07-2026     | Residual sweep: stable order-by; array atomize/flatten; default-ns computed names; div duration rule |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.83  | 01-08-2026     | XPath 1.0 BC: numeric fn args truncate to first item and convert via fn:number       |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.84  | 01-08-2026     | BC first-item truncation for all singleton params; pre-atomization type pass-through |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.85  | 03-08-2026     | element()/attribute() kind tests honor Q{uri}local and default-element/no-namespace rules |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.86  | 03-08-2026     | Document-order sort computes keys in sequence order (detached-tree sequence stability) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.87  | 07-08-2026     | Dropped VM-level constructor attribute normalization: the parser already normalizes raw whitespace and exempts character references (K2-Serialization-6, xml-to-json-051) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.88  | 07-08-2026     | Comparison strictness sweep: same-type binary (hex/base64) comparisons order by decoded octets, mixed binary/non-binary XPTY0004; duration ordering honors the dynamic subtype annotation (plain xs:duration XPTY0004); general comparisons flatten nested arrays; unary minus on untypedAtomic yields xs:double; idiv raises FOAR0002 when the result exceeds xs:long range |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.89  | 07-08-2026     | NamespaceTest Q{}* sentinel (never the default element ns); EQName xs type names in ValueMatchesType/ApplyFunctionConversion; element/attribute(*, prefixed-T) kind tests validate the schema type (XPST0008/XPST0081) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.90  | 07-08-2026     | General comparisons on function items raise FOTY0013; named function items subtype-check against coarse kind-derived signatures (instanceof134); ApplyFunctionConversion (now public) atomizes array arguments into their members (FunctionCall-022) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.91  | 07-08-2026     | Coarse named-function return type: Undefined means empty-sequence() (xs-error-006/007) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.92  | 14-08-2026     | Order-by string comparisons use per-spec collation (default or explicit) instead of ordinal |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.93  | 14-08-2026     | Direct attribute constructors include comment/PI string values in attribute values (K2-DirectConElemAttr-42/43); raise XQDY0092 for invalid xml:space (K2-DirectConOther-65) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.94  | 15-08-2026     | ValueMatchesType preserves case for nested kind tests in document-node(element(...)) (NodeTest004) |
//                      | Charles Korthout | 2.95  | 15-08-2026     | Map dynamic calls return empty sequence for missing keys; map/array coercion to function types (UseCaseR31) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.96  | 18-08-2026     | ApplyAxis/PathStepMap treat empty-sequence input as empty instead of XPDY0002 (Catalog004) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.97  | 18-08-2026     | XQDY0101 for namespace constructor bound to XMLNS namespace (nscons-020)                  |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.98  | 18-08-2026     | Clamped function arity int.MaxValue raises FOAR0002 (fn-function-arity-017/fn-function-name-018) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.99  | 19-08-2026     | Schema-aware: user-defined schema types in ValueMatchesType/ApplyFunctionConversion; pass context to atomic type match |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.100 | 19-08-2026     | InstanceOf accepts prefixed user-defined schema types; ConvertSchemaValue keeps integer kind for integer subtypes |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.99  | 18-08-2026     | Unprefixed computed attribute names do not use the default element namespace (currencysvg) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.101 | 21-08-2026     | SchemaElementTest/SchemaAttributeTest opcodes and ValueMatchesType support for schema kind tests |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.102 | 21-08-2026     | SchemaElementTest nilled check uses the actual element declaration's nillability |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.103 | 21-08-2026     | Schema-aware recursive cast for XSD union/list simple types; union typed-value annotation in XDocumentNode |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.104 | 21-08-2026     | Resolve compiled BaseXmlSchemaType for restrictions of union/list schema types; preserve lexical form for union restriction facets |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.105 | 21-08-2026     | Schema-aware sequence-type subtyping; preserve QName values when casting to user-defined union types; accept Q{} user-defined types in InstanceOf |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.106 | 21-08-2026     | Handle atomic schema types in sequence-subtype expansion (union-of-lists vs xs:anyAtomicType*) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.107 | 21-08-2026     | Accept typed QName values when casting to xs:QName / QName-derived union members |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.108 | 21-08-2026     | Capture/restore namespaces for NamedFunctionItem dynamic calls; reject restrictions of union/list types in SequenceType (XPST0051) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.109 | 21-08-2026     | Schema-aware QName/NOTATION cast fixes; preserve prefixes, reject QName to string-subtype casts, XQST0034 constructor conflicts |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.110 | 21-08-2026     | element(*, T) and element(N, T) kind tests reject nilled elements; fn:nilled uses PSVI IsNil |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.111 | 21-08-2026     | Reject non-atomic user-defined schema types as SequenceType item types (XPST0051)     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.112 | 21-08-2026     | TryCast updates result to atomized node value so xs:T($node) returns the typed value   |
//                      | Charles Korthout | 2.113 | 22-08-2026     | Derived string/numeric/union cast fixes: numeric→string subtypes, XSD canonical pattern validation, list cast restrictions, date/duration serialization |
//                      | Charles Korthout | 2.114 | 22-08-2026     | Cast/castable atomize arrays recursively and raise FOTY0013 for maps/function items      |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.115 | 22-08-2026     | GetUnionMemberTypes returns both named @memberTypes and inline BaseTypes members         |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.116 | 22-08-2026     | Schema-aware list/union fixes: attribute kind-test case preservation, union function conversion, default-ns instance-of, element schema subtyping |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.117 | 23-08-2026     | Validate expression returns parentless elements, cleans up injected xsi:type, checks type existence |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.117 | 22-08-2026     | Function conversion raises XPTY0117 when xs:untypedAtomic is supplied to namespace-sensitive atomic types (CastAs675a, CastAsNamespaceSensitiveType) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.118 | 22-08-2026     | Validate opcode for XQuery validate expressions |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.119 | 22-08-2026     | Validate opcode reads mode; lax with no schema returns operand unchanged |
//                      | Charles Korthout | 2.120 | 23-08-2026     | Schema-aware validate: built-in schema set, validate type QName, PSVI annotations, xsi:type ID/IDREF, NOTATION instance-of |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.121 | 23-08-2026     | HOF function-item instance-of for element kind-test result types without schema (hof-039/053) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.122 | 23-08-2026     | document-node() matches empty document nodes; constructed elements have xs:anyType type annotation |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.123 | 23-08-2026     | ApplyFunctionConversion atomizes nodes for atomic/simple targets even when typed value matches (qischema040/qischema040a) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.124 | 23-08-2026     | instance-of rejects xs:untypedAtomic for user-defined schema simple types (cbcl-module-001) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.125 | 23-08-2026     | xs:numeric recognized as element/attribute kind-test type; xml:id schema for lax IDREF validation |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.126 | 23-08-2026     | Validate expression raises XQDY0061 for document roots with invalid content model |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.127 | 23-08-2026     | element(N) defaults to xs:anyType? (nillable) in IsElementOrAttributeSchemaSubtype (hof-034) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.128 | 26-08-2026     | InvokeFunctionItem clears current item so fn:current() raises XTDE1360 in dynamic calls |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.130 | 29-08-2026     | Updated NormalizeSequence comment for namespace-node DocumentOrder slot after owner element |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.129 | 27-08-2026     | DocumentRoot opcode raises XPTY0020 when the context item is atomic                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.131 | 02-09-2026     | FODT0001 for lexically valid date/dateTime casts with out-of-range years (REQ-082)     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.132 | 02-09-2026     | Capture resolved signature on named-function references; captured-signature             |
//                      |                  |       |                | invocation fallback (override-f-014)                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.133 | 05-09-2026     | Structural XPTY0019/XPTY0020 split: axis/PathStepMap raise XPTY0019 for atomic input only when the step has a path LHS (RegisterC flag from lowerer) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.134 | 07-09-2026     | §19.3 permitted-cast matrix (GetCastSourceFamily/IsCastCombinationPermitted): non-    |
//                      |                  |       |                | permitted combinations raise XPTY0004 (was FORG0001); NaN/INF→integer/decimal raise    |
//                      |                  |       |                | FOCA0002 (CastFailureKind; QT3 strict sweep, REQ-082 follow-up)                        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.135 | 07-09-2026     | CheckFunction opcode resolves the callee before arguments are evaluated (XPST0017      |
//                      |                  |       |                | precedence over argument errors, K2-NodeTest-10)                                       |
//                      | Charles Korthout | 2.136 | 09-09-2026     | QT3 triage: numeric FORG0001/XPTY0004 conversions, ctor codes, validate XQDY0084/0061, |
//                      |                  |       |                | xs:error cast, dynamic-call XPTY0004                                                 |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.137 | 09-09-2026     | XPST0051 for illegal sequence-type item types in function conversion (none, list      |
//                      |                  |       |                | types, unions containing/derived from lists); XPST0051 for unknown type constructors   |
//                      |                  |       |                | in schema-imported namespaces (instanceof117)                                        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.138 | 09-09-2026     | XML doc coverage on public API (Beta review)                                             |
//                      | Charles Korthout | 2.139 | 09-09-2026     | Perf: MaterializeSequence fast path for already-materialized inputs; wrappers via shared |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.140 | 16-09-2026     | REQ-085 perf wave 5: lazy name/kind/namespace-test filtering (no per-node intermediate  |
//                      |                  |       |                | lists); Filter opcode: copy-free input view, pooled kept-buffer, singleton predicate     |
//                      |                  |       |                | probe; PathStepMap/SimpleMap/ApplyAxis read inputs via materialization view              |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.141 | 16-09-2026     | Lazy-sequence cardinality fixes exposed by wave-5 lazy node tests: JumpIfEmpty, Cast,   |
//                      |                  |       |                | Castable, TryCast, and empty-sequence() matching peek (at most two items) instead of     |
//                      |                  |       |                | treating unknown length as non-empty                                                     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.142 | 16-09-2026     | REQ-085 perf wave 6: FLWOR tuple materialization — OrderBy atomizes sort keys ONCE per  |
//                      |                  |       |                | tuple (was per comparison, re-materializing lazy node keys per pair), keeps tuple item   |
//                      |                  |       |                | lists copy-free and reuses incoming array tuples in the sorted stream; TupleBind indexes  |
//                      |                  |       |                | tuple values without ToArray; For/Some/Every/OrderBy/GroupBy inputs via view             |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.143 | 16-09-2026     | REQ-085 perf wave 7: Call opcode passes argument registers as a span when no callee   |
//                      |                  |       |                | can rewrite them (no map/array/function-typed params, no declared sequence types) —     |
//                      |                  |       |                | eliminates the per-call argument array on the built-in hot path                          |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.144 | 16-09-2026     | REQ-085 perf wave 8: ApplyFunctionConversion caches the syntactic sequence-type parse |
//                      |                  |       |                | (normalized name, occurrence flags, function-test marker) per distinct type string —    |
//                      |                  |       |                | typed signatures no longer re-parse type names per argument per call                     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.145 | 16-09-2026     | REQ-085 perf wave 9: ValueMatchesType caches the lowercase occurrence/prefix-stripped |
//                      |                  |       |                | atomic-match type name per distinct input (was Trim().ToLowerInvariant() + slices per    |
//                      |                  |       |                | call); parenthesized types still re-enter the full matcher unchanged                     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.146 | 16-09-2026     | Streaming Phase A: lazy single-pass branches — NormalizeSequence passthrough,          |
//                      |                  |       |                | ApplyAxis/FilterNodesLazy marker propagation, lazy Filter, PathStepMap and SimpleMap   |
//                      |                  |       |                | (marked input + single-item probe) over ISinglePassSequence inputs                     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.147 | 17-09-2026     | Streaming Phase D1: single-pass instance-of in one enumeration; TreatAs validates   |
//                      |                  |       |                | ISinglePassSequence inputs lazily via TreatAsLazyIterator                              |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.148 | 17-09-2026     | UnaryPlus/Negate atomize their operand (+@att returned the attribute node, making a  |
//                      |                  |       |                | final path step mix nodes/atomics and spuriously raise XPTY0018 on streamed docs)     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.149 | 17-09-2026     | ValueMatchesType map(K,V)/array(T) params split from the case-preserved type name     |
//                      |                  |       |                | so Q{...} key-type prefixes survive the lowercase normalization (si-fork-119)          |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.150 | 21-09-2026     | MapAdd raises XTDE3365 instead of XQDY0137 when EvaluationContext.InStreamingMapContext |
//                      | Charles Korthout | 2.151 | 21-09-2026     | API freeze stage A: ParseException renamed to XPathParseException                      |
//                      | Charles Korthout | 2.152 | 21-09-2026     | API freeze stage A: reduced accessibility (internalized Compiler types)                |
//                      |                  |       |                | is set (xsl:fork branches, si-fork-814)                                                |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.153 | 21-09-2026     | API freeze stage D: EffectiveBooleanValue -> GetEffectiveBooleanValue call sites        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.154 | 24-09-2026     | REQ-104 (PA-2): ValueMatchesType accepts DateTime-kind g* values (gYear/gYearMonth/    |
//                      |                  |       |                | gMonthDay/gDay/gMonth) — the PSVI typed-value path produces DateTime-kind values        |
//                      |                  |       |                | annotated with the g* type name, previously rejected by the string-kind-only match      |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.155 | 24-09-2026     | REQ-105 (PA-3): schema-element/schema-attribute matching reads the post-compilation  |
//                      |                  |       |                | ElementSchemaType/AttributeSchemaType (SchemaType is null for type-referenced decls)  |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.156 | 24-09-2026     | REQ-106 (PA-3): NOTATION-derived casts annotate xs:NOTATION; namespace-sensitive     |
//                      |                  |       |                | casts restricted to the stringish source family; InstanceOf resolves unprefixed       |
//                      |                  |       |                | schema types in no namespace (notation-0001..0102)                                     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.157 | 25-09-2026     | REQ-108: user-defined type identity annotation on cast/PSVI values; instance-of        |
//                      |                  |       |                | for user-defined types uses identity, not castability (as-2002/2101, as-1806..1809)   |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.158 | 25-09-2026     | REQ-108: bool/float/double/date/time cast results keep their user-defined type        |
//                      |                  |       |                | identity (evaluate-009, type-expr-0201/0401, type-functions-0201)                       |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.159 | 30-09-2026     | REQ-114/PB-3 C9: general comparisons and function conversion flatten multi-item       |
//                      |                  |       |                | atomized sequences (list-typed schema nodes) — existential pairwise comparison and     |
//                      |                  |       |                | per-member conversion to xs:T* targets (import-schema-020/029/030, validation-0301/    |
//                      |                  |       |                | 0401)                                                                                  |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.160 | 30-09-2026     | REQ-114/PB-3 C9: parameterized document-node() KindTest enforces exactly one element    |
//                      |                  |       |                | child, no text children, and the inner element(E[,T])/schema-element(E) test;           |
//                      |                  |       |                | element(*,T) matches anonymous simple-type annotations; anyURI schema values keep       |
//                      |                  |       |                | their lexical form (validation-1401, import-schema-052/055, type-0302)                  |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.161 | 01-10-2026     | Normalize opcode passes through unsorted/dedup-free inside streamable source-document  |
//                      |                  |       |                | pipelines (EvaluationContext.InStreamedPipeline); sf-reverse-001                        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.162 | 01-10-2026     | Normalize passthrough narrowed to forward-axis steps (RegisterC=1, set by the lowerer):  |
//                      |                  |       |                | reverse-axis steps sort+dedup again, fixing climbing-operand regressions (sx-if-030,    |
//                      |                  |       |                | si-for-each-012, sf-head-030, ...) while sf-reverse-001 stays fixed                     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.163 | 01-10-2026     | Streamed passthrough also bails to full normalize when the step sequence mixes          |
//                      |                  |       |                | document-rooted and parentless nodes (si-fork-118, sf-insert-before-141); only           |
//                      |                  |       |                | MaterializedSequence inputs are scanned — enumerating lazy streams would consume them     |
//                      |                  |       |                | (sf-avg-043, sf-deep-equal-043)                                                          |
//                      |==================|=======|================|=========================================================================================
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.164 | 08-10-2026     | REQ-118 4.0-S4: Pipeline opcode; 'for member'/'for key value' iteration in the For opcode (XPTY0141)
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.165 | 08-10-2026     | REQ-118 4.0-S5: ConvertArgToKind made public (fn:partial-apply coerces bound values  |
//                      |                  |       |                | against the base function's parameter types eagerly, fn-partial-apply-13)              |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.166 | 08-10-2026     | REQ-118 4.0-S6a: enum types + choice item types (§3.2.5/§3.2.6) in ValueMatchesType, |
//                      |                  |       |                | InstanceOf, TryCast (cast/castable), and node-kind conversion targets                  |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.167 | 08-10-2026     | REQ-118 4.0-S6b: structural record types (§3.2.10) — record annotations on XdmMap,   |
//                      |                  |       |                | instance-of/coercion (§3.4.2 rule 10)/cast (§4.19.2.7), record lookup checks, 'but with'|
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.168 | 09-10-2026     | REQ-123 fn:op support: extracted EvaluateRange/Union/Intersect/ExceptNodeSequences   |
//                      |                  |       |                | + EvaluateNodeComparison from the opcode dispatch; public ApplyBinaryOperator (F&O    |
//                      |                  |       |                | 4.0 §18.4) reuses them for all 31 fn:op operators                                     |
//                      |------------------|-------|----------------|------------------------------------------------------------------------------------------|
//                      | Charles Korthout | 2.169 | 09-10-2026     | REQ-123 element-to-map slice: XPath 4.0 map/array path navigation — MapAxis/            |
//                      |                  |       |                | CollectMapClosure/MayContainMaps (materialized sequences only — lazy/streamed inputs    |
//                      |                  |       |                | stay single-enumeration, ReverseAxisInsideRecord), FlattenItems/AddFlattened, LookupKey |
//                      |                  |       |                | opcode case, map-preserving NameTest/KindTest/NamespaceTest branches (E/"key",          |
//                      |                  |       |                | E//"key", E//QName)                                                                     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.170 | 10-10-2026     | REQ-123 sort-with slice: public CompareAtomic 3-way comparator (fn:compare PR909 —     |
//                      |                  |       |                | collation strings, mutual binary octets, booleans, exact cross-numeric via BigInteger    |
//                      |                  |       |                | expansion, QName {uri,local}, same-subtype durations, same-subtype date/times),          |
//                      |                  |       |                | CompareBinaryValuesLoose/DecodeBinaryOctets, DurationSubtype + GetDurationSubtype/      |
//                      |                  |       |                | GetDateTimeSubtype/NormalizeDuration made public                                        |
//                      | Charles Korthout | 2.171 | 10-10-2026     | REQ-123 compare-tail slice: unicode-case-insensitive collation accepted in order-by    |
//                      |==================|=======|================|=========================================================================================
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.172   | 10-10-2026     | REQ-123 JNode cluster: XdmValueKind.JNode navigation model - JNodeAxis/JChildren axes
//                      | Charles Korthout |         |                | yielding keyed JNodes, implicit fn:jtree wrap of raw maps/arrays, LookupKey
//                      | Charles Korthout |         |                | select-by-key rework, LookupIndex/LookupComputed opcodes, jnode() type tests,
//                      | Charles Korthout |         |                | Atomize/call-site jvalue extraction, 4.0 path-step context checks
//                      |------------------|---------|----------------|------------------------------------------------------------------------------------------
//                      | Charles Korthout | 2.173  | 10-10-2026     | REQ-123 destructuring let: Destructure opcode (PR1131 let $(...)/$[...]/${...});
//                      |                  |         |                | EnforceType applies XPath 4.0 §3.4.2 coercion (incl. records) when IsXPath40
//                      |------------------|---------|----------------|------------------------------------------------------------------------------------------
//                      | Charles Korthout | 2.174  | 16-10-2026     | REQ-123 PR1131: SaveVariables/RestoreVariables lexical let scoping + §3.4.2
//                      |                  |         |                | numeric relabeling to derived integer types (PR 254 datum-in-value-space rule);
//                      |                  |         |                | SaveVariables captures direct bindings only (via TryGetDirectVariable) so in-flight
//                      |                  |         |                | lazy globals are not flagged circular (K2-FunctionProlog-15)
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.175 | 13-10-2026     | Match named record types by annotation identity in type tests.                           |
//                      | Charles Korthout | 2.176 | 13-10-2026     | Normalize schema EQName cast targets for XPath 4.0 default item types
//                      | Charles Korthout | 2.177 | 13-10-2026     | Apply XPath 4.0 array member coercion without atomizing the outer array
//                      | Charles Korthout | 2.178 | 13-10-2026     | Coerce XPath 4.0 typed map keys and values with collision checks and entry order
//                      | Charles Korthout | 2.179 | 13-10-2026     | Use cardinality-aware function type matching for XPath 4.0 instance-of operands
//                      | Charles Korthout | 2.180 | 13-10-2026     | Apply sequence-aware nominative record coercion through the host callback
//                      | Charles Korthout | 2.181 | 13-10-2026     | Preserve map operands for named record casts and cast field sequences
//                      | Charles Korthout | 2.182 | 13-10-2026     | Cast XPath 4.0 array members and map entries using shared sequence casting
//                      | Charles Korthout | 2.183 | 13-10-2026     | Match explicit empty-namespace element and attribute type names
//                      | Charles Korthout | 2.184 | 13-10-2026     | Match processing-instruction sequence types by their case-sensitive target
//                      | Charles Korthout | 2.185 | 13-10-2026     | Match element and attribute type tests with partial name wildcards
//                      | Charles Korthout | 2.186 | 13-10-2026     | Match node-name unions without splitting EQName namespace separators
//                      | Charles Korthout | 2.187 | 13-10-2026     | Reject empty values for required single structural record conversion
//                      | Charles Korthout | 2.188 | 14-10-2026     | Defer optional host omission markers while preserving normal type conversion.            |
//                      | Charles Korthout | 2.189 | 14-10-2026     | Share XPath 4.0 primitive numeric coercion with the XSLT argument host (1.3.2).            |
//                      | Charles Korthout | 2.190  | 15-10-2026     | Capture lexical host targets and preserve bound original item identity.                  |
//                      | Charles Korthout | 2.191 | 15-10-2026     | Retain lexical original aliases in escaping inline functions and restore callers on errors. |
//                      | Charles Korthout | 2.192 | 16-10-2026     | Compare structural record signatures with case-sensitive fields and typed zero-arity results. |
//                      | Charles Korthout | 2.193 | 16-10-2026     | Compare record fields against map value types and generic function supertypes.               |
//                      | Charles Korthout | 2.194 | 18-10-2026     | Correct build-warning documentation and nullable-flow diagnostics.                     |
//                      | Charles Korthout | 2.195 | 24-10-2026     | Preserve promoted integer arithmetic and check subtraction without negating Int64.MinValue. |
//                      | Charles Korthout | 2.196 | 24-10-2026     | Check exact floating integer thresholds and preserve accepted unsigned magnitudes.          |
//                      | Charles Korthout | 2.197 | 24-10-2026     | Truncate unsignedLong decimal operands before range facets and integer backing selection. |
//                      | Charles Korthout | 2.198 | 24-10-2026     | Truncate finite unsigned floating operands before lower/upper range facets.                |
//                      | Charles Korthout | 2.199 | 25-10-2026     | Preserve integer identity and promote minimum-value unary negation without wraparound.     |
//                      | Charles Korthout | 2.200 | 25-10-2026     | Preserve integer modulo identity and return zero for Int64 minimum modulo negative one.    |
//                      | Charles Korthout | 2.201 | 25-10-2026     | Truncate decimal-backed idiv exactly before checking existing Int64 result bounds.         |
//                      | Charles Korthout | 2.202 | 25-10-2026     | Preserve an empty atomized operand before numeric unary negation.                           |
//                      | Charles Korthout | 2.203 | 25-10-2026     | Count atomic values after recursive array-member atomization for singleton consumers.       |
//                      | Charles Korthout | 2.204 | 25-10-2026     | Propagate empty atomized numeric binary and modern range operands before conversion.         |
//                      | Charles Korthout | 2.205 | 25-10-2026     | Report function/map atomization errors for numeric-union function parameters.                |
//                      | Charles Korthout | 2.206 | 26-10-2026     | Retain atomization errors for integer function parameters including rounding precision.     |
//                      | Charles Korthout | 2.207 | 27-10-2026     | Validate legacy binding item types before atomization and cardinality checks (K01).        |
//                      |==================|=======|================|=========================================================================================

//                      | Charles Korthout | 2.208 | 28-10-2026     | Resolve pending XQuery initial focus at semantic context-load instructions (1.30.0).     |
//                      | Charles Korthout | 2.209 | 28-10-2026     | Pass constructor-local namespace-copy modes to provider node-content cloning (1.31.0). |
//                      | Charles Korthout | 2.210 | 28-10-2026     | Carry construction mode and original attribute metadata through provider hooks (1.32.0). |
//                      | Charles Korthout | 2.211 | 29-10-2026     | Share actual schema-element membership across node matching and sequence subtyping.       |
// ===========================================================================================================================================================
using System.Buffers;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using Bosak.XPath.Compiler.Ir;
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Parser.Ast;
using Bosak.XPath.Providers.Xml;
using Bosak.XPath.Runtime.Functions;

namespace Bosak.XPath.Runtime.Vm;

/// <summary>
/// A register-based virtual machine that interprets <see cref="IrModule"/> instructions.
/// </summary>
internal static class VmEngine
{
    /// <summary>
    /// Executes a compiled IR module against the given evaluation context.
    /// </summary>
    /// <param name="module">The compiled IR module to interpret.</param>
    /// <param name="context">The evaluation context holding the focus, variables, and functions.</param>
    /// <returns>The XDM value produced by the expression.</returns>
    internal static XdmValue Execute(IrModule module, EvaluationContext context)
    {
        try
        {
            // The lowerer uses monotonic register allocation; size is determined at compile time.
            var registers = new XdmValue[module.MaxRegisterCount];
            var (result, _) = ExecuteBlock(module, context, registers, 0);
            return result;
        }
        catch (OverflowException ex)
        {
            // XPath surfaces numeric range failures as FOAR0002 (arithmetic overflow),
            // not as raw CLR conversion/negation exceptions.
            throw new InvalidOperationException($"FOAR0002: {ex.Message}", ex);
        }
    }

    private static (XdmValue Result, int NextIp) ExecuteBlock(
        IrModule module,
        EvaluationContext context,
        XdmValue[] registers,
        int startIp)
    {
        var instructions = module.Instructions;
        var literalPool = module.LiteralPool;
        // Lexical let-scoping stack (SaveVariables/RestoreVariables); frame-local so a
        // region that exits with an exception cannot leak markers into its caller.
        List<List<((string Local, string Ns) Key, bool Had, XdmValue Value)>>? variableScopes = null;
        int ip = startIp;
        while (ip < instructions.Length)
        {
            var instr = instructions[ip];

            switch (instr.OpCode)
            {
                // ------------------------------------------------------------------
                // Control flow
                // ------------------------------------------------------------------
                case IrOpCode.Nop:
                    ip++;
                    break;

                case IrOpCode.Return:
                    return (registers[instr.RegisterA], ip + 1);

                case IrOpCode.Jump:
                    ip = instr.Operand;
                    break;

                case IrOpCode.JumpIfTrue:
                    ip = registers[instr.RegisterA].GetEffectiveBooleanValue() ? instr.Operand : ip + 1;
                    break;

                case IrOpCode.JumpIfFalse:
                    ip = !registers[instr.RegisterA].GetEffectiveBooleanValue() ? instr.Operand : ip + 1;
                    break;

                case IrOpCode.JumpIfEmpty:
                    {
                        // Peek-based emptiness: lazy sequences report unknown length, so a
                        // TryGetLength-only check would treat a lazy empty as non-empty.
                        bool isEmpty = !SequenceHasAnyItem(registers[instr.RegisterA]);
                        ip = isEmpty ? instr.Operand : ip + 1;
                        break;
                    }

                case IrOpCode.Call:
                    {
                        int argCount = instr.RegisterC;
                        int firstArgReg = instr.RegisterB;

                        string localName;
                        string nsUri;
                        var funcLiteral = literalPool[instr.Operand]!;
                        if (funcLiteral is ValueTuple<string, string> resolved)
                        {
                            localName = resolved.Item1;
                            nsUri = resolved.Item2;
                        }
                        else
                        {
                            string funcName = (string)funcLiteral;
                            (localName, nsUri) = ResolveFunctionName(funcName, context);
                        }

                        bool found = context.TryResolveFunction(nsUri, localName, argCount, out var sig);
                        if (!found)
                        {
                            // A 1-argument call in a schema-imported namespace is a type
                            // constructor; an unknown schema type is XPST0051, not XPST0017
                            // (instanceof117).
                            if (argCount == 1 && IsSchemaImportedNamespace(nsUri, context))
                                throw new InvalidOperationException($"XPST0051: The type '{{{nsUri}}}{localName}' is not a known schema type.");
                            throw new InvalidOperationException(
                                $"XPST0017: Function {{{nsUri}}}{localName}#{argCount} not found.");
                        }

                        // Fast path: when nothing can rewrite the arguments (no map/array/
                        // function-typed params to unwrap, no declared sequence types to
                        // convert), pass the argument registers directly as a span — no
                        // per-call argument array. Implementations receive a ReadOnlySpan
                        // (mutation is impossible), and the aliased argument registers are
                        // single-assignment, so they are dead after this instruction.
                        bool argsMayBeRewritten = sig.ParameterTypeNames is not null;
                        if (!argsMayBeRewritten)
                        {
                            for (int i = 0; i < argCount && i < sig.ParameterTypes.Count; i++)
                            {
                                if (sig.ParameterTypes[i] is XdmValueKind.Map or XdmValueKind.Array or XdmValueKind.Function)
                                {
                                    argsMayBeRewritten = true;
                                    break;
                                }
                            }
                        }

                        if (!argsMayBeRewritten)
                        {
                            registers[instr.RegisterA] = sig.Implementation(
                                context, registers.AsSpan(firstArgReg, argCount));
                            ip++;
                            break;
                        }

                        // Build argument span
                        XdmValue[] args = new XdmValue[argCount];
                        for (int i = 0; i < argCount; i++)
                            args[i] = registers[firstArgReg + i];

                        // A singleton sequence unwraps to its item when the parameter is
                        // declared as a map, array, or function item (the function
                        // conversion rules applied to kind-typed parameters — covers
                        // map:size($ctx ! map{...}) and path-position map constructors).
                        for (int i = 0; i < argCount && i < sig.ParameterTypes.Count; i++)
                        {
                            if (sig.ParameterTypes[i] is XdmValueKind.Map or XdmValueKind.Array or XdmValueKind.Function)
                            {
                                // XPath 4.0 §17.7: a JNode argument coerces to a
                                // map/array/function-typed parameter by extracting its
                                // jvalue (fn-jtree-012/013: jtree({...}) => map:size()).
                                if (args[i].IsJNode)
                                    args[i] = args[i].JNodeValue.Value;
                                args[i] = UnwrapSingletonItem(args[i], sig.ParameterTypes[i]);
                            }
                        }

                        // Apply XPath 3.1 function conversion rules when the function signature
                        // declares precise parameter sequence types. This covers untypedAtomic casting,
                        // numeric promotion, and URI promotion for static calls (FunctionCall-011).
                        if (sig.ParameterTypeNames != null)
                        {
                            for (int i = 0; i < argCount && i < sig.ParameterTypeNames.Count; i++)
                            {
                                if (args[i].IsUndefined && sig.MinimumHostArity is { } minimum && i >= minimum)
                                    continue;
                                var paramType = sig.ParameterTypeNames[i];
                                if (!string.IsNullOrEmpty(paramType))
                                    args[i] = ApplyFunctionConversion(args[i], paramType!, context);
                            }
                        }

                        registers[instr.RegisterA] = sig.Implementation(context, args);
                        ip++;
                        break;
                    }

                case IrOpCode.TailCall:
                    throw new NotImplementedException("TailCall is not yet implemented.");

                case IrOpCode.CheckFunction:
                    {
                        // Pre-argument callee resolution: unknown functions raise XPST0017
                        // before argument expressions are evaluated (K2-NodeTest-10).
                        var checkLiteral = literalPool[instr.Operand]!;
                        string checkLocal, checkNs;
                        if (checkLiteral is ValueTuple<string, string> checkResolved)
                        {
                            checkLocal = checkResolved.Item1;
                            checkNs = checkResolved.Item2;
                        }
                        else
                        {
                            (checkLocal, checkNs) = ResolveFunctionName((string)checkLiteral, context);
                        }
                        if (!context.TryResolveFunction(checkNs, checkLocal, instr.RegisterC, out _))
                        {
                            if (instr.RegisterC == 1 && IsSchemaImportedNamespace(checkNs, context))
                                throw new InvalidOperationException($"XPST0051: The type '{{{checkNs}}}{checkLocal}' is not a known schema type.");
                            throw new InvalidOperationException(
                                $"XPST0017: Function {{{checkNs}}}{checkLocal}#{instr.RegisterC} not found.");
                        }
                        ip++;
                        break;
                    }

                // ------------------------------------------------------------------
                // Context
                // ------------------------------------------------------------------
                case IrOpCode.LoadContextItem:
                    if (context.ResolveContextItem().IsUndefined)
                        throw new InvalidOperationException("XPDY0002: The context item is absent.");
                    registers[instr.RegisterA] = context.ContextItem;
                    ip++;
                    break;

                case IrOpCode.LoadContextPosition:
                    context.ResolveContextItem();
                    registers[instr.RegisterA] = XdmValue.FromInteger(context.ContextPosition);
                    ip++;
                    break;

                case IrOpCode.LoadContextSize:
                    context.ResolveContextItem();
                    registers[instr.RegisterA] = XdmValue.FromInteger(context.ContextSize);
                    ip++;
                    break;

                case IrOpCode.SetContext:
                    // Not used by current lowerer; placeholder for future use.
                    throw new NotImplementedException("SetContext is not yet implemented.");

                // ------------------------------------------------------------------
                // Variables
                // ------------------------------------------------------------------
                case IrOpCode.LoadVariable:
                    {
                        string localName;
                        string nsUri;
                        var varLiteral = literalPool[instr.Operand]!;
                        if (varLiteral is ValueTuple<string, string> resolvedVar)
                        {
                            localName = resolvedVar.Item1;
                            nsUri = resolvedVar.Item2;
                        }
                        else
                        {
                            string varName = (string)varLiteral;
                            (localName, nsUri) = ResolveVariableName(varName, context);
                        }

                        if (!context.TryGetVariable(localName, out var value, nsUri))
                        {
                            if (context.BackwardsCompatible)
                            {
                                // XPath 1.0 compatibility: an undefined variable is treated
                                // as an empty sequence.
                                registers[instr.RegisterA] = XdmValue.Undefined;
                            }
                            else
                            {
                                string displayName = string.IsNullOrEmpty(nsUri) ? localName : $"Q{{{nsUri}}}{localName}";
                                // A prolog-declared external variable whose value was never
                                // supplied is a dynamic error (XPDY0002), not XPST0008.
                                if (context.UnsuppliedExternalVariables.Contains((localName, nsUri)))
                                    throw new InvalidOperationException($"XPDY0002: No value was supplied for external variable '${displayName}'.");
                                throw new InvalidOperationException($"XPST0008: Variable ${displayName} is not defined.");
                            }
                        }
                        else
                        {
                            registers[instr.RegisterA] = value;
                        }
                        ip++;
                        break;
                    }

                case IrOpCode.StoreVariable:
                    {
                        string localName;
                        string nsUri;
                        var varLiteral = literalPool[instr.Operand]!;
                        if (varLiteral is ValueTuple<string, string> resolvedVar)
                        {
                            localName = resolvedVar.Item1;
                            nsUri = resolvedVar.Item2;
                        }
                        else
                        {
                            string varName = (string)varLiteral;
                            (localName, nsUri) = ResolveVariableName(varName, context);
                        }
                        context.WithVariable(localName, registers[instr.RegisterB], nsUri);
                        ip++;
                        break;
                    }

                case IrOpCode.SaveVariables:
                    {
                        // Lexical let scoping: capture the current values of the bound
                        // variables so RestoreVariables can undo the let's bindings when
                        // the body completes. The stack is local to this ExecuteBlock
                        // frame: Save/Restore pairs are always emitted within one
                        // instruction region, so an exception abandoning a region cannot
                        // leave stale markers behind. Only DIRECT bindings are captured:
                        // probing lazy globals here would re-enter the lazy resolver for
                        // an in-flight global of the same name and falsely report a
                        // circular dependency (K2-FunctionProlog-15).
                        var keys = (List<object>)literalPool[instr.Operand]!;
                        var saved = new List<((string Local, string Ns) Key, bool Had, XdmValue Value)>(keys.Count);
                        foreach (var keyLiteral in keys)
                        {
                            var (local, ns) = keyLiteral is ValueTuple<string, string> resolvedKey
                                ? resolvedKey
                                : ResolveVariableName((string)keyLiteral, context);
                            bool had = context.TryGetDirectVariable(local, out var oldValue, ns);
                            saved.Add(((local, ns), had, oldValue));
                        }
                        (variableScopes ??= new List<List<((string Local, string Ns) Key, bool Had, XdmValue Value)>>()).Add(saved);
                        ip++;
                        break;
                    }

                case IrOpCode.RestoreVariables:
                    {
                        var saved = variableScopes![variableScopes.Count - 1];
                        variableScopes.RemoveAt(variableScopes.Count - 1);
                        foreach (var (key, had, value) in saved)
                        {
                            if (had)
                                context.WithVariable(key.Local, value, key.Ns);
                            else
                                context.RemoveVariable(key.Local, key.Ns);
                        }
                        ip++;
                        break;
                    }

                // ------------------------------------------------------------------
                // Literals
                // ------------------------------------------------------------------
                case IrOpCode.LoadString:
                    registers[instr.RegisterA] = XdmValue.FromString((string)literalPool[instr.Operand]!);
                    ip++;
                    break;

                case IrOpCode.LoadInteger:
                    registers[instr.RegisterA] = XdmValue.FromInteger((long)literalPool[instr.Operand]!);
                    ip++;
                    break;

                case IrOpCode.LoadDecimal:
                    registers[instr.RegisterA] = literalPool[instr.Operand] is (decimal typedDec, string decAnnotation)
                        ? XdmValue.FromDecimal(typedDec, decAnnotation)
                        : XdmValue.FromDecimal((decimal)literalPool[instr.Operand]!);
                    ip++;
                    break;

                case IrOpCode.LoadDouble:
                    registers[instr.RegisterA] = XdmValue.FromDouble((double)literalPool[instr.Operand]!);
                    ip++;
                    break;

                case IrOpCode.LoadBoolean:
                    registers[instr.RegisterA] = XdmValue.FromBoolean(instr.Operand != 0);
                    ip++;
                    break;

                case IrOpCode.LoadNode:
                    registers[instr.RegisterA] = (XdmValue)literalPool[instr.Operand]!;
                    ip++;
                    break;

                case IrOpCode.LoadEmptySequence:
                    registers[instr.RegisterA] = XdmValue.FromSequence(XdmSequence.Empty);
                    ip++;
                    break;

                case IrOpCode.Move:
                    registers[instr.RegisterA] = registers[instr.RegisterB];
                    ip++;
                    break;

                // ------------------------------------------------------------------
                // Sequences
                // ------------------------------------------------------------------
                case IrOpCode.SequenceStart:
                    // Store a mutable list as an external value during construction.
                    registers[instr.RegisterA] = XdmValue.FromExternal(new List<XdmValue>());
                    ip++;
                    break;

                case IrOpCode.SequenceAdd:
                    {
                        var list = (List<XdmValue>)registers[instr.RegisterA].ExternalValue!;
                        var item = registers[instr.RegisterB];
                        // Flatten empty sequences (e.g., () in (a, (), b))
                        if (item.IsUndefined)
                        {
                            ip++;
                            break;
                        }
                        if (item.IsSequence && item.SequenceValue is not null)
                        {
                            if (item.SequenceValue.TryGetLength(out var len) && len == 0)
                            {
                                ip++;
                                break;
                            }
                            // Sequences are always flat in XPath; flatten nested sequences
                            foreach (var seqItem in item.SequenceValue)
                                list.Add(seqItem);
                        }
                        else
                        {
                            list.Add(item);
                        }
                        ip++;
                        break;
                    }

                case IrOpCode.SequenceEnd:
                    {
                        var list = (List<XdmValue>)registers[instr.RegisterA].ExternalValue!;
                        registers[instr.RegisterA] = XdmValue.FromSequence(MaterializedSequence.FromList(list));
                        ip++;
                        break;
                    }

                case IrOpCode.Singleton:
                    registers[instr.RegisterA] = XdmValue.FromSequence(XdmSequence.Singleton(registers[instr.RegisterB]));
                    ip++;
                    break;

                case IrOpCode.Range:
                    registers[instr.RegisterA] = EvaluateRange(registers[instr.RegisterB], registers[instr.RegisterC], context);
                    ip++;
                    break;

                case IrOpCode.Concatenate:
                    registers[instr.RegisterA] = UnionNodeSequences(registers[instr.RegisterB], registers[instr.RegisterC]);
                    ip++;
                    break;

                case IrOpCode.Intersect:
                    registers[instr.RegisterA] = IntersectNodeSequences(registers[instr.RegisterB], registers[instr.RegisterC]);
                    ip++;
                    break;

                case IrOpCode.ButWith:
                    {
                        // XPath 4.0 §4.15.4: merge the RHS map into the LHS record
                        // (use-last) and re-validate against the record annotation.
                        registers[instr.RegisterA] = ButWith(
                            registers[instr.RegisterB], registers[instr.RegisterC], context);
                        ip++;
                        break;
                    }

                case IrOpCode.Except:
                    registers[instr.RegisterA] = ExceptNodeSequences(registers[instr.RegisterB], registers[instr.RegisterC]);
                    ip++;
                    break;

                case IrOpCode.SimpleMap:
                    {
                        var sequence = registers[instr.RegisterB];
                        int rhsEntry = instr.Operand;
                        // RegisterC: 0 = `!` (no node checks), 1 = last path step (mixed
                        // result is XPTY0018), 2 = non-last path step (non-node result item
                        // is XPTY0019).
                        int pathResultMode = instr.RegisterC;
                        bool enforceNodeResult = pathResultMode != 0;

                        // Single-pass (streamed) input: map lazily so streamed items are
                        // pulled and released one at a time; path-mode result checks are
                        // applied during enumeration.
                        if (sequence.IsSequence && sequence.SequenceValue is ISinglePassSequence singlePassMapInput)
                        {
                            registers[instr.RegisterA] = XdmValue.FromSequence(XdmSequence.FromSource(
                                new SinglePassXdmSequence(LazySimpleMapIterator(
                                    module, context, registers, rhsEntry, singlePassMapInput, pathResultMode))));
                            ip++;
                            break;
                        }

                        var items = MaterializeSequenceView(sequence);
                        var results = new List<XdmValue>();
                        int startIndex = 0;

                        // XPath path steps require every context item to be a node (XPTY0019).
                        // SimpleMap with ! allows non-node items, so only enforce in path mode.
                        // XPath 4.0: JNodes (and raw maps/arrays, implicitly wrapped) are
                        // valid path-step context items too.
                        if (enforceNodeResult)
                        {
                            foreach (var item in items)
                            {
                                if (!IsPathStepContextItem(item, context))
                                    throw new InvalidOperationException("XPTY0019: An axis step requires a node as context item.");
                            }
                        }

                        // Single-context-item probe: evaluate the mapping once; when it
                        // yields a streamed (single-pass) result, forward it (with the
                        // path-mode result checks applied lazily) instead of
                        // materializing the stream.
                        if (items.Count == 1 && items[0].IsNode)
                        {
                            var probeItem = context.ContextItem;
                            var probePos = context.ContextPosition;
                            var probeSize = context.ContextSize;
                            context.WithFocus(items[0], 1, 1);
                            var (probeResult, _) = ExecuteBlock(module, context, registers, rhsEntry);
                            context.WithFocus(probeItem, probePos, probeSize);

                            if (probeResult.IsSequence && probeResult.SequenceValue is ISinglePassSequence probeSinglePass)
                            {
                                registers[instr.RegisterA] = pathResultMode switch
                                {
                                    2 => XdmValue.FromSequence(XdmSequence.FromSource(
                                        new SinglePassXdmSequence(RequireNodesLazy(probeSinglePass)))),
                                    1 => XdmValue.FromSequence(XdmSequence.FromSource(
                                        new SinglePassXdmSequence(RejectMixedNodesLazy(probeSinglePass)))),
                                    _ => probeResult,
                                };
                                ip++;
                                break;
                            }

                            if (probeResult.IsSequence && probeResult.SequenceValue is not null)
                            {
                                foreach (var r in XdmSequence.FromSource(probeResult.SequenceValue))
                                    results.Add(r);
                            }
                            else if (!probeResult.IsUndefined)
                            {
                                results.Add(probeResult);
                            }
                            startIndex = 1;
                        }

                        // Save context
                        var savedItem = context.ContextItem;
                        var savedPos = context.ContextPosition;
                        var savedSize = context.ContextSize;

                        for (int i = startIndex; i < items.Count; i++)
                        {
                            context.WithFocus(items[i], i + 1, items.Count);
                            var (rhsResult, _) = ExecuteBlock(module, context, registers, rhsEntry);

                            if (rhsResult.IsSequence && rhsResult.SequenceValue is not null)
                            {
                                foreach (var r in XdmSequence.FromSource(rhsResult.SequenceValue))
                                    results.Add(r);
                            }
                            else if (!rhsResult.IsUndefined)
                            {
                                results.Add(rhsResult);
                            }
                        }

                        // Restore context
                        context.WithFocus(savedItem, savedPos, savedSize);

                        // Non-last path steps must produce nodes only (XPTY0019, mode 2);
                        // the last step merely must not mix nodes and non-nodes (XPTY0018,
                        // mode 1). `!` (mode 0) performs no result check. XPath 4.0:
                        // JNodes count as nodes in both checks.
                        if (pathResultMode == 2)
                        {
                            if (results.Any(r => !r.IsNode && !r.IsJNode))
                                throw new InvalidOperationException("XPTY0019: result of a path expression step other than the last step contains a non-node item");
                        }
                        else if (enforceNodeResult)
                        {
                            bool hasNode = results.Any(r => r.IsNode || r.IsJNode);
                            bool hasNonNode = results.Any(r => !r.IsNode && !r.IsJNode);
                            if (hasNode && hasNonNode)
                                throw new InvalidOperationException("XPTY0018: result of a path expression step contains both nodes and non-nodes");
                        }

                        registers[instr.RegisterA] = XdmValue.FromSequence(
                            MaterializedSequence.FromList(results));
                        ip++;
                        break;
                    }

                case IrOpCode.Pipeline:
                    {
                        // XPath 4.0 '->' (§4.20): the source value is bound as a whole to the
                        // context value (an inner fixed focus with position 1 and size 1) and
                        // the right block is evaluated exactly once.
                        var sourceValue = registers[instr.RegisterB];
                        int rhsEntry = instr.Operand;
                        var savedItem = context.ContextItem;
                        var savedPos = context.ContextPosition;
                        var savedSize = context.ContextSize;
                        context.WithFocus(sourceValue, 1, 1);
                        var (pipeResult, _) = ExecuteBlock(module, context, registers, rhsEntry);
                        context.WithFocus(savedItem, savedPos, savedSize);
                        registers[instr.RegisterA] = pipeResult;
                        ip++;
                        break;
                    }

                case IrOpCode.PathStepMap:
                    {
                        var sequence = registers[instr.RegisterB];
                        if (sequence.IsUndefined)
                        {
                            // Empty sequence input to a path step simply produces an empty
                            // sequence; the real "no context item" case is caught earlier by
                            // LoadContextItem.
                            registers[instr.RegisterA] = XdmValue.Undefined;
                            ip++;
                            break;
                        }
                        int rhsEntry = instr.Operand;
                        // RegisterC set by the lowerer: the step input is the result of a
                        // preceding path step (LHS of '/'), not the ambient context item.
                        bool hasLhs = instr.RegisterC != 0;

                        // Single-pass (streamed) step input: map the step lazily so
                        // streamed records are pulled and released one at a time.
                        if (sequence.IsSequence && sequence.SequenceValue is ISinglePassSequence singlePassStepInput)
                        {
                            registers[instr.RegisterA] = XdmValue.FromSequence(XdmSequence.FromSource(
                                new SinglePassXdmSequence(LazyPathStepIterator(
                                    module, context, registers, rhsEntry, singlePassStepInput, hasLhs))));
                            ip++;
                            break;
                        }

                        var items = MaterializeSequenceView(sequence);
                        var results = new List<XdmValue>();
                        int startIndex = 0;

                        // Single-context-item probe: evaluate the step once; when it
                        // yields a streamed (single-pass) result, forward it untouched
                        // instead of materializing the stream.
                        if (items.Count == 1 && items[0].IsNode)
                        {
                            var probeItem = context.ContextItem;
                            var probePos = context.ContextPosition;
                            var probeSize = context.ContextSize;
                            context.WithFocus(items[0], 1, 1);
                            var (probeResult, _) = ExecuteBlock(module, context, registers, rhsEntry);
                            context.WithFocus(probeItem, probePos, probeSize);

                            if (probeResult.IsSequence && probeResult.SequenceValue is ISinglePassSequence)
                            {
                                registers[instr.RegisterA] = probeResult;
                                ip++;
                                break;
                            }

                            if (probeResult.IsSequence && probeResult.SequenceValue is not null)
                            {
                                foreach (var r in XdmSequence.FromSource(probeResult.SequenceValue))
                                    results.Add(r);
                            }
                            else if (!probeResult.IsUndefined)
                            {
                                results.Add(probeResult);
                            }
                            startIndex = 1;
                        }

                        // Save context
                        var savedItem = context.ContextItem;
                        var savedPos = context.ContextPosition;
                        var savedSize = context.ContextSize;

                        for (int i = startIndex; i < items.Count; i++)
                        {
                            // A step whose input comes from a preceding path step raises
                            // XPTY0019 for atomic items; a standalone/first step applied to
                            // the ambient context item raises XPTY0020. XPath 4.0: JNodes
                            // and raw maps/arrays (implicitly wrapped) are valid context.
                            if (!IsPathStepContextItem(items[i], context))
                            {
                                if (hasLhs)
                                    throw new InvalidOperationException("XPTY0019: An axis step requires a node as context item.");
                                throw new InvalidOperationException("XPTY0020: An axis step requires a context item that is a node.");
                            }

                            // Path-step predicates must see position=1, size=1
                            // for each context item (predicate is relative to the
                            // step result, not the outer sequence).
                            context.WithFocus(items[i], 1, 1);
                            var (rhsResult, _) = ExecuteBlock(module, context, registers, rhsEntry);

                            if (rhsResult.IsSequence && rhsResult.SequenceValue is not null)
                            {
                                foreach (var r in XdmSequence.FromSource(rhsResult.SequenceValue))
                                    results.Add(r);
                            }
                            else if (!rhsResult.IsUndefined)
                            {
                                results.Add(rhsResult);
                            }
                        }

                        // Restore context
                        context.WithFocus(savedItem, savedPos, savedSize);

                        registers[instr.RegisterA] = XdmValue.FromSequence(
                            MaterializedSequence.FromList(results));
                        ip++;
                        break;
                    }

                case IrOpCode.Normalize:
                    {
                        // RegisterC: 1 = forward-axis path step. Inside a streamable
                        // xsl:source-document pipeline the document-order sort/dedup is
                        // suppressed for those steps only: sequences in encounter order
                        // (e.g. fn:reverse results, sf-reverse-001) keep that order.
                        // Reverse-axis steps (ancestor/...) are always sorted into
                        // document order with duplicates removed — streamed climbing
                        // paths deliver reverse document order otherwise (sx-if-030,
                        // si-for-each-012). A forward step over a sequence that MIXES
                        // document-rooted and parentless nodes is still normalized:
                        // Saxon orders such path results with rooted nodes before
                        // parentless ones (si-fork-118, sf-insert-before-141). Pure
                        // streamed input (single-pass) is rooted by construction and
                        // passes through untouched.
                        var normalizeInput = registers[instr.RegisterB];
                        if (context.InStreamedPipeline && instr.RegisterC == 1 && !MixesDetachedNodes(normalizeInput))
                        {
                            registers[instr.RegisterA] = normalizeInput;
                        }
                        else
                        {
                            registers[instr.RegisterA] = NormalizeSequence(normalizeInput);
                        }
                        ip++;
                        break;
                    }

                // ------------------------------------------------------------------
                // FLWOR / Quantified
                // ------------------------------------------------------------------
                case IrOpCode.For:
                    {
                        var info = (QuantifiedLoopInfo)literalPool[instr.Operand]!;
                        var sequence = registers[instr.RegisterB];
                        var items = MaterializeSequenceView(sequence);
                        var results = new List<XdmValue>();

                        var (bindLocal, bindNs) = ResolveLoopVariableKey(info, context);

                        // Save the bindings of the loop variable and an optional positional
                        // variable. Let-bound (scoped) variables are captured separately and
                        // restored after EACH iteration: their bindings are scoped to the
                        // tuple and must not persist across iterations or leak out.
                        var savedBindings = new List<(string Name, string Ns, bool Had, XdmValue Value)>();
                        void Save(string name, string ns)
                        {
                            savedBindings.Add((name, ns, context.TryGetVariable(name, out var saved, ns), saved));
                        }
                        Save(bindLocal, bindNs);
                        if (info.PositionalVariableName is not null)
                            Save(info.PositionalVariableName, "");
                        // XPath 4.0 §4.14.1: 'for member' iterates the members of each array
                        // and 'for key value' the entries of each map in the binding collection.
                        // The positional variable (if any) counts across the whole expansion.
                        (string Local, string Ns)? entryValueKey = null;
                        List<(XdmValue First, XdmValue? Second)>? expanded = null;
                        if (info.BindingKind != ForBindingKind.Item)
                        {
                            expanded = new List<(XdmValue First, XdmValue? Second)>();
                            foreach (var item in items)
                            {
                                if (info.BindingKind == ForBindingKind.Member)
                                {
                                    if (!item.IsArray)
                                        throw new InvalidOperationException("XPTY0141: The binding collection of a 'for member' clause must contain only arrays.");
                                    foreach (var member in item.ArrayValue.Values)
                                        expanded.Add((member, null));
                                }
                                else
                                {
                                    if (!item.IsMap)
                                        throw new InvalidOperationException("XPTY0141: The binding collection of a 'for key value' clause must contain only maps.");
                                    foreach (var kvp in item.MapValue.Entries)
                                    {
                                        expanded.Add(info.BindingKind == ForBindingKind.EntryValueOnly
                                            ? (kvp.Value, null)
                                            : (kvp.Key, info.BindingKind == ForBindingKind.EntryKeyValue ? kvp.Value : null));
                                    }
                                }
                            }
                            if (info.EntryValueVariableName is not null)
                            {
                                entryValueKey = ResolveEntryValueVariableKey(info, context);
                                Save(entryValueKey.Value.Local, entryValueKey.Value.Ns);
                            }
                        }
                        var scopedSaved = new List<(string Name, bool Had, XdmValue Value)>();
                        if (info.ScopedVariableNames is not null)
                        {
                            foreach (var scoped in info.ScopedVariableNames)
                                scopedSaved.Add((scoped, context.TryGetVariable(scoped, out var saved, ""), saved));
                        }
                        void RestoreScoped()
                        {
                            foreach (var (name, had, value) in scopedSaved)
                            {
                                if (had)
                                    context.WithVariable(name, value, "");
                                else
                                    context.RemoveVariable(name, "");
                            }
                        }

                        int position = 0;
                        if (items.Count == 0 && info.AllowingEmpty)
                        {
                            // XQuery "allowing empty": one iteration with the variable bound to
                            // the empty sequence (and a declared positional variable bound to 0).
                            context.WithVariable(bindLocal, XdmValue.FromSequence(XdmSequence.Empty), bindNs);
                            if (info.PositionalVariableName is not null)
                                context.WithVariable(info.PositionalVariableName, XdmValue.FromInteger(0));
                            var (emptyResult, _) = ExecuteBlock(module, context, registers, info.RhsEntryPoint);
                            if (emptyResult.IsSequence && emptyResult.SequenceValue is not null)
                            {
                                foreach (var r in XdmSequence.FromSource(emptyResult.SequenceValue))
                                    results.Add(r);
                            }
                            else if (!emptyResult.IsUndefined)
                            {
                                results.Add(emptyResult);
                            }
                        }

                        void Accumulate(XdmValue rhsResult)
                        {
                            if (rhsResult.IsSequence && rhsResult.SequenceValue is not null)
                            {
                                foreach (var r in XdmSequence.FromSource(rhsResult.SequenceValue))
                                    results.Add(r);
                            }
                            else if (!rhsResult.IsUndefined)
                            {
                                results.Add(rhsResult);
                            }
                        }

                        if (expanded is not null)
                        {
                            foreach (var (first, second) in expanded)
                            {
                                position++;
                                // FLWOR for-expression does NOT change the focus;
                                // it only binds the variable (and optional positional variable).
                                context.WithVariable(bindLocal, first, bindNs);
                                var entryValue = second;
                                if (entryValueKey is not null && entryValue.HasValue)
                                    context.WithVariable(entryValueKey.Value.Local, entryValue.Value, entryValueKey.Value.Ns);
                                if (info.PositionalVariableName is not null)
                                    context.WithVariable(info.PositionalVariableName, XdmValue.FromInteger(position));
                                var (memberRhsResult, _) = ExecuteBlock(module, context, registers, info.RhsEntryPoint);
                                RestoreScoped();
                                Accumulate(memberRhsResult);
                            }
                        }
                        else
                        {
                            foreach (var item in items)
                            {
                                position++;
                                // FLWOR for-expression does NOT change the focus;
                                // it only binds the variable (and optional positional variable).
                                context.WithVariable(bindLocal, item, bindNs);
                                if (info.PositionalVariableName is not null)
                                    context.WithVariable(info.PositionalVariableName, XdmValue.FromInteger(position));
                                var (rhsResult, _) = ExecuteBlock(module, context, registers, info.RhsEntryPoint);
                                RestoreScoped();
                                Accumulate(rhsResult);
                            }
                        }

                        foreach (var (name, ns, had, value) in savedBindings)
                        {
                            if (had)
                                context.WithVariable(name, value, ns);
                            else
                                context.RemoveVariable(name, ns);
                        }

                        registers[instr.RegisterA] = XdmValue.FromSequence(
                            MaterializedSequence.FromList(results));
                        ip++;
                        break;
                    }

                case IrOpCode.Some:
                    {
                        var info = (QuantifiedLoopInfo)literalPool[instr.Operand]!;
                        var sequence = registers[instr.RegisterB];
                        var items = MaterializeSequenceView(sequence);

                        var (bindLocal, bindNs) = ResolveLoopVariableKey(info, context);
                        bool hadVariable = context.TryGetVariable(bindLocal, out var savedVar, bindNs);

                        bool result = false;
                        foreach (var item in items)
                        {
                            // Quantified expression does NOT change the focus;
                            // it only binds the variable.
                            context.WithVariable(bindLocal, item, bindNs);
                            var (rhsResult, _) = ExecuteBlock(module, context, registers, info.RhsEntryPoint);

                            if (rhsResult.GetEffectiveBooleanValue())
                            {
                                result = true;
                                break;
                            }
                        }

                        if (hadVariable)
                            context.WithVariable(bindLocal, savedVar, bindNs);
                        else
                            context.RemoveVariable(bindLocal, bindNs);

                        registers[instr.RegisterA] = XdmValue.FromBoolean(result);
                        ip++;
                        break;
                    }

                case IrOpCode.Every:
                    {
                        var info = (QuantifiedLoopInfo)literalPool[instr.Operand]!;
                        var sequence = registers[instr.RegisterB];
                        var items = MaterializeSequenceView(sequence);

                        var (bindLocal, bindNs) = ResolveLoopVariableKey(info, context);
                        bool hadVariable = context.TryGetVariable(bindLocal, out var savedVar, bindNs);

                        bool result = true;
                        foreach (var item in items)
                        {
                            // Quantified expression does NOT change the focus;
                            // it only binds the variable.
                            context.WithVariable(bindLocal, item, bindNs);
                            var (rhsResult, _) = ExecuteBlock(module, context, registers, info.RhsEntryPoint);

                            if (!rhsResult.GetEffectiveBooleanValue())
                            {
                                result = false;
                                break;
                            }
                        }

                        if (hadVariable)
                            context.WithVariable(bindLocal, savedVar, bindNs);
                        else
                            context.RemoveVariable(bindLocal, bindNs);

                        registers[instr.RegisterA] = XdmValue.FromBoolean(result);
                        ip++;
                        break;
                    }

                case IrOpCode.OrderBy:
                    {
                        var orderInfo = (OrderByInfo)literalPool[instr.Operand]!;
                        var tupleSequence = registers[instr.RegisterB];

                        // XQST0076: an unknown collation in an order by clause is a static error.
                        // Relative collation URIs resolve against the static base URI.
                        foreach (var collation in orderInfo.CollationUri)
                        {
                            if (collation is not null && !IsSupportedOrderByCollation(ResolveCollationUri(collation, context.BaseUri)))
                                throw new InvalidOperationException($"XQST0076: Collation '{collation}' is not supported.");
                        }

                        var tuples = MaterializeSequenceView(tupleSequence);
                        // Copy-free tuple handling + sort keys atomized ONCE per tuple.
                        // Previously each tuple's item list was ToArray-copied here, re-wrapped
                        // after the sort, and ToArray-copied again in TupleBind; and every
                        // comparison re-atomized the raw keys — a lazy node key (e.g. $i/@id)
                        // re-materialized its attribute sequence per compared pair.
                        var materializedTuples = new List<(IReadOnlyList<XdmValue> Items, XdmValue[] Keys, XdmValue Original, int Index)>(tuples.Count);
                        int tupleIndex = 0;
                        foreach (var tuple in tuples)
                        {
                            IReadOnlyList<XdmValue> items;
                            if (tuple.IsArray && tuple.ArrayValue is not null)
                                items = ArrayValuesView(tuple.ArrayValue);
                            else if (tuple.IsSequence && tuple.SequenceValue is not null)
                                items = MaterializeSequenceView(tuple);
                            else
                                items = new[] { tuple };

                            var keys = new XdmValue[orderInfo.KeyCount];
                            for (int k = 0; k < orderInfo.KeyCount; k++)
                            {
                                int keyIndex = orderInfo.ValueCount + k;
                                var rawKey = keyIndex < items.Count ? items[keyIndex] : XdmValue.Undefined;
                                // Pre-atomize exactly as the CompareOrderByValues prologue did;
                                // atomization errors (XPTY0004 multi-item, FOTY0012/0013) surface
                                // here instead of mid-sort, with the same codes.
                                keys[k] = Atomize(rawKey);
                            }

                            materializedTuples.Add((items, keys, tuple, tupleIndex));
                            tupleIndex++;
                        }

                        try
                        {
                            materializedTuples.Sort((x, y) =>
                            {
                                for (int i = 0; i < orderInfo.KeyCount; i++)
                                {
                                    int cmp = CompareOrderByValues(x.Keys[i], y.Keys[i], orderInfo.EmptyOrder[i], orderInfo.CollationUri[i], context);
                                    if (cmp != 0)
                                        return orderInfo.Descending[i] ? -cmp : cmp;
                                }
                                // List<T>.Sort is introsort and NOT stable: decorate with the
                                // original position so equal keys keep their input order
                                // ('stable order by' semantics, fn-doc-33).
                                return x.Index.CompareTo(y.Index);
                            });
                        }
                        catch (InvalidOperationException wrap) when (wrap.InnerException is not null
                            && wrap.Message.StartsWith("Failed to compare", StringComparison.Ordinal))
                        {
                            // List<T>.Sort wraps exceptions thrown by the comparison delegate;
                            // rethrow the original XPTY0004 (incomparable order-by keys).
                            throw wrap.InnerException;
                        }

                        var sorted = new List<XdmValue>(materializedTuples.Count);
                        foreach (var (items, _, original, _) in materializedTuples)
                        {
                            // Incoming array tuples pass through unchanged (TupleBind reads the
                            // same value list); sequence/single items are wrapped as before.
                            sorted.Add(original.IsArray && original.ArrayValue is not null
                                ? original
                                : XdmValue.FromArray(new XdmArray(items)));
                        }

                        registers[instr.RegisterA] = XdmValue.FromSequence(MaterializedSequence.FromList(sorted));
                        ip++;
                        break;
                    }

                case IrOpCode.TupleBind:
                    {
                        var bindInfo = (TupleBindInfo)literalPool[instr.Operand]!;
                        var tuple = registers[instr.RegisterA];
                        IReadOnlyList<XdmValue> items;
                        if (tuple.IsArray && tuple.ArrayValue is not null)
                        {
                            items = ArrayValuesView(tuple.ArrayValue);
                        }
                        else if (tuple.IsSequence && tuple.SequenceValue is not null)
                        {
                            items = MaterializeSequenceView(tuple);
                        }
                        else
                        {
                            items = new[] { tuple };
                        }

                        for (int i = 0; i < bindInfo.Variables.Count; i++)
                        {
                            var (localName, prefix, nsUri) = bindInfo.Variables[i];
                            var item = i < items.Count ? items[i] : XdmValue.Undefined;
                            string bindNs = nsUri ?? "";
                            if (nsUri is null && prefix is not null)
                            {
                                if (!context.TryResolveNamespace(prefix, out var resolvedPrefixNs))
                                    throw new InvalidOperationException($"XPST0081: Prefix '{prefix}' is not declared.");
                                bindNs = resolvedPrefixNs;
                            }
                            context.WithVariable(localName, item, bindNs);
                        }
                        ip++;
                        break;
                    }

                case IrOpCode.GroupBy:
                    {
                        var groupInfo = (GroupByInfo)literalPool[instr.Operand]!;
                        var tupleSequence = registers[instr.RegisterB];
                        var tuples = MaterializeSequence(tupleSequence);
                        var materializedTuples = new List<XdmValue[]>(tuples.Length);
                        foreach (var tuple in tuples)
                        {
                            if (tuple.IsArray && tuple.ArrayValue is not null)
                            {
                                materializedTuples.Add(tuple.ArrayValue.Values.ToArray());
                            }
                            else if (tuple.IsSequence && tuple.SequenceValue is not null)
                            {
                                materializedTuples.Add(MaterializeSequence(tuple));
                            }
                            else
                            {
                                materializedTuples.Add(new[] { tuple });
                            }
                        }

                        // Group tuples by their grouping keys, preserving first-appearance order.
                        var groups = new List<List<XdmValue[]>>();
                        foreach (var tupleItems in materializedTuples)
                        {
                            // XPTY0004: enforce optional 'as SequenceType' declarations on grouping keys.
                            // The check applies to the atomized key value.
                            for (int k = 0; k < groupInfo.KeyIndices.Count; k++)
                            {
                                var declaredType = groupInfo.DeclaredTypeNames[k];
                                if (declaredType is null)
                                    continue;
                                int keyIndex = groupInfo.KeyIndices[k];
                                var keyValue = keyIndex < tupleItems.Length ? tupleItems[keyIndex] : XdmValue.Undefined;
                                if (!InstanceOf(Atomize(keyValue), declaredType, groupInfo.DeclaredTypeOccurrences[k], null, context))
                                {
                                    throw new InvalidOperationException(
                                        $"XPTY0004: Grouping key does not match the declared type '{declaredType}'.");
                                }
                            }

                            List<XdmValue[]>? match = null;
                            foreach (var group in groups)
                            {
                                if (GroupKeysEqual(group[0], tupleItems, groupInfo, context))
                                {
                                    match = group;
                                    break;
                                }
                            }
                            if (match is null)
                            {
                                match = new List<XdmValue[]>();
                                groups.Add(match);
                            }
                            match.Add(tupleItems);
                        }

                        // Merge each group into a single tuple: grouping variables keep their
                        // (shared) key value atomized (per the XQuery grouping rules); all other
                        // variables are bound to the concatenation of their per-tuple values.
                        var merged = new List<XdmValue>(groups.Count);
                        foreach (var group in groups)
                        {
                            int arity = group[0].Length;
                            var mergedTuple = new XdmValue[arity];
                            for (int slot = 0; slot < arity; slot++)
                            {
                                if (IsGroupKeySlot(slot, groupInfo))
                                {
                                    var keyValue = group[0][slot];
                                    mergedTuple[slot] = SingleGroupKeyItem(Atomize(keyValue));
                                    continue;
                                }

                                var combined = new List<XdmValue>();
                                foreach (var member in group)
                                {
                                    var slotValue = slot < member.Length ? member[slot] : XdmValue.Undefined;
                                    if (slotValue.IsSequence && slotValue.SequenceValue is not null)
                                    {
                                        foreach (var item in XdmSequence.FromSource(slotValue.SequenceValue))
                                            combined.Add(item);
                                    }
                                    else if (!slotValue.IsUndefined)
                                    {
                                        combined.Add(slotValue);
                                    }
                                }
                                mergedTuple[slot] = combined.Count switch
                                {
                                    0 => XdmValue.FromSequence(MaterializedSequence.FromList(combined)),
                                    1 => combined[0],
                                    _ => XdmValue.FromSequence(MaterializedSequence.FromList(combined))
                                };
                            }
                            merged.Add(XdmValue.FromArray(new XdmArray(mergedTuple)));
                        }

                        registers[instr.RegisterA] = XdmValue.FromSequence(MaterializedSequence.FromList(merged));
                        ip++;
                        break;
                    }

                case IrOpCode.EnforceType:
                    {
                        var enforceInfo = (EnforceTypeInfo)literalPool[instr.Operand]!;
                        var value = registers[instr.RegisterA];
                        if (context.IsXPath40)
                        {
                            // XPath 4.0 (PR1131): a type declaration on a let/for binding
                            // coerces the bound value with the function-conversion rules
                            // (§3.4.2) instead of a plain instance check: numeric promotion
                            // ('let $v as xs:double := 42'), untypedAtomic casting, and
                            // record coercion all succeed (prod-LetClause letexprwith-26,
                            // K2-LetExprWithout-7a, let-map-027). The coerced value is bound.
                            string targetType = enforceInfo.TypeName + enforceInfo.Occurrence switch
                            {
                                OccurrenceIndicator.ZeroOrOne => "?",
                                OccurrenceIndicator.ZeroOrMore => "*",
                                OccurrenceIndicator.OneOrMore => "+",
                                _ => "",
                            };
                            registers[instr.RegisterA] = ApplyFunctionConversion(value, targetType, context);
                            ip++;
                            break;
                        }
                        // XQuery 3.1 'as SequenceType' enforcement for variable bindings: the
                        // value is atomized (unless the target is a node-kind test) and then
                        // instance-checked — no casts or promotions (XQuery 3.1 §4.16/§4.10).
                        // An illegal list item type is XPST0051 regardless of whether its
                        // value has one or multiple items (XQuery 3.1 §2.5.5.2). Validate
                        // before InstanceOf can reject cardinality with XPTY0004.
                        ValidateFunctionConversionTarget(enforceInfo.TypeName, context);
                        if (!IsNodeKindTest(enforceInfo.TypeName))
                            value = AtomizeItems(value);
                        if (!InstanceOf(value, enforceInfo.TypeName, enforceInfo.Occurrence, context.DefaultElementNamespace, context))
                        {
                            throw new InvalidOperationException(
                                $"{enforceInfo.ErrorCode}: Value does not match the declared type '{enforceInfo.TypeName}'.");
                        }
                        ip++;
                        break;
                    }

                case IrOpCode.Destructure:
                    {
                        // XPath 4.0 destructuring let (PR1131): decompose the RHS (RegisterA)
                        // into the pattern variables and store each into the variable scope,
                        // in declaration order (a repeated variable name binds the last
                        // extracted value, matching sequential let semantics).
                        var info = (DestructuringInfo)literalPool[instr.Operand]!;
                        var boundValue = registers[instr.RegisterA];
                        switch (info.Kind)
                        {
                            case LetDestructuringKind.Sequence:
                            {
                                // The optional whole-pattern type coerces the whole value
                                // (let-seq-007/008/017). Variables bind positionally, except
                                // the LAST variable, which binds all remaining items as a
                                // sequence (let-seq-002/009); earlier surplus items are
                                // discarded and surplus variables bind the empty sequence
                                // (let-seq-003).
                                var source = info.WholeTypeName is null
                                    ? boundValue
                                    : ApplyFunctionConversion(boundValue, WholeTypeText(info), context);
                                var items = source.IsUndefined
                                    ? Array.Empty<XdmValue>()
                                    : source.IsSequence && source.SequenceValue is not null
                                        ? MaterializeSequence(source)
                                        : new[] { source };
                                int last = info.Variables.Length - 1;
                                for (int i = 0; i < info.Variables.Length; i++)
                                {
                                    XdmValue item;
                                    if (i < last)
                                    {
                                        item = i < items.Length ? items[i] : XdmValue.Undefined;
                                    }
                                    else if (i >= items.Length)
                                    {
                                        item = XdmValue.Undefined;
                                    }
                                    else if (i == items.Length - 1)
                                    {
                                        item = items[i];
                                    }
                                    else
                                    {
                                        item = XdmValue.FromSequence(MaterializedSequence.FromList(new List<XdmValue>(items[i..])));
                                    }
                                    StoreDestructuredVariable(info.Variables[i], item, context);
                                }
                                break;
                            }
                            case LetDestructuringKind.Array:
                            {
                                // The bound value must be a single array (let-arr-020/021);
                                // surplus members are discarded, surplus variables raise
                                // FOAY0001 (let-arr-003/015a).
                                var array = SingleArrayItem(boundValue);
                                if (info.WholeTypeName is not null)
                                    array = CoerceDestructuredArray(array, info, context);
                                for (int i = 0; i < info.Variables.Length; i++)
                                {
                                    if (i >= array.Count)
                                        throw new InvalidOperationException(
                                            $"FOAY0001: Array index {i + 1} is out of bounds (array size {array.Count}).");
                                    StoreDestructuredVariable(info.Variables[i], array.Get(i + 1), context);
                                }
                                break;
                            }
                            default: // LetDestructuringKind.Map
                            {
                                // The bound value must be a single map (let-map-019/021);
                                // each variable extracts the entry whose key equals its name,
                                // missing keys bind the empty sequence (let-map-003/016).
                                var map = SingleMapItem(boundValue);
                                XdmRecordType? recordType = null;
                                if (info.WholeTypeName is not null)
                                {
                                    var typeText = info.WholeTypeName.Trim();
                                    if (IsRecordTypeText(typeText))
                                    {
                                        recordType = TryGetRecordType(typeText)!;
                                        map = CoerceMapToRecord(map, recordType, typeText, context);
                                    }
                                    else if (typeText is "map(*)" or "map")
                                    {
                                        // Wildcard: no entry checks.
                                    }
                                    else if (typeText.StartsWith("map(", StringComparison.Ordinal))
                                    {
                                        map = CoerceDestructuredMap(map, typeText, context);
                                    }
                                    else
                                    {
                                        throw new InvalidOperationException(
                                            $"XPTY0004: The declared type '{info.WholeTypeName}' of a map destructuring binding is not a map or record type.");
                                    }
                                }
                                foreach (var variable in info.Variables)
                                {
                                    // A record-typed pattern (other than record(*)) exposes
                                    // only its declared fields: any other variable name is a
                                    // type error (let-map-025).
                                    if (recordType is not null && !recordType.IsAny
                                        && !recordType.HasField(variable.LocalName))
                                    {
                                        throw new InvalidOperationException(
                                            $"XPTY0004: The variable '${variable.LocalName}' is not a declared field of the record type {info.WholeTypeName}.");
                                    }
                                    var entry = map.TryGetValue(RecordFieldKey(variable.LocalName), out var entryValue)
                                        ? entryValue
                                        : XdmValue.Undefined;
                                    StoreDestructuredVariable(variable, entry, context);
                                }
                                break;
                            }
                        }
                        ip++;
                        break;
                    }

                case IrOpCode.ConstructComputed:
                    {
                        var computedInfo = (ComputedConstructorInfo)literalPool[instr.Operand]!;
                        switch (computedInfo.Kind)
                        {
                            case ComputedConstructorKind.Element:
                            {
                                var (local, prefix, ns) = ResolveComputedName(computedInfo, registers[instr.RegisterB], context, "element");
                                var accumulator = new ComputedContentAccumulator(elementNamespaceUri: ns ?? "");
                                foreach (var item in MaterializeSequence(registers[instr.RegisterC]))
                                    accumulator.Add(item, context);
                                accumulator.Flush();
                                // An element in no namespace under a non-empty default namespace
                                // undeclares it: xmlns="" is materialized so in-scope-prefixes and
                                // the namespace axis see it (K2-InScopePrefixesFunc-12/29).
                                if (ns is null && !string.IsNullOrEmpty(context.DefaultElementNamespace))
                                    accumulator.Content.Insert(0, new XdmContentItem(XdmContentKind.Namespace, "", null, ""));
                                AppendConstructorLocalNamespaces(accumulator.Content, accumulator.Attributes, context, prefix, computedInfo.LexicalNamespaces);
                                if (context.ElementConstructorHook is null)
                                    throw new InvalidOperationException("Node construction is not available: no element-constructor provider is registered (EvaluationContext.ElementConstructorHook).");
                                ApplyConstructionCopyMode(accumulator.Content, computedInfo.PreserveNamespaces, computedInfo.InheritNamespaces, computedInfo.ConstructionMode);
                                var spec = new XdmElementSpec(local, prefix, ns, accumulator.Attributes, accumulator.Content, context.BaseUri, context.Xml11Mode) { ConstructionMode = computedInfo.ConstructionMode };
                                registers[instr.RegisterA] = XdmValue.FromNode(context.ElementConstructorHook(spec));
                                break;
                            }
                            case ComputedConstructorKind.Attribute:
                            {
                                var (local, prefix, ns) = ResolveComputedName(computedInfo, registers[instr.RegisterB], context, "attribute");
                                // Attribute prefix rules: a name in the XML namespace coerces to the
                                // 'xml' prefix; any other namespace without a prefix gets a generated one.
                                if (prefix is null && ns is not null)
                                    prefix = ns == "http://www.w3.org/XML/1998/namespace" ? "xml" : "ns1";
                                // XQDY0044: an attribute must not be named xmlns, use the xmlns
                                // prefix, or be in the xmlns namespace.
                                if (local == "xmlns" || prefix == "xmlns" || ns == "http://www.w3.org/2000/xmlns/")
                                    throw new InvalidOperationException("XQDY0044: An attribute must not be named 'xmlns', use the 'xmlns' prefix, or be in the xmlns namespace.");
                                var value = JoinAtomizedItems(registers[instr.RegisterC], " ");
                                // XQDY0091: xml:id attribute values must not have leading/trailing whitespace.
                                if (local == "id" && prefix == "xml" && value != value.Trim())
                                    throw new InvalidOperationException("XQDY0091: An xml:id attribute value must not have leading or trailing whitespace.");
                                if (context.AttributeConstructorHook is null)
                                    throw new InvalidOperationException("Node construction is not available: no attribute-constructor provider is registered (EvaluationContext.AttributeConstructorHook).");
                                registers[instr.RegisterA] = XdmValue.FromNode(context.AttributeConstructorHook(new XdmAttributeValue(local, prefix, ns, value) { ConstructionMode = computedInfo.ConstructionMode }));
                                break;
                            }
                            case ComputedConstructorKind.Document:
                            {
                                var accumulator = new ComputedContentAccumulator(allowAttributes: false);
                                foreach (var item in MaterializeSequence(registers[instr.RegisterC]))
                                    accumulator.Add(item, context);
                                accumulator.Flush();
                                if (context.DocumentConstructorHook is null)
                                    throw new InvalidOperationException("Node construction is not available: no document-constructor provider is registered (EvaluationContext.DocumentConstructorHook).");
                                ApplyConstructionCopyMode(accumulator.Content, computedInfo.PreserveNamespaces, computedInfo.InheritNamespaces, computedInfo.ConstructionMode);
                                registers[instr.RegisterA] = XdmValue.FromNode(context.DocumentConstructorHook(accumulator.Content));
                                break;
                            }
                            case ComputedConstructorKind.Text:
                            {
                                // An empty content sequence produces no text node at all
                                // (a zero-length string still constructs a text node).
                                if (MaterializeSequence(registers[instr.RegisterC]).Length == 0)
                                {
                                    registers[instr.RegisterA] = XdmValue.Undefined;
                                    break;
                                }
                                var value = JoinAtomizedItems(registers[instr.RegisterC], " ");
                                if (context.ContentNodeConstructorHook is null)
                                    throw new InvalidOperationException("Node construction is not available: no content-node provider is registered (EvaluationContext.ContentNodeConstructorHook).");
                                registers[instr.RegisterA] = XdmValue.FromNode(context.ContentNodeConstructorHook(new XdmContentItem(XdmContentKind.Text, value)));
                                break;
                            }
                            case ComputedConstructorKind.Comment:
                            {
                                var value = JoinAtomizedItems(registers[instr.RegisterC], " ");
                                // XQDY0072: comment content must not contain '--' or end with '-'.
                                if (value.Contains("--", StringComparison.Ordinal) || value.EndsWith('-'))
                                    throw new InvalidOperationException("XQDY0072: A comment must not contain '--' or end with '-'.");
                                if (context.ContentNodeConstructorHook is null)
                                    throw new InvalidOperationException("Node construction is not available: no content-node provider is registered (EvaluationContext.ContentNodeConstructorHook).");
                                registers[instr.RegisterA] = XdmValue.FromNode(context.ContentNodeConstructorHook(new XdmContentItem(XdmContentKind.Comment, value)));
                                break;
                            }
                            case ComputedConstructorKind.ProcessingInstruction:
                            {
                                string target;
                                if (computedInfo.HasNameExpression)
                                {
                                    // XPTY0004: a computed PI target must atomize to a single
                                    // xs:string / xs:untypedAtomic / xs:NCName value.
                                    var nameAtom = Atomize(registers[instr.RegisterB]);
                                    if (nameAtom.IsUndefined || !IsValidPiTargetType(nameAtom))
                                        throw new InvalidOperationException("XPTY0004: The computed processing-instruction target must be a single xs:string, xs:untypedAtomic, or xs:NCName value.");
                                    target = nameAtom.ToString().Trim();
                                }
                                else
                                {
                                    target = computedInfo.LocalName!;
                                }
                                // XQDY0041: the target must be a valid NCName (colons are not
                                // allowed); XQDY0064: the target must not be 'xml' in any case.
                                if (target.Contains(':') || !IsValidNcName(target))
                                    throw new InvalidOperationException($"XQDY0041: Invalid processing instruction target '{target}'.");
                                if (target.Equals("xml", StringComparison.OrdinalIgnoreCase))
                                    throw new InvalidOperationException($"XQDY0064: Invalid processing instruction target '{target}'.");
                                var data = JoinAtomizedItems(registers[instr.RegisterC], " ").TrimStart();
                                // XQDY0026: PI data must not contain '?>'.
                                if (data.Contains("?>", StringComparison.Ordinal))
                                    throw new InvalidOperationException("XQDY0026: Processing instruction data must not contain '?>'.");
                                if (context.ContentNodeConstructorHook is null)
                                    throw new InvalidOperationException("Node construction is not available: no content-node provider is registered (EvaluationContext.ContentNodeConstructorHook).");
                                registers[instr.RegisterA] = XdmValue.FromNode(context.ContentNodeConstructorHook(new XdmContentItem(XdmContentKind.ProcessingInstruction, data, null, target)));
                                break;
                            }
                            case ComputedConstructorKind.Namespace:
                            {
                                string nsPrefix;
                                if (computedInfo.HasNameExpression)
                                {
                                    var prefixAtom = Atomize(registers[instr.RegisterB]);
                                    if (prefixAtom.IsUndefined)
                                    {
                                        // An empty prefix expression yields a default
                                        // namespace declaration (nscons-015).
                                        nsPrefix = string.Empty;
                                    }
                                    else
                                    {
                                        // XPTY0004: the prefix expression must atomize to a single
                                        // xs:string / xs:untypedAtomic / xs:NCName value
                                        // (nscons-043/044: xs:anyURI and xs:duration are rejected).
                                        if (prefixAtom.Kind != XdmValueKind.String
                                            || prefixAtom.SchemaTypeName is not (null or "untypedAtomic" or "NCName"))
                                        {
                                            throw new InvalidOperationException("XPTY0004: The computed namespace prefix must be a single xs:string, xs:untypedAtomic, or xs:NCName value.");
                                        }
                                        nsPrefix = prefixAtom.ToString().Trim();
                                    }
                                }
                                else
                                {
                                    nsPrefix = computedInfo.LocalName!;
                                }
                                var uri = JoinAtomizedItems(registers[instr.RegisterC], " ");
                                // XQDY0101: reserved/invalid namespace-node forms.
                                if (nsPrefix == "xmlns")
                                    throw new InvalidOperationException("XQDY0101: The 'xmlns' prefix must not be used in a namespace constructor.");
                                if (nsPrefix == "xml" && uri != "http://www.w3.org/XML/1998/namespace")
                                    throw new InvalidOperationException("XQDY0101: The 'xml' prefix must only be bound to the XML namespace URI.");
                                if (nsPrefix != "xml" && uri == "http://www.w3.org/XML/1998/namespace")
                                    throw new InvalidOperationException("XQDY0101: The XML namespace URI must only be bound to the 'xml' prefix.");
                                if (uri == "http://www.w3.org/2000/xmlns/")
                                    throw new InvalidOperationException("XQDY0101: A namespace constructor must not bind a prefix to the XMLNS namespace URI.");
                                if (uri.Length == 0 && nsPrefix.Length > 0)
                                    throw new InvalidOperationException("XQDY0101: A namespace constructor with a non-empty prefix must not have an empty URI.");
                                // XQDY0074: the prefix must be a valid NCName (nscons-016/017);
                                // reserved-prefix/URI misuse above is XQDY0101.
                                if (nsPrefix.Length > 0 && !IsValidNcName(nsPrefix))
                                    throw new InvalidOperationException($"XQDY0074: Invalid namespace prefix '{nsPrefix}'.");
                                if (context.ContentNodeConstructorHook is null)
                                    throw new InvalidOperationException("Node construction is not available: no content-node provider is registered (EvaluationContext.ContentNodeConstructorHook).");
                                registers[instr.RegisterA] = XdmValue.FromNode(context.ContentNodeConstructorHook(new XdmContentItem(XdmContentKind.Namespace, uri, null, nsPrefix)));
                                break;
                            }
                        }
                        ip++;
                        break;
                    }

                case IrOpCode.SaveNamespaces:
                    // Snapshot namespace bindings and the default element namespace for
                    // constructor-local namespace scoping (restored by RestoreNamespaces).
                    registers[instr.RegisterA] = XdmValue.FromExternal(
                        (context.SnapshotNamespaces(), context.DefaultElementNamespace, context.ConstructorLocalNamespaceCount));
                    ip++;
                    break;

                case IrOpCode.DeclareNamespace:
                    {
                        // Constructor-local namespace declaration (prefix operand in the pool,
                        // URI value in RegisterB). Empty prefix sets the default element namespace.
                        string prefix = (string)literalPool[instr.Operand]!;
                        var nsValue = registers[instr.RegisterB];
                        string uri = nsValue.IsUndefined ? string.Empty : Atomize(nsValue).ToString();
                        if (prefix.Length > 0)
                            context.AddConstructorLocalNamespace(prefix, uri);
                        if (prefix.Length == 0)
                        {
                            // An empty URI undeclares the default namespace.
                            context.DefaultElementNamespace = uri.Length == 0 ? null : uri;
                        }
                        else if (uri.Length == 0)
                        {
                            // An empty URI undeclares the prefix.
                            context.RemoveNamespace(prefix);
                        }
                        else
                        {
                            context.WithNamespace(prefix, uri);
                        }
                        ip++;
                        break;
                    }

                case IrOpCode.RestoreNamespaces:
                    {
                        var snapshot = ((Dictionary<string, string> Namespaces, string? DefaultNs, int LocalCount))registers[instr.RegisterB].ExternalValue!;
                        context.RestoreNamespaces(snapshot.Namespaces);
                        context.DefaultElementNamespace = snapshot.DefaultNs;
                        context.TruncateConstructorLocalNamespaces(snapshot.LocalCount);
                        ip++;
                        break;
                    }

                case IrOpCode.ConstructElement:
                    {
                        var ctorInfo = (ConstructElementInfo)literalPool[instr.Operand]!;

                        // Evaluate all attribute values first.
                        var evaluatedAttrs = new List<(string LocalName, string? Prefix, string Value)>(ctorInfo.Attributes.Length);
                        foreach (var attr in ctorInfo.Attributes)
                        {
                            var valueParts = new List<string>();
                            for (int i = attr.FirstPart; i < attr.FirstPart + attr.PartCount; i++)
                            {
                                var part = ctorInfo.Parts[i];
                                // The parser normalizes raw whitespace (tab/CR/LF → space) in
                                // literal parts at scan time; characters introduced by character
                                // references (e.g. &#x9;) must survive verbatim (XML 1.0 §3.3.3;
                                // K2-Serialization-6), so no further normalization happens here.
                                // Enclosed-expression values are never normalized.
                                switch (part.Kind)
                                {
                                    case ConstructPartKind.Literal:
                                    case ConstructPartKind.Comment:
                                    case ConstructPartKind.ProcessingInstruction:
                                        valueParts.Add((string)literalPool[part.Index]!);
                                        break;
                                    default:
                                        valueParts.Add(JoinAtomizedItems(registers[instr.RegisterB + part.Index], " "));
                                        break;
                                }
                            }
                            var value = string.Concat(valueParts);

                            // xml:id additionally uses whiteSpace="collapse" normalization
                            // (the xml:id specification; K2-DirectConElem-51).
                            if (attr.LocalName == "id" && attr.Prefix == "xml")
                                value = string.Join(' ', value.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries));

                            // XQDY0092: xml:space must be "default" or "preserve" (XQ 3.1 §3.9.2).
                            if (attr.LocalName == "space" && attr.Prefix == "xml" && value != "default" && value != "preserve")
                                throw new InvalidOperationException("XQDY0092: The value of xml:space must be 'default' or 'preserve'.");

                            evaluatedAttrs.Add((attr.LocalName, attr.Prefix, value));
                        }

                        // Tag prefix resolves against the static context (constructor-local
                        // declarations were applied by DeclareNamespace); an unprefixed tag
                        // uses the default element namespace (attribute names never do).
                        string? tagNs = null;
                        if (ctorInfo.Prefix is not null)
                        {
                            if (!context.TryResolveNamespace(ctorInfo.Prefix, out var resolvedTagNs))
                                throw new InvalidOperationException($"XPST0081: Prefix '{ctorInfo.Prefix}' is not declared.");
                            tagNs = resolvedTagNs;
                        }
                        else if (!string.IsNullOrEmpty(context.DefaultElementNamespace))
                        {
                            tagNs = context.DefaultElementNamespace;
                        }

                        var attributes = new List<XdmAttributeValue>(evaluatedAttrs.Count);
                        var seenAttrs = new HashSet<(string, string)>();
                        foreach (var (attrLocalName, attrPrefix, attrValue) in evaluatedAttrs)
                        {
                            string? attrNs = null;
                            if (attrPrefix is not null && attrPrefix != "xmlns")
                            {
                                if (!context.TryResolveNamespace(attrPrefix, out var resolvedAttrNs))
                                    throw new InvalidOperationException($"XPST0081: Prefix '{attrPrefix}' is not declared.");
                                attrNs = resolvedAttrNs;
                            }

                            // XQDY0025: duplicate expanded attribute names are an error
                            // (xmlns declarations are not ordinary attributes).
                            if (attrLocalName != "xmlns" && attrPrefix != "xmlns" &&
                                !seenAttrs.Add((attrLocalName, attrNs ?? "")))
                            {
                                throw new InvalidOperationException($"XQDY0025: Duplicate attribute '{attrLocalName}'.");
                            }
                            attributes.Add(new XdmAttributeValue(attrLocalName, attrPrefix, attrNs, attrValue));
                        }

                        var content = new List<XdmContentItem>();
                        string? pendingAtomic = null;
                        bool lastWasAtomic = false;
                        bool seenNonAttributeContent = false;
                        void FlushAtomic()
                        {
                            if (pendingAtomic is not null)
                            {
                                content.Add(new XdmContentItem(XdmContentKind.Text, pendingAtomic));
                                pendingAtomic = null;
                                lastWasAtomic = false;
                                seenNonAttributeContent = true;
                            }
                        }

                        // One array member (or sequence item) as content: flattened recursively
                        // (nested arrays and sequence members included, ArrayTest-047/051).
                        void AddArrayMember(XdmValue member)
                        {
                            if (member.IsSequence && member.SequenceValue is not null)
                            {
                                foreach (var inner in XdmSequence.FromSource(member.SequenceValue))
                                    AddArrayMember(inner);
                                return;
                            }
                            if (member.IsArray && member.ArrayValue is not null)
                            {
                                foreach (var nested in member.ArrayValue.Values)
                                    AddArrayMember(nested);
                                return;
                            }
                            if (member.IsNode && member.NodeValue.NodeKind == XdmNodeKind.Attribute)
                            {
                                if (seenNonAttributeContent)
                                    throw new InvalidOperationException("XQTY0024: An attribute node in element content must not follow other content.");
                                var attrNode = member.NodeValue;
                                string? itemNs = string.IsNullOrEmpty(attrNode.NamespaceUri) ? null : attrNode.NamespaceUri;
                                if (attrNode.LocalName != "xmlns" && attrNode.Prefix != "xmlns" &&
                                    !seenAttrs.Add((attrNode.LocalName, itemNs ?? "")))
                                {
                                    throw new InvalidOperationException($"XQDY0025: Duplicate attribute '{attrNode.LocalName}'.");
                                }
                                attributes.Add(new XdmAttributeValue(attrNode.LocalName, attrNode.Prefix, itemNs, attrNode.StringValue) { SourceNode = attrNode });
                                return;
                            }
                            if (member.IsNode)
                            {
                                FlushAtomic();
                                content.Add(new XdmContentItem(XdmContentKind.Node, null, member));
                                seenNonAttributeContent = true;
                                return;
                            }
                            var memberText = member.ToString();
                            pendingAtomic = pendingAtomic is null ? memberText : pendingAtomic + (lastWasAtomic ? " " : "") + memberText;
                            lastWasAtomic = true;
                            seenNonAttributeContent = true;
                        }

                        for (int i = ctorInfo.FirstContentPart; i < ctorInfo.FirstContentPart + ctorInfo.ContentPartCount; i++)
                        {
                            var part = ctorInfo.Parts[i];
                            switch (part.Kind)
                            {
                                case ConstructPartKind.Literal:
                                    FlushAtomic();
                                    content.Add(new XdmContentItem(XdmContentKind.Text, (string)literalPool[part.Index]!));
                                    seenNonAttributeContent = true;
                                    break;
                                case ConstructPartKind.Comment:
                                    FlushAtomic();
                                    content.Add(new XdmContentItem(XdmContentKind.Comment, (string)literalPool[part.Index]!));
                                    seenNonAttributeContent = true;
                                    break;
                                case ConstructPartKind.ProcessingInstruction:
                                    FlushAtomic();
                                    content.Add(new XdmContentItem(XdmContentKind.ProcessingInstruction,
                                        (string)literalPool[part.Index]!, null, (string)literalPool[part.Index2]!));
                                    seenNonAttributeContent = true;
                                    break;
                                default:
                                    foreach (var item in MaterializeSequence(registers[instr.RegisterB + part.Index]))
                                    {
                                        // XQuery content rules: attribute nodes in content become
                                        // attributes of the element, but only before any other
                                        // content (XQTY0024 after non-attribute content).
                                        if (item.IsNode && item.NodeValue.NodeKind == XdmNodeKind.Attribute)
                                        {
                                            if (seenNonAttributeContent)
                                                throw new InvalidOperationException("XQTY0024: An attribute node in element content must not follow other content.");
                                            var attrNode = item.NodeValue;
                                            // The attribute keeps the namespace it had in the source.
                                            string? itemNs = string.IsNullOrEmpty(attrNode.NamespaceUri) ? null : attrNode.NamespaceUri;
                                            if (attrNode.LocalName != "xmlns" && attrNode.Prefix != "xmlns" &&
                                                !seenAttrs.Add((attrNode.LocalName, itemNs ?? "")))
                                            {
                                                throw new InvalidOperationException($"XQDY0025: Duplicate attribute '{attrNode.LocalName}'.");
                                            }
                                            attributes.Add(new XdmAttributeValue(attrNode.LocalName, attrNode.Prefix, itemNs, attrNode.StringValue) { SourceNode = attrNode });
                                            continue;
                                        }
                                        // A namespace node in content becomes a namespace declaration
                                        // (XQDY0102 on conflicting redeclaration of the same prefix).
                                        // The node's name is the bound prefix (empty for a default
                                        // declaration); its string value is the namespace URI.
                                        if (item.IsNode && item.NodeValue.NodeKind == XdmNodeKind.Namespace)
                                        {
                                            var nsNode = item.NodeValue;
                                            string declPrefix = nsNode.LocalName;
                                            string declUri = nsNode.StringValue;
                                            if (declPrefix.Length == 0)
                                            {
                                                // Spec bug 22032: a default namespace declaration
                                                // conflicts with an element name in no namespace, and an
                                                // empty-URI undeclaration with an element name in one.
                                                if (string.IsNullOrEmpty(tagNs) && declUri.Length > 0)
                                                    throw new InvalidOperationException("XQDY0102: A default namespace declaration must not be added to an element in no namespace.");
                                                if (!string.IsNullOrEmpty(tagNs) && declUri.Length == 0)
                                                    throw new InvalidOperationException("XQDY0102: The default namespace must not be undeclared on an element in a namespace.");
                                                if (!string.IsNullOrEmpty(context.DefaultElementNamespace) && context.DefaultElementNamespace != declUri)
                                                    throw new InvalidOperationException("XQDY0102: The default namespace is redeclared with a different URI.");
                                                context.DefaultElementNamespace = declUri.Length == 0 ? null : declUri;
                                            }
                                            else
                                            {
                                                if (context.TryResolveNamespace(declPrefix, out var existing) && existing != declUri)
                                                    throw new InvalidOperationException($"XQDY0102: The namespace prefix '{declPrefix}' is redeclared with a different URI.");
                                                context.WithNamespace(declPrefix, declUri);
                                            }
                                            content.Add(new XdmContentItem(XdmContentKind.Namespace, declUri, null, declPrefix));
                                            // Namespace declarations are not "other content": they may
                                            // interleave freely with attributes at the start of the
                                            // content (nscons-001 — no XQTY0024 between them).
                                            continue;
                                        }
                                        if (item.IsNode && item.NodeValue.NodeKind is XdmNodeKind.Text)
                                        {
                                            // Text nodes merge with adjacent atomic text rather than
                                            // being copied; no separator at a text-node boundary.
                                            var textNodeValue = item.NodeValue.StringValue;
                                            pendingAtomic = pendingAtomic is null ? textNodeValue : pendingAtomic + textNodeValue;
                                            lastWasAtomic = false;
                                            seenNonAttributeContent = true;
                                            continue;
                                        }
                                        if (item.IsNode)
                                        {
                                            FlushAtomic();
                                            content.Add(new XdmContentItem(XdmContentKind.Node, null, item) { IsLiteralElement = part.IsLiteralElement });
                                            seenNonAttributeContent = true;
                                        }
                                        else if (item.IsFunction)
                                        {
                                            // XQTY0105: element content must not contain function items
                                            // (function-item-5: element a { avg#1 }).
                                            throw new InvalidOperationException("XQTY0105: Element content must not contain a function item.");
                                        }
                                        else if (item.IsArray && item.ArrayValue is not null)
                                        {
                                            // Arrays in content are flattened: their members are
                                            // processed recursively as content (ArrayTest-047/051).
                                            foreach (var member in item.ArrayValue.Values)
                                                AddArrayMember(member);
                                        }
                                        else
                                        {
                                            // Adjacent atomic values WITHIN one enclosed expression join
                                            // with single spaces; separate expressions concatenate
                                            // without a separator. A text node adjacent to an atomic
                                            // value takes no separator either.
                                            var text = item.ToString();
                                            pendingAtomic = pendingAtomic is null ? text : pendingAtomic + (lastWasAtomic ? " " : "") + text;
                                            lastWasAtomic = true;
                                            seenNonAttributeContent = true;
                                        }
                                    }
                                    // End of one enclosed expression: flush so the next part starts fresh.
                                    FlushAtomic();
                                    break;
                            }
                        }
                        FlushAtomic();
                        AppendConstructorLocalNamespaces(content, attributes, context, ctorInfo.Prefix, ctorInfo.LexicalNamespaces);

                        if (context.ElementConstructorHook is null)
                        {
                            throw new InvalidOperationException(
                                "Node construction is not available: no element-constructor provider is registered (EvaluationContext.ElementConstructorHook).");
                        }

                        ApplyConstructionCopyMode(content, ctorInfo.PreserveNamespaces, ctorInfo.InheritNamespaces, ctorInfo.ConstructionMode);
                        var spec = new XdmElementSpec(ctorInfo.LocalName, ctorInfo.Prefix, tagNs, attributes, content, context.BaseUri, context.Xml11Mode) { ConstructionMode = ctorInfo.ConstructionMode };
                        registers[instr.RegisterA] = XdmValue.FromNode(context.ElementConstructorHook(spec));
                        ip++;
                        break;
                    }

                case IrOpCode.ConstructContentNode:
                    {
                        var item = (XdmContentItem)literalPool[instr.Operand]!;
                        if (context.ContentNodeConstructorHook is null)
                        {
                            throw new InvalidOperationException(
                                "Node construction is not available: no content-node provider is registered (EvaluationContext.ContentNodeConstructorHook).");
                        }
                        registers[instr.RegisterA] = XdmValue.FromNode(context.ContentNodeConstructorHook(item));
                        ip++;
                        break;
                    }

                case IrOpCode.Window:
                    {
                        var windowInfo = (WindowInfo)literalPool[instr.Operand]!;
                        var input = registers[instr.RegisterB];
                        var items = MaterializeSequence(input);
                        var results = new List<XdmValue>();

                        // Resolve every variable name this clause binds (including lexical
                        // prefix:local and Q{uri}local forms) to its (local, namespace) pair,
                        // so the bindings match the way references to the variables resolve.
                        var boundVars = new List<(string Local, string Ns)>
                        {
                            ResolveWindowVariableName(windowInfo.VariableName, context)
                        };
                        foreach (var name in new[]
                        {
                            windowInfo.StartCurrent, windowInfo.StartPos, windowInfo.StartPrev, windowInfo.StartNext,
                            windowInfo.EndCurrent, windowInfo.EndPos, windowInfo.EndPrev, windowInfo.EndNext
                        })
                        {
                            if (name is null)
                                continue;
                            var resolved = ResolveWindowVariableName(name, context);
                            if (!boundVars.Contains(resolved))
                                boundVars.Add(resolved);
                        }

                        // Save the previous bindings of every variable this clause binds.
                        var savedBindings = new List<((string Local, string Ns) Var, bool Had, XdmValue Value)>(boundVars.Count);
                        foreach (var boundVar in boundVars)
                        {
                            bool had = context.TryGetVariable(boundVar.Local, out var saved, boundVar.Ns);
                            savedBindings.Add((boundVar, had, saved));
                        }

                        bool hasEndCondition = windowInfo.EndEntryPoint >= 0;

                        if (windowInfo.Sliding)
                        {
                            // Sliding: every item matching the start condition opens a new
                            // (possibly overlapping) window. Without an end condition each
                            // window extends to the end of the input sequence.
                            for (int i = 0; i < items.Length; i++)
                            {
                                if (!EvaluateWindowCondition(module, context, registers, windowInfo.StartEntryPoint,
                                        items, i, i + 1,
                                        windowInfo.StartCurrent, windowInfo.StartPos, windowInfo.StartPrev, windowInfo.StartNext))
                                    continue;

                                var startBindings = CaptureWindowBindings(items, i, i + 1,
                                    windowInfo.StartCurrent, windowInfo.StartPos, windowInfo.StartPrev, windowInfo.StartNext);

                                var windowItems = new List<XdmValue>();
                                bool closed = false;
                                if (hasEndCondition)
                                {
                                    for (int j = i; j < items.Length; j++)
                                    {
                                        windowItems.Add(items[j]);
                                        if (EvaluateWindowCondition(module, context, registers, windowInfo.EndEntryPoint,
                                                items, j, j + 1,
                                                windowInfo.EndCurrent, windowInfo.EndPos, windowInfo.EndPrev, windowInfo.EndNext))
                                        {
                                            EmitFlworWindow(module, context, registers, windowInfo, results, windowItems,
                                                startBindings, items, j, j + 1);
                                            closed = true;
                                            break;
                                        }
                                    }
                                }
                                else
                                {
                                    windowItems.AddRange(items.Skip(i));
                                }
                                if (!closed && !windowInfo.OnlyEnd)
                                {
                                    EmitFlworWindow(module, context, registers, windowInfo, results, windowItems,
                                        startBindings, items, items.Length - 1, items.Length);
                                }
                            }
                        }
                        else
                        {
                            // Tumbling: a new window starts only when no window is open.
                            // Without an end condition a window closes when the next one
                            // starts (exclusive) or at the end of the input sequence.
                            var windowItems = new List<XdmValue>();
                            List<(string Name, XdmValue Value)>? startBindings = null;
                            bool open = false;
                            for (int i = 0; i < items.Length; i++)
                            {
                                if (!open)
                                {
                                    if (!EvaluateWindowCondition(module, context, registers, windowInfo.StartEntryPoint,
                                            items, i, i + 1,
                                            windowInfo.StartCurrent, windowInfo.StartPos, windowInfo.StartPrev, windowInfo.StartNext))
                                        continue;
                                    open = true;
                                    startBindings = CaptureWindowBindings(items, i, i + 1,
                                        windowInfo.StartCurrent, windowInfo.StartPos, windowInfo.StartPrev, windowInfo.StartNext);
                                    windowItems.Add(items[i]);
                                }
                                else if (!hasEndCondition &&
                                         EvaluateWindowCondition(module, context, registers, windowInfo.StartEntryPoint,
                                             items, i, i + 1,
                                             windowInfo.StartCurrent, windowInfo.StartPos, windowInfo.StartPrev, windowInfo.StartNext))
                                {
                                    // No end condition: the current window closes before a
                                    // new start; the new window opens at this item.
                                    EmitFlworWindow(module, context, registers, windowInfo, results, windowItems,
                                        startBindings!, items, i - 1, i);
                                    startBindings = CaptureWindowBindings(items, i, i + 1,
                                        windowInfo.StartCurrent, windowInfo.StartPos, windowInfo.StartPrev, windowInfo.StartNext);
                                    windowItems = new List<XdmValue> { items[i] };
                                }
                                else
                                {
                                    windowItems.Add(items[i]);
                                }

                                if (open && hasEndCondition &&
                                    EvaluateWindowCondition(module, context, registers, windowInfo.EndEntryPoint,
                                        items, i, i + 1,
                                        windowInfo.EndCurrent, windowInfo.EndPos, windowInfo.EndPrev, windowInfo.EndNext))
                                {
                                    EmitFlworWindow(module, context, registers, windowInfo, results, windowItems,
                                        startBindings!, items, i, i + 1);
                                    open = false;
                                    windowItems = new List<XdmValue>();
                                }
                            }
                            if (open && !windowInfo.OnlyEnd)
                            {
                                EmitFlworWindow(module, context, registers, windowInfo, results, windowItems,
                                    startBindings!, items, items.Length - 1, items.Length);
                            }
                        }

                        // Restore the previous variable bindings.
                        foreach (var (boundVar, had, value) in savedBindings)
                        {
                            if (had)
                                context.WithVariable(boundVar.Local, value, boundVar.Ns);
                            else
                                context.RemoveVariable(boundVar.Local, boundVar.Ns);
                        }

                        registers[instr.RegisterA] = XdmValue.FromSequence(MaterializedSequence.FromList(results));
                        ip++;
                        break;
                    }

                case IrOpCode.TryCatch:
                    {
                        var info = (TryCatchInfo)literalPool[instr.Operand]!;
                        try
                        {
                            var (result, _) = ExecuteBlock(module, context, registers, info.TryEntryPoint);
                            registers[instr.RegisterA] = result;
                        }
                        // Errors raised by lazy global variable initializers are not caught
                        // by try/catch (XQuery try-006/007).
                        catch (Exception ex) when (ex is not GlobalVariableEvaluationException)
                        {
                            var details = XPathError.GetErrorDetails(ex);
                            // try/catch catches dynamic errors only: static (XPST/XQST)
                            // errors propagate even when a pattern would match them.
                            if (XPathError.IsUncatchableStaticError(ex, details))
                                throw;
                            CatchClauseInfo? matched = null;
                            foreach (var clause in info.Clauses)
                            {
                                bool clauseMatches = false;
                                foreach (var pattern in clause.Patterns)
                                {
                                    if (XPathError.CatchPatternMatches(pattern, details, context))
                                    {
                                        clauseMatches = true;
                                        break;
                                    }
                                }
                                if (clauseMatches)
                                {
                                    matched = clause;
                                    break;
                                }
                            }
                            // No catch clause matches the error: it propagates unchanged.
                            if (matched is null)
                                throw;
                            var previousErrorVars = XPathError.BindCatchErrorVariables(context, details);
                            try
                            {
                                var (catchResult, _) = ExecuteBlock(module, context, registers, matched.EntryPoint);
                                registers[instr.RegisterA] = catchResult;
                            }
                            finally
                            {
                                XPathError.RestoreCatchErrorVariables(context, previousErrorVars);
                            }
                        }
                        ip++;
                        break;
                    }

                // ------------------------------------------------------------------
                // Axes
                // ------------------------------------------------------------------
                case IrOpCode.Child:
                case IrOpCode.Descendant:
                case IrOpCode.DescendantOrSelf:
                case IrOpCode.Ancestor:
                case IrOpCode.AncestorOrSelf:
                case IrOpCode.Attribute:
                case IrOpCode.Parent:
                case IrOpCode.Self:
                case IrOpCode.Following:
                case IrOpCode.FollowingSibling:
                case IrOpCode.Preceding:
                case IrOpCode.PrecedingSibling:
                case IrOpCode.Namespace:
                    {
                        var input = registers[instr.RegisterB];
                        var axis = ToXdmAxis(instr.OpCode);
                        registers[instr.RegisterA] = ApplyAxis(input, axis, instr.RegisterC != 0);
                        ip++;
                        break;
                    }

                case IrOpCode.DocumentRoot:
                    {
                        var input = registers[instr.RegisterB];
                        if (input.IsUndefined)
                        {
                            // No context item: the path cannot be evaluated.
                            registers[instr.RegisterA] = XdmValue.Undefined;
                        }
                        else if (input.IsAtomic)
                        {
                            throw new InvalidOperationException("XPTY0020: An axis step requires a context item that is a node.");
                        }
                        else if (input.IsNode && input.NodeValue != null)
                        {
                            var node = input.NodeValue;
                            var root = node.Document;
                            if (root == null)
                            {
                                // Parentless node: the root of its tree is the node itself.
                                root = node;
                            }
                            if (root.NodeKind != XdmNodeKind.Document)
                            {
                                throw new InvalidOperationException("XPDY0050: The root of the tree containing the context item is not a document node.");
                            }
                            registers[instr.RegisterA] = XdmValue.FromNode(root);
                        }
                        else
                        {
                            registers[instr.RegisterA] = XdmValue.Undefined;
                        }
                        ip++;
                        break;
                    }

                // ------------------------------------------------------------------
                // Node tests
                // ------------------------------------------------------------------
                case IrOpCode.NameTest:
                    {
                        string name = (string)literalPool[instr.Operand]!;
                        var input = registers[instr.RegisterB];

                        // XPath 4.0: a name test applied to map/array items performs a key
                        // lookup ($m//b, element-to-map-550+); nodes in a mixed sequence
                        // keep their name-test semantics, arrays and atomics yield nothing.
                        // JNodes (the XPath 4.0 §17.7 navigation product) match the test
                        // against their entry key; the wildcard passes them through.
                        if (MayContainMaps(input))
                        {
                            var selected = new List<XdmValue>();
                            var nodePredicate = BuildNameTestPredicate(name, context);
                            foreach (var item in FlattenItems(input))
                            {
                                if (item.IsJNode)
                                {
                                    if (name == "*" || JNodeKeyMatchesName(item.JNodeValue.Key, name, context))
                                        selected.Add(item);
                                }
                                else if (item.IsMap)
                                {
                                    var map = item.MapValue;
                                    if (name == "*")
                                    {
                                        foreach (var k in map.Keys)
                                            if (map.TryGetValue(k, out var all))
                                                AddFlattened(selected, all);
                                    }
                                    else if (map.TryGetValue(XdmValue.FromString(name), out var v))
                                    {
                                        AddFlattened(selected, v);
                                    }
                                }
                                else if (item.IsNode && nodePredicate(item.NodeValue))
                                {
                                    selected.Add(item);
                                }
                            }
                            registers[instr.RegisterA] = selected.Count == 0
                                ? XdmValue.Undefined
                                : XdmValue.FromSequence(MaterializedSequence.FromList(selected));
                            ip++;
                            break;
                        }
                        XdmValue filtered;

                        // Wildcard: match any name (kind test already restricted node kind).
                        if (name == "*")
                        {
                            filtered = FilterNodesLazy(input, static n => true);
                        }
                        // Namespace wildcard prefix:* — match any local name in the namespace.
                        else if (name.EndsWith(":*", StringComparison.Ordinal))
                        {
                            var wildcardPrefix = name[..^2];
                            if (context.TryResolveNamespace(wildcardPrefix, out var wildcardNsUri))
                                filtered = FilterNodesLazy(input, n => n.NamespaceUri == wildcardNsUri);
                            else
                                filtered = FilterNodesLazy(input, static n => false);
                        }
                        else
                        {
                            var predicate = BuildNameTestPredicate(name, context);
                            filtered = FilterNodesLazy(input, predicate);
                        }
                        registers[instr.RegisterA] = filtered;
                        ip++;
                        break;
                    }

                // XPath 4.0 string-literal lookup step (E/"key"): selects the items whose
                // JNode entry key equals the literal ($m/"key" is the child entry keyed
                // "key"). The child axis has already produced the entry JNodes; raw map
                // items (defensive: a map reaching the opcode without an axis wrap) are
                // looked up directly and wrapped with an implicit root parent.
                case IrOpCode.LookupKey:
                    {
                        string key = (string)literalPool[instr.Operand]!;
                        var input = registers[instr.RegisterB];
                        var selected = new List<XdmValue>();
                        foreach (var item in FlattenItems(input))
                        {
                            if (item.IsJNode)
                            {
                                var entryKey = item.JNodeValue.Key;
                                if (entryKey.Kind == XdmValueKind.String && entryKey.StringValue == key)
                                    selected.Add(item);
                            }
                            else if (item.IsMap)
                            {
                                var map = item.MapValue;
                                var lookupKey = XdmValue.FromString(key);
                                foreach (var entry in map.Entries)
                                {
                                    if (XdmValueEqualityComparer.Instance.Equals(entry.Key, lookupKey))
                                    {
                                        selected.Add(XdmValue.FromJNode(
                                            new XdmJNode(entry.Value, entry.Key, new XdmJNode(item))));
                                        break;
                                    }
                                }
                            }
                        }
                        registers[instr.RegisterA] = selected.Count == 0
                            ? XdmValue.Undefined
                            : XdmValue.FromSequence(MaterializedSequence.FromList(selected));
                        ip++;
                        break;
                    }

                // XPath 4.0 integer lookup step (E/2): selects the child JNode whose key
                // equals the integer — an array position or an integer map key.
                case IrOpCode.LookupIndex:
                    {
                        long index = long.Parse((string)literalPool[instr.Operand]!, CultureInfo.InvariantCulture);
                        var input = registers[instr.RegisterB];
                        var selected = new List<XdmValue>();
                        foreach (var item in FlattenItems(input))
                        {
                            if (item.IsJNode)
                            {
                                var entryKey = item.JNodeValue.Key;
                                if (entryKey.Kind == XdmValueKind.Integer && entryKey.IntegerValue == index)
                                    selected.Add(item);
                            }
                            else if (item.IsMap)
                            {
                                var map = item.MapValue;
                                var intKey = XdmValue.FromInteger(index);
                                foreach (var entry in map.Entries)
                                {
                                    if (XdmValueEqualityComparer.Instance.Equals(entry.Key, intKey))
                                    {
                                        selected.Add(XdmValue.FromJNode(
                                            new XdmJNode(entry.Value, entry.Key, new XdmJNode(item))));
                                        break;
                                    }
                                }
                            }
                            else if (item.IsArray)
                            {
                                var members = item.ArrayValue;
                                if (index >= 1 && index <= members.Count)
                                {
                                    selected.Add(XdmValue.FromJNode(new XdmJNode(
                                        members.Values.ElementAt((int)index - 1),
                                        XdmValue.FromInteger(index),
                                        new XdmJNode(item))));
                                }
                            }
                        }
                        registers[instr.RegisterA] = selected.Count == 0
                            ? XdmValue.Undefined
                            : XdmValue.FromSequence(MaterializedSequence.FromList(selected));
                        ip++;
                        break;
                    }

                // XPath 4.0 braced key selector (E/child::{K}, PR2667): selects the child
                // JNode whose key equals the evaluated key expression.
                case IrOpCode.LookupComputed:
                    {
                        var input = registers[instr.RegisterB];
                        var keyValue = Atomize(registers[instr.RegisterC]);
                        var selected = new List<XdmValue>();
                        foreach (var item in FlattenItems(input))
                        {
                            if (item.IsJNode)
                            {
                                if (XdmValueEqualityComparer.Instance.Equals(item.JNodeValue.Key, keyValue))
                                    selected.Add(item);
                            }
                            else if (item.IsMap)
                            {
                                var map = item.MapValue;
                                foreach (var entry in map.Entries)
                                {
                                    if (XdmValueEqualityComparer.Instance.Equals(entry.Key, keyValue))
                                    {
                                        selected.Add(XdmValue.FromJNode(
                                            new XdmJNode(entry.Value, entry.Key, new XdmJNode(item))));
                                        break;
                                    }
                                }
                            }
                            else if (item.IsArray && keyValue.Kind == XdmValueKind.Integer)
                            {
                                var members = item.ArrayValue;
                                long index = keyValue.IntegerValue;
                                if (index >= 1 && index <= members.Count)
                                {
                                    selected.Add(XdmValue.FromJNode(new XdmJNode(
                                        members.Values.ElementAt((int)index - 1),
                                        XdmValue.FromInteger(index),
                                        new XdmJNode(item))));
                                }
                            }
                        }
                        registers[instr.RegisterA] = selected.Count == 0
                            ? XdmValue.Undefined
                            : XdmValue.FromSequence(MaterializedSequence.FromList(selected));
                        ip++;
                        break;
                    }

                case IrOpCode.KindTest:
                    {
                        string kindName = (string)literalPool[instr.Operand]!;
                        var input = registers[instr.RegisterB];
                        // XPath 4.0: node() over map/array items is the identity; other
                        // kinds keep only matching nodes (element-to-map-550+).
                        if (MayContainMaps(input))
                        {
                            if (kindName == "node")
                            {
                                registers[instr.RegisterA] = input;
                            }
                            else if (kindName == "element")
                            {
                                // XPath 4.0 map navigation: an element kind test preserves
                                // map/array/JNode items so the following name test performs
                                // the key lookup ($m//id, element-to-map-559+); nodes must match.
                                var kept = new List<XdmValue>();
                                foreach (var item in FlattenItems(input))
                                {
                                    if (item.IsMap || item.IsArray || item.IsJNode)
                                        kept.Add(item);
                                    else if (item.IsNode && MatchesKindTest(item.NodeValue, kindName, context))
                                        kept.Add(item);
                                }
                                registers[instr.RegisterA] = kept.Count == 0
                                    ? XdmValue.Undefined
                                    : XdmValue.FromSequence(MaterializedSequence.FromList(kept));
                            }
                            else
                            {
                                var kept = new List<XdmValue>();
                                foreach (var item in FlattenItems(input))
                                {
                                    if (item.IsNode && MatchesKindTest(item.NodeValue, kindName, context))
                                        kept.Add(item);
                                }
                                registers[instr.RegisterA] = kept.Count == 0
                                    ? XdmValue.Undefined
                                    : XdmValue.FromSequence(MaterializedSequence.FromList(kept));
                            }
                            ip++;
                            break;
                        }
                        var filtered = FilterNodesLazy(input, n => MatchesKindTest(n, kindName, context));
                        registers[instr.RegisterA] = filtered;
                        ip++;
                        break;
                    }

                case IrOpCode.KindTestType:
                    {
                        string typeName = (string)literalPool[instr.Operand]!;
                        var input = registers[instr.RegisterB];
                        ValidateKindTestTypeName(typeName, context);
                        var filtered = FilterNodes(input, n => n.NodeKind == XdmNodeKind.Attribute
                            ? IsAttributeTypeCompatible(typeName, context, n)
                            : IsElementTypeCompatible(typeName, context, n));
                        registers[instr.RegisterA] = filtered;
                        ip++;
                        break;
                    }

                case IrOpCode.SchemaElementTest:
                    {
                        string nameArg = (string)literalPool[instr.Operand]!;
                        var input = registers[instr.RegisterB];
                        var filtered = FilterNodes(input, n => MatchesSchemaElement(n, nameArg, context));
                        registers[instr.RegisterA] = filtered;
                        ip++;
                        break;
                    }

                case IrOpCode.SchemaAttributeTest:
                    {
                        string nameArg = (string)literalPool[instr.Operand]!;
                        var input = registers[instr.RegisterB];
                        var filtered = FilterNodes(input, n => MatchesSchemaAttribute(n, nameArg, context));
                        registers[instr.RegisterA] = filtered;
                        ip++;
                        break;
                    }

                case IrOpCode.NamespaceTest:
                    {
                        string prefix = (string)literalPool[instr.Operand]!;
                        var input = registers[instr.RegisterB];
                        // XPath 4.0: namespace filtering does not apply to map/array items
                        // (the key lookup of the following name test sees them unchanged).
                        if (MayContainMaps(input))
                        {
                            registers[instr.RegisterA] = input;
                            ip++;
                            break;
                        }
                        XdmValue filtered;
                        if (prefix == "Q{}")
                        {
                            // Sentinel from a Q{}* wildcard: match the empty namespace
                            // unconditionally (never the default element namespace).
                            filtered = FilterNodesLazy(input, n => n.NamespaceUri == "");
                        }
                        else if (context.TryResolveNamespace(prefix, out var nsUri))
                        {
                            filtered = FilterNodesLazy(input, n => n.NamespaceUri == nsUri);
                        }
                        else if (prefix.Contains('/') || prefix.Contains(':'))
                        {
                            // Operand is a URI (e.g. from Q{uri}local syntax) — use directly
                            filtered = FilterNodesLazy(input, n => n.NamespaceUri == prefix);
                        }
                        else if (prefix.Length == 0)
                        {
                            // Empty prefix stands for the default element namespace:
                            // none is declared, so match the empty namespace.
                            filtered = FilterNodesLazy(input, n => n.NamespaceUri == "");
                        }
                        else
                        {
                            // XPST0081: a name test with an unresolvable prefix is a static error.
                            throw new InvalidOperationException($"XPST0081: Prefix '{prefix}' is not declared.");
                        }
                        registers[instr.RegisterA] = filtered;
                        ip++;
                        break;
                    }

                // ------------------------------------------------------------------
                // Predicates / Filtering
                // ------------------------------------------------------------------
                case IrOpCode.Filter:
                    {
                        var sequence = registers[instr.RegisterB];
                        int predicateEntry = instr.Operand;

                        // Single-pass (streamed) input: filter lazily so records are
                        // pulled and released one at a time. The context size is unknown;
                        // fn:last() inside the predicate raises a streaming error.
                        if (sequence.IsSequence && sequence.SequenceValue is ISinglePassSequence singlePassFilterInput)
                        {
                            registers[instr.RegisterA] = XdmValue.FromSequence(XdmSequence.FromSource(
                                new SinglePassXdmSequence(LazyFilterIterator(
                                    module, context, registers, predicateEntry, singlePassFilterInput))));
                            ip++;
                            break;
                        }

                        // Copy-free view over the input: no ToArray double copy for lazy
                        // axis results, no copy at all for materialized sequences.
                        var items = MaterializeSequenceView(sequence);
                        if (items.Count == 0)
                        {
                            registers[instr.RegisterA] = XdmValue.FromSequence(XdmSequence.Empty);
                            ip++;
                            break;
                        }

                        // Pooled kept-item buffer instead of a per-evaluation List (cleared
                        // on return so the pool never retains node references).
                        var kept = ArrayPool<XdmValue>.Shared.Rent(items.Count);
                        int keptCount = 0;

                        // Save context
                        var savedItem = context.ContextItem;
                        var savedPos = context.ContextPosition;
                        var savedSize = context.ContextSize;

                        for (int i = 0; i < items.Count; i++)
                        {
                            context.WithFocus(items[i], i + 1, items.Count);
                            var (predResult, _) = ExecuteBlock(module, context, registers, predicateEntry);

                            // Predicate semantics (XPath §2.4): a singleton whose single item
                            // is numeric is a positional predicate ([n] means position() = n);
                            // everything else uses effective boolean value — a node is always
                            // true, so the result must NOT be atomized before the EBV check.
                            bool numericPredicate = false;
                            double numericValue = 0;
                            if (!predResult.IsUndefined)
                            {
                                if (IsNumeric(predResult))
                                {
                                    numericPredicate = true;
                                    numericValue = ToDouble(predResult);
                                }
                                else if (predResult.IsSequence && predResult.SequenceValue is not null &&
                                         TryGetSingletonItem(predResult.SequenceValue, out var singletonItem))
                                {
                                    // A singleton node always has EBV true: keep it without
                                    // re-enumerating a (possibly lazy) predicate result.
                                    if (singletonItem.IsNode)
                                    {
                                        kept[keptCount++] = items[i];
                                        continue;
                                    }
                                    var atomizedItem = Atomize(singletonItem);
                                    if (IsNumeric(atomizedItem))
                                    {
                                        numericPredicate = true;
                                        numericValue = ToDouble(atomizedItem);
                                    }
                                }
                            }

                            if (numericPredicate)
                            {
                                if (numericValue == i + 1)
                                    kept[keptCount++] = items[i];
                            }
                            else if (predResult.GetEffectiveBooleanValue())
                            {
                                kept[keptCount++] = items[i];
                            }
                        }

                        // Restore context
                        context.WithFocus(savedItem, savedPos, savedSize);

                        if (keptCount == 0)
                        {
                            registers[instr.RegisterA] = XdmValue.FromSequence(XdmSequence.Empty);
                        }
                        else if (keptCount == items.Count)
                        {
                            // Nothing was filtered out: the input is the result (aliasing is
                            // safe — sequences are immutable once produced).
                            registers[instr.RegisterA] = sequence.IsSequence
                                ? sequence
                                : XdmValue.FromSequence(XdmSequence.Singleton(sequence));
                        }
                        else
                        {
                            var keptArray = new XdmValue[keptCount];
                            Array.Copy(kept, keptArray, keptCount);
                            registers[instr.RegisterA] = XdmValue.FromSequence(MaterializedSequence.FromArray(keptArray));
                        }
                        ArrayPool<XdmValue>.Shared.Return(kept, clearArray: true);
                        ip++;
                        break;
                    }

                case IrOpCode.Subscript:
                    {
                        var sequence = registers[instr.RegisterB];
                        int index = instr.Operand; // 1-based

                        if (sequence.IsUndefined || index < 1)
                        {
                            registers[instr.RegisterA] = XdmValue.FromSequence(XdmSequence.Empty);
                        }
                        else if (!sequence.IsSequence)
                        {
                            registers[instr.RegisterA] = index == 1 ? sequence : XdmValue.FromSequence(XdmSequence.Empty);
                        }
                        else
                        {
                            var seq = sequence.SequenceValue;
                            if (seq is null)
                            {
                                registers[instr.RegisterA] = XdmValue.FromSequence(XdmSequence.Empty);
                            }
                            else
                            {
                                var en = XdmSequence.FromSource(seq).GetEnumerator();
                                XdmValue? result = null;
                                for (int i = 0; i < index; i++)
                                {
                                    if (!en.MoveNext())
                                    {
                                        result = null;
                                        break;
                                    }
                                    result = en.Current;
                                }
                                registers[instr.RegisterA] = result ?? XdmValue.FromSequence(XdmSequence.Empty);
                            }
                        }
                        ip++;
                        break;
                    }

                case IrOpCode.First:
                    {
                        var sequence = registers[instr.RegisterB];
                        if (sequence.IsUndefined)
                        {
                            registers[instr.RegisterA] = XdmValue.FromSequence(XdmSequence.Empty);
                        }
                        else if (!sequence.IsSequence)
                        {
                            registers[instr.RegisterA] = sequence;
                        }
                        else
                        {
                            var seq = sequence.SequenceValue;
                            if (seq is null)
                                registers[instr.RegisterA] = XdmValue.FromSequence(XdmSequence.Empty);
                            else
                            {
                                var en = XdmSequence.FromSource(seq).GetEnumerator();
                                registers[instr.RegisterA] = en.MoveNext() ? en.Current : XdmValue.FromSequence(XdmSequence.Empty);
                            }
                        }
                        ip++;
                        break;
                    }

                case IrOpCode.Last:
                    {
                        var sequence = registers[instr.RegisterB];
                        if (sequence.IsUndefined)
                        {
                            registers[instr.RegisterA] = XdmValue.FromSequence(XdmSequence.Empty);
                        }
                        else if (!sequence.IsSequence)
                        {
                            registers[instr.RegisterA] = sequence;
                        }
                        else
                        {
                            var seq = sequence.SequenceValue;
                            if (seq is null)
                                registers[instr.RegisterA] = XdmValue.FromSequence(XdmSequence.Empty);
                            else
                            {
                                var en = XdmSequence.FromSource(seq).GetEnumerator();
                                XdmValue? last = null;
                                while (en.MoveNext())
                                    last = en.Current;
                                registers[instr.RegisterA] = last ?? XdmValue.FromSequence(XdmSequence.Empty);
                            }
                        }
                        ip++;
                        break;
                    }

                case IrOpCode.Position:
                    registers[instr.RegisterA] = XdmValue.FromInteger(context.ContextPosition);
                    ip++;
                    break;

                // ------------------------------------------------------------------
                // Comparisons (value comparisons for atomics)
                // ------------------------------------------------------------------
                case IrOpCode.Equal:
                case IrOpCode.NotEqual:
                case IrOpCode.LessThan:
                case IrOpCode.LessThanOrEqual:
                case IrOpCode.GreaterThan:
                case IrOpCode.GreaterThanOrEqual:
                case IrOpCode.ValueEqual:
                case IrOpCode.ValueNotEqual:
                case IrOpCode.ValueLessThan:
                case IrOpCode.ValueLessThanOrEqual:
                case IrOpCode.ValueGreaterThan:
                case IrOpCode.ValueGreaterThanOrEqual:
                    {
                        var cmpResult = Compare(instr.OpCode, registers[instr.RegisterB], registers[instr.RegisterC], context);
                        registers[instr.RegisterA] = cmpResult;
                        ip++;
                        break;
                    }

                case IrOpCode.GeneralEqual:
                case IrOpCode.GeneralNotEqual:
                case IrOpCode.GeneralLessThan:
                case IrOpCode.GeneralLessThanOrEqual:
                case IrOpCode.GeneralGreaterThan:
                case IrOpCode.GeneralGreaterThanOrEqual:
                    // General comparisons have existential semantics over sequences.
                    {
                        var cmpResult = CompareGeneral(instr.OpCode, registers[instr.RegisterB], registers[instr.RegisterC], context);
                        registers[instr.RegisterA] = cmpResult;
                        ip++;
                        break;
                    }

                case IrOpCode.IsSameNode:
                    registers[instr.RegisterA] = EvaluateNodeComparison(NodeComparison.Is, registers[instr.RegisterB], registers[instr.RegisterC]);
                    ip++;
                    break;

                case IrOpCode.PrecedesNode:
                    registers[instr.RegisterA] = EvaluateNodeComparison(NodeComparison.Precedes, registers[instr.RegisterB], registers[instr.RegisterC]);
                    ip++;
                    break;

                case IrOpCode.FollowsNode:
                    registers[instr.RegisterA] = EvaluateNodeComparison(NodeComparison.Follows, registers[instr.RegisterB], registers[instr.RegisterC]);
                    ip++;
                    break;

                // ------------------------------------------------------------------
                // Arithmetic
                // ------------------------------------------------------------------
                case IrOpCode.Add:
                    registers[instr.RegisterA] = Add(registers[instr.RegisterB], registers[instr.RegisterC], context);
                    ip++;
                    break;

                case IrOpCode.Subtract:
                    registers[instr.RegisterA] = Subtract(registers[instr.RegisterB], registers[instr.RegisterC], context);
                    ip++;
                    break;

                case IrOpCode.Multiply:
                    registers[instr.RegisterA] = Multiply(registers[instr.RegisterB], registers[instr.RegisterC], context);
                    ip++;
                    break;

                case IrOpCode.Divide:
                    registers[instr.RegisterA] = Divide(registers[instr.RegisterB], registers[instr.RegisterC], context);
                    ip++;
                    break;

                case IrOpCode.IntegerDivide:
                    registers[instr.RegisterA] = IntegerDivide(registers[instr.RegisterB], registers[instr.RegisterC], context);
                    ip++;
                    break;

                case IrOpCode.Modulo:
                    registers[instr.RegisterA] = Modulo(registers[instr.RegisterB], registers[instr.RegisterC], context);
                    ip++;
                    break;

                case IrOpCode.UnaryPlus:
                    registers[instr.RegisterA] = UnaryPlus(registers[instr.RegisterB], context);
                    ip++;
                    break;

                case IrOpCode.UnaryMinus:
                    registers[instr.RegisterA] = Negate(registers[instr.RegisterB], context);
                    ip++;
                    break;

                // ------------------------------------------------------------------
                // Boolean logic
                // ------------------------------------------------------------------
                case IrOpCode.And:
                    {
                        bool result = registers[instr.RegisterB].GetEffectiveBooleanValue() &&
                                      registers[instr.RegisterC].GetEffectiveBooleanValue();
                        registers[instr.RegisterA] = XdmValue.FromBoolean(result);
                        ip++;
                        break;
                    }

                case IrOpCode.Or:
                    {
                        bool result = registers[instr.RegisterB].GetEffectiveBooleanValue() ||
                                      registers[instr.RegisterC].GetEffectiveBooleanValue();
                        registers[instr.RegisterA] = XdmValue.FromBoolean(result);
                        ip++;
                        break;
                    }

                case IrOpCode.Not:
                    registers[instr.RegisterA] = XdmValue.FromBoolean(!registers[instr.RegisterB].GetEffectiveBooleanValue());
                    ip++;
                    break;

                // ------------------------------------------------------------------
                // String
                // ------------------------------------------------------------------
                case IrOpCode.StringConcat:
                    registers[instr.RegisterA] = XdmValue.FromString(
                        AtomizedStringValue(registers[instr.RegisterB]) + AtomizedStringValue(registers[instr.RegisterC]));
                    ip++;
                    break;

                case IrOpCode.StringLength:
                    {
                        string s = AtomizedString(registers[instr.RegisterB]);
                        registers[instr.RegisterA] = XdmValue.FromInteger(s.Length);
                        ip++;
                        break;
                    }

                case IrOpCode.Substring:
                    {
                        string s = AtomizedString(registers[instr.RegisterB]);
                        double startD = ToDouble(Atomize(registers[instr.RegisterC]));
                        if (double.IsNaN(startD))
                        {
                            registers[instr.RegisterA] = XdmValue.FromString(string.Empty);
                        }
                        else
                        {
                            int start = (int)Math.Round(startD);
                            if (start <= 0) start = 1;
                            if (start > s.Length)
                                registers[instr.RegisterA] = XdmValue.FromString(string.Empty);
                            else if (instr.Operand != 0)
                            {
                                double lenD = ToDouble(Atomize(registers[instr.Operand]));
                                if (double.IsNaN(lenD) || lenD <= 0)
                                    registers[instr.RegisterA] = XdmValue.FromString(string.Empty);
                                else
                                {
                                    int len = (int)Math.Round(lenD);
                                    int end = Math.Min(start - 1 + len, s.Length);
                                    registers[instr.RegisterA] = XdmValue.FromString(s[(start - 1)..end]);
                                }
                            }
                            else
                            {
                                registers[instr.RegisterA] = XdmValue.FromString(s[(start - 1)..]);
                            }
                        }
                        ip++;
                        break;
                    }

                case IrOpCode.Contains:
                    registers[instr.RegisterA] = XdmValue.FromBoolean(
                        AtomizedString(registers[instr.RegisterB]).Contains(AtomizedString(registers[instr.RegisterC])));
                    ip++;
                    break;

                case IrOpCode.StartsWith:
                    registers[instr.RegisterA] = XdmValue.FromBoolean(
                        AtomizedString(registers[instr.RegisterB]).StartsWith(AtomizedString(registers[instr.RegisterC])));
                    ip++;
                    break;

                case IrOpCode.EndsWith:
                    registers[instr.RegisterA] = XdmValue.FromBoolean(
                        AtomizedString(registers[instr.RegisterB]).EndsWith(AtomizedString(registers[instr.RegisterC])));
                    ip++;
                    break;

                case IrOpCode.NormalizeSpace:
                    {
                        string s = AtomizedString(registers[instr.RegisterB]);
                        registers[instr.RegisterA] = XdmValue.FromString(NormalizeSpaceString(s));
                        ip++;
                        break;
                    }

                case IrOpCode.Translate:
                    {
                        string arg = AtomizedString(registers[instr.RegisterB]);
                        string map = AtomizedString(registers[instr.RegisterC]);
                        string trans = AtomizedString(registers[instr.RegisterB + 1]);
                        var sb = new System.Text.StringBuilder(arg.Length);
                        foreach (char c in arg)
                        {
                            int idx = map.IndexOf(c);
                            if (idx >= 0)
                            {
                                if (idx < trans.Length)
                                    sb.Append(trans[idx]);
                            }
                            else
                            {
                                sb.Append(c);
                            }
                        }
                        registers[instr.RegisterA] = XdmValue.FromString(sb.ToString());
                        ip++;
                        break;
                    }

                case IrOpCode.UpperCase:
                    registers[instr.RegisterA] = XdmValue.FromString(AtomizedString(registers[instr.RegisterB]).ToUpperInvariant());
                    ip++;
                    break;

                case IrOpCode.LowerCase:
                    registers[instr.RegisterA] = XdmValue.FromString(AtomizedString(registers[instr.RegisterB]).ToLowerInvariant());
                    ip++;
                    break;

                case IrOpCode.MatchesRegex:
                    {
                        string input = AtomizedString(registers[instr.RegisterB]);
                        string pattern = AtomizedString(registers[instr.RegisterC]);
                        var options = instr.Operand != 0
                            ? ParseRegexFlags(AtomizedString(registers[instr.Operand]))
                            : System.Text.RegularExpressions.RegexOptions.None;
                        registers[instr.RegisterA] = XdmValue.FromBoolean(
                            System.Text.RegularExpressions.Regex.IsMatch(input, pattern, options));
                        ip++;
                        break;
                    }

                case IrOpCode.ReplaceRegex:
                    {
                        string input = AtomizedString(registers[instr.RegisterB]);
                        string pattern = AtomizedString(registers[instr.RegisterC]);
                        string replacement = AtomizedString(registers[instr.RegisterB + 1]);
                        var options = instr.Operand != 0
                            ? ParseRegexFlags(AtomizedString(registers[instr.Operand]))
                            : System.Text.RegularExpressions.RegexOptions.None;
                        registers[instr.RegisterA] = XdmValue.FromString(
                            System.Text.RegularExpressions.Regex.Replace(input, pattern, replacement, options));
                        ip++;
                        break;
                    }

                case IrOpCode.TokenizeRegex:
                    {
                        string input = AtomizedString(registers[instr.RegisterB]);
                        string pattern = AtomizedString(registers[instr.RegisterC]);
                        var options = instr.Operand != 0
                            ? ParseRegexFlags(AtomizedString(registers[instr.Operand]))
                            : System.Text.RegularExpressions.RegexOptions.None;
                        var tokens = System.Text.RegularExpressions.Regex.Split(input, pattern, options)
                            .Where(t => !string.IsNullOrEmpty(t))
                            .Select(XdmValue.FromString)
                            .ToList();
                        registers[instr.RegisterA] = XdmValue.FromSequence(MaterializedSequence.FromList(tokens));
                        ip++;
                        break;
                    }

                // ------------------------------------------------------------------
                // Type operations
                // ------------------------------------------------------------------
                case IrOpCode.Cast:
                    {
                        string typeName = (string)literalPool[instr.Operand]!;
                        var occurrence = (OccurrenceIndicator)instr.RegisterC;
                        // XPath 4.0 §4.19.2.7: a record-type target takes a map operand,
                        // which must not be atomized (maps otherwise raise FOTY0013).
                        var value = IsRecordTypeText(typeName) || context.TryResolveNamedRecordType(typeName, context.DefaultElementNamespace, out _) || IsContainerCastTarget(typeName, context)
                            ? registers[instr.RegisterB]
                            : AtomizeForCast(registers[instr.RegisterB]);
                        // Peek-based emptiness: a lazy sequence reports unknown length.
                        bool isEmpty = !SequenceHasAnyItem(value);
                        if (isEmpty)
                        {
                            if (occurrence == OccurrenceIndicator.ZeroOrOne)
                            {
                                registers[instr.RegisterA] = XdmValue.Undefined;
                            }
                            else if (occurrence is OccurrenceIndicator.ZeroOrMore or OccurrenceIndicator.OneOrMore)
                            {
                                throw new InvalidOperationException("Cannot cast to a sequence type with * or + occurrence indicator.");
                            }
                            else
                            {
                                throw new InvalidOperationException("XPTY0004: Cast expression requires a singleton input sequence.");
                            }
                        }
                        else
                        {
                            registers[instr.RegisterA] = Cast(value, typeName, context);
                        }
                        ip++;
                        break;
                    }

                case IrOpCode.Castable:
                    {
                        string typeName = (string)literalPool[instr.Operand]!;
                        var occurrence = (OccurrenceIndicator)instr.RegisterC;
                        // Record-type targets take a map operand (see the Cast case).
                        var value = IsRecordTypeText(typeName) || context.TryResolveNamedRecordType(typeName, context.DefaultElementNamespace, out _) || IsContainerCastTarget(typeName, context)
                            ? registers[instr.RegisterB]
                            : AtomizeForCast(registers[instr.RegisterB]);
                        // Peek-based emptiness: a lazy sequence reports unknown length.
                        bool isEmpty = !SequenceHasAnyItem(value);
                        bool castable;
                        if (isEmpty)
                        {
                            castable = occurrence is OccurrenceIndicator.ZeroOrOne or OccurrenceIndicator.ZeroOrMore;
                        }
                        else if (occurrence is OccurrenceIndicator.ZeroOrMore or OccurrenceIndicator.OneOrMore)
                        {
                            castable = false;
                        }
                        else
                        {
                            try
                            {
                                castable = TryCast(value, typeName, context, out _);
                            }
                            catch (InvalidOperationException ex) when (!IsTypeError(ex))
                            {
                                // castable as returns false for any dynamic error that the cast would raise
                                // (e.g. FOCA0003, FOAR0002), rather than propagating the exception.
                                castable = false;
                            }
                            catch (OverflowException)
                            {
                                castable = false;
                            }
                        }
                        registers[instr.RegisterA] = XdmValue.FromBoolean(castable);
                        ip++;
                        break;
                    }

                case IrOpCode.InstanceOf:
                    {
                        string typeName = (string)literalPool[instr.Operand]!;
                        var occurrence = (OccurrenceIndicator)instr.RegisterC;
                        var instanceValue = registers[instr.RegisterB];
                        bool instance;
                        if (context.IsXPath40)
                        {
                            instance = InstanceOf(instanceValue, typeName, occurrence, context.DefaultElementNamespace, context);
                        }
                        else if (typeName.TrimStart().StartsWith("function(", StringComparison.OrdinalIgnoreCase))
                        {
                            // Function type tests on named function items need the
                            // registered signature, which requires the evaluation context.
                            if (instanceValue.IsUndefined)
                                instance = occurrence is OccurrenceIndicator.ZeroOrOne or OccurrenceIndicator.ZeroOrMore;
                            else
                                instance = FunctionItemInstanceOf(instanceValue, typeName, context);
                        }
                        else
                        {
                            instance = InstanceOf(instanceValue, typeName, occurrence, context.DefaultElementNamespace, context);
                        }
                        registers[instr.RegisterA] = XdmValue.FromBoolean(instance);
                        ip++;
                        break;
                    }

                case IrOpCode.TreatAs:
                    {
                        string typeName = (string)literalPool[instr.Operand]!;
                        var occurrence = (OccurrenceIndicator)instr.RegisterC;
                        var value = registers[instr.RegisterB];
                        // Single-pass (streamed) input: skip the eager instance-of check
                        // (it would burn the stream) and validate lazily during the one
                        // real enumeration instead, keeping the sequence single-pass for
                        // the enclosing expression.
                        if (value.IsSequence && value.SequenceValue is ISinglePassSequence treatSinglePass)
                        {
                            registers[instr.RegisterA] = XdmValue.FromSequence(XdmSequence.FromSource(
                                new SinglePassXdmSequence(TreatAsLazyIterator(
                                    treatSinglePass, typeName, occurrence, context.DefaultElementNamespace, context))));
                            ip++;
                            break;
                        }
                        if (!InstanceOf(value, typeName, occurrence, context.DefaultElementNamespace, context))
                            throw new InvalidOperationException($"XPDY0050: Treat as assertion failed for type {typeName} with occurrence {occurrence}.");
                        registers[instr.RegisterA] = value;
                        ip++;
                        break;
                    }

                case IrOpCode.Validate:
                    {
                        var value = registers[instr.RegisterB];
                        var (mode, typeName) = ((string Mode, string TypeName))literalPool[instr.Operand]!;
                        registers[instr.RegisterA] = ValidateNode(value, mode, typeName, context);
                        ip++;
                        break;
                    }

                // ------------------------------------------------------------------
                // Sequence functions
                // ------------------------------------------------------------------
                case IrOpCode.Count:
                    {
                        var seq = registers[instr.RegisterB];
                        if (!seq.IsSequence)
                            registers[instr.RegisterA] = XdmValue.FromInteger(1);
                        else if (seq.SequenceValue!.TryGetLength(out var len))
                            registers[instr.RegisterA] = XdmValue.FromInteger(len);
                        else
                        {
                            long count = 0;
                            foreach (var _ in XdmSequence.FromSource(seq.SequenceValue!))
                                count++;
                            registers[instr.RegisterA] = XdmValue.FromInteger(count);
                        }
                        ip++;
                        break;
                    }

                case IrOpCode.Exists:
                    {
                        // fn:exists is purely existential: any item (including 0, "",
                        // false, maps and arrays) counts; no effective boolean value
                        // is computed.
                        var seq = registers[instr.RegisterB];
                        registers[instr.RegisterA] = XdmValue.FromBoolean(SequenceHasAnyItem(seq));
                        ip++;
                        break;
                    }

                case IrOpCode.Empty:
                    {
                        var seq = registers[instr.RegisterB];
                        registers[instr.RegisterA] = XdmValue.FromBoolean(!SequenceHasAnyItem(seq));
                        ip++;
                        break;
                    }

                case IrOpCode.Head:
                    {
                        var seq = registers[instr.RegisterB];
                        if (!seq.IsSequence)
                            registers[instr.RegisterA] = seq;
                        else
                        {
                            XdmValue? first = null;
                            foreach (var item in XdmSequence.FromSource(seq.SequenceValue!))
                            {
                                first = item;
                                break;
                            }
                            registers[instr.RegisterA] = first ?? XdmValue.FromSequence(XdmSequence.Empty);
                        }
                        ip++;
                        break;
                    }

                case IrOpCode.Tail:
                    {
                        var seq = registers[instr.RegisterB];
                        if (!seq.IsSequence)
                        {
                            registers[instr.RegisterA] = XdmValue.FromSequence(XdmSequence.Empty);
                        }
                        else
                        {
                            var list = new List<XdmValue>();
                            bool first = true;
                            foreach (var item in XdmSequence.FromSource(seq.SequenceValue!))
                            {
                                if (first) { first = false; continue; }
                                list.Add(item);
                            }
                            registers[instr.RegisterA] = XdmValue.FromSequence(MaterializedSequence.FromList(list));
                        }
                        ip++;
                        break;
                    }

                case IrOpCode.InsertBefore:
                    {
                        var target = MaterializeSequence(registers[instr.RegisterB]).ToList();
                        long pos = ToInteger(Atomize(registers[instr.RegisterC]));
                        var inserts = MaterializeSequence(registers[instr.RegisterB + 1]).ToList();
                        if (pos < 1) pos = 1;
                        if (pos > target.Count + 1) pos = target.Count + 1;
                        target.InsertRange((int)pos - 1, inserts);
                        registers[instr.RegisterA] = XdmValue.FromSequence(MaterializedSequence.FromList(target));
                        ip++;
                        break;
                    }

                case IrOpCode.Remove:
                    {
                        var target = MaterializeSequence(registers[instr.RegisterB]).ToList();
                        long pos = ToInteger(Atomize(registers[instr.RegisterC]));
                        if (pos >= 1 && pos <= target.Count)
                            target.RemoveAt((int)pos - 1);
                        registers[instr.RegisterA] = XdmValue.FromSequence(MaterializedSequence.FromList(target));
                        ip++;
                        break;
                    }

                case IrOpCode.Reverse:
                    {
                        var items = MaterializeSequence(registers[instr.RegisterB]).ToList();
                        items.Reverse();
                        registers[instr.RegisterA] = XdmValue.FromSequence(MaterializedSequence.FromList(items));
                        ip++;
                        break;
                    }

                case IrOpCode.Subsequence:
                    {
                        var items = MaterializeSequence(registers[instr.RegisterB]).ToList();
                        double startD = ToDouble(Atomize(registers[instr.RegisterC]));
                        if (double.IsNaN(startD))
                        {
                            registers[instr.RegisterA] = XdmValue.Undefined;
                        }
                        else
                        {
                            int start = (int)Math.Round(startD);
                            if (start < 1) start = 1;
                            if (start > items.Count)
                            {
                                registers[instr.RegisterA] = XdmValue.Undefined;
                            }
                            else if (instr.Operand != 0)
                            {
                                double lenD = ToDouble(Atomize(registers[instr.Operand]));
                                if (double.IsNaN(lenD) || lenD <= 0)
                                    registers[instr.RegisterA] = XdmValue.Undefined;
                                else
                                {
                                    int len = (int)Math.Round(lenD);
                                    int count = Math.Min(len, items.Count - start + 1);
                                    registers[instr.RegisterA] = XdmValue.FromSequence(
                                        MaterializedSequence.FromList(items.Skip(start - 1).Take(count).ToList()));
                                }
                            }
                            else
                            {
                                registers[instr.RegisterA] = XdmValue.FromSequence(
                                    MaterializedSequence.FromList(items.Skip(start - 1).ToList()));
                            }
                        }
                        ip++;
                        break;
                    }

                case IrOpCode.DistinctValues:
                    {
                        var items = MaterializeSequence(registers[instr.RegisterB]).ToList();
                        var seen = new HashSet<string>();
                        var result = new List<XdmValue>();
                        foreach (var item in items)
                        {
                            string key = AtomizedString(item);
                            if (seen.Add(key))
                                result.Add(item);
                        }
                        registers[instr.RegisterA] = XdmValue.FromSequence(MaterializedSequence.FromList(result));
                        ip++;
                        break;
                    }

                case IrOpCode.IndexOf:
                    {
                        var seq = MaterializeSequence(registers[instr.RegisterB]).ToList();
                        string search = AtomizedString(registers[instr.RegisterC]);
                        var result = new List<XdmValue>();
                        for (int i = 0; i < seq.Count; i++)
                        {
                            if (AtomizedString(seq[i]) == search)
                                result.Add(XdmValue.FromInteger(i + 1));
                        }
                        registers[instr.RegisterA] = XdmValue.FromSequence(MaterializedSequence.FromList(result));
                        ip++;
                        break;
                    }

                // ------------------------------------------------------------------
                // Aggregation
                // ------------------------------------------------------------------
                case IrOpCode.Sum:
                    {
                        var items = MaterializeSequence(registers[instr.RegisterB]).ToList();
                        if (items.Count == 0)
                            registers[instr.RegisterA] = instr.Operand != 0 ? registers[instr.Operand] : XdmValue.FromInteger(0);
                        else
                            registers[instr.RegisterA] = Sum(items);
                        ip++;
                        break;
                    }

                case IrOpCode.Avg:
                    {
                        var items = MaterializeSequence(registers[instr.RegisterB]).ToList();
                        if (items.Count == 0)
                            registers[instr.RegisterA] = XdmValue.Undefined;
                        else
                        {
                            var total = Sum(items);
                            if (total.Kind == XdmValueKind.Decimal)
                                registers[instr.RegisterA] = XdmValue.FromDecimal(total.DecimalValue / items.Count);
                            else
                                registers[instr.RegisterA] = XdmValue.FromDouble(ToDouble(total) / items.Count);
                        }
                        ip++;
                        break;
                    }

                case IrOpCode.Min:
                    {
                        var items = MaterializeSequence(registers[instr.RegisterB]).ToList();
                        if (items.Count == 0)
                            registers[instr.RegisterA] = XdmValue.Undefined;
                        else
                            registers[instr.RegisterA] = MinMax(items, true);
                        ip++;
                        break;
                    }

                case IrOpCode.Max:
                    {
                        var items = MaterializeSequence(registers[instr.RegisterB]).ToList();
                        if (items.Count == 0)
                            registers[instr.RegisterA] = XdmValue.Undefined;
                        else
                            registers[instr.RegisterA] = MinMax(items, false);
                        ip++;
                        break;
                    }

                case IrOpCode.StringJoin:
                    {
                        var items = MaterializeSequence(registers[instr.RegisterB]).ToList();
                        string sep = instr.Operand != 0 ? AtomizedString(registers[instr.Operand]) : string.Empty;
                        var strings = new List<string>(items.Count);
                        foreach (var item in items)
                            strings.Add(AtomizedString(item));
                        registers[instr.RegisterA] = XdmValue.FromString(string.Join(sep, strings));
                        ip++;
                        break;
                    }

                // ------------------------------------------------------------------
                // Higher-order (XPath 3.1)
                // ------------------------------------------------------------------
                case IrOpCode.Map:
                    registers[instr.RegisterA] = XdmValue.FromMap(new XdmMap());
                    ip++;
                    break;

                case IrOpCode.MapAdd:
                    {
                        var map = registers[instr.RegisterA].MapValue;
                        var key = AtomizeMapKey(registers[instr.RegisterB]);
                        // XPath 3.1 §3.11.4: duplicate keys in a map constructor are a dynamic
                        // error (XQDY0137). Inside an XSLT streaming construct the XSLT error
                        // XTDE3365 applies instead (si-fork-814).
                        if (map.ContainsKey(key))
                        {
                            var code = context.InStreamingMapContext ? "XTDE3365" : "XQDY0137";
                            throw new InvalidOperationException($"{code}: Duplicate key '{key}' in map constructor.");
                        }
                        map.Add(key, registers[instr.RegisterC]);
                        ip++;
                        break;
                    }

                case IrOpCode.Array:
                    registers[instr.RegisterA] = XdmValue.FromArray(new XdmArray());
                    ip++;
                    break;

                case IrOpCode.ArrayAdd:
                    {
                        var arr = registers[instr.RegisterA].ArrayValue;
                        arr.Add(registers[instr.RegisterB]);
                        ip++;
                        break;
                    }

                case IrOpCode.ArrayAddAll:
                    {
                        var arr = registers[instr.RegisterA].ArrayValue;
                        var seq = registers[instr.RegisterB];
                        if (seq.IsSequence && seq.SequenceValue is not null)
                        {
                            foreach (var item in seq.SequenceValue)
                                arr.Add(item);
                        }
                        else if (!seq.IsUndefined)
                        {
                            arr.Add(seq);
                        }
                        ip++;
                        break;
                    }

                case IrOpCode.Lookup:
                    {
                        var container = registers[instr.RegisterB];
                        var key = registers[instr.RegisterC];

                        registers[instr.RegisterA] = LookupValue(container, key);
                        ip++;
                        break;
                    }

                case IrOpCode.LookupWildcard:
                    {
                        var container = registers[instr.RegisterB];
                        // XPath 4.0 §17.7: the LHS of '?' extracts the jvalue of a JNode.
                        if (container.IsJNode)
                            container = container.JNodeValue.Value;
                        var result = new List<XdmValue>();

                        void AddFlattened(XdmValue v)
                        {
                            if (v.IsSequence && v.SequenceValue is not null)
                            {
                                foreach (var item in XdmSequence.FromSource(v.SequenceValue))
                                    result.Add(item);
                            }
                            else if (!v.IsUndefined)
                            {
                                result.Add(v);
                            }
                        }

                        if (container.Kind == XdmValueKind.Map)
                        {
                            foreach (var v in container.MapValue.Values)
                                AddFlattened(v);
                        }
                        else if (container.Kind == XdmValueKind.Array)
                        {
                            foreach (var v in container.ArrayValue.Values)
                                AddFlattened(v);
                        }
                        else if (container.IsSequence && container.SequenceValue is not null)
                        {
                            foreach (var item in XdmSequence.FromSource(container.SequenceValue))
                            {
                                if (item.Kind == XdmValueKind.Map)
                                {
                                    foreach (var v in item.MapValue.Values)
                                        AddFlattened(v);
                                }
                                else if (item.Kind == XdmValueKind.Array)
                                {
                                    foreach (var v in item.ArrayValue.Values)
                                        AddFlattened(v);
                                }
                                else
                                {
                                    throw new InvalidOperationException($"XPTY0004: Wildcard lookup requires a map or an array, got {item.Kind}.");
                                }
                            }
                        }
                        else if (!container.IsUndefined)
                        {
                            throw new InvalidOperationException($"XPTY0004: Wildcard lookup requires a map or an array, got {container.Kind}.");
                        }

                        registers[instr.RegisterA] = XdmValue.FromSequence(
                            MaterializedSequence.FromList(result));
                        ip++;
                        break;
                    }

                case IrOpCode.LoadFunction:
                    {
                        var raw = literalPool[instr.Operand]!;
                        FunctionItem funcItem = raw switch
                        {
                            // Capture the defining context so the function item can still be
                            // resolved if it crosses into another evaluation context (e.g. a
                            // function returned by fn:transform delivery-format="raw").
                            NamedFunctionItem named => ResolveNamedFunctionItem(named, context),
                            CurriedFunctionItem curried => curried,
                            InlineFunctionItem inline => inline,
                            CompilerInlineFunction cif => new InlineFunctionItem(cif.Parameters, cif.Body, cif.ParameterTypes, cif.ReturnType)
                            {
                                // Capture the defining variable environment for closure semantics.
                                CapturedVariables = context.SnapshotVariables(),
                                CapturedBoundFunctionAliases = context.SnapshotBoundFunctionAliases()
                            },
                            ValueTuple<string, int> namedTuple => ResolveNamedFunctionTuple(namedTuple, context),
                            _ => throw new InvalidOperationException($"Unknown function item type: {raw.GetType().Name}")
                        };
                        registers[instr.RegisterA] = XdmValue.FromFunction(funcItem);
                        ip++;
                        break;
                    }

                case IrOpCode.Curry:
                    {
                        var baseFunc = (FunctionItem)registers[instr.RegisterB].FunctionValue;
                        var descriptor = (int[])literalPool[instr.Operand]!;
                        // XPTY0004: a partial application must supply exactly the function's
                        // arity in argument positions, placeholders included (xqhof8/9).
                        if (descriptor.Length != baseFunc.Arity)
                            throw new InvalidOperationException($"XPTY0004: Partial application of a function of arity {baseFunc.Arity} with {descriptor.Length} argument positions.");
                        var fixedArgs = new XdmValue?[descriptor.Length];
                        for (int i = 0; i < descriptor.Length; i++)
                        {
                            fixedArgs[i] = descriptor[i] >= 0 ? registers[descriptor[i]] : null;
                        }
                        registers[instr.RegisterA] = XdmValue.FromFunction(new CurriedFunctionItem(baseFunc, fixedArgs));
                        ip++;
                        break;
                    }

                case IrOpCode.Apply:
                    {
                        var funcValue = registers[instr.RegisterB];
                        int argCount = instr.RegisterC;
                        int firstArgReg = instr.Operand;
                        XdmValue[] args = new XdmValue[argCount];
                        for (int i = 0; i < argCount; i++)
                            args[i] = registers[firstArgReg + i];
                        registers[instr.RegisterA] = InvokeFunctionItem(funcValue, context, args);
                        ip++;
                        break;
                    }

                // ------------------------------------------------------------------
                // Constructors
                // ------------------------------------------------------------------
                case IrOpCode.ElementConstructor:
                case IrOpCode.AttributeConstructor:
                case IrOpCode.TextConstructor:
                case IrOpCode.DocumentConstructor:
                    throw new NotImplementedException($"{instr.OpCode} is not yet implemented.");

                // ------------------------------------------------------------------
                // Error
                // ------------------------------------------------------------------
                case IrOpCode.Error:
                    throw new InvalidOperationException("Runtime error instruction encountered.");

                default:
                    throw new NotSupportedException($"Unsupported opcode: {instr.OpCode}");
            }
        }

        throw new InvalidOperationException("VM reached end of instructions without Return.");
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private static XdmValue[] MaterializeSequence(XdmValue sequence)
    {
        if (sequence.IsUndefined)
            return Array.Empty<XdmValue>();

        if (sequence.IsSequence)
        {
            var seq = sequence.SequenceValue;
            if (seq is null)
                return Array.Empty<XdmValue>();

            // Fast path: an already-materialized sequence exposes its item list without
            // the List-growth + ToArray double copy (hot on multi-step path evaluations).
            if (seq is MaterializedSequence materialized)
            {
                if (materialized.Items is XdmValue[] arr)
                    return arr;
                if (materialized.Items is List<XdmValue> list)
                    return list.ToArray();
                var copy = new XdmValue[materialized.Items.Count];
                for (int i = 0; i < copy.Length; i++)
                    copy[i] = materialized.Items[i];
                return copy;
            }

            var list2 = new List<XdmValue>();
            foreach (var item in XdmSequence.FromSource(seq))
                list2.Add(item);
            return list2.ToArray();
        }

        return new[] { sequence };
    }

    private static readonly XmlSchemaSet s_builtInSchemaSet = CreateBuiltInSchemaSet();

    private static XmlSchemaSet CreateBuiltInSchemaSet()
    {
        var ss = new XmlSchemaSet { XmlResolver = new XmlUrlResolver() };

        // XML Schema validation does not automatically treat xml:id as an xs:ID attribute.
        // Import a schema for the XML namespace that declares xml:id with type xs:ID so that
        // lax validation can resolve IDREFs that point to xml:id values (fo-test-fn-idref-*).
        const string XmlIdSchema = """
            <xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema"
                       targetNamespace="http://www.w3.org/XML/1998/namespace">
              <xs:attribute name="id" type="xs:ID"/>
            </xs:schema>
            """;
        using (var reader = System.Xml.XmlReader.Create(new System.IO.StringReader(XmlIdSchema)))
        {
            ss.Add(null, reader);
        }

        ss.Compile();
        return ss;
    }

    /// <summary>
    /// Validates the node returned by a <c>validate</c> expression against the compiled
    /// schema set on the evaluation context. Returns the validated node and raises
    /// <c>XQTY0030</c> when the operand is not a valid validation root, <c>XQST0075</c>
    /// when no schema is available for a strict validation, <c>XQDY0027</c> when validation
    /// fails. Lax validation with no available schema is still run against the built-in schema
    /// set so that <c>xsi:type</c> annotations are honoured.
    /// </summary>
    private static XdmValue ValidateNode(XdmValue value, string mode, string typeName, EvaluationContext context)
    {
        var items = MaterializeSequence(value);
        if (items.Length != 1 || !items[0].IsNode || items[0].NodeValue!.NodeKind is not (XdmNodeKind.Element or XdmNodeKind.Document))
            throw new InvalidOperationException("XQTY0030: The operand of a validate expression must be a single document or element node.");

        var item = items[0];
        var node = item.NodeValue;

        // XQDY0061: a validation root document node must contain exactly one element child
        // and no text node children. This operand-shape error precedes schema-availability
        // (XQST0075) — cbcl-validateexpr-11/12, validateexpr-26 expect it without a schema.
        // It is also detected before serializing, otherwise XDocument.Load throws a generic
        // XmlException about multiple root elements.
        if (node.NodeKind == XdmNodeKind.Document)
        {
            int elementChildCount = 0;
            foreach (var childValue in node.Children())
            {
                if (childValue.NodeValue is not { } child)
                    continue;
                if (child.NodeKind == XdmNodeKind.Element)
                {
                    elementChildCount++;
                }
                else if (child.NodeKind == XdmNodeKind.Text)
                {
                    throw new InvalidOperationException("XQDY0061: The document node of the validation root has an invalid content model.");
                }
            }
            if (elementChildCount != 1)
            {
                throw new InvalidOperationException("XQDY0061: The document node of the validation root must have exactly one element child.");
            }
        }

        XmlSchemaSet schemaSetToUse = context.SchemaSet ?? s_builtInSchemaSet;
        if (context.SchemaSet is null && !string.IsNullOrEmpty(typeName))
        {
            // validate type Q { ... } may use a built-in XML Schema type without a user schema;
            // built-in types are always in-scope. Check that the type resolves before deciding
            // whether a schema is needed.
            var (builtInNs, builtInLocal) = ResolveValidateTypeName(typeName, context);
            bool isBuiltInType = builtInNs == XmlSchema.Namespace
                && XmlSchemaType.GetBuiltInSimpleType(new XmlQualifiedName(builtInLocal, builtInNs)) is not null;
            if (!isBuiltInType)
            {
                throw new InvalidOperationException("XQST0075: A validate expression requires a schema, but no schema is available.");
            }
        }
        else if (context.SchemaSet is null && mode != "lax")
        {
            // XQuery 3.1 §3.13.2: only lax validation without a target type may proceed
            // without a user schema; strict/default validation requires one.
            throw new InvalidOperationException("XQST0075: A validate expression requires a schema, but no schema is available.");
        }

        var validationErrors = new List<string>();
        bool hasErrors = false;
        ValidationEventHandler handler = (sender, e) =>
        {
            if (e.Severity == XmlSeverityType.Error)
            {
                hasErrors = true;
                validationErrors.Add(e.Message);
            }
        };

        // Validation creates a new XDM value with PSVI annotations. Preserve the original
        // document URI if the operand was a document node; element inputs conceptually return
        // the validated root element.
        string documentUri = item.NodeValue.NodeKind == XdmNodeKind.Document ? item.NodeValue.DocumentUri : string.Empty;

        (string TypeNs, string TypeLocal)? validateType = null;
        string? usedTypePrefix = null;
        bool addedTypeNs = false;
        bool addedXsiNs = false;
        if (!string.IsNullOrEmpty(typeName))
        {
            var (typeNs, typeLocal) = ResolveValidateTypeName(typeName, context);
            var schemaType = schemaSetToUse.GlobalTypes[new XmlQualifiedName(typeLocal, typeNs)] as XmlSchemaType
                ?? (typeNs == XmlSchema.Namespace ? XmlSchemaType.GetBuiltInSimpleType(new XmlQualifiedName(typeLocal, typeNs)) : null);
            if (schemaType is null)
                throw new InvalidOperationException("XQST0104: The validate type is not defined in the in-scope schema definitions.");
            validateType = (typeNs, typeLocal);
        }

        XDocument doc;
        const string XsiNs = "http://www.w3.org/2001/XMLSchema-instance";
        if (mode == "lax" && string.IsNullOrEmpty(typeName))
        {
            // Lax validation: load the document, then validate it. If the root element has no
            // matching global element declaration and no xsi:type, it is skipped in lax mode,
            // but its descendants that do have declarations must still be validated. .NET's
            // schema reader treats an undeclared root as an error, so we supply a dynamic
            // schema that declares the actual root element as xs:anyType; this makes the root
            // valid while still validating declared descendants (anyType allows any content but
            // processes child elements laxly).
            using (var stringReader = new System.IO.StringReader(node.ToXmlString()))
            using (var xmlReader = System.Xml.XmlReader.Create(stringReader))
            {
                doc = System.Xml.Linq.XDocument.Load(xmlReader, System.Xml.Linq.LoadOptions.None);
            }

            var xsi = XNamespace.Get(XsiNs);
            bool rootHasXsiType = doc.Root?.Attribute(xsi + "type") is not null;
            bool rootHasGlobal = schemaSetToUse.GlobalElements[new XmlQualifiedName(doc.Root?.Name.LocalName ?? "", doc.Root?.Name.NamespaceName ?? "")] is not null;

            XmlSchemaSet laxSchemaSet = schemaSetToUse;
            if (!rootHasGlobal && !rootHasXsiType && doc.Root is not null)
            {
                laxSchemaSet = new XmlSchemaSet { XmlResolver = new XmlUrlResolver() };
                foreach (XmlSchema existing in schemaSetToUse.Schemas())
                    laxSchemaSet.Add(existing);

                string targetNsAttr = string.IsNullOrEmpty(doc.Root.Name.NamespaceName)
                    ? ""
                    : $" targetNamespace=\"{System.Security.SecurityElement.Escape(doc.Root.Name.NamespaceName)}\"";
                string schemaXml = $"<xs:schema xmlns:xs=\"http://www.w3.org/2001/XMLSchema\"{targetNsAttr}><xs:element name=\"{System.Security.SecurityElement.Escape(doc.Root.Name.LocalName)}\" type=\"xs:anyType\" /></xs:schema>";
                using var schemaReader = System.Xml.XmlReader.Create(new System.IO.StringReader(schemaXml));
                laxSchemaSet.Add(null, schemaReader);
                laxSchemaSet.Compile();
            }

            doc.Validate(laxSchemaSet, handler, addSchemaInfo: true);
            if (hasErrors)
                throw new InvalidOperationException($"XQDY0027: Validation of the validate expression operand failed: {string.Join("; ", validationErrors)}");
        }
        else
        {
            using var stringReader = new System.IO.StringReader(node.ToXmlString());
            using var xmlReader = System.Xml.XmlReader.Create(stringReader);
            doc = System.Xml.Linq.XDocument.Load(xmlReader, System.Xml.Linq.LoadOptions.None);

            // validate type QName { ... }: force the root element to be validated against the
            // named type by injecting an xsi:type attribute. This is required for tests such as
            // CastAs-UnionType-33 where the element has no matching global element declaration.
            if (validateType is not null && doc.Root is not null)
            {
                const string XsNs = "http://www.w3.org/2001/XMLSchema";
                var (typeNs, typeLocal) = validateType.Value;

                if (doc.Root.GetNamespaceOfPrefix("xsi") is null)
                {
                    doc.Root.SetAttributeValue(XNamespace.Xmlns + "xsi", XsiNs);
                    addedXsiNs = true;
                }

                var existingTypePrefix = doc.Root.Attributes()
                    .Where(a => a.IsNamespaceDeclaration && a.Value == typeNs)
                    .Select(a => a.Name.LocalName)
                    .FirstOrDefault();
                if (existingTypePrefix is null)
                {
                    usedTypePrefix = typeNs == XsNs ? "xs" : GenerateUniquePrefix(doc.Root, "t");
                    doc.Root.SetAttributeValue(XNamespace.Xmlns + usedTypePrefix, typeNs);
                    addedTypeNs = true;
                }
                else
                {
                    usedTypePrefix = existingTypePrefix;
                }

                doc.Root.SetAttributeValue(XNamespace.Get(XsiNs) + "type", $"{usedTypePrefix}:{typeLocal}");
            }

            // addSchemaInfo: true is required to populate XElement.GetSchemaInfo() / PSVI
            // annotations used by fn:id, fn:idref, schema-element(), and typed value access.
            doc.Validate(schemaSetToUse, handler, addSchemaInfo: true);

            // XQDY0084 (strict/default): the root element must have a top-level element
            // declaration in the in-scope element declarations; xsi:type is no substitute.
            // This takes precedence over content-validity errors (XQDY0027), which apply
            // only when a governing declaration exists (cbcl-validateexpr-5/7/8/10 vs
            // qischema90703-err, whose FpML root IS declared).
            if (validateType is null && (mode == "strict" || mode == "") && doc.Root is not null
                && schemaSetToUse.GlobalElements[new XmlQualifiedName(doc.Root.Name.LocalName, doc.Root.Name.NamespaceName)] is null)
            {
                throw new InvalidOperationException("XQDY0084: The root element does not match a top-level element declaration.");
            }

            if (hasErrors)
                throw new InvalidOperationException($"XQDY0027: Validation of the validate expression operand failed: {string.Join("; ", validationErrors)}");

            // Remove the injected xsi:type and any namespace declarations we added; the result
            // of validate type Q { ... } must not expose the temporary xsi:type attribute.
            if (validateType is not null && doc.Root is not null)
            {
                doc.Root.SetAttributeValue(XNamespace.Get(XsiNs) + "type", null);
                if (addedTypeNs && usedTypePrefix is not null)
                    doc.Root.SetAttributeValue(XNamespace.Xmlns + usedTypePrefix, null);
                if (addedXsiNs)
                    doc.Root.SetAttributeValue(XNamespace.Xmlns + "xsi", null);
            }
        }

        if (item.NodeValue.NodeKind == XdmNodeKind.Document)
        {
            var validatedDoc = XDocumentNode.Wrap(doc);
            validatedDoc.SetDocumentUri(documentUri);
            return XdmValue.FromNode(validatedDoc);
        }

        // For element input, the validated result must be a parentless element. Validation
        // had to load it as a document root, so detach that root before returning it; this
        // keeps the PSVI annotations while making the XPath parent axis empty.
        var validatedRoot = doc.Root;
        if (validatedRoot is null)
            throw new InvalidOperationException("XQDY0027: Validation produced no element.");
        validatedRoot.Remove();
        return XdmValue.FromNode(XDocumentNode.Wrap(validatedRoot));
    }

    private static (string NamespaceUri, string LocalName) ResolveValidateTypeName(string typeName, EvaluationContext context)
    {
        if (typeName.StartsWith("Q{", StringComparison.Ordinal))
        {
            int closeBrace = typeName.IndexOf('}');
            if (closeBrace > 2)
                return (typeName[2..closeBrace], typeName[(closeBrace + 1)..]);
        }

        int colon = typeName.IndexOf(':');
        string prefix = colon >= 0 ? typeName[..colon] : "";
        string local = colon >= 0 ? typeName[(colon + 1)..] : typeName;
        if (!context.TryResolveNamespace(prefix, out var nsUri))
            throw new InvalidOperationException($"XPST0081: Prefix '{prefix}' is not declared.");
        return (nsUri, local);
    }

    private static string GenerateUniquePrefix(XElement element, string basePrefix)
    {
        int index = 0;
        string prefix;
        do
        {
            prefix = index == 0 ? basePrefix : $"{basePrefix}{index}";
            index++;
        } while (element.GetNamespaceOfPrefix(prefix) is not null);
        return prefix;
    }

    /// <summary>
    /// Expands arrays into their member items for general-comparison operands
    /// (XDM 3.1 atomization: an array atomizes to the atomized values of its members).
    /// Returns the input array unchanged when no item is an array.
    /// </summary>
    private static XdmValue[] ExpandArraysForComparison(XdmValue[] items)
    {
        bool hasArray = false;
        foreach (var item in items)
        {
            if (item.IsArray) { hasArray = true; break; }
        }
        if (!hasArray)
            return items;

        var list = new List<XdmValue>();
        foreach (var item in items)
            FlattenArrayItem(item, list);
        return list.ToArray();
    }

    /// <summary>
    /// Lazily enumerates the items of a value for general comparison, expanding arrays.
    /// Unlike <see cref="MaterializeSequence"/>, this avoids allocating huge lists for
    /// large lazy sequences such as integer ranges.
    /// </summary>
    private static IEnumerable<XdmValue> EnumerateItemsForComparison(XdmValue value)
    {
        if (value.IsUndefined) yield break;

        if (!value.IsSequence)
        {
            if (value.IsArray)
            {
                // General-comparison atomization flattens array members recursively,
                // so a nested array contributes its own atomized members (GenCompEq-8).
                foreach (var member in value.ArrayValue.Values)
                {
                    foreach (var flattened in EnumerateItemsForComparison(member))
                        yield return flattened;
                }
            }
            else
            {
                yield return value;
            }
            yield break;
        }

        var seq = value.SequenceValue;
        if (seq is null) yield break;

        foreach (var item in XdmSequence.FromSource(seq))
        {
            if (item.IsArray)
            {
                foreach (var flattened in EnumerateItemsForComparison(item))
                    yield return flattened;
            }
            else
            {
                yield return item;
            }
        }
    }

    private static bool SequenceContainsBooleanItem(XdmValue value)
    {
        foreach (var item in EnumerateItemsForComparison(value))
        {
            var atomized = Atomize(item);
            if (!atomized.IsUndefined && atomized.Kind == XdmValueKind.Boolean)
                return true;
        }
        return false;
    }

    private static void FlattenArrayItem(XdmValue value, List<XdmValue> list)
    {
        if (value.IsArray)
        {
            foreach (var member in value.ArrayValue.Values)
                FlattenArrayItem(member, list);
            return;
        }
        if (value.IsSequence && value.SequenceValue is not null)
        {
            foreach (var item in XdmSequence.FromSource(value.SequenceValue))
                FlattenArrayItem(item, list);
            return;
        }
        if (!value.IsUndefined)
            list.Add(value);
    }

    private static bool TryGetSequenceLength(IXdmSequence? seq, out int length)
    {
        if (seq is null)
        {
            length = 0;
            return true;
        }
        return seq.TryGetLength(out length);
    }

    private static (string LocalName, string NamespaceUri) ResolveFunctionName(string funcName, EvaluationContext? context)
    {
        string localName = funcName;
        string? prefix = null;
        int colon = funcName.IndexOf(':');
        if (colon >= 0)
        {
            prefix = funcName[..colon];
            localName = funcName[(colon + 1)..];
        }

        string nsUri;
        if (prefix is not null)
        {
            if (context is null || !context.TryResolveNamespace(prefix, out nsUri))
                throw new InvalidOperationException($"XPST0081: Prefix '{prefix}' is not declared.");
        }
        else
        {
            nsUri = "http://www.w3.org/2005/xpath-functions"; // default function namespace
        }

        return (localName, nsUri);
    }

    private static (string LocalName, string NamespaceUri) ResolveVariableName(string varName, EvaluationContext context)
    {
        // Braced URI literal: Q{uri}localname or Q{uri}prefix:local
        // The empty URI form Q{}local is permitted and means "no namespace".
        if (varName.Length > 2 && varName[0] == 'Q' && varName[1] == '{')
        {
            int closeBrace = varName.IndexOf('}');
            if (closeBrace >= 2)
            {
                string uri = varName[2..closeBrace];
                string local = varName[(closeBrace + 1)..];
                return (local, uri);
            }
        }

        string localName = varName;
        string? prefix = null;
        int colon = varName.IndexOf(':');
        if (colon >= 0)
        {
            prefix = varName[..colon];
            localName = varName[(colon + 1)..];
        }

        string nsUri = "";
        if (prefix is not null)
        {
            if (!context.TryResolveNamespace(prefix, out var resolvedNs))
                throw new InvalidOperationException($"XPST0081: Prefix '{prefix}' is not declared.");
            nsUri = resolvedNs;
        }

        return (localName, nsUri);
    }

    private static XdmAxis ToXdmAxis(IrOpCode opcode) => opcode switch
    {
        IrOpCode.Child => XdmAxis.Child,
        IrOpCode.Descendant => XdmAxis.Descendant,
        IrOpCode.DescendantOrSelf => XdmAxis.DescendantOrSelf,
        IrOpCode.Ancestor => XdmAxis.Ancestor,
        IrOpCode.AncestorOrSelf => XdmAxis.AncestorOrSelf,
        IrOpCode.Attribute => XdmAxis.Attribute,
        IrOpCode.Parent => XdmAxis.Parent,
        IrOpCode.Self => XdmAxis.Self,
        IrOpCode.Following => XdmAxis.Following,
        IrOpCode.FollowingSibling => XdmAxis.FollowingSibling,
        IrOpCode.Preceding => XdmAxis.Preceding,
        IrOpCode.PrecedingSibling => XdmAxis.PrecedingSibling,
        IrOpCode.Namespace => XdmAxis.Namespace,
        _ => throw new ArgumentOutOfRangeException(nameof(opcode), opcode, null)
    };

    /// <summary>
    /// The node-matching predicate of a <see cref="IrOpCode.NameTest"/> for a plain
    /// (non-wildcard) name: match on the full name or, for prefixed forms, on the local
    /// part, with unprefixed attribute names matching no namespace.
    /// </summary>
    private static Func<IXdmNode, bool> BuildNameTestPredicate(string name, EvaluationContext context)
    {
        int colonIndex = name.IndexOf(':');
        string? colonLocalName = colonIndex >= 0 ? name[(colonIndex + 1)..] : null;
        return n =>
        {
            if (n.LocalName != name && !(colonLocalName is not null && n.LocalName == colonLocalName))
                return false;
            // Unprefixed attribute names always match no namespace
            if (n.NodeKind == XdmNodeKind.Attribute && colonIndex < 0)
                return n.NamespaceUri == "";
            return true;
        };
    }

    /// <summary>
    /// Matches a JNode entry key against a name test (XPath 4.0 §17.7): a string key
    /// matches the lexical name; a QName key matches a prefixed name whose prefix
    /// resolves to the key's namespace (XPST0081 for an unbound prefix); position
    /// (integer) keys and a keyless root never match a name test.
    /// </summary>
    private static bool JNodeKeyMatchesName(XdmValue key, string name, EvaluationContext context)
    {
        if (key.IsUndefined)
            return false;
        if (key.Kind == XdmValueKind.String)
            return key.StringValue == name;
        if (key.Kind == XdmValueKind.QName)
        {
            var qn = key.QNameValue;
            int colon = name.IndexOf(':');
            if (colon <= 0 || colon == name.Length - 1)
                return false;
            var prefix = name.Substring(0, colon);
            var local = name[(colon + 1)..];
            // The '*:local' form comes from a prefixed step whose NamespaceTest is a
            // no-op on JNode items (identity pass-through), so only the local part
            // can be matched.
            if (prefix == "*")
                return qn.LocalName == local;
            if (!context.TryResolveNamespace(prefix, out var ns))
                throw new InvalidOperationException($"XPST0081: Prefix '{prefix}' is not declared.");
            return qn.NamespaceUri == ns && qn.LocalName == local;
        }
        return false;
    }

    /// <summary>
    /// XPath 4.0 §17.7: axes over a map/array value navigate the value structure.
    /// The value is implicitly wrapped as by fn:jtree and the axis yields JNodes
    /// (keyed wrappers): child of a map yields one JNode per entry (keyed by the
    /// entry key), child of an array yields one JNode per member (keyed by 1-based
    /// position), self yields the (wrapped) input, parent/ancestor walk the J-parent
    /// chain, and descendant(-or-self) yields the JNode plus all reachable JNodes.
    /// </summary>
    private static XdmValue MapAxis(XdmValue input, XdmAxis axis)
        => JNodeAxis(new XdmJNode(input), axis);

    /// <summary>Applies an XDM axis to a JNode, yielding JNode values.</summary>
    private static XdmValue JNodeAxis(XdmJNode jn, XdmAxis axis)
    {
        switch (axis)
        {
            case XdmAxis.Self:
                return XdmValue.FromJNode(jn);
            case XdmAxis.Child:
                {
                    var children = JChildren(jn);
                    return children.Count == 0
                        ? XdmValue.Undefined
                        : XdmValue.FromSequence(MaterializedSequence.FromList(children));
                }
            case XdmAxis.Parent:
                return jn.Parent is { } parent
                    ? XdmValue.FromJNode(parent)
                    : XdmValue.Undefined;
            case XdmAxis.Ancestor:
            case XdmAxis.AncestorOrSelf:
                {
                    var acc = new List<XdmValue>();
                    if (axis == XdmAxis.AncestorOrSelf)
                        acc.Add(XdmValue.FromJNode(jn));
                    for (var current = jn.Parent; current is not null; current = current.Parent)
                        acc.Add(XdmValue.FromJNode(current));
                    return acc.Count == 0
                        ? XdmValue.Undefined
                        : XdmValue.FromSequence(MaterializedSequence.FromList(acc));
                }
            case XdmAxis.Descendant:
            case XdmAxis.DescendantOrSelf:
                {
                    var acc = new List<XdmValue>();
                    if (axis == XdmAxis.DescendantOrSelf)
                        acc.Add(XdmValue.FromJNode(jn));
                    AddJNodeDescendants(jn, acc);
                    return acc.Count == 0
                        ? XdmValue.Undefined
                        : XdmValue.FromSequence(MaterializedSequence.FromList(acc));
                }
            case XdmAxis.Attribute:
            case XdmAxis.Namespace:
                // JNodes have no attributes/namespaces: the axis is empty rather than
                // an error (mirrors the empty-children rule for atomic values).
                return XdmValue.Undefined;
            default:
                throw new InvalidOperationException(
                    $"Axis {axis} is not defined for JNode values.");
        }
    }

    /// <summary>
    /// The j-children accessor (F&amp;O 4.0 §17.7): a map yields one JNode per entry
    /// keyed by the entry key; an array yields one JNode per member keyed by 1-based
    /// position; a sequence yields one JNode per item keyed by position; any other
    /// value has no children.
    /// </summary>
    private static List<XdmValue> JChildren(XdmJNode jn)
    {
        var children = new List<XdmValue>();
        var value = jn.Value;
        if (value.IsMap)
        {
            foreach (var entry in value.MapValue.Entries)
                children.Add(XdmValue.FromJNode(new XdmJNode(entry.Value, entry.Key, jn)));
        }
        else if (value.IsArray)
        {
            long position = 0;
            foreach (var member in value.ArrayValue.Values)
                children.Add(XdmValue.FromJNode(new XdmJNode(member, XdmValue.FromInteger(++position), jn)));
        }
        else if (value.IsSequence && value.SequenceValue is not null)
        {
            long position = 0;
            foreach (var item in XdmSequence.FromSource(value.SequenceValue))
                children.Add(XdmValue.FromJNode(new XdmJNode(item, XdmValue.FromInteger(++position), jn)));
        }
        return children;
    }

    private static void AddJNodeDescendants(XdmJNode jn, List<XdmValue> acc)
    {
        foreach (var child in JChildren(jn))
        {
            acc.Add(child);
            AddJNodeDescendants(child.JNodeValue, acc);
        }
    }

    /// <summary>
    /// Whether the value contains any map or array item. Only materialized sequences
    /// are scanned: single-pass (streamed) sequences are forward-only and lazy
    /// (enumerable) sequences must stay single-enumeration — materializing them here
    /// would consume the stream a path step is about to read lazily
    /// (StreamingXPathTests.ReverseAxisInsideRecord).
    /// </summary>
    private static bool MayContainMaps(XdmValue value)
        => value.IsMap || value.IsArray || value.IsJNode
        || (value.IsSequence && value.SequenceValue is MaterializedSequence materialized
            && materialized.Items.Any(i => i.IsMap || i.IsArray || i.IsJNode));

    /// <summary>Iterates the items of a value (singletons yield themselves).</summary>
    private static IEnumerable<XdmValue> FlattenItems(XdmValue value)
    {
        if (value.IsSequence)
        {
            foreach (var item in MaterializeSequenceView(value))
                yield return item;
        }
        else if (!value.IsUndefined)
        {
            yield return value;
        }
    }

    private static void AddFlattened(List<XdmValue> acc, XdmValue value)
    {
        if (value.IsSequence)
        {
            foreach (var item in MaterializeSequenceView(value))
                acc.Add(item);
        }
        else if (!value.IsUndefined)
        {
            acc.Add(value);
        }
    }

    private static XdmValue ApplyAxis(XdmValue input, XdmAxis axis, bool hasLhs)
    {
        if (input.IsUndefined)
        {
            // An empty-sequence input to a path step (e.g. doc(())/*) produces an empty
            // sequence; the real "no context item" case is already caught by LoadContextItem.
            return XdmValue.Undefined;
        }
        if (input.IsAtomic)
        {
            if (hasLhs)
                throw new InvalidOperationException("XPTY0019: A path step requires nodes, but the step input contains an atomic value.");
            throw new InvalidOperationException("XPTY0020: An axis step requires a context item that is a node.");
        }

        if (input.IsNode)
            return XdmValue.FromSequence(input.NodeValue.Axis(axis));

        // XPath 4.0 §17.7: a JNode navigates its tree; a raw map/array context item
        // is implicitly wrapped as by fn:jtree. Both yield JNode values.
        if (input.IsJNode)
            return JNodeAxis(input.JNodeValue, axis);

        // XPath 4.0: axes over a map/array value navigate the value structure.
        if (input.IsMap || input.IsArray)
            return MapAxis(input, axis);

        if (input.IsSequence)
        {
            // Single-pass (streamed) input: map the axis lazily so records are pulled
            // one at a time. Forward axes preserve document order and keep the marker;
            // reverse axes drop it so sequence normalization re-sorts as usual.
            if (input.SequenceValue is ISinglePassSequence singlePassInput)
            {
                bool forward = axis is XdmAxis.Child or XdmAxis.Descendant or XdmAxis.DescendantOrSelf
                    or XdmAxis.Attribute or XdmAxis.Namespace or XdmAxis.Self
                    or XdmAxis.Following or XdmAxis.FollowingSibling;
                var pull = LazyAxisMapIterator(singlePassInput, axis);
                IXdmSequence mapped = forward
                    ? new SinglePassXdmSequence(pull)
                    : new EnumerableXdmSequence(pull);
                return XdmValue.FromSequence(XdmSequence.FromSource(mapped));
            }

            var items = MaterializeSequenceView(input);

            // XPath 4.0: a sequence mixing maps/arrays/JNodes with nodes navigates each
            // item according to its kind (element-to-map-550+).
            if (items.Any(i => i.IsMap || i.IsArray || i.IsJNode))
            {
                var mixed = new List<XdmValue>();
                foreach (var item in items)
                {
                    if (item.IsNode)
                    {
                        foreach (var node in item.NodeValue.Axis(axis))
                            mixed.Add(node);
                    }
                    else if (item.IsJNode)
                    {
                        AddFlattened(mixed, JNodeAxis(item.JNodeValue, axis));
                    }
                    else if (item.IsMap || item.IsArray)
                    {
                        AddFlattened(mixed, MapAxis(item, axis));
                    }
                    else
                    {
                        throw new InvalidOperationException("XPTY0019: A path step requires nodes, but the step input contains an atomic value.");
                    }
                }
                return XdmValue.FromSequence(MaterializedSequence.FromList(mixed));
            }
            var result = new List<XdmValue>();
            int startIndex = 0;

            // Single-input-item probe: apply the axis once; when it yields a streamed
            // (single-pass) sequence, forward it untouched instead of draining the
            // stream into a list.
            if (items.Count == 1 && items[0].IsNode)
            {
                var axisOutput = items[0].NodeValue.Axis(axis);
                if (axisOutput.IsSinglePass)
                    return XdmValue.FromSequence(axisOutput);
                foreach (var node in axisOutput)
                    result.Add(node);
                startIndex = 1;
            }

            for (int i = startIndex; i < items.Count; i++)
            {
                // A path step whose input contains atomic values is a type error
                // (XPTY0019 — this covers both intermediate steps and axis steps
                // applied to a mixed sequence, XPTY0019_1/2).
                if (!items[i].IsNode)
                    throw new InvalidOperationException("XPTY0019: A path step requires nodes, but the step input contains an atomic value.");
                var seq = items[i].NodeValue.Axis(axis);
                foreach (var node in seq)
                    result.Add(node);
            }
            return XdmValue.FromSequence(MaterializedSequence.FromList(result));
        }

        throw new InvalidOperationException(
            $"Axis {axis} requires a node or sequence of nodes, but got {input.Kind}.");
    }

    /// <summary>
    /// Atomizes an XDM value for comparison: nodes become their string value,
    /// singleton sequences are unpacked, and other values pass through.
    /// </summary>
    private static FunctionItem ResolveNamedFunctionTuple(ValueTuple<string, int> tuple, EvaluationContext context)
    {
        var (localName, nsUri) = ResolveFunctionName(tuple.Item1, context);
        // An arity clamped to int.MaxValue in the parser indicates an out-of-range literal
        // (e.g. fn:concat#340282366920938463463374607431768211456); surface FOAR0002 instead
        // of resolving against a variadic fallback and returning an impossible arity.
        if (tuple.Item2 == int.MaxValue)
            throw new InvalidOperationException($"FOAR0002: Function {{{nsUri}}}{localName}#{tuple.Item2} arity exceeds the implementation limit.");
        if (!context.TryResolveFunction(nsUri, localName, tuple.Item2, out var signature))
            throw new InvalidOperationException($"XPST0017: Function {{{nsUri}}}{localName}#{tuple.Item2} not found.");
        signature = signature.FunctionItemTarget ?? signature;
        return new NamedFunctionItem(signature.NamespaceUri, signature.LocalName, tuple.Item2)
        {
            DefiningContext = context,
            CapturedContextItem = context.ContextItem,
            CapturedContextPosition = context.ContextPosition,
            CapturedContextSize = context.ContextSize,
            CapturedBaseUri = context.BaseUri,
            CapturedNamespaces = context.SnapshotNamespaces(),
            CapturedSignature = signature
        };
    }

    /// <summary>
    /// Validates the arity of a compile-time-resolved named function reference and captures
    /// the defining context (XPST0017 when the function/arity pair is not registered).
    /// </summary>
    private static NamedFunctionItem ResolveNamedFunctionItem(NamedFunctionItem named, EvaluationContext context)
    {
        if (named.DefiningContext != null)
            return named;
        // An arity clamped to int.MaxValue in the parser indicates an out-of-range literal;
        // surface FOAR0002 instead of resolving against a variadic fallback.
        if (named.Arity == int.MaxValue)
            throw new InvalidOperationException($"FOAR0002: Function {{{named.NamespaceUri}}}{named.LocalName}#{named.Arity} arity exceeds the implementation limit.");
        if (!context.TryResolveFunction(named.NamespaceUri, named.LocalName, named.Arity, out var signature))
            throw new InvalidOperationException($"XPST0017: Function {{{named.NamespaceUri}}}{named.LocalName}#{named.Arity} not found.");
        signature = signature.FunctionItemTarget ?? signature;
        return named with
        {
            NamespaceUri = signature.NamespaceUri,
            LocalName = signature.LocalName,
            DefiningContext = context,
            CapturedContextItem = context.ContextItem,
            CapturedContextPosition = context.ContextPosition,
            CapturedContextSize = context.ContextSize,
            CapturedBaseUri = context.BaseUri,
            CapturedNamespaces = context.SnapshotNamespaces(),
            CapturedSignature = signature
        };
    }

    /// <summary>
    /// Invokes a function item dynamically. Per XSLT 3.0 §5.3.4, the current captured
    /// substrings (regex groups), the current output URI, and the XSLT current item are
    /// cleared for the duration of the call, so <c>fn:current()</c> raises XTDE1360.
    /// </summary>
    /// <param name="func">The function item to invoke.</param>
    /// <param name="context">The evaluation context for the call.</param>
    /// <param name="args">The call arguments.</param>
    /// <returns>The value produced by the function item.</returns>
    /// <exception cref="InvalidOperationException">The function item type is not recognized,
    /// or the invoked function raises a dynamic error.</exception>
    public static XdmValue InvokeFunctionItem(FunctionItem func, EvaluationContext context, ReadOnlySpan<XdmValue> args)
    {
        // XSLT 3.0 §5.3.4: dynamic function calls clear the current captured substrings
        // (regex groups) and the current output URI for the duration of the call.
        // They also clear the XSLT current node, so fn:current() raises XTDE1360 when
        // invoked through a function item.
        var savedRegexGroups = context.RegexGroups;
        var savedOutputUri = context.CurrentOutputUri;
        var savedCurrentItem = context.CurrentItem;
        context.RegexGroups = null;
        context.CurrentOutputUri = null;
        context.WithCurrentItem(XdmValue.Undefined);
        try
        {
            return InvokeFunctionItemCore(func, context, args);
        }
        finally
        {
            context.RegexGroups = savedRegexGroups;
            context.CurrentOutputUri = savedOutputUri;
            context.WithCurrentItem(savedCurrentItem);
        }
    }

    private static XdmValue InvokeFunctionItemCore(FunctionItem func, EvaluationContext context, ReadOnlySpan<XdmValue> args)
    {
        switch (func)
        {
            case NamedFunctionItem named:
                // The function item has a fixed arity; a dynamic call must supply exactly
                // that many arguments (higher-order-functions-049/050). A mismatch in a
                // DYNAMIC call is a type error (XPTY0004) — XPST0017 applies only to
                // static calls resolved at compile time (xqhof7, for-each-901).
                if (args.Length != named.ArityValue)
                    throw new InvalidOperationException($"XPTY0004: Function {{{named.NamespaceUri}}}{named.LocalName}#{named.ArityValue} cannot be called with {args.Length} argument(s).");
                FunctionSignature sig;
                if (named.CapturedSignature is FunctionSignature { IsBoundFunctionItem: true } bound)
                {
                    sig = bound;
                }
                else if (!context.TryResolveFunction(named.NamespaceUri, named.LocalName, args.Length, out sig))
                {
                    // Fall back to the context in which the function item was created
                    // (function items returned by fn:transform delivery-format="raw").
                    if (named.DefiningContext is EvaluationContext definingContext
                        && definingContext.TryResolveFunction(named.NamespaceUri, named.LocalName, args.Length, out sig))
                    {
                        // Resolved against the defining context.
                    }
                    else if (named.CapturedSignature is FunctionSignature capturedSignature
                        && capturedSignature.NamespaceUri == named.NamespaceUri
                        && capturedSignature.LocalName == named.LocalName
                        && capturedSignature.Arity == args.Length)
                    {
                        // Last-resort fallback: the signature the item was bound to when it
                        // was materialized. This keeps XSLT package-private functions
                        // callable through a function item created in the declaring
                        // package after that package's scope has been exited
                        // (override-f-014).
                        sig = capturedSignature;
                    }
                    else
                    {
                        throw new InvalidOperationException($"XPST0017: Function {{{named.NamespaceUri}}}{named.LocalName}#{args.Length} not found.");
                    }
                }
                // Named function references and function-lookup results capture the dynamic
                // context in which they are created. Context-dependent functions such as
                // fn:base-uri#0 and fn:document-uri#0 therefore use the creator's focus,
                // not the call-site focus (fn-function-lookup-018/022).
                XdmValue savedItem = XdmValue.Undefined;
                int savedPosition = 0;
                int savedSize = 0;
                bool restoreFocus = false;
                if (!named.CapturedContextItem.IsUndefined)
                {
                    savedItem = context.ContextItem;
                    savedPosition = context.ContextPosition;
                    savedSize = context.ContextSize;
                    context.WithFocus(named.CapturedContextItem, named.CapturedContextPosition, named.CapturedContextSize);
                    restoreFocus = true;
                }
                else if (!context.ContextItem.IsUndefined)
                {
                    // No focus was captured at creation: the function item's focus is
                    // absent. Context-dependent calls see XPDY0002 rather than the
                    // call-site focus (xqhof14: <a/>/(name#0)()).
                    savedItem = context.ContextItem;
                    savedPosition = context.ContextPosition;
                    savedSize = context.ContextSize;
                    context.WithFocus(XdmValue.Undefined, 0, 0);
                    restoreFocus = true;
                }
                // Static base URI: context-dependent functions resolve against the base URI
                // of the module that materialized the function item (xqhof16/18).
                string? savedBaseUri = null;
                bool restoreBaseUri = false;
                if (named.CapturedBaseUri is not null && named.CapturedBaseUri != context.BaseUri)
                {
                    savedBaseUri = context.BaseUri;
                    context.BaseUri = named.CapturedBaseUri;
                    restoreBaseUri = true;
                }
                // Namespace bindings: constructor functions for namespace-sensitive schema
                // types resolve lexical prefixes using the context in which the function item
                // was created, not the call-site context (CastAs-UnionType-13/14/15).
                Dictionary<string, string>? savedNamespaces = null;
                bool restoreNamespaces = false;
                if (named.CapturedNamespaces is not null)
                {
                    savedNamespaces = context.SnapshotNamespaces();
                    context.RestoreNamespaces(named.CapturedNamespaces);
                    restoreNamespaces = true;
                }
                try
                {
                    // XSLT context-dependent functions (e.g. current-group) supply a separate
                    // implementation for dynamic invocation through a function item.
                    return (sig.DynamicImplementation ?? sig.Implementation)(context, ConvertDynamicCallArgs(sig, args, context));
                }
                finally
                {
                    if (restoreFocus)
                        context.WithFocus(savedItem, savedPosition, savedSize);
                    if (restoreBaseUri)
                        context.BaseUri = savedBaseUri;
                    if (restoreNamespaces && savedNamespaces is not null)
                        context.RestoreNamespaces(savedNamespaces);
                }

            case DelegateFunctionItem del:
                if (args.Length != del.ArityValue)
                    throw new InvalidOperationException("XPTY0004: Wrong number of arguments for dynamic function call.");
                return del.Implementation(context, args);

            case CoercedFunctionItem coerced:
                {
                    // XPath 3.1 function conversion rules: convert each argument to the
                    // declared parameter type, invoke the inner function, and validate the
                    // result against the declared return type (higher-order-functions-038/060).
                    if (args.Length != coerced.ParamTypes.Count)
                        throw new InvalidOperationException("XPTY0004: Wrong number of arguments for dynamic function call.");
                    var convertedArgs = new XdmValue[args.Length];
                    for (int i = 0; i < args.Length; i++)
                    {
                        var paramType = coerced.ParamTypes[i];
                        convertedArgs[i] = string.IsNullOrEmpty(paramType)
                            ? args[i]
                            : ApplyFunctionConversion(args[i], paramType!, context);
                    }
                    var coercedResult = InvokeFunctionItem(coerced.Inner, context, convertedArgs);
                    return string.IsNullOrEmpty(coerced.ReturnType)
                        ? coercedResult
                        : ApplyFunctionConversion(coercedResult, coerced.ReturnType!, context);
                }

            case InlineFunctionItem inline:
                {
                    if (args.Length != inline.Parameters.Count)
                        throw new InvalidOperationException("XPTY0004: Wrong number of arguments for dynamic call of an inline function.");

                    // Snapshot the entire variable scope: the function body is a new scope.
                    // Parameters, captured closure variables, and any let/for bindings created
                    // during execution must not leak back to the caller, and recursive calls
                    // must not clobber the caller's same-named bindings (functx dynamic-path).
                    var variableSnapshot = context.SnapshotVariables();

                    // Restore captured closure variables (the defining environment) so the
                    // body can reference outer variables after the defining frame exited.
                    if (inline.CapturedVariables is { Count: > 0 } captured)
                    {
                        foreach (var (key, capturedValue) in captured)
                            context.WithVariable(key.LocalName, capturedValue, key.NamespaceUri);
                    }

                    // Apply XPath 3.1 function conversion rules to each argument: atomization,
                    // untypedAtomic casting, numeric promotion, and URI promotion. Validation
                    // against the declared type is performed on the converted value using the
                    // static context for context-sensitive types (e.g., xs:QName).
                    var convertedArgs = new XdmValue[args.Length];
                    for (int i = 0; i < inline.Parameters.Count; i++)
                    {
                        var expectedType = i < inline.ParameterTypes.Count ? inline.ParameterTypes[i] : null;
                        if (!string.IsNullOrEmpty(expectedType))
                        {
                            convertedArgs[i] = ApplyFunctionConversion(args[i], expectedType!, context);
                            // Function tests: ApplyFunctionConversion already enforced arity
                            // and wrapped the items in CoercedFunctionItems, which carry no
                            // declared signature for ValueMatchesType to match — skip the
                            // redundant re-validation for function items (hof-040/045).
                            var trimmedType = expectedType!.TrimStart();
                            bool functionTest = trimmedType.StartsWith("function", StringComparison.OrdinalIgnoreCase)
                                || trimmedType.StartsWith("(function", StringComparison.OrdinalIgnoreCase);
                            var converted = convertedArgs[i];
                            if (!converted.IsUndefined && !functionTest)
                            {
                                if (converted.IsSequence)
                                {
                                    foreach (var item in XdmSequence.FromSource(converted.SequenceValue!))
                                    {
                                        if (!ValueMatchesType(item, expectedType, context))
                                            throw new InvalidOperationException("XPTY0004");
                                    }
                                }
                                else
                                {
                                    if (!ValueMatchesType(converted, expectedType, context))
                                        throw new InvalidOperationException("XPTY0004");
                                }
                            }
                        }
                        else
                        {
                            convertedArgs[i] = args[i];
                        }
                    }

                    for (int i = 0; i < inline.Parameters.Count; i++)
                    {
                        var (localName, nsUri) = ResolveVariableName(inline.Parameters[i], context);
                        context.WithVariable(localName, i < convertedArgs.Length ? convertedArgs[i] : XdmValue.Undefined, nsUri);
                    }
                    var savedFocusItem = context.ContextItem;
                    var savedFocusPosition = context.ContextPosition;
                    var savedFocusSize = context.ContextSize;
                    var savedAliases = inline.CapturedBoundFunctionAliases is null
                        ? null : context.SnapshotBoundFunctionAliases();
                    try
                    {
                        if (inline.CapturedBoundFunctionAliases is { } aliases)
                            context.RestoreBoundFunctionAliases(aliases);
                        // XPath 3.1 §3.1.5 / XQuery: a user-defined function body (declared or
                        // inline) is evaluated with the context item, position, and size
                        // absent — the caller's focus must not propagate into the body
                        // (K2-FunctionProlog-14); references to it raise XPDY0002.
                        context.WithFocus(XdmValue.Undefined, 0, 0);
                        var result = Execute(inline.Body, context);
                        // XPath 3.1 function conversion (atomization, untypedAtomic and URI
                        // casts, numeric promotion) applies to the result before return-type
                        // validation; cardinality and type mismatches raise XPTY0004.
                        if (!string.IsNullOrEmpty(inline.ReturnType))
                            result = ApplyFunctionConversion(result, inline.ReturnType, context);
                        return result;
                    }
                    finally
                    {
                        context.WithFocus(savedFocusItem, savedFocusPosition, savedFocusSize);
                        context.RestoreVariables(variableSnapshot);
                        if (inline.CapturedBoundFunctionAliases is not null)
                            context.RestoreBoundFunctionAliases(savedAliases);
                    }
                }

            case CurriedFunctionItem curried:
                {
                    int placeholderCount = curried.FixedArgs.Count(a => a is null);
                    if (args.Length != placeholderCount)
                        throw new InvalidOperationException("XPTY0004: Wrong number of arguments for dynamic call of a partially applied function.");
                    var merged = new XdmValue[curried.FixedArgs.Length];
                    int argIdx = 0;
                    for (int i = 0; i < curried.FixedArgs.Length; i++)
                    {
                        if (curried.FixedArgs[i] is { } boundArg)
                            merged[i] = boundArg;
                        else
                            merged[i] = argIdx < args.Length ? args[argIdx++] : XdmValue.Undefined;
                    }
                    return InvokeFunctionItem(curried.BaseFunction, context, merged);
                }

            default:
                throw new InvalidOperationException($"Unknown function item type: {func.GetType().Name}");
        }
    }

    /// <summary>
    /// Invokes a value as a function: function items are invoked directly, maps are
    /// invoked as functions of their key, and arrays as functions of their 1-based index.
    /// A single-item sequence wrapping a function item is unwrapped first.
    /// </summary>
    /// <param name="funcValue">The value to invoke.</param>
    /// <param name="context">The evaluation context for the call.</param>
    /// <param name="args">The call arguments.</param>
    /// <returns>The value produced by the invocation.</returns>
    /// <exception cref="InvalidOperationException">The value is not invocable, or the
    /// argument count is wrong for a map/array call (XPTY0004).</exception>
    public static XdmValue InvokeFunctionItem(XdmValue funcValue, EvaluationContext context, ReadOnlySpan<XdmValue> args)
    {
        // A dynamic call target may arrive as a single-item sequence wrapping a
        // function item (e.g. the result of a let expression); unwrap it.
        if (funcValue.IsSequence)
        {
            var items = MaterializeSequence(funcValue);
            if (items.Length == 1)
                funcValue = items[0];
            else
                throw new InvalidOperationException("XPTY0004");
        }

        if (funcValue.IsFunction)
            return InvokeFunctionItem((FunctionItem)funcValue.FunctionValue, context, args);

        if (funcValue.IsMap)
        {
            if (args.Length != 1)
                throw new InvalidOperationException("XPTY0004");
            var key = AtomizeMapKey(args[0]);
            var map = funcValue.MapValue;
            // XPath 4.0 §4.15.3: a record called as a function field-checks its key.
            CheckRecordLookupKey(map, key);
            if (map.TryGetValue(key, out var value))
                return value;
            return XdmValue.FromSequence(XdmSequence.Empty);
        }

        if (funcValue.IsArray)
        {
            if (args.Length != 1)
                throw new InvalidOperationException("XPTY0004");
            return ArrayLookup(funcValue.ArrayValue, args[0]);
        }

        throw new InvalidOperationException("XPTY0004");
    }

    private static XdmValue Atomize(XdmValue value)
    {
        if (value.IsUndefined)
            return XdmValue.Undefined;

        if (value.IsNode)
        {
            var node = value.NodeValue;
            // XDM §2.7.2: comments and PIs atomize to xs:string; namespace nodes too.
            // Untyped nodes atomize to xs:untypedAtomic. Schema-validated nodes return
            // their PSVI typed value; element-only/empty complex types raise FOTY0012.
            if (node.NodeKind is XdmNodeKind.ProcessingInstruction or XdmNodeKind.Comment)
                return XdmValue.FromString(node.StringValue);
            if (node.NodeKind == XdmNodeKind.Namespace)
                return XdmValue.FromString(node.StringValue);
            if (node.SchemaTypeAnnotation is null)
                return XdmValue.FromString(node.StringValue, "untypedAtomic");
            if (node.HasNoTypedValue)
                throw new InvalidOperationException("FOTY0012: Cannot atomize a node that has no typed value.");
            return node.TypedValue;
        }

        if (value.IsArray && value.ArrayValue is not null)
        {
            // Empty members contribute no atomic values; count after recursive atomization.
            var singleton = XdmValue.Undefined;
            foreach (var member in value.ArrayValue.Values)
                AppendArrayAtomizedSingleton(member, ref singleton);
            return singleton;
        }

        if (value.IsJNode)
        {
            // XPath 4.0 §17.7: atomic-required contexts extract the jvalue before
            // atomizing (fn-jtree-010/011/021/026 coercion).
            return Atomize(value.JNodeValue.Value);
        }

        if (value.IsSequence)
        {
            var items = MaterializeSequence(value);
            if (items.Length == 1)
                return Atomize(items[0]);
            if (items.Length == 0)
                return XdmValue.Undefined;
            // Singleton requirement (fn:data, arithmetic, value comparisons):
            // atomization of a multi-item sequence is a type error.
            throw new InvalidOperationException(
                "XPTY0004: Atomization requires a singleton or empty sequence, but got a sequence of length " + items.Length);
        }

        return value;
    }

    /// <summary>Accumulates at most one atomic value from a recursively atomized array member.</summary>
    private static void AppendArrayAtomizedSingleton(XdmValue value, ref XdmValue singleton)
    {
        if (value.IsUndefined)
            return;
        if (value.IsArray && value.ArrayValue is not null)
        {
            foreach (var member in value.ArrayValue.Values)
                AppendArrayAtomizedSingleton(member, ref singleton);
            return;
        }
        if (value.IsSequence && value.SequenceValue is not null)
        {
            foreach (var item in XdmSequence.FromSource(value.SequenceValue))
                AppendArrayAtomizedSingleton(item, ref singleton);
            return;
        }
        if (value.IsJNode)
        {
            AppendArrayAtomizedSingleton(value.JNodeValue.Value, ref singleton);
            return;
        }
        if (value.IsNode)
        {
            AppendArrayAtomizedSingleton(Atomize(value), ref singleton);
            return;
        }
        if (value.IsMap || value.IsFunction)
            throw new InvalidOperationException("FOTY0013: Cannot atomize a function item or map.");
        if (!singleton.IsUndefined)
            throw new InvalidOperationException(
                "XPTY0004: Atomization requires a singleton or empty sequence, but got an array with multiple atomic values.");
        singleton = value;
    }

    /// <summary>
    /// Atomizes a value for <c>cast as</c> / <c>castable as</c> operands. Arrays are
    /// recursively flattened and their members atomized; maps and function items raise
    /// <c>FOTY0013</c>; sequences have each item atomized and flattened.
    /// </summary>
    private static XdmValue AtomizeForCast(XdmValue value)
    {
        if (value.IsUndefined)
            return XdmValue.Undefined;

        if (value.IsJNode)
        {
            // XPath 4.0 §17.7: atomic-required contexts (casts included) extract the jvalue.
            return AtomizeForCast(value.JNodeValue.Value);
        }

        if (value.IsFunction || value.IsMap)
            throw new InvalidOperationException("FOTY0013: Cannot atomize a function item (including maps)");

        if (value.IsNode)
            return Atomize(value);

        if (value.IsArray && value.ArrayValue is not null)
        {
            var items = new List<XdmValue>();
            foreach (var member in value.ArrayValue.Values)
                AppendAtomizedForCast(AtomizeForCast(member), items);
            return MakeAtomizedSequence(items);
        }

        if (value.IsSequence && value.SequenceValue is not null)
        {
            var items = new List<XdmValue>();
            foreach (var item in XdmSequence.FromSource(value.SequenceValue))
                AppendAtomizedForCast(AtomizeForCast(item), items);
            return MakeAtomizedSequence(items);
        }

        return value;
    }

    private static void AppendAtomizedForCast(XdmValue atomized, List<XdmValue> items)
    {
        if (atomized.IsUndefined)
            return;
        if (atomized.IsSequence && atomized.SequenceValue is not null)
        {
            foreach (var sub in XdmSequence.FromSource(atomized.SequenceValue))
                items.Add(sub);
        }
        else
        {
            items.Add(atomized);
        }
    }

    private static XdmValue MakeAtomizedSequence(List<XdmValue> items)
    {
        if (items.Count == 0)
            return XdmValue.Undefined;
        if (items.Count == 1)
            return items[0];
        return XdmValue.FromSequence(MaterializedSequence.FromList(items));
    }

    private static bool IsMapArrayFunctionConversionTarget(string type)
        => type.StartsWith("map(", StringComparison.OrdinalIgnoreCase)
            || type.StartsWith("array(", StringComparison.OrdinalIgnoreCase)
            || type.StartsWith("function(", StringComparison.OrdinalIgnoreCase)
            || type.Equals("map", StringComparison.OrdinalIgnoreCase)
            || type.Equals("array", StringComparison.OrdinalIgnoreCase)
            || type.Equals("function", StringComparison.OrdinalIgnoreCase);

    /// <summary>
    /// Returns true if the exception represents a type error that must be raised by
    /// <c>castable as</c> rather than swallowed as a failed cast.
    /// </summary>
    private static bool IsTypeError(InvalidOperationException exception)
    {
        var message = exception.Message;
        return message.StartsWith("FOTY", StringComparison.Ordinal)
            || message.StartsWith("XPTY", StringComparison.Ordinal);
    }

    // Atomizes node items in a value (one level; sequence items are mapped individually)
    // for variable-declaration type checking (XQuery 3.1 §4.16).
    private static XdmValue AtomizeItems(XdmValue value)
    {
        if (value.IsNode)
            return Atomize(value);
        if (!value.IsSequence || value.SequenceValue is null)
            return value;
        var items = MaterializeSequence(value);
        bool anyNode = false;
        foreach (var item in items)
        {
            if (item.IsNode)
            {
                anyNode = true;
                break;
            }
        }
        if (!anyNode)
            return value;
        var atomized = new List<XdmValue>(items.Length);
        foreach (var item in items)
            atomized.Add(item.IsNode ? Atomize(item) : item);
        return XdmValue.FromSequence(MaterializedSequence.FromList(atomized));
    }

    // True when a sequence-type text is a node kind test (element/attribute/node/...),
    // whose matching applies to the nodes themselves without atomization.
    private static bool IsNodeKindTest(string typeName)
    {
        var t = typeName.TrimStart();
        return t.StartsWith("element(", StringComparison.Ordinal)
            || t.StartsWith("attribute(", StringComparison.Ordinal)
            || t.StartsWith("document-node(", StringComparison.Ordinal)
            || t.StartsWith("comment(", StringComparison.Ordinal)
            || t.StartsWith("text(", StringComparison.Ordinal)
            || t.StartsWith("processing-instruction(", StringComparison.Ordinal)
            || t.StartsWith("namespace-node(", StringComparison.Ordinal)
            || t.StartsWith("schema-element(", StringComparison.Ordinal)
            || t.StartsWith("schema-attribute(", StringComparison.Ordinal)
            || t.StartsWith("node(", StringComparison.Ordinal);
    }

    private static string AtomizedStringValue(XdmValue value)
    {
        if (value.IsUndefined)
            return string.Empty;

        if (value.IsFunction || value.IsMap || value.IsArray)
            throw new InvalidOperationException("FOTY0013: Argument to string concatenation is a function, map, or array");

        var atomized = Atomize(value);
        if (atomized.IsUndefined)
            return string.Empty;

        return atomized.ToString();
    }

    /// <summary>
    /// Unwraps a singleton sequence to its single item, or returns the value as-is.
    /// Returns Undefined for an empty sequence.
    /// </summary>
    private static XdmValue UnwrapSingleton(XdmValue value)
    {
        if (value.IsUndefined || !value.IsSequence)
            return value;

        var items = MaterializeSequence(value);
        if (items.Length == 0)
            return XdmValue.Undefined;
        if (items.Length == 1)
            return items[0];
        return value;
    }

    /// <summary>
    /// Returns true if the value is a node or a singleton sequence containing a node.
    /// Used to determine whether atomization produces an untyped atomic value.
    /// </summary>
    private static bool IsNodeOrigin(XdmValue value)
    {
        if (value.IsUndefined)
            return false;
        if (value.IsNode)
            return true;
        if (value.IsSequence && value.SequenceValue is not null)
        {
            var items = MaterializeSequence(value);
            if (items.Length == 1)
                return IsNodeOrigin(items[0]);
        }
        return false;
    }

    /// <summary>
    /// Whether a node sequence mixes document-rooted and parentless (detached) nodes.
    /// Only materialized sequences are inspected: enumerating any other (lazy,
    /// forward-only) sequence kind here would consume a stream that the passthrough
    /// is meant to keep live (sf-avg-043). Single-pass streamed sequences are rooted
    /// by construction. Non-node items are ignored. Used by the Normalize opcode's
    /// streamed-pipeline passthrough: mixed materialized sequences still need the
    /// rooted-before-parentless ordering (si-fork-118, sf-insert-before-141).
    /// </summary>
    private static bool MixesDetachedNodes(XdmValue value)
    {
        if (value.IsUndefined || !value.IsSequence)
            return false;
        if (value.SequenceValue is not MaterializedSequence materialized)
            return false;
        bool sawRooted = false;
        bool sawDetached = false;
        foreach (var item in materialized.Items)
        {
            if (!item.IsNode)
                continue;
            if (item.NodeValue!.Document is not null)
                sawRooted = true;
            else
                sawDetached = true;
            if (sawRooted && sawDetached)
                return true;
        }
        return false;
    }

    /// <summary>
    /// Removes duplicate nodes and sorts the remaining nodes into document order.
    /// Non-node items are preserved in their original relative order after all nodes.
    /// </summary>
    private static XdmValue NormalizeSequence(XdmValue value)
    {
        if (value.IsUndefined || !value.IsSequence)
            return value;

        // Single-pass (streamed) sequences are produced duplicate-free in document
        // order by construction; skip materialization, dedup, and sorting entirely
        // so streamed items are released as they are consumed.
        if (value.SequenceValue is ISinglePassSequence)
            return value;

        var items = MaterializeSequenceView(value);
        if (items.Count <= 1)
            return value;

        // Fast path: axis walks already produce duplicate-free node sequences in document
        // order with a uniform document partition. Strictly increasing DocumentOrder keys
        // imply distinctness, and the stable partition sort below is then the identity —
        // so the HashSet, order-key list, and sort can all be skipped. Keys are computed
        // eagerly in sequence order (parentless trees receive their tree sequence on first
        // access — square-array-014).
        bool alreadyOrdered = true;
        bool sawInDocument = false;
        bool sawDetached = false;
        long previousKey = 0;
        bool firstNode = true;
        foreach (var item in items)
        {
            if (!item.IsNode)
                continue;
            var node = item.NodeValue!;
            long key = node.DocumentOrder;
            if (node.Document is not null)
                sawInDocument = true;
            else
                sawDetached = true;
            if ((!firstNode && key <= previousKey) || (sawInDocument && sawDetached))
            {
                alreadyOrdered = false;
                break;
            }
            previousKey = key;
            firstNode = false;
        }

        if (alreadyOrdered)
        {
            var orderedNodes = new List<XdmValue>(items.Count);
            List<XdmValue>? orderedNonNodes = null;
            bool sawAnyNode = false;
            foreach (var item in items)
            {
                if (item.IsNode)
                {
                    orderedNodes.Add(item);
                    sawAnyNode = true;
                }
                else
                {
                    (orderedNonNodes ??= new List<XdmValue>()).Add(item);
                }
            }

            if (!sawAnyNode)
                return XdmValue.FromSequence(MaterializedSequence.FromList(orderedNonNodes!));
            if (orderedNonNodes is null)
                return XdmValue.FromSequence(MaterializedSequence.FromList(orderedNodes));
            var orderedCombined = new List<XdmValue>(orderedNodes.Count + orderedNonNodes.Count);
            orderedCombined.AddRange(orderedNodes);
            orderedCombined.AddRange(orderedNonNodes);
            return XdmValue.FromSequence(MaterializedSequence.FromList(orderedCombined));
        }

        // Separate nodes from non-node items and remove duplicate nodes.
        var nodes = new List<XdmValue>(items.Count);
        var nonNodes = new List<XdmValue>();
        var seen = new HashSet<IXdmNode>();
        bool hasNodes = false;
        foreach (var item in items)
        {
            if (!item.IsNode)
            {
                nonNodes.Add(item);
                continue;
            }

            hasNodes = true;
            var node = item.NodeValue;
            if (seen.Add(node))
                nodes.Add(item);
        }

        if (!hasNodes)
            return XdmValue.FromSequence(MaterializedSequence.FromList(nonNodes));

        if (nodes.Count > 1)
        {
            // Use a stable sort by document order. Namespace nodes of an element are
            // ordered immediately after the owner element (and before its attributes),
            // so the namespace axis order (xml first, then root-to-current) is preserved
            // by the DocumentOrder key. Document-order keys are computed eagerly in
            // sequence order first: parentless trees receive their tree sequence on first
            // access, and computing keys inside the comparator would assign them in
            // comparison order, scrambling detached copies (square-array-014).
            var indexed = new List<(XdmValue Node, int Index, long OrderKey)>(nodes.Count);
            for (int i = 0; i < nodes.Count; i++)
                indexed.Add((nodes[i], i, nodes[i].NodeValue!.DocumentOrder));
            indexed.Sort((a, b) =>
            {
                bool aDoc = a.Node.NodeValue!.Document is not null;
                bool bDoc = b.Node.NodeValue!.Document is not null;
                if (aDoc != bDoc)
                    return aDoc ? -1 : 1;
                int cmp = a.OrderKey.CompareTo(b.OrderKey);
                if (cmp != 0)
                    return cmp;
                return a.Index.CompareTo(b.Index);
            });
            var sortedNodes = new List<XdmValue>(nodes.Count);
            foreach (var entry in indexed)
                sortedNodes.Add(entry.Node);
            nodes = sortedNodes;
        }

        if (nonNodes.Count == 0)
            return XdmValue.FromSequence(MaterializedSequence.FromList(nodes));

        var combined = new List<XdmValue>(nodes.Count + nonNodes.Count);
        combined.AddRange(nodes);
        combined.AddRange(nonNodes);
        return XdmValue.FromSequence(MaterializedSequence.FromList(combined));
    }

    /// <summary>
    /// Validates that every item in a sequence is a node, raising XPTY0004 otherwise.
    /// Used by union, intersect, and except operators.
    /// </summary>
    private static void RequireNodeSequence(XdmValue[] sequence)
    {
        foreach (var item in sequence)
        {
            if (!item.IsNode)
                throw new InvalidOperationException("XPTY0004");
        }
    }

    /// <summary>
    /// Exposes an array's item list without copying: the backing store is a list at runtime,
    /// so the read-only-list view is free; falls back to a copy if that ever changes.
    /// Callers must treat the view as read-only.
    /// </summary>
    private static IReadOnlyList<XdmValue> ArrayValuesView(XdmArray array)
        => array.Values is IReadOnlyList<XdmValue> list ? list : array.Values.ToArray();

    private static XdmValue FilterNodes(XdmValue input, Func<IXdmNode, bool> predicate)
    {
        var items = MaterializeSequence(input);
        var filtered = new List<XdmValue>();
        foreach (var item in items)
        {
            if (item.IsNode && predicate(item.NodeValue))
                filtered.Add(item);
        }
        return XdmValue.FromSequence(MaterializedSequence.FromList(filtered));
    }

    /// <summary>
    /// Lazy variant of <see cref="FilterNodes"/> for pure node tests (name/kind/namespace):
    /// no intermediate list is materialized — each enumeration re-applies the predicate.
    /// Mirrors FilterNodes exactly: undefined/empty input yields an empty sequence, non-node
    /// items are dropped, and a matching single-item input is returned as a singleton sequence.
    /// </summary>
    private static XdmValue FilterNodesLazy(XdmValue input, Func<IXdmNode, bool> predicate)
    {
        if (input.IsUndefined)
            return XdmValue.FromSequence(XdmSequence.Empty);

        if (!input.IsSequence)
        {
            return input.IsNode && predicate(input.NodeValue)
                ? XdmValue.FromSequence(XdmSequence.Singleton(input))
                : XdmValue.FromSequence(XdmSequence.Empty);
        }

        var seq = input.SequenceValue;
        if (seq is null)
            return XdmValue.FromSequence(XdmSequence.Empty);

        // A filtered subset of a single-pass (streamed) sequence keeps its order and
        // stays duplicate-free, so the marker propagates.
        if (seq is ISinglePassSequence)
        {
            return XdmValue.FromSequence(XdmSequence.FromSource(
                new SinglePassXdmSequence(FilterNodesLazyIterator(seq, predicate))));
        }

        return XdmValue.FromSequence(XdmSequence.FromSource(
            new EnumerableXdmSequence(FilterNodesLazyIterator(seq, predicate))));
    }

    private static IEnumerable<XdmValue> FilterNodesLazyIterator(IXdmSequence source, Func<IXdmNode, bool> predicate)
    {
        foreach (var item in XdmSequence.FromSource(source))
        {
            if (item.IsNode && predicate(item.NodeValue))
                yield return item;
        }
    }

    // ------------------------------------------------------------------
    // Lazy streaming (single-pass) iterators
    //
    // These mirror their eager opcode counterparts but pull the input one
    // item at a time so a streamed sequence is consumed and released
    // incrementally. Focus is saved at first pull and restored after each
    // item; the context size is unknown (-1) for single-pass inputs.
    // ------------------------------------------------------------------

    private static IEnumerable<XdmValue> LazyAxisMapIterator(IXdmSequence source, XdmAxis axis)
    {
        foreach (var item in XdmSequence.FromSource(source))
        {
            if (!item.IsNode)
                throw new InvalidOperationException("XPTY0019: A path step requires nodes, but the step input contains an atomic value.");
            foreach (var node in item.NodeValue.Axis(axis))
                yield return node;
        }
    }

    private static IEnumerable<XdmValue> LazyFilterIterator(
        IrModule module, EvaluationContext context, XdmValue[] registers, int predicateEntry, IXdmSequence input)
    {
        var savedItem = context.ContextItem;
        var savedPos = context.ContextPosition;
        var savedSize = context.ContextSize;

        int pos = 0;
        foreach (var item in XdmSequence.FromSource(input))
        {
            pos++;
            context.WithFocus(item, pos, -1);
            var (predResult, _) = ExecuteBlock(module, context, registers, predicateEntry);
            context.WithFocus(savedItem, savedPos, savedSize);

            // Predicate semantics (XPath §2.4) as in the eager Filter path: a numeric
            // singleton is positional, a singleton node is kept, everything else uses
            // the effective boolean value.
            bool numericPredicate = false;
            double numericValue = 0;
            if (!predResult.IsUndefined)
            {
                if (IsNumeric(predResult))
                {
                    numericPredicate = true;
                    numericValue = ToDouble(predResult);
                }
                else if (predResult.IsSequence && predResult.SequenceValue is not null &&
                         TryGetSingletonItem(predResult.SequenceValue, out var singletonItem))
                {
                    if (singletonItem.IsNode)
                    {
                        yield return item;
                        continue;
                    }
                    var atomizedItem = Atomize(singletonItem);
                    if (IsNumeric(atomizedItem))
                    {
                        numericPredicate = true;
                        numericValue = ToDouble(atomizedItem);
                    }
                }
            }

            if (numericPredicate)
            {
                if (numericValue == pos)
                    yield return item;
            }
            else if (predResult.GetEffectiveBooleanValue())
            {
                yield return item;
            }
        }

        context.WithFocus(savedItem, savedPos, savedSize);
    }

    private static IEnumerable<XdmValue> LazyPathStepIterator(
        IrModule module, EvaluationContext context, XdmValue[] registers, int rhsEntry, IXdmSequence input, bool hasLhs)
    {
        var savedItem = context.ContextItem;
        var savedPos = context.ContextPosition;
        var savedSize = context.ContextSize;

        foreach (var item in XdmSequence.FromSource(input))
        {
            if (!item.IsNode)
            {
                if (hasLhs)
                    throw new InvalidOperationException("XPTY0019: An axis step requires a node as context item.");
                throw new InvalidOperationException("XPTY0020: An axis step requires a context item that is a node.");
            }

            // Path-step predicates see position=1, size=1 for each context item.
            context.WithFocus(item, 1, 1);
            var (rhsResult, _) = ExecuteBlock(module, context, registers, rhsEntry);
            context.WithFocus(savedItem, savedPos, savedSize);

            if (rhsResult.IsSequence && rhsResult.SequenceValue is not null)
            {
                foreach (var r in XdmSequence.FromSource(rhsResult.SequenceValue))
                    yield return r;
            }
            else if (!rhsResult.IsUndefined)
            {
                yield return rhsResult;
            }
        }

        context.WithFocus(savedItem, savedPos, savedSize);
    }

    private static IEnumerable<XdmValue> LazySimpleMapIterator(
        IrModule module, EvaluationContext context, XdmValue[] registers, int rhsEntry, IXdmSequence input, int pathResultMode)
    {
        bool enforceNodeResult = pathResultMode != 0;
        var savedItem = context.ContextItem;
        var savedPos = context.ContextPosition;
        var savedSize = context.ContextSize;

        int pos = 0;
        bool hasNode = false;
        bool hasNonNode = false;
        foreach (var item in XdmSequence.FromSource(input))
        {
            pos++;
            if (enforceNodeResult && !IsPathStepContextItem(item, context))
                throw new InvalidOperationException("XPTY0019: An axis step requires a node as context item.");

            context.WithFocus(item, pos, -1);
            var (rhsResult, _) = ExecuteBlock(module, context, registers, rhsEntry);
            context.WithFocus(savedItem, savedPos, savedSize);

            if (rhsResult.IsSequence && rhsResult.SequenceValue is not null)
            {
                foreach (var r in XdmSequence.FromSource(rhsResult.SequenceValue))
                {
                    if (pathResultMode == 2 && !r.IsNode && !r.IsJNode)
                        throw new InvalidOperationException("XPTY0019: result of a path expression step other than the last step contains a non-node item");
                    if (r.IsNode || r.IsJNode) hasNode = true; else hasNonNode = true;
                    yield return r;
                }
            }
            else if (!rhsResult.IsUndefined)
            {
                if (pathResultMode == 2 && !rhsResult.IsNode && !rhsResult.IsJNode)
                    throw new InvalidOperationException("XPTY0019: result of a path expression step other than the last step contains a non-node item");
                if (rhsResult.IsNode || rhsResult.IsJNode) hasNode = true; else hasNonNode = true;
                yield return rhsResult;
            }
        }

        // The mixed-result check (XPTY0018) can only be decided at the end of a
        // single-pass enumeration; eager evaluation raises it before returning.
        if (enforceNodeResult && hasNode && hasNonNode)
            throw new InvalidOperationException("XPTY0018: result of a path expression step contains both nodes and non-nodes");

        context.WithFocus(savedItem, savedPos, savedSize);
    }

    /// <summary>
    /// XPath 4.0 §4.7.5/§17.7: nodes, JNodes, and (at the 4.0 level) raw maps/arrays
    /// are valid path-step context items — raw maps/arrays are implicitly wrapped as
    /// by fn:jtree. Anything else raises XPTY0019/XPTY0020.
    /// </summary>
    private static bool IsPathStepContextItem(XdmValue item, EvaluationContext context)
        => item.IsNode || item.IsJNode
            || (context.IsXPath40 && (item.IsMap || item.IsArray));

    /// <summary>Lazily enforces the all-nodes result contract of a non-final path step.</summary>
    private static IEnumerable<XdmValue> RequireNodesLazy(IXdmSequence source)
    {
        foreach (var item in XdmSequence.FromSource(source))
        {
            // XPath 4.0: JNodes are path-step results like nodes.
            if (!item.IsNode && !item.IsJNode)
                throw new InvalidOperationException("XPTY0019: result of a path expression step other than the last step contains a non-node item");
            yield return item;
        }
    }

    /// <summary>
    /// Lazily enforces a treat-as assertion over a single-pass (streamed) input: each
    /// item is instance-checked as it flows through, and the cardinality assertion is
    /// decided from the item count at the end of the single real enumeration.
    /// </summary>
    private static IEnumerable<XdmValue> TreatAsLazyIterator(
        IXdmSequence source,
        string typeName,
        OccurrenceIndicator occurrence,
        string? defaultElementNamespace,
        EvaluationContext? context)
    {
        int count = 0;
        foreach (var item in XdmSequence.FromSource(source))
        {
            count++;
            if (!InstanceOf(item, typeName, OccurrenceIndicator.One, defaultElementNamespace, context))
                throw new InvalidOperationException(
                    $"XPDY0050: Treat as assertion failed for type {typeName} with occurrence {occurrence}.");
            if (count == 2 && occurrence is OccurrenceIndicator.One or OccurrenceIndicator.ZeroOrOne)
                throw new InvalidOperationException(
                    $"XPDY0050: Treat as assertion failed for type {typeName} with occurrence {occurrence}.");
            yield return item;
        }

        // 'treat as empty-sequence()' succeeds only for the empty sequence.
        if (count == 0 && NormalizeTypeName(typeName) is "empty-sequence" or "empty-sequence()")
            yield break;

        bool cardinalityOk = occurrence switch
        {
            OccurrenceIndicator.One => count == 1,
            OccurrenceIndicator.ZeroOrOne => count <= 1,
            OccurrenceIndicator.ZeroOrMore => true,
            OccurrenceIndicator.OneOrMore => count >= 1,
            _ => count == 1,
        };
        if (!cardinalityOk)
            throw new InvalidOperationException(
                $"XPDY0050: Treat as assertion failed for type {typeName} with occurrence {occurrence}.");
    }

    /// <summary>Lazily enforces the no-mixed-results contract of a final path step.</summary>
    private static IEnumerable<XdmValue> RejectMixedNodesLazy(IXdmSequence source)
    {
        bool hasNode = false;
        bool hasNonNode = false;
        foreach (var item in XdmSequence.FromSource(source))
        {
            if (item.IsNode) hasNode = true; else hasNonNode = true;
            yield return item;
        }
        if (hasNode && hasNonNode)
            throw new InvalidOperationException("XPTY0018: result of a path expression step contains both nodes and non-nodes");
    }

    /// <summary>
    /// Returns the single item of a sequence when it has exactly one item, without
    /// materializing lazy sequences (at most two items are enumerated to decide).
    /// </summary>
    private static bool TryGetSingletonItem(IXdmSequence seq, out XdmValue item)
    {
        if (seq is MaterializedSequence materialized)
        {
            if (materialized.Items.Count == 1)
            {
                item = materialized.Items[0];
                return true;
            }
            item = default;
            return false;
        }

        var enumerator = XdmSequence.FromSource(seq).GetEnumerator();
        if (!enumerator.MoveNext())
        {
            item = default;
            return false;
        }
        var first = enumerator.Current;
        if (enumerator.MoveNext())
        {
            item = default;
            return false;
        }
        item = first;
        return true;
    }

    /// <summary>
    /// Materializes a sequence like <see cref="MaterializeSequence"/> but returns a read-only
    /// view: an already-materialized sequence is exposed without copying, and a lazy sequence
    /// is collected into a single list (no List-growth + ToArray double copy).
    /// </summary>
    private static IReadOnlyList<XdmValue> MaterializeSequenceView(XdmValue sequence)
    {
        if (sequence.IsUndefined)
            return Array.Empty<XdmValue>();

        if (sequence.IsSequence)
        {
            var seq = sequence.SequenceValue;
            if (seq is null)
                return Array.Empty<XdmValue>();

            if (seq is MaterializedSequence materialized)
                return materialized.Items;

            var list = new List<XdmValue>();
            foreach (var item in XdmSequence.FromSource(seq))
                list.Add(item);
            return list;
        }

        return new[] { sequence };
    }

    /// <summary>
    /// Matches a node against a kind-test name carried by the <see cref="IrOpCode.KindTest"/>
    /// operand. A parameterized <c>document-node(element(E[,T]))</c> /
    /// <c>document-node(schema-element(E))</c> operand is matched structurally: the document
    /// must have exactly one element child, no text-node children, and the element child must
    /// satisfy the inner test (validation-1401, import-schema-055).
    /// </summary>
    /// <param name="node">The candidate node.</param>
    /// <param name="kindName">The kind-test name, optionally a full document-node(...) test.</param>
    /// <param name="context">The evaluation context (namespace and schema lookups).</param>
    /// <returns>True when the node satisfies the kind test.</returns>
    private static bool MatchesKindTest(IXdmNode node, string kindName, EvaluationContext? context)
    {
        if (kindName.StartsWith("document-node(", StringComparison.Ordinal) && kindName.EndsWith(')'))
            return MatchesDocumentNodeTest(node, kindName, context);

        return kindName.ToLowerInvariant() switch
        {
            "node" => true,
            "text" => node.NodeKind == XdmNodeKind.Text,
            "comment" => node.NodeKind == XdmNodeKind.Comment,
            "processing-instruction" => node.NodeKind == XdmNodeKind.ProcessingInstruction,
            "element" => node.NodeKind == XdmNodeKind.Element,
            "attribute" => node.NodeKind == XdmNodeKind.Attribute,
            "document-node" => node.NodeKind == XdmNodeKind.Document,
            "namespace-node" => node.NodeKind == XdmNodeKind.Namespace,
            // Schema-aware kind tests are XPST0008 (no schema awareness); a prefixed
            // name argument has already been namespace-checked by a preceding
            // NamespaceTest opcode (XPST0081 for unbound prefixes, K2-NameTest-35/36).
            _ => true // permissive fallback
        };
    }

    /// <summary>
    /// Matches a document node against a parameterized <c>document-node(element(E[,T]))</c> or
    /// <c>document-node(schema-element(E))</c> kind test: exactly one element child, no
    /// text-node children, and the element child must satisfy the inner name/type test.
    /// </summary>
    /// <param name="node">The candidate node.</param>
    /// <param name="kindName">The full kind-test text, e.g. <c>document-node(element(E, T))</c>.</param>
    /// <param name="context">The evaluation context (namespace and schema lookups).</param>
    /// <returns>True when the document node satisfies the inner test.</returns>
    private static bool MatchesDocumentNodeTest(IXdmNode node, string kindName, EvaluationContext? context)
    {
        if (node.NodeKind != XdmNodeKind.Document)
            return false;

        string inner = kindName["document-node(".Length..^1].Trim();
        if (inner.Length == 0)
            return true; // bare document-node() form

        IXdmNode? elementChild = null;
        int elementCount = 0;
        foreach (var child in node.Children())
        {
            if (child.NodeValue?.NodeKind == XdmNodeKind.Element)
            {
                elementCount++;
                elementChild ??= child.NodeValue;
            }
            else if (child.NodeValue?.NodeKind == XdmNodeKind.Text)
            {
                // A document-node(element(...)) test requires no text-node children.
                return false;
            }
        }
        if (elementCount != 1 || elementChild is null)
            return false;

        return MatchesInnerElementTest(elementChild, inner, context);
    }

    /// <summary>
    /// Matches an element node against the inner test of a parameterized document-node() kind
    /// test: <c>element(E)</c>, <c>element(E, T)</c>, <c>element(*, T)</c>, or
    /// <c>schema-element(E)</c>. Element names resolve like path-step name tests (unprefixed
    /// names use the default element namespace); the type argument is checked with the same
    /// compatibility rules as the <c>element(*, T)</c> kind test.
    /// </summary>
    /// <param name="element">The document's single element child.</param>
    /// <param name="inner">The inner test text, e.g. <c>element(E, T)</c> or <c>schema-element(E)</c>.</param>
    /// <param name="context">The evaluation context (namespace and schema lookups).</param>
    /// <returns>True when the element satisfies the inner test.</returns>
    private static bool MatchesInnerElementTest(IXdmNode element, string inner, EvaluationContext? context)
    {
        if (inner.StartsWith("schema-element(", StringComparison.Ordinal) && inner.EndsWith(')'))
        {
            var arg = inner["schema-element(".Length..^1].Trim();
            return MatchesSchemaElement(element, arg, context);
        }

        if (!inner.StartsWith("element(", StringComparison.Ordinal) || !inner.EndsWith(')'))
            return false;
        var content = inner["element(".Length..^1].Trim();

        // Split the inner argument into name and type parts at the top-level comma.
        string namePart = content;
        string? typePart = null;
        int depth = 0;
        for (int i = 0; i < content.Length; i++)
        {
            if (content[i] == '(') depth++;
            else if (content[i] == ')') depth--;
            else if (content[i] == ',' && depth == 0)
            {
                namePart = content[..i].Trim();
                typePart = content[(i + 1)..].Trim();
                break;
            }
        }

        if (namePart.Length > 0 && namePart != "*")
        {
            if (namePart.StartsWith("Q{", StringComparison.Ordinal))
            {
                int close = namePart.IndexOf('}');
                string ns = close > 2 ? namePart[2..close] : string.Empty;
                string local = close >= 0 ? namePart[(close + 1)..] : namePart;
                if (element.NamespaceUri != ns || element.LocalName != local)
                    return false;
            }
            else
            {
                int colon = namePart.IndexOf(':');
                string expectedNs;
                string local;
                if (colon > 0)
                {
                    var prefix = namePart[..colon];
                    if (context is null || !context.TryResolveNamespace(prefix, out var resolvedNs))
                        throw new InvalidOperationException($"XPST0081: Prefix '{prefix}' is not declared.");
                    expectedNs = resolvedNs;
                    local = namePart[(colon + 1)..];
                }
                else
                {
                    // Unprefixed element-test names use the default element namespace,
                    // mirroring path-step name tests.
                    expectedNs = context?.DefaultElementNamespace ?? string.Empty;
                    local = namePart;
                }
                if (element.LocalName != local || element.NamespaceUri != expectedNs)
                    return false;
            }
        }

        if (!string.IsNullOrEmpty(typePart))
        {
            if (context is not null)
                ValidateKindTestTypeName(typePart, context);
            return IsElementTypeCompatible(typePart, context, element);
        }
        return true;
    }

    /// <summary>
    /// Matches an element node against a <c>schema-element(N)</c> kind test using the
    /// compiled schema set in the evaluation context. The node matches when its validated
    /// element declaration is <c>N</c> or a member of its substitution group, the nillability
    /// constraint is satisfied, and the node's type annotation is derived from the declared
    /// type of the matching declaration.
    /// </summary>
    private static bool MatchesSchemaElement(IXdmNode node, string nameArg, EvaluationContext? context)
    {
        if (node.NodeKind != XdmNodeKind.Element)
            return false;

        if (context?.SchemaSet is null)
            throw new InvalidOperationException("XPST0008: Schema-aware kind tests are not supported (no schema awareness).");

        var (targetNs, targetLocal) = ResolveTypeQName(nameArg, context);
        var targetDecl = context.GetSchemaElement(targetNs, targetLocal)
            ?? throw new InvalidOperationException($"XPST0008: Schema element declaration Q{{{targetNs}}}{targetLocal} is not defined.");

        if (node.SchemaElementDeclaration is null)
            return false;

        // XPath 3.1 2.5.5.4 uses the global declaration for the node's name N,
        // including when its governing validation declaration is local.
        var candidateDecl = context.GetSchemaElement(node.NamespaceUri, node.LocalName);
        if (candidateDecl is null || !IsActualSubstitutionMember(candidateDecl, targetDecl, context))
            return false;
        if (node.IsNilled && !candidateDecl.IsNillable)
            return false;

        var candidateType = candidateDecl.ElementSchemaType ?? candidateDecl.SchemaType;
        if (candidateType is null)
            return true;

        // Retain the existing anonymous-type fallback. Named annotations must derive
        // from declaration N's type, rather than the potentially broader head type.
        var actualType = ResolveSchemaTypeAnnotation(context, node.SchemaTypeAnnotation)
            ?? candidateType;
        return XmlSchemaType.IsDerivedFrom(actualType, candidateType, XmlSchemaDerivationMethod.Empty);
    }

    /// <summary>Tests actual membership in a compiled single-affiliation substitution group.</summary>
    private static bool IsActualSubstitutionMember(XmlSchemaElement candidate, XmlSchemaElement head, EvaluationContext context)
    {
        if (candidate.IsAbstract)
            return false;
        if (ReferenceEquals(candidate, head))
            return true;
        if ((head.BlockResolved & XmlSchemaDerivationMethod.Substitution) != 0)
            return false;

        // Affiliation is transitive; an intermediate element's block applies to
        // its own group, not automatically to the group of a different head.
        var current = candidate;
        int remaining = context.SchemaSet!.GlobalElements.Count;
        while (remaining-- > 0)
        {
            var affiliation = current.SubstitutionGroup;
            if (affiliation.IsEmpty)
                return false;
            current = context.GetSchemaElement(affiliation.Namespace, affiliation.Name);
            if (current is null)
                return false;
            if (ReferenceEquals(current, head))
                break;
        }
        if (!ReferenceEquals(current, head))
            return false;

        var candidateType = candidate.ElementSchemaType;
        var headType = head.ElementSchemaType;
        if (candidateType is null || headType is null ||
            !XmlSchemaType.IsDerivedFrom(candidateType, headType, head.BlockResolved))
            return false;

        // XSD 1.0 3.3.6: derivation methods must also avoid prohibited
        // substitutions on the head and intermediate complex type definitions.
        var methods = XmlSchemaDerivationMethod.Empty;
        var prohibited = head.BlockResolved;
        if (headType is XmlSchemaComplexType headComplex)
            prohibited |= headComplex.BlockResolved;
        for (var type = candidateType; !ReferenceEquals(type, headType);)
        {
            methods |= type.DerivedBy;
            var baseType = type.BaseXmlSchemaType;
            if (baseType is null || ReferenceEquals(baseType, type))
                break;
            if (baseType is XmlSchemaComplexType complex)
                prohibited |= complex.BlockResolved;
            type = baseType;
        }
        return (methods & prohibited) == 0;
    }

    /// <summary>Compares schema-element types by actual member-set containment.</summary>
    private static bool IsSchemaElementSubtype(string actual, string test, EvaluationContext context)
    {
        var (actualNs, actualLocal) = ResolveTypeQName(actual[15..^1].Trim(), context);
        var (testNs, testLocal) = ResolveTypeQName(test[15..^1].Trim(), context);
        var actualHead = context.GetSchemaElement(actualNs, actualLocal);
        var testHead = context.GetSchemaElement(testNs, testLocal);
        if (actualHead is null || testHead is null || context.SchemaSet is null)
            return false;
        foreach (XmlSchemaElement candidate in context.SchemaSet.GlobalElements.Values)
            if (IsActualSubstitutionMember(candidate, actualHead, context) &&
                !IsActualSubstitutionMember(candidate, testHead, context))
                return false;
        return true;
    }

    /// <summary>
    /// Matches an attribute node against a <c>schema-attribute(N)</c> kind test using the
    /// compiled schema set in the evaluation context.
    /// </summary>
    private static bool MatchesSchemaAttribute(IXdmNode node, string nameArg, EvaluationContext? context)
    {
        if (node.NodeKind != XdmNodeKind.Attribute)
            return false;

        if (context?.SchemaSet is null)
            throw new InvalidOperationException("XPST0008: Schema-aware kind tests are not supported (no schema awareness).");

        var (targetNs, targetLocal) = ResolveTypeQName(nameArg, context);
        var targetDecl = context.GetSchemaAttribute(targetNs, targetLocal)
            ?? throw new InvalidOperationException($"XPST0008: Schema attribute declaration Q{{{targetNs}}}{targetLocal} is not defined.");

        // XmlSchemaAttribute.SchemaType is null for type-referenced declarations; the
        // post-compilation AttributeSchemaType carries the effective type (REQ-105).
        var targetType = targetDecl.AttributeSchemaType ?? targetDecl.SchemaType;

        var nodeDeclName = node.SchemaAttributeDeclaration;
        if (nodeDeclName is null)
        {
            // No governing declaration (validated by named type only, e.g. a constructed
            // xsl:attribute with a type attribute): match by name and by type derivation
            // from the declared type (match-191).
            if (node.NamespaceUri != targetNs || node.LocalName != targetLocal)
                return false;
            return IsSchemaTypeCompatible(node.SchemaTypeAnnotation, targetType, context);
        }
        if (!IsSameQName(nodeDeclName.Value, targetNs, targetLocal))
            return false;

        // The annotation names the node's type; an anonymous type has no name, in which
        // case the governing declaration's own type is the annotation.
        var nodeDecl = context.GetSchemaAttribute(nodeDeclName.Value.NamespaceUri, nodeDeclName.Value.LocalName);
        var actualType = ResolveSchemaTypeAnnotation(context, node.SchemaTypeAnnotation)
            ?? nodeDecl?.AttributeSchemaType ?? nodeDecl?.SchemaType;
        return actualType is not null && targetType is not null
            && XmlSchemaType.IsDerivedFrom(actualType, targetType, XmlSchemaDerivationMethod.Empty);
    }

    private static bool IsSameQName((string NamespaceUri, string LocalName) qname, string ns, string local)
        => qname.NamespaceUri == ns && qname.LocalName == local;

    /// <summary>
    /// Returns true when the node's schema type annotation is the same as or derived from
    /// the supplied target schema type.
    /// </summary>
    private static bool IsSchemaTypeCompatible((string NamespaceUri, string LocalName)? typeAnnotation, XmlSchemaType? targetType, EvaluationContext context)
    {
        if (targetType is null)
            return true;
        if (typeAnnotation is not { } annotation)
            return false;
        if (IsSameQName(annotation, targetType.QualifiedName.Namespace, targetType.QualifiedName.Name))
            return true;
        var actualType = ResolveSchemaType(context, annotation.NamespaceUri, annotation.LocalName);
        if (actualType is null)
            return false;
        return XmlSchemaType.IsDerivedFrom(actualType, targetType, XmlSchemaDerivationMethod.Empty);
    }

    /// <summary>
    /// Resolves a node's schema type annotation to a type definition, returning
    /// <c>null</c> for absent or anonymous (unnamed) annotations.
    /// </summary>
    private static XmlSchemaType? ResolveSchemaTypeAnnotation(EvaluationContext context, (string NamespaceUri, string LocalName)? annotation)
        => annotation is { } a && a.LocalName.Length > 0
            ? ResolveSchemaType(context, a.NamespaceUri, a.LocalName)
            : null;

    /// <summary>
    /// Resolves a schema type by expanded name: user-defined types come from the in-scope
    /// compiled schema set; the built-in XML Schema types are not surfaced by
    /// <see cref="XmlSchemaSet.GlobalTypes"/> and are resolved from the System.Xml.Schema
    /// built-in type table instead.
    /// </summary>
    private static XmlSchemaType? ResolveSchemaType(EvaluationContext context, string namespaceUri, string localName)
    {
        if (context.GetSchemaType(namespaceUri, localName) is { } fromSet)
            return fromSet;
        if (namespaceUri != XmlSchema.Namespace)
            return null;
        var qualifiedName = new XmlQualifiedName(localName, namespaceUri);
        if (XmlSchemaType.GetBuiltInSimpleType(qualifiedName) is { } builtInSimple)
            return builtInSimple;
        if (XmlSchemaType.GetBuiltInComplexType(qualifiedName) is { } builtInComplex)
            return builtInComplex;
        // XPath type-hierarchy members that are not XSD 1.0 built-ins.
        return localName switch
        {
            "anyAtomicType" => XmlSchemaType.GetBuiltInSimpleType(XmlTypeCode.AnyAtomicType),
            "untypedAtomic" => XmlSchemaType.GetBuiltInSimpleType(XmlTypeCode.UntypedAtomic),
            "dayTimeDuration" => XmlSchemaType.GetBuiltInSimpleType(XmlTypeCode.DayTimeDuration),
            "yearMonthDuration" => XmlSchemaType.GetBuiltInSimpleType(XmlTypeCode.YearMonthDuration),
            _ => null,
        };
    }

    // ------------------------------------------------------------------
    // Arithmetic
    // ------------------------------------------------------------------

    private static bool IsEmptySequence(XdmValue value)
    {
        if (value.IsUndefined)
            return true;
        if (value.IsSequence && value.SequenceValue is not null)
        {
            foreach (var _ in XdmSequence.FromSource(value.SequenceValue))
                return false;
            return true;
        }
        return false;
    }

    /// <summary>
    /// Node-comparison variants shared by the <c>is</c>/<c>&lt;&lt;</c>/<c>&gt;&gt;</c> opcodes
    /// (via <see cref="EvaluateNodeComparison"/>) and the XPath 4.0 fn:op keyword forms
    /// <c>is-not</c>, <c>precedes</c>, <c>follows</c>, <c>precedes-or-is</c>, <c>follows-or-is</c>.
    /// </summary>
    internal enum NodeComparison
    {
        Is,
        IsNot,
        Precedes,
        Follows,
        PrecedesOrIs,
        FollowsOrIs,
    }

    /// <summary>
    /// Evaluates a node comparison over two operands. An empty operand yields the empty
    /// sequence; a non-node operand is XPTY0004. Document order decides precedes/follows,
    /// with identity accepted by the *-or-is variants.
    /// </summary>
    private static XdmValue EvaluateNodeComparison(NodeComparison comparison, XdmValue leftValue, XdmValue rightValue)
    {
        var left = UnwrapSingleton(leftValue);
        var right = UnwrapSingleton(rightValue);
        // Empty sequence operand -> empty sequence result
        if (left.IsUndefined || right.IsUndefined)
            return XdmValue.Undefined;
        if (!left.IsNode || !right.IsNode)
        {
            throw comparison is NodeComparison.Is or NodeComparison.IsNot
                ? new InvalidOperationException("XPTY0004: Node comparison operator 'is' requires single node operands.")
                : new InvalidOperationException("XPTY0004: Node comparison operators '<<' and '>>' require single node operands.");
        }

        bool same = left.NodeValue.IsSameNode(right.NodeValue);
        bool result = comparison switch
        {
            NodeComparison.Is => same,
            NodeComparison.IsNot => !same,
            NodeComparison.Precedes => !same && left.NodeValue.DocumentOrder < right.NodeValue.DocumentOrder,
            NodeComparison.Follows => !same && left.NodeValue.DocumentOrder > right.NodeValue.DocumentOrder,
            NodeComparison.PrecedesOrIs => same || left.NodeValue.DocumentOrder < right.NodeValue.DocumentOrder,
            NodeComparison.FollowsOrIs => same || left.NodeValue.DocumentOrder > right.NodeValue.DocumentOrder,
            _ => throw new InvalidOperationException($"XPTY0004: Unsupported node comparison {comparison}."),
        };
        return XdmValue.FromBoolean(result);
    }

    /// <summary>
    /// Union (<c>|</c>) of two node sequences: both operands must be node sequences (XPTY0004
    /// otherwise); the result is duplicate-free in document order.
    /// </summary>
    private static XdmValue UnionNodeSequences(XdmValue leftValue, XdmValue rightValue)
    {
        var left = MaterializeSequence(leftValue);
        var right = MaterializeSequence(rightValue);
        RequireNodeSequence(left);
        RequireNodeSequence(right);
        var combined = new List<XdmValue>(left.Length + right.Length);
        combined.AddRange(left);
        combined.AddRange(right);
        return NormalizeSequence(XdmValue.FromSequence(MaterializedSequence.FromList(combined)));
    }

    /// <summary>Intersection of two node sequences, in document order (see <see cref="UnionNodeSequences"/>).</summary>
    private static XdmValue IntersectNodeSequences(XdmValue leftValue, XdmValue rightValue)
    {
        var left = MaterializeSequence(leftValue);
        var right = MaterializeSequence(rightValue);
        RequireNodeSequence(left);
        RequireNodeSequence(right);
        var rightNodes = new List<IXdmNode>();
        foreach (var item in right)
            if (item.IsNode)
                rightNodes.Add(item.NodeValue);

        var result = new List<XdmValue>();
        foreach (var item in left)
        {
            if (!item.IsNode) continue;
            foreach (var rn in rightNodes)
            {
                if (rn.IsSameNode(item.NodeValue))
                {
                    result.Add(item);
                    break;
                }
            }
        }
        return NormalizeSequence(XdmValue.FromSequence(MaterializedSequence.FromList(result)));
    }

    /// <summary>Set difference of two node sequences, in document order (see <see cref="UnionNodeSequences"/>).</summary>
    private static XdmValue ExceptNodeSequences(XdmValue leftValue, XdmValue rightValue)
    {
        var left = MaterializeSequence(leftValue);
        var right = MaterializeSequence(rightValue);
        RequireNodeSequence(left);
        RequireNodeSequence(right);
        var rightNodes = new List<IXdmNode>();
        foreach (var item in right)
            if (item.IsNode)
                rightNodes.Add(item.NodeValue);

        var result = new List<XdmValue>();
        foreach (var item in left)
        {
            if (!item.IsNode) continue;
            bool inRight = false;
            foreach (var rn in rightNodes)
            {
                if (rn.IsSameNode(item.NodeValue))
                {
                    inRight = true;
                    break;
                }
            }
            if (!inRight)
                result.Add(item);
        }
        return NormalizeSequence(XdmValue.FromSequence(MaterializedSequence.FromList(result)));
    }

    /// <summary>Range (<c>to</c>) operator: both operands must be xs:integer (XPTY0004 otherwise).</summary>
    private static XdmValue EvaluateRange(XdmValue leftValue, XdmValue rightValue, EvaluationContext context)
    {
        var left = leftValue;
        var right = rightValue;

        // XPath 1.0 backwards compatibility: the operands of "to" are
        // converted to integers by taking the first item of a sequence.
        if (context.BackwardsCompatible)
        {
            left = FirstItemOrUndefined(left);
            right = FirstItemOrUndefined(right);
        }

        if (left.IsUndefined || IsEmptySeq(left) || right.IsUndefined || IsEmptySeq(right))
            return XdmValue.FromSequence(XdmSequence.Empty);
        if (context.BackwardsCompatible)
        {
            long from = ToInteger(left);
            long to = ToInteger(right);
            if (from > to)
                return XdmValue.FromSequence(XdmSequence.Empty);
            return XdmValue.FromSequence(XdmSequence.FromSource(new IntegerRangeSequence(from, to)));
        }

        left = Atomize(left);
        right = Atomize(right);
        if (IsEmptySequence(left) || IsEmptySequence(right))
            return XdmValue.FromSequence(XdmSequence.Empty);

        if (!TryGetRangeOperand(left, out var fromDecimal) || !TryGetRangeOperand(right, out var toDecimal))
            throw new InvalidOperationException("XPTY0004: The operands of 'to' must be xs:integer");

        if (fromDecimal > toDecimal)
            return XdmValue.FromSequence(XdmSequence.Empty);
        if (fromDecimal >= long.MinValue && fromDecimal <= long.MaxValue
            && toDecimal >= long.MinValue && toDecimal <= long.MaxValue)
        {
            return XdmValue.FromSequence(
                XdmSequence.FromSource(new IntegerRangeSequence((long)fromDecimal, (long)toDecimal)));
        }
        return XdmValue.FromSequence(
            XdmSequence.FromSource(new DecimalRangeSequence(fromDecimal, toDecimal)));
    }

    /// <summary>
    /// Applies one of the 31 binary operators exposed by XPath 4.0 fn:op (F&amp;O 4.0 §18.4) to
    /// two operand sequences. This is the single semantics source for the operator: the
    /// opcode dispatch above and the fn:op function item both route through here.
    /// </summary>
    /// <param name="operatorName">The operator name as accepted by fn:op (e.g. <c>"+"</c>, <c>"eq"</c>, <c>"union"</c>).</param>
    /// <param name="left">The left operand (<c>$x</c> in <c>$x ⊙ $y</c>).</param>
    /// <param name="right">The right operand (<c>$y</c> in <c>$x ⊙ $y</c>).</param>
    /// <param name="context">The evaluation context (collation, implicit timezone, backwards-compat mode).</param>
    /// <returns>The operator result; operators with empty-sequence propagation return the empty sequence.</returns>
    /// <exception cref="InvalidOperationException">XPTY0004: the operator name is not one of the 31 supported operators.</exception>
    public static XdmValue ApplyBinaryOperator(string operatorName, XdmValue left, XdmValue right, EvaluationContext context)
    {
        switch (operatorName)
        {
            case ",": // sequence concatenation: fn($x, $y) { $x, $y }
                if (IsEmptySequence(left))
                    return right;
                if (IsEmptySequence(right))
                    return left;
                var concatLeft = MaterializeSequence(left);
                var concatRight = MaterializeSequence(right);
                var concatenated = new List<XdmValue>(concatLeft.Length + concatRight.Length);
                concatenated.AddRange(concatLeft);
                concatenated.AddRange(concatRight);
                return XdmValue.FromSequence(MaterializedSequence.FromList(concatenated));

            case "and":
                return XdmValue.FromBoolean(left.GetEffectiveBooleanValue() && right.GetEffectiveBooleanValue());
            case "or":
                return XdmValue.FromBoolean(left.GetEffectiveBooleanValue() || right.GetEffectiveBooleanValue());
            case "otherwise": // XPath 4.0 §4.17: LHS unless empty, then RHS
                return IsEmptySequence(left) ? right : left;

            case "+":
                return Add(left, right, context);
            case "-":
                return Subtract(left, right, context);
            case "*":
                return Multiply(left, right, context);
            case "div":
                return Divide(left, right, context);
            case "idiv":
                return IntegerDivide(left, right, context);
            case "mod":
                return Modulo(left, right, context);

            case "=":
                return CompareGeneral(IrOpCode.GeneralEqual, left, right, context);
            case "<":
                return CompareGeneral(IrOpCode.GeneralLessThan, left, right, context);
            case "<=":
                return CompareGeneral(IrOpCode.GeneralLessThanOrEqual, left, right, context);
            case ">":
                return CompareGeneral(IrOpCode.GeneralGreaterThan, left, right, context);
            case ">=":
                return CompareGeneral(IrOpCode.GeneralGreaterThanOrEqual, left, right, context);
            case "!=":
                return CompareGeneral(IrOpCode.GeneralNotEqual, left, right, context);

            case "eq":
                return Compare(IrOpCode.ValueEqual, left, right, context);
            case "lt":
                return Compare(IrOpCode.ValueLessThan, left, right, context);
            case "le":
                return Compare(IrOpCode.ValueLessThanOrEqual, left, right, context);
            case "gt":
                return Compare(IrOpCode.ValueGreaterThan, left, right, context);
            case "ge":
                return Compare(IrOpCode.ValueGreaterThanOrEqual, left, right, context);
            case "ne":
                return Compare(IrOpCode.ValueNotEqual, left, right, context);

            case "is":
                return EvaluateNodeComparison(NodeComparison.Is, left, right);
            case "is-not":
                return EvaluateNodeComparison(NodeComparison.IsNot, left, right);
            case "<<":
            case "precedes":
                return EvaluateNodeComparison(NodeComparison.Precedes, left, right);
            case ">>":
            case "follows":
                return EvaluateNodeComparison(NodeComparison.Follows, left, right);
            case "precedes-or-is":
                return EvaluateNodeComparison(NodeComparison.PrecedesOrIs, left, right);
            case "follows-or-is":
                return EvaluateNodeComparison(NodeComparison.FollowsOrIs, left, right);

            case "||":
                return XdmValue.FromString(AtomizedStringValue(left) + AtomizedStringValue(right));

            case "|":
            case "union":
                return UnionNodeSequences(left, right);
            case "intersect":
                return IntersectNodeSequences(left, right);
            case "except":
                return ExceptNodeSequences(left, right);

            case "to":
                return EvaluateRange(left, right, context);

            default:
                throw new InvalidOperationException(
                    $"XPTY0004: fn:op: '{operatorName}' is not one of the supported binary operators.");
        }
    }

    private static XdmValue Add(XdmValue left, XdmValue right, EvaluationContext context)
    {
        if (IsEmptySequence(left) || IsEmptySequence(right))
        {
            if (context.BackwardsCompatible)
                return XdmValue.FromDouble(double.NaN);
            return XdmValue.Undefined;
        }

        // XPath 1.0 backwards compatibility: arithmetic always returns an xs:double.
        if (context.BackwardsCompatible)
            return XdmValue.FromDouble(ToDoubleOrNaN(left) + ToDoubleOrNaN(right));

        // Date/Time + Duration
        if ((left.Kind is XdmValueKind.DateTime or XdmValueKind.Date or XdmValueKind.Time) && (right.Kind == XdmValueKind.String || right.Kind == XdmValueKind.Duration))
        {
            RequireProperDurationSubtype(right);
            return AddDuration(left, right.ToString());
        }
        if ((right.Kind is XdmValueKind.DateTime or XdmValueKind.Date or XdmValueKind.Time) && (left.Kind == XdmValueKind.String || left.Kind == XdmValueKind.Duration))
        {
            RequireProperDurationSubtype(left);
            return AddDuration(right, left.ToString());
        }

        // Duration + Duration
        if (left.Kind == XdmValueKind.Duration && right.Kind == XdmValueKind.Duration)
        {
            RequireProperDurationSubtype(left);
            RequireProperDurationSubtype(right);
            return AddDurations(left, right);
        }

        ValidateNumericOperand(left);
        ValidateNumericOperand(right);

        left = Atomize(left);
        right = Atomize(right);
        if (IsEmptySequence(left) || IsEmptySequence(right))
            return XdmValue.Undefined;
        if (IsUntypedAtomic(left) || IsUntypedAtomic(right))
            return XdmValue.FromDouble(ToDouble(left) + ToDouble(right));

        if (IsDouble(left) || IsDouble(right))
            return XdmValue.FromDouble(ToDouble(left) + ToDouble(right));
        if (IsFloat(left) || IsFloat(right))
            return XdmValue.FromFloat(ToFloat(left) + ToFloat(right));
        if (IsDecimal(left) || IsDecimal(right))
            return DecimalArithmeticResult(ToDecimal(left) + ToDecimal(right), left, right);

        return IntegerArithmetic(ToInteger(left), ToInteger(right), '+');
    }

    // A duration operand in date/time arithmetic must be an xs:dayTimeDuration or
    // xs:yearMonthDuration — a plain xs:duration is a type error (cbcl-plus/minus-*).
    private static void RequireProperDurationSubtype(XdmValue value)
    {
        if (value.Kind == XdmValueKind.Duration && GetDurationSubtype(value) == DurationSubtype.Duration)
            throw new InvalidOperationException("XPTY0004: A plain xs:duration value is not allowed in date/time arithmetic (xs:dayTimeDuration or xs:yearMonthDuration required).");
    }

    private static XdmValue AddDuration(XdmValue dateTimeValue, string duration)
    {
        bool hasTz = dateTimeValue.HasTimezone;
        var xdt = dateTimeValue.Kind switch
        {
            XdmValueKind.DateTime => dateTimeValue.DateTimeXPathValue,
            XdmValueKind.Date => dateTimeValue.DateXPathValue,
            XdmValueKind.Time => dateTimeValue.TimeXPathValue,
            _ => throw new InvalidOperationException("Expected date/time value")
        };
        int tzMinutes = xdt.TimezoneOffsetMinutes;
        bool isTime = dateTimeValue.Kind == XdmValueKind.Time;

        XPathDateTime result;
        if (IsYearMonthDurationString(duration))
        {
            if (isTime)
                throw new InvalidOperationException("XPTY0004: xs:time values do not support year-month duration arithmetic");

            var (years, months, _, _, _, _) = ParseDuration(duration);
            var (ny, nm, nd) = XPathDateTimeHelper.AddMonths(xdt.Year, xdt.Month, xdt.Day, years * 12 + months);
            result = new XPathDateTime(ny, nm, nd, xdt.Hour, xdt.Minute, xdt.Second, xdt.Millisecond, tzMinutes, hasTz);
        }
        else if (IsDayTimeDurationString(duration))
        {
            result = AddDayTimeDuration(xdt, duration, isTime, tzMinutes, hasTz);
            if (dateTimeValue.Kind == XdmValueKind.Date)
                result = new XPathDateTime(result.Year, result.Month, result.Day, 0, 0, 0, 0, tzMinutes, hasTz);
        }
        else
        {
            throw new InvalidOperationException("Invalid duration format");
        }

        return dateTimeValue.Kind switch
        {
            XdmValueKind.DateTime => XdmValue.FromDateTime(result, hasTz),
            XdmValueKind.Date => XdmValue.FromDate(result, hasTz),
            XdmValueKind.Time => XdmValue.FromTime(result, hasTz),
            _ => throw new InvalidOperationException("Unexpected kind")
        };
    }

    private static XPathDateTime AddDayTimeDuration(XPathDateTime xdt, string duration, bool isTime, int tzMinutes, bool hasTz)
    {
        var (_, _, days, hours, minutes, seconds) = ParseDuration(duration);
        long deltaMs = ((days * 24L + hours) * 3600L + minutes * 60L) * 1000L + (long)(seconds * 1000m);
        long msOfDay = (xdt.Hour * 3600L + xdt.Minute * 60L + xdt.Second) * 1000L + xdt.Millisecond;
        if (isTime)
        {
            long totalMs = (msOfDay + deltaMs) % 86400000L;
            if (totalMs < 0) totalMs += 86400000L;
            return MsToTime(totalMs, tzMinutes, hasTz);
        }
        long totalMsFull = msOfDay + deltaMs;
        long dayOffset = totalMsFull / 86400000L;
        long newMsOfDay = totalMsFull % 86400000L;
        if (newMsOfDay < 0) { newMsOfDay += 86400000L; dayOffset--; }
        var (ny, nm, nd) = XPathDateTimeHelper.CivilFromDays(XPathDateTimeHelper.DaysFromCivil(xdt.Year, xdt.Month, xdt.Day) + dayOffset);
        return MsToDateTime(ny, nm, nd, newMsOfDay, tzMinutes, hasTz);
    }

    private static XPathDateTime MsToTime(long totalMs, int tzMinutes, bool hasTz)
    {
        int hour = (int)(totalMs / 3600000L); totalMs %= 3600000L;
        int minute = (int)(totalMs / 60000L); totalMs %= 60000L;
        int second = (int)(totalMs / 1000L);
        int ms = (int)(totalMs % 1000L);
        return new XPathDateTime(1, 1, 1, hour, minute, second, ms, tzMinutes, hasTz);
    }

    private static XPathDateTime MsToDateTime(long year, int month, int day, long totalMs, int tzMinutes, bool hasTz)
    {
        int hour = (int)(totalMs / 3600000L); totalMs %= 3600000L;
        int minute = (int)(totalMs / 60000L); totalMs %= 60000L;
        int second = (int)(totalMs / 1000L);
        int ms = (int)(totalMs % 1000L);
        return new XPathDateTime(year, month, day, hour, minute, second, ms, tzMinutes, hasTz);
    }

    private static XdmValue Subtract(XdmValue left, XdmValue right, EvaluationContext context)
    {
        if (IsEmptySequence(left) || IsEmptySequence(right))
        {
            if (context.BackwardsCompatible)
                return XdmValue.FromDouble(double.NaN);
            return XdmValue.Undefined;
        }

        // XPath 1.0 backwards compatibility: arithmetic always returns an xs:double.
        if (context.BackwardsCompatible)
            return XdmValue.FromDouble(ToDoubleOrNaN(left) - ToDoubleOrNaN(right));

        if (left.Kind == XdmValueKind.Date && right.Kind == XdmValueKind.Date)
            return XdmValue.FromDuration(FormatDurationFromDateTimeDiff(left.DateXPathValue, right.DateXPathValue));
        if (left.Kind == XdmValueKind.DateTime && right.Kind == XdmValueKind.DateTime)
            return XdmValue.FromDuration(FormatDurationFromDateTimeDiff(left.DateTimeXPathValue, right.DateTimeXPathValue));
        if (left.Kind == XdmValueKind.Time && right.Kind == XdmValueKind.Time)
        {
            var leftDt = left.TimeXPathValue;
            var rightDt = right.TimeXPathValue;
            var leftRef = new XPathDateTime(1972, 12, 31, leftDt.Hour, leftDt.Minute, leftDt.Second, leftDt.Millisecond, leftDt.TimezoneOffsetMinutes, left.HasTimezone);
            var rightRef = new XPathDateTime(1972, 12, 31, rightDt.Hour, rightDt.Minute, rightDt.Second, rightDt.Millisecond, rightDt.TimezoneOffsetMinutes, right.HasTimezone);
            return XdmValue.FromDuration(FormatDurationFromDateTimeDiff(leftRef, rightRef));
        }
        if (left.Kind is XdmValueKind.DateTime or XdmValueKind.Date or XdmValueKind.Time && (right.Kind == XdmValueKind.String || right.Kind == XdmValueKind.Duration))
        {
            RequireProperDurationSubtype(right);
            return SubtractDuration(left, right.ToString());
        }

        // Duration - Duration
        if (left.Kind == XdmValueKind.Duration && right.Kind == XdmValueKind.Duration)
        {
            RequireProperDurationSubtype(left);
            RequireProperDurationSubtype(right);
            return SubtractDurations(left, right);
        }

        ValidateNumericOperand(left);
        ValidateNumericOperand(right);

        left = Atomize(left);
        right = Atomize(right);
        if (IsEmptySequence(left) || IsEmptySequence(right))
            return XdmValue.Undefined;
        if (IsUntypedAtomic(left) || IsUntypedAtomic(right))
            return XdmValue.FromDouble(ToDouble(left) - ToDouble(right));

        if (IsDouble(left) || IsDouble(right))
            return XdmValue.FromDouble(ToDouble(left) - ToDouble(right));
        if (IsFloat(left) || IsFloat(right))
            return XdmValue.FromFloat(ToFloat(left) - ToFloat(right));
        if (IsDecimal(left) || IsDecimal(right))
            return DecimalArithmeticResult(ToDecimal(left) - ToDecimal(right), left, right);

        return IntegerArithmetic(ToInteger(left), ToInteger(right), '-');
    }

    private static string FormatDurationFromDateTimeDiff(XPathDateTime left, XPathDateTime right)
    {
        var ul = XPathDateTimeHelper.NormalizeToUtc(left);
        var ur = XPathDateTimeHelper.NormalizeToUtc(right);
        decimal msL = (decimal)XPathDateTimeHelper.DaysFromCivil(ul.Year, ul.Month, ul.Day) * 86400000m
            + ((ul.Hour * 3600m + ul.Minute * 60m + ul.Second) * 1000m + ul.Millisecond);
        decimal msR = (decimal)XPathDateTimeHelper.DaysFromCivil(ur.Year, ur.Month, ur.Day) * 86400000m
            + ((ur.Hour * 3600m + ur.Minute * 60m + ur.Second) * 1000m + ur.Millisecond);
        return FormatDurationFromMilliseconds(msL - msR);
    }

    private static XdmValue SubtractDuration(XdmValue dateTimeValue, string duration)
    {
        bool hasTz = dateTimeValue.HasTimezone;
        var xdt = dateTimeValue.Kind switch
        {
            XdmValueKind.DateTime => dateTimeValue.DateTimeXPathValue,
            XdmValueKind.Date => dateTimeValue.DateXPathValue,
            XdmValueKind.Time => dateTimeValue.TimeXPathValue,
            _ => throw new InvalidOperationException("Expected date/time value")
        };
        int tzMinutes = xdt.TimezoneOffsetMinutes;
        bool isTime = dateTimeValue.Kind == XdmValueKind.Time;

        XPathDateTime result;
        if (IsYearMonthDurationString(duration))
        {
            if (isTime)
                throw new InvalidOperationException("XPTY0004: xs:time values do not support year-month duration arithmetic");

            var (years, months, _, _, _, _) = ParseDuration(duration);
            var (ny, nm, nd) = XPathDateTimeHelper.AddMonths(xdt.Year, xdt.Month, xdt.Day, -(years * 12 + months));
            result = new XPathDateTime(ny, nm, nd, xdt.Hour, xdt.Minute, xdt.Second, xdt.Millisecond, tzMinutes, hasTz);
        }
        else if (IsDayTimeDurationString(duration))
        {
            var (_, _, days, hours, minutes, seconds) = ParseDuration(duration);
            long deltaMs = ((days * 24L + hours) * 3600L + minutes * 60L) * 1000L + (long)(seconds * 1000m);
            result = AddDayTimeDuration(xdt, $"-P{days}DT{hours}H{minutes}M{seconds}S", isTime, tzMinutes, hasTz);
            if (dateTimeValue.Kind == XdmValueKind.Date)
                result = new XPathDateTime(result.Year, result.Month, result.Day, 0, 0, 0, 0, tzMinutes, hasTz);
        }
        else
        {
            throw new InvalidOperationException("Invalid duration format");
        }

        return dateTimeValue.Kind switch
        {
            XdmValueKind.DateTime => XdmValue.FromDateTime(result, hasTz),
            XdmValueKind.Date => XdmValue.FromDate(result, hasTz),
            XdmValueKind.Time => XdmValue.FromTime(result, hasTz),
            _ => throw new InvalidOperationException("Unexpected kind")
        };
    }

    private static string FormatDuration(TimeSpan ts) => FormatDurationFromMilliseconds((decimal)ts.TotalMilliseconds);

    private static string FormatDurationFromMilliseconds(decimal totalMs)
    {
        if (totalMs == 0) return "PT0S";
        bool negative = totalMs < 0;
        decimal remaining = negative ? -totalMs : totalMs;
        long days = (long)(remaining / 86400000m);
        remaining -= (decimal)days * 86400000m;
        int hours = (int)(remaining / 3600000m);
        remaining -= hours * 3600000m;
        int minutes = (int)(remaining / 60000m);
        remaining -= minutes * 60000m;
        int seconds = (int)(remaining / 1000m);
        decimal frac = remaining - seconds * 1000m;
        decimal sec = seconds + frac / 1000m;
        return FormatDayTimeDurationParts(negative, days, hours, minutes, sec);
    }

    private static string FormatDayTimeDurationParts(bool negative, long days, int hours, int minutes, decimal seconds)
    {
        var sb = new System.Text.StringBuilder();
        if (negative) sb.Append('-');
        sb.Append('P');
        if (days > 0) sb.Append(days).Append('D');
        if (hours > 0 || minutes > 0 || seconds > 0)
        {
            sb.Append('T');
            if (hours > 0) sb.Append(hours).Append('H');
            if (minutes > 0) sb.Append(minutes).Append('M');
            if (seconds > 0 || (hours == 0 && minutes == 0))
            {
                sb.Append(FormatDecimalTrim(seconds)).Append('S');
            }
        }
        if (sb.Length == (negative ? 2 : 1)) sb.Append("T0S");
        return sb.ToString();
    }

    private static string FormatDecimalTrim(decimal value)
    {
        string s = value.ToString(System.Globalization.CultureInfo.InvariantCulture);
        if (s.Contains('.')) s = s.TrimEnd('0').TrimEnd('.');
        return s;
    }

    private static (long Years, long Months, long Days, long Hours, long Minutes, decimal Seconds) ParseDuration(string s)
    {
        bool negative = s.StartsWith('-');
        s = negative ? s[1..] : s;
        if (!s.StartsWith('P')) return (0, 0, 0, 0, 0, 0m);
        s = s[1..];

        long years = 0, months = 0, days = 0, hours = 0, minutes = 0;
        decimal seconds = 0m;

        int tIndex = s.IndexOf('T');
        string datePart = tIndex >= 0 ? s[..tIndex] : s;
        string timePart = tIndex >= 0 ? s[(tIndex + 1)..] : string.Empty;

        years = ParseDurationNumber(ref datePart, 'Y');
        months = ParseDurationNumber(ref datePart, 'M');
        days = ParseDurationNumber(ref datePart, 'D');

        hours = ParseDurationNumber(ref timePart, 'H');
        minutes = ParseDurationNumber(ref timePart, 'M');
        seconds = ParseDurationDecimal(ref timePart, 'S');

        if (negative)
        {
            years = -years;
            months = -months;
            days = -days;
            hours = -hours;
            minutes = -minutes;
            seconds = -seconds;
        }

        return (years, months, days, hours, minutes, seconds);
    }

    private static long ParseDurationNumber(ref string s, char suffix)
    {
        int idx = s.IndexOf(suffix);
        if (idx < 0) return 0;
        var numStr = s[..idx];
        s = s[(idx + 1)..];
        return long.TryParse(numStr, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var v) ? v : 0;
    }

    private static decimal ParseDurationDecimal(ref string s, char suffix)
    {
        int idx = s.IndexOf(suffix);
        if (idx < 0) return 0m;
        var numStr = s[..idx];
        s = s[(idx + 1)..];
        return decimal.TryParse(numStr, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var v) ? v : 0m;
    }

    private static bool IsYearMonthDurationString(string s)
    {
        if (string.IsNullOrEmpty(s)) return false;
        if (s.StartsWith('-')) s = s[1..];
        return s.StartsWith('P') && !s.Contains('D') && !s.Contains('T');
    }

    private static bool IsDayTimeDurationString(string s)
    {
        if (string.IsNullOrEmpty(s)) return false;
        if (s.StartsWith('-')) s = s[1..];
        return s.StartsWith('P') && (s.Contains('D') || s.Contains('T'));
    }

    private static long RoundHalfUp(decimal value)
    {
        return (long)Math.Floor(value + 0.5m);
    }

    /// <summary>
    /// The dynamic subtype of an <c>xs:duration</c> value, decided by its schema
    /// annotation (or its components when unannotated). Plain <c>xs:duration</c>
    /// is unordered; the year-month and day-time subtypes are orderable.
    /// </summary>
    public enum DurationSubtype
    {
        /// <summary>An <c>xs:yearMonthDuration</c> value (orderable by total months).</summary>
        YearMonthDuration,
        /// <summary>An <c>xs:dayTimeDuration</c> value (orderable by total seconds).</summary>
        DayTimeDuration,
        /// <summary>A plain <c>xs:duration</c> value (not orderable).</summary>
        Duration,
    }

    private static DurationSubtype GetDurationSubtype(string s)
    {
        var m = DurationPartsRegex.Match(s);
        if (!m.Success) return DurationSubtype.Duration;
        bool hasYm = m.Groups["Y"].Success || m.Groups["M"].Success;
        bool hasDt = m.Groups["D"].Success || m.Groups["T"].Success;
        if (hasYm && !hasDt) return DurationSubtype.YearMonthDuration;
        if (!hasYm && hasDt) return DurationSubtype.DayTimeDuration;
        return DurationSubtype.Duration;
    }

    /// <summary>
    /// Returns the dynamic duration subtype of a value: <see cref="DurationSubtype.YearMonthDuration"/>,
    /// <see cref="DurationSubtype.DayTimeDuration"/>, or the unordered plain
    /// <see cref="DurationSubtype.Duration"/>, decided by the schema annotation first.
    /// </summary>
    /// <param name="value">The duration value to classify.</param>
    /// <returns>The duration subtype.</returns>
    public static DurationSubtype GetDurationSubtype(XdmValue value)
    {
        var schemaType = value.SchemaTypeName;
        if (schemaType is not null)
        {
            var normalized = schemaType.ToLowerInvariant().Replace("xs:", "");
            if (normalized == "yearmonthduration") return DurationSubtype.YearMonthDuration;
            if (normalized == "daytimeduration") return DurationSubtype.DayTimeDuration;
            if (normalized == "duration") return DurationSubtype.Duration;
        }
        return GetDurationSubtype(value.DurationValue);
    }

    /// <summary>
    /// Returns the date/time subtype name (<c>dateTime</c>, <c>date</c>, <c>time</c>,
    /// <c>gYear</c>, <c>gYearMonth</c>, <c>gMonth</c>, <c>gMonthDay</c>, <c>gDay</c>)
    /// of a value, or <c>null</c> when the value is not a date/time value.
    /// </summary>
    /// <param name="value">The value to classify.</param>
    /// <returns>The subtype name, or <c>null</c>.</returns>
    public static string? GetDateTimeSubtype(XdmValue value)
    {
        return value.Kind switch
        {
            XdmValueKind.DateTime => "dateTime",
            XdmValueKind.Date => "date",
            XdmValueKind.Time => "time",
            XdmValueKind.String => value.SchemaTypeName?.ToLowerInvariant() switch
            {
                "gyear" => "gYear",
                "gyearmonth" => "gYearMonth",
                "gmonth" => "gMonth",
                "gmonthday" => "gMonthDay",
                "gday" => "gDay",
                _ => null
            },
            _ => null
        };
    }

    /// <summary>
    /// Compares two date/time values of the same subtype on the timeline.
    /// A value without a timezone is treated as having the supplied implicit timezone.
    /// Returns null when the comparison is indeterminate.
    /// </summary>
    /// <param name="left">The left-hand date/time value.</param>
    /// <param name="right">The right-hand date/time value.</param>
    /// <param name="subtype">The shared subtype name (e.g. <c>dateTime</c>, <c>date</c>, <c>time</c>).</param>
    /// <param name="implicitTz">The implicit timezone offset in minutes for values without a timezone.</param>
    /// <returns>A negative value, zero, or a positive value, or <c>null</c> when indeterminate.</returns>
    public static int? CompareDateTimeValues(XdmValue left, XdmValue right, string subtype, int implicitTz)
    {
        var leftXdt = AsComparableDateTime(GetXPathDateTime(left, subtype), subtype);
        var rightXdt = AsComparableDateTime(GetXPathDateTime(right, subtype), subtype);

        bool leftHasTz = GetHasTimezone(left, subtype);
        bool rightHasTz = GetHasTimezone(right, subtype);

        // Neither has timezone: compare local components directly
        if (!leftHasTz && !rightHasTz)
        {
            return XPathDateTimeHelper.CompareComponents(leftXdt, rightXdt);
        }

        var leftEffective = leftHasTz
            ? leftXdt
            : new XPathDateTime(leftXdt.Year, leftXdt.Month, leftXdt.Day,
                leftXdt.Hour, leftXdt.Minute, leftXdt.Second, leftXdt.Millisecond,
                implicitTz, true);
        var rightEffective = rightHasTz
            ? rightXdt
            : new XPathDateTime(rightXdt.Year, rightXdt.Month, rightXdt.Day,
                rightXdt.Hour, rightXdt.Minute, rightXdt.Second, rightXdt.Millisecond,
                implicitTz, true);

        var leftUtc = XPathDateTimeHelper.NormalizeToUtc(leftEffective);
        var rightUtc = XPathDateTimeHelper.NormalizeToUtc(rightEffective);
        return XPathDateTimeHelper.CompareComponents(leftUtc, rightUtc);
    }

    private static int GetImplicitTimezoneOffsetMinutes(EvaluationContext context)
        => context.ImplicitTimezoneOffsetMinutes;

    private static XPathDateTime AsComparableDateTime(XPathDateTime xdt, string subtype)
    {
        if (subtype == "time")
        {
            // xs:time comparisons use the reference date 1972-12-31 (per XPath spec).
            return new XPathDateTime(1972, 12, 31, xdt.Hour, xdt.Minute, xdt.Second, xdt.Millisecond, xdt.TimezoneOffsetMinutes, xdt.HasTimezone);
        }
        if (subtype is "gYear" or "gYearMonth" or "gMonth" or "gMonthDay" or "gDay")
        {
            // ParseGDateTime already applies the correct reference components for each subtype.
            return xdt;
        }
        return xdt;
    }

    private static XPathDateTime GetXPathDateTime(XdmValue value, string subtype)
    {
        return subtype switch
        {
            "dateTime" => value.DateTimeXPathValue,
            "date" => value.DateXPathValue,
            "time" => value.TimeXPathValue,
            "gYear" or "gYearMonth" or "gMonth" or "gMonthDay" or "gDay" => ParseGDateTime(value.ToString(), subtype).Xdt,
            _ => throw new InvalidOperationException($"Unsupported date/time subtype: {subtype}")
        };
    }

    private static bool GetHasTimezone(XdmValue value, string subtype)
    {
        return subtype switch
        {
            "dateTime" => value.HasTimezone,
            "date" => value.HasTimezone,
            "time" => value.HasTimezone,
            "gYear" or "gYearMonth" or "gMonth" or "gMonthDay" or "gDay" => ParseGDateTime(value.ToString(), subtype).HasTz,
            _ => throw new InvalidOperationException($"Unsupported date/time subtype: {subtype}")
        };
    }

    private static (XPathDateTime Xdt, bool HasTz) ParseGDateTime(string s, string subtype)
    {
        int year = 1972, month = 1, day = 1;
        int tz = 0;
        bool hasTz = false;

        s = s.Trim();
        string tzStr = "";

        switch (subtype)
        {
            case "gYear":
                var gYearMatch = Regex.Match(s, @"^(-?\d{4,})((?:[Zz]|[+\-]\d{2}:\d{2})?)$");
                if (gYearMatch.Success)
                {
                    year = int.Parse(gYearMatch.Groups[1].Value, CultureInfo.InvariantCulture);
                    tzStr = NormalizeTimezone(gYearMatch.Groups[2].Value) ?? "";
                }
                break;
            case "gYearMonth":
                var gYearMonthMatch = Regex.Match(s, @"^(-?\d{4,})-(\d{2})((?:[Zz]|[+\-]\d{2}:\d{2})?)$");
                if (gYearMonthMatch.Success)
                {
                    year = int.Parse(gYearMonthMatch.Groups[1].Value, CultureInfo.InvariantCulture);
                    month = int.Parse(gYearMonthMatch.Groups[2].Value, CultureInfo.InvariantCulture);
                    tzStr = NormalizeTimezone(gYearMonthMatch.Groups[3].Value) ?? "";
                }
                break;
            case "gMonth":
                var gMonthMatch = Regex.Match(s, @"^--(\d{2})((?:[Zz]|[+\-]\d{2}:\d{2})?)$");
                if (gMonthMatch.Success)
                {
                    month = int.Parse(gMonthMatch.Groups[1].Value, CultureInfo.InvariantCulture);
                    tzStr = NormalizeTimezone(gMonthMatch.Groups[2].Value) ?? "";
                }
                break;
            case "gMonthDay":
                var gMonthDayMatch = Regex.Match(s, @"^--(\d{2})-(\d{2})((?:[Zz]|[+\-]\d{2}:\d{2})?)$");
                if (gMonthDayMatch.Success)
                {
                    month = int.Parse(gMonthDayMatch.Groups[1].Value, CultureInfo.InvariantCulture);
                    day = int.Parse(gMonthDayMatch.Groups[2].Value, CultureInfo.InvariantCulture);
                    tzStr = NormalizeTimezone(gMonthDayMatch.Groups[3].Value) ?? "";
                }
                break;
            case "gDay":
                var gDayMatch = Regex.Match(s, @"^---(\d{2})((?:[Zz]|[+\-]\d{2}:\d{2})?)$");
                if (gDayMatch.Success)
                {
                    day = int.Parse(gDayMatch.Groups[1].Value, CultureInfo.InvariantCulture);
                    tzStr = NormalizeTimezone(gDayMatch.Groups[2].Value) ?? "";
                }
                break;
        }

        hasTz = !string.IsNullOrEmpty(tzStr);
        if (hasTz)
            tz = tzStr == "Z" ? 0 : ParseTimezoneOffset(tzStr);

        return (new XPathDateTime(year, month, day, 0, 0, 0, 0, tz, hasTz), hasTz);
    }

    /// <summary>
    /// Normalizes a duration lexical form to its total months and total seconds,
    /// the canonical ordering components for duration values.
    /// </summary>
    /// <param name="s">The duration lexical form.</param>
    /// <returns>The total months and total seconds.</returns>
    public static (long TotalMonths, decimal TotalSeconds) NormalizeDuration(string s)
    {
        var m = DurationPartsRegex.Match(s);
        if (!m.Success) return (0, 0);
        bool negative = m.Groups["sign"].Value == "-";

        long years = m.Groups["Y"].Success ? long.Parse(m.Groups["Y"].Value.TrimEnd('Y'), CultureInfo.InvariantCulture) : 0;
        long months = m.Groups["M"].Success ? long.Parse(m.Groups["M"].Value.TrimEnd('M'), CultureInfo.InvariantCulture) : 0;
        long days = m.Groups["D"].Success ? long.Parse(m.Groups["D"].Value.TrimEnd('D'), CultureInfo.InvariantCulture) : 0;
        long hours = m.Groups["H"].Success ? long.Parse(m.Groups["H"].Value.TrimEnd('H'), CultureInfo.InvariantCulture) : 0;
        long minutes = m.Groups["Tm"].Success ? long.Parse(m.Groups["Tm"].Value.TrimEnd('M'), CultureInfo.InvariantCulture) : 0;
        decimal seconds = m.Groups["S"].Success ? decimal.Parse(m.Groups["S"].Value.TrimEnd('S'), CultureInfo.InvariantCulture) : 0;

        long totalMonths = years * 12 + months;
        decimal totalSeconds = days * 86400m + hours * 3600m + minutes * 60m + seconds;

        if (negative)
        {
            totalMonths = -totalMonths;
            totalSeconds = -totalSeconds;
        }

        return (totalMonths, totalSeconds);
    }

    /// <summary>
    /// Splits a duration lexical form into its un-normalized component tuple
    /// (total months, days, time-in-seconds) for XPath 4.0 fn:compare ordering.
    /// </summary>
    /// <param name="s">The duration lexical form.</param>
    /// <returns>The (months, days, seconds) component tuple.</returns>
    private static (long Months, long Days, decimal Seconds) DurationComponents(string s)
    {
        var m = DurationPartsRegex.Match(s);
        if (!m.Success) return (0, 0, 0);
        bool negative = m.Groups["sign"].Value == "-";

        long years = m.Groups["Y"].Success ? long.Parse(m.Groups["Y"].Value.TrimEnd('Y'), CultureInfo.InvariantCulture) : 0;
        long months = m.Groups["M"].Success ? long.Parse(m.Groups["M"].Value.TrimEnd('M'), CultureInfo.InvariantCulture) : 0;
        long days = m.Groups["D"].Success ? long.Parse(m.Groups["D"].Value.TrimEnd('D'), CultureInfo.InvariantCulture) : 0;
        long hours = m.Groups["H"].Success ? long.Parse(m.Groups["H"].Value.TrimEnd('H'), CultureInfo.InvariantCulture) : 0;
        long minutes = m.Groups["Tm"].Success ? long.Parse(m.Groups["Tm"].Value.TrimEnd('M'), CultureInfo.InvariantCulture) : 0;
        decimal seconds = m.Groups["S"].Success ? decimal.Parse(m.Groups["S"].Value.TrimEnd('S'), CultureInfo.InvariantCulture) : 0;

        long totalMonths = years * 12 + months;
        decimal totalSeconds = hours * 3600m + minutes * 60m + seconds;

        if (negative)
        {
            totalMonths = -totalMonths;
            days = -days;
            totalSeconds = -totalSeconds;
        }

        return (totalMonths, days, totalSeconds);
    }

    private static XdmValue AddDurations(XdmValue left, XdmValue right)
    {
        var l = left.DurationValue;
        var r = right.DurationValue;
        if (IsYearMonthDurationString(l) && IsYearMonthDurationString(r))
        {
            var (y1, m1, _, _, _, _) = ParseDuration(l);
            var (y2, m2, _, _, _, _) = ParseDuration(r);
            long totalMonths = y1 * 12 + m1 + y2 * 12 + m2;
            return XdmValue.FromDuration(FormatYearMonthDuration(totalMonths));
        }
        if (IsDayTimeDurationString(l) && IsDayTimeDurationString(r))
        {
            var (_, _, d1, h1, min1, s1) = ParseDuration(l);
            var (_, _, d2, h2, min2, s2) = ParseDuration(r);
            long totalTicks = (d1 + d2) * TimeSpan.TicksPerDay
                + (h1 + h2) * TimeSpan.TicksPerHour
                + (min1 + min2) * TimeSpan.TicksPerMinute
                + (long)((s1 + s2) * TimeSpan.TicksPerSecond);
            return XdmValue.FromDuration(FormatDuration(new TimeSpan(totalTicks)));
        }
        throw new InvalidOperationException("XPTY0004");
    }

    private static XdmValue SubtractDurations(XdmValue left, XdmValue right)
    {
        var l = left.DurationValue;
        var r = right.DurationValue;
        if (IsYearMonthDurationString(l) && IsYearMonthDurationString(r))
        {
            var (y1, m1, _, _, _, _) = ParseDuration(l);
            var (y2, m2, _, _, _, _) = ParseDuration(r);
            long totalMonths = y1 * 12 + m1 - (y2 * 12 + m2);
            return XdmValue.FromDuration(FormatYearMonthDuration(totalMonths));
        }
        if (IsDayTimeDurationString(l) && IsDayTimeDurationString(r))
        {
            var (_, _, d1, h1, min1, s1) = ParseDuration(l);
            var (_, _, d2, h2, min2, s2) = ParseDuration(r);
            long totalTicks = (d1 - d2) * TimeSpan.TicksPerDay
                + (h1 - h2) * TimeSpan.TicksPerHour
                + (min1 - min2) * TimeSpan.TicksPerMinute
                + (long)((s1 - s2) * TimeSpan.TicksPerSecond);
            return XdmValue.FromDuration(FormatDuration(new TimeSpan(totalTicks)));
        }
        throw new InvalidOperationException("XPTY0004");
    }

    private static XdmValue MultiplyDuration(XdmValue duration, XdmValue factor)
    {
        double f = ToDouble(factor);
        // op:multiply-yearMonthDuration/dayTimeDuration: a NaN factor is FOCA0005;
        // an infinite factor overflows the duration range (FODT0002).
        if (double.IsNaN(f))
            throw new InvalidOperationException("FOCA0005: Cannot multiply a duration by NaN.");
        if (double.IsInfinity(f))
            throw new InvalidOperationException("FODT0002: Cannot multiply a duration by an infinite factor.");

        var subtype = GetDurationSubtype(duration);
        if (subtype == DurationSubtype.YearMonthDuration)
        {
            var d = duration.DurationValue;
            var (y, m, _, _, _, _) = ParseDuration(d);
            decimal baseMonths = y * 12m + m;
            if (baseMonths == 0m)
                return XdmValue.FromDuration("P0M");
            decimal totalMonths = baseMonths * (decimal)f;
            long roundedMonths;
            try
            {
                roundedMonths = RoundHalfUp(totalMonths);
            }
            catch (OverflowException)
            {
                throw new InvalidOperationException("FODT0002");
            }
            return XdmValue.FromDuration(FormatYearMonthDuration(roundedMonths));
        }
        if (subtype == DurationSubtype.DayTimeDuration)
        {
            var d = duration.DurationValue;
            var (_, _, days, hours, minutes, seconds) = ParseDuration(d);
            decimal totalSeconds = days * 86400m + hours * 3600m + minutes * 60m + seconds;
            if (totalSeconds == 0m)
                return XdmValue.FromDuration("PT0S");
            try
            {
                decimal resultSeconds = totalSeconds * (decimal)f;
                long totalTicks = (long)(resultSeconds * TimeSpan.TicksPerSecond);
                return XdmValue.FromDuration(FormatDuration(new TimeSpan(totalTicks)));
            }
            catch (OverflowException)
            {
                throw new InvalidOperationException("FODT0002");
            }
        }
        throw new InvalidOperationException("XPTY0004");
    }

    private static XdmValue DivideDuration(XdmValue duration, XdmValue divisor)
    {
        double div = ToDouble(divisor);
        var subtype = GetDurationSubtype(duration);
        if (subtype == DurationSubtype.YearMonthDuration)
        {
            if (double.IsNaN(div))
                throw new InvalidOperationException("FOCA0005");
            if (div == 0.0)
                throw new InvalidOperationException("FODT0002");
            if (double.IsInfinity(div))
                return XdmValue.FromDuration("P0M");
            var d = duration.DurationValue;
            var (y, m, _, _, _, _) = ParseDuration(d);
            decimal baseMonths = y * 12m + m;
            if (baseMonths == 0m)
                return XdmValue.FromDuration("P0M");
            long roundedMonths;
            try
            {
                decimal totalMonths = baseMonths / (decimal)div;
                roundedMonths = RoundHalfUp(totalMonths);
            }
            catch (OverflowException)
            {
                double resultMonthsD = (double)baseMonths / div;
                if (Math.Abs(resultMonthsD) < 0.5)
                    return XdmValue.FromDuration("P0M");
                throw new InvalidOperationException("FODT0002");
            }
            catch (DivideByZeroException)
            {
                double resultMonthsD = (double)baseMonths / div;
                if (Math.Abs(resultMonthsD) < 0.5)
                    return XdmValue.FromDuration("P0M");
                if (Math.Abs(resultMonthsD) > (double)decimal.MaxValue || double.IsInfinity(resultMonthsD))
                    throw new InvalidOperationException("FODT0002");
                roundedMonths = RoundHalfUp((decimal)resultMonthsD);
            }
            return XdmValue.FromDuration(FormatYearMonthDuration(roundedMonths));
        }
        if (subtype == DurationSubtype.DayTimeDuration)
        {
            if (double.IsNaN(div))
                throw new InvalidOperationException("FOCA0005");
            if (div == 0.0)
                throw new InvalidOperationException("FODT0002");
            if (double.IsInfinity(div))
                return XdmValue.FromDuration("PT0S");
            var d = duration.DurationValue;
            var (_, _, days, hours, minutes, seconds) = ParseDuration(d);
            decimal totalSeconds = days * 86400m + hours * 3600m + minutes * 60m + seconds;
            if (totalSeconds == 0m)
                return XdmValue.FromDuration("PT0S");
            try
            {
                decimal resultSeconds = totalSeconds / (decimal)div;
                long totalTicks = (long)(resultSeconds * TimeSpan.TicksPerSecond);
                return XdmValue.FromDuration(FormatDuration(new TimeSpan(totalTicks)));
            }
            catch (OverflowException)
            {
                double resultSecondsD = (double)totalSeconds / div;
                if (Math.Abs(resultSecondsD) * TimeSpan.TicksPerSecond < 0.5)
                    return XdmValue.FromDuration("PT0S");
                throw new InvalidOperationException("FODT0002");
            }
            catch (DivideByZeroException)
            {
                double resultSecondsD = (double)totalSeconds / div;
                if (Math.Abs(resultSecondsD) * TimeSpan.TicksPerSecond < 0.5)
                    return XdmValue.FromDuration("PT0S");
                if (Math.Abs(resultSecondsD) > (double)decimal.MaxValue || double.IsInfinity(resultSecondsD))
                    throw new InvalidOperationException("FODT0002");
                long totalTicks = (long)((decimal)resultSecondsD * TimeSpan.TicksPerSecond);
                return XdmValue.FromDuration(FormatDuration(new TimeSpan(totalTicks)));
            }
        }
        throw new InvalidOperationException("XPTY0004");
    }

    private static string FormatYearMonthDuration(long totalMonths)
    {
        bool negative = totalMonths < 0;
        totalMonths = Math.Abs(totalMonths);
        long years = totalMonths / 12;
        long months = totalMonths % 12;
        var sb = new System.Text.StringBuilder();
        if (negative) sb.Append('-');
        sb.Append('P');
        if (years > 0) sb.Append($"{years}Y");
        if (months > 0) sb.Append($"{months}M");
        if (years == 0 && months == 0) sb.Append("0M");
        return sb.ToString();
    }

    private static XdmValue DivideDurationByDuration(XdmValue left, XdmValue right)
    {
        var l = left.DurationValue;
        var r = right.DurationValue;
        if (IsYearMonthDurationString(l) && IsYearMonthDurationString(r))
        {
            var (y1, m1, _, _, _, _) = ParseDuration(l);
            var (y2, m2, _, _, _, _) = ParseDuration(r);
            decimal totalMonths1 = y1 * 12m + m1;
            decimal totalMonths2 = y2 * 12m + m2;
            // op:divide-yearMonthDuration-by-yearMonthDuration: a zero divisor is FOAR0001.
            if (totalMonths2 == 0) throw new InvalidOperationException("FOAR0001: Division of a duration by a zero duration.");
            return XdmValue.FromDecimal(totalMonths1 / totalMonths2);
        }
        if (IsDayTimeDurationString(l) && IsDayTimeDurationString(r))
        {
            var (_, _, d1, h1, min1, s1) = ParseDuration(l);
            var (_, _, d2, h2, min2, s2) = ParseDuration(r);
            decimal totalSeconds1 = d1 * 86400m + h1 * 3600m + min1 * 60m + s1;
            decimal totalSeconds2 = d2 * 86400m + h2 * 3600m + min2 * 60m + s2;
            if (totalSeconds2 == 0) throw new InvalidOperationException("FOAR0001: Division of a duration by a zero duration.");
            return XdmValue.FromDecimal(totalSeconds1 / totalSeconds2);
        }
        throw new InvalidOperationException("XPTY0004");
    }

    private static XdmValue Multiply(XdmValue left, XdmValue right, EvaluationContext context)
    {
        if (IsEmptySequence(left) || IsEmptySequence(right))
        {
            if (context.BackwardsCompatible)
                return XdmValue.FromDouble(double.NaN);
            return XdmValue.Undefined;
        }

        // XPath 1.0 backwards compatibility: arithmetic always returns an xs:double.
        if (context.BackwardsCompatible)
            return XdmValue.FromDouble(ToDoubleOrNaN(left) * ToDoubleOrNaN(right));

        // Duration * number or number * Duration
        if (left.Kind == XdmValueKind.Duration)
            return MultiplyDuration(left, right);
        if (right.Kind == XdmValueKind.Duration)
            return MultiplyDuration(right, left);

        ValidateNumericOperand(left);
        ValidateNumericOperand(right);

        left = Atomize(left);
        right = Atomize(right);
        if (IsEmptySequence(left) || IsEmptySequence(right))
            return XdmValue.Undefined;
        if (IsUntypedAtomic(left) || IsUntypedAtomic(right))
            return XdmValue.FromDouble(ToDouble(left) * ToDouble(right));

        if (IsDouble(left) || IsDouble(right))
            return XdmValue.FromDouble(ToDouble(left) * ToDouble(right));
        if (IsFloat(left) || IsFloat(right))
            return XdmValue.FromFloat(ToFloat(left) * ToFloat(right));
        if (IsDecimal(left) || IsDecimal(right))
            return DecimalArithmeticResult(ToDecimal(left) * ToDecimal(right), left, right);

        return IntegerArithmetic(ToInteger(left), ToInteger(right), '*');
    }

    private static XdmValue Divide(XdmValue left, XdmValue right, EvaluationContext context)
    {
        if (IsEmptySequence(left) || IsEmptySequence(right))
        {
            if (context.BackwardsCompatible)
                return XdmValue.FromDouble(double.NaN);
            return XdmValue.Undefined;
        }

        // XPath 1.0 backwards compatibility: arithmetic always returns an xs:double.
        if (context.BackwardsCompatible)
            return XdmValue.FromDouble(ToDoubleOrNaN(left) / ToDoubleOrNaN(right));

        // Duration div number
        if (left.Kind == XdmValueKind.Duration && !IsDuration(right))
        {
            RequireProperDurationSubtype(left);
            return DivideDuration(left, right);
        }

        // Duration div Duration
        if (left.Kind == XdmValueKind.Duration && right.Kind == XdmValueKind.Duration)
        {
            RequireProperDurationSubtype(left);
            RequireProperDurationSubtype(right);
            return DivideDurationByDuration(left, right);
        }

        ValidateNumericOperand(left);
        ValidateNumericOperand(right);

        left = Atomize(left);
        right = Atomize(right);
        if (IsEmptySequence(left) || IsEmptySequence(right))
            return XdmValue.Undefined;
        if (IsUntypedAtomic(left) || IsUntypedAtomic(right))
            return XdmValue.FromDouble(ToDouble(left) / ToDouble(right));

        if (IsDouble(left) || IsDouble(right))
            return XdmValue.FromDouble(ToDouble(left) / ToDouble(right));
        if (IsFloat(left) || IsFloat(right))
            return XdmValue.FromFloat(ToFloat(left) / ToFloat(right));

        var divisor = ToDecimal(right);
        if (divisor == 0)
            throw new InvalidOperationException("FOAR0001: Division by zero.");
        return XdmValue.FromDecimal(ToDecimal(left) / divisor);
    }

    private static XdmValue IntegerDivide(XdmValue left, XdmValue right, EvaluationContext context)
    {
        if (IsEmptySequence(left) || IsEmptySequence(right))
        {
            if (context.BackwardsCompatible)
                return XdmValue.FromDouble(double.NaN);
            return XdmValue.Undefined;
        }

        // XPath 1.0 backwards compatibility: integer division returns xs:integer.
        if (context.BackwardsCompatible)
            return XdmValue.FromInteger((long)(ToDoubleOrNaN(left) / ToDoubleOrNaN(right)));

        ValidateNumericOperand(left);
        ValidateNumericOperand(right);

        left = Atomize(left);
        right = Atomize(right);
        if (IsEmptySequence(left) || IsEmptySequence(right))
            return XdmValue.Undefined;
        if (IsUntypedAtomic(left) || IsUntypedAtomic(right))
        {
            double l = ToDouble(left);
            double r = ToDouble(right);
            // A zero divisor is FOAR0001 even when the dividend is INF (it takes
            // precedence over the FOAR0002 result-overflow check).
            if (r == 0)
                throw new InvalidOperationException("FOAR0001: Division by zero.");
            if (double.IsNaN(l) || double.IsNaN(r) || double.IsInfinity(l))
                throw new InvalidOperationException("FOAR0002: Integer division overflow.");
            if (double.IsInfinity(r))
                return XdmValue.FromInteger(0L);
            double result = l / r;
            if (double.IsNaN(result) || double.IsInfinity(result))
                throw new InvalidOperationException("FOAR0002: Integer division overflow.");
            // The xs:integer result is backed by long; a quotient beyond its range is
            // an overflow (cbcl-numeric-idivide-002).
            if (result >= 9223372036854775808.0 || result < -9223372036854775808.0)
                throw new InvalidOperationException("FOAR0002: Integer division overflow.");
            return XdmValue.FromInteger((long)result);
        }

        if (IsDouble(left) || IsDouble(right))
        {
            double l = ToDouble(left);
            double r = ToDouble(right);
            // A zero divisor is FOAR0001 even when the dividend is INF (it takes
            // precedence over the FOAR0002 result-overflow check).
            if (r == 0)
                throw new InvalidOperationException("FOAR0001: Division by zero.");
            if (double.IsNaN(l) || double.IsNaN(r) || double.IsInfinity(l))
                throw new InvalidOperationException("FOAR0002: Integer division overflow.");
            if (double.IsInfinity(r))
                return XdmValue.FromInteger(0L);
            double result = l / r;
            if (double.IsNaN(result) || double.IsInfinity(result))
                throw new InvalidOperationException("FOAR0002: Integer division overflow.");
            // The xs:integer result is backed by long; a quotient beyond its range is
            // an overflow (cbcl-numeric-idivide-002).
            if (result >= 9223372036854775808.0 || result < -9223372036854775808.0)
                throw new InvalidOperationException("FOAR0002: Integer division overflow.");
            return XdmValue.FromInteger((long)result);
        }

        if (IsFloat(left) || IsFloat(right))
        {
            float l = ToFloat(left);
            float r = ToFloat(right);
            if (r == 0)
                throw new InvalidOperationException("FOAR0001: Division by zero.");
            if (float.IsNaN(l) || float.IsNaN(r) || float.IsInfinity(l))
                throw new InvalidOperationException("FOAR0002: Integer division overflow.");
            if (float.IsInfinity(r))
                return XdmValue.FromInteger(0L);
            float result = l / r;
            if (float.IsNaN(result) || float.IsInfinity(result))
                throw new InvalidOperationException("FOAR0002: Integer division overflow.");
            if (result >= 9223372036854775808.0 || result < -9223372036854775808.0)
                throw new InvalidOperationException("FOAR0002: Integer division overflow.");
            return XdmValue.FromInteger((long)result);
        }

        if (IsDecimal(left) || IsDecimal(right))
            return DivideDecimalToInteger(ToDecimal(left), ToDecimal(right));

        if (ToInteger(right) == 0)
            throw new InvalidOperationException("FOAR0001: Division by zero.");
        return XdmValue.FromInteger(ToInteger(left) / ToInteger(right));
    }

    /// <summary>Truncates an exact decimal quotient before enforcing the existing Int64 result range.</summary>
    /// <param name="left">The finite decimal dividend.</param>
    /// <param name="right">The finite decimal divisor.</param>
    /// <returns>The exact truncated quotient as an Int64-backed integer.</returns>
    private static XdmValue DivideDecimalToInteger(decimal left, decimal right)
    {
        if (right == 0)
            throw new InvalidOperationException("FOAR0001: Division by zero.");

        BigInteger numerator = DecimalIntegerCoefficient(left, out int leftScale);
        BigInteger denominator = DecimalIntegerCoefficient(right, out int rightScale);
        int scaleDifference = rightScale - leftScale;
        if (scaleDifference > 0)
            numerator *= BigInteger.Pow(10, scaleDifference);
        else if (scaleDifference < 0)
            denominator *= BigInteger.Pow(10, -scaleDifference);

        // BigInteger division truncates toward zero. Temporary values are bounded by
        // decimal's 96-bit coefficient and scale 0..28; XDM storage stays unchanged.
        BigInteger quotient = numerator / denominator;
        if (quotient < long.MinValue || quotient > long.MaxValue)
            throw new InvalidOperationException("FOAR0002: Integer division overflow.");
        return XdmValue.FromInteger((long)quotient);
    }

    /// <summary>Extracts a signed decimal coefficient and scale without allocating a bits array.</summary>
    /// <param name="value">The decimal value to decompose.</param>
    /// <param name="scale">The decimal scale between zero and 28.</param>
    /// <returns>The signed 96-bit coefficient.</returns>
    private static BigInteger DecimalIntegerCoefficient(decimal value, out int scale)
    {
        Span<int> bits = stackalloc int[4];
        decimal.GetBits(value, bits);
        scale = (bits[3] >> 16) & 0xff;
        BigInteger coefficient = (BigInteger)(uint)bits[0]
            | ((BigInteger)(uint)bits[1] << 32)
            | ((BigInteger)(uint)bits[2] << 64);
        return bits[3] < 0 ? -coefficient : coefficient;
    }

    private static XdmValue Modulo(XdmValue left, XdmValue right, EvaluationContext context)
    {
        if (IsEmptySequence(left) || IsEmptySequence(right))
        {
            if (context.BackwardsCompatible)
                return XdmValue.FromDouble(double.NaN);
            return XdmValue.Undefined;
        }

        // XPath 1.0 backwards compatibility: arithmetic always returns an xs:double.
        if (context.BackwardsCompatible)
            return XdmValue.FromDouble(ToDoubleOrNaN(left) % ToDoubleOrNaN(right));

        ValidateNumericOperand(left);
        ValidateNumericOperand(right);

        left = Atomize(left);
        right = Atomize(right);
        if (IsEmptySequence(left) || IsEmptySequence(right))
            return XdmValue.Undefined;
        if (IsUntypedAtomic(left) || IsUntypedAtomic(right))
        {
            if (ToDouble(right) == 0)
                throw new InvalidOperationException("FOAR0001: Division by zero.");
            return XdmValue.FromDouble(ToDouble(left) % ToDouble(right));
        }

        if (IsDouble(left) || IsDouble(right))
        {
            // IEEE 754 semantics: floating-point mod by zero returns NaN, not FOAR0001.
            return XdmValue.FromDouble(ToDouble(left) % ToDouble(right));
        }
        if (IsFloat(left) || IsFloat(right))
        {
            // IEEE 754 semantics: floating-point mod by zero returns NaN, not FOAR0001.
            return XdmValue.FromFloat(ToFloat(left) % ToFloat(right));
        }
        if (IsDecimal(left) || IsDecimal(right))
        {
            if (ToDecimal(right) == 0)
                throw new InvalidOperationException("FOAR0001: Division by zero.");
            return DecimalArithmeticResult(ToDecimal(left) % ToDecimal(right), left, right);
        }

        long divisor = ToInteger(right);
        if (divisor == 0)
            throw new InvalidOperationException("FOAR0001: Division by zero.");
        long dividend = ToInteger(left);
        // The remainder is zero even though the corresponding Int64 quotient overflows.
        return XdmValue.FromInteger(dividend == long.MinValue && divisor == -1 ? 0 : dividend % divisor);
    }

    private static XdmValue Negate(XdmValue value, EvaluationContext context)
    {
        if (IsEmptySequence(value))
        {
            if (context.BackwardsCompatible)
                return XdmValue.FromDouble(double.NaN);
            return XdmValue.Undefined;
        }

        if (context.BackwardsCompatible)
            return XdmValue.FromDouble(-ToDoubleOrNaN(value));

        // The operand is atomized first (XPTY0004 for a multi-item sequence): unary
        // minus on a node yields the negated typed value, not a node.
        value = Atomize(value);
        // An array can be nonempty as an item while its atomized value is empty.
        if (IsEmptySequence(value))
            return XdmValue.Undefined;

        if (value.Kind == XdmValueKind.Duration)
        {
            var s = value.DurationValue;
            if (s.StartsWith('-'))
                return XdmValue.FromDuration(s[1..]);
            return XdmValue.FromDuration("-" + s);
        }

        // XPath 3.1 §3.1.5: an xs:untypedAtomic operand is converted to xs:double
        // before negation (op-numeric-unary-minus-1).
        if (IsUntypedAtomic(value))
            return XdmValue.FromDouble(-ToDouble(value));

        ValidateNumericOperand(value);
        if (IsDouble(value))
            return XdmValue.FromDouble(-ToDouble(value));
        if (IsFloat(value))
            return XdmValue.FromFloat(-ToFloat(value));
        if (IsDecimal(value))
            return IsIntegerOperand(value)
                ? XdmValue.FromDecimal(-ToDecimal(value), "integer")
                : XdmValue.FromDecimal(-ToDecimal(value));
        long integer = ToInteger(value);
        return integer == long.MinValue
            ? XdmValue.FromDecimal(-(decimal)integer, "integer")
            : XdmValue.FromInteger(-integer);
    }

    private static XdmValue UnaryPlus(XdmValue value, EvaluationContext context)
    {
        if (IsEmptySequence(value))
        {
            if (context.BackwardsCompatible)
                return XdmValue.FromDouble(double.NaN);
            return XdmValue.Undefined;
        }

        if (context.BackwardsCompatible)
            return XdmValue.FromDouble(ToDoubleOrNaN(value));

        // The operand is atomized first (XPTY0004 for a multi-item sequence): unary
        // plus on a node yields its typed value, not the node itself.
        ValidateNumericOperand(value);
        value = Atomize(value);

        // XPath 3.1 §3.1.5: an xs:untypedAtomic operand is converted to xs:double.
        if (IsUntypedAtomic(value))
            return XdmValue.FromDouble(ToDouble(value));

        return value;
    }

    /// <summary>Retains the integer result type only when both arithmetic operands are integers.</summary>
    private static XdmValue DecimalArithmeticResult(decimal value, XdmValue left, XdmValue right)
        => IsIntegerOperand(left) && IsIntegerOperand(right)
            ? XdmValue.FromDecimal(value, "integer")
            : XdmValue.FromDecimal(value);

    private static bool IsIntegerOperand(XdmValue value)
        => value.Kind == XdmValueKind.Integer
            || (value.Kind == XdmValueKind.Decimal && IsIntegerSchemaType(value.SchemaTypeName));

    /// <summary>Performs checked integer arithmetic with decimal-backed integer promotion.</summary>
    private static XdmValue IntegerArithmetic(long a, long b, char operation)
    {
        try
        {
            long result = operation switch
            {
                '+' => checked(a + b),
                '-' => checked(a - b),
                _ => checked(a * b)
            };
            return XdmValue.FromInteger(result);
        }
        catch (OverflowException)
        {
            decimal result = operation switch
            {
                '+' => (decimal)a + b,
                '-' => (decimal)a - b,
                _ => (decimal)a * b
            };
            return XdmValue.FromDecimal(result, "integer");
        }
    }

    // ------------------------------------------------------------------
    // Comparisons
    // ------------------------------------------------------------------

    private static XdmValue Compare(IrOpCode op, XdmValue left, XdmValue right, EvaluationContext context, bool strict = true)
    {
        bool leftFromNode = IsNodeOrigin(left);
        bool rightFromNode = IsNodeOrigin(right);

        // Value comparisons (eq/ne/lt/... and their value-comparison opcodes) require
        // each operand to be a singleton after atomization.
        if (strict && (SequenceLength(left) > 1 || SequenceLength(right) > 1))
            throw new InvalidOperationException("XPTY0004: Value comparison requires singleton operands");

        left = Atomize(left);
        right = Atomize(right);

        // Function items and maps cannot be atomized: any comparison involving one is
        // FOTY0013 (function-item-4 — string-join#1 eq string-join#1; value-comparison-11
        // — map{1:1} eq 1).
        if (left.IsFunction || left.IsMap || right.IsFunction || right.IsMap)
            throw new InvalidOperationException("FOTY0013: A comparison operand must not be a function item or map.");

        // XPath value comparisons with empty sequence operand return empty sequence
        if (left.IsUndefined || right.IsUndefined)
            return XdmValue.Undefined;

        // XPath 3.1 §17.2: in a value comparison, an xs:untypedAtomic operand is
        // cast to xs:string before the comparison proceeds, unless the other operand
        // is an xs:QName, in which case the untypedAtomic value is cast to xs:QName.
        if (strict)
        {
            if (IsUntypedAtomic(left) && right.Kind != XdmValueKind.QName)
            {
                left = XdmValue.FromString(left.StringValue);
                leftFromNode = false;
            }
            if (IsUntypedAtomic(right) && left.Kind != XdmValueKind.QName)
            {
                right = XdmValue.FromString(right.StringValue);
                rightFromNode = false;
            }
        }

        return XdmValue.FromBoolean(CompareCore(op, left, right, strict, leftFromNode, rightFromNode, context));
    }

    /// <summary>
    /// Returns the number of items in <paramref name="value"/> if it is a sequence,
    /// or 1 for any other defined value, or 0 for undefined.
    /// </summary>
    private static int SequenceLength(XdmValue value)
    {
        if (value.IsUndefined)
            return 0;
        if (!value.IsSequence)
            return 1;
        return MaterializeSequence(value).Length;
    }

    private static int CompareStrings(string left, string right, string collation, EvaluationContext context)
        => context.CollationComparer?.Invoke(left, right, collation)
           ?? string.CompareOrdinal(left, right);

    private static bool CompareCore(IrOpCode op, XdmValue left, XdmValue right, bool strict, bool leftFromNode, bool rightFromNode, EvaluationContext context)
    {
        // After untypedAtomic operands have been cast (xs:string for value comparisons,
        // per-type for general comparisons), a remaining xs:string operand has no valid
        // operator mapping against a numeric operand: type error XPTY0004.
        if (strict && ((left.Kind == XdmValueKind.String && IsNumeric(right))
            || (right.Kind == XdmValueKind.String && IsNumeric(left))))
            throw new InvalidOperationException(
                "XPTY0004: Comparison between xs:string and numeric operands is not defined");

        if (IsDouble(left) || IsDouble(right))
        {
            double l = ToDouble(left);
            double r = ToDouble(right);
            return op switch
            {
                IrOpCode.Equal or IrOpCode.ValueEqual => l == r,
                IrOpCode.NotEqual or IrOpCode.ValueNotEqual => l != r,
                IrOpCode.LessThan or IrOpCode.ValueLessThan => l < r,
                IrOpCode.LessThanOrEqual or IrOpCode.ValueLessThanOrEqual => l <= r,
                IrOpCode.GreaterThan or IrOpCode.ValueGreaterThan => l > r,
                IrOpCode.GreaterThanOrEqual or IrOpCode.ValueGreaterThanOrEqual => l >= r,
                _ => throw new ArgumentOutOfRangeException(nameof(op), op, null)
            };
        }

        if (IsFloat(left) || IsFloat(right))
        {
            float l = ToFloat(left);
            float r = ToFloat(right);
            return op switch
            {
                IrOpCode.Equal or IrOpCode.ValueEqual => l == r,
                IrOpCode.NotEqual or IrOpCode.ValueNotEqual => l != r,
                IrOpCode.LessThan or IrOpCode.ValueLessThan => l < r,
                IrOpCode.LessThanOrEqual or IrOpCode.ValueLessThanOrEqual => l <= r,
                IrOpCode.GreaterThan or IrOpCode.ValueGreaterThan => l > r,
                IrOpCode.GreaterThanOrEqual or IrOpCode.ValueGreaterThanOrEqual => l >= r,
                _ => throw new ArgumentOutOfRangeException(nameof(op), op, null)
            };
        }

        if (IsDecimal(left) || IsDecimal(right))
        {
            decimal l = ToDecimal(left);
            decimal r = ToDecimal(right);
            return op switch
            {
                IrOpCode.Equal or IrOpCode.ValueEqual => l == r,
                IrOpCode.NotEqual or IrOpCode.ValueNotEqual => l != r,
                IrOpCode.LessThan or IrOpCode.ValueLessThan => l < r,
                IrOpCode.LessThanOrEqual or IrOpCode.ValueLessThanOrEqual => l <= r,
                IrOpCode.GreaterThan or IrOpCode.ValueGreaterThan => l > r,
                IrOpCode.GreaterThanOrEqual or IrOpCode.ValueGreaterThanOrEqual => l >= r,
                _ => throw new ArgumentOutOfRangeException(nameof(op), op, null)
            };
        }

        if (left.Kind == XdmValueKind.Integer && right.Kind == XdmValueKind.Integer)
        {
            long l = left.IntegerValue;
            long r = right.IntegerValue;
            return op switch
            {
                IrOpCode.Equal or IrOpCode.ValueEqual => l == r,
                IrOpCode.NotEqual or IrOpCode.ValueNotEqual => l != r,
                IrOpCode.LessThan or IrOpCode.ValueLessThan => l < r,
                IrOpCode.LessThanOrEqual or IrOpCode.ValueLessThanOrEqual => l <= r,
                IrOpCode.GreaterThan or IrOpCode.ValueGreaterThan => l > r,
                IrOpCode.GreaterThanOrEqual or IrOpCode.ValueGreaterThanOrEqual => l >= r,
                _ => throw new ArgumentOutOfRangeException(nameof(op), op, null)
            };
        }

        if (left.Kind == XdmValueKind.Boolean && right.Kind == XdmValueKind.Boolean)
        {
            bool l = left.BooleanValue;
            bool r = right.BooleanValue;
            return op switch
            {
                IrOpCode.Equal or IrOpCode.ValueEqual => l == r,
                IrOpCode.NotEqual or IrOpCode.ValueNotEqual => l != r,
                IrOpCode.LessThan or IrOpCode.ValueLessThan => !l && r,
                IrOpCode.LessThanOrEqual or IrOpCode.ValueLessThanOrEqual => !l || r,
                IrOpCode.GreaterThan or IrOpCode.ValueGreaterThan => l && !r,
                IrOpCode.GreaterThanOrEqual or IrOpCode.ValueGreaterThanOrEqual => l || !r,
                _ => throw new ArgumentOutOfRangeException(nameof(op), op, null)
            };
        }

        // QName comparison: prefix is ignored; only namespace URI and local name matter.
        // Ordering comparisons are not defined for QNames.
        if (left.Kind == XdmValueKind.QName && right.Kind == XdmValueKind.QName)
        {
            if (op is IrOpCode.LessThan or IrOpCode.ValueLessThan
                or IrOpCode.LessThanOrEqual or IrOpCode.ValueLessThanOrEqual
                or IrOpCode.GreaterThan or IrOpCode.ValueGreaterThan
                or IrOpCode.GreaterThanOrEqual or IrOpCode.ValueGreaterThanOrEqual)
            {
                throw new InvalidOperationException("XPTY0004: Ordering comparison is not defined for xs:QName values.");
            }
            bool eq = left.QNameValue.Equals(right.QNameValue);
            return op switch
            {
                IrOpCode.Equal or IrOpCode.ValueEqual => eq,
                IrOpCode.NotEqual or IrOpCode.ValueNotEqual => !eq,
                _ => throw new ArgumentOutOfRangeException(nameof(op), op, null)
            };
        }

        // General comparison promotion: an xs:untypedAtomic operand is cast to the
        // type of the other operand. When that type is xs:QName, resolve the lexical
        // QName using the static namespace context of the expression.
        if (left.Kind == XdmValueKind.QName && IsUntypedAtomic(right))
        {
            return CompareCore(op, left, CastUntypedAtomicToQName(right, context), strict, leftFromNode, false, context);
        }
        if (IsUntypedAtomic(left) && right.Kind == XdmValueKind.QName)
        {
            return CompareCore(op, CastUntypedAtomicToQName(left, context), right, strict, false, rightFromNode, context);
        }

        // Duration comparison: normalize to total months and total seconds
        if (left.Kind == XdmValueKind.Duration && right.Kind == XdmValueKind.Duration)
        {
            var (lMonths, lSeconds) = NormalizeDuration(left.DurationValue);
            var (rMonths, rSeconds) = NormalizeDuration(right.DurationValue);
            // The dynamic subtype (schema annotation) decides orderability: a plain
            // xs:duration is unordered even when its value carries only year/month or
            // only day/time parts (cbcl-value-greater-than-002/006/010).
            var lSub = GetDurationSubtype(left);
            var rSub = GetDurationSubtype(right);

            bool isEquality = op is IrOpCode.Equal or IrOpCode.ValueEqual
                              or IrOpCode.NotEqual or IrOpCode.ValueNotEqual;
            if (isEquality)
            {
                bool eq = lMonths == rMonths && lSeconds == rSeconds;
                return op switch
                {
                    IrOpCode.Equal or IrOpCode.ValueEqual => eq,
                    IrOpCode.NotEqual or IrOpCode.ValueNotEqual => !eq,
                    _ => throw new ArgumentOutOfRangeException(nameof(op), op, null)
                };
            }

            // Ordering is only defined when both operands are the same subtype
            if (lSub == DurationSubtype.YearMonthDuration && rSub == DurationSubtype.YearMonthDuration)
            {
                int cmp = lMonths.CompareTo(rMonths);
                return op switch
                {
                    IrOpCode.LessThan or IrOpCode.ValueLessThan => cmp < 0,
                    IrOpCode.LessThanOrEqual or IrOpCode.ValueLessThanOrEqual => cmp <= 0,
                    IrOpCode.GreaterThan or IrOpCode.ValueGreaterThan => cmp > 0,
                    IrOpCode.GreaterThanOrEqual or IrOpCode.ValueGreaterThanOrEqual => cmp >= 0,
                    _ => throw new ArgumentOutOfRangeException(nameof(op), op, null)
                };
            }
            if (lSub == DurationSubtype.DayTimeDuration && rSub == DurationSubtype.DayTimeDuration)
            {
                int cmp = lSeconds.CompareTo(rSeconds);
                return op switch
                {
                    IrOpCode.LessThan or IrOpCode.ValueLessThan => cmp < 0,
                    IrOpCode.LessThanOrEqual or IrOpCode.ValueLessThanOrEqual => cmp <= 0,
                    IrOpCode.GreaterThan or IrOpCode.ValueGreaterThan => cmp > 0,
                    IrOpCode.GreaterThanOrEqual or IrOpCode.ValueGreaterThanOrEqual => cmp >= 0,
                    _ => throw new ArgumentOutOfRangeException(nameof(op), op, null)
                };
            }

            throw new InvalidOperationException("XPTY0004");
        }

        // Date/time comparison: only defined between operands of the same subtype
        string? leftDateSub = GetDateTimeSubtype(left);
        string? rightDateSub = GetDateTimeSubtype(right);
        if (leftDateSub is not null || rightDateSub is not null)
        {
            if (leftDateSub is null || rightDateSub is null || leftDateSub != rightDateSub)
            {
                // XPath general comparison promotion: an atomized untypedAtomic value
                // (typically from a node) is cast to the date/time subtype of the other
                // operand when the types would otherwise be incompatible.
                if (leftDateSub is not null && right.Kind == XdmValueKind.String && right.SchemaTypeName == "untypedAtomic" && TryCast(right, leftDateSub, out var castedRight))
                {
                    right = castedRight;
                    rightDateSub = leftDateSub;
                }
                else if (rightDateSub is not null && left.Kind == XdmValueKind.String && left.SchemaTypeName == "untypedAtomic" && TryCast(left, rightDateSub, out var castedLeft))
                {
                    left = castedLeft;
                    leftDateSub = rightDateSub;
                }
                else
                {
                    throw new InvalidOperationException("XPTY0004");
                }
            }
            // gYear/gYearMonth/gMonth/gMonthDay/gDay only support equality.
            if (leftDateSub is "gYear" or "gYearMonth" or "gMonth" or "gMonthDay" or "gDay")
            {
                if (op is IrOpCode.LessThan or IrOpCode.ValueLessThan or IrOpCode.GreaterThan or IrOpCode.ValueGreaterThan
                    or IrOpCode.LessThanOrEqual or IrOpCode.ValueLessThanOrEqual or IrOpCode.GreaterThanOrEqual or IrOpCode.ValueGreaterThanOrEqual)
                    throw new InvalidOperationException("XPTY0004");

                var gCmp = CompareDateTimeValues(left, right, leftDateSub, GetImplicitTimezoneOffsetMinutes(context));
                if (gCmp.HasValue)
                {
                    return op switch
                    {
                        IrOpCode.Equal or IrOpCode.ValueEqual => gCmp.Value == 0,
                        IrOpCode.NotEqual or IrOpCode.ValueNotEqual => gCmp.Value != 0,
                        _ => throw new ArgumentOutOfRangeException(nameof(op), op, null)
                    };
                }
                // Indeterminate: eq/ne fall back to string comparison
                int lexCmp = string.CompareOrdinal(left.ToString(), right.ToString());
                return op switch
                {
                    IrOpCode.Equal or IrOpCode.ValueEqual => lexCmp == 0,
                    IrOpCode.NotEqual or IrOpCode.ValueNotEqual => lexCmp != 0,
                    _ => throw new ArgumentOutOfRangeException(nameof(op), op, null)
                };
            }

            var cmp = CompareDateTimeValues(left, right, leftDateSub, GetImplicitTimezoneOffsetMinutes(context));
            if (cmp.HasValue)
            {
                return op switch
                {
                    IrOpCode.Equal or IrOpCode.ValueEqual => cmp.Value == 0,
                    IrOpCode.NotEqual or IrOpCode.ValueNotEqual => cmp.Value != 0,
                    IrOpCode.LessThan or IrOpCode.ValueLessThan => cmp.Value < 0,
                    IrOpCode.LessThanOrEqual or IrOpCode.ValueLessThanOrEqual => cmp.Value <= 0,
                    IrOpCode.GreaterThan or IrOpCode.ValueGreaterThan => cmp.Value > 0,
                    IrOpCode.GreaterThanOrEqual or IrOpCode.ValueGreaterThanOrEqual => cmp.Value >= 0,
                    _ => throw new ArgumentOutOfRangeException(nameof(op), op, null)
                };
            }
            // Indeterminate comparison: lt/gt/le/ge return false; eq/ne use string fallback
            return op is IrOpCode.Equal or IrOpCode.ValueEqual or IrOpCode.NotEqual or IrOpCode.ValueNotEqual
                ? CompareStrings(left.ToString(), right.ToString(), context.DefaultCollation, context) == (op is IrOpCode.Equal or IrOpCode.ValueEqual ? 0 : 1)
                : false;
        }

        // Binary comparison: xs:hexBinary / xs:base64Binary values are stored as
        // annotated strings. Comparison is defined only between two values of the same
        // binary type and orders by the decoded octets, not the lexical form
        // (op-base64Binary-less-than-17/25, op-hexBinary-greater-than-25).
        bool leftIsBinary = IsBinaryTypedString(left);
        bool rightIsBinary = IsBinaryTypedString(right);
        if (leftIsBinary || rightIsBinary)
        {
            if (!leftIsBinary || !rightIsBinary
                || !string.Equals(left.SchemaTypeName, right.SchemaTypeName, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException(
                    "XPTY0004: Comparison is only defined between two xs:hexBinary or two xs:base64Binary values.");
            }
            int bcmp = CompareBinaryValues(left, right);
            return op switch
            {
                IrOpCode.Equal or IrOpCode.ValueEqual => bcmp == 0,
                IrOpCode.NotEqual or IrOpCode.ValueNotEqual => bcmp != 0,
                IrOpCode.LessThan or IrOpCode.ValueLessThan => bcmp < 0,
                IrOpCode.LessThanOrEqual or IrOpCode.ValueLessThanOrEqual => bcmp <= 0,
                IrOpCode.GreaterThan or IrOpCode.ValueGreaterThan => bcmp > 0,
                IrOpCode.GreaterThanOrEqual or IrOpCode.ValueGreaterThanOrEqual => bcmp >= 0,
                _ => throw new ArgumentOutOfRangeException(nameof(op), op, null)
            };
        }

        // Atomized nodes become strings; try numeric parsing for untyped values
        string lStr = left.ToString();
        string rStr = right.ToString();

        // If both are explicitly strings, compare as strings (don't parse as numbers)
        if (left.Kind == XdmValueKind.String && right.Kind == XdmValueKind.String)
        {
            int cmp = CompareStrings(lStr, rStr, context.DefaultCollation, context);
            return op switch
            {
                IrOpCode.Equal or IrOpCode.ValueEqual => cmp == 0,
                IrOpCode.NotEqual or IrOpCode.ValueNotEqual => cmp != 0,
                IrOpCode.LessThan or IrOpCode.ValueLessThan => cmp < 0,
                IrOpCode.LessThanOrEqual or IrOpCode.ValueLessThanOrEqual => cmp <= 0,
                IrOpCode.GreaterThan or IrOpCode.ValueGreaterThan => cmp > 0,
                IrOpCode.GreaterThanOrEqual or IrOpCode.ValueGreaterThanOrEqual => cmp >= 0,
                _ => throw new ArgumentOutOfRangeException(nameof(op), op, null)
            };
        }

        // In strict mode, a string may only be compared with a numeric if it originated
        // from a node (untyped atomic) or is explicitly typed as xs:untypedAtomic.
        // Typed string literals are not comparable with numbers.
        bool leftIsString = left.Kind == XdmValueKind.String;
        bool rightIsString = right.Kind == XdmValueKind.String;
        bool leftIsNumeric = IsDouble(left) || IsFloat(left) || IsDecimal(left) || left.Kind == XdmValueKind.Integer;
        bool rightIsNumeric = IsDouble(right) || IsFloat(right) || IsDecimal(right) || right.Kind == XdmValueKind.Integer;

        bool numericMismatch = (leftIsString && rightIsNumeric) || (leftIsNumeric && rightIsString);
        if (strict && numericMismatch)
        {
            bool stringIsCastable = (leftIsString && (leftFromNode || left.SchemaTypeName?.Equals("untypedAtomic", StringComparison.OrdinalIgnoreCase) == true))
                                 || (rightIsString && (rightFromNode || right.SchemaTypeName?.Equals("untypedAtomic", StringComparison.OrdinalIgnoreCase) == true));
            if (!stringIsCastable)
                throw new InvalidOperationException("XPTY0004");
        }

        if (double.TryParse(lStr, NumberStyles.Any, CultureInfo.InvariantCulture, out double lDbl) &&
            double.TryParse(rStr, NumberStyles.Any, CultureInfo.InvariantCulture, out double rDbl))
        {
            return op switch
            {
                IrOpCode.Equal or IrOpCode.ValueEqual => lDbl == rDbl,
                IrOpCode.NotEqual or IrOpCode.ValueNotEqual => lDbl != rDbl,
                IrOpCode.LessThan or IrOpCode.ValueLessThan => lDbl < rDbl,
                IrOpCode.LessThanOrEqual or IrOpCode.ValueLessThanOrEqual => lDbl <= rDbl,
                IrOpCode.GreaterThan or IrOpCode.ValueGreaterThan => lDbl > rDbl,
                IrOpCode.GreaterThanOrEqual or IrOpCode.ValueGreaterThanOrEqual => lDbl >= rDbl,
                _ => throw new ArgumentOutOfRangeException(nameof(op), op, null)
            };
        }

        if (strict && numericMismatch)
        {
            // String came from a node but didn't parse as a number
            throw new InvalidOperationException("XPTY0004");
        }

        // In strict mode, only same-kind atomic values are comparable (cross-kind
        // mismatches such as boolean vs numeric should have been handled above).
        if (strict && left.Kind != right.Kind)
            throw new InvalidOperationException("XPTY0004");

        int cmp2 = CompareStrings(lStr, rStr, context.DefaultCollation, context);
        return op switch
        {
            IrOpCode.Equal or IrOpCode.ValueEqual => cmp2 == 0,
            IrOpCode.NotEqual or IrOpCode.ValueNotEqual => cmp2 != 0,
            IrOpCode.LessThan or IrOpCode.ValueLessThan => cmp2 < 0,
            IrOpCode.LessThanOrEqual or IrOpCode.ValueLessThanOrEqual => cmp2 <= 0,
            IrOpCode.GreaterThan or IrOpCode.ValueGreaterThan => cmp2 > 0,
            IrOpCode.GreaterThanOrEqual or IrOpCode.ValueGreaterThanOrEqual => cmp2 >= 0,
            _ => throw new ArgumentOutOfRangeException(nameof(op), op, null)
        };
    }

    /// <summary>
    /// True when the value is an xs:hexBinary or xs:base64Binary atomic, which this
    /// engine stores as an <see cref="XdmValueKind.String"/> value carrying the binary
    /// schema-type annotation.
    /// </summary>
    private static bool IsBinaryTypedString(XdmValue value)
        => value.Kind == XdmValueKind.String
           && (value.SchemaTypeName?.Equals("hexBinary", StringComparison.OrdinalIgnoreCase) == true
               || value.SchemaTypeName?.Equals("base64Binary", StringComparison.OrdinalIgnoreCase) == true);

    /// <summary>
    /// Compares two same-type binary values by their decoded octets (unsigned,
    /// lexicographic). Callers must ensure both values share one binary schema type.
    /// </summary>
    private static int CompareBinaryValues(XdmValue left, XdmValue right)
    {
        bool isHex = left.SchemaTypeName!.Equals("hexBinary", StringComparison.OrdinalIgnoreCase);
        byte[] lBytes = isHex ? Convert.FromHexString(left.StringValue) : Convert.FromBase64String(left.StringValue);
        byte[] rBytes = isHex ? Convert.FromHexString(right.StringValue) : Convert.FromBase64String(right.StringValue);
        return ((ReadOnlySpan<byte>)lBytes).SequenceCompareTo(rBytes);
    }

    /// <summary>
    /// Three-way comparison for XPath 4.0 <c>fn:compare</c> (spec PR909): compares two
    /// single atomic values of any comparable combination and returns -1, 0, or 1.
    /// Strings (including <c>xs:untypedAtomic</c>) compare by collation; binary values
    /// (hexBinary/base64Binary annotations) compare by decoded octets, mutually
    /// comparable across the two binary types; booleans order false &lt; true; any mix
    /// of numeric types compares by exact mathematical value (NaN &lt; -INF &lt; finite
    /// &lt; +INF, NaN equal NaN, +0 equal -0); date/time values of the same subtype
    /// compare on the timeline (indeterminate falls back to the lexical form, mirroring
    /// the eq/ne fallback); durations order within the same subtype; QNames order by
    /// {namespace URI, local name}. Any other combination raises XPTY0004.
    /// </summary>
    /// <param name="left">The left-hand atomic value.</param>
    /// <param name="right">The right-hand atomic value.</param>
    /// <param name="context">The evaluation context (collation, implicit timezone).</param>
    /// <returns>A negative value, zero, or a positive value.</returns>
    /// <exception cref="InvalidOperationException">XPTY0004 when the values are not comparable.</exception>
    public static int CompareAtomic(XdmValue left, XdmValue right, EvaluationContext context)
    {
        // Detect date/time subtypes first: g*-family values are String-kind but
        // compare on the timeline (PR2256), not as strings.
        string? leftDateSub = GetDateTimeSubtype(left);
        string? rightDateSub = GetDateTimeSubtype(right);

        if (left.Kind == XdmValueKind.String && right.Kind == XdmValueKind.String
            && leftDateSub is null && rightDateSub is null)
        {
            bool leftBinary = IsBinaryTypedString(left);
            bool rightBinary = IsBinaryTypedString(right);
            if (leftBinary || rightBinary)
            {
                if (!leftBinary || !rightBinary)
                    throw new InvalidOperationException("XPTY0004: A binary value can only be compared with another binary value.");
                return CompareBinaryValuesLoose(left, right);
            }
            int strCmp = CompareStrings(left.ToString(), right.ToString(), context.DefaultCollation, context);
            return strCmp < 0 ? -1 : strCmp > 0 ? 1 : 0;
        }

        if (left.Kind == XdmValueKind.Boolean && right.Kind == XdmValueKind.Boolean)
            return left.BooleanValue.CompareTo(right.BooleanValue);

        if (IsNumericKind(left.Kind) && IsNumericKind(right.Kind))
            return CompareNumericExact(left, right);

        if (left.Kind == XdmValueKind.QName && right.Kind == XdmValueKind.QName)
        {
            int nsCmp = string.CompareOrdinal(left.QNameValue.NamespaceUri, right.QNameValue.NamespaceUri);
            if (nsCmp != 0)
                return nsCmp < 0 ? -1 : 1;
            int localCmp = string.CompareOrdinal(left.QNameValue.LocalName, right.QNameValue.LocalName);
            return localCmp < 0 ? -1 : localCmp > 0 ? 1 : 0;
        }

        if (left.Kind == XdmValueKind.Duration && right.Kind == XdmValueKind.Duration)
        {
            // XPath 4.0 fn:compare (PR909): all duration subtypes are mutually
            // comparable by the component tuple (months, days, seconds), without
            // normalizing across units — P2Y > P1000D, PT1H == PT60M0.00S,
            // P1Y == P12M (compare-duration-01..09, duration vs yearMonthDuration).
            var (lMonths, lDays, lSeconds) = DurationComponents(left.DurationValue);
            var (rMonths, rDays, rSeconds) = DurationComponents(right.DurationValue);
            int c = lMonths.CompareTo(rMonths);
            if (c == 0) c = lDays.CompareTo(rDays);
            if (c == 0) c = lSeconds.CompareTo(rSeconds);
            return c < 0 ? -1 : c > 0 ? 1 : 0;
        }

        if (leftDateSub is not null || rightDateSub is not null)
        {
            if (leftDateSub is null || rightDateSub is null || leftDateSub != rightDateSub)
                throw new InvalidOperationException("XPTY0004: Values of different date/time subtypes cannot be compared.");
            var cmp = CompareDateTimeValues(left, right, leftDateSub, context.ImplicitTimezoneOffsetMinutes);
            if (cmp.HasValue)
                return cmp.Value < 0 ? -1 : cmp.Value > 0 ? 1 : 0;
            // Indeterminate (e.g. g* values with mixed timezone presence): fall back
            // to the lexical form, mirroring the eq/ne fallback in CompareCore.
            int lexCmp = string.CompareOrdinal(left.ToString(), right.ToString());
            return lexCmp < 0 ? -1 : lexCmp > 0 ? 1 : 0;
        }

        throw new InvalidOperationException(
            $"XPTY0004: Values of type {left.Kind} and {right.Kind} cannot be compared.");
    }

    private static bool IsNumericKind(XdmValueKind kind)
        => kind is XdmValueKind.Integer or XdmValueKind.Decimal or XdmValueKind.Double or XdmValueKind.Float;

    // Binary comparison for XPath 4.0 fn:compare (PR909): unlike the 3.1 same-type
    // rule, hexBinary and base64Binary are mutually comparable; each side decodes per
    // its own SchemaTypeName annotation (compare-binary-07/08/09).
    private static int CompareBinaryValuesLoose(XdmValue left, XdmValue right)
    {
        byte[] lBytes = DecodeBinaryOctets(left);
        byte[] rBytes = DecodeBinaryOctets(right);
        return ((ReadOnlySpan<byte>)lBytes).SequenceCompareTo(rBytes);
    }

    private static byte[] DecodeBinaryOctets(XdmValue value)
        => value.SchemaTypeName!.Equals("hexBinary", StringComparison.OrdinalIgnoreCase)
            ? Convert.FromHexString(value.StringValue)
            : Convert.FromBase64String(value.StringValue);

    // Exact three-way comparison of two numeric values of any mix of integer, decimal,
    // float, and double (XPath 4.0 fn:compare, PR909): NaN < -INF < finite < +INF,
    // NaN equals NaN, +0 equals -0, and finite values compare by exact mathematical
    // value — (double)3.1 > (decimal)3.1 while (float)3.1 < (decimal)3.1. Each value
    // is expanded exactly to a (sign, significand, decimal-exponent) triple using
    // BigInteger arithmetic, so no rounding ever occurs.
    private static int CompareNumericExact(XdmValue left, XdmValue right)
    {
        var l = ExactDecimalForm(left);
        var r = ExactDecimalForm(right);
        // NaN sorts below everything (including -INF); NaN equals NaN.
        if (l.Kind != ExactNumericKind.Finite || r.Kind != ExactNumericKind.Finite)
        {
            if (l.Kind == ExactNumericKind.NaN || r.Kind == ExactNumericKind.NaN)
            {
                if (l.Kind == ExactNumericKind.NaN && r.Kind == ExactNumericKind.NaN) return 0;
                return l.Kind == ExactNumericKind.NaN ? -1 : 1;
            }
            // Infinities: -INF < finite < +INF.
            if (l.Kind == ExactNumericKind.NegativeInfinity) return r.Kind == ExactNumericKind.NegativeInfinity ? 0 : -1;
            if (r.Kind == ExactNumericKind.NegativeInfinity) return 1;
            return l.Kind == ExactNumericKind.PositiveInfinity ? (r.Kind == ExactNumericKind.PositiveInfinity ? 0 : 1) : -1;
        }
        if (l.Sign != r.Sign)
            return l.Sign.CompareTo(r.Sign);
        if (l.Significand.IsZero)
            return 0; // both zero (+0 == -0)
        int mag = CompareExactMagnitude(l, r);
        return l.Sign > 0 ? mag : -mag;
    }

    private enum ExactNumericKind { Finite, NaN, NegativeInfinity, PositiveInfinity }

    private readonly record struct ExactDecimalFormData(int Sign, BigInteger Significand, int Exponent, ExactNumericKind Kind);

    private static ExactDecimalFormData ExactDecimalForm(XdmValue value)
    {
        switch (value.Kind)
        {
            case XdmValueKind.Integer:
            {
                long i = value.IntegerValue;
                return new ExactDecimalFormData(i < 0 ? -1 : 1, new BigInteger(i < 0 ? -i : i), 0, ExactNumericKind.Finite);
            }
            case XdmValueKind.Decimal:
            {
                decimal d = value.DecimalValue;
                if (d == 0) return new ExactDecimalFormData(0, BigInteger.Zero, 0, ExactNumericKind.Finite);
                int[] bits = decimal.GetBits(d);
                var mantissa = new BigInteger((uint)bits[0]) | (new BigInteger((uint)bits[1]) << 32) | (new BigInteger((uint)bits[2]) << 64);
                int scale = (bits[3] >> 16) & 0xFF;
                int sign = (bits[3] >> 31) != 0 ? -1 : 1;
                return StripTrailingZeros(new ExactDecimalFormData(sign, mantissa, -scale, ExactNumericKind.Finite));
            }
            case XdmValueKind.Double:
            case XdmValueKind.Float:
            {
                // float widens to double exactly, so both go through the binary path.
                double d = value.DoubleValue;
                if (double.IsNaN(d)) return new ExactDecimalFormData(0, BigInteger.Zero, 0, ExactNumericKind.NaN);
                if (double.IsNegativeInfinity(d)) return new ExactDecimalFormData(0, BigInteger.Zero, 0, ExactNumericKind.NegativeInfinity);
                if (double.IsPositiveInfinity(d)) return new ExactDecimalFormData(0, BigInteger.Zero, 0, ExactNumericKind.PositiveInfinity);
                long bits = BitConverter.DoubleToInt64Bits(d);
                int sign = bits < 0 ? -1 : 1;
                int exponentBits = (int)((bits >> 52) & 0x7FF);
                long mantissaBits = bits & 0xFFFFFFFFFFFFF;
                if (exponentBits == 0 && mantissaBits == 0)
                    return new ExactDecimalFormData(0, BigInteger.Zero, 0, ExactNumericKind.Finite); // ±0
                int e; BigInteger m;
                if (exponentBits == 0)
                {
                    m = mantissaBits; e = -1074; // subnormal
                }
                else
                {
                    m = mantissaBits | (1L << 52); e = exponentBits - 1075;
                }
                // m * 2^e, expanded exactly into a decimal (significand, exponent) pair:
                // e >= 0 → integer significand; e < 0 → multiply by 5^|e|, drop 10^|e|.
                if (e >= 0)
                    return StripTrailingZeros(new ExactDecimalFormData(sign, m << e, 0, ExactNumericKind.Finite));
                return StripTrailingZeros(new ExactDecimalFormData(sign, m * BigInteger.Pow(new BigInteger(5), -e), e, ExactNumericKind.Finite));
            }
            default:
                throw new InvalidOperationException("XPTY0004: Not a numeric value.");
        }
    }

    // Canonicalizes a finite (sign, significand, exponent) triple so the significand
    // carries no trailing decimal zeros — required for exact cross-type equality
    // (2e0 vs 2 both become (1, 2, 0)).
    private static ExactDecimalFormData StripTrailingZeros(ExactDecimalFormData form)
    {
        var significand = form.Significand;
        int exponent = form.Exponent;
        while (!significand.IsZero)
        {
            var (quotient, remainder) = BigInteger.DivRem(significand, new BigInteger(10));
            if (!remainder.IsZero) break;
            significand = quotient;
            exponent++;
        }
        return form with { Significand = significand, Exponent = exponent };
    }

    // Compares magnitudes of two finite exact forms by aligning decimal exponents.
    private static int CompareExactMagnitude(ExactDecimalFormData left, ExactDecimalFormData right)
    {
        int minExponent = Math.Min(left.Exponent, right.Exponent);
        var l = left.Significand * BigInteger.Pow(new BigInteger(10), left.Exponent - minExponent);
        var r = right.Significand * BigInteger.Pow(new BigInteger(10), right.Exponent - minExponent);
        return l.CompareTo(r);
    }

    private static XdmValue CompareGeneral(IrOpCode op, XdmValue left, XdmValue right, EvaluationContext context)
    {
        // XPath 3.1 §17.3: if one operand is an empty sequence, the result is false.
        if (left.IsUndefined || right.IsUndefined)
            return XdmValue.FromBoolean(false);

        // Fast path: '=' / '!=' between a single xs:integer and a large all-integer
        // sequence (e.g. $validrange[not(. = $c)] with 1.1M x 2k comparisons): use a
        // cached hash set instead of O(n x m) pairwise comparison.
        if (!context.BackwardsCompatible && op is IrOpCode.GeneralEqual or IrOpCode.GeneralNotEqual &&
            TryIntegerSetComparison(op, left, right, out bool intSetResult))
        {
            return XdmValue.FromBoolean(intSetResult);
        }

        // General comparisons use existential semantics over sequences.
        // Enumerate lazily to avoid materializing huge ranges (e.g. 1e21 to 1e21+5e9).
        var leftItems = EnumerateItemsForComparison(left);
        var rightItems = EnumerateItemsForComparison(right);

        // XPath 1.0 backwards compatibility: when a node-set (or any sequence) is
        // compared to a boolean, both operands are converted to booleans using the
        // effective boolean value of the whole operand.
        if (context.BackwardsCompatible &&
            (SequenceContainsBooleanItem(left) || SequenceContainsBooleanItem(right) ||
             (left.IsUndefined && SequenceContainsBooleanItem(right)) ||
             (right.IsUndefined && SequenceContainsBooleanItem(left))))
        {
            int li = left.GetEffectiveBooleanValue() ? 1 : 0;
            int ri = right.GetEffectiveBooleanValue() ? 1 : 0;
            bool match = CompareCore(
                MapGeneralToStrictOp(op),
                XdmValue.FromInteger(li), XdmValue.FromInteger(ri), strict: false,
                false, false, context);
            return XdmValue.FromBoolean(match);
        }

        bool relational = IsRelationalGeneralComparison(op);
        var leftBuffer = new List<XdmValue>(4);
        var rightBuffer = new List<XdmValue>(4);

        foreach (var l in leftItems)
        {
            foreach (var r in rightItems)
            {
                // Atomize each operand. Atomizing a schema-validated node whose type is a
                // list type yields a multi-item sequence; XPath 3.1 §3.5.2 gives general
                // comparisons existential semantics over the Cartesian product of both
                // atomized sequences, so each member pair is compared individually
                // (import-schema-020/029/030, validation-0401).
                var atomizedL = Atomize(l);
                var atomizedR = Atomize(r);

                leftBuffer.Clear();
                rightBuffer.Clear();
                AddAtomizedComparisonItems(atomizedL, leftBuffer);
                AddAtomizedComparisonItems(atomizedR, rightBuffer);
                if (leftBuffer.Count == 0 || rightBuffer.Count == 0)
                    continue;

                foreach (var al in leftBuffer)
                {
                    foreach (var ar in rightBuffer)
                    {
                        var pairL = al;
                        var pairR = ar;

                        // XPath 1.0 backwards compatibility coercion rules
                        if (context.BackwardsCompatible)
                        {
                            if (relational)
                            {
                                // Relational operators convert both operands to numbers.
                                if (pairL.Kind != XdmValueKind.Boolean)
                                    pairL = XdmValue.FromDouble(ToDoubleOrNaN(pairL));
                                if (pairR.Kind != XdmValueKind.Boolean)
                                    pairR = XdmValue.FromDouble(ToDoubleOrNaN(pairR));
                            }
                            else
                            {
                                ApplyBackwardsCompatibleCoercion(ref pairL, ref pairR);
                            }
                        }

                        // XPath 3.1 §3.5.3 general-comparison casting rules: when exactly one
                        // value is xs:untypedAtomic, cast it to a type depending on the other
                        // value's type (numeric -> xs:double, duration subtypes -> same subtype,
                        // otherwise the primitive base type of T).
                        if (!context.BackwardsCompatible)
                            CastUntypedForGeneralComparison(ref pairL, ref pairR, context);

                        bool match = CompareCore(
                            MapGeneralToStrictOp(op),
                            pairL, pairR, strict: !context.BackwardsCompatible,
                            IsNodeOrigin(l), IsNodeOrigin(r), context);

                        if (match)
                            return XdmValue.FromBoolean(true);
                    }
                }
            }
        }

        return XdmValue.FromBoolean(false);
    }

    /// <summary>
    /// Appends the items of an atomized general-comparison operand to <paramref name="items"/>,
    /// flattening the multi-item sequences produced by atomizing list-typed schema nodes.
    /// An undefined operand contributes nothing; a function item is FOTY0013.
    /// </summary>
    /// <param name="atomized">The atomized operand value.</param>
    /// <param name="items">The buffer receiving the operand's items.</param>
    private static void AddAtomizedComparisonItems(XdmValue atomized, List<XdmValue> items)
    {
        if (atomized.IsUndefined)
            return;
        if (atomized.IsSequence && atomized.SequenceValue is not null)
        {
            foreach (var inner in XdmSequence.FromSource(atomized.SequenceValue))
            {
                if (inner.IsUndefined)
                    continue;
                if (inner.IsFunction)
                    throw new InvalidOperationException("FOTY0013: A comparison operand must not be a function item.");
                items.Add(inner);
            }
            return;
        }

        // Function items cannot be atomized: a comparison involving one is
        // FOTY0013 (inline-fn-031: comparing two inline functions with '=').
        if (atomized.IsFunction)
            throw new InvalidOperationException("FOTY0013: A comparison operand must not be a function item.");
        items.Add(atomized);
    }

    /// <summary>
    /// Applies the XPath 3.1 §3.5.3 general-comparison casting rules to one atomized
    /// value pair: both xs:untypedAtomic are cast to xs:string; a single xs:untypedAtomic
    /// is cast to xs:double (numeric other), the matching duration subtype, xs:QName
    /// (QName other), or the primitive base type of the other value.
    /// </summary>
    private static void CastUntypedForGeneralComparison(ref XdmValue left, ref XdmValue right, EvaluationContext context)
    {
        bool lu = IsUntypedAtomic(left);
        bool ru = IsUntypedAtomic(right);
        if (lu && ru)
        {
            left = XdmValue.FromString(left.StringValue);
            right = XdmValue.FromString(right.StringValue);
            return;
        }
        if (lu)
            left = CastUntypedToOtherType(left, right, context);
        else if (ru)
            right = CastUntypedToOtherType(right, left, context);
    }

    private static XdmValue CastUntypedToOtherType(XdmValue untyped, XdmValue other, EvaluationContext context)
    {
        string targetType;
        if (other.Kind is XdmValueKind.Integer or XdmValueKind.Decimal or XdmValueKind.Double or XdmValueKind.Float)
        {
            targetType = "xs:double";
        }
        else if (other.Kind == XdmValueKind.Duration)
        {
            targetType = other.SchemaTypeName?.Equals("yearMonthDuration", StringComparison.OrdinalIgnoreCase) == true
                ? "xs:yearMonthDuration"
                : "xs:dayTimeDuration";
        }
        else if (other.Kind == XdmValueKind.QName)
        {
            return CastUntypedAtomicToQName(untyped, context);
        }
        else
        {
            targetType = other.Kind switch
            {
                XdmValueKind.String => "xs:" + (other.SchemaTypeName is null
                    ? "string"
                    : PrimitiveBaseTypeName(other.SchemaTypeName)),
                XdmValueKind.Boolean => "xs:boolean",
                XdmValueKind.Uri => "xs:anyURI",
                XdmValueKind.Date => "xs:date",
                XdmValueKind.Time => "xs:time",
                XdmValueKind.DateTime => "xs:dateTime",
                _ => "xs:string"
            };
        }
        if (!TryCast(untyped, targetType, out var casted))
            throw new InvalidOperationException(
                $"FORG0001: Cannot cast xs:untypedAtomic '{untyped}' to {targetType}");
        return casted;
    }

    /// <summary>
    /// Walks the direct-supertype chain from a schema type annotation up to (but not
    /// including) xs:anyAtomicType, yielding the primitive base type — e.g. NCName →
    /// string, hexBinary → hexBinary. Used by the general-comparison casting rules.
    /// </summary>
    private static string PrimitiveBaseTypeName(string schemaTypeName)
    {
        string current = schemaTypeName;
        while (true)
        {
            var next = GetDirectSupertypes(current.ToLowerInvariant()).FirstOrDefault();
            if (next is null or "anyatomictype" or "item()")
                return current;
            current = next;
        }
    }

    private static IrOpCode MapGeneralToStrictOp(IrOpCode op)
        => op switch
        {
            IrOpCode.GeneralEqual => IrOpCode.Equal,
            IrOpCode.GeneralNotEqual => IrOpCode.NotEqual,
            IrOpCode.GeneralLessThan => IrOpCode.LessThan,
            IrOpCode.GeneralLessThanOrEqual => IrOpCode.LessThanOrEqual,
            IrOpCode.GeneralGreaterThan => IrOpCode.GreaterThan,
            IrOpCode.GeneralGreaterThanOrEqual => IrOpCode.GreaterThanOrEqual,
            _ => throw new ArgumentOutOfRangeException(nameof(op), op, null)
        };

    private sealed class IntegerSetHolder
    {
        public HashSet<long>? Set;
    }

    private static readonly System.Runtime.CompilerServices.ConditionalWeakTable<IXdmSequence, IntegerSetHolder> IntegerSetCache = new();

    /// <summary>
    /// Evaluates <c>=</c>/<c>!=</c> between a single xs:integer item and a sequence that
    /// consists solely of xs:integer items, using a cached hash set for the sequence
    /// (built once per sequence identity). Returns false when the fast path does not apply.
    /// </summary>
    private static bool TryIntegerSetComparison(IrOpCode op, XdmValue left, XdmValue right, out bool result)
    {
        result = false;
        XdmValue single, multi;
        if (left.IsAtomic) { single = left; multi = right; }
        else if (right.IsAtomic) { single = right; multi = left; }
        else return false;

        var atom = Atomize(single);
        if (atom.Kind != XdmValueKind.Integer)
            return false;

        HashSet<long>? set;
        long singleOther = 0;
        if (multi.IsAtomic)
        {
            var other = Atomize(multi);
            if (other.Kind != XdmValueKind.Integer)
                return false;
            singleOther = other.IntegerValue;
            set = null;
        }
        else if (multi.IsSequence && multi.SequenceValue is not null)
        {
            set = GetOrBuildIntegerSet(multi.SequenceValue);
            if (set is null)
                return false;
        }
        else return false;

        result = op == IrOpCode.GeneralEqual
            ? (set is null ? atom.IntegerValue == singleOther : set.Contains(atom.IntegerValue))
            : (set is null ? atom.IntegerValue != singleOther : set.Count > 1 || !set.Contains(atom.IntegerValue));
        return true;
    }

    private static HashSet<long>? GetOrBuildIntegerSet(IXdmSequence seq)
    {
        var holder = IntegerSetCache.GetValue(seq, BuildIntegerSetHolder);
        return holder.Set;
    }

    private static IntegerSetHolder BuildIntegerSetHolder(IXdmSequence seq)
    {
        // Only larger, all-integer sequences qualify for the cached hash set.
        if (!seq.TryGetLength(out int len) || len < 8)
            return new IntegerSetHolder { Set = null };
        var set = new HashSet<long>(len);
        foreach (var item in XdmSequence.FromSource(seq))
        {
            var atom = Atomize(item);
            if (atom.Kind != XdmValueKind.Integer)
                return new IntegerSetHolder { Set = null };
            set.Add(atom.IntegerValue);
        }
        return new IntegerSetHolder { Set = set };
    }

    private static bool IsRelationalGeneralComparison(IrOpCode op)
        => op is IrOpCode.GeneralLessThan or IrOpCode.GeneralLessThanOrEqual
                or IrOpCode.GeneralGreaterThan or IrOpCode.GeneralGreaterThanOrEqual;

    private static bool HasBooleanItem(ReadOnlySpan<XdmValue> items)
    {
        foreach (var item in items)
        {
            var atomized = Atomize(item);
            if (!atomized.IsUndefined && atomized.Kind == XdmValueKind.Boolean)
                return true;
        }
        return false;
    }

    /// <summary>
    /// Applies XPath 1.0 backwards-compatible coercion rules for general comparisons:
    /// 1. If either operand is boolean, convert the other to boolean.
    /// 2. If either operand is numeric, convert the other to numeric.
    /// 3. Otherwise, convert both to strings.
    /// </summary>
    private static void ApplyBackwardsCompatibleCoercion(ref XdmValue left, ref XdmValue right)
    {
        bool leftIsBool = left.Kind == XdmValueKind.Boolean;
        bool rightIsBool = right.Kind == XdmValueKind.Boolean;
        if (leftIsBool || rightIsBool)
        {
            if (!leftIsBool) left = XdmValue.FromBoolean(left.GetEffectiveBooleanValue());
            if (!rightIsBool) right = XdmValue.FromBoolean(right.GetEffectiveBooleanValue());
            return;
        }

        bool leftIsNum = IsNumeric(left);
        bool rightIsNum = IsNumeric(right);
        if (leftIsNum || rightIsNum)
        {
            if (!leftIsNum) left = XdmValue.FromDouble(ToDoubleOrNaN(left));
            if (!rightIsNum) right = XdmValue.FromDouble(ToDoubleOrNaN(right));
            return;
        }

        // Otherwise both become strings (they already are after atomization)
    }

    /// <summary>
    /// Converts a value to double, returning NaN for unparseable strings
    /// (XPath 1.0 semantics) instead of throwing.
    /// </summary>
    private static double ToDoubleOrNaN(XdmValue value)
    {
        // XPath 1.0 backwards compatibility: a multi-item sequence converts via its
        // first item (backwards-024: 1 + (6 to 10) = 7); the empty sequence gives NaN.
        if (value.IsSequence && value.SequenceValue is not null)
            value = FirstItemOrUndefined(value);
        value = Atomize(value);
        return value.Kind switch
        {
            XdmValueKind.Integer => value.IntegerValue,
            XdmValueKind.Decimal => (double)value.DecimalValue,
            XdmValueKind.Double or XdmValueKind.Float => value.DoubleValue,
            XdmValueKind.Boolean => value.BooleanValue ? 1.0 : 0.0,
            _ => double.TryParse(value.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out var d) ? d : double.NaN
        };
    }

    private static bool IsNumeric(XdmValue value)
        => IsDouble(value) || IsFloat(value) || IsDecimal(value) || value.Kind == XdmValueKind.Integer;

    /// <summary>
    /// Resolves the (local, namespace) key under which a for/quantified loop variable is
    /// bound: resolved EQName URI if present, prefix resolved against the static context,
    /// otherwise the bare local name in no namespace.
    /// </summary>
    private static (string Local, string Ns) ResolveLoopVariableKey(QuantifiedLoopInfo info, EvaluationContext context)
    {
        if (info.VariableNamespaceUri is not null)
            return (info.VariableName, info.VariableNamespaceUri);
        if (info.VariablePrefix is not null)
            return ResolveVariableName($"{info.VariablePrefix}:{info.VariableName}", context);
        if (info.VariableName.Contains(':'))
            return ResolveVariableName(info.VariableName, context);
        return (info.VariableName, "");
    }

    // Entry value variable of an XPath 4.0 'for key value' binding, resolved the
    // same way as the primary loop variable.
    private static (string Local, string Ns) ResolveEntryValueVariableKey(QuantifiedLoopInfo info, EvaluationContext context)
    {
        if (info.EntryValueVariableNamespaceUri is not null)
            return (info.EntryValueVariableName!, info.EntryValueVariableNamespaceUri);
        if (info.EntryValueVariablePrefix is not null)
            return ResolveVariableName($"{info.EntryValueVariablePrefix}:{info.EntryValueVariableName}", context);
        if (info.EntryValueVariableName!.Contains(':'))
            return ResolveVariableName(info.EntryValueVariableName, context);
        return (info.EntryValueVariableName, "");
    }

    /// <summary>
    /// Converts a 'to' (range) operand to an integer per function conversion rules:
    /// xs:integer is accepted directly, xs:untypedAtomic is cast (FORG0001 on failure),
    /// anything else (including xs:decimal/xs:double) is XPTY0004.
    /// </summary>
    private static bool TryGetRangeOperand(XdmValue value, out decimal result)
    {
        result = 0;
        var atomized = Atomize(value);
        if (atomized.Kind == XdmValueKind.Integer)
        {
            result = atomized.IntegerValue;
            return true;
        }
        if (atomized.Kind == XdmValueKind.Decimal)
        {
            decimal d = atomized.DecimalValue;
            if (d != decimal.Truncate(d))
                return false;
            result = d;
            return true;
        }
        if (IsUntypedAtomic(atomized))
        {
            string s = atomized.ToString().Trim();
            if (decimal.TryParse(s, out var dec) && dec == decimal.Truncate(dec))
            {
                result = dec;
                return true;
            }
            throw new InvalidOperationException(
                $"FORG0001: Cannot cast xs:untypedAtomic '{s}' to xs:integer");
        }
        return false;
    }

    /// <summary>
    /// Validates that an arithmetic operand is numeric or xs:untypedAtomic after atomization.
    /// Date/time and duration operands must be handled by the caller before this check.
    /// Throws XPTY0004 for xs:string, xs:boolean and other non-numeric atomic types.
    /// </summary>
    private static void ValidateNumericOperand(XdmValue value)
    {
        var atomized = Atomize(value);
        if (atomized.IsUndefined)
            return; // empty-sequence operands are handled by the caller
        // Atomization of a map or function item is undefined (FOTY0013, ArrayTest-031/032).
        if (atomized.IsMap || atomized.IsFunction)
            throw new InvalidOperationException("FOTY0013: Cannot atomize a function item or map.");
        if (IsNumeric(atomized) || IsUntypedAtomic(atomized))
            return;
        throw new InvalidOperationException(
            $"XPTY0004: Arithmetic operands must be numeric or xs:untypedAtomic values, but got {atomized.Kind}");
    }

    private static bool IsUntypedAtomic(XdmValue value)
        => value.Kind == XdmValueKind.String &&
           string.Equals(value.SchemaTypeName, "untypedAtomic", StringComparison.OrdinalIgnoreCase);

    /// <summary>
    /// Casts an xs:untypedAtomic value to xs:QName, resolving any prefix against
    /// the static namespace context and using the default element namespace for
    /// unprefixed lexical QNames.
    /// </summary>
    private static XdmValue CastUntypedAtomicToQName(XdmValue value, EvaluationContext context)
    {
        string lexical = value.StringValue.Trim();
        if (string.IsNullOrEmpty(lexical))
            throw new InvalidOperationException("XPTY0004: Cannot cast empty xs:untypedAtomic value to xs:QName.");

        int colon = lexical.IndexOf(':');
        string prefix = colon >= 0 ? lexical[..colon] : string.Empty;
        string local = colon >= 0 ? lexical[(colon + 1)..] : lexical;

        if (!IsValidNcName(prefix) || !IsValidNcName(local))
            throw new InvalidOperationException("XPTY0004: Invalid lexical QName for cast to xs:QName.");

        string namespaceUri;
        if (string.IsNullOrEmpty(prefix))
        {
            namespaceUri = context.DefaultElementNamespace ?? string.Empty;
        }
        else
        {
            if (!context.TryResolveNamespace(prefix, out namespaceUri!))
                throw new InvalidOperationException($"XPTY0004: Namespace prefix '{prefix}' is not declared for xs:QName cast.");
        }

        return XdmValue.FromQName(new XsQName(local, namespaceUri, prefix));
    }

    private static bool IsValidNcName(string name)
    {
        if (string.IsNullOrEmpty(name))
            return true; // empty prefix is allowed
        if (!char.IsLetter(name[0]) && name[0] != '_')
            return false;
        for (int i = 1; i < name.Length; i++)
        {
            char c = name[i];
            if (!char.IsLetterOrDigit(c) && c != '.' && c != '-' && c != '_')
                return false;
        }
        return true;
    }

    // ------------------------------------------------------------------
    // Type operations
    // ------------------------------------------------------------------

    /// <summary>
    /// Casts a value to the named type using the XPath 3.1 §19 cast rules.
    /// </summary>
    /// <param name="value">The value to cast.</param>
    /// <param name="typeName">The target type name (e.g. <c>xs:integer</c>), optionally with an occurrence indicator.</param>
    /// <returns>The casted value.</returns>
    /// <exception cref="InvalidOperationException">The cast fails: XPTY0004 for a combination
    /// outside the §19.3 permitted-cast matrix, FOCA0002 for an out-of-range value, FORG0001
    /// for a lexical failure.</exception>
    public static XdmValue Cast(XdmValue value, string typeName)
        => Cast(value, typeName, null);

    /// <summary>
    /// Casts a value to the named type using the XPath 3.1 §19 cast rules.
    /// </summary>
    /// <param name="value">The value to cast.</param>
    /// <param name="typeName">The target type name (e.g. <c>xs:integer</c>), optionally with an occurrence indicator.</param>
    /// <param name="context">An optional evaluation context used for namespace resolution and user-defined schema types.</param>
    /// <returns>The casted value.</returns>
    /// <exception cref="InvalidOperationException">The cast fails: XPTY0004 for a combination
    /// outside the §19.3 permitted-cast matrix, FOCA0002 for an out-of-range value, FORG0001
    /// for a lexical failure.</exception>
    public static XdmValue Cast(XdmValue value, string typeName, EvaluationContext? context)
    {
        if (IsContainerCastTarget(typeName, context)) return CastContainer(value, typeName, context!);
        if (context is not null && context.TryResolveNamedRecordType(typeName, context.DefaultElementNamespace, out var named))
        {
            var inputs = MaterializeSequence(value);
            if (inputs.Length != 1 || !inputs[0].IsMap || context.NamedRecordCoercion is null)
                throw new InvalidOperationException("XPTY0004: A named record cast requires one map.");
            return XdmValue.FromMap(context.NamedRecordCoercion(named!, inputs[0].MapValue, true));
        }
        try
        {
            if (!TryCast(value, typeName, context, out var result, out var failureKind))
            {
                // XPath 3.1 §19: combinations outside the permitted-cast matrix are type
                // errors (XPTY0004), NaN/INF→integer/decimal is out-of-range (FOCA0002);
                // only lexical failures of permitted casts raise FORG0001.
                throw failureKind switch
                {
                    CastFailureKind.NotPermitted => new InvalidOperationException(
                        $"XPTY0004: The value '{value}' cannot be cast to {typeName}: the cast combination is not permitted (XPath 3.1 §19.3)."),
                    CastFailureKind.OutOfRange => new InvalidOperationException(
                        $"FOCA0002: The value '{value}' is out of range or not representable for {typeName}."),
                    _ => new InvalidOperationException($"FORG0001: Cannot cast '{value}' to {typeName}."),
                };
            }
            return result;
        }
        catch (OverflowException)
        {
            // Numeric conversion overflow maps to the spec code for the target family
            // (cbcl-cast-*: decimal/integer FOCA0001, date/time FODT0001, durations FODT0002).
            string code = normalizedCode(typeName) switch
            {
                "duration" or "yearmonthduration" or "daytimeduration" => "FODT0002",
                "datetime" or "date" or "time"
                    or "gyear" or "gyearmonth" or "gmonthday" or "gday" or "gmonth" => "FODT0001",
                "decimal" => "FOCA0001",
                _ => "FORG0001",
            };
            throw new InvalidOperationException($"{code}: The value '{value}' is out of range for {typeName}.");
        }

        static string normalizedCode(string name)
        {
            var n = name.Trim();
            if (n.EndsWith('?') || n.EndsWith('*') || n.EndsWith('+'))
                n = n[..^1].TrimEnd();
            int colon = n.IndexOf(':');
            if (colon >= 0 && !n.StartsWith("Q{", StringComparison.Ordinal))
                n = n[(colon + 1)..];
            return n.ToLowerInvariant();
        }
    }

    private static bool IsContainerCastTarget(string type, EvaluationContext? context)
        => context?.IsXPath40 == true && (type.StartsWith("array(", StringComparison.Ordinal) || type.StartsWith("map(", StringComparison.Ordinal));

    private static XdmValue CastContainer(XdmValue value, string type, EvaluationContext context)
    {
        type = type.Trim();
        var optional = type.EndsWith('?');
        if (optional) type = type[..^1].TrimEnd();
        var inputs = MaterializeSequence(value);
        if (inputs.Length == 0 && optional) return XdmValue.Undefined;
        if (inputs.Length != 1) throw new InvalidOperationException("XPTY0004: A container cast requires one item.");
        var input = inputs[0];
        if (type.StartsWith("array(", StringComparison.Ordinal))
        {
            if (!input.IsArray) throw new InvalidOperationException("XPTY0004: An array cast requires an array.");
            var memberType = type[6..^1].Trim();
            if (memberType == "*") return input;
            if (memberType.Length == 0)
            {
                if (input.ArrayValue.Count != 0) throw new InvalidOperationException("XPTY0004: An empty array is required.");
                return input;
            }
            var members = new XdmValue[input.ArrayValue.Count];
            for (int i = 0; i < members.Length; i++) members[i] = CastSequence(input.ArrayValue.Get(i + 1), memberType, context);
            return XdmValue.FromArray(new XdmArray(members));
        }
        if (!input.IsMap) throw new InvalidOperationException("XPTY0004: A map cast requires a map.");
        if (type == "map(*)") return input;
        if (type == "map()")
        {
            if (input.MapValue.Count != 0) throw new InvalidOperationException("XPTY0004: An empty map is required.");
            return input;
        }
        if (!TryGetMapTypeParts(type, out var keyType, out var valueType))
            throw new InvalidOperationException("XPST0003: Invalid map cast type.");
        var result = new XdmMap();
        foreach (var key in input.MapValue.Keys)
        {
            var castKey = CastSequence(key, keyType, context);
            if (result.TryGetValue(castKey, out _)) throw new InvalidOperationException("XQDY0137: A map cast produces duplicate keys.");
            input.MapValue.TryGetValue(key, out var entry);
            result.Add(castKey, CastSequence(entry, valueType, context));
        }
        return XdmValue.FromMap(result);
    }

    /// <summary>Casts each unmatched sequence item and validates the required cardinality.</summary>
    internal static XdmValue CastSequence(XdmValue value, string sequenceType, EvaluationContext context)
    {
        var parsed = (InstanceOfNode)XPathParser.Parse("() instance of " + sequenceType, xpath40: true);
        var type = string.IsNullOrEmpty(parsed.Prefix) ? parsed.TypeName : parsed.Prefix + ":" + parsed.TypeName;
        var inputs = MaterializeSequence(value);
        if (type == "empty-sequence()")
        {
            if (inputs.Length != 0) throw new InvalidOperationException("XPTY0004: An empty sequence is required.");
            return XdmValue.Undefined;
        }
        var converted = new List<XdmValue>(inputs.Length);
        foreach (var item in inputs) converted.Add(ValueMatchesType(item, type, context) ? item : Cast(item, type, context));
        if ((converted.Count == 0 && parsed.Occurrence is OccurrenceIndicator.One or OccurrenceIndicator.OneOrMore)
            || (converted.Count > 1 && parsed.Occurrence is OccurrenceIndicator.One or OccurrenceIndicator.ZeroOrOne))
            throw new InvalidOperationException("XPTY0004: Cast sequence cardinality does not match its declaration.");
        return converted.Count == 0 ? XdmValue.Undefined : converted.Count == 1 ? converted[0]
            : XdmValue.FromSequence(MaterializedSequence.FromList(converted));
    }

    /// <summary>
    /// Attempts to cast a value to the named type using the XPath 3.1 §19 cast rules.
    /// </summary>
    /// <param name="value">The value to cast.</param>
    /// <param name="typeName">The target type name (e.g. <c>xs:integer</c>), optionally with an occurrence indicator.</param>
    /// <param name="result">The casted value when the cast succeeds.</param>
    /// <returns><c>true</c> when the cast succeeds.</returns>
    public static bool TryCast(XdmValue value, string typeName, out XdmValue result)
        => TryCast(value, typeName, null, out result);

    /// <summary>
    /// Attempts to cast a value to the named type using the XPath 3.1 §19 cast rules.
    /// </summary>
    /// <param name="value">The value to cast.</param>
    /// <param name="typeName">The target type name (e.g. <c>xs:integer</c>), optionally with an occurrence indicator.</param>
    /// <param name="context">An optional evaluation context used for namespace resolution and user-defined schema types.</param>
    /// <param name="result">The casted value when the cast succeeds.</param>
    /// <returns><c>true</c> when the cast succeeds.</returns>
    public static bool TryCast(XdmValue value, string typeName, EvaluationContext? context, out XdmValue result)
        => TryCast(value, typeName, context, out result, out _);

    /// <summary>Distinguishes why a cast failed so <see cref="Cast(XdmValue, string, EvaluationContext)"/> can raise the spec-mandated code.</summary>
    private enum CastFailureKind
    {
        /// <summary>A permitted cast whose lexical form or value is invalid (FORG0001).</summary>
        Lexical,
        /// <summary>The source/target combination is outside the §19.3 permitted-cast matrix (XPTY0004).</summary>
        NotPermitted,
        /// <summary>A representable value is out of range for the target type, e.g. NaN/INF to integer (FOCA0002).</summary>
        OutOfRange,
    }

    // XPath 4.0 §4.19.2.7: casting to a record type. record(*) is an assertion that the
    // input already is a record (XPTY0004 otherwise). A typed record type reads the input
    // as a map (XPTY0004 when it is not a map): a present field value is kept when it
    // matches the field type, otherwise cast to it (a failed value cast is FORG0001); an
    // absent field becomes () with XPTY0004 when the field type requires a value; surplus
    // keys are DISCARDED (unlike coercion, §3.4.2 rule 10, which rejects them).
    private static bool TryCastToRecord(XdmValue value, string recordText, EvaluationContext? context, out XdmValue result, out CastFailureKind failureKind)
    {
        failureKind = CastFailureKind.NotPermitted;
        result = value;

        // The empty sequence casts to the empty sequence (handled here because this
        // branch runs before the general atomization/emptiness frame).
        if (value.IsSequence && value.SequenceValue is not null)
        {
            var items = MaterializeSequence(value);
            if (items.Length == 0)
            {
                result = XdmValue.Undefined;
                return true;
            }
            if (items.Length > 1)
                return false; // XPTY0004: more than one input item
            value = items[0];
        }
        if (value.IsUndefined)
        {
            result = XdmValue.Undefined;
            return true;
        }

        var target = TryGetRecordType(recordText);
        if (target is null)
            return false;
        if (!value.IsMap)
            return false; // XPTY0004: the input is not a map
        var map = value.MapValue;

        if (target.IsAny)
            return map.RecordType is not null; // assertion: the input must already be a record

        var casted = new XdmMap();
        foreach (var field in target.Fields)
        {
            if (map.TryGetValue(RecordFieldKey(field.Name), out var fieldValue))
            {
                if (ValueMatchesType(fieldValue, field.SequenceTypeText, context))
                {
                    casted.Add(RecordFieldKey(field.Name), fieldValue);
                }
                else if (context?.IsXPath40 == true)
                {
                    try { casted.Add(RecordFieldKey(field.Name), CastSequence(fieldValue, field.SequenceTypeText, context)); }
                    catch (InvalidOperationException error)
                    {
                        failureKind = error.Message.StartsWith("XPTY0004", StringComparison.Ordinal)
                            ? CastFailureKind.NotPermitted : CastFailureKind.Lexical;
                        return false;
                    }
                }
                else if (TryCast(fieldValue, field.SequenceTypeText, context, out var castField, out _))
                {
                    casted.Add(RecordFieldKey(field.Name), castField);
                }
                else
                {
                    failureKind = CastFailureKind.Lexical; // FORG0001
                    return false;
                }
            }
            else if (field.AllowsEmpty)
            {
                casted.Add(RecordFieldKey(field.Name), XdmValue.Undefined);
            }
            else
            {
                failureKind = CastFailureKind.NotPermitted; // XPTY0004
                return false;
            }
        }
        result = XdmValue.FromMap(casted.WithRecordType(target));
        return true;
    }

    private static bool TryCast(XdmValue value, string typeName, EvaluationContext? context, out XdmValue result, out CastFailureKind failureKind)
    {
        if (IsContainerCastTarget(typeName, context))
        {
            try { result = CastContainer(value, typeName, context!); failureKind = CastFailureKind.Lexical; return true; }
            catch (InvalidOperationException) { result = value; failureKind = CastFailureKind.NotPermitted; return false; }
        }
        if (context is not null && context.TryResolveNamedRecordType(typeName, context.DefaultElementNamespace, out _))
        {
            try { result = Cast(value, typeName, context); failureKind = CastFailureKind.Lexical; return true; }
            catch (InvalidOperationException) { result = value; failureKind = CastFailureKind.NotPermitted; return false; }
        }
        failureKind = CastFailureKind.Lexical;
        result = value;
        string normalized = typeName.ToLowerInvariant().Replace("xs:", "").Replace("xsd:", "");
        if (normalized.EndsWith('?') || normalized.EndsWith('*') || normalized.EndsWith('+'))
            normalized = normalized[..^1].TrimEnd();

        // XPath 4.0 §3.2.5/§3.2.6/§3.2.10: enum, choice, and record type texts are
        // structural, not QNames — prefix resolution (and its XPST0081 errors) must not
        // run on them.
        var castTargetText = typeName.Trim();
        if (castTargetText.EndsWith('?') || castTargetText.EndsWith('*') || castTargetText.EndsWith('+'))
            castTargetText = castTargetText[..^1].TrimEnd();
        bool isStructuralCastTarget = IsEnumOrChoiceTypeText(castTargetText) || IsRecordTypeText(castTargetText);

        var (resolvedNs, resolvedLocal) = isStructuralCastTarget
            ? default
            : ResolveTypeQName(typeName, context);

        // XPath 4.0 default ##any item types are resolved to schema EQNames by the compiler.
        if (context?.IsXPath40 == true && typeName.StartsWith("Q{", StringComparison.Ordinal)
            && resolvedNs == XmlSchema.Namespace)
            normalized = resolvedLocal.ToLowerInvariant();

        // A prefixed type name resolves via the in-scope namespaces (constructor-local
        // declarations included). If the prefix is bound to the XML Schema namespace,
        // normalize to the bare local name so the built-in type switch can match it.
        // Use the original-case prefix here; prefixes are case-sensitive and the
        // normalized string has been lowercased.
        if (typeName.Contains(':') && !typeName.Contains('{', StringComparison.Ordinal))
        {
            string original = typeName.Trim();
            if (original.EndsWith('?') || original.EndsWith('*') || original.EndsWith('+'))
                original = original[..^1].TrimEnd();
            int colon = original.IndexOf(':');
            if (colon > 0)
            {
                var typePrefix = original[..colon];
                if (context is not null && context.TryResolveNamespace(typePrefix, out var resolvedTypeNs))
                {
                    if (resolvedTypeNs == "http://www.w3.org/2001/XMLSchema")
                        normalized = original[(colon + 1)..].ToLowerInvariant();
                }
                // Non-XS prefixes are schema types or unknown; do not throw here:
                // ResolveTypeQName already reports XPST0081 for undeclared prefixes,
                // and the schema-type path below handles user-defined types.
            }
        }

        // XPath 4.0 §4.19.2.7 (casting to a record type): the input is a map — it must
        // NOT be atomized (maps otherwise raise FOTY0013), so this branch runs before
        // the atomization below. record(*) is an assertion that the input already is a
        // record (XPTY0004 otherwise); a typed record type coerces per field — present
        // values are kept when they match, otherwise cast to the field type (FORG0001 on
        // failure); absent fields become () with XPTY0004 when the field type requires a
        // value; surplus keys are DISCARDED (unlike coercion, §3.4.2 rule 10).
        if (IsRecordTypeText(castTargetText))
        {
            return TryCastToRecord(value, castTargetText, context, out result, out failureKind);
        }

        // Atomize the operand: arrays are recursively flattened, nodes are atomized,
        // and maps/function items raise FOTY0013 (per XPath 3.1 §18.2.1).
        // Update result so that casts of a node to its own typed value return the
        // atomic typed value rather than the original node.
        value = AtomizeForCast(value);
        result = value;

        // Empty sequence casts to empty sequence for all types
        if (value.IsUndefined)
        {
            result = XdmValue.Undefined;
            return true;
        }

        // If value is a sequence, only allow single-item sequences for atomic casts
        if (value.IsSequence)
        {
            if (TryGetSequenceLength(value.SequenceValue, out var seqLen))
            {
                if (seqLen == 0)
                {
                    result = XdmValue.Undefined;
                    return true;
                }
                if (seqLen != 1)
                {
                    // Casting a sequence of more than one item is a type error (XPTY0004),
                    // not a cast failure (K-SeqExprCast-145).
                    failureKind = CastFailureKind.NotPermitted;
                    return false;
                }
                var knownEnumerator = XdmSequence.FromSource(value.SequenceValue!).GetEnumerator();
                knownEnumerator.MoveNext();
                value = knownEnumerator.Current;
            }
            else
            {
                // Lazy sequence: at most two enumerated items decide the cardinality.
                var enumerator = XdmSequence.FromSource(value.SequenceValue!).GetEnumerator();
                if (!enumerator.MoveNext())
                {
                    result = XdmValue.Undefined;
                    return true;
                }
                var first = enumerator.Current;
                if (enumerator.MoveNext())
                {
                    // Same XPTY0004-as-NotPermitted rule as the known-length path.
                    failureKind = CastFailureKind.NotPermitted;
                    return false;
                }
                value = first;
            }
        }

        // XPath 4.0 §3.2.6: casting to an enumeration type. The atomized value is read
        // as a string (non-string atoms, xs:anyURI, and xs:untypedAtomic per §3.4.2
        // rule 05 are cast to xs:string first) and must equal a member by codepoints;
        // the result is a plain xs:string (enum types are structural, instances are
        // not re-annotated). A non-member is a lexical failure (FORG0001).
        if (TryGetEnumMembers(castTargetText) is { } enumMembers)
        {
            string memberText;
            if (value.Kind == XdmValueKind.String)
            {
                memberText = AtomizedString(value);
            }
            else if (!TryCast(value, "xs:string", context, out var asString, out _))
            {
                failureKind = CastFailureKind.Lexical;
                return false;
            }
            else
            {
                memberText = AtomizedString(asString);
            }
            if (enumMembers.Contains(memberText, StringComparer.Ordinal))
            {
                result = XdmValue.FromString(memberText);
                return true;
            }
            failureKind = CastFailureKind.Lexical;
            return false;
        }

        // XPath 4.0 §3.2.5 (with §3.4.2 rule 02 / F&O §23.3.7): casting to a choice
        // item type tries each alternative in declaration order — a value already
        // matching an alternative is returned unchanged, otherwise the first
        // successful cast to an atomic alternative wins; when every alternative
        // fails the cast fails lexically (FORG0001).
        if (TryGetChoiceAlternatives(castTargetText, out var choiceAlternatives))
        {
            foreach (var alternative in choiceAlternatives)
            {
                bool matched;
                try
                {
                    matched = ValueMatchesType(value, alternative, context);
                }
                catch (InvalidOperationException)
                {
                    matched = false;
                }
                if (matched)
                {
                    result = value;
                    return true;
                }
                if (IsNonAtomicCastAlternative(alternative))
                    continue;
                try
                {
                    if (TryCast(value, alternative, context, out var coerced, out _))
                    {
                        result = coerced;
                        return true;
                    }
                }
                catch (InvalidOperationException) { }
                catch (OverflowException) { }
            }
            failureKind = CastFailureKind.Lexical;
            return false;
        }

        // Schema-imported simple types (not built-in xs:*): unions, lists, and atomic
        // restrictions are handled recursively with XPath cast semantics.
        if (resolvedNs != XmlSchema.Namespace && TryGetSchemaSimpleType(resolvedNs, resolvedLocal, context, out var schemaSimpleType))
        {
            return TryCastToSchemaType(value, schemaSimpleType, context, out result);
        }

        // An unprefixed type name resolves against the default element namespace: when it
        // is set and is not the XML Schema namespace, the name is not a built-in type
        // (XQST0052, K2-DefaultNamespaceProlog-12a — '2 cast as byte' under the XSL namespace).
        if (!typeName.Contains(':') && !typeName.StartsWith("Q{", StringComparison.Ordinal)
            && context is not null
            && !string.IsNullOrEmpty(context.DefaultElementNamespace)
            && context.DefaultElementNamespace != "http://www.w3.org/2001/XMLSchema")
        {
            throw new InvalidOperationException($"XQST0052: The type '{typeName}' is not a known simple type in the namespace '{context.DefaultElementNamespace}'.");
        }

        // Prefixed name that is not xs:* and not a schema type is XPST0051.
        if (resolvedNs != "http://www.w3.org/2001/XMLSchema"
            && typeName.Contains(':')
            && !typeName.StartsWith("Q{", StringComparison.Ordinal))
        {
            throw new InvalidOperationException("XPST0051");
        }

        // Unknown xs:* cast target: XQST0052 (matches the lowerer's static check and
        // K-SeqExprCast-9a). User-defined simple types resolved above via
        // TryGetSchemaSimpleType. (XSD list types such as NMTOKENS resolve through the
        // schema path; their residual miscodes are recorded as known gaps.)
        if (resolvedNs == XmlSchema.Namespace
            && !BuiltInSchemaTypes.Any(t => string.Equals(t, resolvedLocal, StringComparison.OrdinalIgnoreCase)))
        {
            throw new InvalidOperationException($"XQST0052: The type '{typeName}' is not a known schema type.");
        }

        // xs:error has no instances: a cast to it always fails (FORG0001 via the lexical
        // classification, xs-error-050/051) — before the §19.3 matrix would misclassify it
        // as a not-permitted combination.
        if (normalized == "error")
        {
            failureKind = CastFailureKind.Lexical;
            return false;
        }

        // XPath 3.1 §19.3 permitted-cast matrix: combinations outside the matrix are
        // type errors (XPTY0004) for 'cast as' and simply false for 'castable as' —
        // never FORG0001. The source family is derived from the runtime kind plus any
        // schema type annotation (plain xs:float etc. carry no annotation).
        if (!IsCastCombinationPermitted(GetCastSourceFamily(value), normalized))
        {
            failureKind = CastFailureKind.NotPermitted;
            return false;
        }

        switch (normalized)
        {
            case "string":
                result = XdmValue.FromString(value.ToString());
                return true;

            case "integer":
            case "int":
            case "long":
            case "short":
            case "byte":
            case "unsignedshort":
            case "unsignedint":
            case "unsignedlong":
            case "unsignedbyte":
            case "positiveinteger":
            case "negativeinteger":
            case "nonpositiveinteger":
            case "nonnegativeinteger":
                // xs:unsignedLong values can exceed long.MaxValue; handle them with decimal backing.
                if (normalized == "unsignedlong")
                {
                    if (value.Kind == XdmValueKind.Integer)
                    {
                        if (value.IntegerValue < 0) return false;
                        result = XdmValue.FromInteger(value.IntegerValue, normalized);
                        return true;
                    }
                    if (value.Kind == XdmValueKind.Decimal)
                    {
                        // Numeric integer casts discard the fraction before derived-type range checks.
                        decimal d = decimal.Truncate(value.DecimalValue);
                        if (d < 0 || d > ulong.MaxValue) return false;
                        if (d <= long.MaxValue)
                            result = XdmValue.FromInteger((long)d, normalized);
                        else
                            result = XdmValue.FromDecimal(d, normalized);
                        return true;
                    }
                    if (value.Kind == XdmValueKind.Double || value.Kind == XdmValueKind.Float)
                    {
                        double d = value.DoubleValue;
                        if (double.IsNaN(d) || double.IsInfinity(d))
                        {
                            failureKind = CastFailureKind.OutOfRange;
                            return false;
                        }
                        // Discard finite fractions before applying the unsigned range facets.
                        d = Math.Truncate(d);
                        // MaxValue rounds upward when converted to double; compare exact binary thresholds.
                        if (d < 0 || d >= 18446744073709551616d) return false; // 2^64, exclusive
                        if (d < 9223372036854775808d) // 2^63, exclusive for signed backing
                            result = XdmValue.FromInteger((long)d, normalized);
                        else
                            // Above 2^63 every representable floating value is integral. Convert through
                            // UInt64 so the double-to-decimal rounding policy cannot change its magnitude.
                            result = XdmValue.FromDecimal((decimal)(ulong)d, normalized);
                        return true;
                    }
                    if (value.Kind == XdmValueKind.Boolean)
                    {
                        result = XdmValue.FromInteger(value.BooleanValue ? 1 : 0, normalized);
                        return true;
                    }
                    if (value.Kind is XdmValueKind.Date or XdmValueKind.Time or XdmValueKind.DateTime
                        or XdmValueKind.Duration or XdmValueKind.QName or XdmValueKind.Node)
                        return false;
                    string s = value.ToString().Trim();
                    if (s.StartsWith('+')) s = s[1..];
                    if (ulong.TryParse(s, out var uInt))
                    {
                        if (uInt <= (ulong)long.MaxValue)
                            result = XdmValue.FromInteger((long)uInt, normalized);
                        else
                            result = XdmValue.FromDecimal((decimal)uInt, normalized);
                        return true;
                    }
                    return false;
                }

                if (value.Kind == XdmValueKind.Integer)
                {
                    if (!IsIntegerInRange(value.IntegerValue, normalized))
                        return false;
                    result = XdmValue.FromInteger(value.IntegerValue, normalized);
                    return true;
                }
                if (value.Kind == XdmValueKind.Decimal)
                {
                    long lVal = (long)value.DecimalValue;
                    if (!IsIntegerInRange(lVal, normalized))
                        return false;
                    result = XdmValue.FromInteger(lVal, normalized);
                    return true;
                }
                if (value.Kind == XdmValueKind.Double || value.Kind == XdmValueKind.Float)
                {
                    double d = value.DoubleValue;
                    if (double.IsNaN(d) || double.IsInfinity(d))
                    {
                        failureKind = CastFailureKind.OutOfRange;
                        return false;
                    }
                    if (d >= 9223372036854775808d || d < -9223372036854775808d)
                        throw new InvalidOperationException("FOCA0003");
                    long lDbl = (long)d;
                    if (!IsIntegerInRange(lDbl, normalized))
                        return false;
                    result = XdmValue.FromInteger(lDbl, normalized);
                    return true;
                }
                if (value.Kind == XdmValueKind.Boolean)
                {
                    long lBool = value.BooleanValue ? 1 : 0;
                    if (!IsIntegerInRange(lBool, normalized))
                        return false;
                    result = XdmValue.FromInteger(lBool, normalized);
                    return true;
                }
                if (value.Kind is XdmValueKind.Date or XdmValueKind.Time or XdmValueKind.DateTime
                    or XdmValueKind.Duration or XdmValueKind.QName or XdmValueKind.Node)
                    return false;
                if (long.TryParse(value.ToString().Trim(), out var lInt))
                {
                    if (!IsIntegerInRange(lInt, normalized))
                        return false;
                    result = XdmValue.FromInteger(lInt, normalized);
                    return true;
                }
                return false;

            case "decimal":
                if (value.Kind == XdmValueKind.Decimal)
                    return true;
                if (value.Kind == XdmValueKind.Integer)
                {
                    result = XdmValue.FromDecimal(value.IntegerValue);
                    return true;
                }
                if (value.Kind == XdmValueKind.Double || value.Kind == XdmValueKind.Float)
                {
                    double d = value.DoubleValue;
                    if (double.IsNaN(d) || double.IsInfinity(d))
                    {
                        failureKind = CastFailureKind.OutOfRange;
                        return false;
                    }
                    result = XdmValue.FromDecimal((decimal)d);
                    return true;
                }
                if (value.Kind == XdmValueKind.Boolean)
                {
                    result = XdmValue.FromDecimal(value.BooleanValue ? 1m : 0m);
                    return true;
                }
                if (value.Kind is XdmValueKind.Date or XdmValueKind.Time or XdmValueKind.DateTime
                    or XdmValueKind.Duration or XdmValueKind.QName or XdmValueKind.Node)
                    return false;
                {
                    string sDec = value.ToString();
                    // xs:decimal does not allow exponent notation
                    if (sDec.Contains('e', StringComparison.OrdinalIgnoreCase))
                        return false;
                    if (decimal.TryParse(sDec, NumberStyles.Any, CultureInfo.InvariantCulture, out var dec))
                    {
                        result = XdmValue.FromDecimal(dec);
                        return true;
                    }
                }
                return false;

            case "double":
                if (value.Kind == XdmValueKind.Double)
                    return true;
                if (value.Kind == XdmValueKind.Float)
                {
                    result = XdmValue.FromDouble(value.DoubleValue);
                    return true;
                }
                if (value.Kind == XdmValueKind.Integer)
                {
                    result = XdmValue.FromDouble(value.IntegerValue);
                    return true;
                }
                if (value.Kind == XdmValueKind.Decimal)
                {
                    result = XdmValue.FromDouble((double)value.DecimalValue);
                    return true;
                }
                if (value.Kind == XdmValueKind.Boolean)
                {
                    result = XdmValue.FromDouble(value.BooleanValue ? 1.0 : 0.0);
                    return true;
                }
                if (value.Kind is XdmValueKind.Date or XdmValueKind.Time or XdmValueKind.DateTime
                    or XdmValueKind.Duration or XdmValueKind.QName or XdmValueKind.Node)
                    return false;
                if (TryParseDouble(value.ToString(), out var dbl))
                {
                    result = XdmValue.FromDouble(dbl);
                    return true;
                }
                return false;

            case "float":
                if (value.Kind == XdmValueKind.Float)
                    return true;
                if (value.Kind == XdmValueKind.Double)
                {
                    result = XdmValue.FromFloat((float)value.DoubleValue);
                    return true;
                }
                if (value.Kind == XdmValueKind.Integer)
                {
                    result = XdmValue.FromFloat(value.IntegerValue);
                    return true;
                }
                if (value.Kind == XdmValueKind.Decimal)
                {
                    result = XdmValue.FromFloat((float)value.DecimalValue);
                    return true;
                }
                if (value.Kind == XdmValueKind.Boolean)
                {
                    result = XdmValue.FromFloat(value.BooleanValue ? 1.0f : 0.0f);
                    return true;
                }
                if (value.Kind is XdmValueKind.Date or XdmValueKind.Time or XdmValueKind.DateTime
                    or XdmValueKind.Duration or XdmValueKind.QName or XdmValueKind.Node)
                    return false;
                if (TryParseFloat(value.ToString(), out var flt))
                {
                    result = XdmValue.FromFloat(flt);
                    return true;
                }
                return false;

            case "numeric":
                // xs:numeric is a union type of xs:double, xs:float, xs:decimal.
                // Casting from a member type preserves the source type; casting from
                // string, untypedAtomic, or boolean yields xs:double.
                if (value.Kind is XdmValueKind.Integer or XdmValueKind.Decimal or XdmValueKind.Double or XdmValueKind.Float)
                {
                    result = value;
                    return true;
                }
                if (value.Kind == XdmValueKind.Boolean)
                {
                    result = XdmValue.FromDouble(value.BooleanValue ? 1.0 : 0.0);
                    return true;
                }
                if (value.Kind is XdmValueKind.Date or XdmValueKind.Time or XdmValueKind.DateTime
                    or XdmValueKind.Duration or XdmValueKind.QName or XdmValueKind.Node)
                    return false;
                if (TryParseDouble(value.ToString(), out var numericDbl))
                {
                    result = XdmValue.FromDouble(numericDbl);
                    return true;
                }
                return false;

            case "boolean":
                if (value.Kind == XdmValueKind.Boolean)
                    return true;
                if (value.Kind == XdmValueKind.String)
                {
                    // xs:boolean lexical values are case-sensitive: true, false, 0, 1.
                    var s = CollapseWhitespace(value.StringValue);
                    if (s == "true" || s == "1")
                    {
                        result = XdmValue.True;
                        return true;
                    }
                    if (s == "false" || s == "0")
                    {
                        result = XdmValue.False;
                        return true;
                    }
                    return false;
                }
                if (value.Kind == XdmValueKind.Integer)
                {
                    result = XdmValue.FromBoolean(value.IntegerValue != 0);
                    return true;
                }
                if (value.Kind == XdmValueKind.Decimal)
                {
                    result = XdmValue.FromBoolean(value.DecimalValue != 0m);
                    return true;
                }
                if (value.Kind == XdmValueKind.Double || value.Kind == XdmValueKind.Float)
                {
                    double d = value.DoubleValue;
                    result = XdmValue.FromBoolean(d != 0.0 && !double.IsNaN(d));
                    return true;
                }
                return false;

            case "datetime":
                if (value.Kind == XdmValueKind.DateTime)
                    return true;
                if (value.Kind == XdmValueKind.Date)
                {
                    var xdtSrc = value.DateXPathValue;
                    result = XdmValue.FromDateTime(new XPathDateTime(xdtSrc.Year, xdtSrc.Month, xdtSrc.Day, 0, 0, 0, 0, xdtSrc.TimezoneOffsetMinutes, value.HasTimezone), value.HasTimezone);
                    return true;
                }
                if (value.Kind == XdmValueKind.Time)
                    return false;
                {
                    string sDt = NormalizeDateTimeString(value.ToString().Trim());
                    if (TryParseXPathDateTime(sDt, out var xdtDt, out var hasTzDt))
                    {
                        if (xdtDt.IsRepresentableAsDateTimeOffset && DateTimeOffset.TryParse(sDt, out var dtoDt))
                        {
                            result = XdmValue.FromDateTime(dtoDt, hasTzDt);
                        }
                        else
                        {
                            result = XdmValue.FromDateTime(xdtDt, hasTzDt);
                        }
                        return true;
                    }
                }
                return false;

            case "datetimestamp":
                if (value.Kind == XdmValueKind.DateTime && value.HasTimezone)
                {
                    result = XdmValue.FromDateTime(value.DateTimeXPathValue, hasTimezone: true, schemaTypeName: "dateTimeStamp");
                    return true;
                }
                if (value.Kind == XdmValueKind.Date)
                {
                    if (!value.HasTimezone) return false;
                    var xdtSrcStamp = value.DateXPathValue;
                    result = XdmValue.FromDateTime(
                        new XPathDateTime(xdtSrcStamp.Year, xdtSrcStamp.Month, xdtSrcStamp.Day, 0, 0, 0, 0, xdtSrcStamp.TimezoneOffsetMinutes, true),
                        hasTimezone: true,
                        schemaTypeName: "dateTimeStamp");
                    return true;
                }
                if (value.Kind == XdmValueKind.Time)
                    return false;
                {
                    string sStamp = NormalizeDateTimeString(value.ToString().Trim());
                    if (TryParseXPathDateTime(sStamp, out var xdtStamp, out var hasTzStamp))
                    {
                        if (!hasTzStamp) return false;
                        if (xdtStamp.IsRepresentableAsDateTimeOffset && DateTimeOffset.TryParse(sStamp, out var dtoStamp))
                        {
                            result = XdmValue.FromDateTime(dtoStamp, hasTimezone: true, schemaTypeName: "dateTimeStamp");
                        }
                        else
                        {
                            result = XdmValue.FromDateTime(xdtStamp, hasTimezone: true, schemaTypeName: "dateTimeStamp");
                        }
                        return true;
                    }
                }
                return false;

            case "date":
                if (value.Kind == XdmValueKind.Date)
                    return true;
                if (value.Kind == XdmValueKind.DateTime)
                {
                    bool hasTz = value.HasTimezone;
                    var xdtDt = value.DateTimeXPathValue;
                    result = XdmValue.FromDate(new XPathDateTime(xdtDt.Year, xdtDt.Month, xdtDt.Day, 0, 0, 0, 0, xdtDt.TimezoneOffsetMinutes, hasTz), hasTz);
                    return true;
                }
                if (value.Kind == XdmValueKind.Time)
                    return false;
                {
                    string sD = NormalizeDateTimeString(value.ToString().Trim());
                    if (TryParseXPathDate(sD, out var xdtD, out var hasTzD))
                    {
                        if (xdtD.IsRepresentableAsDateTimeOffset && DateTimeOffset.TryParse(sD, out var dtoD))
                        {
                            result = XdmValue.FromDate(dtoD, hasTzD);
                        }
                        else
                        {
                            result = XdmValue.FromDate(xdtD, hasTzD);
                        }
                        return true;
                    }
                    // Fallback for backward compatibility with dateTime-shaped strings cast to date
                    // (removed - DateTimeOffset.TryParse is too lenient and accepts invalid formats)
                }
                return false;

            case "time":
                if (value.Kind == XdmValueKind.Time)
                    return true;
                if (value.Kind == XdmValueKind.DateTime)
                {
                    var xdtDt = value.DateTimeXPathValue;
                    bool hasTz = value.HasTimezone;
                    result = XdmValue.FromTime(new XPathDateTime(1, 1, 1, xdtDt.Hour, xdtDt.Minute, xdtDt.Second, xdtDt.Millisecond, xdtDt.TimezoneOffsetMinutes, hasTz), hasTz);
                    return true;
                }
                if (value.Kind == XdmValueKind.Date)
                    return false;
                {
                    string sT = NormalizeDateTimeString(value.ToString().Trim());
                    if (TryParseXPathTime(sT, out var xdtT, out var hasTzT))
                    {
                        result = XdmValue.FromTime(xdtT, hasTzT);
                        return true;
                    }
                    // Fallback for backward compatibility with dateTime-shaped strings cast to time
                    // (removed - DateTimeOffset.TryParse is too lenient and accepts invalid formats)
                }
                return false;

            case "untypedatomic":
                result = XdmValue.FromString(value.ToString(), "untypedAtomic");
                return true;

            case "anyuri":
                if (value.Kind is XdmValueKind.Integer or XdmValueKind.Decimal or XdmValueKind.Double
                    or XdmValueKind.Float or XdmValueKind.Boolean or XdmValueKind.Date
                    or XdmValueKind.Time or XdmValueKind.DateTime or XdmValueKind.Duration
                    or XdmValueKind.QName or XdmValueKind.Node)
                    return false;
                {
                    // XML Schema anyURI has whiteSpace="collapse"
                    string sUri = CollapseWhitespace(value.ToString());
                    // Reject invalid percent-encoding sequences
                    if (!IsValidAnyUri(sUri))
                        return false;
                    result = XdmValue.FromString(sUri, "anyURI");
                    return true;
                }

            case "base64binary":
                if (value.Kind is XdmValueKind.Date or XdmValueKind.Time or XdmValueKind.DateTime
                    or XdmValueKind.Duration or XdmValueKind.QName or XdmValueKind.Integer
                    or XdmValueKind.Decimal or XdmValueKind.Double or XdmValueKind.Float
                    or XdmValueKind.Boolean or XdmValueKind.Node)
                    return false;
                {
                    string sB64 = value.ToString();
                    // Cross-cast from hexBinary: decode hex to bytes, encode as base64
                    if (value.SchemaTypeName is not null && value.SchemaTypeName.Equals("hexBinary", StringComparison.OrdinalIgnoreCase))
                    {
                        string hex = sB64.Replace(" ", "").Replace("\t", "").Replace("\r", "").Replace("\n", "");
                        try
                        {
                            byte[] bytes = Convert.FromHexString(hex);
                            result = XdmValue.FromString(Convert.ToBase64String(bytes), "base64Binary");
                            return true;
                        }
                        catch
                        {
                            return false;
                        }
                    }
                    string normalizedB64 = sB64.Replace(" ", "").Replace("\t", "").Replace("\r", "").Replace("\n", "");
                    if (!IsValidBase64(normalizedB64))
                        return false;
                    result = XdmValue.FromString(normalizedB64, "base64Binary");
                    return true;
                }

            case "hexbinary":
                if (value.Kind is XdmValueKind.Date or XdmValueKind.Time or XdmValueKind.DateTime
                    or XdmValueKind.Duration or XdmValueKind.QName or XdmValueKind.Integer
                    or XdmValueKind.Decimal or XdmValueKind.Double or XdmValueKind.Float
                    or XdmValueKind.Boolean or XdmValueKind.Node)
                    return false;
                {
                    string sHex = value.ToString().Replace(" ", "").Replace("\t", "").Replace("\r", "").Replace("\n", "");
                    // Cross-cast from base64Binary: decode base64 to bytes, encode as hex
                    if (value.SchemaTypeName is not null && value.SchemaTypeName.Equals("base64Binary", StringComparison.OrdinalIgnoreCase))
                    {
                        try
                        {
                            byte[] bytes = Convert.FromBase64String(sHex);
                            result = XdmValue.FromString(Convert.ToHexString(bytes), "hexBinary");
                            return true;
                        }
                        catch
                        {
                            return false;
                        }
                    }
                    if (!Regex.IsMatch(sHex, @"^[0-9a-fA-F]*$"))
                        return false;
                    if (sHex.Length % 2 != 0)
                        return false;
                    result = XdmValue.FromString(sHex.ToUpperInvariant(), "hexBinary");
                    return true;
                }

            case "duration":
                if (value.Kind == XdmValueKind.Duration)
                {
                    // Casting to the generic xs:duration type ensures subsequent operator
                    // dispatch can distinguish it from the yearMonth/dayTime subtypes.
                    result = XdmValue.FromDuration(value.DurationValue, "duration");
                    return true;
                }
                {
                    string sDur = value.ToString().Trim();
                    if (IsValidDuration(sDur))
                    {
                        result = XdmValue.FromDuration(CanonicalizeDuration(sDur), "duration");
                        return true;
                    }
                }
                return false;

            case "yearmonthduration":
                if (value.Kind == XdmValueKind.Duration)
                {
                    result = XdmValue.FromDuration(ExtractYearMonthDuration(value.DurationValue), "yearMonthDuration");
                    return true;
                }
                {
                    string sYm = value.ToString().Trim();
                    if (IsValidYearMonthDuration(sYm))
                    {
                        result = XdmValue.FromDuration(ExtractYearMonthDuration(sYm), "yearMonthDuration");
                        return true;
                    }
                }
                return false;

            case "daytimeduration":
                if (value.Kind == XdmValueKind.Duration)
                {
                    result = XdmValue.FromDuration(ExtractDayTimeDuration(value.DurationValue), "dayTimeDuration");
                    return true;
                }
                {
                    string sDt = value.ToString().Trim();
                    if (IsValidDayTimeDuration(sDt))
                    {
                        result = XdmValue.FromDuration(ExtractDayTimeDuration(sDt), "dayTimeDuration");
                        return true;
                    }
                }
                return false;

            case "gyear":
                if (value.Kind is XdmValueKind.Integer or XdmValueKind.Decimal or XdmValueKind.Double
                    or XdmValueKind.Float or XdmValueKind.Boolean or XdmValueKind.Duration
                    or XdmValueKind.QName or XdmValueKind.Node)
                    return false;
                if (value.Kind == XdmValueKind.DateTime || value.Kind == XdmValueKind.Date)
                {
                    var xdtY = value.Kind == XdmValueKind.DateTime ? value.DateTimeXPathValue : value.DateXPathValue;
                    string tz = xdtY.FormatTimezone();
                    result = XdmValue.FromString($"{xdtY.FormatYear()}{tz}", "gYear");
                    return true;
                }
                {
                    string s = value.ToString().Trim();
                    var m = Regex.Match(s, @"^(-?)(\d{4,})((?:[Zz]|[+\-]\d{2}:\d{2})?)$");
                    if (m.Success)
                    {
                        string sign = m.Groups[1].Value;
                        string yearStr = m.Groups[2].Value;
                        string tz = m.Groups[3].Value;
                        // Reject leading zeros for years longer than 4 digits
                        if (yearStr.Length > 4 && yearStr[0] == '0')
                            return false;
                        // Validate and normalize timezone
                        if (!string.IsNullOrEmpty(tz))
                        {
                            if (tz.Equals("Z", StringComparison.OrdinalIgnoreCase))
                            {
                                tz = "Z";
                            }
                            else
                            {
                                int tzHour = int.Parse(tz[1..3], CultureInfo.InvariantCulture);
                                int tzMin = int.Parse(tz[4..6], CultureInfo.InvariantCulture);
                                if (tzHour > 14 || (tzHour == 14 && tzMin > 0) || tzMin > 59)
                                    return false;
                                if (tzHour == 0 && tzMin == 0)
                                    tz = "Z";
                            }
                        }
                        // Reject years too large to fit in long (overflow)
                        if (yearStr.Length > 18)
                            return false;
                        // Normalize -0000 to 0000
                        if (sign == "-" && yearStr.TrimStart('0') == "")
                        {
                            sign = "";
                            yearStr = "0000";
                        }
                        result = XdmValue.FromString(sign + yearStr + tz, "gYear");
                        return true;
                    }
                }
                return false;

            case "gyearmonth":
                if (value.Kind is XdmValueKind.Integer or XdmValueKind.Decimal or XdmValueKind.Double
                    or XdmValueKind.Float or XdmValueKind.Boolean or XdmValueKind.Duration
                    or XdmValueKind.QName or XdmValueKind.Node)
                    return false;
                if (value.Kind == XdmValueKind.DateTime || value.Kind == XdmValueKind.Date)
                {
                    var xdtYm = value.Kind == XdmValueKind.DateTime ? value.DateTimeXPathValue : value.DateXPathValue;
                    string tz = xdtYm.FormatTimezone();
                    result = XdmValue.FromString($"{xdtYm.FormatYear()}-{xdtYm.Month:00}{tz}", "gYearMonth");
                    return true;
                }
                {
                    string s = value.ToString().Trim();
                    var m = Regex.Match(s, @"^(-?)(\d{4,})-(\d{2})((?:[Zz]|[+\-]\d{2}:\d{2})?)$");
                    if (m.Success)
                    {
                        string sign = m.Groups[1].Value;
                        string yearStr = m.Groups[2].Value;
                        string monthStr = m.Groups[3].Value;
                        if (!int.TryParse(monthStr, out int monthVal) || monthVal < 1 || monthVal > 12)
                            return false;
                        string rest = $"-{monthStr}{m.Groups[4].Value}";
                        // Reject leading zeros for years longer than 4 digits
                        if (yearStr.Length > 4 && yearStr[0] == '0')
                            return false;
                        // Validate and normalize timezone
                        string tz = rest[3..]; // after -MM
                        if (!string.IsNullOrEmpty(tz))
                        {
                            if (tz.Equals("Z", StringComparison.OrdinalIgnoreCase))
                            {
                                rest = rest[..3] + "Z";
                            }
                            else
                            {
                                int tzHour = int.Parse(tz[1..3], CultureInfo.InvariantCulture);
                                int tzMin = int.Parse(tz[4..6], CultureInfo.InvariantCulture);
                                if (tzHour > 14 || (tzHour == 14 && tzMin > 0) || tzMin > 59)
                                    return false;
                                if (tzHour == 0 && tzMin == 0)
                                    rest = rest[..3] + "Z";
                            }
                        }
                        // Reject years too large to fit in long (overflow)
                        if (yearStr.Length > 18)
                            return false;
                        // Normalize -0000 to 0000
                        if (sign == "-" && yearStr.TrimStart('0') == "")
                        {
                            sign = "";
                            yearStr = "0000";
                        }
                        result = XdmValue.FromString(sign + yearStr + rest, "gYearMonth");
                        return true;
                    }
                }
                return false;

            case "gmonthday":
                if (value.Kind is XdmValueKind.Integer or XdmValueKind.Decimal or XdmValueKind.Double
                    or XdmValueKind.Float or XdmValueKind.Boolean or XdmValueKind.Duration
                    or XdmValueKind.QName or XdmValueKind.Node)
                    return false;
                if (value.Kind == XdmValueKind.DateTime || value.Kind == XdmValueKind.Date)
                {
                    var xdtMd = value.Kind == XdmValueKind.DateTime ? value.DateTimeXPathValue : value.DateXPathValue;
                    string tz = xdtMd.FormatTimezone();
                    result = XdmValue.FromString($"--{xdtMd.Month:00}-{xdtMd.Day:00}{tz}", "gMonthDay");
                    return true;
                }
                {
                    string s = value.ToString().Trim();
                    var m = Regex.Match(s, @"^--(\d{2})-(\d{2})((?:[Zz]|[+\-]\d{2}:\d{2})?)$");
                    if (m.Success)
                    {
                        if (!int.TryParse(m.Groups[1].Value, out int month) || month < 1 || month > 12)
                            return false;
                        if (!int.TryParse(m.Groups[2].Value, out int day) || day < 1 || day > 31)
                            return false;
                        // Validate days per month (Feb max 29, Apr/Jun/Sep/Nov max 30)
                        int maxDay = month == 2 ? 29 : (month is 4 or 6 or 9 or 11 ? 30 : 31);
                        if (day > maxDay) return false;
                        string tz = m.Groups[3].Value;
                        string? normalizedTz = NormalizeTimezone(tz);
                        if (normalizedTz is null) return false;
                        result = XdmValue.FromString($"--{m.Groups[1].Value}-{m.Groups[2].Value}{normalizedTz}", "gMonthDay");
                        return true;
                    }
                }
                return false;

            case "gday":
                if (value.Kind is XdmValueKind.Integer or XdmValueKind.Decimal or XdmValueKind.Double
                    or XdmValueKind.Float or XdmValueKind.Boolean or XdmValueKind.Duration
                    or XdmValueKind.QName or XdmValueKind.Node)
                    return false;
                if (value.Kind == XdmValueKind.DateTime || value.Kind == XdmValueKind.Date)
                {
                    var xdtD = value.Kind == XdmValueKind.DateTime ? value.DateTimeXPathValue : value.DateXPathValue;
                    string tz = xdtD.FormatTimezone();
                    result = XdmValue.FromString($"---{xdtD.Day:00}{tz}", "gDay");
                    return true;
                }
                {
                    string s = value.ToString().Trim();
                    var m = Regex.Match(s, @"^---(\d{2})((?:[Zz]|[+\-]\d{2}:\d{2})?)$");
                    if (m.Success)
                    {
                        if (!int.TryParse(m.Groups[1].Value, out int day) || day < 1 || day > 31)
                            return false;
                        string tz = m.Groups[2].Value;
                        string? normalizedTz = NormalizeTimezone(tz);
                        if (normalizedTz is null) return false;
                        result = XdmValue.FromString($"---{m.Groups[1].Value}{normalizedTz}", "gDay");
                        return true;
                    }
                }
                return false;

            case "gmonth":
                if (value.Kind is XdmValueKind.Integer or XdmValueKind.Decimal or XdmValueKind.Double
                    or XdmValueKind.Float or XdmValueKind.Boolean or XdmValueKind.Duration
                    or XdmValueKind.QName or XdmValueKind.Node)
                    return false;
                if (value.Kind == XdmValueKind.DateTime || value.Kind == XdmValueKind.Date)
                {
                    var xdtM = value.Kind == XdmValueKind.DateTime ? value.DateTimeXPathValue : value.DateXPathValue;
                    string tz = xdtM.FormatTimezone();
                    result = XdmValue.FromString($"--{xdtM.Month:00}{tz}", "gMonth");
                    return true;
                }
                {
                    string s = value.ToString().Trim();
                    var m = Regex.Match(s, @"^--(\d{2})((?:[Zz]|[+\-]\d{2}:\d{2})?)$");
                    if (m.Success)
                    {
                        if (!int.TryParse(m.Groups[1].Value, out int month) || month < 1 || month > 12)
                            return false;
                        string tz = m.Groups[2].Value;
                        string? normalizedTz = NormalizeTimezone(tz);
                        if (normalizedTz is null) return false;
                        result = XdmValue.FromString($"--{m.Groups[1].Value}{normalizedTz}", "gMonth");
                        return true;
                    }
                }
                return false;

            case "ncname":
            case "id":
            case "idref":
            case "entity":
            {
                // xs:string-derived atomic types only accept string/untypedAtomic values
                // (QName and other atomic kinds are not castable to these subtypes).
                if (value.Kind != XdmValueKind.String)
                    return false;
                string s = CollapseWhitespace(value.ToString());
                if (Regex.IsMatch(s, @"^[\p{L}_][\w.\-]*$"))
                {
                    result = XdmValue.FromString(s, normalized);
                    return true;
                }
                return false;
            }

            case "name":
            {
                if (value.Kind != XdmValueKind.String)
                    return false;
                string s = CollapseWhitespace(value.ToString());
                if (Regex.IsMatch(s, @"^[\p{L}_:][\w.:\-]*$"))
                {
                    result = XdmValue.FromString(s, "Name");
                    return true;
                }
                return false;
            }

            case "nmtoken":
            {
                if (value.Kind != XdmValueKind.String)
                    return false;
                string s = CollapseWhitespace(value.ToString());
                if (Regex.IsMatch(s, @"^[\w.:\-]+$"))
                {
                    result = XdmValue.FromString(s, "NMTOKEN");
                    return true;
                }
                return false;
            }

            case "language":
            {
                // XPath 3.1 §17.3: casting to xs:string (and its subtypes) is permitted
                // from any atomic type by first converting to xs:string.
                string s = CollapseWhitespace(value.ToString());
                if (Regex.IsMatch(s, @"^[a-zA-Z]{1,8}(-[a-zA-Z0-9]{1,8})*$"))
                {
                    result = XdmValue.FromString(s, "language");
                    return true;
                }
                return false;
            }

            case "normalizedstring":
            {
                // XPath 3.1 §17.3: casting to xs:string (or a subtype) from any atomic
                // type is permitted by first converting to xs:string.
                string s = value.ToString();
                // XML Schema whiteSpace="replace": replace tab, CR, LF with space
                s = s.Replace('\r', ' ').Replace('\n', ' ').Replace('\t', ' ');
                result = XdmValue.FromString(s, "normalizedString");
                return true;
            }
            case "token":
            {
                // XPath 3.1 §17.3: casting to xs:string (or a subtype) from any atomic
                // type is permitted by first converting to xs:string.
                string s = value.ToString();
                // XML Schema whiteSpace="collapse": replace tab/CR/LF with space,
                // trim leading/trailing spaces, collapse internal runs of spaces
                s = s.Replace('\r', ' ').Replace('\n', ' ').Replace('\t', ' ');
                s = s.Trim(' ');
                while (s.Contains("  "))
                    s = s.Replace("  ", " ");
                result = XdmValue.FromString(s, "token");
                return true;
            }

            case "idrefs":
            {
                string s = CollapseWhitespace(value.ToString());
                if (string.IsNullOrEmpty(s))
                    return false;
                var idrefTokens = s.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                var idrefItems = new XdmValue[idrefTokens.Length];
                for (int i = 0; i < idrefTokens.Length; i++)
                {
                    if (!Regex.IsMatch(idrefTokens[i], @"^[\p{L}_][\w.\-]*$"))
                        return false;
                    idrefItems[i] = XdmValue.FromString(idrefTokens[i], "IDREF");
                }
                result = XdmValue.FromSequence(MaterializedSequence.FromArray(idrefItems));
                return true;
            }

            case "nmtokens":
            {
                string s = CollapseWhitespace(value.ToString());
                if (string.IsNullOrEmpty(s))
                    return false;
                var nmtokens = s.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                var nmtokenItems = new XdmValue[nmtokens.Length];
                for (int i = 0; i < nmtokens.Length; i++)
                {
                    if (!Regex.IsMatch(nmtokens[i], @"^[\w.:\-]+$"))
                        return false;
                    nmtokenItems[i] = XdmValue.FromString(nmtokens[i], "NMTOKEN");
                }
                result = XdmValue.FromSequence(MaterializedSequence.FromArray(nmtokenItems));
                return true;
            }

            case "entities":
            {
                string s = CollapseWhitespace(value.ToString());
                if (string.IsNullOrEmpty(s))
                    return false;
                var entityTokens = s.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                var entityItems = new XdmValue[entityTokens.Length];
                for (int i = 0; i < entityTokens.Length; i++)
                {
                    if (!Regex.IsMatch(entityTokens[i], @"^[\p{L}_][\w.\-]*$"))
                        return false;
                    entityItems[i] = XdmValue.FromString(entityTokens[i], "ENTITY");
                }
                result = XdmValue.FromSequence(MaterializedSequence.FromArray(entityItems));
                return true;
            }

            case "qname":
                if (value.Kind == XdmValueKind.QName)
                    return true;
                if (value.Kind == XdmValueKind.String)
                {
                    string sQName = value.StringValue.Trim();
                    if (string.IsNullOrEmpty(sQName))
                        return false;
                    // Validate lexical QName: prefix:local or local (no prefix)
                    int colon = sQName.IndexOf(':');
                    string prefix;
                    string local;
                    if (colon >= 0)
                    {
                        prefix = sQName[..colon];
                        local = sQName[(colon + 1)..];
                        if (string.IsNullOrEmpty(prefix) || string.IsNullOrEmpty(local))
                            return false;
                    }
                    else
                    {
                        prefix = string.Empty;
                        local = sQName;
                    }

                    if (!IsValidNcName(prefix) || !IsValidNcName(local))
                        return false;

                    // Resolve namespace using the static namespace context. Without a context,
                    // a prefixed QName cannot be resolved and the cast fails. An unprefixed
                    // QName always resolves to the default element namespace or the empty namespace.
                    string namespaceUri;
                    if (context is not null)
                    {
                        if (string.IsNullOrEmpty(prefix))
                        {
                            namespaceUri = context.DefaultElementNamespace ?? string.Empty;
                        }
                        else
                        {
                            if (!context.TryResolveNamespace(prefix, out namespaceUri!))
                                return false;
                        }
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(prefix))
                            return false;
                        namespaceUri = string.Empty;
                    }

                    result = XdmValue.FromQName(new XsQName(local, namespaceUri, prefix));
                    return true;
                }
                return false;

            default:
                return false;
        }
    }

    private static readonly Regex DurationPartsRegex = new(
        @"^(?<sign>[-+]?)(?<P>P)(?<Y>\d+Y)?(?<M>\d+M)?(?<D>\d+D)?(?<T>T(?<H>\d+H)?(?<Tm>\d+M)?(?<S>\d+(?:\.\d+)?S)?)?$",
        RegexOptions.Compiled);

    private static bool IsValidAnyUri(string s)
    {
        for (int i = 0; i < s.Length; i++)
        {
            if (s[i] == '%')
            {
                if (i + 2 >= s.Length)
                    return false;
                if (!IsHexDigit(s[i + 1]) || !IsHexDigit(s[i + 2]))
                    return false;
            }
        }
        return true;
    }

    private static bool IsHexDigit(char c)
        => (c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f');

    private static string CollapseWhitespace(string s)
    {
        s = s.Replace('\r', ' ').Replace('\n', ' ').Replace('\t', ' ');
        s = s.Trim(' ');
        while (s.Contains("  "))
            s = s.Replace("  ", " ");
        return s;
    }

    private static bool IsMixedDuration(string s)
    {
        var m = DurationPartsRegex.Match(s);
        if (!m.Success) return false;
        bool hasYm = m.Groups["Y"].Success || m.Groups["M"].Success;
        bool hasDt = m.Groups["D"].Success || m.Groups["T"].Success;
        return hasYm && hasDt;
    }

    private static string? NormalizeTimezone(string tz)
    {
        if (string.IsNullOrEmpty(tz)) return "";
        if (tz.Equals("Z", StringComparison.OrdinalIgnoreCase)) return "Z";
        int tzHour = int.Parse(tz[1..3], CultureInfo.InvariantCulture);
        int tzMin = int.Parse(tz[4..6], CultureInfo.InvariantCulture);
        if (tzHour > 14 || (tzHour == 14 && tzMin > 0) || tzMin > 59)
            return null;
        if (tzHour == 0 && tzMin == 0)
            return "Z";
        return tz;
    }

    private static string CanonicalizeDuration(string s)
    {
        var m = DurationPartsRegex.Match(s);
        if (!m.Success) return s;
        string sign = m.Groups["sign"].Value;
        int years = 0, months = 0, days = 0, hours = 0, minutes = 0;
        double seconds = 0;
        if (m.Groups["Y"].Success) years = int.Parse(m.Groups["Y"].Value.TrimEnd('Y'), CultureInfo.InvariantCulture);
        if (m.Groups["M"].Success) months = int.Parse(m.Groups["M"].Value.TrimEnd('M'), CultureInfo.InvariantCulture);
        if (m.Groups["D"].Success) days = int.Parse(m.Groups["D"].Value.TrimEnd('D'), CultureInfo.InvariantCulture);
        if (m.Groups["H"].Success) hours = int.Parse(m.Groups["H"].Value.TrimEnd('H'), CultureInfo.InvariantCulture);
        if (m.Groups["Tm"].Success) minutes = int.Parse(m.Groups["Tm"].Value.TrimEnd('M'), CultureInfo.InvariantCulture);
        if (m.Groups["S"].Success) seconds = double.Parse(m.Groups["S"].Value.TrimEnd('S'), CultureInfo.InvariantCulture);

        years += months / 12;
        months %= 12;

        minutes += (int)(seconds / 60);
        seconds = seconds % 60;
        hours += minutes / 60;
        minutes %= 60;
        days += hours / 24;
        hours %= 24;

        if (years == 0 && months == 0 && days == 0 && hours == 0 && minutes == 0 && seconds == 0)
            sign = "";

        var sb = new System.Text.StringBuilder();
        if (!string.IsNullOrEmpty(sign)) sb.Append('-');
        sb.Append('P');
        if (years > 0) sb.Append(years).Append('Y');
        if (months > 0) sb.Append(months).Append('M');
        if (days > 0) sb.Append(days).Append('D');
        bool hasTime = hours > 0 || minutes > 0 || seconds > 0;
        if (hasTime || (years == 0 && months == 0 && days == 0))
        {
            sb.Append('T');
            if (hours > 0) sb.Append(hours).Append('H');
            if (minutes > 0) sb.Append(minutes).Append('M');
            if (seconds > 0 || (hours == 0 && minutes == 0))
                sb.Append(FormatDurationSeconds(seconds)).Append('S');
        }
        return sb.ToString();
    }

    /// <summary>
    /// Extracts the year/month components of an <c>xs:duration</c> lexical string as a
    /// canonical <c>xs:yearMonthDuration</c> lexical string (months folded into years).
    /// </summary>
    /// <param name="s">The <c>xs:duration</c> lexical string.</param>
    /// <returns>The canonical yearMonthDuration form, or the input unchanged when it does not parse.</returns>
    public static string ExtractYearMonthDuration(string s)
    {
        var m = DurationPartsRegex.Match(s);
        if (!m.Success) return s;
        string sign = m.Groups["sign"].Value;
        int years = 0, months = 0;
        if (m.Groups["Y"].Success) years = int.Parse(m.Groups["Y"].Value.TrimEnd('Y'), CultureInfo.InvariantCulture);
        if (m.Groups["M"].Success) months = int.Parse(m.Groups["M"].Value.TrimEnd('M'), CultureInfo.InvariantCulture);
        years += months / 12;
        months %= 12;
        if (years == 0 && months == 0) sign = "";
        string result = sign + "P";
        if (years > 0) result += years + "Y";
        if (months > 0 || years == 0) result += months + "M";
        return result;
    }

    /// <summary>
    /// Extracts the day/time components of an <c>xs:duration</c> lexical string as a
    /// canonical <c>xs:dayTimeDuration</c> lexical string (smaller units folded upwards).
    /// </summary>
    /// <param name="s">The <c>xs:duration</c> lexical string.</param>
    /// <returns>The canonical dayTimeDuration form, or the input unchanged when it does not parse.</returns>
    public static string ExtractDayTimeDuration(string s)
    {
        var m = DurationPartsRegex.Match(s);
        if (!m.Success) return s;
        string sign = m.Groups["sign"].Value;
        int days = 0, hours = 0, minutes = 0;
        double seconds = 0;
        if (m.Groups["D"].Success) days = int.Parse(m.Groups["D"].Value.TrimEnd('D'), CultureInfo.InvariantCulture);
        if (m.Groups["H"].Success) hours = int.Parse(m.Groups["H"].Value.TrimEnd('H'), CultureInfo.InvariantCulture);
        if (m.Groups["Tm"].Success) minutes = int.Parse(m.Groups["Tm"].Value.TrimEnd('M'), CultureInfo.InvariantCulture);
        if (m.Groups["S"].Success) seconds = double.Parse(m.Groups["S"].Value.TrimEnd('S'), CultureInfo.InvariantCulture);

        minutes += (int)(seconds / 60);
        seconds = seconds % 60;
        hours += minutes / 60;
        minutes %= 60;
        days += hours / 24;
        hours %= 24;

        if (days == 0 && hours == 0 && minutes == 0 && seconds == 0) sign = "";

        string result = sign + "P";
        if (days > 0) result += days + "D";
        bool hasTime = hours > 0 || minutes > 0 || seconds > 0 || days == 0;
        if (hasTime)
        {
            result += "T";
            if (hours > 0) result += hours + "H";
            if (minutes > 0) result += minutes + "M";
            if (seconds > 0 || (hours == 0 && minutes == 0)) result += FormatDurationSeconds(seconds) + "S";
        }
        return result;
    }

    private static string FormatDurationSeconds(double seconds)
    {
        string s = seconds.ToString("0.0#########", CultureInfo.InvariantCulture);
        s = s.TrimEnd('0').TrimEnd('.');
        if (s == "0" || s == "-0") s = "0";
        return s;
    }

    private static readonly Regex DurationComponentRegex = new(@"(\d+)([YMDHST])", RegexOptions.Compiled);

    private static bool IsValidDuration(string s)
    {
        if (string.IsNullOrEmpty(s)) return false;
        // Disallow leading '+'; 'T' must be followed by at least one time component
        if (!Regex.IsMatch(s, @"^-?P(\d+Y)?(\d+M)?(\d+D)?(T(\d+H)?(\d+M)?(\d+(\.\d+)?S)?)?$"))
            return false;
        if (s == "P" || s == "-P") return false;
        // Reject 'T' without following components (e.g., P1DT, P1Y24MT)
        int tIdx = s.IndexOf('T');
        if (tIdx >= 0)
        {
            bool hasTimeComponent = s.IndexOf('H', tIdx) >= 0 || s.IndexOf('M', tIdx) >= 0 || s.IndexOf('S', tIdx) >= 0;
            if (!hasTimeComponent) return false;
        }
        // Reject absurdly large components
        foreach (Match m in DurationComponentRegex.Matches(s))
        {
            if (long.Parse(m.Groups[1].Value, CultureInfo.InvariantCulture) > 999999999999L)
                return false;
        }
        return true;
    }

    private static bool IsValidYearMonthDuration(string s)
    {
        if (string.IsNullOrEmpty(s)) return false;
        if (!Regex.IsMatch(s, @"^-?P(\d+Y)?(\d+M)?$"))
            return false;
        return s.Contains('Y') || s.Contains('M');
    }

    private static bool IsValidDayTimeDuration(string s)
    {
        if (string.IsNullOrEmpty(s)) return false;
        // Disallow leading '+'; 'T' must be followed by at least one time component
        if (!Regex.IsMatch(s, @"^-?P(\d+D)?(T(\d+H)?(\d+M)?(\d+(\.\d+)?S)?)?$"))
            return false;
        if (s.Contains('Y')) return false;
        // Reject 'M' before 'T' (months), but allow 'M' after 'T' (minutes)
        int tIdx = s.IndexOf('T');
        if (tIdx >= 0)
        {
            if (s.IndexOf('M') >= 0 && s.IndexOf('M') < tIdx) return false;
            bool hasTimeComponent = s.IndexOf('H', tIdx) >= 0 || s.IndexOf('M', tIdx) >= 0 || s.IndexOf('S', tIdx) >= 0;
            if (!hasTimeComponent) return false;
        }
        else
        {
            if (s.Contains('M')) return false;
        }
        if (s.Contains('D')) return true;
        if (tIdx < 0) return false;
        return s.IndexOf('H', tIdx) >= 0 || s.IndexOf('M', tIdx) >= 0 || s.IndexOf('S', tIdx) >= 0;
    }

    /// <summary>
    /// Converts a .NET <see cref="TimeSpan"/> to an XSD <c>xs:duration</c> lexical string.
    /// </summary>
    private static string TimeSpanToXsdDuration(TimeSpan ts)
    {
        bool negative = ts.Ticks < 0;
        if (negative) ts = ts.Negate();

        int days = ts.Days;
        int hours = ts.Hours;
        int minutes = ts.Minutes;
        int seconds = ts.Seconds;
        int milliseconds = ts.Milliseconds;

        var sb = new System.Text.StringBuilder();
        if (negative) sb.Append('-');
        sb.Append('P');
        if (days > 0) sb.Append(days).Append('D');
        bool hasTime = hours > 0 || minutes > 0 || seconds > 0 || milliseconds > 0 || days == 0;
        if (hasTime)
        {
            sb.Append('T');
            if (hours > 0) sb.Append(hours).Append('H');
            if (minutes > 0) sb.Append(minutes).Append('M');
            if (seconds > 0 || milliseconds > 0 || (hours == 0 && minutes == 0))
            {
                sb.Append(seconds);
                if (milliseconds > 0)
                {
                    string frac = milliseconds.ToString("000").TrimEnd('0');
                    sb.Append('.').Append(frac);
                }
                sb.Append('S');
            }
        }
        return sb.ToString();
    }

    /// <summary>
    /// Validates an <c>xs:base64Binary</c> lexical string: whitespace is ignored, the
    /// remaining length must be a multiple of four, and only the base64 alphabet with
    /// trailing <c>=</c> padding is allowed.
    /// </summary>
    /// <param name="s">The lexical string to validate.</param>
    /// <returns><c>true</c> when the string is a valid base64 lexical form.</returns>
    public static bool IsValidBase64(string s)
    {
        if (string.IsNullOrEmpty(s)) return true;
        s = s.Replace(" ", "").Replace("\t", "").Replace("\n", "").Replace("\r", "");
        if (s.Length % 4 != 0) return false;
        const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        foreach (char c in s)
            if (!chars.Contains(c) && c != '=')
                return false;
        int eq = s.IndexOf('=');
        if (eq >= 0)
        {
            for (int i = eq; i < s.Length; i++)
                if (s[i] != '=')
                    return false;
            if (s.Length - eq > 2)
                return false;
            // Validate padding rules:
            // '==' : preceding char must be one of AQgw (lower 4 bits == 0)
            // '='  : preceding char must be one of AEIMQUYcgkosw048 (lower 2 bits == 0)
            if (eq > 0)
            {
                char lastData = s[eq - 1];
                int padding = s.Length - eq;
                if (padding == 2)
                {
                    const string validForDoublePad = "AQgw";
                    if (!validForDoublePad.Contains(lastData))
                        return false;
                }
                else if (padding == 1)
                {
                    const string validForSinglePad = "AEIMQUYcgkosw048";
                    if (!validForSinglePad.Contains(lastData))
                        return false;
                }
            }
        }
        return true;
    }

    // Annotation assertions must not be in a reserved namespace (XQST0045,
    // annotation-assertion-11..18). Unprefixed names (e.g. %public/%private) are in no
    // namespace and are always allowed.
    private static readonly string[] ReservedAnnotationNamespaces =
    {
        "http://www.w3.org/XML/1998/namespace",
        "http://www.w3.org/2001/XMLSchema",
        "http://www.w3.org/2001/XMLSchema-instance",
        "http://www.w3.org/2005/xpath-functions",
        "http://www.w3.org/2005/xpath-functions/math",
        "http://www.w3.org/2012/xquery",
    };

    // Strips leading annotation assertions ('%name', '%name(literal, ...)') from a
    // function-test type text, validating the annotation namespaces (XQST0045) and
    // resolving prefixes against the evaluation context (XPST0081 when unbound).
    private static string StripAnnotationAssertions(string typeName, EvaluationContext? context)
    {
        var s = typeName.TrimStart();
        while (s.Length > 0 && s[0] == '%')
        {
            int i = 1;
            while (i < s.Length && char.IsWhiteSpace(s[i])) i++;
            string? annotationNs = null;
            if (i + 1 < s.Length && s[i] == 'Q' && s[i + 1] == '{')
            {
                int closeBrace = s.IndexOf('}', i + 2);
                if (closeBrace < 0)
                    throw new InvalidOperationException($"XPST0003: Unclosed EQName in annotation assertion '{s}'.");
                annotationNs = s[(i + 2)..closeBrace];
                i = closeBrace + 1;
                while (i < s.Length && IsAnnotationNameChar(s[i])) i++;
            }
            else
            {
                int nameStart = i;
                while (i < s.Length && (IsAnnotationNameChar(s[i]) || s[i] == ':')) i++;
                var rawName = s[nameStart..i];
                int colon = rawName.IndexOf(':');
                if (colon > 0)
                {
                    var prefix = rawName[..colon];
                    if (context is null || !context.TryResolveNamespace(prefix, out var resolvedNs))
                        throw new InvalidOperationException($"XPST0081: Prefix '{prefix}' is not declared.");
                    annotationNs = resolvedNs;
                }
            }
            if (annotationNs is not null && ReservedAnnotationNamespaces.Contains(annotationNs))
                throw new InvalidOperationException($"XQST0045: The annotation namespace '{annotationNs}' is reserved.");
            // Optional literal argument list: skip balanced parens with string awareness.
            while (i < s.Length && char.IsWhiteSpace(s[i])) i++;
            if (i < s.Length && s[i] == '(')
            {
                int depth = 0;
                do
                {
                    char c = s[i];
                    if (c is '"' or '\'')
                    {
                        char quote = c;
                        i++;
                        while (i < s.Length && s[i] != quote) i++;
                        if (i < s.Length) i++;
                        continue;
                    }
                    if (c == '(') depth++;
                    else if (c == ')') depth--;
                    i++;
                } while (depth > 0 && i < s.Length);
            }
            s = s[i..].TrimStart();
        }
        return s;
    }

    private static bool IsAnnotationNameChar(char c)
        => char.IsLetterOrDigit(c) || c is '.' or '-' or '_';

    // Unwraps a singleton sequence whose item matches the declared parameter kind
    // (map, array, or function item); anything else passes through unchanged so the
    // implementation's own type error still applies.
    private static XdmValue UnwrapSingletonItem(XdmValue value, XdmValueKind kind)
    {
        if (!value.IsSequence || value.SequenceValue is null)
            return value;
        XdmValue single = default;
        int count = 0;
        foreach (var item in XdmSequence.FromSource(value.SequenceValue))
        {
            count++;
            if (count == 1) single = item;
            if (count > 1) return value;
        }
        return count == 1 && single.Kind == kind ? single : value;
    }

    private static bool InstanceOf(XdmValue value, string typeName, OccurrenceIndicator occurrence, string? defaultElementNamespace, EvaluationContext? context = null)
    {
        // Annotation assertions preceding a function test are validated (XQST0045) and
        // ignored: they can only restrict matches, which implementations may decline to do.
        typeName = StripAnnotationAssertions(typeName, context);
        // Unwrap redundant outer parentheses (hof-013).
        while (typeName.Length > 1 && typeName[0] == '(' && FindMatchingParen(typeName, 0) == typeName.Length - 1)
            typeName = typeName[1..^1].Trim();
        string normalized = NormalizeTypeName(typeName);

        if (normalized is "empty-sequence" or "empty-sequence()")
            return !SequenceHasAnyItem(value);

        // Single-pass (streamed) input: run the cardinality and item-type checks in
        // one enumeration — a separate counting pass would exhaust the stream.
        if (value.IsSequence && value.SequenceValue is ISinglePassSequence singlePass)
        {
            int seen = 0;
            foreach (var item in XdmSequence.FromSource(singlePass))
            {
                seen++;
                if (!InstanceOf(item, typeName, OccurrenceIndicator.One, defaultElementNamespace, context))
                    return false;
                if (seen == 2 && occurrence is OccurrenceIndicator.One or OccurrenceIndicator.ZeroOrOne)
                    return false;
            }
            return occurrence switch
            {
                OccurrenceIndicator.ZeroOrMore or OccurrenceIndicator.ZeroOrOne => true,
                OccurrenceIndicator.OneOrMore => seen >= 1,
                _ => seen == 1,
            };
        }

        // Check cardinality
        int count;
        if (value.IsUndefined)
            count = 0;
        else if (!value.IsSequence)
            count = 1;
        else if (!TryGetSequenceLength(value.SequenceValue, out count))
        {
            // Materialize to count
            count = 0;
            foreach (var _ in XdmSequence.FromSource(value.SequenceValue!))
                count++;
        }

        bool cardinalityOk = occurrence switch
        {
            OccurrenceIndicator.One => count == 1,
            OccurrenceIndicator.ZeroOrOne => count <= 1,
            OccurrenceIndicator.ZeroOrMore => true,
            OccurrenceIndicator.OneOrMore => count >= 1,
            _ => count == 1
        };

        if (!cardinalityOk)
            return false;

        if (count == 0)
            return true;

        if (context is not null && context.TryResolveNamedRecordType(typeName, defaultElementNamespace, out var namedRecord))
        {
            bool Matches(XdmValue item) => item.IsMap && ReferenceEquals(item.MapValue?.RecordType, namedRecord);
            if (!value.IsSequence)
                return Matches(value);
            foreach (var item in XdmSequence.FromSource(value.SequenceValue!))
                if (!Matches(item)) return false;
            return true;
        }

        // XPath 4.0 §3.2.5/§3.2.6: choice item types and enumeration types are structural
        // type texts, not QNames: the QName resolution below does not apply, and the type
        // is matched per item (enum: an xs:string instance whose value is a member;
        // choice: any alternative matches). The occurrence indicator was consumed by
        // the caller, but strip a residual suffix defensively before the shape tests.
        var itemTypeText = typeName.Trim();
        if (itemTypeText.Length > 1 && itemTypeText[^1] is '?' or '*' or '+')
            itemTypeText = itemTypeText[..^1].TrimEnd();
        if (TryGetEnumMembers(itemTypeText) is not null || TryGetChoiceAlternatives(itemTypeText, out _))
        {
            if (!value.IsSequence)
                return ValueMatchesType(value, itemTypeText, context);
            foreach (var item in XdmSequence.FromSource(value.SequenceValue!))
                if (!ValueMatchesType(item, itemTypeText, context))
                    return false;
            return true;
        }
        // XPath 4.0 §3.2.10: record types are structural texts matched per item, like
        // enum/choice texts above (the QName resolution below does not apply to them).
        if (IsRecordTypeText(itemTypeText))
        {
            if (!value.IsSequence)
                return ValueMatchesType(value, itemTypeText, context);
            foreach (var item in XdmSequence.FromSource(value.SequenceValue!))
                if (!ValueMatchesType(item, itemTypeText, context))
                    return false;
            return true;
        }

        string effective;
        if (typeName.StartsWith("xs:", StringComparison.OrdinalIgnoreCase))
        {
            effective = normalized.StartsWith("xs:") ? normalized[3..] : normalized;
        }
        else if (typeName.StartsWith("xsd:", StringComparison.OrdinalIgnoreCase))
        {
            effective = normalized.StartsWith("xsd:") ? normalized[4..] : normalized;
        }
        else if (typeName.StartsWith("Q{", StringComparison.Ordinal))
        {
            // Braced URI literals name the type directly; user-defined schema simple types
            // are valid as atomic item types.
            var (qNs, qLocal) = ResolveTypeQName(typeName, context);
            if (qNs == XmlSchema.Namespace)
            {
                effective = qLocal.ToLowerInvariant();
            }
            else if (TryGetSchemaSimpleTypeExpanded(qNs, qLocal, context, out _))
            {
                effective = $"Q{{{qNs}}}{qLocal}";
            }
            else
            {
                throw new InvalidOperationException("XPST0051");
            }
        }
        else if (typeName.Contains(':') && !typeName.Contains('(') && !typeName.Contains('{'))
        {
            // A prefixed type name resolves via the in-scope namespaces: the XML Schema
            // namespace maps to the bare type; a non-XS prefix is valid only when it names
            // a user-defined schema simple type.
            int colon = typeName.IndexOf(':');
            var typePrefix = typeName[..colon];
            if (context is not null && context.TryResolveNamespace(typePrefix, out var resolvedTypeNs))
            {
                if (resolvedTypeNs == "http://www.w3.org/2001/XMLSchema")
                {
                    effective = normalized[(normalized.IndexOf(':') + 1)..];
                }
                else if (IsUserDefinedSchemaType(typeName, context, out _))
                {
                    effective = typeName;
                }
                else
                {
                    throw new InvalidOperationException("XPST0051");
                }
            }
            else
            {
                throw new InvalidOperationException($"XPST0081: Prefix '{typePrefix}' is not declared.");
            }
        }
        else
        {
            if (defaultElementNamespace == "http://www.w3.org/2001/XMLSchema")
            {
                effective = normalized;
            }
            else if (!string.IsNullOrEmpty(defaultElementNamespace)
                && TryGetSchemaSimpleTypeExpanded(defaultElementNamespace, typeName.Trim(), context, out _))
            {
                // Unprefixed user-defined schema simple types in the default element namespace
                // are valid atomic item types (ForExprType052/053).
                effective = $"Q{{{defaultElementNamespace}}}{typeName.Trim()}";
            }
            else if (string.IsNullOrEmpty(defaultElementNamespace)
                && TryGetSchemaSimpleTypeExpanded("", typeName.Trim(), context, out _))
            {
                // No xpath-default-namespace: unprefixed names are in no namespace, and a
                // no-namespace schema may declare the type (REQ-106, notation-0101/0102).
                effective = $"Q{{}}{typeName.Trim()}";
            }
            else
            {
                // No prefix and the default namespace is not XML Schema: only node kind
                // and function/map/array/item tests are valid; bare atomic type names are not.
                if (IsKnownSequenceTypeName(normalized))
                    effective = normalized;
                else
                    throw new InvalidOperationException("XPST0051");
            }
        }

        // Function, map, array and item tests are valid regardless of the default namespace.
        if (effective is "function" or "function(*)" or "function()")
        {
            if (HasNonGenericParameters(typeName) || TryParseFunctionType(typeName.Trim(), out _, out _))
            {
                // Typed function test function(A) as R: delegate per item (maps and
                // arrays are matched against their implied function signature).
                if (!value.IsSequence) return ValueMatchesType(value, typeName, context);
                foreach (var item in XdmSequence.FromSource(value.SequenceValue!))
                    if (!ValueMatchesType(item, typeName, context)) return false;
                return true;
            }
            // function(*) matches every function item, including maps and arrays.
            if (!value.IsSequence) return value.IsFunction || value.IsMap || value.IsArray;
            foreach (var item in XdmSequence.FromSource(value.SequenceValue!))
                if (!item.IsFunction && !item.IsMap && !item.IsArray) return false;
            return true;
        }

        if (effective is "map" or "map(*)" or "map()")
        {
            if (HasNonGenericParameters(typeName))
            {
                ValidateParameterizedMapArrayTypeNames(typeName, defaultElementNamespace);
                if (!value.IsSequence) return ValueMatchesType(value, typeName, context);
                foreach (var item in XdmSequence.FromSource(value.SequenceValue!))
                    if (!ValueMatchesType(item, typeName, context)) return false;
                return true;
            }
            if (!value.IsSequence) return value.IsMap;
            foreach (var item in XdmSequence.FromSource(value.SequenceValue!))
                if (!item.IsMap) return false;
            return true;
        }

        if (effective is "array" or "array(*)" or "array()")
        {
            if (HasNonGenericParameters(typeName))
            {
                ValidateParameterizedMapArrayTypeNames(typeName, defaultElementNamespace);
                if (!value.IsSequence) return ValueMatchesType(value, typeName, context);
                foreach (var item in XdmSequence.FromSource(value.SequenceValue!))
                    if (!ValueMatchesType(item, typeName, context)) return false;
                return true;
            }
            if (!value.IsSequence) return value.IsArray;
            foreach (var item in XdmSequence.FromSource(value.SequenceValue!))
                if (!item.IsArray) return false;
            return true;
        }

        if (effective is "item" or "item()")
        {
            if (!value.IsSequence) return !value.IsUndefined;
            foreach (var item in XdmSequence.FromSource(value.SequenceValue!))
                if (item.IsUndefined) return false;
            return true;
        }

        // Node kind tests (use the original typeName so that parameterised forms
        // such as element(*, xs:anyType) are evaluated by ValueMatchesType).
        if (IsKnownSequenceTypeName(effective))
        {
            if (!value.IsSequence) return ValueMatchesType(value, typeName, context);
            foreach (var item in XdmSequence.FromSource(value.SequenceValue!))
            {
                if (!ValueMatchesType(item, typeName, context))
                    return false;
            }
            return true;
        }

        // Atomic type names: must be in the XML Schema namespace (either via xs: prefix
        // or via the default element/type namespace) or a user-defined schema simple type.
        XmlSchemaSimpleType? userSchemaType = null;
        if (!IsKnownAtomicTypeName(effective) && !IsUserDefinedSchemaType(effective, context, out userSchemaType))
            throw new InvalidOperationException("XPST0051");

        // A SequenceType item type must denote an atomic type. User-defined simple types whose
        // variety is list, or union types that are restrictions or contain a list member,
        // are not allowed.
        if (userSchemaType is not null && IsDisallowedSequenceTypeItemType(userSchemaType, context))
            throw new InvalidOperationException("XPST0051");

        // xs:QName is case-sensitive: only the exact local name "QName" is valid.
        // xs:qname, xs:QNAME, etc. are not known types and must raise XPST0051.
        if (effective == "qname" && GetTypeLocalName(typeName) != "QName")
            throw new InvalidOperationException("XPST0051");

        // User-defined schema simple types use type-hierarchy semantics for instance-of.
        // xs:untypedAtomic is not a subtype of any user-defined simple type, even though
        // casting may succeed under XSD facets (cbcl-module-001).
        if (userSchemaType is not null)
        {
            if (!value.IsSequence)
                return !IsUntypedAtomicValue(value) && ValueMatchesType(value, effective, context);

            foreach (var item in XdmSequence.FromSource(value.SequenceValue!))
            {
                if (IsUntypedAtomicValue(item) || !ValueMatchesType(item, effective, context))
                    return false;
            }
            return true;
        }

        if (!value.IsSequence)
            return ValueMatchesType(value, effective, context);

        foreach (var item in XdmSequence.FromSource(value.SequenceValue!))
        {
            if (!ValueMatchesType(item, effective, context))
                return false;
        }
        return true;
    }

    /// <summary>
    /// Returns true when the type test carries parenthesised parameters other than
    /// the generic <c>()</c> and <c>(*)</c> forms (e.g. <c>map(xs:string, xs:integer)</c>,
    /// <c>array(xs:string)</c>, <c>function(xs:integer) as xs:string</c>).
    /// </summary>
    private static bool HasNonGenericParameters(string typeName)
    {
        int paren = typeName.IndexOf('(');
        if (paren < 0) return false;
        int close = FindMatchingParen(typeName, paren);
        if (close < 0) return false;
        var inner = typeName.Substring(paren + 1, close - paren - 1).Trim();
        return inner.Length > 0 && inner != "*";
    }

    /// <summary>
    /// Validates that type names nested inside a parameterised map/array/function test
    /// are namespace-qualified (or kind tests). Bare atomic names are only valid when
    /// the default element/type namespace is the XML Schema namespace (MapTest-008).
    /// </summary>
    private static void ValidateParameterizedMapArrayTypeNames(string typeName, string? defaultElementNamespace)
    {
        if (defaultElementNamespace == "http://www.w3.org/2001/XMLSchema")
            return;
        int paren = typeName.IndexOf('(');
        if (paren < 0) return;
        int close = FindMatchingParen(typeName, paren);
        if (close < 0) return;
        var inner = typeName.Substring(paren + 1, close - paren - 1);
        foreach (var part in SplitTopLevel(inner, ','))
        {
            var t = part.Trim();
            if (t.Length > 0 && t[^1] is '?' or '*' or '+')
                t = t[..^1].TrimEnd();
            if (t.Length == 0 || t == "*")
                continue;
            var lower = t.ToLowerInvariant();
            if (lower.StartsWith("map(") || lower.StartsWith("array(") || lower.StartsWith("function("))
            {
                ValidateParameterizedMapArrayTypeNames(t, defaultElementNamespace);
                continue;
            }
            if (t.Contains('(') || t.Contains(':'))
                continue; // kind test (element(), item(), ...) or prefixed QName
            throw new InvalidOperationException(
                $"XPST0051: Type name '{t}' in a map/array type test is not in the XML Schema namespace");
        }
    }

    private static string NormalizeTypeName(string typeName)
    {
        var s = typeName.Trim().ToLowerInvariant();
        if (s.Length > 0 && (s[^1] is '?' or '*' or '+'))
            s = s[..^1].TrimEnd();
        // Strip any parenthesised parameters so that forms such as
        // element(*, xs:anyType), attribute(*, T), and item() all reduce
        // to their base kind name for the initial classification.
        int paren = s.IndexOf('(');
        if (paren >= 0)
            s = s[..paren].TrimEnd();
        return s;
    }

    /// <summary>
    /// Maps an EQName atomic type name in the XML Schema namespace
    /// (<c>Q{http://www.w3.org/2001/XMLSchema}integer</c>) to the equivalent
    /// <c>xs:</c>-prefixed form (eqname-004: EQName parameter types in user function
    /// declarations). Any other EQName is returned unchanged.
    /// </summary>
    private static string NormalizeEQNameTypeName(string typeName)
    {
        if (typeName.StartsWith("Q{", StringComparison.Ordinal))
        {
            int close = typeName.IndexOf('}');
            if (close > 2 && string.Equals(typeName[2..close].Trim(), "http://www.w3.org/2001/XMLSchema", StringComparison.Ordinal))
                return string.Concat("xs:", typeName.AsSpan(close + 1));
        }
        return typeName;
    }

    /// <summary>
    /// Extracts the local name from a sequence type string, stripping an optional
    /// xs:/xsd: prefix or Q{uri} EQName wrapper. Used for case-sensitive checks
    /// where the lower-cased normalized form is no longer sufficient.
    /// </summary>
    private static string GetTypeLocalName(string typeName)
    {
        var s = typeName.Trim();
        int brace = s.IndexOf('}');
        if (brace >= 0 && brace < s.Length - 1)
            s = s[(brace + 1)..];
        int colon = s.IndexOf(':');
        if (colon >= 0 && colon < s.Length - 1)
            s = s[(colon + 1)..];
        // Strip occurrence indicator if present.
        if (s.Length > 0 && (s[^1] is '?' or '*' or '+'))
            s = s[..^1].TrimEnd();
        return s;
    }

    private static string ResolveTypeName(string original, string normalized, string? defaultElementNamespace)
    {
        if (original.Contains(':'))
        {
            if (original.StartsWith("xs:", StringComparison.OrdinalIgnoreCase))
                return normalized.StartsWith("xs:") ? normalized[3..] : normalized;
            if (original.StartsWith("xsd:", StringComparison.OrdinalIgnoreCase))
                return normalized.StartsWith("xsd:") ? normalized[4..] : normalized;
            throw new InvalidOperationException("XPST0051");
        }

        if (defaultElementNamespace == "http://www.w3.org/2001/XMLSchema")
            return normalized;

        return normalized;
    }

    private static bool IsKnownSequenceTypeName(string name)
    {
        if (name is "node" or "node()" or "element" or "element()" or "attribute" or "attribute()"
            or "document-node" or "document-node()" or "text" or "text()" or "comment" or "comment()"
            or "processing-instruction" or "processing-instruction()" or "namespace-node" or "namespace-node()"
            or "item" or "item()"
            or "function" or "function(*)" or "function()"
            or "map" or "map(*)" or "map()"
            or "array" or "array(*)" or "array()"
            or "jnode" or "jnode()" or "jnode(*)" or "jnode(())"
            or "schema-element" or "schema-element()"
            or "schema-attribute" or "schema-attribute()")
        {
            return true;
        }

        return name.StartsWith("element(", StringComparison.Ordinal)
            || name.StartsWith("attribute(", StringComparison.Ordinal)
            || name.StartsWith("document-node(", StringComparison.Ordinal)
            || name.StartsWith("schema-element(", StringComparison.Ordinal)
            || name.StartsWith("schema-attribute(", StringComparison.Ordinal)
            || name.StartsWith("processing-instruction(", StringComparison.Ordinal)
            || name.StartsWith("jnode(", StringComparison.Ordinal);
    }

    /// <summary>
    /// Matches a JNode's entry key against a jnode() type-test key specifier
    /// (XPath 4.0 §17.7): '*' or '' matches any key, '()' matches a keyless root,
    /// a quoted string literal or bare NCName matches a string key, an integer
    /// literal matches a position key, and a '#' QName literal matches a QName key.
    /// Comparison uses map-key (atomic-equal family) semantics.
    /// </summary>
    private static bool JNodeKeyMatches(XdmJNode jnode, string keySpec, EvaluationContext? context)
    {
        if (keySpec.Length == 0 || keySpec == "*")
            return true;
        if (keySpec == "()")
            return jnode.Key.IsUndefined;

        XdmValue expected = keySpec[0] switch
        {
            '"' or '\'' => XdmValue.FromString(UnquoteKeyLiteral(keySpec)),
            '#' => ParseJNodeQNameKeyLiteral(keySpec, context),
            _ when long.TryParse(keySpec, NumberStyles.Integer, CultureInfo.InvariantCulture, out var pos)
                => XdmValue.FromInteger(pos),
            _ when IsKeySpecifierNcName(keySpec) => XdmValue.FromString(keySpec),
            _ => throw new InvalidOperationException(
                $"XPST0003: Invalid jnode() key specifier '{keySpec}'"),
        };
        return XdmValueEqualityComparer.Instance.Equals(jnode.Key, expected);
    }

    /// <summary>
    /// Removes the enclosing quotes of a string key literal in a jnode() type test,
    /// unescaping the doubled enclosing delimiter.
    /// </summary>
    private static string UnquoteKeyLiteral(string literal)
    {
        if (literal.Length < 2 || literal[0] != literal[^1])
            throw new InvalidOperationException($"XPST0003: Malformed string key literal '{literal}'");
        char quote = literal[0];
        return literal.Substring(1, literal.Length - 2).Replace(new string(quote, 2), quote.ToString());
    }

    /// <summary>Returns whether the key specifier is a bare NCName (matched as a string key).</summary>
    private static bool IsKeySpecifierNcName(string spec)
    {
        if (spec.Length == 0 || !char.IsLetter(spec[0]))
            return false;
        foreach (char c in spec)
        {
            if (!char.IsLetterOrDigit(c) && c is not ('.' or '-' or '_'))
                return false;
        }
        return true;
    }

    /// <summary>
    /// Parses a '#' QName key literal (#Q{uri}local or #prefix:local) for a jnode()
    /// type test; the prefix form resolves against the static context (XPST0081).
    /// </summary>
    private static XdmValue ParseJNodeQNameKeyLiteral(string literal, EvaluationContext? context)
    {
        string body = literal.Substring(1);
        if (body.StartsWith("Q{", StringComparison.Ordinal))
        {
            int close = body.IndexOf('}');
            if (close < 2 || close == body.Length - 1)
                throw new InvalidOperationException($"XPST0003: Invalid '#' QName literal '{literal}'");
            return XdmValue.FromQName(new XsQName(body[(close + 1)..], body.Substring(2, close - 2)));
        }
        int colon = body.IndexOf(':');
        if (colon <= 0 || colon == body.Length - 1)
            throw new InvalidOperationException($"XPST0003: Invalid '#' QName literal '{literal}'");
        string prefix = body.Substring(0, colon);
        string local = body[(colon + 1)..];
        // TryResolveNamespace handles the predefined 'xml' prefix itself.
        if (context is null || !context.TryResolveNamespace(prefix, out var ns))
            throw new InvalidOperationException($"XPST0081: Prefix '{prefix}' is not declared.");
        return XdmValue.FromQName(new XsQName(local, ns));
    }

    private static bool IsKnownAtomicTypeName(string name)
        => name is "string" or "normalizedstring" or "token" or "language" or "nmtoken" or "name"
            or "ncname" or "id" or "idref" or "entity" or "boolean" or "integer" or "int" or "long"
            or "short" or "byte" or "unsignedshort" or "unsignedint" or "unsignedlong" or "unsignedbyte"
            or "positiveinteger" or "negativeinteger" or "nonpositiveinteger" or "nonnegativeinteger"
            or "decimal" or "double" or "float" or "numeric" or "datetime" or "datetimestamp" or "date" or "time"
            or "duration" or "daytimeduration" or "yearmonthduration" or "qname" or "anyuri" or "notation"
            or "gyear" or "gyearmonth" or "gmonthday" or "gday" or "gmonth"
            or "hexbinary" or "base64binary" or "untypedatomic" or "anyatomictype" or "error";

    private static bool ItemInstanceOf(XdmValue value, string normalized)
    {
        return normalized switch
        {
            // xs:error is the empty type: no value is ever an instance of it.
            "error" => false,
            "string" or "normalizedstring" or "token" or "language" or "nmtoken" or "name"
                or "ncname" or "id" or "idref" or "entity"
                => value.Kind == XdmValueKind.String && IsAtomicTypeSubtype(value.SchemaTypeName ?? "string", normalized),
            "integer" or "int" or "long" or "short" or "byte"
                or "unsignedshort" or "unsignedint" or "unsignedlong" or "unsignedbyte"
                or "positiveinteger" or "negativeinteger" or "nonpositiveinteger" or "nonnegativeinteger"
                => (value.Kind == XdmValueKind.Integer || (value.Kind == XdmValueKind.Decimal && IsIntegerSchemaType(value.SchemaTypeName)))
                   && IsAtomicTypeSubtype(value.SchemaTypeName ?? "integer", normalized),
            "decimal" => value.Kind is XdmValueKind.Decimal or XdmValueKind.Integer,
            "double" => value.Kind == XdmValueKind.Double,
            "float" => value.Kind == XdmValueKind.Float,
            "numeric" => value.Kind is XdmValueKind.Integer or XdmValueKind.Decimal or XdmValueKind.Double or XdmValueKind.Float,
            "anyatomictype" => value.Kind is >= XdmValueKind.String and <= XdmValueKind.Binary,
            "boolean" => value.Kind == XdmValueKind.Boolean,
            "datetime" => value.Kind == XdmValueKind.DateTime,
            "datetimestamp" => value.Kind == XdmValueKind.DateTime && value.HasTimezone,
            "date" => value.Kind == XdmValueKind.Date,
            "time" => value.Kind == XdmValueKind.Time,
            "duration" => value.Kind == XdmValueKind.Duration,
            "daytimeduration" => value.Kind == XdmValueKind.Duration &&
                (value.SchemaTypeName is null || value.SchemaTypeName.Equals("dayTimeDuration", StringComparison.OrdinalIgnoreCase)),
            "yearmonthduration" => value.Kind == XdmValueKind.Duration &&
                (value.SchemaTypeName is null || value.SchemaTypeName.Equals("yearMonthDuration", StringComparison.OrdinalIgnoreCase)),
            "qname" => value.Kind == XdmValueKind.QName,
            "gyear" => (value.Kind == XdmValueKind.String || value.Kind == XdmValueKind.DateTime) && value.SchemaTypeName?.Equals("gYear", StringComparison.OrdinalIgnoreCase) == true,
            "gyearmonth" => (value.Kind == XdmValueKind.String || value.Kind == XdmValueKind.DateTime) && value.SchemaTypeName?.Equals("gYearMonth", StringComparison.OrdinalIgnoreCase) == true,
            "gmonthday" => (value.Kind == XdmValueKind.String || value.Kind == XdmValueKind.DateTime) && value.SchemaTypeName?.Equals("gMonthDay", StringComparison.OrdinalIgnoreCase) == true,
            "gday" => (value.Kind == XdmValueKind.String || value.Kind == XdmValueKind.DateTime) && value.SchemaTypeName?.Equals("gDay", StringComparison.OrdinalIgnoreCase) == true,
            "gmonth" => (value.Kind == XdmValueKind.String || value.Kind == XdmValueKind.DateTime) && value.SchemaTypeName?.Equals("gMonth", StringComparison.OrdinalIgnoreCase) == true,
            "hexbinary" => value.Kind == XdmValueKind.String && value.SchemaTypeName?.Equals("hexBinary", StringComparison.OrdinalIgnoreCase) == true,
            "base64binary" => value.Kind == XdmValueKind.String && value.SchemaTypeName?.Equals("base64Binary", StringComparison.OrdinalIgnoreCase) == true,
            "anyuri" => value.Kind == XdmValueKind.String && value.SchemaTypeName?.Equals("anyURI", StringComparison.OrdinalIgnoreCase) == true,
            "untypedatomic" => value.Kind == XdmValueKind.String && value.SchemaTypeName?.Equals("untypedAtomic", StringComparison.OrdinalIgnoreCase) == true,
            "notation" => (value.Kind == XdmValueKind.QName || value.Kind == XdmValueKind.String)
                && value.SchemaTypeName is not null
                && IsAtomicTypeSubtype(value.SchemaTypeName, "notation"),
            "node" => value.IsNode,
            "element" or "element()" => value.IsNode && value.NodeValue.NodeKind == XdmNodeKind.Element,
            "attribute" or "attribute()" => value.IsNode && value.NodeValue.NodeKind == XdmNodeKind.Attribute,
            "document-node" or "document-node()" => value.IsNode && value.NodeValue.NodeKind == XdmNodeKind.Document,
            "text" or "text()" => value.IsNode && value.NodeValue.NodeKind == XdmNodeKind.Text,
            "comment" or "comment()" => value.IsNode && value.NodeValue.NodeKind == XdmNodeKind.Comment,
            "processing-instruction" or "processing-instruction()" => value.IsNode && value.NodeValue.NodeKind == XdmNodeKind.ProcessingInstruction,
            "namespace-node" or "namespace-node()" => value.IsNode && value.NodeValue.NodeKind == XdmNodeKind.Namespace,
            "item" => !value.IsUndefined,
            _ => false
        };
    }

    /// <summary>
    /// Returns true when the atomic type <paramref name="actual"/> equals or derives from
    /// <paramref name="target"/> per the XSD type hierarchy (instance-of semantics).
    /// Names are case-insensitive and compared without the xs: prefix.
    /// </summary>
    private static bool IsAtomicTypeSubtype(string actual, string target)
    {
        actual = actual.ToLowerInvariant().Replace("xs:", "");
        target = target.ToLowerInvariant().Replace("xs:", "");
        if (actual == target) return true;
        var visited = new HashSet<string>();
        var queue = new Queue<string>();
        queue.Enqueue(actual);
        while (queue.Count > 0)
        {
            var current = queue.Dequeue();
            if (!visited.Add(current)) continue;
            foreach (var super in GetDirectSupertypes(current))
            {
                if (super == target) return true;
                queue.Enqueue(super);
            }
        }
        return false;
    }

    private static bool IsElementTypeCompatible(string typeName, EvaluationContext? context, IXdmNode node)
    {
        var (targetNs, targetLocal) = ResolveKindTestTypeName(typeName, context);
        // element(*, T?) / element(N, T?) explicitly allow nilled elements (fn-nilled-40/42/43/49/53);
        // element(*, T) / element(N, T) do not (fn-nilled-44/45/46).
        bool nillableType = typeName.TrimEnd().EndsWith("?");
        if (node.IsNilled)
            return nillableType;
        // xs:anyType is the base of every element annotation, including xs:untyped.
        if (targetNs == XmlSchema.Namespace && targetLocal == "anyType") return true;
        if (node.SchemaTypeAnnotation is not { } actual)
        {
            // Untyped parsed element: xs:anyType and xs:untyped both match.
            // Constructed element (XQuery direct/computed constructor): XDM type annotation
            // is xs:anyType, so xs:untyped must not match (K2-DirectConElemContent-35a).
            if (targetNs != XmlSchema.Namespace)
                return false;
            var targetLower = targetLocal.ToLowerInvariant();
            if (node.IsConstructedElement)
                return targetLower is "anytype";
            return targetLower is "anytype" or "untyped";
        }
        if (IsSchemaTypeSubtype(context, actual.NamespaceUri, actual.LocalName, targetNs, targetLocal))
            return true;

        // element(N, simpleType) also matches an element whose type annotation is a complex
        // type with simple content whose base simple type derives from that simple type
        // (cbcl-validateexpr-15).
        if (context?.SchemaSet is not null)
        {
            var actualType = context.SchemaSet.GlobalTypes[new XmlQualifiedName(actual.LocalName, actual.NamespaceUri)] as XmlSchemaType;
            if (actualType is XmlSchemaComplexType complex && complex.ContentType == XmlSchemaContentType.TextOnly)
            {
                if (complex.BaseXmlSchemaType is XmlSchemaSimpleType baseSimple)
                {
                    var qn = baseSimple.QualifiedName;
                    if (IsSchemaTypeSubtype(context, qn.Namespace, qn.Name, targetNs, targetLocal))
                        return true;
                }
            }
        }

        // Anonymous schema types are reported with an empty SchemaTypeAnnotation. Fall back to
        // the underlying XElement PSVI so element(N, T) can still match complex types with simple
        // content whose base simple type derives from T.
        if (actual.NamespaceUri.Length == 0 && actual.LocalName.Length == 0
            && node is XDocumentNode xdn && xdn.UnderlyingObject is XElement element
            && element.GetSchemaInfo()?.SchemaType is XmlSchemaType anonymousType)
        {
            if (anonymousType is XmlSchemaComplexType anonComplex && anonComplex.ContentType == XmlSchemaContentType.TextOnly
                && anonComplex.BaseXmlSchemaType is XmlSchemaSimpleType baseSimple)
            {
                var qn = baseSimple.QualifiedName;
                if (IsSchemaTypeSubtype(context, qn.Namespace, qn.Name, targetNs, targetLocal))
                    return true;
            }
            // Anonymous simple types (e.g. an inline xs:restriction base="xs:string") derive
            // from the target exactly like a named simple type (import-schema-052/053/054).
            else if (anonymousType is XmlSchemaSimpleType anonSimple && context is not null)
            {
                var targetType = ResolveSchemaType(context, targetNs, targetLocal);
                if (targetType is not null
                    && XmlSchemaType.IsDerivedFrom(anonSimple, targetType, XmlSchemaDerivationMethod.Empty))
                    return true;
            }
        }
        return false;
    }

    private static bool IsAttributeTypeCompatible(string typeName, EvaluationContext? context, IXdmNode node)
    {
        var (targetNs, targetLocal) = ResolveKindTestTypeName(typeName, context);
        if (node.SchemaTypeAnnotation is not { } actual)
        {
            // Untyped attribute: xs:untypedAtomic and its supertypes match.
            return targetNs == XmlSchema.Namespace && targetLocal.ToLowerInvariant() is "untypedatomic" or "anyatomictype" or "anysimpletype" or "anytype";
        }
        return IsSchemaTypeSubtype(context, actual.NamespaceUri, actual.LocalName, targetNs, targetLocal);
    }

    /// <summary>
    /// Resolves a type name used in <c>element(*, T)</c> / <c>attribute(*, T)</c> to an
    /// expanded QName. The xs: prefix maps to the XML Schema namespace; prefixed names are
    /// resolved against the context namespace bindings; unprefixed names use the default
    /// element namespace when one is declared.
    /// </summary>
    private static (string NamespaceUri, string LocalName) ResolveKindTestTypeName(string typeName, EvaluationContext? context)
    {
        var s = typeName.Trim().Replace("*", "").Trim();
        if (s.EndsWith('?'))
            s = s[..^1].Trim();
        if (s.StartsWith("xs:", StringComparison.OrdinalIgnoreCase))
            return (XmlSchema.Namespace, s[3..]);
        if (s.StartsWith("Q{", StringComparison.Ordinal))
        {
            int close = s.IndexOf('}');
            string ns = close > 2 ? s[2..close] : string.Empty;
            string local = close >= 0 ? s[(close + 1)..] : s;
            return (ns, local);
        }
        int colon = s.IndexOf(':');
        if (colon > 0)
        {
            string prefix = s[..colon];
            if (context is null || !context.TryResolveNamespace(prefix, out var ns))
                throw new InvalidOperationException($"XPST0081: Prefix '{prefix}' is not declared.");
            return (ns, s[(colon + 1)..]);
        }
        return (context?.DefaultElementNamespace ?? string.Empty, s);
    }

    /// <summary>
    /// Resolves a lexical type name (xs:local, Q{uri}local, prefix:local, or unprefixed local)
    /// to an expanded QName using the in-scope namespace bindings and default element namespace.
    /// </summary>
    private static (string NamespaceUri, string LocalName) ResolveTypeQName(string typeName, EvaluationContext? context)
    {
        var s = typeName.Trim();
        if (s.EndsWith('?') || s.EndsWith('*') || s.EndsWith('+'))
            s = s[..^1].TrimEnd();
        if (s.StartsWith("xs:", StringComparison.OrdinalIgnoreCase))
            return (XmlSchema.Namespace, s[3..]);
        if (s.StartsWith("Q{", StringComparison.Ordinal))
        {
            int close = s.IndexOf('}');
            string ns = close > 2 ? s[2..close] : string.Empty;
            string local = close >= 0 ? s[(close + 1)..] : s;
            return (ns, local);
        }
        int colon = s.IndexOf(':');
        if (colon > 0)
        {
            string prefix = s[..colon];
            if (context is null || !context.TryResolveNamespace(prefix, out var ns))
                throw new InvalidOperationException($"XPST0081: Prefix '{prefix}' is not declared.");
            return (ns, s[(colon + 1)..]);
        }
        return (context?.DefaultElementNamespace ?? string.Empty, s);
    }

    /// <summary>
    /// Looks up a type by expanded QName in the evaluation context's schema set.
    /// Returns true when the type is present and is a simple type with a datatype.
    /// </summary>
    private static bool TryGetSchemaSimpleType(string namespaceUri, string localName, EvaluationContext? context, [NotNullWhen(true)] out XmlSchemaSimpleType? simpleType)
    {
        simpleType = null;
        if (context?.SchemaSet is null)
            return false;
        if (context.SchemaSet.GlobalTypes[new XmlQualifiedName(localName, namespaceUri)] is not XmlSchemaSimpleType simple)
            return false;
        simpleType = simple;
        return simpleType.Datatype is not null;
    }

    /// <summary>
    /// Looks up a simple type by expanded QName, falling back to the built-in XML Schema
    /// simple types (including list types such as xs:NMTOKENS) when it is not present in
    /// the schema set's GlobalTypes table.
    /// </summary>
    private static bool TryGetSchemaSimpleTypeExpanded(string namespaceUri, string localName, EvaluationContext? context, [NotNullWhen(true)] out XmlSchemaSimpleType? simpleType)
    {
        if (TryGetSchemaSimpleType(namespaceUri, localName, context, out simpleType))
            return true;

        if (namespaceUri == XmlSchema.Namespace)
        {
            var builtIn = XmlSchemaType.GetBuiltInSimpleType(new XmlQualifiedName(localName, namespaceUri)) as XmlSchemaSimpleType;
            if (builtIn?.Datatype is not null)
            {
                simpleType = builtIn;
                return true;
            }
        }

        simpleType = null;
        return false;
    }

    /// <summary>
    /// Returns true when the sequence-type name denotes a user-defined schema simple type
    /// (i.e. not a built-in xs:* type) that is present in the evaluation context's schema set.
    /// </summary>
    private static bool IsUserDefinedSchemaType(string typeName, EvaluationContext? context, [NotNullWhen(true)] out XmlSchemaSimpleType? simpleType)
    {
        simpleType = null;
        if (context?.SchemaSet is null)
            return false;
        if (typeName.Contains('('))
            return false;
        var (ns, local) = ResolveTypeQName(typeName, context);
        if (ns == XmlSchema.Namespace)
            return false;
        return TryGetSchemaSimpleType(ns, local, context, out simpleType);
    }

    /// <summary>
    /// Walks a derived schema type up to its built-in XML Schema base and returns the
    /// local name, or null when no built-in base can be reached.
    /// </summary>
    private static string? GetBuiltInBaseTypeName(XmlSchemaType type)
    {
        var visited = new HashSet<XmlSchemaType>();
        var current = type;
        while (current is not null && visited.Add(current))
        {
            if (current.QualifiedName.Namespace == XmlSchema.Namespace)
                return current.QualifiedName.Name;
            current = current.BaseXmlSchemaType;
        }
        return null;
    }

    private enum SchemaTypeVariety { Atomic, List, Union }

    private static SchemaTypeVariety GetSchemaTypeVariety(XmlSchemaSimpleType type)
    {
        if (type.Content is XmlSchemaSimpleTypeUnion) return SchemaTypeVariety.Union;
        if (type.Content is XmlSchemaSimpleTypeList) return SchemaTypeVariety.List;
        if (type.Datatype?.Variety == XmlSchemaDatatypeVariety.Union) return SchemaTypeVariety.Union;
        if (type.Datatype?.Variety == XmlSchemaDatatypeVariety.List) return SchemaTypeVariety.List;
        if (type.Content is XmlSchemaSimpleTypeRestriction restriction)
        {
            // The restriction may be defined against either the base type reference
            // (resolved after compilation) or the compiled BaseXmlSchemaType.
            if (restriction.BaseType is XmlSchemaSimpleType baseType)
            {
                if (baseType.Content is XmlSchemaSimpleTypeUnion || baseType.Datatype?.Variety == XmlSchemaDatatypeVariety.Union) return SchemaTypeVariety.Union;
                if (baseType.Content is XmlSchemaSimpleTypeList || baseType.Datatype?.Variety == XmlSchemaDatatypeVariety.List) return SchemaTypeVariety.List;
            }
            if (type.BaseXmlSchemaType is XmlSchemaSimpleType compiledBase)
            {
                if (compiledBase.Content is XmlSchemaSimpleTypeUnion || compiledBase.Datatype?.Variety == XmlSchemaDatatypeVariety.Union) return SchemaTypeVariety.Union;
                if (compiledBase.Content is XmlSchemaSimpleTypeList || compiledBase.Datatype?.Variety == XmlSchemaDatatypeVariety.List) return SchemaTypeVariety.List;
            }
        }
        return SchemaTypeVariety.Atomic;
    }

    /// <summary>
    /// Returns true when the schema simple type is not allowed as an item type in a
    /// SequenceType. List types and restrictions of union/list types are always disallowed;
    /// union types are disallowed if they are derived by restriction or transitively contain
    /// a list type member.
    /// </summary>
    // A 1-argument call in a schema-imported namespace is interpreted as a type
    // constructor function; when no such type exists the error is XPST0051.
    private static bool IsSchemaImportedNamespace(string nsUri, EvaluationContext context)
    {
        if (context.SchemaSet is null)
            return false;
        foreach (XmlSchema schema in context.SchemaSet.Schemas())
            if (schema.TargetNamespace == nsUri)
                return true;
        return false;
    }

    /// <summary>
    /// Validates that a function-conversion target names a legal sequence-type item type
    /// (XPath 3.1 §2.5.5.2): raises XPST0051 for the pseudo-name 'none', built-in list
    /// types (xs:NMTOKENS/IDREFS/ENTITIES), and schema types whose variety is list or a
    /// union that contains or is derived from a list (FunctionCall-027/032/033/034/039,
    /// K-FunctionProlog-57/58). Unknown names are left to the conversion path (XPTY0004).
    /// </summary>
    private static void ValidateFunctionConversionTarget(string type, EvaluationContext? context)
    {
        var name = NormalizeTypeName(type); // lowercased, occurrence indicator and parens stripped
        if (name == "none")
            throw new InvalidOperationException($"XPST0051: '{type}' is not a type available to users.");
        if (IsKnownSequenceTypeName(name) || IsFunctionFamilyType(name))
            return;
        var bare = name.StartsWith("xs:", StringComparison.Ordinal) ? name[3..] : name;
        if (bare is "nmtokens" or "idrefs" or "entities")
            throw new InvalidOperationException($"XPST0051: The list type '{type}' must not be used as an item type in a sequence type.");
        if (IsKnownAtomicTypeName(bare) || !name.Contains(':'))
            return;
        // Prefixed, non-xs name: a user-defined schema simple type must not be a list type
        // or a union containing/derived from a list (case-sensitive resolution on the
        // original spelling).
        if (IsUserDefinedSchemaType(type, context, out var userType)
            && IsDisallowedSequenceTypeItemType(userType, context))
            throw new InvalidOperationException($"XPST0051: The type '{type}' is a list type or a union type that contains or is derived from a list type, and must not be used in a sequence type.");
    }

    private static bool IsDisallowedSequenceTypeItemType(XmlSchemaSimpleType type, EvaluationContext? context)
    {
        var variety = GetSchemaTypeVariety(type);
        if (variety == SchemaTypeVariety.List)
            return true;

        if (variety == SchemaTypeVariety.Union)
        {
            // A restriction of a union type is not a valid SequenceType item type.
            if (type.Content is XmlSchemaSimpleTypeRestriction)
                return true;

            // A union type that transitively contains a list type member is disallowed.
            return UnionContainsListType(type, context, new HashSet<XmlSchemaSimpleType>());
        }

        return false;
    }

    /// <summary>
    /// Returns true when the union type (or any of its member union types) contains a list
    /// type member, directly or transitively.
    /// </summary>
    private static bool UnionContainsListType(XmlSchemaSimpleType type, EvaluationContext? context, HashSet<XmlSchemaSimpleType> visited)
    {
        if (!visited.Add(type))
            return false;

        foreach (var member in GetUnionMemberTypes(type, context))
        {
            if (member is null)
                continue;

            var memberVariety = GetSchemaTypeVariety(member);
            if (memberVariety == SchemaTypeVariety.List)
                return true;

            if (memberVariety == SchemaTypeVariety.Union && UnionContainsListType(member, context, visited))
                return true;
        }

        return false;
    }

    private static XmlSchemaSimpleType[] GetUnionMemberTypes(XmlSchemaSimpleType type, EvaluationContext? context)
    {
        if (type.Content is not XmlSchemaSimpleTypeUnion union)
            return Array.Empty<XmlSchemaSimpleType>();

        var members = new List<XmlSchemaSimpleType>();

        // Anonymous/local member types defined inline.
        for (int i = 0; i < union.BaseTypes.Count; i++)
        {
            if (union.BaseTypes[i] is XmlSchemaSimpleType member)
                members.Add(member);
        }

        // Named member types referenced via @memberTypes (including built-in xs:* types).
        if (union.MemberTypes is not null && context?.SchemaSet is not null)
        {
            foreach (XmlQualifiedName qn in union.MemberTypes)
            {
                if (context.SchemaSet.GlobalTypes[qn] is XmlSchemaSimpleType member)
                {
                    members.Add(member);
                }
                else if (qn.Namespace == XmlSchema.Namespace)
                {
                    // Built-in XML Schema member types are not always present in the
                    // schema set's GlobalTypes table; resolve them directly.
                    var builtIn = XmlSchemaType.GetBuiltInSimpleType(qn);
                    if (builtIn is not null)
                        members.Add(builtIn);
                }
            }
        }

        return members.ToArray();
    }

    private static XmlSchemaSimpleType? GetListItemType(XmlSchemaSimpleType type)
    {
        XmlSchemaSimpleTypeList? list = type.Content as XmlSchemaSimpleTypeList;
        if (list is null && type.Content is XmlSchemaSimpleTypeRestriction restriction)
        {
            XmlSchemaSimpleType? baseType = restriction.BaseType as XmlSchemaSimpleType
                ?? type.BaseXmlSchemaType as XmlSchemaSimpleType;
            if (baseType is not null)
                list = baseType.Content as XmlSchemaSimpleTypeList;
        }
        if (list is null)
            return null;
        // After compilation the concrete item type is in BaseItemType; ItemType may be null.
        return list.BaseItemType ?? list.ItemType;
    }

    private static XmlSchemaSimpleType? GetUnionBaseType(XmlSchemaSimpleType type)
    {
        if (type.Content is XmlSchemaSimpleTypeUnion)
            return type;
        if (type.Content is XmlSchemaSimpleTypeRestriction restriction)
        {
            if (restriction.BaseType is XmlSchemaSimpleType baseType)
                return baseType;
            if (type.BaseXmlSchemaType is XmlSchemaSimpleType compiledBase)
                return compiledBase;
        }
        return null;
    }

    private static XmlSchemaSimpleType? GetListBaseType(XmlSchemaSimpleType type)
    {
        if (type.Content is XmlSchemaSimpleTypeList)
            return type;
        if (type.Content is XmlSchemaSimpleTypeRestriction restriction)
        {
            if (restriction.BaseType is XmlSchemaSimpleType baseType)
                return baseType;
            if (type.BaseXmlSchemaType is XmlSchemaSimpleType compiledBase)
                return compiledBase;
        }
        return null;
    }

    /// <summary>
    /// Returns the built-in atomic type name to use for XDM annotation when casting
    /// to a user-defined atomic simple type or a union member that is an atomic type.
    /// </summary>
    private static string GetAtomicBaseTypeName(XmlSchemaSimpleType type)
        => GetBuiltInBaseTypeName(type) ?? "untypedAtomic";

    /// <summary>
    /// Returns true when the built-in type name denotes an XSD integer subtype
    /// (including signed, unsigned, and bounded variants).
    /// </summary>
    private static bool IsIntegerTypeName(string typeName)
        => typeName.Equals("integer", StringComparison.OrdinalIgnoreCase)
            || typeName.Equals("nonPositiveInteger", StringComparison.OrdinalIgnoreCase)
            || typeName.Equals("nonNegativeInteger", StringComparison.OrdinalIgnoreCase)
            || typeName.Equals("positiveInteger", StringComparison.OrdinalIgnoreCase)
            || typeName.Equals("negativeInteger", StringComparison.OrdinalIgnoreCase)
            || typeName.Equals("long", StringComparison.OrdinalIgnoreCase)
            || typeName.Equals("int", StringComparison.OrdinalIgnoreCase)
            || typeName.Equals("short", StringComparison.OrdinalIgnoreCase)
            || typeName.Equals("byte", StringComparison.OrdinalIgnoreCase)
            || typeName.Equals("unsignedLong", StringComparison.OrdinalIgnoreCase)
            || typeName.Equals("unsignedInt", StringComparison.OrdinalIgnoreCase)
            || typeName.Equals("unsignedShort", StringComparison.OrdinalIgnoreCase)
            || typeName.Equals("unsignedByte", StringComparison.OrdinalIgnoreCase);

    /// <summary>
    /// Returns true when the built-in type name is namespace-sensitive (QName or NOTATION),
    /// meaning its lexical form must be parsed with an in-scope namespace resolver.
    /// </summary>
    private static bool IsNamespaceSensitiveTypeName(string typeName)
        => typeName.Equals("QName", StringComparison.OrdinalIgnoreCase)
            || typeName.Equals("NOTATION", StringComparison.OrdinalIgnoreCase);

    /// <summary>
    /// Returns true when a schema simple type (including a union type) is namespace-sensitive:
    /// its built-in base is xs:QName or xs:NOTATION, or one of its member types is.
    /// </summary>
    private static bool IsNamespaceSensitiveSchemaType(XmlSchemaSimpleType type, EvaluationContext? context)
    {
        var baseName = GetBuiltInBaseTypeName(type);
        if (baseName is not null && IsNamespaceSensitiveTypeName(baseName))
            return true;

        if (GetSchemaTypeVariety(type) == SchemaTypeVariety.Union)
        {
            foreach (var member in GetUnionMemberTypes(type, context))
            {
                if (member is null)
                    continue;
                if (IsNamespaceSensitiveSchemaType(member, context))
                    return true;
            }
        }

        return false;
    }

    /// <summary>
    /// Returns true when the sequence type name denotes a namespace-sensitive atomic type
    /// (xs:QName, xs:NOTATION, a user-defined restriction of those, or a union containing one).
    /// </summary>
    private static bool IsNamespaceSensitiveTargetType(string typeName, EvaluationContext? context)
    {
        var t = typeName.Trim();
        if (t.Length > 0 && "?+*".Contains(t[^1]))
            t = t[..^1].TrimEnd();
        while (t.Length > 1 && t[0] == '(' && FindMatchingParen(t, 0) == t.Length - 1)
            t = t[1..^1].Trim();

        if (t.StartsWith("xs:", StringComparison.OrdinalIgnoreCase))
            t = t[3..];
        if (IsNamespaceSensitiveTypeName(t))
            return true;

        if (IsUserDefinedSchemaType(typeName, context, out var schemaType))
            return IsNamespaceSensitiveSchemaType(schemaType, context);

        return false;
    }

    /// <summary>
    /// Validates a singleton atomic value against the facets of a schema simple type.
    /// Returns false when parsing/validation fails.
    /// </summary>
    private static bool ValidateSchemaAtomicValue(XdmValue value, XmlSchemaSimpleType schemaSimpleType, EvaluationContext? context, string? lexical = null)
    {
        try
        {
            string effectiveLexical = lexical ?? value.ToString() ?? string.Empty;
            var nsResolver = CreateNamespaceResolver(context);
            schemaSimpleType.Datatype!.ParseValue(effectiveLexical, new NameTable(), nsResolver);
            return true;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// Validates a sequence of atomic values as a list value against the facets of a
    /// schema list simple type. Returns false when parsing/validation fails.
    /// </summary>
    private static bool ValidateSchemaListValue(IReadOnlyList<XdmValue> items, XmlSchemaSimpleType schemaSimpleType, EvaluationContext? context)
    {
        try
        {
            string lexical = string.Join(" ", items.Select(i => i.ToString()));
            var nsResolver = CreateNamespaceResolver(context);
            schemaSimpleType.Datatype!.ParseValue(lexical, new NameTable(), nsResolver);
            return true;
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// Returns the XSD canonical lexical representation of an atomic value for validating
    /// pattern facets on derived atomic types. This differs from XPath <c>fn:string</c>
    /// (and from <see cref="XdmValue.ToString"/>) for decimals (always have a decimal point)
    /// and doubles/floats (always use scientific notation with one leading digit).
    /// </summary>
    private static string GetXsdCanonicalLexical(XdmValue value)
    {
        return value.Kind switch
        {
            XdmValueKind.Decimal => FormatXsdCanonicalDecimal(value.DecimalValue),
            XdmValueKind.Double => FormatXsdCanonicalDouble(value.DoubleValue),
            XdmValueKind.Float => FormatXsdCanonicalFloat((float)value.DoubleValue),
            _ => value.ToString() ?? string.Empty
        };
    }

    private static string FormatXsdCanonicalDecimal(decimal value)
    {
        // XSD canonical decimal requires a decimal point with digits on both sides.
        string s = value.ToString(CultureInfo.InvariantCulture);
        if (!s.Contains('.'))
            s += ".0";
        return s;
    }

    private static string FormatXsdCanonicalDouble(double value)
    {
        if (double.IsPositiveInfinity(value)) return "INF";
        if (double.IsNegativeInfinity(value)) return "-INF";
        if (double.IsNaN(value)) return "NaN";
        if (value == 0.0) return double.IsNegative(value) ? "-0.0E0" : "0.0E0";

        // XPath/XSD canonical double uses scientific notation with one digit before
        // the decimal point and a mandatory exponent.
        string s = value.ToString("R", CultureInfo.InvariantCulture);
        if (!s.Contains('E') && !s.Contains('e'))
        {
            bool negative = s.StartsWith('-');
            if (negative) s = s[1..];
            var digits = s.Replace(".", "");
            int decimalPos = s.IndexOf('.');
            if (decimalPos < 0) decimalPos = digits.Length;
            int exponent = decimalPos - 1;
            string mantissa = digits.Insert(1, ".");
            mantissa = mantissa.TrimEnd('0').TrimEnd('.');
            if (!mantissa.Contains('.')) mantissa += ".0";
            s = (negative ? "-" : "") + mantissa + "E" + exponent;
        }
        else
        {
            s = NormalizeXsdScientific(s);
        }
        return s;
    }

    private static string FormatXsdCanonicalFloat(float value)
    {
        if (float.IsPositiveInfinity(value)) return "INF";
        if (float.IsNegativeInfinity(value)) return "-INF";
        if (float.IsNaN(value)) return "NaN";
        if (value == 0.0f) return float.IsNegative(value) ? "-0.0E0" : "0.0E0";

        string s = value.ToString("R", CultureInfo.InvariantCulture);
        if (!s.Contains('E') && !s.Contains('e'))
        {
            bool negative = s.StartsWith('-');
            if (negative) s = s[1..];
            var digits = s.Replace(".", "");
            int decimalPos = s.IndexOf('.');
            if (decimalPos < 0) decimalPos = digits.Length;
            int exponent = decimalPos - 1;
            string mantissa = digits.Insert(1, ".");
            mantissa = mantissa.TrimEnd('0').TrimEnd('.');
            if (!mantissa.Contains('.')) mantissa += ".0";
            s = (negative ? "-" : "") + mantissa + "E" + exponent;
        }
        else
        {
            s = NormalizeXsdScientific(s);
        }
        return s;
    }

    /// <summary>
    /// Normalizes a scientific-notation string to XSD canonical form: one non-zero digit
    /// before the decimal point, no trailing zeros in the mantissa, and no leading zeros
    /// or plus sign in the exponent.
    /// </summary>
    private static string NormalizeXsdScientific(string s)
    {
        s = s.Replace("E+", "E");
        int eIdx = s.IndexOf('E');
        if (eIdx < 0) eIdx = s.IndexOf('e');
        if (eIdx <= 0) return s;

        string mantissa = s[..eIdx];
        string exp = s[(eIdx + 1)..];
        bool negative = mantissa.StartsWith('-');
        if (negative) mantissa = mantissa[1..];

        mantissa = mantissa.TrimEnd('0').TrimEnd('.');
        if (!mantissa.Contains('.')) mantissa += ".0";

        bool expNegative = exp.StartsWith('-');
        if (expNegative) exp = exp[1..];
        exp = exp.TrimStart('0');
        if (string.IsNullOrEmpty(exp)) exp = "0";
        if (expNegative) exp = "-" + exp;

        return (negative ? "-" : "") + mantissa + "E" + exp;
    }

    /// <summary>
    /// Builds an <see cref="XmlNamespaceManager"/> from the evaluation context's namespace
    /// bindings for use by schema validation that needs to resolve lexical prefixes.
    /// </summary>
    private static IXmlNamespaceResolver CreateNamespaceResolver(EvaluationContext? context)
    {
        var manager = new XmlNamespaceManager(new NameTable());
        if (context is not null)
        {
            foreach (var (prefix, uri) in context.SnapshotNamespaces())
            {
                if (!string.IsNullOrEmpty(prefix))
                    manager.AddNamespace(prefix, uri);
            }
            if (!string.IsNullOrEmpty(context.DefaultElementNamespace))
                manager.AddNamespace(string.Empty, context.DefaultElementNamespace);
        }
        return manager;
    }

    /// <summary>
    /// Casts a value to a user-defined schema simple type, recursively handling
    /// unions, lists, and atomic restrictions. Uses XPath cast semantics for
    /// atomic member types (e.g. decimal to integer truncation).
    /// </summary>
    private static bool TryCastToSchemaType(
        XdmValue value,
        XmlSchemaSimpleType schemaSimpleType,
        EvaluationContext? context,
        out XdmValue result)
    {
        result = XdmValue.Undefined;

        switch (GetSchemaTypeVariety(schemaSimpleType))
        {
            case SchemaTypeVariety.Union:
            {
                var baseUnion = GetUnionBaseType(schemaSimpleType) ?? schemaSimpleType;
                // Preserve the original lexical form so that restriction facets (e.g. pattern)
                // are validated against the source representation. Namespace-sensitive types such
                // as xs:QName may render differently after casting, losing the original prefix.
                string originalLexical = value.ToString() ?? string.Empty;
                foreach (var memberType in GetUnionMemberTypes(baseUnion, context))
                {
                    if (memberType is null)
                        continue;
                    if (TryCastToSchemaType(value, memberType, context, out result))
                    {
                        // For a restriction of a union, validate the selected value against the
                        // restriction facets (e.g. pattern).
                        if (baseUnion != schemaSimpleType && !ValidateSchemaAtomicValue(result, schemaSimpleType, context, originalLexical))
                            continue;
                        return true;
                    }
                }
                return false;
            }

            case SchemaTypeVariety.List:
            {
                var baseList = GetListBaseType(schemaSimpleType) ?? schemaSimpleType;
                var itemType = GetListItemType(baseList);
                if (itemType is null)
                    return false;

                var items = new List<XdmValue>();
                if (!value.IsUndefined)
                {
                    if (value.IsSequence && value.SequenceValue != null)
                    {
                        foreach (var item in XdmSequence.FromSource(value.SequenceValue))
                            items.Add(item);
                    }
                    else if (value.Kind == XdmValueKind.String)
                    {
                        // Tokenize on whitespace.
                        foreach (var token in value.ToString()!.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries))
                            items.Add(XdmValue.FromString(token));
                    }
                    else
                    {
                        // A single non-string atomic value cannot be cast to a list type;
                        // list casts require a string/untypedAtomic lexical form to tokenize
                        // (cbcl-castable-impure-009/019).
                        return false;
                    }
                }

                var converted = new List<XdmValue>(items.Count);
                foreach (var item in items)
                {
                    if (!TryCastToSchemaType(item, itemType, context, out var convertedItem))
                        return false;
                    converted.Add(convertedItem);
                }

                if (converted.Count == 0)
                {
                    result = XdmValue.Undefined;
                    return true;
                }
                if (converted.Count == 1)
                    result = converted[0];
                else
                    result = XdmValue.FromSequence(MaterializedSequence.FromList(converted));

                // For a restriction of a list type, validate the converted list against the
                // restriction facets (e.g. pattern).
                if (baseList != schemaSimpleType && !ValidateSchemaListValue(converted, schemaSimpleType, context))
                    return false;
                return true;
            }

            case SchemaTypeVariety.Atomic:
            default:
            {
                try
                {
                    // For atomic types (including restrictions of atomic types), use XPath cast
                    // semantics by routing through TryCast for the built-in base type. This handles
                    // decimal-to-integer truncation, string-to-date casting, etc.
                    var baseTypeName = GetAtomicBaseTypeName(schemaSimpleType);
                    if (baseTypeName == "untypedAtomic")
                        return false;

                    // REQ-108: a user-defined target keeps its type identity on the result.
                    string? userTypeName = schemaSimpleType.QualifiedName.Namespace != XmlSchema.Namespace
                        ? $"Q{{{schemaSimpleType.QualifiedName.Namespace}}}{schemaSimpleType.QualifiedName.Name}"
                        : null;

                    // Preserve the original lexical form: namespace-sensitive types (QName,
                    // NOTATION) lose prefix information when cast to a typed value, so validation
                    // must use the source lexical string.
                    string originalLexical = value.ToString() ?? string.Empty;

                    // Namespace-sensitive types (QName, NOTATION) cannot always be cast through
                    // the built-in xs:* path: xs:NOTATION is abstract, and even for xs:QName the
                    // user-defined facets must be validated against the original lexical form.
                    // Parse the lexical form directly with the schema datatype so in-scope namespace
                    // bindings are available, then preserve the original prefix in the resulting
                    // QName value for correct serialization.
                    if (IsNamespaceSensitiveTypeName(baseTypeName))
                    {
                        // A typed QName/NOTATION value is already valid. Validate it against the
                        // user-defined facets and keep the original XDM value so prefix and
                        // namespace information are preserved.
                        if (value.Kind == XdmValueKind.QName)
                        {
                            try
                            {
                                var qname = value.QNameValue;
                                var syntheticResolver = CreateNamespaceResolver(context);
                                if (syntheticResolver is XmlNamespaceManager manager && !string.IsNullOrEmpty(qname.NamespaceUri))
                                {
                                    manager.AddNamespace("__q", qname.NamespaceUri);
                                    schemaSimpleType.Datatype!.ParseValue($"__q:{qname.LocalName}", new NameTable(), manager);
                                }
                                else
                                {
                                    schemaSimpleType.Datatype!.ParseValue(originalLexical, new NameTable(), CreateNamespaceResolver(context));
                                }
                                // NOTATION-derived targets: re-annotate as xs:NOTATION so the
                                // result matches instance of xs:NOTATION (the PSVI typed-value
                                // path annotates the same way); QName targets keep their
                                // original annotation (REQ-106, notation-0001/0003/0004).
                                result = baseTypeName == "NOTATION" && value.SchemaTypeName != "NOTATION"
                                    ? XdmValue.FromQName(value.QNameValue, "NOTATION", userTypeName)
                                    : value;
                                return true;
                            }
                            catch
                            {
                                return false;
                            }
                        }

                        // String (or untypedAtomic) input: parse with the schema datatype and
                        // preserve the original prefix when it resolves to the value's namespace.
                        // The §19.3 cast matrix admits only the stringish family here (an
                        // xs:anyURI value is stored as Kind=String but may not be cast to a
                        // QName/NOTATION-derived type — notation-0002 case l).
                        if (value.Kind == XdmValueKind.String && GetCastSourceFamily(value) == "stringish")
                        {
                            try
                            {
                                var stringNsResolver = CreateNamespaceResolver(context);
                                object stringParsed = schemaSimpleType.Datatype!.ParseValue(originalLexical, new NameTable(), stringNsResolver);
                                if (stringParsed is XmlQualifiedName qn)
                                {
                                    string prefix = string.Empty;
                                    int colon = originalLexical.IndexOf(':');
                                    if (colon > 0 && context is not null)
                                    {
                                        string origPrefix = originalLexical[..colon];
                                        if (context.TryResolveNamespace(origPrefix, out var origNs) && origNs == qn.Namespace)
                                            prefix = origPrefix;
                                    }
                                    result = baseTypeName == "NOTATION"
                                        ? XdmValue.FromQName(new XsQName(qn.Name, qn.Namespace, prefix), "NOTATION", userTypeName)
                                        : XdmValue.FromQName(new XsQName(qn.Name, qn.Namespace, prefix));
                                    return true;
                                }
                            }
                            catch
                            {
                                return false;
                            }
                        }

                        return false;
                    }

                    if (!TryCast(value, $"xs:{baseTypeName}", context, out var casted))
                        return false;

                    // Validate the user-defined facets by parsing with the actual schema type.
                    // XSD pattern facets are matched against the canonical lexical representation
                    // of the value, not the XPath string value (CastableAs653-658).
                    string validationLexical = GetXsdCanonicalLexical(casted);
                    var nsResolver = CreateNamespaceResolver(context);
                    object parsed = schemaSimpleType.Datatype!.ParseValue(validationLexical, new NameTable(), nsResolver);

                    // Annotate with the built-in base type, matching existing behavior for
                    // user-defined atomic types (e.g. unrestrictedInteger is stored as integer).
                    result = ConvertSchemaValue(parsed, schemaSimpleType.Datatype, schemaSimpleType, LexicalHasTimezone(validationLexical), validationLexical);
                    return true;
                }
                catch
                {
                    return false;
                }
            }
        }
    }

    /// <summary>
    /// Converts a .NET value returned by <see cref="XmlSchemaDatatype.ParseValue"/> into an
    /// <see cref="XdmValue"/> with the appropriate schema-type annotation.
    /// </summary>
    private static XdmValue ConvertSchemaValue(object value, XmlSchemaDatatype datatype, XmlSchemaType schemaType, bool hasTimezone = true, string? lexicalValue = null)
    {
        string typeName = schemaType.QualifiedName.Name;
        string typeNs = schemaType.QualifiedName.Namespace;

        string? userTypeName = null;
        if (typeNs != XmlSchema.Namespace)
        {
            // User-defined type: derive the annotation from the ultimate built-in base type,
            // but keep the user-defined type identity in Q{uri}local form (REQ-108).
            typeName = GetBuiltInBaseTypeName(schemaType) ?? "untypedAtomic";
            userTypeName = $"Q{{{typeNs}}}{schemaType.QualifiedName.Name}";
        }

        switch (value)
        {
            case bool b:
                return XdmValue.FromBoolean(b, typeName, userTypeName);
            case decimal d:
                // Integer-derived schema types preserve the integer XDM kind when the value fits.
                if (IsIntegerTypeName(typeName) && d >= long.MinValue && d <= long.MaxValue && d == (long)d)
                    return XdmValue.FromInteger((long)d, typeName, userTypeName);
                return XdmValue.FromDecimal(d, typeName, userTypeName);
            case float f:
                return XdmValue.FromFloat(f, typeName, userTypeName);
            case double d:
                return XdmValue.FromDouble(d, typeName, userTypeName);
            case byte u8: return XdmValue.FromInteger(u8, typeName, userTypeName);
            case sbyte i8: return XdmValue.FromInteger(i8, typeName, userTypeName);
            case short i16: return XdmValue.FromInteger(i16, typeName, userTypeName);
            case ushort u16: return XdmValue.FromInteger(u16, typeName, userTypeName);
            case int i32: return XdmValue.FromInteger(i32, typeName, userTypeName);
            case uint u32:
                return XdmValue.FromInteger((long)u32, typeName, userTypeName);
            case long i64:
                return XdmValue.FromInteger(i64, typeName, userTypeName);
            case ulong u64:
                if (u64 <= (ulong)long.MaxValue)
                    return XdmValue.FromInteger((long)u64, typeName, userTypeName);
                return XdmValue.FromDecimal(u64, typeName, userTypeName);
            case DateTime dt:
                return ConvertSchemaDateTime(dt, typeName, hasTimezone, userTypeName);
            case DateTimeOffset dto:
                return ConvertSchemaDateTime(dto.DateTime, typeName, hasTimezone, userTypeName);
            case XmlQualifiedName qn:
            {
                string qnType = typeName;
                if (GetBuiltInBaseTypeName(schemaType) is "NOTATION")
                    qnType = "NOTATION";
                string prefix = string.Empty;
                if (lexicalValue is not null)
                {
                    int colon = lexicalValue.IndexOf(':');
                    if (colon > 0)
                        prefix = lexicalValue[..colon];
                }
                return XdmValue.FromQName(new XsQName(qn.Name, qn.Namespace, prefix), qnType, userTypeName);
            }
            case string s:
                return XdmValue.FromString(s, typeName, userTypeName);
            case byte[] bytes:
                // XdmValue stores binary types as annotated strings.
                string text = typeName.Equals("hexBinary", StringComparison.OrdinalIgnoreCase)
                    ? Convert.ToHexString(bytes)
                    : Convert.ToBase64String(bytes);
                return XdmValue.FromString(text, typeName, userTypeName);
            case TimeSpan ts:
                // xs:duration values parsed by .NET come back as TimeSpan; convert back to
                // the XSD lexical duration form (cbcl-cast-derived-001).
                return XdmValue.FromDuration(TimeSpanToXsdDuration(ts), typeName, userTypeName);
            case Uri uri:
                // .NET parses xs:anyURI to System.Uri, whose ToString() normalizes the
                // lexical form (appends '/' to a bare authority). Keep the original
                // whitespace-collapsed lexical form, mirroring the built-in xs:anyURI
                // cast (type-0302); identity and the type annotation are unaffected.
                return XdmValue.FromString(CollapseWhitespace(lexicalValue ?? uri.OriginalString), typeName, userTypeName);
            default:
                return XdmValue.FromString(value.ToString() ?? string.Empty, typeName, userTypeName);
        }
    }

    private static XdmValue ConvertSchemaDateTime(DateTime dt, string typeName, bool hasTimezone, string? userSchemaTypeName = null)
    {
        var offset = dt.Kind switch
        {
            DateTimeKind.Utc => TimeSpan.Zero,
            DateTimeKind.Local => TimeZoneInfo.Local.GetUtcOffset(dt),
            _ => TimeSpan.Zero,
        };
        var dto = new DateTimeOffset(dt, offset);
        return typeName.ToLowerInvariant() switch
        {
            "date" => XdmValue.FromDate(dto, hasTimezone, "date", userSchemaTypeName),
            "time" => XdmValue.FromTime(dto, hasTimezone, "time", userSchemaTypeName),
            "gyear" => XdmValue.FromDateTime(dto, hasTimezone, schemaTypeName: "gYear", userSchemaTypeName: userSchemaTypeName),
            "gyearmonth" => XdmValue.FromDateTime(dto, hasTimezone, schemaTypeName: "gYearMonth", userSchemaTypeName: userSchemaTypeName),
            "gmonth" => XdmValue.FromDateTime(dto, hasTimezone, schemaTypeName: "gMonth", userSchemaTypeName: userSchemaTypeName),
            "gmonthday" => XdmValue.FromDateTime(dto, hasTimezone, schemaTypeName: "gMonthDay", userSchemaTypeName: userSchemaTypeName),
            "gday" => XdmValue.FromDateTime(dto, hasTimezone, schemaTypeName: "gDay", userSchemaTypeName: userSchemaTypeName),
            _ => XdmValue.FromDateTime(dto, hasTimezone, schemaTypeName: typeName, userSchemaTypeName: userSchemaTypeName)
        };
    }

    /// <summary>
    /// Returns true when a schema-validated lexical date/time value carries an explicit
    /// timezone (trailing <c>Z</c> or <c>+/-hh:mm</c>).
    /// </summary>
    private static bool LexicalHasTimezone(string? lexical)
    {
        if (string.IsNullOrEmpty(lexical))
            return false;
        var s = lexical.AsSpan().Trim();
        if (s.EndsWith("Z".AsSpan(), StringComparison.OrdinalIgnoreCase))
            return true;
        // Match a trailing +hh:mm or -hh:mm timezone offset.
        if (s.Length >= 6)
        {
            char c = s[^6];
            if ((c == '+' || c == '-') && s[^3] == ':')
            {
                for (int i = s.Length - 5; i < s.Length - 3; i++)
                {
                    if (!char.IsDigit(s[i]))
                        return false;
                }
                for (int i = s.Length - 2; i < s.Length; i++)
                {
                    if (!char.IsDigit(s[i]))
                        return false;
                }
                return true;
            }
        }
        return false;
    }

    /// <summary>
    /// Returns true when the schema type <paramref name="actualNs"/>:<paramref name="actualLocal"/>
    /// equals or derives from <paramref name="targetNs"/>:<paramref name="targetLocal"/>.
    /// </summary>
    private static bool IsSchemaTypeSubtype(EvaluationContext? context, string actualNs, string actualLocal, string targetNs, string targetLocal)
    {
        if (string.Equals(actualNs, targetNs, StringComparison.Ordinal)
            && string.Equals(actualLocal, targetLocal, StringComparison.Ordinal))
            return true;

        // XPath 3.1 xs:numeric is a pseudo-union of xs:integer, xs:decimal, xs:float and xs:double.
        // It is not a real XSD type, so treat it as a special compatibility target for built-in
        // numeric types and for user-defined types that derive from one of them.
        if (targetNs == XmlSchema.Namespace
            && targetLocal.Equals("numeric", StringComparison.OrdinalIgnoreCase))
        {
            if (IsNumericSchemaType(actualNs, actualLocal))
                return true;

            if (context?.SchemaSet is not null)
            {
                try
                {
                    var actualQName = new XmlQualifiedName(actualLocal, actualNs);
                    if (context.SchemaSet.GlobalTypes[actualQName] is XmlSchemaType actualType)
                    {
                        var visited = new HashSet<XmlSchemaType>();
                        var current = actualType;
                        while (current is not null && visited.Add(current))
                        {
                            if (IsNumericSchemaType(current.QualifiedName.Namespace, current.QualifiedName.Name))
                                return true;
                            current = current.BaseXmlSchemaType;
                        }
                    }
                }
                catch
                {
                    // Ignore schema lookup errors and fall through to false.
                }
            }

            return false;
        }

        // Built-in atomic type hierarchy.
        if (targetNs == XmlSchema.Namespace && actualNs == XmlSchema.Namespace)
            return IsAtomicTypeSubtype(actualLocal, targetLocal);

        // User-defined or mixed: walk the schema-set type hierarchy.
        if (context?.SchemaSet is null)
            return false;

        try
        {
            var actualQName = new XmlQualifiedName(actualLocal, actualNs);
            var actualType = context.SchemaSet.GlobalTypes[actualQName] as XmlSchemaType;
            if (actualType is null)
                return false;
            var targetQName = new XmlQualifiedName(targetLocal, targetNs);
            var visited = new HashSet<XmlSchemaType>();
            var current = actualType;
            while (current is not null && visited.Add(current))
            {
                if (current.QualifiedName == targetQName)
                    return true;
                current = current.BaseXmlSchemaType;
            }
        }
        catch
        {
            // Ignore schema-lookup errors and fall through to false.
        }
        return false;
    }

    /// <summary>
    /// Returns true when the expanded schema type name denotes one of the XPath 3.1 numeric
    /// atomic types (the xs:numeric pseudo-union and its member types).
    /// </summary>
    private static bool IsNumericSchemaType(string ns, string local)
        => ns == XmlSchema.Namespace
            && local.ToLowerInvariant() is "numeric" or "integer" or "decimal" or "float" or "double"
                or "nonpositiveinteger" or "negativeinteger" or "long" or "int" or "short" or "byte"
                or "nonnegativeinteger" or "unsignedlong" or "unsignedint" or "unsignedshort" or "unsignedbyte"
                or "positiveinteger";

    // Validates the schema type name of an element(name, T) / attribute(name, T) test.
    // A prefixed or URI-qualified T must resolve to a built-in schema type: XPST0081 for
    // an undeclared prefix, XPST0008 for an unknown type (static-context-1). Unprefixed
    // names keep the lenient local interpretation used for element-type compatibility.
    private static void ValidateKindTestSchemaType(string typeName, EvaluationContext? context)
    {
        if (context is null)
            return;
        var s = GetCasePreservedTypeName(typeName);
        int open = s.IndexOf('(');
        int close = s.LastIndexOf(')');
        if (open < 0 || close <= open)
            return;
        var inner = s.Substring(open + 1, close - open - 1);
        var parts = SplitNodeTestParts(inner, ',');
        if (parts.Length < 2)
            return;
        var typePart = parts[1];
        if (typePart.EndsWith('?'))
            typePart = typePart[..^1].TrimEnd();
        if (typePart.Length == 0 || typePart == "*")
            return;
        if (!typePart.Contains(':') && !typePart.StartsWith("Q{", StringComparison.Ordinal))
            return;
        ValidateKindTestTypeName(typePart, context);
    }

    // Validates a schema type name used in a kind test (element(foo, T) / attribute(foo, T)):
    // the name must resolve (XPST0081 for an undeclared prefix) and must designate a known
    // built-in schema type or a type declared in an imported schema (XPST0008 otherwise).
    private static void ValidateKindTestTypeName(string typeName, EvaluationContext context)
    {
        string local;
        string ns;
        if (typeName.StartsWith("Q{", StringComparison.Ordinal))
        {
            int close = typeName.IndexOf('}');
            ns = close > 2 ? typeName[2..close] : string.Empty;
            local = close >= 0 ? typeName[(close + 1)..] : typeName;
        }
        else
        {
            int colon = typeName.IndexOf(':');
            if (colon > 0)
            {
                var prefix = typeName[..colon];
                if (!context.TryResolveNamespace(prefix, out var resolved))
                    throw new InvalidOperationException($"XPST0081: Prefix '{prefix}' is not declared.");
                ns = resolved;
                local = typeName[(colon + 1)..];
            }
            else
            {
                ns = context.DefaultElementNamespace ?? string.Empty;
                local = typeName;
            }
        }
        if (ns == "http://www.w3.org/2001/XMLSchema" && BuiltInSchemaTypes.Contains(local))
            return;
        if (context.SchemaSet is not null && context.SchemaSet.GlobalTypes[new XmlQualifiedName(local, ns)] is XmlSchemaType)
            return;
        throw new InvalidOperationException($"XPST0008: The type '{typeName}' is not declared.");
    }

    /// <summary>The built-in XML Schema type names (XSD 1.0 + 1.1) plus the XPath types.</summary>
    private static readonly HashSet<string> BuiltInSchemaTypes = new(StringComparer.Ordinal)
    {
        "anyType", "anySimpleType", "anyAtomicType", "untyped", "untypedAtomic",
        "string", "normalizedString", "token", "language", "NMTOKEN", "NMTOKENS",
        "Name", "NCName", "ID", "IDREF", "IDREFS", "ENTITY", "ENTITIES",
        "boolean", "decimal", "float", "double", "duration", "dateTime", "time", "date",
        "gYearMonth", "gYear", "gMonthDay", "gDay", "gMonth",
        "hexBinary", "base64Binary", "anyURI", "QName", "NOTATION",
        "integer", "nonPositiveInteger", "negativeInteger", "long", "int", "short", "byte",
        "nonNegativeInteger", "unsignedLong", "unsignedInt", "unsignedShort", "unsignedByte",
        "positiveInteger", "dateTimeStamp", "dayTimeDuration", "yearMonthDuration",
        "numeric", "error",
    };

    /// <summary>
    /// Classifies an atomized value into the XPath 3.1 §19.3 source-type families used by
    /// the permitted-cast matrix. Plain typed values (xs:float etc.) carry no schema
    /// annotation, so the runtime kind is the primary discriminator; schema annotations
    /// (xs:untypedAtomic, xs:yearMonthDuration, xs:gYear, ...) refine it. Date/time values
    /// are distinguished by subtype (date vs time vs the g* types) because §19.3.4
    /// permits only specific subtype combinations.
    /// </summary>
    private static string GetCastSourceFamily(XdmValue value)
    {
        var st = value.SchemaTypeName?.ToLowerInvariant();
        if (st is not null)
        {
            if (st is "untypedatomic" or "string"
                or "normalizedstring" or "token" or "language" or "nmtoken" or "name"
                or "ncname" or "id" or "idref" or "entity")
                return "stringish";
            if (st is "hexbinary" or "base64binary")
                return "binary";
            if (st is "anyuri")
                return "uri";
            if (st is "qname" or "notation")
                return "qname";
            if (st is "duration")
                return "duration";
            if (st is "yearmonthduration")
                return "yearmonthduration";
            if (st is "daytimeduration")
                return "daytimeduration";
            if (st is "gyear" or "gyearmonth" or "gmonthday" or "gday" or "gmonth")
                return st;
            if (st is "datetime")
                return "datetime";
            if (st is "date")
                return "date";
            if (st is "time")
                return "time";
            if (IsIntegerSchemaType(st) || st is "decimal" or "double" or "float" or "numeric")
                return "numeric";
            if (st is "boolean")
                return "boolean";
            return "other";
        }

        return value.Kind switch
        {
            XdmValueKind.String => "stringish",
            XdmValueKind.Integer or XdmValueKind.Decimal or XdmValueKind.Double or XdmValueKind.Float => "numeric",
            XdmValueKind.Boolean => "boolean",
            XdmValueKind.Duration => value.SchemaTypeName?.ToLowerInvariant() switch
            {
                "yearmonthduration" => "yearmonthduration",
                "daytimeduration" => "daytimeduration",
                _ => "duration",
            },
            XdmValueKind.Date => "date",
            XdmValueKind.Time => "time",
            XdmValueKind.DateTime => "datetime",
            XdmValueKind.QName => "qname",
            XdmValueKind.Uri => "uri",
            _ => "other",
        };
    }

    /// <summary>
    /// Applies the XPath 3.1 §19.3 permitted-cast matrix: xs:string/xs:untypedAtomic
    /// (the "stringish" family) cast to anything; numeric targets accept numeric, boolean
    /// and stringish sources; duration targets accept duration-family sources with
    /// subtype rules (yearMonthDuration/dayTimeDuration only from themselves or
    /// xs:duration); date/time targets accept only the subtype combinations of §19.3.4
    /// (date and dateTime cast to all date/time types, time and the g* types only to
    /// themselves). Combinations outside the matrix raise XPTY0004, not FORG0001.
    /// </summary>
    private static bool IsCastCombinationPermitted(string sourceFamily, string targetType)
    {
        if (sourceFamily is "stringish" or "other")
            return true;
        if (targetType is "string" or "untypedatomic"
            or "normalizedstring" or "token" or "language" or "nmtoken" or "name"
            or "ncname" or "id" or "idref" or "entity")
            return true;
        if (IsIntegerSchemaType(targetType) || targetType is "decimal" or "double" or "float" or "numeric")
            return sourceFamily is "numeric" or "boolean";
        if (targetType is "boolean")
            return sourceFamily is "boolean" or "numeric";
        if (targetType is "duration" or "yearmonthduration" or "daytimeduration")
            return sourceFamily is "duration" or "yearmonthduration" or "daytimeduration";
        if (targetType is "datetime" or "datetimestamp")
            // dateTimeStamp follows the dateTime rules (§19.3.4); the timezone requirement
            // is a value check in the cast itself (FORG0001 when absent), not a matrix rule.
            return sourceFamily is "datetime" or "date";
        if (targetType is "date")
            return sourceFamily is "datetime" or "date";
        if (targetType is "time")
            return sourceFamily is "datetime" or "time";
        if (targetType is "gyear" or "gyearmonth" or "gmonthday" or "gday" or "gmonth")
            return sourceFamily is "datetime" or "date" || sourceFamily == targetType;
        if (targetType is "qname" or "notation")
            return sourceFamily is "qname";
        if (targetType is "anyuri")
            return sourceFamily is "uri";
        if (targetType is "hexbinary" or "base64binary")
            return sourceFamily is "binary";
        // time, gYear, gYearMonth, gMonthDay, gDay, gMonth sources reach here for
        // non-date targets: rejected above except casting to themselves.
        return sourceFamily == targetType;
    }

    private static bool IsIntegerInRange(long value, string typeName)
    {
        return typeName switch
        {
            "byte" => value >= sbyte.MinValue && value <= sbyte.MaxValue,
            "short" => value >= short.MinValue && value <= short.MaxValue,
            "int" => value >= int.MinValue && value <= int.MaxValue,
            "long" or "integer" => true,
            "unsignedbyte" => value >= byte.MinValue && value <= byte.MaxValue,
            "unsignedshort" => value >= ushort.MinValue && value <= ushort.MaxValue,
            "unsignedint" => value >= uint.MinValue && value <= uint.MaxValue,
            "unsignedlong" => value >= 0,
            "positiveinteger" => value > 0,
            "negativeinteger" => value < 0,
            "nonpositiveinteger" => value <= 0,
            "nonnegativeinteger" => value >= 0,
            _ => true
        };
    }

    private static bool IsIntegerSchemaType(string? schemaTypeName)
    {
        if (string.IsNullOrEmpty(schemaTypeName)) return false;
        return schemaTypeName.ToLowerInvariant() is
            "integer" or "int" or "long" or "short" or "byte"
            or "unsignedshort" or "unsignedint" or "unsignedlong" or "unsignedbyte"
            or "positiveinteger" or "negativeinteger" or "nonpositiveinteger" or "nonnegativeinteger";
    }

    private static readonly System.Collections.Concurrent.ConcurrentDictionary<string, string> s_atomicMatchTypeNames = new();

    /// <summary>
    /// Computes the lowercased, occurrence- and xs:/xsd:-prefix-stripped type name used by
    /// the atomic/kind-test matching path of <see cref="ValueMatchesType(XdmValue, string, EvaluationContext)"/>, cached per
    /// distinct input string (the same signature type names repeat on every call). The
    /// parenthesized-type case is deliberately left in place: the matcher re-enters itself
    /// for it, so fully parenthesized inputs flow through unchanged.
    /// </summary>
    private static string NormalizeTypeNameForAtomicMatch(string typeName)
    {
        string normalized = typeName.Trim().ToLowerInvariant();

        // Strip occurrence indicator for non-sequence values. For function-family
        // types a trailing indicator only counts as an outer occurrence when it
        // directly follows the closing parenthesis of the parameter list; after an
        // 'as' clause it belongs to the return type (ArrayTest-063).
        if (normalized.Length > 0 && normalized[^1] is '?' or '*' or '+')
        {
            if (normalized.StartsWith("function(") || normalized.StartsWith("map(") || normalized.StartsWith("array("))
                (normalized, _) = StripOuterOccurrence(normalized);
            else
                normalized = normalized[..^1].TrimEnd();
        }

        // Strip xs:/xsd: prefix
        if (normalized.StartsWith("xs:"))
            normalized = normalized[3..];
        else if (normalized.StartsWith("xsd:"))
            normalized = normalized[4..];

        return normalized;
    }

    /// <summary>
    /// Checks whether an XDM value matches a declared type name (e.g. "xs:string", "element(foo)").
    /// </summary>
    /// <param name="value">The value to test.</param>
    /// <param name="typeName">The sequence type string to match against.</param>
    /// <returns><c>true</c> when the value matches the type.</returns>
    public static bool ValueMatchesType(XdmValue value, string typeName)
        => ValueMatchesType(value, typeName, null);

    /// <summary>
    /// Checks whether a value matches a sequence type, with an optional evaluation
    /// context that enables signature-aware matching of named function items.
    /// </summary>
    /// <param name="value">The value to test.</param>
    /// <param name="typeName">The sequence type string to match against.</param>
    /// <param name="context">An optional evaluation context used to match named function items by signature.</param>
    /// <returns><c>true</c> when the value matches the type.</returns>
    public static bool ValueMatchesType(XdmValue value, string typeName, EvaluationContext? context)
    {
        if (string.IsNullOrEmpty(typeName)) return true;

        if (context is not null && context.TryResolveNamedRecordType(typeName, context.DefaultElementNamespace, out var namedRecord))
            return value.IsMap && ReferenceEquals(value.MapValue?.RecordType, namedRecord);

        // XPath 4.0 §3.2.5/§3.2.6: choice item types and enumeration types are matched
        // structurally, before QName resolution and case-folding. Enum members compare
        // with codepoint (ordinal) equality against the string datum of any xs:string
        // instance; a choice matches when any alternative matches. Sequence values were
        // handled above the single-item path by the caller's per-item recursion.
        var rawText = typeName.Trim();
        if (rawText.Length > 1 && rawText[^1] is '?' or '*' or '+')
            rawText = rawText[..^1].TrimEnd();
        if (TryGetChoiceAlternatives(rawText, out var choiceAlternatives))
        {
            if (value.IsUndefined) return false;
            foreach (var alternative in choiceAlternatives)
                if (ValueMatchesType(value, alternative, context))
                    return true;
            return false;
        }
        if (TryGetEnumMembers(rawText) is { } enumMembers)
        {
            // xs:untypedAtomic is not an instance of xs:string, so it never matches an
            // enumeration type (the cast/coercion paths convert it first, §3.4.2 rule 05).
            return !value.IsUndefined && !value.IsSequence
                && value.Kind == XdmValueKind.String && !IsUntypedAtomicValue(value)
                && enumMembers.Contains(AtomizedString(value), StringComparer.Ordinal);
        }
        // XPath 4.0 §3.2.10: record types match structurally — a plain map never matches,
        // an annotated record matches record(*) and, for a typed record type, matches when
        // its shape is exactly the declared fields with matching values.
        if (IsRecordTypeText(rawText))
        {
            var recordTarget = TryGetRecordType(rawText);
            return recordTarget is not null && RecordValueMatchesType(value, recordTarget, context);
        }

        // Unwrap redundant outer parentheses: (function(xs:integer) as xs:integer) is the
        // same type as function(xs:integer) as xs:integer (hof-013).
        var unwrapped = typeName.Trim();
        while (unwrapped.Length > 1 && unwrapped[0] == '(' && FindMatchingParen(unwrapped, 0) == unwrapped.Length - 1)
            unwrapped = unwrapped[1..^1].Trim();
        typeName = NormalizeEQNameTypeName(unwrapped);

        // empty-sequence() only matches the empty sequence.
        if (typeName.Trim().Equals("empty-sequence()", StringComparison.OrdinalIgnoreCase))
        {
            if (value.IsUndefined) return true;
            // Peek-based: a lazy empty sequence reports unknown length.
            return value.IsSequence && !SequenceHasAnyItem(value);
        }

        // Sequence values (including the empty sequence) must be checked against the
        // occurrence indicator of the sequence type. Each item is matched against the
        // base type recursively so that node tests, function types, and atomic types
        // are handled uniformly.
        if (value.IsUndefined || (value.IsSequence && value.SequenceValue != null))
        {
            var trimmed = typeName.Trim();
            char occ = '\0';
            if (trimmed.Length > 0 && "?+*".Contains(trimmed[^1]))
            {
                occ = trimmed[^1];
                trimmed = trimmed[..^1].TrimEnd();
            }

            var items = new List<XdmValue>();
            if (!value.IsUndefined && value.SequenceValue != null)
            {
                foreach (var item in XdmSequence.FromSource(value.SequenceValue))
                    items.Add(item);
            }

            switch (occ)
            {
                case '?':
                    if (items.Count > 1) return false;
                    break;
                case '*':
                    break;
                case '+':
                    if (items.Count == 0) return false;
                    break;
                default:
                    if (items.Count != 1) return false;
                    break;
            }

            foreach (var item in items)
            {
                if (!ValueMatchesType(item, trimmed, context))
                    return false;
            }
            return true;
        }

        // Cached normalization (lowercase, occurrence/prefix strip) — the same signature
        // type names repeat on every call.
        string normalized = s_atomicMatchTypeNames.GetOrAdd(typeName, static t => NormalizeTypeNameForAtomicMatch(t));

        // Unwrap one layer of redundant outer parentheses: (function(...) as T) is
        // equivalent to function(...) as T.
        if (normalized.Length > 1 && normalized[0] == '(' && FindMatchingParen(normalized, 0) == normalized.Length - 1)
            return ValueMatchesType(value, typeName.Trim()[1..^1], context);

        if (normalized == "item()")
            return !value.IsUndefined;

        if (normalized == "node()")
            return value.IsNode;

        if (normalized.StartsWith("element(") && normalized.EndsWith(')'))
        {
            ValidateKindTestSchemaType(typeName, context);
            if (!value.IsNode || value.NodeValue.NodeKind != XdmNodeKind.Element)
                return false;
            var inner = normalized.Substring(8, normalized.Length - 9).Trim();
            // element() or element(*) → any element
            if (string.IsNullOrEmpty(inner) || inner == "*")
                return true;
            // element(name) or element(name, T) → check name match.
            // Use the case-preserved type string so local names such as 'A' and schema
            // type names such as 'stringType' are not lowercased.
            var casePreserved = GetCasePreservedTypeName(typeName);
            var cpInner = casePreserved.Substring(8, casePreserved.Length - 9).Trim();
            // element(*, T) → check type compatibility
            if (cpInner.StartsWith("*, "))
            {
                var typePart = cpInner.Substring(3).Trim();
                return IsElementTypeCompatible(typePart, context, value.NodeValue);
            }
            var nodeParts = SplitNodeTestParts(cpInner, ',');
            var names = SplitNodeTestParts(nodeParts[0], '|');
            if (names.Length > 1)
                return names.Any(name => ValueMatchesType(value, "element(" + name +
                    (nodeParts.Length > 1 ? "," + nodeParts[1] : string.Empty) + ")", context));
            var namePart = nodeParts[0];
            if (namePart != "*")
            {
                if (namePart.StartsWith("*:", StringComparison.Ordinal))
                {
                    if (value.NodeValue.LocalName != namePart[2..]) return false;
                }
                else if (namePart.StartsWith("Q{", StringComparison.Ordinal))
                {
                    // Q{uri}local — match namespace URI and local name exactly.
                    var closeBrace = namePart.IndexOf('}');
                    if (closeBrace >= 2)
                    {
                        if ((namePart[(closeBrace + 1)..] != "*" && value.NodeValue.LocalName != namePart[(closeBrace + 1)..]) ||
                            value.NodeValue.NamespaceUri != namePart[2..closeBrace])
                            return false;
                    }
                }
                else
                {
                    var testLocalName = namePart.Contains(':') ? namePart[(namePart.IndexOf(':') + 1)..] : namePart;
                    if (testLocalName != "*" && value.NodeValue.LocalName != testLocalName)
                        return false;
                    if (namePart.Contains(':'))
                    {
                        // A prefixed element name also matches on the resolved namespace URI when a
                        // resolution context is available (K2-DirectConElemNamespace-79: element(P:L)
                        // distinguishes URL1 from URL2); context-less checks stay local-name-only.
                        if (context is not null)
                        {
                            var namePrefix = namePart[..namePart.IndexOf(':')];
                            if (!context.TryResolveNamespace(namePrefix, out var nameNs))
                                throw new InvalidOperationException($"XPST0081: Prefix '{namePrefix}' is not declared.");
                            if (value.NodeValue.NamespaceUri != nameNs)
                                return false;
                        }
                    }
                    else if (value.NodeValue.NamespaceUri != (context?.DefaultElementNamespace ?? ""))
                    {
                        // An unprefixed element name uses the default element namespace
                        // (or no namespace when none is declared).
                        return false;
                    }
                }
            }
            if (nodeParts.Length > 1)
            {
                var typePart = nodeParts[1];
                return IsElementTypeCompatible(typePart, context, value.NodeValue);
            }
            return true;
        }

        if (normalized.StartsWith("attribute(") && normalized.EndsWith(')'))
        {
            ValidateKindTestSchemaType(typeName, context);
            if (!value.IsNode || value.NodeValue.NodeKind != XdmNodeKind.Attribute)
                return false;
            // attribute(name) or attribute(name, T) → check name match.
            // Use the case-preserved type string so local names keep their original case.
            var casePreserved = GetCasePreservedTypeName(typeName);
            var cpInner = casePreserved.Substring(10, casePreserved.Length - 11).Trim();
            // attribute() or attribute(*) → any attribute
            if (string.IsNullOrEmpty(cpInner) || cpInner == "*")
                return true;
            // attribute(*, T) → check type compatibility
            if (cpInner.StartsWith("*, "))
            {
                var typePart = cpInner.Substring(3).Trim();
                return IsAttributeTypeCompatible(typePart, context, value.NodeValue);
            }
            var nodeParts = SplitNodeTestParts(cpInner, ',');
            var names = SplitNodeTestParts(nodeParts[0], '|');
            if (names.Length > 1)
                return names.Any(name => ValueMatchesType(value, "attribute(" + name +
                    (nodeParts.Length > 1 ? "," + nodeParts[1] : string.Empty) + ")", context));
            var namePart = nodeParts[0];
            if (namePart != "*")
            {
                if (namePart.StartsWith("*:", StringComparison.Ordinal))
                {
                    if (value.NodeValue.LocalName != namePart[2..]) return false;
                }
                else if (namePart.StartsWith("Q{", StringComparison.Ordinal))
                {
                    // Q{uri}local — match namespace URI and local name exactly.
                    var closeBrace = namePart.IndexOf('}');
                    if (closeBrace >= 2)
                    {
                        if ((namePart[(closeBrace + 1)..] != "*" && value.NodeValue.LocalName != namePart[(closeBrace + 1)..]) ||
                            value.NodeValue.NamespaceUri != namePart[2..closeBrace])
                            return false;
                    }
                }
                else
                {
                    var testLocalName = namePart.Contains(':') ? namePart[(namePart.IndexOf(':') + 1)..] : namePart;
                    if (testLocalName != "*" && value.NodeValue.LocalName != testLocalName)
                        return false;
                    if (namePart.Contains(':'))
                    {
                        // A prefixed attribute name also matches on the resolved namespace URI when a
                        // resolution context is available; context-less checks stay local-name-only.
                        if (context is not null)
                        {
                            var namePrefix = namePart[..namePart.IndexOf(':')];
                            if (!context.TryResolveNamespace(namePrefix, out var nameNs))
                                throw new InvalidOperationException($"XPST0081: Prefix '{namePrefix}' is not declared.");
                            if (value.NodeValue.NamespaceUri != nameNs)
                                return false;
                        }
                    }
                    else if (value.NodeValue.NamespaceUri != "")
                    {
                        // An unprefixed attribute name always matches no namespace.
                        return false;
                    }
                }
            }
            if (nodeParts.Length > 1)
            {
                var typePart = nodeParts[1];
                return IsAttributeTypeCompatible(typePart, context, value.NodeValue);
            }
            return true;
        }

        // document-node(element(...)) / document-node(schema-element(...)) — check document
        // node and match its single child element against the nested kind test.
        if (normalized.StartsWith("document-node(", StringComparison.Ordinal) && normalized.EndsWith(')'))
        {
            if (!value.IsNode || value.NodeValue.NodeKind != XdmNodeKind.Document)
                return false;
            // Preserve the original case of the nested kind test (e.g. element(Root) or
            // schema-element(j:array)).
            var casePreserved = GetCasePreservedTypeName(typeName);
            var inner = casePreserved.Substring("document-node(".Length, casePreserved.Length - "document-node(".Length - 1).Trim();
            // Bare document-node() matches any document node; only the parameterized form
            // requires exactly one child element and matches it against the inner test.
            if (string.IsNullOrEmpty(inner))
                return true;
            var childElems = new List<XdmValue>();
            foreach (var c in value.NodeValue.Axis(XdmAxis.Child))
            {
                if (c.NodeValue?.NodeKind == XdmNodeKind.Element)
                    childElems.Add(c);
            }
            if (childElems.Count != 1)
                return false;
            return ValueMatchesType(XdmValue.FromNode(childElems[0].NodeValue!), inner, context);
        }

        if (normalized is "document-node()" or "document-node")
            return value.IsNode && value.NodeValue.NodeKind == XdmNodeKind.Document;

        if (normalized.StartsWith("schema-element(") && normalized.EndsWith(')'))
        {
            if (!value.IsNode || value.NodeValue.NodeKind != XdmNodeKind.Element)
                return false;
            var casePreserved = GetCasePreservedTypeName(typeName);
            var inner = casePreserved.Substring("schema-element(".Length, casePreserved.Length - "schema-element(".Length - 1).Trim();
            return MatchesSchemaElement(value.NodeValue, inner, context);
        }

        if (normalized.StartsWith("schema-attribute(") && normalized.EndsWith(')'))
        {
            if (!value.IsNode || value.NodeValue.NodeKind != XdmNodeKind.Attribute)
                return false;
            var casePreserved = GetCasePreservedTypeName(typeName);
            var inner = casePreserved.Substring("schema-attribute(".Length, casePreserved.Length - "schema-attribute(".Length - 1).Trim();
            return MatchesSchemaAttribute(value.NodeValue, inner, context);
        }

        if (normalized is "text()" or "text")
            return value.IsNode && value.NodeValue.NodeKind == XdmNodeKind.Text;

        if (normalized is "comment()" or "comment")
            return value.IsNode && value.NodeValue.NodeKind == XdmNodeKind.Comment;

        if (normalized is "processing-instruction()" or "processing-instruction")
            return value.IsNode && value.NodeValue.NodeKind == XdmNodeKind.ProcessingInstruction;

        if (normalized.StartsWith("processing-instruction(", StringComparison.Ordinal))
        {
            var text = GetCasePreservedTypeName(typeName);
            return XPathParser.TryParseProcessingInstructionTypeTarget(text, out var target)
                && value.IsNode && value.NodeValue.NodeKind == XdmNodeKind.ProcessingInstruction
                && (target is null || string.Equals(value.NodeValue.LocalName, target, StringComparison.Ordinal));
        }

        if (normalized is "namespace-node()" or "namespace-node")
            return value.IsNode && value.NodeValue.NodeKind == XdmNodeKind.Namespace;

        // Handle typed function signatures before general normalization, because function
        // type strings contain nested type names whose occurrence indicators and xs: prefixes
        // must not be stripped by the general normalization logic.
        string trimmedLower = typeName.Trim().ToLowerInvariant();
        if (trimmedLower.StartsWith("function(") && !trimmedLower.StartsWith("function(*)"))
        {
            if (TryParseFunctionType(typeName.Trim(), out var testParamTypes, out var testReturnType))
            {
                // function(*) wildcard falls through to the check below
                bool isFunctionStar = testParamTypes.Length == 1 && testParamTypes[0] == "*";
                if (!isFunctionStar)
                {
                    // Maps and arrays are function items: match them against their
                    // implied signature (MapTest-059..066, ArrayTest-043).
                    if (value.IsMap || value.IsArray)
                        return MapOrArrayMatchesFunctionType(value, testParamTypes, testReturnType, context);
                    if (!value.IsFunction) return false;
                    if (TryGetInlineFunctionSignature(value, out var actualParamTypes, out var actualReturnType))
                    {
                        if (actualParamTypes.Length != testParamTypes.Length) return false;
                        // Parameter types are contravariant: test param must be subtype of actual param
                        for (int i = 0; i < testParamTypes.Length; i++)
                        {
                            if (!IsSequenceTypeSubtype(testParamTypes[i], actualParamTypes[i], context))
                                return false;
                        }
                        // Return type is covariant: actual return must be subtype of test return
                        if (!IsSequenceTypeSubtype(actualReturnType, testReturnType, context))
                            return false;
                        return true;
                    }
                    // Named function items: when an evaluation context is available,
                    // match against the registered declared signature (ArrayTest-064/084).
                    if (context != null)
                        return FunctionItemInstanceOf(value, typeName, context);
                    // Named, curried, or delegate function items: the declared parameter and
                    // return types are not available without an evaluation context, so match
                    // on arity only. Argument types are re-checked against the target
                    // function's own signature when the item is invoked.
                    return TryGetFunctionArity(value, out var arity) && arity == testParamTypes.Length;
                }
            }
        }

        if (normalized is "function(*)" or "function")
            return value.IsFunction || value.IsMap || value.IsArray;

        // Parameterized map types: map(K, V). Empty maps match any key/value types;
        // otherwise every entry must match the declared key and value types.
        // Split the parameters from the case-preserved type string: Q{uri} type names
        // inside the parameter list lose the xs-namespace recognition when lowercased.
        if (normalized.StartsWith("map(") && normalized.EndsWith(')'))
        {
            if (!value.IsMap) return false;
            var casePreservedMap = GetCasePreservedTypeName(typeName);
            var inner = casePreservedMap.Substring(4, casePreservedMap.Length - 5).Trim();
            if (string.IsNullOrEmpty(inner) || inner == "*")
                return true;
            var parts = SplitTopLevel(inner, ',');
            if (parts.Length != 2)
                throw new InvalidOperationException(
                    "XPST0003: A map type test takes either zero or two arguments, e.g. map(xs:string, xs:integer)");
            string keyType = parts[0].Trim();
            string valueType = parts[1].Trim();
            if (keyType.Length > 0 && keyType[^1] is '?' or '*' or '+')
                throw new InvalidOperationException(
                    "XPST0003: The key type of a map type test must be an item type without an occurrence indicator");
            foreach (var entry in value.MapValue.Entries)
            {
                if (!ValueMatchesType(entry.Key, keyType, context)) return false;
                if (!ValueMatchesType(entry.Value, valueType, context)) return false;
            }
            return true;
        }

        // Parameterized array types: array(T). Empty arrays match any member type;
        // otherwise every member must match the declared type. As with map(K, V),
        // split from the case-preserved string so Q{uri} member types survive intact.
        if (normalized.StartsWith("array(") && normalized.EndsWith(')'))
        {
            if (!value.IsArray) return false;
            var casePreservedArray = GetCasePreservedTypeName(typeName);
            var inner = casePreservedArray.Substring(6, casePreservedArray.Length - 7).Trim();
            if (string.IsNullOrEmpty(inner) || inner == "*")
                return true;
            foreach (var member in value.ArrayValue.Values)
            {
                if (!ValueMatchesType(member, inner, context)) return false;
            }
            return true;
        }

        // XPath 4.0 §17.7: jnode type tests. jnode() / jnode(*) match any JNode;
        // jnode(()) matches a root (keyless) JNode; jnode(K) matches the entry key
        // against the key specifier K ('*', '()', a string literal, an NCName treated
        // as a string key, an integer literal, or a '#' QName literal) using atomic-equal
        // semantics; jnode(K, T) additionally matches the jvalue against sequence type T.
        // Split from the case-preserved string so nested Q{uri} types survive intact.
        if (normalized.StartsWith("jnode(") && normalized.EndsWith(')'))
        {
            if (!value.IsJNode) return false;
            var casePreservedJnode = GetCasePreservedTypeName(typeName);
            var jnodeInner = casePreservedJnode.Substring(6, casePreservedJnode.Length - 7).Trim();
            if (string.IsNullOrEmpty(jnodeInner) || jnodeInner == "*")
                return true;
            var jnodeParts = SplitTopLevel(jnodeInner, ',');
            if (jnodeParts.Length > 2)
                throw new InvalidOperationException(
                    "XPST0003: A jnode type test takes at most two arguments, e.g. jnode(*, item()*)");
            if (!JNodeKeyMatches(value.JNodeValue, jnodeParts[0].Trim(), context)) return false;
            if (jnodeParts.Length == 2)
                return ValueMatchesType(value.JNodeValue.Value, jnodeParts[1].Trim(), context);
            return true;
        }

        if (normalized is "map(*)" or "map")
            return value.IsMap;

        if (normalized is "array(*)" or "array")
            return value.IsArray;

        // User-defined schema simple types: a value matches by IDENTITY, not castability —
        // the value must carry the user-defined type annotation itself (REQ-108). A built-in
        // typed or untyped value is not an instance of a user-defined type even when it is
        // castable to it (as-2002). Union types are different: instance-of uses membership
        // semantics, so the value must already match one of the member types.
        if (IsUserDefinedSchemaType(typeName, context, out var schemaSimpleType)
            && TryGetSchemaSimpleType(schemaSimpleType.QualifiedName.Namespace, schemaSimpleType.QualifiedName.Name, context, out var concreteType))
        {
            if (GetSchemaTypeVariety(concreteType) == SchemaTypeVariety.Union)
            {
                foreach (var member in GetUnionMemberTypes(concreteType, context))
                {
                    if (member is null)
                        continue;
                    if (ValueMatchesType(value, FormatSchemaTypeName(member), context))
                        return true;
                }
                return false;
            }

            string? userTypeName = value.UserSchemaTypeName;
            if (userTypeName is null)
                return false;

            // Parse the Q{uri}local annotation into its namespace and local parts; a
            // malformed annotation cannot establish identity.
            if (!userTypeName.StartsWith("Q{", StringComparison.Ordinal))
                return false;
            int separator = userTypeName.IndexOf('}');
            if (separator < 2)
                return false;
            string userNs = userTypeName.Substring(2, separator - 2);
            string userLocal = userTypeName[(separator + 1)..];

            if (context?.SchemaSet is null)
            {
                // Without a schema set the hierarchy cannot be walked: only exact QName
                // equality establishes identity.
                return string.Equals(userNs, concreteType.QualifiedName.Namespace, StringComparison.Ordinal)
                    && string.Equals(userLocal, concreteType.QualifiedName.Name, StringComparison.Ordinal);
            }

            return IsSchemaTypeSubtype(context, userNs, userLocal,
                concreteType.QualifiedName.Namespace, concreteType.QualifiedName.Name);
        }

        return ItemInstanceOf(value, normalized);
    }

    /// <summary>
    /// Strips occurrence indicators and the <c>xs:/xsd:</c> prefix from a type name
    /// while preserving the original case of the remaining text (needed for element
    /// and attribute local-name matching).
    /// </summary>
    private static string GetCasePreservedTypeName(string typeName)
    {
        var s = typeName.Trim();
        if (s.EndsWith('?') || s.EndsWith('*') || s.EndsWith('+'))
            s = s[..^1].TrimEnd();
        if (s.StartsWith("xs:"))
            s = s[3..];
        else if (s.StartsWith("xsd:"))
            s = s[4..];
        return s;
    }

    /// <summary>
    /// Parses a function type string such as <c>function(item()*, xs:double) as xs:double</c>.
    /// </summary>
    /// <summary>
    /// Parses a function type string such as <c>function(item()*, xs:double) as xs:double</c>.
    /// Returns false for malformed types; a typed function test must include the
    /// <c>as</c> return clause (only <c>function(*)</c> may omit it).
    /// </summary>
    /// <param name="typeName">The function type string.</param>
    /// <param name="paramTypes">The declared parameter sequence types.</param>
    /// <param name="returnType">The declared return sequence type.</param>
    /// <returns>True if the type string is well-formed.</returns>
    public static bool TryParseFunctionType(string typeName, out string[] paramTypes, out string returnType)
    {
        paramTypes = [];
        returnType = "item()*";

        string s = typeName.Trim();
        if (!s.StartsWith("function(", StringComparison.OrdinalIgnoreCase))
            return false;

        int openIdx = s.IndexOf('(');
        int closeIdx = FindMatchingParen(s, openIdx);
        if (closeIdx < 0) return false;

        string paramList = s.Substring(openIdx + 1, closeIdx - openIdx - 1).Trim();
        if (string.IsNullOrEmpty(paramList))
        {
            paramTypes = [];
        }
        else if (paramList == "*")
        {
            paramTypes = ["*"];
        }
        else
        {
            paramTypes = SplitTopLevel(paramList, ',');
        }

        string after = s.Substring(closeIdx + 1).Trim();
        if (after.StartsWith("as ", StringComparison.OrdinalIgnoreCase))
        {
            returnType = after.Substring(3).Trim();
            return true;
        }

        // function(*) is the only form that may omit the 'as' return clause; a typed
        // function test without 'as' is malformed (XPST0003).
        if (paramList == "*" && string.IsNullOrEmpty(after))
            return true;
        return false;
    }

    /// <summary>
    /// Finds the index of the closing parenthesis that matches the opening parenthesis at <paramref name="openIdx"/>.
    /// </summary>
    private static int FindMatchingParen(string s, int openIdx)
    {
        int depth = 0;
        for (int i = openIdx; i < s.Length; i++)
        {
            if (s[i] == '(') depth++;
            else if (s[i] == ')') depth--;
            if (depth == 0) return i;
        }
        return -1;
    }

    /// <summary>Splits node-test names and annotations without dividing EQName namespace URIs.</summary>
    private static string[] SplitNodeTestParts(string text, char delimiter)
    {
        var parts = new List<string>();
        int start = 0;
        bool inUri = false;
        for (int i = 0; i < text.Length; i++)
        {
            if (text[i] == '{') inUri = true;
            else if (text[i] == '}') inUri = false;
            else if (text[i] == delimiter && !inUri)
            {
                parts.Add(text[start..i].Trim());
                start = i + 1;
            }
        }
        parts.Add(text[start..].Trim());
        return parts.ToArray();
    }

    /// <summary>
    /// Splits a string by a delimiter, respecting nested parentheses.
    /// </summary>
    private static string[] SplitTopLevel(string s, char delimiter)
    {
        var parts = new List<string>();
        int depth = 0;
        int start = 0;
        for (int i = 0; i < s.Length; i++)
        {
            if (s[i] == '(') depth++;
            else if (s[i] == ')') depth--;
            else if (s[i] == delimiter && depth == 0)
            {
                parts.Add(s.Substring(start, i - start).Trim());
                start = i + 1;
            }
        }
        parts.Add(s.Substring(start).Trim());
        return parts.ToArray();
    }

    /// <summary>
    /// Splits a choice item type (XPath 4.0 §3.2.5) into its alternative item type texts.
    /// Returns false when the text contains no top-level '|' (it is not a choice). The
    /// split is parenthesis-respecting, so '|' inside enum members or kind tests does
    /// not divide alternatives.
    /// </summary>
    private static bool TryGetChoiceAlternatives(string typeText, out string[] alternatives)
    {
        alternatives = [];
        var trimmed = typeText.Trim();
        // Redundant outer parentheses do not change the type: unwrap before scanning so
        // both "(a|b)" and "a|b" are recognised (the matcher unwraps later anyway).
        while (trimmed.Length > 1 && trimmed[0] == '(' && FindMatchingParen(trimmed, 0) == trimmed.Length - 1)
            trimmed = trimmed[1..^1].Trim();
        if (trimmed.IndexOf('|') < 0)
            return false;
        var parts = SplitTopLevel(trimmed, '|');
        if (parts.Length < 2 || parts.Any(p => p.Length == 0))
            return false;
        alternatives = parts;
        return true;
    }

    /// <summary>
    /// Parses an enumeration type text (XPath 4.0 §3.2.6, <c>enum("a", "b", ...)</c>) into
    /// its member values. Returns null when the text is not a well-formed enumeration type.
    /// The parser-side validator (<c>Parser.XPathParser.TryParseEnumTypeMembers</c>)
    /// guarantees well-formedness for expressions that compiled successfully.
    /// </summary>
    private static string[]? TryGetEnumMembers(string typeText)
        => XPathParser.TryParseEnumTypeMembers(typeText);

    /// <summary>
    /// Returns true when the sequence-type text denotes an XPath 4.0 enumeration type or
    /// choice item type, either of which bypasses QName-based type resolution.
    /// </summary>
    private static bool IsEnumOrChoiceTypeText(string typeText)
        => TryGetEnumMembers(typeText) is not null || TryGetChoiceAlternatives(typeText, out _);

    /// <summary>
    /// Returns true when the sequence-type text denotes an XPath 4.0 structural record
    /// type (§3.2.10): <c>record(*)</c> or <c>record(field, ...)</c>. Such texts are
    /// structural, not QNames, so they bypass QName-based type resolution everywhere
    /// enum/choice texts do.
    /// </summary>
    private static bool IsRecordTypeText(string typeText)
    {
        var trimmed = typeText.Trim();
        if (trimmed.Equals("record(*)", StringComparison.Ordinal)) return true;
        return XPathParser.TryParseRecordTypeFields(trimmed) is not null;
    }

    /// <summary>
    /// Parses a record-type text into its annotation form (fields in declaration order
    /// plus the verbatim text). Returns <see cref="XdmRecordType.Any"/> for
    /// <c>record(*)</c>; <see langword="null"/> when the text is not a well-formed
    /// record type (the parser-side validator guarantees well-formedness for compiled
    /// expressions; duplicates were rejected with XPST0021 at parse time).
    /// </summary>
    private static XdmRecordType? TryGetRecordType(string typeText)
    {
        var trimmed = typeText.Trim();
        if (trimmed.Equals("record(*)", StringComparison.Ordinal)) return XdmRecordType.Any;
        var fields = XPathParser.TryParseRecordTypeFields(trimmed);
        return fields is null ? null : new XdmRecordType(fields, trimmed);
    }

    /// <summary>The map key for a record field: a string atomic value equal to the field name.</summary>
    private static XdmValue RecordFieldKey(string fieldName) => XdmValue.FromString(fieldName);

    /// <summary>
    /// XPath 4.0 §3.2.10 structural matching: a value matches a record type only when it
    /// is a map carrying a record annotation (plain maps never match), and for a typed
    /// record type the entry count equals the field count and every declared field is
    /// present with a value matching its declared type. Field values are matched
    /// recursively, which gives the spec's covariant field-type subtyping.
    /// </summary>
    private static bool RecordValueMatchesType(XdmValue value, XdmRecordType target, EvaluationContext? context)
    {
        if (value.IsUndefined || value.IsSequence || !value.IsMap) return false;
        var map = value.MapValue;
        if (map.RecordType is null) return false;
        if (target.IsAny) return true;
        if (map.Count != target.Fields.Count) return false;
        foreach (var field in target.Fields)
        {
            if (!map.TryGetValue(RecordFieldKey(field.Name), out var fieldValue)) return false;
            if (!ValueMatchesType(fieldValue, field.SequenceTypeText, context)) return false;
        }
        return true;
    }

    /// <summary>The whole-pattern declared type text of a destructuring binding, including
    /// its occurrence indicator.</summary>
    private static string WholeTypeText(in DestructuringInfo info)
        => info.WholeTypeName! + info.WholeOccurrence switch
        {
            OccurrenceIndicator.ZeroOrOne => "?",
            OccurrenceIndicator.ZeroOrMore => "*",
            OccurrenceIndicator.OneOrMore => "+",
            _ => "",
        };

    /// <summary>
    /// Stores one destructured variable: the per-variable declared type (when present)
    /// coerces the extracted value with the function-conversion rules (PR1131), then the
    /// value is bound under the same key form StoreVariable uses.
    /// </summary>
    private static void StoreDestructuredVariable(in DestructuredVariableInfo variable, XdmValue value, EvaluationContext context)
    {
        if (variable.DeclaredTypeName is not null)
        {
            string targetType = variable.DeclaredTypeName + variable.Occurrence switch
            {
                OccurrenceIndicator.ZeroOrOne => "?",
                OccurrenceIndicator.ZeroOrMore => "*",
                OccurrenceIndicator.OneOrMore => "+",
                _ => "",
            };
            value = ApplyFunctionConversion(value, targetType, context);
        }
        if (variable.VariableKey is ValueTuple<string, string> resolved)
        {
            context.WithVariable(resolved.Item1, value, resolved.Item2);
        }
        else
        {
            var (localName, nsUri) = ResolveVariableName((string)variable.VariableKey, context);
            context.WithVariable(localName, value, nsUri);
        }
    }

    /// <summary>The single array a <c>let $[...]</c> binding decomposes: exactly one item,
    /// which must be an array, else XPTY0004 (let-arr-020/021).</summary>
    private static XdmArray SingleArrayItem(XdmValue value)
    {
        var item = SingleContainerItem(value, "array");
        if (!item.IsArray)
            throw new InvalidOperationException($"XPTY0004: An array destructuring binding requires a single array, got {item.Kind}.");
        return item.ArrayValue;
    }

    /// <summary>The single map a <c>let ${...}</c> binding decomposes: exactly one item,
    /// which must be a map, else XPTY0004 (let-map-019/021).</summary>
    private static XdmMap SingleMapItem(XdmValue value)
    {
        var item = SingleContainerItem(value, "map");
        if (!item.IsMap)
            throw new InvalidOperationException($"XPTY0004: A map destructuring binding requires a single map, got {item.Kind}.");
        return item.MapValue;
    }

    private static XdmValue SingleContainerItem(XdmValue value, string kind)
    {
        if (value.IsUndefined)
            throw new InvalidOperationException($"XPTY0004: A {kind} destructuring binding requires a single {kind}; got the empty sequence.");
        if (value.IsSequence && value.SequenceValue is not null)
        {
            var items = MaterializeSequence(value);
            if (items.Length != 1)
                throw new InvalidOperationException($"XPTY0004: A {kind} destructuring binding requires a single {kind}; got {items.Length} items.");
            return items[0];
        }
        return value;
    }

    /// <summary>
    /// Whole-pattern type coercion of an array destructuring: the declared type must be
    /// an array type (a non-array type such as <c>xs:integer*</c> is XPTY0004,
    /// let-arr-019); each member is coerced to the declared member type and the array is
    /// rebuilt so the extracted variables carry the coerced members (let-arr-006/007).
    /// </summary>
    private static XdmArray CoerceDestructuredArray(XdmArray array, in DestructuringInfo info, EvaluationContext context)
    {
        var typeText = info.WholeTypeName!.Trim();
        if (typeText is "array(*)" or "array")
            return array;
        if (!typeText.StartsWith("array(", StringComparison.Ordinal) || !typeText.EndsWith(')'))
            throw new InvalidOperationException(
                $"XPTY0004: The declared type '{info.WholeTypeName}' of an array destructuring binding is not an array type.");
        var memberTypeText = typeText[6..^1].Trim();
        if (memberTypeText == "*")
            return array;
        if (memberTypeText.Length == 0)
        {
            if (array.Count != 0)
                throw new InvalidOperationException(
                    $"XPTY0004: The array has {array.Count} members but the declared type is the empty array type 'array()'.");
            return array;
        }
        var members = new XdmValue[array.Count];
        for (int i = 0; i < members.Length; i++)
            members[i] = ApplyFunctionConversion(array.Get(i + 1), memberTypeText, context);
        return new XdmArray(members);
    }

    /// <summary>
    /// Whole-pattern type coercion of a map destructuring against <c>map(K, V)</c>: every
    /// key must match K and every value is coerced to V, producing a new map so the
    /// extracted variables carry the coerced values (let-map-006/007/008).
    /// </summary>
    private static XdmMap CoerceDestructuredMap(XdmMap map, string typeText, EvaluationContext context)
    {
        var inner = typeText.Substring(4, typeText.Length - 5).Trim();
        if (inner.Length == 0 || inner == "*")
            return map;
        var parts = SplitTopLevel(inner, ',');
        if (parts.Length != 2)
            throw new InvalidOperationException(
                "XPST0003: A map type test takes either zero or two arguments, e.g. map(xs:string, xs:integer)");
        string keyType = parts[0].Trim();
        string valueType = parts[1].Trim();
        if (keyType.Length > 0 && keyType[^1] is '?' or '*' or '+')
            throw new InvalidOperationException(
                "XPST0003: The key type of a map type test must be an item type without an occurrence indicator");
        var result = new XdmMap();
        foreach (var entry in map.Entries)
        {
            if (!ValueMatchesType(entry.Key, keyType, context))
                throw new InvalidOperationException(
                    $"XPTY0004: The map key {entry.Key} does not match the declared key type '{keyType}' of the map destructuring binding.");
            result = result.WithAdded(entry.Key, ApplyFunctionConversion(entry.Value, valueType, context));
        }
        return result;
    }

    /// <summary>
    /// XPath 4.0 §3.4.2 rule 10 (record coercion): builds a new map annotated with the
    /// target record type. A surplus key is a type error (XPTY0004); a missing field
    /// becomes an entry with the empty sequence (XPTY0004 when the field type does not
    /// allow empty); a present value is converted recursively to the field type. Entries
    /// are stored in field-declaration order. For <c>record(*)</c> the map must already
    /// carry a record annotation, otherwise a plain map has no coercion rule (XPTY0004).
    /// </summary>
    private static XdmMap CoerceMapToRecord(XdmMap map, XdmRecordType target, string targetText, EvaluationContext? context)
    {
        if (target.IsAny)
        {
            if (map.RecordType is null)
                throw new InvalidOperationException($"XPTY0004: Cannot convert a plain map to {targetText}: the target type is record(*), which requires an existing record annotation.");
            return map;
        }
        // Surplus keys can never become fields of the record: reject them up front.
        foreach (var key in map.Keys)
        {
            if (key.Kind != XdmValueKind.String || !target.HasField(AtomizedString(key)))
            {
                string keyName = key.Kind == XdmValueKind.String ? AtomizedString(key) : key.ToString();
                throw new InvalidOperationException($"XPTY0004: The map contains an entry '{keyName}' that is not a declared field of the record type {target.TypeText}.");
            }
        }
        var result = new XdmMap();
        foreach (var field in target.Fields)
        {
            XdmValue fieldValue;
            if (map.TryGetValue(RecordFieldKey(field.Name), out var present))
            {
                fieldValue = ApplyFunctionConversion(present, field.SequenceTypeText, context);
            }
            else if (field.AllowsEmpty)
            {
                fieldValue = XdmValue.Undefined;
            }
            else
            {
                throw new InvalidOperationException($"XPTY0004: The required field '{field.Name}' is absent and its declared type {field.SequenceTypeText} does not allow an empty sequence.");
            }
            result.Add(RecordFieldKey(field.Name), fieldValue);
        }
        return result.WithRecordType(target);
    }

    /// <summary>
    /// XPath 4.0 §4.15.4: <c>$A but with $B</c> is equivalent to
    /// <c>let $temp as R := map:merge(($A, $B), {{'duplicates':'use-last'}}) return $temp</c>,
    /// where R is the record annotation of A. The left operand must be a record (a map
    /// with a record annotation — a plain map has no annotation to name R); the right
    /// operand must be a map. Unknown fields and values that cannot be coerced to their
    /// field types raise XPTY0004 through the record coercion of the merged map.
    /// </summary>
    internal static XdmValue ButWith(XdmValue left, XdmValue right, EvaluationContext context)
    {
        var lhsItem = SingleMapOperand(left, "left", "record");
        var annotation = lhsItem.MapValue.RecordType
            ?? throw new InvalidOperationException("XPTY0004: The left operand of 'but with' must be a record (a map with a record annotation); got a plain map.");
        var rhsItem = SingleMapOperand(right, "right", "map");
        XdmMap merged = lhsItem.MapValue;
        foreach (var entry in rhsItem.MapValue.Entries)
            merged = merged.WithAdded(entry.Key, entry.Value);
        return XdmValue.FromMap(CoerceMapToRecord(merged, annotation, annotation.TypeText, context));
    }

    /// <summary>Unwraps a singleton map operand for <c>but with</c>, raising XPTY0004 otherwise.</summary>
    private static XdmValue SingleMapOperand(XdmValue value, string side, string requirement)
    {
        if (value.IsUndefined)
            throw new InvalidOperationException($"XPTY0004: The {side} operand of 'but with' must be a {requirement}; got the empty sequence.");
        if (value.IsSequence && value.SequenceValue is not null)
        {
            var items = MaterializeSequence(value);
            if (items.Length == 1)
                value = items[0];
        }
        if (value.IsSequence || !value.IsMap)
            throw new InvalidOperationException($"XPTY0004: The {side} operand of 'but with' must be a {requirement}.");
        return value;
    }

    /// <summary>
    /// XPath 4.0 §4.15.3: the lookup operator and record-as-function calls raise XPTY0004
    /// for a key that is not a declared field of the record's annotation; plain maps keep
    /// returning the empty sequence. Wildcard lookup (<c>?*</c>) does not pass a key and
    /// is unaffected.
    /// </summary>
    private static void CheckRecordLookupKey(XdmMap map, XdmValue key)
    {
        var annotation = map.RecordType;
        if (annotation is null || annotation.IsAny)
            return;
        if (key.Kind != XdmValueKind.String && !IsUntypedAtomicValue(key))
            return;
        string name = AtomizedString(key);
        if (!annotation.HasField(name))
            throw new InvalidOperationException($"XPTY0004: The key '{name}' is not a declared field of the record type {annotation.TypeText}.");
    }

    /// <summary>
    /// Whether a choice alternative can never be the target of a cast (XPath 4.0 §19.3
    /// permits only atomic cast targets): node kind tests, function/map/array types, and
    /// item(). Such alternatives contribute a match check but no coercion attempt.
    /// </summary>
    private static bool IsNonAtomicCastAlternative(string alternative)
    {
        var t = alternative.Trim();
        if (t.Length > 0 && "?+*".Contains(t[^1]))
            t = t[..^1].TrimEnd();
        while (t.Length > 1 && t[0] == '(' && FindMatchingParen(t, 0) == t.Length - 1)
            t = t[1..^1].Trim();
        return IsNodeKindTestType(t) || IsFunctionFamilyType(t) || t is "item" or "item()";
    }

    /// <summary>
    /// Extracts the declared parameter and return types from an inline function item.
    /// </summary>
    private static bool TryGetInlineFunctionSignature(XdmValue value, out string[] paramTypes, out string returnType)
    {
        paramTypes = [];
        returnType = "item()*";

        if (!value.IsFunction) return false;

        var func = value.FunctionValue as FunctionItem;
        if (func is InlineFunctionItem inline)
        {
            paramTypes = inline.ParameterTypes.Select(pt => pt ?? "item()*").ToArray();
            returnType = inline.ReturnType ?? "item()*";
            return true;
        }

        return false;
    }

    /// <summary>
    /// XPath 3.1 function conversion rules: a function item is coercible to a function
    /// type with the same arity. Parameter and return type mismatches surface as dynamic
    /// errors when the coerced function is invoked, not at coercion time.
    /// </summary>
    /// <param name="value">The value to test.</param>
    /// <param name="functionType">The target function type, e.g. <c>function(xs:string) as xs:string</c>.</param>
    /// <returns>True if <paramref name="value"/> is a function item coercible to <paramref name="functionType"/>.</returns>
    public static bool FunctionItemCoercibleTo(XdmValue value, string functionType)
    {
        var t = functionType.Trim();
        while (t.Length > 1 && t[0] == '(' && FindMatchingParen(t, 0) == t.Length - 1)
            t = t[1..^1].Trim();
        if (!t.StartsWith("function(", StringComparison.OrdinalIgnoreCase))
            return false;
        if (!value.IsFunction)
            return false;
        if (!TryParseFunctionType(t, out var paramTypes, out _))
            throw new InvalidOperationException($"XPST0003: Malformed function type '{functionType}'");
        if (paramTypes.Length == 1 && paramTypes[0] == "*")
            return true; // function(*)
        return TryGetFunctionArity(value, out var arity) && arity == paramTypes.Length;
    }

    /// <summary>
    /// Returns the effective arity of a function item (the number of arguments a dynamic
    /// call must supply). For curried items this is the number of unbound placeholders.
    /// </summary>
    private static bool TryGetFunctionArity(XdmValue value, out int arity)
    {
        arity = 0;
        if (!value.IsFunction) return false;
        switch (value.FunctionValue as FunctionItem)
        {
            case InlineFunctionItem inline:
                arity = inline.Parameters.Count;
                return true;
            case NamedFunctionItem named:
                arity = named.ArityValue;
                return true;
            case DelegateFunctionItem del:
                arity = del.ArityValue;
                return true;
            case CurriedFunctionItem curried:
                arity = curried.FixedArgs.Count(a => a is null);
                return true;
            case CoercedFunctionItem coerced:
                arity = coerced.ParamTypes.Count;
                return true;
            default:
                return false;
        }
    }

    /// <summary>
    /// Context-aware function type test (<c>instance of function(...) as ...</c>):
    /// named function items are matched against their registered declared signature
    /// using XPath 3.1 function subtyping (contravariant parameters, covariant result);
    /// all other function items use the static matching rules.
    /// </summary>
    private static bool FunctionItemInstanceOf(XdmValue value, string typeName, EvaluationContext context)
    {
        if (!TryParseFunctionType(typeName.Trim(), out var testParamTypes, out var testReturnType))
            return false;
        if (testParamTypes.Length == 1 && testParamTypes[0] == "*")
            return value.IsFunction || value.IsMap || value.IsArray;
        // Maps and arrays are function items (MapTest-059..066, ArrayTest-042/043).
        if (value.IsMap || value.IsArray)
            return MapOrArrayMatchesFunctionType(value, testParamTypes, testReturnType, context);
        if (value.FunctionValue is not FunctionItem func)
            return false;

        if (func is NamedFunctionItem named
            && context.TryResolveFunction(named.NamespaceUri, named.LocalName, named.ArityValue, out var sig))
        {
            // Precise declared sequence types when the signature provides them; otherwise
            // derive a coarse but sound approximation from the kind-level metadata
            // (Sequence → item()*, Function → function(*), ...) so built-ins such as
            // filter#2 subtype-check structurally instead of by arity alone
            // (instanceof132/133/134).
            var actualParams = sig.ParameterTypeNames ?? CoarseParameterTypeNames(sig, named.ArityValue);
            if (actualParams.Count != testParamTypes.Length)
                return false;
            // Parameter types are contravariant: test param must be a subtype of the actual param.
            for (int i = 0; i < testParamTypes.Length; i++)
            {
                var actualParam = actualParams[i] ?? "item()*";
                if (!IsSequenceTypeSubtype(testParamTypes[i], actualParam, context))
                    return false;
            }
            // Return type is covariant: actual return must be a subtype of the test return.
            // A signature whose return kind is Undefined never returns a value (fn:error, xs:error);
            // that is equivalent to empty-sequence(), which is a subtype of every sequence type
            // (xs-error-006/007).
            var actualReturn = sig.ReturnTypeName
                ?? (sig.ReturnType == XdmValueKind.Undefined ? "empty-sequence()" : CoarseKindTypeName(sig.ReturnType));
            return IsSequenceTypeSubtype(actualReturn, testReturnType, context);
        }

        if (func is InlineFunctionItem inline)
        {
            // Inline functions: undeclared parameter/return types are item()*; subsumption
            // uses contravariant parameters and a covariant result.
            if (inline.Parameters.Count != testParamTypes.Length)
                return false;
            for (int i = 0; i < testParamTypes.Length; i++)
            {
                var actualParam = i < inline.ParameterTypes.Count ? inline.ParameterTypes[i] ?? "item()*" : "item()*";
                if (!IsSequenceTypeSubtype(testParamTypes[i], actualParam, context))
                    return false;
            }
            return IsSequenceTypeSubtype(inline.ReturnType ?? "item()*", testReturnType, context);
        }

        // Other function items (delegates, curried/coerced items, or named functions whose
        // signature cannot be resolved): precise parameter/return types are unavailable, so
        // match on arity only. Calling ValueMatchesType here would re-enter FunctionItemInstanceOf
        // for the same function item and type, causing unbounded recursion.
        return TryGetFunctionArity(value, out var arity) && arity == testParamTypes.Length;
    }

    /// <summary>
    /// Builds coarse parameter sequence-type names from a signature's kind-level metadata,
    /// sized to the referenced arity (a variadic registration such as fn:concat may carry
    /// fewer kinds than the referenced arity — the extras default to <c>item()*</c>).
    /// </summary>
    private static IReadOnlyList<string?> CoarseParameterTypeNames(FunctionSignature sig, int arity)
    {
        var names = new string?[arity];
        for (int i = 0; i < arity; i++)
            names[i] = CoarseKindTypeName(i < sig.ParameterTypes.Count ? sig.ParameterTypes[i] : XdmValueKind.Sequence);
        return names;
    }

    /// <summary>
    /// Maps a kind-level parameter/return type to a coarse sequence-type name for
    /// function-item subtyping when no precise declared type name is registered.
    /// </summary>
    private static string CoarseKindTypeName(XdmValueKind kind) => kind switch
    {
        XdmValueKind.String => "xs:string",
        XdmValueKind.Integer => "xs:integer",
        XdmValueKind.Decimal => "xs:decimal",
        XdmValueKind.Double => "xs:double",
        XdmValueKind.Float => "xs:float",
        XdmValueKind.Boolean => "xs:boolean",
        XdmValueKind.Uri => "xs:anyURI",
        XdmValueKind.QName => "xs:QName",
        XdmValueKind.Date => "xs:date",
        XdmValueKind.Time => "xs:time",
        XdmValueKind.DateTime => "xs:dateTime",
        XdmValueKind.Duration => "xs:duration",
        XdmValueKind.Binary => "xs:base64Binary",
        XdmValueKind.Node => "node()",
        XdmValueKind.Function => "function(*)",
        XdmValueKind.Map => "map(*)",
        XdmValueKind.Array => "array(*)",
        _ => "item()*",
    };

    /// <summary>
    /// Matches a map or array value against a typed function test <c>function(A) as R</c>.
    /// A map behaves as <c>function(xs:anyAtomicType) as V?</c> (an absent key returns the
    /// empty sequence, so () must also match R); an array behaves as
    /// <c>function(xs:integer) as T</c>. The parameter type is contravariant.
    /// </summary>
    private static bool MapOrArrayMatchesFunctionType(XdmValue value, string[] testParamTypes, string testReturnType, EvaluationContext? context = null)
    {
        if (testParamTypes.Length != 1)
            return false;
        // Contravariant domain: the test's parameter type must accept every key/index
        // the map or array itself accepts.
        string domain = value.IsMap ? "xs:anyAtomicType" : "xs:integer";
        if (!IsSequenceTypeSubtype(testParamTypes[0], domain, context))
            return false;
        if (value.IsMap)
        {
            if (!ValueMatchesType(XdmValue.Undefined, testReturnType))
                return false;
            foreach (var v in value.MapValue.Values)
                if (!ValueMatchesType(v, testReturnType))
                    return false;
            return true;
        }
        foreach (var member in value.ArrayValue.Values)
            if (!ValueMatchesType(member, testReturnType))
                return false;
        return true;
    }

    /// <summary>
    /// Like <see cref="MapOrArrayMatchesFunctionType"/> but used for function coercion:
    /// a map or array can be coerced to a one-argument function type even when the
    /// target return type does not allow an empty sequence, because a missing key
    /// will raise XPTY0004 at call time rather than at the coercion point.
    /// </summary>
    private static bool MapOrArrayCoercibleToFunctionType(XdmValue value, string[] testParamTypes, string testReturnType, EvaluationContext? context = null)
    {
        if (testParamTypes.Length != 1)
            return false;
        string domain = value.IsMap ? "xs:anyAtomicType" : "xs:integer";
        if (!IsSequenceTypeSubtype(testParamTypes[0], domain, context))
            return false;
        if (value.IsMap)
        {
            foreach (var v in value.MapValue.Values)
                if (!ValueMatchesType(v, testReturnType))
                    return false;
            return true;
        }
        foreach (var member in value.ArrayValue.Values)
            if (!ValueMatchesType(member, testReturnType))
                return false;
        return true;
    }

    /// <summary>
    /// Applies kind-level function conversion to the arguments of a dynamically invoked
    /// named function: node atomization, untypedAtomic casting, numeric promotion, and
    /// URI promotion; anything else raises XPTY0004 (higher-order-functions-064).
    /// </summary>
    private static XdmValue[] ConvertDynamicCallArgs(FunctionSignature sig, ReadOnlySpan<XdmValue> args, EvaluationContext? context = null)
    {
        var converted = new XdmValue[args.Length];
        for (int i = 0; i < args.Length; i++)
        {
            if (args[i].IsUndefined && sig.MinimumHostArity is { } minimum && i >= minimum)
            {
                converted[i] = args[i];
                continue;
            }
            // User-declared functions register precise parameter type names: apply the full
            // function conversion rules (atomization, untypedAtomic casting, numeric/URI
            // promotion) — hof-043: xs:untypedAtomic against xs:double.
            if (sig.ParameterTypeNames is not null && i < sig.ParameterTypeNames.Count
                && !string.IsNullOrEmpty(sig.ParameterTypeNames[i]))
            {
                converted[i] = ApplyFunctionConversion(args[i], sig.ParameterTypeNames[i]!, context);
                continue;
            }
            var expected = i < sig.ParameterTypes.Count ? sig.ParameterTypes[i] : XdmValueKind.Sequence;
            // External is an opaque/unconstrained kind (user-declared XQuery functions
            // register with External fillers and convert via type names instead).
            converted[i] = expected is XdmValueKind.Undefined or XdmValueKind.Sequence or XdmValueKind.Node or XdmValueKind.Function
                or XdmValueKind.Map or XdmValueKind.Array or XdmValueKind.External
                ? args[i]
                : ConvertArgToKind(args[i], expected);
        }
        return converted;
    }

    /// <summary>
    /// Applies kind-level function conversion to a single argument: node atomization,
    /// untypedAtomic casting, numeric promotion, and URI promotion; anything else raises
    /// XPTY0004 (higher-order-functions-064). Exposed for fn:partial-apply (REQ-118
    /// 4.0-S5), which coerces bound argument values against the base function's
    /// declared parameter kinds at bind time.
    /// </summary>
    /// <param name="arg">The argument value to convert.</param>
    /// <param name="expected">The declared parameter kind.</param>
    /// <returns>The converted value.</returns>
    /// <exception cref="InvalidOperationException">No conversion rule applies (XPTY0004).</exception>
    public static XdmValue ConvertArgToKind(XdmValue arg, XdmValueKind expected)
    {
        if (arg.Kind == expected || arg.IsUndefined)
            return arg;

        // An empty sequence satisfies any optional parameter (xs:T? / xs:T*) — the
        // kind-level metadata cannot express optionality, so pass it through.
        if (arg.Kind == XdmValueKind.Sequence)
        {
            bool isEmpty = true;
            foreach (var _ in XdmSequence.FromSource(arg.SequenceValue!))
            {
                isEmpty = false;
                break;
            }
            if (isEmpty)
                return arg;
        }

        // Function conversion atomizes nodes to xs:untypedAtomic before casting.
        // A singleton sequence unwraps first (hof-042: an attribute node argument).
        if (arg.IsSequence && arg.SequenceValue is not null)
        {
            var argItems = MaterializeSequence(arg);
            if (argItems.Length == 1)
                arg = argItems[0];
        }
        var atomic = arg.IsNode ? XdmValue.FromString(arg.NodeValue.StringValue, "untypedAtomic") : arg;
        if (atomic.Kind == expected)
            return atomic;

        bool untyped = IsUntypedAtomicValue(atomic);
        switch (expected)
        {
            case XdmValueKind.Double:
                if ((atomic.Kind is XdmValueKind.Integer or XdmValueKind.Decimal or XdmValueKind.Float || untyped)
                    && TryCast(atomic, "xs:double", out var d))
                    return d;
                break;
            case XdmValueKind.Float:
                if ((atomic.Kind is XdmValueKind.Integer or XdmValueKind.Decimal || untyped)
                    && TryCast(atomic, "xs:float", out var f))
                    return f;
                break;
            case XdmValueKind.Decimal:
                if (atomic.Kind == XdmValueKind.Integer)
                    return atomic; // xs:integer is a subtype of xs:decimal
                if (untyped && TryCast(atomic, "xs:decimal", out var dec))
                    return dec;
                break;
            case XdmValueKind.Integer:
                if (untyped && TryCast(atomic, "xs:integer", out var n))
                    return n;
                break;
            case XdmValueKind.String:
                if (untyped)
                    return atomic;
                // URI promotion: xs:anyURI may be promoted to xs:string.
                if (atomic.Kind == XdmValueKind.Uri && TryCast(atomic, "xs:string", out var s))
                    return s;
                break;
            case XdmValueKind.Boolean:
                if (untyped && TryCast(atomic, "xs:boolean", out var b))
                    return b;
                break;
            case XdmValueKind.Uri:
                if (untyped && TryCast(atomic, "xs:anyURI", out var u))
                    return u;
                break;
        }

        throw new InvalidOperationException($"XPTY0004: Cannot convert argument of kind {arg.Kind} to {expected}");
    }

    private static bool IsUntypedAtomicValue(XdmValue value)
        => value.Kind == XdmValueKind.String
           && string.Equals(value.SchemaTypeName, "untypedAtomic", StringComparison.OrdinalIgnoreCase);

    private readonly record struct ConversionTargetInfo(string Type, bool AllowsEmpty, bool AllowsMultiple, bool IsFunctionTest);

    private static readonly System.Collections.Concurrent.ConcurrentDictionary<string, ConversionTargetInfo> s_conversionTargets = new();

    /// <summary>
    /// Parses a sequence-type string into its normalized item-type name, occurrence flags,
    /// and function-test marker. Purely syntactic (context-independent); results are cached
    /// in <see cref="s_conversionTargets"/> because call sites repeat the same type names
    /// on every invocation.
    /// </summary>
    private static ConversionTargetInfo ParseConversionTarget(string targetType)
    {
        var type = NormalizeEQNameTypeName(targetType.Trim());
        while (type.Length > 1 && type[0] == '(' && FindMatchingParen(type, 0) == type.Length - 1)
            type = type[1..^1].Trim();

        // Normalize 'function (' / 'map (' / 'array (' to the compact form so function
        // tests parse regardless of source whitespace (hof-049).
        foreach (var family in new[] { "function", "map", "array" })
        {
            if (type.StartsWith(family, StringComparison.OrdinalIgnoreCase))
            {
                int afterKeyword = family.Length;
                while (afterKeyword < type.Length && char.IsWhiteSpace(type[afterKeyword]))
                    afterKeyword++;
                if (afterKeyword < type.Length && type[afterKeyword] == '(' && afterKeyword != family.Length)
                    type = string.Concat(type.AsSpan(0, family.Length), type.AsSpan(afterKeyword));
                break;
            }
        }

        // Function tests: a trailing occurrence indicator belongs to the function item
        // only when the test has no 'as' return clause; otherwise it is part of the
        // return type (function(xs:string) as xs:string*). Handle occurrence before the
        // generic stripping so the return type is not mangled (hof-028).
        bool isFunctionTest = type.StartsWith("function(", StringComparison.OrdinalIgnoreCase);
        bool allowsMultiple;
        bool allowsEmpty;
        if (isFunctionTest)
        {
            allowsMultiple = false;
            allowsEmpty = false;
            if (!TryParseFunctionType(type, out _, out _) && type.Length > 1 && type[^1] is '?' or '*' or '+')
            {
                allowsMultiple = type[^1] is '*' or '+';
                allowsEmpty = type[^1] is '?' or '*';
                type = type[..^1].TrimEnd();
            }
        }
        else
        {
            allowsMultiple = type.EndsWith('*') || type.EndsWith('+');
            allowsEmpty = type.EndsWith('?') || type.EndsWith('*');
            if (type.EndsWith('?') || type.EndsWith('*') || type.EndsWith('+'))
                type = type[..^1].Trim();
            while (type.Length > 1 && type[0] == '(' && FindMatchingParen(type, 0) == type.Length - 1)
                type = type[1..^1].Trim();
            // An occurrence-wrapped parenthesized function test: (function(...) as ...)?
            isFunctionTest = type.StartsWith("function(", StringComparison.OrdinalIgnoreCase);
        }

        return new ConversionTargetInfo(type, allowsEmpty, allowsMultiple, isFunctionTest);
    }

    /// <summary>
    /// Applies the XPath 3.1 function conversion rules to convert a value to a target
    /// sequence type: subtype substitution, node atomization, untypedAtomic casting,
    /// numeric promotion, and URI promotion. Raises XPTY0004 when no rule applies.
    /// </summary>
    /// <param name="value">The value to convert.</param>
    /// <param name="targetType">The target sequence type string.</param>
    /// <param name="context">An optional evaluation context used for namespace resolution and function-item coercion.</param>
    /// <returns>The converted value.</returns>
    /// <exception cref="InvalidOperationException">No function conversion rule applies (XPTY0004).</exception>
    public static XdmValue ApplyFunctionConversion(XdmValue value, string targetType, EvaluationContext? context = null)
    {
        var nominalText = targetType.Trim();
        var nominalSuffix = nominalText.Length > 0 && nominalText[^1] is '?' or '*' or '+' ? nominalText[^1] : '\0';
        var nominalName = nominalSuffix == '\0' ? nominalText : nominalText[..^1].TrimEnd();
        if (context is not null && context.TryResolveNamedRecordType(nominalName, context.DefaultElementNamespace, out var nominalType))
        {
            var nominalItems = new List<XdmValue>();
            if (value.IsSequence)
            {
                foreach (var item in XdmSequence.FromSource(value.SequenceValue!)) nominalItems.Add(item);
            }
            else if (!value.IsUndefined) nominalItems.Add(value);
            if ((nominalItems.Count == 0 && nominalSuffix is not ('?' or '*')) || (nominalItems.Count > 1 && nominalSuffix is not ('*' or '+')))
                throw new InvalidOperationException($"XPTY0004: Cardinality does not match {targetType}.");
            var nominalConverted = new List<XdmValue>(nominalItems.Count);
            foreach (var item in nominalItems)
            {
                if (!item.IsMap) throw new InvalidOperationException($"XPTY0004: A map is required for {targetType}.");
                if (ReferenceEquals(item.MapValue.RecordType, nominalType)) nominalConverted.Add(item);
                else if (context.NamedRecordCoercion is { } coerce) nominalConverted.Add(XdmValue.FromMap(coerce(nominalType!, item.MapValue, false)));
                else throw new InvalidOperationException($"XPTY0004: No host coercion is registered for {targetType}.");
            }
            return nominalConverted.Count == 0 ? XdmValue.Undefined : nominalConverted.Count == 1 ? nominalConverted[0]
                : XdmValue.FromSequence(MaterializedSequence.FromList(nominalConverted));
        }
        // XPath 4.0 §3.4.2 rule 10 (record coercion): a record type text is structural
        // and is not a legal QName conversion target, so it is handled before the
        // syntactic parse of the target below. The occurrence indicator applies to the
        // record item itself: each item of the input is coerced individually.
        var recordTargetText = targetType.Trim();
        bool recordRequiresSingle = IsRecordTypeText(recordTargetText);
        if (recordRequiresSingle) recordTargetText += "?";
        bool recordAllowsEmpty = false;
        bool recordAllowsMultiple = false;
        if (recordTargetText.Length > 1 && recordTargetText[^1] is '?' or '*' or '+')
        {
            recordAllowsEmpty = !recordRequiresSingle && recordTargetText[^1] is '?' or '*';
            recordAllowsMultiple = recordTargetText[^1] is '*' or '+';
            var recordBaseText = recordTargetText[..^1].TrimEnd();
            if (IsRecordTypeText(recordBaseText))
            {
                var recordTarget = TryGetRecordType(recordBaseText)!;
                if (value.IsUndefined)
                {
                    if (recordAllowsEmpty)
                        return XdmValue.Undefined;
                    throw new InvalidOperationException($"XPTY0004: Empty sequence not allowed for type {targetType}");
                }
                var recordItems = new List<XdmValue>();
                if (value.IsSequence && value.SequenceValue is not null)
                {
                    foreach (var item in XdmSequence.FromSource(value.SequenceValue))
                        recordItems.Add(item);
                }
                else
                {
                    recordItems.Add(value);
                }
                if (recordItems.Count == 0 && !recordAllowsEmpty)
                    throw new InvalidOperationException($"XPTY0004: Empty sequence not allowed for type {targetType}");
                if (recordItems.Count > 1 && !recordAllowsMultiple)
                    throw new InvalidOperationException($"XPTY0004: Sequence of more than one item not allowed for type {targetType}");
                var coercedRecords = new List<XdmValue>(recordItems.Count);
                foreach (var item in recordItems)
                {
                    if (!item.IsMap)
                        throw new InvalidOperationException($"XPTY0004: Cannot convert {item.Kind} to {targetType}: record coercion requires a map.");
                    coercedRecords.Add(XdmValue.FromMap(CoerceMapToRecord(item.MapValue, recordTarget, targetType, context)));
                }
                return coercedRecords.Count == 1 ? coercedRecords[0]
                    : XdmValue.FromSequence(MaterializedSequence.FromList(coercedRecords));
            }
        }

        // The syntactic parse of the target sequence type depends only on the type string,
        // so it is cached per distinct name (call sites repeat the same handful of type
        // names per call); schema-dependent validation and the value-dependent conversion
        // below still run per call.
        var (type, allowsEmpty, allowsMultiple, isFunctionTest) =
            s_conversionTargets.GetOrAdd(targetType, static t => ParseConversionTarget(t));

        // XPath 4.0 array coercion preserves the array item and recursively converts
        // each member sequence. The 3.1 conversion path remains version-gated.
        if (context?.IsXPath40 == true && type.StartsWith("array(", StringComparison.Ordinal) && type.EndsWith(')'))
        {
            if (value.IsJNode) return ApplyFunctionConversion(value.JNodeValue.Value, targetType, context);
            if (value.IsUndefined)
            {
                if (allowsEmpty) return value;
                throw new InvalidOperationException($"XPTY0004: Empty sequence not allowed for type {targetType}");
            }
            var arrayItems = new List<XdmValue>();
            if (value.IsSequence && value.SequenceValue is not null)
            {
                foreach (var item in XdmSequence.FromSource(value.SequenceValue)) arrayItems.Add(item);
            }
            else arrayItems.Add(value);
            if (arrayItems.Count == 0 && !allowsEmpty || arrayItems.Count > 1 && !allowsMultiple)
                throw new InvalidOperationException($"XPTY0004: Cardinality does not match {targetType}");
            var memberType = type[6..^1].Trim();
            var arrays = new List<XdmValue>(arrayItems.Count);
            foreach (var item in arrayItems)
            {
                if (!item.IsArray) throw new InvalidOperationException($"XPTY0004: Cannot convert {item.Kind} to {targetType}");
                var array = item.ArrayValue;
                if (memberType == "*") { arrays.Add(item); continue; }
                if (memberType.Length == 0)
                {
                    if (array.Count != 0) throw new InvalidOperationException($"XPTY0004: Nonempty array does not match {targetType}");
                    arrays.Add(item);
                    continue;
                }
                var members = new XdmValue[array.Count];
                for (int i = 0; i < members.Length; i++)
                    members[i] = ApplyFunctionConversion(array.Get(i + 1), memberType, context);
                arrays.Add(XdmValue.FromArray(new XdmArray(members)));
            }
            return arrays.Count == 1 ? arrays[0] : XdmValue.FromSequence(MaterializedSequence.FromList(arrays));
        }

        // XPath 4.0 §3.4.2 rule 9: coerce both keys and value sequences,
        // rejecting key collisions after conversion and retaining entry order.
        if (context?.IsXPath40 == true && type.StartsWith("map(", StringComparison.Ordinal) && type.EndsWith(')')
            && type is not ("map(*)" or "map()"))
        {
            if (value.IsJNode) return ApplyFunctionConversion(value.JNodeValue.Value, targetType, context);
            if (ValueMatchesType(value, targetType, context)) return value;
            if (value.IsUndefined)
            {
                if (allowsEmpty) return value;
                throw new InvalidOperationException($"XPTY0004: Empty sequence not allowed for type {targetType}");
            }
            var mapItems = new List<XdmValue>();
            if (value.IsSequence && value.SequenceValue is not null)
            {
                foreach (var item in XdmSequence.FromSource(value.SequenceValue)) mapItems.Add(item);
            }
            else mapItems.Add(value);
            if (mapItems.Count == 0 && !allowsEmpty || mapItems.Count > 1 && !allowsMultiple)
                throw new InvalidOperationException($"XPTY0004: Cardinality does not match {targetType}");
            var inner = type[4..^1].Trim();
            var parts = inner is "" or "*" ? Array.Empty<string>() : SplitTopLevel(inner, ',');
            if (parts.Length is not (0 or 2)) throw new InvalidOperationException("XPST0003: A map type requires a key and value type.");
            if (parts.Length == 2 && (string.IsNullOrWhiteSpace(parts[0]) || parts[0].TrimEnd()[^1] is '?' or '*' or '+'))
                throw new InvalidOperationException("XPST0003: A map key type cannot have an occurrence indicator.");
            var maps = new List<XdmValue>(mapItems.Count);
            foreach (var item in mapItems)
            {
                if (!item.IsMap) throw new InvalidOperationException($"XPTY0004: Cannot convert {item.Kind} to {targetType}");
                if (parts.Length == 0) { maps.Add(item); continue; }
                var map = new XdmMap();
                foreach (var entry in item.MapValue.Entries)
                {
                    var key = ApplyFunctionConversion(entry.Key, parts[0].Trim(), context);
                    if (map.ContainsKey(key)) throw new InvalidOperationException("XPTY0004: Map key coercion produced duplicate keys.");
                    map = map.WithAdded(key, ApplyFunctionConversion(entry.Value, parts[1].Trim(), context));
                }
                maps.Add(XdmValue.FromMap(map));
            }
            return maps.Count == 1 ? maps[0] : XdmValue.FromSequence(MaterializedSequence.FromList(maps));
        }

        // XPath 4.0 §17.7: a JNode coerces to a map/array/function-typed parameter by
        // extracting its jvalue, then the standard conversion rules apply to that value.
        if (value.IsJNode && IsMapArrayFunctionConversionTarget(type))
            return ApplyFunctionConversion(value.JNodeValue.Value, targetType, context);

        // A declared type that is not a legal sequence-type item type is XPST0051
        // (XPath 3.1 §2.5.5.2), reported before any conversion attempt: the pseudo-name
        // 'none', built-in list types (xs:NMTOKENS/IDREFS/ENTITIES), and schema types
        // whose variety is list or a union containing/restricted-from a list
        // (FunctionCall-027/032/033/034/039, K-FunctionProlog-57/58).
        if (!isFunctionTest)
            ValidateFunctionConversionTarget(type, context);

        // XPath 3.1 function conversion: xs:untypedAtomic cannot be implicitly cast to a
        // namespace-sensitive atomic type such as xs:QName or xs:NOTATION (XPTY0117).
        if (!value.IsSequence && IsUntypedAtomicValue(value) && IsNamespaceSensitiveTargetType(type, context))
            throw new InvalidOperationException($"XPTY0117: Cannot cast xs:untypedAtomic to namespace-sensitive type {targetType}");

        // XPath 4.0 §3.4.2 rule 02: a choice item type coerces per alternative in
        // declaration order (not "any match wins"), so the whole-value and per-item
        // pass-through shortcuts below must not short-circuit the in-order scan.
        bool isChoiceConversionTarget = TryGetChoiceAlternatives(type, out _);

        // XPath 3.1 function conversion: node values must be atomized when the target
        // type is not a node kind test, even if the node's typed value could be cast to
        // the target atomic type (qischema040). Only short-circuit when the value already
        // matches and nodes are accepted as-is (node kind tests or item()).
        bool valueContainsNode = value.IsNode;
        if (!valueContainsNode && value.IsSequence && value.SequenceValue != null)
        {
            foreach (var item in XdmSequence.FromSource(value.SequenceValue))
            {
                if (item.IsNode)
                {
                    valueContainsNode = true;
                    break;
                }
            }
        }
        if ((!valueContainsNode || IsNodeKindTestType(type)) && !isChoiceConversionTarget && ValueMatchesType(value, targetType, context))
            return value;

        var items = new List<XdmValue>();
        if (!value.IsUndefined)
        {
            if (value.IsSequence && value.SequenceValue != null)
            {
                foreach (var item in XdmSequence.FromSource(value.SequenceValue))
                    AddConversionItems(item, items);
            }
            else
            {
                AddConversionItems(value, items);
            }
        }

        // XPath 1.0 backwards compatibility (XSLT 3.0 §3.9.1): an argument to a singleton
        // parameter is truncated to its first item (xpath-compat-0301, string-003/031);
        // a numeric parameter additionally converts as by fn:number.
        bool bcTruncate = context?.BackwardsCompatible == true && !allowsMultiple;
        bool bcNumeric = bcTruncate && IsNumericTypeName(type);

        if (items.Count == 0)
        {
            if (allowsEmpty)
                return XdmValue.Undefined;
            throw new InvalidOperationException($"XPTY0004: Empty sequence not allowed for type {targetType}");
        }
        if (items.Count > 1 && !allowsMultiple)
        {
            if (bcTruncate)
            {
                items.RemoveRange(1, items.Count - 1);
            }
            else
            {
                throw new InvalidOperationException($"XPTY0004: Sequence of more than one item not allowed for type {targetType}");
            }
        }

        var converted = new List<XdmValue>(items.Count);
        foreach (var item in items)
        {
            // An item that already matches the target type passes through unchanged —
            // checked before atomization so node items survive node-typed parameters
            // (e.g. a node truncated to a node()? parameter in backwards-compatible mode).
            // For atomic/simple targets, nodes must be atomized even if their typed value
            // matches the target type; node kind tests and item() accept nodes as-is
            // (qischema040).
            bool nodeNeedsAtomization = item.IsNode && !IsNodeKindTestType(type);
            // For choice targets, atomic items take the in-order alternative scan in
            // ConvertAtomizedItem; node items may still pass through on a matching
            // node-kind alternative (unchanged in both paths).
            if (!nodeNeedsAtomization && (!isChoiceConversionTarget || item.IsNode) && ValueMatchesType(item, type, context))
            {
                converted.Add(item);
                continue;
            }
            // XPath 3.1 function conversion atomizes argument items. This also covers
            // comment/processing-instruction/namespace nodes, which atomize to xs:string
            // and are therefore not promoted to numeric types (K2-FunctionProlog-18/20).
            // These numeric targets require atomic input, so function items and maps
            // must fail atomization rather than reach the generic type mismatch.
            if (type is "xs:numeric" or "xs:integer" && (item.IsFunction || item.IsMap))
                throw new InvalidOperationException("FOTY0013: Cannot atomize a function item or map.");
            var atomic = Atomize(item);
            // Atomizing a schema-validated node whose type is a list type yields a
            // multi-item sequence (e.g. a 3-item xs:decimal sequence from a list-typed
            // element); a plural target such as xs:decimal* accepts each member
            // individually (validation-0301). A singular target keeps its cardinality
            // error when atomization produced more than one member.
            if (atomic.IsSequence && atomic.SequenceValue is not null)
            {
                int added = 0;
                foreach (var member in XdmSequence.FromSource(atomic.SequenceValue))
                {
                    if (member.IsUndefined)
                        continue;
                    ConvertAtomizedItem(member, type, targetType, isFunctionTest, bcNumeric, context, converted);
                    added++;
                }
                if (added > 1 && !allowsMultiple)
                    throw new InvalidOperationException($"XPTY0004: Sequence of more than one item not allowed for type {targetType}");
                continue;
            }
            ConvertAtomizedItem(atomic, type, targetType, isFunctionTest, bcNumeric, context, converted);
        }

        if (converted.Count == 0)
            return XdmValue.Undefined;
        if (converted.Count == 1)
            return converted[0];
        return XdmValue.FromSequence(MaterializedSequence.FromList(converted));
    }

    /// <summary>
    /// Converts a single atomized item against the target item type of a function
    /// conversion: exact type match, function-item coercion, union member casting,
    /// xs:untypedAtomic casting, numeric/URI promotion, and derived schema type
    /// casting. Raises XPTY0004/XPTY0117/FORG0001 when no rule applies.
    /// </summary>
    /// <param name="atomic">The atomized item to convert.</param>
    /// <param name="type">The target item type without occurrence indicator.</param>
    /// <param name="targetType">The original target sequence type (used in error messages).</param>
    /// <param name="isFunctionTest">Whether the target is a function test.</param>
    /// <param name="bcNumeric">Whether backwards-compatible numeric conversion applies.</param>
    /// <param name="context">The evaluation context used for namespace and schema resolution.</param>
    /// <param name="converted">The buffer receiving the converted value.</param>
    private static void ConvertAtomizedItem(
        XdmValue atomic, string type, string targetType, bool isFunctionTest, bool bcNumeric,
        EvaluationContext? context, List<XdmValue> converted)
    {
        // XPath 4.0 §3.4.2 rule 02: a choice item type is handled by the in-order
        // alternative scan below, not by the any-match fast path.
        if (!TryGetChoiceAlternatives(type, out var choiceAlternatives) && ValueMatchesType(atomic, type, context))
        {
            converted.Add(atomic);
        }
        else if (choiceAlternatives is { Length: > 0 })
        {
            // Each alternative is tried in declaration order: a matching alternative
            // passes the value through unchanged, otherwise the first successful cast
            // to an atomic alternative wins (the spec's fn:char example: an integer
            // argument to (xs:string|xs:positiveInteger) becomes the string).
            foreach (var alternative in choiceAlternatives)
            {
                bool matched;
                try
                {
                    matched = ValueMatchesType(atomic, alternative, context);
                }
                catch (InvalidOperationException)
                {
                    matched = false;
                }
                if (matched)
                {
                    converted.Add(atomic);
                    return;
                }
                if (IsNonAtomicCastAlternative(alternative))
                    continue;
                try
                {
                    if (TryCast(atomic, alternative, context, out var coerced, out _))
                    {
                        converted.Add(coerced);
                        return;
                    }
                }
                catch (InvalidOperationException) { }
                catch (OverflowException) { }
            }
            throw new InvalidOperationException($"XPTY0004: Cannot convert value to type {targetType}");
        }
        else if (isFunctionTest && atomic.IsFunction && FunctionItemCoercibleTo(atomic, type))
        {
            // XPath 3.1 function conversion: wrap the item in a CoercedFunctionItem so
            // invocation converts the arguments and the result to the declared types
            // (the XSLT engine applies the same pattern — hof-028).
            if (!type.StartsWith("function(*)", StringComparison.OrdinalIgnoreCase)
                && TryParseFunctionType(type, out var coercionParamTypes, out var coercionReturnType)
                && !(coercionParamTypes.Length == 1 && coercionParamTypes[0] == "*")
                && atomic.FunctionValue is FunctionItem functionItem)
            {
                converted.Add(XdmValue.FromFunction(new CoercedFunctionItem(functionItem, coercionParamTypes, coercionReturnType)));
            }
            else
            {
                converted.Add(atomic);
            }
        }
        else if (isFunctionTest && (atomic.IsMap || atomic.IsArray)
            && !type.StartsWith("function(*)", StringComparison.OrdinalIgnoreCase)
            && TryParseFunctionType(type, out var mapCoercionParamTypes, out var mapCoercionReturnType)
            && !(mapCoercionParamTypes.Length == 1 && mapCoercionParamTypes[0] == "*")
            && MapOrArrayCoercibleToFunctionType(atomic, mapCoercionParamTypes, mapCoercionReturnType, context))
        {
            var capturedValue = atomic;
            var inner = new DelegateFunctionItem(1, (ctx, args) => InvokeFunctionItem(capturedValue, ctx, args));
            converted.Add(XdmValue.FromFunction(new CoercedFunctionItem(inner, mapCoercionParamTypes, mapCoercionReturnType)));
        }
        else if (IsUserDefinedSchemaType(type, context, out var targetSchemaType)
            && GetSchemaTypeVariety(targetSchemaType) == SchemaTypeVariety.Union)
        {
            // Function conversion to a union type: xs:untypedAtomic is cast to the
            // first matching member unless the union is namespace-sensitive (XPTY0117);
            // other values must already be instances of a member type.
            if (IsUntypedAtomicValue(atomic))
            {
                if (IsNamespaceSensitiveSchemaType(targetSchemaType, context))
                    throw new InvalidOperationException($"XPTY0117: Cannot cast xs:untypedAtomic to namespace-sensitive type {targetType}");
                if (TryCastToSchemaType(atomic, targetSchemaType, context, out var unionCasted))
                {
                    converted.Add(unionCasted);
                    return;
                }
            }
            throw new InvalidOperationException($"XPTY0004: Cannot convert value to type {targetType}");
        }
        else if (IsUntypedAtomicValue(atomic) && IsNamespaceSensitiveTargetType(type, context))
        {
            // XPath 3.1 function conversion: xs:untypedAtomic cannot be implicitly cast to a
            // namespace-sensitive type such as xs:QName or xs:NOTATION (XPTY0117).
            throw new InvalidOperationException($"XPTY0117: Cannot cast xs:untypedAtomic to namespace-sensitive type {targetType}");
        }
        else if (IsUntypedAtomicValue(atomic) && !IsKnownSequenceTypeName(type) && TryCast(atomic, type, context, out var casted))
        {
            converted.Add(casted);
        }
        else if (IsUntypedAtomicValue(atomic) && !IsKnownSequenceTypeName(type)
                 && type.StartsWith("xs:", StringComparison.OrdinalIgnoreCase)
                 && IsKnownAtomicTypeName(type[3..].ToLowerInvariant()))
        {
            // Function conversion casts xs:untypedAtomic to the required atomic type;
            // when the target is a built-in type, a failed cast is the cast's own
            // lexical error (FORG0001), not the generic XPTY0004 (K2-FunctionProlog-24).
            throw new InvalidOperationException($"FORG0001: Cannot cast xs:untypedAtomic '{atomic}' to {targetType}");
        }
        else if (TryPromoteNumericOrUri(atomic, type, out var promoted))
        {
            converted.Add(promoted);
        }
        else if (context?.IsXPath40 == true && TryCoercePrimitiveNumeric(atomic, type, context, out var numeric))
        {
            converted.Add(numeric);
        }
        else if (context?.IsXPath40 == true && TryRelabelToDerivedNumeric(atomic, type, out var relabeled))
        {
            // XPath 4.0 §3.4.2 relabeling (PR 254, Issue 117 — letexprwith-30): when the
            // target R is derived from a primitive type P, a value J that is an instance
            // of P (but not of R) is relabeled as an instance of R when its datum lies
            // within R's value space — the annotation changes, the datum does not. So 42
            // relabels to xs:short, but 2.5 does NOT (its datum is not an integer) and
            // -5 does NOT relabel to xs:unsignedShort. Gated on IsXPath40 so 3.1
            // conversion keeps rejecting downcasts.
            converted.Add(relabeled);
        }
        else if (IsUserDefinedSchemaType(type, context, out _) && TryCast(atomic, type, context, out var schemaCasted))
        {
            // Derived schema simple types (e.g. hat:hatsize) accept values that can be
            // cast to them under XSD facet rules (qischema040).
            converted.Add(schemaCasted);
        }
        else if (bcNumeric)
        {
            // backwards-022: round(concat(...)) under version="1.0" — xs:string and
            // xs:boolean arguments convert to xs:double via fn:number semantics.
            converted.Add(XdmValue.FromDouble(ToDoubleOrNaN(atomic)));
        }
        else
        {
            throw new InvalidOperationException($"XPTY0004: Cannot convert value to type {targetType}");
        }
    }

    /// <summary>
    /// Collects the items of a function-conversion input, expanding arrays into their
    /// (recursively atomized) members: the function conversion rules atomize the
    /// supplied value, and atomizing an array yields the atomization of its members
    /// (FunctionCall-022: an array argument to an xs:integer* parameter contributes
    /// its members).
    /// </summary>
    private static void AddConversionItems(XdmValue item, List<XdmValue> items)
    {
        if (item.IsArray && item.ArrayValue is not null)
        {
            foreach (var member in item.ArrayValue.Values)
            {
                if (member.IsUndefined)
                    continue;
                if (member.IsSequence && member.SequenceValue is not null)
                {
                    foreach (var inner in XdmSequence.FromSource(member.SequenceValue))
                        AddConversionItems(inner, items);
                }
                else
                {
                    AddConversionItems(member, items);
                }
            }
            return;
        }
        items.Add(item);
    }

    /// <summary>Applies only the primitive numeric pairs in XPath 4.0 section 3.4.2's implicit-casting table.</summary>
    /// <param name="value">The atomic source value.</param>
    /// <param name="type">The required item type without a cardinality indicator.</param>
    /// <param name="context">The casting context.</param>
    /// <param name="result">The converted value, when the pair is permitted.</param>
    /// <returns>Whether this is a permitted primitive numeric pair.</returns>
    internal static bool TryCoercePrimitiveNumeric(XdmValue value, string type, EvaluationContext? context, out XdmValue result)
    {
        result = value;
        var normalized = NormalizeEQNameTypeName(type.Trim());
        var target = normalized switch
        {
            "xs:decimal" or "xsd:decimal" or "decimal" => "xs:decimal",
            "xs:float" or "xsd:float" or "float" => "xs:float",
            "xs:double" or "xsd:double" or "double" => "xs:double",
            _ => null
        };
        if (target is null || value.Kind is not (XdmValueKind.Integer or XdmValueKind.Decimal or XdmValueKind.Float or XdmValueKind.Double))
            return false;

        // Derived targets are deliberately excluded: casting and relabeling are never combined.
        // Cast preserves FOCA0002 for NaN/infinity to decimal and existing range limitations.
        result = Cast(value, target, context);
        return true;
    }

    private static bool TryPromoteNumericOrUri(XdmValue value, string type, out XdmValue result)
    {
        result = XdmValue.Undefined;
        var t = type.Trim().ToLowerInvariant();
        if (t.StartsWith("xs:"))
            t = t[3..];

        // xs:anyURI values are sometimes stored as String kind with the schema type name
        // annotation rather than as Uri kind, so consult both sources.
        bool isUri = value.Kind == XdmValueKind.Uri
            || (value.Kind == XdmValueKind.String
                && value.SchemaTypeName?.Equals("anyURI", StringComparison.OrdinalIgnoreCase) == true);

        bool promotable = t switch
        {
            "double" => value.Kind is XdmValueKind.Integer or XdmValueKind.Decimal or XdmValueKind.Float,
            "float" => value.Kind is XdmValueKind.Integer or XdmValueKind.Decimal,
            "string" => isUri,
            _ => false
        };
        return promotable && TryCast(value, type, out result);
    }

    /// <summary>
    /// True when the (occurrence-stripped) sequence-type name is a numeric type:
    /// xs:numeric or one of the numeric primitives. Used for XPath 1.0 backwards-
    /// compatible argument conversion (XSLT 3.0 §3.9.1).
    /// </summary>
    private static bool IsNumericTypeName(string type)
    {
        var t = type.StartsWith("xs:", StringComparison.OrdinalIgnoreCase) ? type[3..] : type;
        return t.Equals("numeric", StringComparison.OrdinalIgnoreCase)
            || t.Equals("double", StringComparison.OrdinalIgnoreCase)
            || t.Equals("float", StringComparison.OrdinalIgnoreCase)
            || t.Equals("decimal", StringComparison.OrdinalIgnoreCase)
            || t.Equals("integer", StringComparison.OrdinalIgnoreCase);
    }

    // The built-in types derived from xs:decimal (all integer types); the relabeling
    // target set of XPath 4.0 §3.4.2 (PR 254). There are no built-in types derived
    // from xs:float or xs:double, so numeric relabeling covers this family only.
    private static bool IsDerivedIntegerTypeName(string normalized)
        => normalized is "int" or "long" or "short" or "byte"
            or "unsignedshort" or "unsignedint" or "unsignedlong" or "unsignedbyte"
            or "positiveinteger" or "negativeinteger" or "nonpositiveinteger" or "nonnegativeinteger";

    /// <summary>
    /// Attempts XPath 4.0 §3.4.2 relabeling of a numeric item to a built-in integer-derived
    /// type: succeeds when the datum lies within the target's value space (an integral value
    /// inside the type's range). The datum is preserved — only the type annotation changes
    /// (42 becomes an xs:short; 2.5 stays a decimal and fails; −5 cannot become an
    /// xs:unsignedShort). Relabeling to xs:integer itself is covered by the earlier
    /// instance-of/member-type check, so this helper handles only the properly derived types.
    /// </summary>
    private static bool TryRelabelToDerivedNumeric(XdmValue value, string type, out XdmValue result)
    {
        result = value;
        var t = type.StartsWith("xs:", StringComparison.OrdinalIgnoreCase) ? type[3..] : type;
        t = t.ToLowerInvariant();
        if (!IsDerivedIntegerTypeName(t))
            return false;
        switch (value.Kind)
        {
            case XdmValueKind.Integer:
                if (!IsIntegerInRange(value.IntegerValue, t))
                    return false;
                result = XdmValue.FromInteger(value.IntegerValue, t);
                return true;
            case XdmValueKind.Decimal:
            {
                decimal d = value.DecimalValue;
                // The datum must be within the value space of the target: an integral
                // number inside the type's range (2.5 is not an xs:integer datum).
                if (d != decimal.Truncate(d))
                    return false;
                if (d >= long.MinValue && d <= long.MaxValue)
                {
                    long l = (long)d;
                    if (!IsIntegerInRange(l, t))
                        return false;
                    result = XdmValue.FromInteger(l, t);
                    return true;
                }
                // Integral decimals beyond long range: only xs:unsignedLong's value
                // space (and the xs:integer family beyond long, which this helper
                // excludes) could hold them.
                if (t == "unsignedlong" && d >= 0m && d <= 18446744073709551615m)
                {
                    result = XdmValue.FromDecimal(d, t);
                    return true;
                }
                return false;
            }
            default:
                return false;
        }
    }

    /// <summary>
    /// Checks whether <paramref name="actualType"/> is a subtype of <paramref name="testType"/>
    /// according to XPath 3.1 sequence type subtyping rules.
    /// </summary>
    private static bool IsSequenceTypeSubtype(string actualType, string testType, EvaluationContext? context = null)
    {
        // Structured types contain case-sensitive field names and type QNames.
        string actual = actualType.Trim();
        string test = testType.Trim();

        if (actual.StartsWith("xs:")) actual = actual[3..];
        if (test.StartsWith("xs:")) test = test[3..];

        // Function-family types (function/map/array) need structured comparison:
        // an occurrence indicator at the end of such a type only counts as an outer
        // occurrence when it directly follows the closing parenthesis (otherwise it
        // belongs to the return type or the map/array member type).
        bool actualFamily = IsFunctionFamilyType(actual) || actual.StartsWith("record(", StringComparison.Ordinal);
        bool testFamily = IsFunctionFamilyType(test) || test.StartsWith("record(", StringComparison.Ordinal);

        char actualOcc = '\0';
        char testOcc = '\0';
        if (actualFamily)
            (actual, actualOcc) = StripOuterOccurrence(actual);
        else if (actual.Length > 0 && "?+*".Contains(actual[^1]))
        {
            actualOcc = actual[^1];
            actual = actual[..^1].TrimEnd();
        }
        if (testFamily)
            (test, testOcc) = StripOuterOccurrence(test);
        else if (test.Length > 0 && "?+*".Contains(test[^1]))
        {
            testOcc = test[^1];
            test = test[..^1].TrimEnd();
        }

        // Host aliases may parenthesize a function type to preserve precedence.
        actual = UnwrapSubtypeType(actual);
        test = UnwrapSubtypeType(test);
        actualFamily = IsFunctionFamilyType(actual) || actual.StartsWith("record(", StringComparison.Ordinal);
        testFamily = IsFunctionFamilyType(test) || test.StartsWith("record(", StringComparison.Ordinal);

        // Every sequence matching actual must also match test
        bool occOk = (actualOcc, testOcc) switch
        {
            ('\0', '\0') => true,
            ('\0', '?') => true,
            ('\0', '+') => true,
            ('\0', '*') => true,
            ('?', '?') => true,
            ('?', '*') => true,
            ('+', '+') => true,
            ('+', '*') => true,
            ('*', '*') => true,
            _ => false,
        };

        if (!occOk) return false;
        if (actual == test) return true;
        // empty-sequence() is a subtype of every sequence type (xs-015/016).
        if (actual is "empty-sequence" or "empty-sequence()") return true;

        var actualRecord = TryGetRecordType(actual);
        var testRecord = TryGetRecordType(test);
        if (actualRecord is not null || testRecord is not null)
            return actualRecord is not null && (test == "item()" ||
                (testRecord is not null ? IsStructuralRecordSubtype(actualRecord, testRecord, context) :
                    IsRecordMapSubtype(actualRecord, test, context)));

        if (actualFamily || testFamily)
            return IsFunctionFamilySubtype(actual, test, context);

        if (context is not null && actual.StartsWith("schema-element(", StringComparison.Ordinal) &&
            test.StartsWith("schema-element(", StringComparison.Ordinal) && actual.EndsWith(')') && test.EndsWith(')'))
            return IsSchemaElementSubtype(actual, test, context);

        // User-defined schema simple types (atomic restrictions, unions, and lists) can
        // be related even when their lexical forms differ (e.g. Q{ns}local vs p:local).
        if (context is not null && IsSchemaAwareSequenceSubtype(context, actualType, testType))
            return true;

        // element(*, T1) / attribute(*, T1) is a subtype of element(*, T2) / attribute(*, T2)
        // when T1 derives from T2 in the schema type hierarchy (FunctionCall-051).
        if (context is not null && IsElementOrAttributeSchemaSubtype(actualType, testType, context))
            return true;

        return IsBaseTypeSubtype(actual.ToLowerInvariant(), test.ToLowerInvariant());
    }

    /// <summary>Compares structural record field sets and covariant field sequence types.</summary>
    private static bool IsStructuralRecordSubtype(XdmRecordType actual, XdmRecordType test, EvaluationContext? context)
    {
        if (test.IsAny) return true;
        if (actual.IsAny || actual.Fields.Count != test.Fields.Count) return false;
        foreach (var field in actual.Fields)
        {
            if (!test.TryGetField(field.Name, out var target) ||
                !IsSequenceTypeSubtype(field.SequenceTypeText, target!.SequenceTypeText, context))
                return false;
        }
        return true;
    }

    /// <summary>Removes grouping parentheses around a complete subtype operand.</summary>
    private static string UnwrapSubtypeType(string text)
    {
        while (text.StartsWith('(') && FindMatchingParen(text, 0) == text.Length - 1)
            text = text[1..^1].Trim();
        return text;
    }

    /// <summary>Checks record-to-map covariance and the generic function supertype.</summary>
    private static bool IsRecordMapSubtype(XdmRecordType actual, string test, EvaluationContext? context)
    {
        if (test is "map" or "map()" or "map(*)" or "function" or "function()" or "function(*)") return true;
        if (!TryGetMapTypeParts(test, out var keyType, out var valueType) ||
            !IsSequenceTypeSubtype("xs:string", keyType, context))
            return false;
        if (actual.IsAny) return IsSequenceTypeSubtype("item()*", valueType, context);
        foreach (var field in actual.Fields)
            if (!IsSequenceTypeSubtype(field.SequenceTypeText, valueType, context)) return false;
        return true;
    }

    /// <summary>
    /// Checks whether one schema-aware sequence type is a subtype of another. Handles
    /// user-defined atomic restrictions, unions, and list types by resolving expanded
    /// QNames and walking the schema type hierarchy.
    /// </summary>
    private static bool IsSchemaAwareSequenceSubtype(EvaluationContext context, string actualTypeName, string testTypeName)
    {
        if (context.SchemaSet is null)
            return false;

        try
        {
            var (actualNs, actualLocal) = ResolveTypeQName(actualTypeName, context);
            var (testNs, testLocal) = ResolveTypeQName(testTypeName, context);

            if (TryGetSchemaSimpleTypeExpanded(actualNs, actualLocal, context, out var actualSchemaType))
            {
                // Exact match or derivation first.
                if (IsSchemaTypeSubtype(context, actualSchemaType.QualifiedName.Namespace, actualSchemaType.QualifiedName.Name, testNs, testLocal))
                    return true;

                // A list type semantically denotes itemType*; a union type denotes the
                // union of its member type sequences.
                return IsSchemaTypeSequenceSubtype(context, actualSchemaType, testTypeName);
            }

            // Built-in actual type against a user-defined test type.
            if (TryGetSchemaSimpleTypeExpanded(testNs, testLocal, context, out _))
            {
                return IsSchemaTypeSubtype(context, actualNs, actualLocal, testNs, testLocal);
            }
        }
        catch
        {
            // Ignore resolution errors and fall through to the built-in subtype check.
        }

        return false;
    }

    /// <summary>
    /// Checks whether a resolved schema simple type (including list and union varieties)
    /// is a subtype of the test sequence type. The caller has already verified that the
    /// two names are not identical or in a direct derivation relationship.
    /// </summary>
    private static bool IsSchemaTypeSequenceSubtype(EvaluationContext context, XmlSchemaSimpleType actualSchemaType, string testTypeName)
        => IsSchemaTypeSequenceSubtype(context, actualSchemaType, testTypeName, new HashSet<XmlSchemaSimpleType>());

    private static bool IsSchemaTypeSequenceSubtype(EvaluationContext context, XmlSchemaSimpleType actualSchemaType, string testTypeName, HashSet<XmlSchemaSimpleType> visited)
    {
        if (!visited.Add(actualSchemaType))
            return false;

        switch (GetSchemaTypeVariety(actualSchemaType))
        {
            case SchemaTypeVariety.List:
            {
                var itemType = GetListItemType(actualSchemaType);
                if (itemType is null)
                    return false;
                return IsSequenceTypeSubtype(FormatSchemaTypeName(itemType) + "*", testTypeName, context);
            }

            case SchemaTypeVariety.Union:
            {
                foreach (var member in GetUnionMemberTypes(actualSchemaType, context))
                {
                    if (member is null)
                        continue;
                    if (!IsSchemaTypeSequenceSubtype(context, member, testTypeName, visited))
                        return false;
                }
                return true;
            }

            default:
            {
                // An atomic type denotes a single item. Direct schema derivation is checked
                // above; remaining non-schema supertypes are item() and xs:anyAtomicType.
                // Do NOT call IsSequenceTypeSubtype here with the original testTypeName: when
                // testTypeName resolves to the same schema type it would re-enter
                // IsSchemaAwareSequenceSubtype and recurse forever because each call starts
                // with a fresh visited set.
                var (testNs, testLocal) = ResolveTypeQName(testTypeName, context);
                var actualQName = actualSchemaType.QualifiedName;
                if (IsSchemaTypeSubtype(context, actualQName.Namespace, actualQName.Name, testNs, testLocal))
                    return true;

                string testNorm = testLocal.ToLowerInvariant();
                if (testNs == XmlSchema.Namespace && testNorm is "anyatomictype")
                    return true;
                if (testNs == string.Empty && testNorm is "item" or "item()")
                    return true;

                // A schema union test accepts any value whose type is a subtype of at least
                // one of its member types (e.g. xs:date is a subtype of union(xs:date, xs:time)).
                if (TryGetSchemaSimpleTypeExpanded(testNs, testLocal, context, out var testSchemaType)
                    && GetSchemaTypeVariety(testSchemaType) == SchemaTypeVariety.Union)
                {
                    string actualName = FormatSchemaTypeName(actualSchemaType);
                    foreach (var member in GetUnionMemberTypes(testSchemaType, context))
                    {
                        if (member is null)
                            continue;
                        if (IsSchemaAwareSequenceSubtype(context, actualName, FormatSchemaTypeName(member)))
                            return true;
                    }
                }

                // Built-in atomic hierarchy (e.g. xs:int is a subtype of xs:decimal).
                string actualNorm = FormatSchemaTypeName(actualSchemaType).ToLowerInvariant();
                if (actualNorm.StartsWith("xs:"))
                    actualNorm = actualNorm[3..];
                return IsBaseTypeSubtype(actualNorm, testNorm);
            }
        }
    }

    /// <summary>
    /// Returns a sequence-type string for a schema simple type (xs:local for built-in
    /// types, Q{uri}local for user-defined types).
    /// </summary>
    private static string FormatSchemaTypeName(XmlSchemaSimpleType type)
    {
        if (type.QualifiedName.Namespace == XmlSchema.Namespace)
            return $"xs:{type.QualifiedName.Name}";
        return $"Q{{{type.QualifiedName.Namespace}}}{type.QualifiedName.Name}";
    }

    /// <summary>
    /// Whether the normalized type name denotes a node kind test (including <c>item()</c>,
    /// which accepts nodes without atomization during function conversion).
    /// </summary>
    private static bool IsNodeKindTestType(string type)
    {
        var t = type.Trim().ToLowerInvariant();
        if (t.Length > 0 && "?+*".Contains(t[^1]))
            t = t[..^1].TrimEnd();
        while (t.Length > 1 && t[0] == '(' && FindMatchingParen(t, 0) == t.Length - 1)
            t = t[1..^1].Trim();

        // XPath 4.0 §3.2.5: a choice is a node kind test when every alternative is one
        // (e.g. (element(a)|element(b))): node arguments then pass through unchanged.
        if (TryGetChoiceAlternatives(t, out var choiceAlts))
            return choiceAlts.All(IsNodeKindTestType);

        return t is "item" or "item()" or "node" or "node()" or "element" or "element()"
            or "attribute" or "attribute()" or "document-node" or "document-node()"
            or "schema-element" or "schema-attribute" or "text" or "text()"
            or "comment" or "comment()" or "processing-instruction" or "processing-instruction()"
            or "namespace-node" or "namespace-node()"
            || t.StartsWith("element(") || t.StartsWith("attribute(") || t.StartsWith("document-node(")
            || t.StartsWith("schema-element(") || t.StartsWith("schema-attribute(")
            || t.StartsWith("text(") || t.StartsWith("comment(") || t.StartsWith("processing-instruction(")
            || t.StartsWith("namespace-node(");
    }

    /// <summary>
    /// Whether the (lower-cased, occurrence-free) base type belongs to the function
    /// family: function types, map types, and array types.
    /// </summary>
    private static bool IsFunctionFamilyType(string baseType)
        => baseType.StartsWith("function(") || baseType.StartsWith("map(") || baseType.StartsWith("array(")
            || baseType is "function(*)" or "map(*)" or "array(*)" or "function" or "map" or "array";

    /// <summary>
    /// Strips an outer occurrence indicator from a function-family type, but only when
    /// it directly follows the closing parenthesis (e.g. <c>map(*)*</c>); a trailing
    /// indicator after a return type (e.g. <c>function(xs:int) as xs:string*</c>) is
    /// part of the type itself.
    /// </summary>
    private static (string Type, char Occurrence) StripOuterOccurrence(string type)
    {
        if (type.Length >= 2 && type[^1] is '?' or '*' or '+' && type[^2] == ')')
        {
            // The trailing indicator is an outer occurrence only when it directly
            // follows the closing parenthesis of the parameter/member list; after an
            // 'as' return clause it belongs to the return type instead.
            int open = type.IndexOf('(');
            if (open >= 0 && FindMatchingParen(type, open) == type.Length - 2)
                return (type[..^1].TrimEnd(), type[^1]);
        }
        return (type, '\0');
    }

    /// <summary>
    /// Adds an empty-sequence alternative to a sequence type (used for the result type
    /// of a map viewed as a function: looking up an absent key returns ()).
    /// </summary>
    private static string Optionalize(string sequenceType)
    {
        var t = sequenceType.Trim();
        if (t.Length == 0) return "item()*";
        return t[^1] switch
        {
            '*' or '?' => t,
            '+' => t[..^1] + "*",
            _ => t + "?"
        };
    }

    /// <summary>
    /// Structural subtyping within the function family (XPath 3.1 §2.5.6): function
    /// subsumption with contravariant parameters and a covariant result; map/array
    /// type covariance; and the implied function signatures of maps and arrays
    /// (MapTest-050..054).
    /// </summary>
    private static bool IsFunctionFamilySubtype(string actual, string test, EvaluationContext? context = null)
    {
        // Normalize the bare/generic names.
        if (actual is "map" or "map()") actual = "map(*)";
        if (actual is "array" or "array()") actual = "array(*)";
        if (actual is "function" or "function()") actual = "function(*)";
        if (test is "map" or "map()") test = "map(*)";
        if (test is "array" or "array()") test = "array(*)";
        if (test is "function" or "function()") test = "function(*)";

        if (test == "item()") return true;
        if (test == "function(*)") return true; // every function-family type is a function(*)
        if (actual == "function(*)") return false;

        if (actual == "map(*)" || actual.StartsWith("map("))
        {
            if (test == "map(*)") return true;
            if (test.StartsWith("map("))
            {
                if (!TryGetMapTypeParts(actual, out var ak, out var av) || !TryGetMapTypeParts(test, out var tk, out var tv))
                    return false;
                return IsSequenceTypeSubtype(ak, tk, context) && IsSequenceTypeSubtype(av, tv, context);
            }
            if (test.StartsWith("function("))
            {
                if (!TryParseFunctionType(test, out var tp, out var tr)) return false;
                if (tp.Length != 1) return false;
                // A map accepts any single atomic key; contravariance: test param ≤ xs:anyAtomicType.
                if (!IsSequenceTypeSubtype(tp[0], "xs:anyAtomicType", context)) return false;
                string v = actual == "map(*)" ? "item()*" : MapTypeParts(actual).Value;
                return IsSequenceTypeSubtype(Optionalize(v), tr, context);
            }
            return false;
        }

        if (actual == "array(*)" || actual.StartsWith("array("))
        {
            if (test == "array(*)") return true;
            if (test.StartsWith("array("))
            {
                return IsSequenceTypeSubtype(ArrayTypeInner(actual), ArrayTypeInner(test), context);
            }
            if (test.StartsWith("function("))
            {
                if (!TryParseFunctionType(test, out var tp, out var tr)) return false;
                if (tp.Length != 1) return false;
                // An array accepts any integer index; contravariance: test param ≤ xs:integer.
                if (!IsSequenceTypeSubtype(tp[0], "xs:integer", context)) return false;
                string t = actual == "array(*)" ? "item()*" : ArrayTypeInner(actual);
                return IsSequenceTypeSubtype(t, tr, context);
            }
            return false;
        }

        if (actual.StartsWith("function(") && test.StartsWith("function("))
        {
            if (!TryParseFunctionType(actual, out var ap, out var ar)) return false;
            if (!TryParseFunctionType(test, out var tp, out var tr)) return false;
            if (ap.Length != tp.Length) return false;
            // Parameters are contravariant; the result is covariant.
            for (int i = 0; i < ap.Length; i++)
                if (!IsSequenceTypeSubtype(tp[i], ap[i], context)) return false;
            return IsSequenceTypeSubtype(ar, tr, context);
        }

        return false;
    }

    /// <summary>Extracts the key and value type parts of a <c>map(K, V)</c> type.</summary>
    private static bool TryGetMapTypeParts(string mapType, out string keyType, out string valueType)
    {
        keyType = "xs:anyAtomicType";
        valueType = "item()*";
        if (!mapType.StartsWith("map(") || !mapType.EndsWith(')'))
            return false;
        var inner = mapType.Substring(4, mapType.Length - 5).Trim();
        if (inner.Length == 0 || inner == "*")
            return false;
        var parts = SplitTopLevel(inner, ',');
        if (parts.Length != 2)
            return false;
        keyType = parts[0];
        valueType = parts[1];
        return true;
    }

    /// <summary>Returns the value type part of a <c>map(K, V)</c> type (assumed well-formed).</summary>
    private static (string Key, string Value) MapTypeParts(string mapType)
    {
        TryGetMapTypeParts(mapType, out var k, out var v);
        return (k, v);
    }

    /// <summary>Extracts the member type of an <c>array(T)</c> type.</summary>
    private static string ArrayTypeInner(string arrayType)
    {
        if (!arrayType.StartsWith("array(") || !arrayType.EndsWith(')'))
            return "item()*";
        var inner = arrayType.Substring(6, arrayType.Length - 7).Trim();
        return inner.Length == 0 || inner == "*" ? "item()*" : inner;
    }

    /// <summary>
    /// Checks whether an element(N, T1) / attribute(N, T1) sequence type is a subtype of
    /// another element(N, T2) / attribute(N, T2) type by comparing names and walking the
    /// schema type hierarchy for the type parts. Built-in schema types (xs:anyType, etc.)
    /// are compared even when no user schema is imported (hof-039 / hof-053).
    /// </summary>
    private static bool IsElementOrAttributeSchemaSubtype(string actualType, string testType, EvaluationContext context)
    {
        static string StripOuterOccurrence(string s)
        {
            s = s.Trim();
            if (s.Length > 0 && "?+*".Contains(s[^1]))
                return s[..^1].TrimEnd();
            return s;
        }

        if (!TryGetElementAttributeKindTestParts(StripOuterOccurrence(actualType), out var actualKind, out var actualName, out var actualTypePart))
            return false;
        if (!TryGetElementAttributeKindTestParts(StripOuterOccurrence(testType), out var testKind, out var testName, out var testTypePart))
            return false;
        if (actualKind != testKind)
            return false;

        // Name compatibility: the actual name must be at least as specific as the test name.
        // element(N, T) ≤ element(N, T) and element(N, T) ≤ element(*, T), but not vice versa.
        if (testName != "*" && actualName != testName)
            return false;

        // A missing element type part defaults to xs:anyType? (nillable) per XPath 3.1;
        // attribute tests default to xs:anyType (attributes cannot be nilled). The wildcard
        // "*" also means the same default type.
        actualTypePart = string.IsNullOrEmpty(actualTypePart) || actualTypePart == "*"
            ? (actualKind == "element" ? "xs:anyType?" : "xs:anyType")
            : actualTypePart;
        testTypePart = string.IsNullOrEmpty(testTypePart) || testTypePart == "*"
            ? (testKind == "element" ? "xs:anyType?" : "xs:anyType")
            : testTypePart;

        // XSD 1.1 nillability marker '?' on the type part: a non-nillable type is a subtype of
        // a nillable one, but a nillable type is not a subtype of a non-nillable one.
        bool actualNillable = actualTypePart.EndsWith("?");
        bool testNillable = testTypePart.EndsWith("?");
        if (actualNillable && !testNillable)
            return false;

        if (actualTypePart.EndsWith("?"))
            actualTypePart = actualTypePart[..^1].TrimEnd();
        if (testTypePart.EndsWith("?"))
            testTypePart = testTypePart[..^1].TrimEnd();

        try
        {
            var (actualNs, actualLocal) = ResolveTypeQName(actualTypePart, context);
            var (testNs, testLocal) = ResolveTypeQName(testTypePart, context);
            return IsSchemaTypeSubtype(context, actualNs, actualLocal, testNs, testLocal);
        }
        catch
        {
            return false;
        }
    }

    /// <summary>
    /// Parses an element(N, T) or attribute(N, T) kind test, returning the kind,
    /// the name part (or "*"), and the optional type part with original case preserved.
    /// </summary>
    private static bool TryGetElementAttributeKindTestParts(string typeName, out string kind, out string name, out string? typePart)
    {
        kind = string.Empty;
        name = string.Empty;
        typePart = null;

        var s = typeName.Trim();
        if (s.StartsWith("element(", StringComparison.OrdinalIgnoreCase) && s.EndsWith(')'))
        {
            kind = "element";
            var inner = s.Substring(8, s.Length - 9).Trim();
            if (string.IsNullOrEmpty(inner) || inner == "*")
                return true;
            var parts = SplitTopLevel(inner, ',');
            name = parts[0].Trim();
            if (parts.Length > 1)
                typePart = parts[1].Trim();
            return true;
        }

        if (s.StartsWith("attribute(", StringComparison.OrdinalIgnoreCase) && s.EndsWith(')'))
        {
            kind = "attribute";
            var inner = s.Substring(10, s.Length - 11).Trim();
            if (string.IsNullOrEmpty(inner) || inner == "*")
                return true;
            var parts = SplitTopLevel(inner, ',');
            name = parts[0].Trim();
            if (parts.Length > 1)
                typePart = parts[1].Trim();
            return true;
        }

        return false;
    }

    /// <summary>
    /// Checks whether <paramref name="actual"/> is a subtype of <paramref name="test"/>
    /// by walking the type hierarchy.
    /// </summary>
    private static bool IsBaseTypeSubtype(string actual, string test)
    {
        var queue = new Queue<string>();
        queue.Enqueue(actual);
        var visited = new HashSet<string>();

        while (queue.Count > 0)
        {
            string current = queue.Dequeue();
            if (current == test) return true;
            if (!visited.Add(current)) continue;

            foreach (var super in GetDirectSupertypes(current))
                queue.Enqueue(super);
        }

        return false;
    }

    /// <summary>
    /// Returns the immediate supertypes of a given base type name.
    /// </summary>
    private static IEnumerable<string> GetDirectSupertypes(string type)
    {
        // Named element/attribute tests are subtypes of the generic node-kind tests.
        if (type.StartsWith("element(") && type != "element()")
            return ["element()"];
        if (type.StartsWith("attribute(") && type != "attribute()")
            return ["attribute()"];

        return type switch
        {
            "byte" => ["short"],
            "short" => ["int"],
            "int" => ["long"],
            "long" => ["integer"],
            "unsignedbyte" => ["unsignedshort"],
            "unsignedshort" => ["unsignedint"],
            "unsignedint" => ["unsignedlong"],
            "unsignedlong" => ["nonnegativeinteger"],
            "positiveinteger" => ["nonnegativeinteger"],
            "nonnegativeinteger" => ["integer"],
            "negativeinteger" => ["nonpositiveinteger"],
            "nonpositiveinteger" => ["integer"],
            "integer" => ["decimal"],
            "decimal" => ["numeric"],
            "double" => ["numeric"],
            "float" => ["numeric"],
            "numeric" => ["anyatomictype"],
            "ncname" => ["name"],
            "name" => ["token"],
            "nmtoken" => ["token"],
            "language" => ["token"],
            "id" => ["ncname"],
            "idref" => ["ncname"],
            "entity" => ["ncname"],
            "token" => ["normalizedstring"],
            "normalizedstring" => ["string"],
            "string" => ["anyatomictype"],
            "untypedatomic" => ["anyatomictype"],
            "boolean" => ["anyatomictype"],
            "date" => ["anyatomictype"],
            "time" => ["anyatomictype"],
            "datetime" => ["anyatomictype"],
            "datetimestamp" => ["datetime"],
            "duration" => ["anyatomictype"],
            "daytimeduration" => ["duration"],
            "yearmonthduration" => ["duration"],
            "anyuri" => ["anyatomictype"],
            "qname" => ["anyatomictype"],
            "notation" => ["anyatomictype"],
            "hexbinary" => ["anyatomictype"],
            "base64binary" => ["anyatomictype"],
            "anyatomictype" => ["anysimpletype"],
            "anysimpletype" => ["anytype"],
            "anytype" => ["item()"],
            "element()" => ["node()"],
            "attribute()" => ["node()"],
            "text()" => ["node()"],
            "comment()" => ["node()"],
            "processing-instruction()" => ["node()"],
            "document-node()" => ["node()"],
            "namespace-node()" => ["node()"],
            "node()" => ["item()"],
            "function(*)" => ["item()"],
            "map(*)" => ["item()"],
            "array(*)" => ["item()"],
            _ => [],
        };
    }

    /// <summary>
    /// Checks whether an XDM value matches a simple <see cref="XdmValueKind"/>.
    /// </summary>
    private static bool ValueMatchesXdmKind(XdmValue value, XdmValueKind kind)
    {
        return kind switch
        {
            XdmValueKind.String => value.Kind == XdmValueKind.String,
            XdmValueKind.Integer => value.Kind == XdmValueKind.Integer,
            XdmValueKind.Decimal => value.Kind == XdmValueKind.Decimal,
            XdmValueKind.Double => value.Kind == XdmValueKind.Double,
            XdmValueKind.Float => value.Kind == XdmValueKind.Float,
            XdmValueKind.Boolean => value.Kind == XdmValueKind.Boolean,
            XdmValueKind.DateTime => value.Kind == XdmValueKind.DateTime,
            XdmValueKind.Date => value.Kind == XdmValueKind.Date,
            XdmValueKind.Time => value.Kind == XdmValueKind.Time,
            XdmValueKind.Duration => value.Kind == XdmValueKind.Duration,
            XdmValueKind.Node => value.IsNode,
            _ => true
        };
    }

    // ------------------------------------------------------------------
    // Type promotion helpers
    // ------------------------------------------------------------------

    private static bool HasTimezoneSuffix(string s)
    {
        string t = s.Trim();
        return t.EndsWith('Z') || t.EndsWith('z') || System.Text.RegularExpressions.Regex.IsMatch(t, @"[Tt]\d{2}:\d{2}:\d{2}[Zz]|[Tt]\d{2}:\d{2}:\d{2}[+\-]\d{2}:\d{2}$|[+\-]\d{2}:\d{2}$");
    }

    private static string FormatXPathTimezone(DateTimeOffset dto, bool hasTz)
    {
        if (!hasTz) return "";
        string tz = dto.ToString("zzz", System.Globalization.CultureInfo.InvariantCulture);
        return tz == "+00:00" ? "Z" : tz;
    }

    private static readonly Regex XPathDateTimeRegex = new(
        @"^(?<year>[+-]?\d{4,})-(?<month>\d{2})-(?<day>\d{2})T(?<hour>\d{2}):(?<minute>\d{2}):(?<second>\d{2})(?:\.(?<frac>\d+))?(?<tz>Z|[+-]\d{2}:\d{2})?$",
        RegexOptions.Compiled);

    private static readonly Regex XPathDateRegex = new(
        @"^(?<year>[+-]?\d{4,})-(?<month>\d{2})-(?<day>\d{2})(?<tz>Z|[+-]\d{2}:\d{2})?$",
        RegexOptions.Compiled);

    private static readonly Regex XPathTimeRegex = new(
        @"^(?<hour>\d{2}):(?<minute>\d{2}):(?<second>\d{2})(?:\.(?<frac>\d+))?(?<tz>Z|[+-]\d{2}:\d{2})?$",
        RegexOptions.Compiled);

    private static bool TryParseXPathDateTime(string s, out XPathDateTime xdt, out bool hasTz)
    {
        xdt = default;
        hasTz = false;
        var m = XPathDateTimeRegex.Match(s);
        if (!m.Success) return false;

        string yearStr = m.Groups["year"].Value;
        long year = long.Parse(yearStr, CultureInfo.InvariantCulture);
        // Lexically valid but outside the implementation-defined year range: FODT0001
        // (date/time overflow), not FORG0001 (date-094e/f, date-095e/f).
        if (year > int.MaxValue || year < int.MinValue)
            throw new InvalidOperationException($"FODT0001: The year '{yearStr}' is outside the supported range.");
        // Reject + sign and leading zeros for years longer than 4 digits
        if (yearStr.StartsWith('+')) return false;
        if (yearStr.Length > 4 && yearStr[0] == '0') return false;

        int month = int.Parse(m.Groups["month"].Value, CultureInfo.InvariantCulture);
        int day = int.Parse(m.Groups["day"].Value, CultureInfo.InvariantCulture);
        if (month < 1 || month > 12) return false;
        if (day < 1 || day > 31) return false;
        if (day > DaysInMonth(year, month)) return false;

        int hour = int.Parse(m.Groups["hour"].Value, CultureInfo.InvariantCulture);
        int minute = int.Parse(m.Groups["minute"].Value, CultureInfo.InvariantCulture);
        int second = int.Parse(m.Groups["second"].Value, CultureInfo.InvariantCulture);
        int millisecond = 0;
        bool hasFrac = m.Groups["frac"].Success;
        if (hasFrac)
        {
            string frac = m.Groups["frac"].Value;
            // Take up to 3 digits for milliseconds
            if (frac.Length > 3) frac = frac[..3];
            millisecond = int.Parse(frac.PadRight(3, '0'), CultureInfo.InvariantCulture);
        }

        // Validate time components
        if (hour > 24 || minute > 59 || second > 59) return false;
        if (hour == 24 && (minute != 0 || second != 0 || millisecond != 0)) return false;

        int tzMinutes = 0;
        hasTz = m.Groups["tz"].Success;
        if (hasTz)
        {
            string tz = m.Groups["tz"].Value;
            if (tz == "Z" || tz == "z")
            {
                tzMinutes = 0;
            }
            else
            {
                if (!IsValidTimezone(tz)) return false;
                tzMinutes = ParseTimezoneOffset(tz);
            }
        }

        xdt = NormalizeHour24(new XPathDateTime(year, month, day, hour, minute, second, millisecond, tzMinutes, hasTz));
        return true;
    }

    private static bool TryParseXPathDate(string s, out XPathDateTime xdt, out bool hasTz)
    {
        xdt = default;
        hasTz = false;
        var m = XPathDateRegex.Match(s);
        if (!m.Success) return false;

        string yearStr = m.Groups["year"].Value;
        long year = long.Parse(yearStr, CultureInfo.InvariantCulture);
        // Lexically valid but outside the implementation-defined year range: FODT0001
        // (date/time overflow), not FORG0001 (date-094e/f, date-095e/f).
        if (year > int.MaxValue || year < int.MinValue)
            throw new InvalidOperationException($"FODT0001: The year '{yearStr}' is outside the supported range.");
        // Reject + sign and leading zeros for years longer than 4 digits
        if (yearStr.StartsWith('+')) return false;
        if (yearStr.Length > 4 && yearStr[0] == '0') return false;

        int month = int.Parse(m.Groups["month"].Value, CultureInfo.InvariantCulture);
        int day = int.Parse(m.Groups["day"].Value, CultureInfo.InvariantCulture);
        if (month < 1 || month > 12) return false;
        if (day < 1 || day > 31) return false;
        if (day > DaysInMonth(year, month)) return false;

        int tzMinutes = 0;
        hasTz = m.Groups["tz"].Success;
        if (hasTz)
        {
            string tz = m.Groups["tz"].Value;
            if (tz == "Z" || tz == "z")
                tzMinutes = 0;
            else
            {
                if (!IsValidTimezone(tz)) return false;
                tzMinutes = ParseTimezoneOffset(tz);
            }
        }

        xdt = new XPathDateTime(year, month, day, 0, 0, 0, 0, tzMinutes, hasTz);
        return true;
    }

    private static bool TryParseXPathTime(string s, out XPathDateTime xdt, out bool hasTz)
    {
        xdt = default;
        hasTz = false;
        var m = XPathTimeRegex.Match(s);
        if (!m.Success) return false;

        int hour = int.Parse(m.Groups["hour"].Value, CultureInfo.InvariantCulture);
        int minute = int.Parse(m.Groups["minute"].Value, CultureInfo.InvariantCulture);
        int second = int.Parse(m.Groups["second"].Value, CultureInfo.InvariantCulture);
        int millisecond = 0;
        bool hasFrac = m.Groups["frac"].Success;
        if (hasFrac)
        {
            string frac = m.Groups["frac"].Value;
            if (frac.Length > 3) frac = frac[..3];
            millisecond = int.Parse(frac.PadRight(3, '0'), CultureInfo.InvariantCulture);
        }

        // Validate time components
        if (hour > 24 || minute > 59 || second > 59) return false;
        if (hour == 24 && (minute != 0 || second != 0 || millisecond != 0)) return false;

        int tzMinutes = 0;
        hasTz = m.Groups["tz"].Success;
        if (hasTz)
        {
            string tz = m.Groups["tz"].Value;
            if (tz == "Z" || tz == "z")
                tzMinutes = 0;
            else
            {
                if (!IsValidTimezone(tz)) return false;
                tzMinutes = ParseTimezoneOffset(tz);
            }
        }

        // xs:time normalizes 24:00:00 to 00:00:00 on the same (reference) day.
        if (hour == 24)
            hour = 0;
        xdt = new XPathDateTime(1, 1, 1, hour, minute, second, millisecond, tzMinutes, hasTz);
        return true;
    }

    private static int DaysInMonth(long year, int month)
    {
        return month switch
        {
            1 or 3 or 5 or 7 or 8 or 10 or 12 => 31,
            4 or 6 or 9 or 11 => 30,
            2 => IsLeapYear(year) ? 29 : 28,
            _ => 0
        };
    }

    private static bool IsLeapYear(long year)
    {
        if (year == 0) return true; // Year 0 is a leap year in XML Schema (proleptic Gregorian)
        if (year < 0) year = -year; // BCE leap years align with the negated year number
        return year % 4 == 0 && (year % 100 != 0 || year % 400 == 0);
    }

    private static bool IsValidTimezone(string tz)
    {
        // tz is like "+14:00" or "-05:00"
        int hours = int.Parse(tz[1..3], CultureInfo.InvariantCulture);
        int minutes = int.Parse(tz[4..6], CultureInfo.InvariantCulture);
        return hours <= 14 && !(hours == 14 && minutes > 0) && minutes <= 59;
    }

    private static int ParseTimezoneOffset(string tz)
    {
        // tz is like "+14:00" or "-05:00"
        bool negative = tz[0] == '-';
        var parts = tz[1..].Split(':');
        int hours = int.Parse(parts[0], CultureInfo.InvariantCulture);
        int minutes = int.Parse(parts[1], CultureInfo.InvariantCulture);
        int total = hours * 60 + minutes;
        return negative ? -total : total;
    }

    private static string NormalizeDateTimeString(string s)
    {
        // XML Schema allows T24:00:00 to represent midnight of the next day.
        // .NET's DateTimeOffset.TryParse does not handle this, so normalize it.
        int idx = s.IndexOf("T24:00:00");
        if (idx >= 0)
        {
            int after = idx + "T24:00:00".Length;
            // Allow T24:00:00 followed by all-zero fractional seconds.
            if (after >= s.Length || s[after] != '.')
            {
                // no fractional seconds - normalize directly
            }
            else
            {
                int i = after + 1;
                while (i < s.Length && char.IsDigit(s[i])) i++;
                if (!s[(after + 1)..i].All(c => c == '0'))
                    return s; // leave non-zero fractional T24 for the parser to reject
                after = i;
            }
            string datePart = s[..idx];
            string rest = s[after..];
            if (DateTimeOffset.TryParse(datePart, out var dto))
            {
                dto = dto.AddDays(1);
                string newDate = dto.ToString("yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
                return newDate + "T00:00:00" + rest;
            }
        }
        return s;
    }

    private static XPathDateTime NormalizeHour24(XPathDateTime xdt)
    {
        if (xdt.Hour != 24)
            return xdt;
        var (year, month, day) = XPathDateTimeHelper.AddDays(xdt.Year, xdt.Month, xdt.Day, 1);
        return new XPathDateTime(year, month, day, 0, 0, 0, 0, xdt.TimezoneOffsetMinutes, xdt.HasTimezone);
    }

    private static bool TryParseDouble(string s, out double result)
    {
        s = s.Trim();
        if (s == "INF" || s == "+INF")
        {
            result = double.PositiveInfinity;
            return true;
        }
        if (s == "-INF")
        {
            result = double.NegativeInfinity;
            return true;
        }
        if (s == "NaN")
        {
            result = double.NaN;
            return true;
        }
        // Explicitly reject case variants that .NET's double.TryParse would accept
        string upper = s.ToUpperInvariant();
        if (upper is "NAN" or "INF" or "+INF" or "-INF" or "INFINITY" or "+INFINITY" or "-INFINITY")
        {
            result = 0;
            return false;
        }
        return double.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out result);
    }

    private static bool TryParseFloat(string s, out float result)
    {
        s = s.Trim();
        if (s == "INF" || s == "+INF")
        {
            result = float.PositiveInfinity;
            return true;
        }
        if (s == "-INF")
        {
            result = float.NegativeInfinity;
            return true;
        }
        if (s == "NaN")
        {
            result = float.NaN;
            return true;
        }
        // Explicitly reject case variants that .NET's float.TryParse would accept
        string upper = s.ToUpperInvariant();
        if (upper is "NAN" or "INF" or "+INF" or "-INF" or "INFINITY" or "+INFINITY" or "-INFINITY")
        {
            result = 0;
            return false;
        }
        return float.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out result);
    }

    private static bool IsDouble(XdmValue value) =>
        value.Kind == XdmValueKind.Double;

    private static bool IsFloat(XdmValue value) =>
        value.Kind == XdmValueKind.Float;

    private static bool IsDuration(XdmValue value) =>
        value.Kind == XdmValueKind.Duration;

    private static bool IsEmptySeq(XdmValue value)
    {
        if (!value.IsSequence || value.SequenceValue is null)
            return false;
        foreach (var _ in XdmSequence.FromSource(value.SequenceValue))
            return false;
        return true;
    }

    /// <summary>
    /// Returns the first item of a sequence, or an undefined value for an empty sequence
    /// or a non-sequence input. Used for XPath 1.0 backwards-compatible first-item rules.
    /// </summary>
    private static XdmValue FirstItemOrUndefined(XdmValue value)
    {
        if (value.IsUndefined)
            return XdmValue.Undefined;
        if (!value.IsSequence || value.SequenceValue is null)
            return value;
        foreach (var item in XdmSequence.FromSource(value.SequenceValue))
        {
            if (!item.IsUndefined)
                return item;
        }
        return XdmValue.Undefined;
    }

    private static bool IsDecimal(XdmValue value) =>
        value.Kind == XdmValueKind.Decimal;

    private static double ToDouble(XdmValue value)
    {
        value = Atomize(value);
        return value.Kind switch
        {
            XdmValueKind.Integer => value.IntegerValue,
            XdmValueKind.Decimal => (double)value.DecimalValue,
            XdmValueKind.Double or XdmValueKind.Float => value.DoubleValue,
            XdmValueKind.Boolean => value.BooleanValue ? 1.0 : 0.0,
            _ => double.TryParse(value.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out var d) ? d : throw NumericConversionError(value, "double")
        };
    }

    private static decimal ToDecimal(XdmValue value)
    {
        value = Atomize(value);
        return value.Kind switch
        {
            XdmValueKind.Integer => value.IntegerValue,
            XdmValueKind.Decimal => value.DecimalValue,
            XdmValueKind.Double or XdmValueKind.Float => (decimal)value.DoubleValue,
            _ => decimal.TryParse(value.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out var d) ? d : throw NumericConversionError(value, "decimal")
        };
    }

    private static long ToInteger(XdmValue value)
    {
        value = Atomize(value);
        return value.Kind switch
        {
            XdmValueKind.Integer => value.IntegerValue,
            XdmValueKind.Decimal => (long)value.DecimalValue,
            XdmValueKind.Double or XdmValueKind.Float => (long)value.DoubleValue,
            _ => long.TryParse(value.ToString(), out var l) ? l : throw NumericConversionError(value, "integer")
        };
    }

    private static float ToFloat(XdmValue value)
    {
        value = Atomize(value);
        return value.Kind switch
        {
            XdmValueKind.Integer => value.IntegerValue,
            XdmValueKind.Decimal => (float)value.DecimalValue,
            XdmValueKind.Double or XdmValueKind.Float => (float)value.DoubleValue,
            XdmValueKind.Boolean => value.BooleanValue ? 1.0f : 0.0f,
            _ => float.TryParse(value.ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out var f) ? f : throw NumericConversionError(value, "float")
        };
    }

    // String-kind failures are xs:untypedAtomic cast failures (FORG0001 — plain xs:string
    // operands are rejected earlier by ValidateNumericOperand); any other kind is a
    // type error (XPTY0004, e.g. xs:duration as an arithmetic factor).
    private static InvalidOperationException NumericConversionError(XdmValue value, string target)
        => new(value.Kind == XdmValueKind.String
            ? $"FORG0001: Cannot convert {value.Kind} to {target}"
            : $"XPTY0004: Cannot convert {value.Kind} to {target}");

    // ------------------------------------------------------------------
    // Opcode helpers
    // ------------------------------------------------------------------

    /// <summary>
    /// Returns whether the value contains at least one item (fn:exists/fn:empty semantics).
    /// </summary>
    private static bool SequenceHasAnyItem(XdmValue value)
    {
        if (value.IsUndefined)
            return false;
        if (value.IsSequence)
        {
            var seq = value.SequenceValue;
            if (seq is null)
                return false; // a sequence value without a source is empty (matches MaterializeSequence/EBV)
            if (seq.TryGetLength(out var length))
                return length > 0;
            foreach (var _ in XdmSequence.FromSource(seq))
                return true;
            return false;
        }
        return true;
    }
    private static XdmValue AtomizeMapKey(XdmValue value)
    {
        if (value.IsFunction || value.IsMap || value.IsArray)
            throw new InvalidOperationException("FOTY0013");
        if (value.IsUndefined)
            throw new InvalidOperationException("XPTY0004: A map key must be a single atomic value, not the empty sequence");
        if (value.IsSequence)
        {
            var items = MaterializeSequence(value);
            if (items.Length != 1)
                throw new InvalidOperationException("XPTY0004: A map key must be a single atomic value, not a sequence");
            value = items[0];
        }
        return Atomize(value);
    }

    private static XdmValue LookupValue(XdmValue container, XdmValue key)
    {
        var results = new List<XdmValue>();
        LookupInto(container, key, results);
        return results.Count switch
        {
            0 => XdmValue.Undefined,
            1 => results[0],
            _ => XdmValue.FromSequence(MaterializedSequence.FromList(results))
        };
    }

    /// <summary>
    /// Expands the lookup over container items (outer) and key items (inner), matching
    /// XPath 3.1 §3.11.3 result ordering (Lookup-107: for each container, for each key).
    /// </summary>
    private static void LookupInto(XdmValue container, XdmValue key, List<XdmValue> results)
    {
        if (container.IsUndefined)
            return;
        // XPath 4.0 §17.7: the LHS of '?' extracts the jvalue of a JNode.
        if (container.IsJNode)
        {
            LookupInto(container.JNodeValue.Value, key, results);
            return;
        }
        if (container.IsSequence && container.SequenceValue is not null)
        {
            foreach (var item in XdmSequence.FromSource(container.SequenceValue))
                LookupInto(item, key, results);
            return;
        }
        if (key.IsUndefined)
            return;
        if (key.IsSequence && key.SequenceValue is not null)
        {
            foreach (var singleKey in XdmSequence.FromSource(key.SequenceValue))
                LookupSingle(container, singleKey, results);
            return;
        }
        LookupSingle(container, key, results);
    }

    private static void LookupSingle(XdmValue container, XdmValue key, List<XdmValue> results)
    {
        if (container.Kind == XdmValueKind.Map)
        {
            var vkey = AtomizeMapKey(key);
            // XPath 4.0 §4.15.3: an undeclared field on a record is XPTY0004; plain
            // maps keep returning the empty sequence for unknown keys.
            CheckRecordLookupKey(container.MapValue, vkey);
            if (container.MapValue.TryGetValue(vkey, out var value))
                AppendLookupResult(results, value);
            return;
        }
        if (container.Kind == XdmValueKind.Array)
        {
            AppendLookupResult(results, ArrayLookup(container.ArrayValue, key));
            return;
        }
        // Lookup on anything other than a map or an array is a type error (Lookup-012).
        throw new InvalidOperationException($"XPTY0004: Lookup operator requires a map or an array, got {container.Kind}.");
    }

    /// <summary>
    /// Array member access shared by the lookup operator and array-as-function calls.
    /// The key must be xs:integer (Lookup-119: a double is XPTY0004, not truncated);
    /// out-of-range indexes raise FOAY0001. Bounds are checked against Count (not Get)
    /// so that a stored empty-sequence member is not mistaken for an out-of-range index.
    /// </summary>
    private static XdmValue ArrayLookup(XdmArray array, XdmValue key)
    {
        var akey = Atomize(key);
        long idx;
        if (akey.Kind == XdmValueKind.Integer)
        {
            idx = akey.IntegerValue;
        }
        else if (IsUntypedAtomicValue(akey) && long.TryParse(akey.ToString(), NumberStyles.Integer, CultureInfo.InvariantCulture, out var parsed))
        {
            idx = parsed;
        }
        else
        {
            throw new InvalidOperationException($"XPTY0004: Array lookup key must be xs:integer, got {akey.Kind}.");
        }
        if (idx < 1 || idx > array.Count)
            throw new InvalidOperationException($"FOAY0001: Array index {idx} is out of bounds (array size {array.Count}).");
        return array.Get((int)idx);
    }

    private static void AppendLookupResult(List<XdmValue> results, XdmValue value)
    {
        if (value.IsUndefined)
            return;
        if (value.IsSequence && value.SequenceValue is not null)
        {
            foreach (var item in XdmSequence.FromSource(value.SequenceValue))
                results.Add(item);
        }
        else
        {
            results.Add(value);
        }
    }

    private static string AtomizedString(XdmValue value)
    {
        if (value.IsUndefined)
            return string.Empty;

        if (value.IsNode)
            return value.NodeValue.StringValue;

        if (value.IsFunction || value.IsMap || value.IsArray)
            throw new InvalidOperationException("FOTY0013");

        if (value.IsSequence)
        {
            foreach (var item in XdmSequence.FromSource(value.SequenceValue!))
                return AtomizedString(item);
            return string.Empty;
        }

        return value.ToString();
    }

    private static string NormalizeSpaceString(string s)
    {
        if (string.IsNullOrWhiteSpace(s)) return string.Empty;
        var parts = s.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries);
        return string.Join(' ', parts);
    }

    private static RegexOptions ParseRegexFlags(string flags)
    {
        var options = RegexOptions.None;
        foreach (char c in flags)
        {
            switch (c)
            {
                case 'i': options |= RegexOptions.IgnoreCase; break;
                case 'm': options |= RegexOptions.Multiline; break;
                case 's': options |= RegexOptions.Singleline; break;
                case 'x': options |= RegexOptions.IgnorePatternWhitespace; break;
            }
        }
        return options;
    }

    private static XdmValue Sum(System.Collections.Generic.List<XdmValue> items)
    {
        bool allIntegerOrDecimal = true;
        foreach (var item in items)
        {
            var a = Atomize(item);
            if (a.Kind != XdmValueKind.Integer && a.Kind != XdmValueKind.Decimal)
            {
                allIntegerOrDecimal = false;
                break;
            }
        }
        if (allIntegerOrDecimal)
        {
            decimal sum = 0m;
            foreach (var item in items)
                sum += ToDecimal(Atomize(item));
            return XdmValue.FromDecimal(sum);
        }
        double sumD = 0.0;
        foreach (var item in items)
            sumD += ToDouble(Atomize(item));
        return XdmValue.FromDouble(sumD);
    }

    private static XdmValue MinMax(System.Collections.Generic.List<XdmValue> items, bool min)
    {
        bool allIntegerOrDecimal = true;
        foreach (var item in items)
        {
            var a = Atomize(item);
            if (a.Kind != XdmValueKind.Integer && a.Kind != XdmValueKind.Decimal)
            {
                allIntegerOrDecimal = false;
                break;
            }
        }
        if (allIntegerOrDecimal)
        {
            decimal result = ToDecimal(Atomize(items[0]));
            for (int i = 1; i < items.Count; i++)
            {
                decimal v = ToDecimal(Atomize(items[i]));
                if (min ? v < result : v > result)
                    result = v;
            }
            return XdmValue.FromDecimal(result);
        }
        double resultD = ToDouble(Atomize(items[0]));
        for (int i = 1; i < items.Count; i++)
        {
            double v = ToDouble(Atomize(items[i]));
            if (min ? v < resultD : v > resultD)
                resultD = v;
        }
        return XdmValue.FromDouble(resultD);
    }

    // ------------------------------------------------------------------
    // OrderBy helpers
    // ------------------------------------------------------------------

    private static List<(string Name, XdmValue Value)> CaptureWindowBindings(
        XdmValue[] items,
        int index,
        int position,
        string? currentVar,
        string? posVar,
        string? prevVar,
        string? nextVar)
    {
        var bindings = new List<(string, XdmValue)>(4);
        if (currentVar is not null)
            bindings.Add((currentVar, items[index]));
        if (posVar is not null)
            bindings.Add((posVar, XdmValue.FromInteger(position)));
        if (prevVar is not null)
            bindings.Add((prevVar, index > 0 ? items[index - 1] : XdmValue.FromSequence(XdmSequence.Empty)));
        if (nextVar is not null)
            bindings.Add((nextVar, index < items.Length - 1 ? items[index + 1] : XdmValue.FromSequence(XdmSequence.Empty)));
        return bindings;
    }

    private static bool EvaluateWindowCondition(
        IrModule module,
        EvaluationContext context,
        XdmValue[] registers,
        int entryPoint,
        XdmValue[] items,
        int index,
        int position,
        string? currentVar,
        string? posVar,
        string? prevVar,
        string? nextVar)
    {
        foreach (var (name, value) in CaptureWindowBindings(items, index, position, currentVar, posVar, prevVar, nextVar))
        {
            var (local, ns) = ResolveWindowVariableName(name, context);
            context.WithVariable(local, value, ns);
        }
        var (condResult, _) = ExecuteBlock(module, context, registers, entryPoint);
        return condResult.GetEffectiveBooleanValue();
    }

    private static void EmitFlworWindow(
        IrModule module,
        EvaluationContext context,
        XdmValue[] registers,
        WindowInfo info,
        List<XdmValue> results,
        List<XdmValue> windowItems,
        List<(string Name, XdmValue Value)> startBindings,
        XdmValue[] items,
        int endIndex,
        int endPosition)
    {
        // Bind the window variable to the window's item sequence.
        var windowValue = windowItems.Count == 1
            ? windowItems[0]
            : XdmValue.FromSequence(MaterializedSequence.FromList(new List<XdmValue>(windowItems)));

        // XPTY0004: enforce an optional 'as SequenceType' declaration on the window variable.
        if (info.DeclaredTypeName is not null &&
            !InstanceOf(windowValue, info.DeclaredTypeName, info.DeclaredTypeOccurrence, null, context))
        {
            throw new InvalidOperationException(
                $"XPTY0004: Window variable '${info.VariableName}' does not match the declared type '{info.DeclaredTypeName}'.");
        }

        var (windowLocal, windowNs) = ResolveWindowVariableName(info.VariableName, context);
        context.WithVariable(windowLocal, windowValue, windowNs);

        // Bind the start condition variables to the values captured when the window opened.
        foreach (var (name, value) in startBindings)
        {
            var (local, ns) = ResolveWindowVariableName(name, context);
            context.WithVariable(local, value, ns);
        }

        // Bind the end condition variables to the values at the closing item.
        foreach (var (name, value) in CaptureWindowBindings(items, endIndex, endPosition,
                     info.EndCurrent, info.EndPos, info.EndPrev, info.EndNext))
        {
            var (local, ns) = ResolveWindowVariableName(name, context);
            context.WithVariable(local, value, ns);
        }

        var (rhsResult, _) = ExecuteBlock(module, context, registers, info.RhsEntryPoint);
        if (rhsResult.IsSequence && rhsResult.SequenceValue is not null)
        {
            foreach (var r in XdmSequence.FromSource(rhsResult.SequenceValue))
                results.Add(r);
        }
        else if (!rhsResult.IsUndefined)
        {
            results.Add(rhsResult);
        }
    }

    // Resolves a window-clause variable name in lexical form (local, prefix:local, or
    // Q{uri}local) to its (local name, namespace URI) pair the way variable references
    // resolve; an undeclared prefix raises XPST0081.
    private static (string Local, string Ns) ResolveWindowVariableName(string rawName, EvaluationContext context)
    {
        if (rawName.StartsWith("Q{", StringComparison.Ordinal))
        {
            int closeBrace = rawName.IndexOf('}');
            if (closeBrace > 1)
                return (rawName[(closeBrace + 1)..], rawName[2..closeBrace]);
        }
        int colon = rawName.IndexOf(':');
        if (colon > 0)
        {
            if (!context.TryResolveNamespace(rawName[..colon], out var prefixNs))
                throw new InvalidOperationException($"XPST0081: Prefix '{rawName[..colon]}' is not declared.");
            return (rawName[(colon + 1)..], prefixNs);
        }
        return (rawName, "");
    }

    private static string ResolveCollationUri(string collation, string? baseUri)
    {
        if (string.IsNullOrEmpty(collation))
            return string.Empty;
        if (Uri.IsWellFormedUriString(collation, UriKind.Absolute))
            return collation;
        if (!string.IsNullOrEmpty(baseUri) &&
            Uri.TryCreate(new Uri(baseUri), collation, out var resolved))
        {
            return resolved.AbsoluteUri;
        }
        return collation;
    }

    /// <summary>
    /// Atomizes a value and joins the string forms of its items with a separator
    /// (used for computed attribute values in element constructors).
    /// </summary>
    private static string JoinAtomizedItems(XdmValue value, string separator)
    {
        if (value.IsUndefined)
            return string.Empty;
        if (!value.IsSequence || value.SequenceValue is null)
        {
            // Function items cannot be atomized (function-item-6: attribute a { avg#1 }).
            if (value.IsFunction)
                throw new InvalidOperationException("FOTY0013: Atomization of a function item is not allowed.");
            // An array in attribute content: its members are joined with single spaces
            // (ArrayTest-050).
            if (value.IsArray && value.ArrayValue is not null)
            {
                var memberParts = new List<string>();
                foreach (var member in value.ArrayValue.Values)
                    memberParts.Add(JoinAtomizedItems(member, separator));
                return string.Join(separator, memberParts);
            }
            return Atomize(value).ToString();
        }
        var items = MaterializeSequence(value);
        if (items.Length == 0)
            return string.Empty;
        var parts = new string[items.Length];
        for (int i = 0; i < items.Length; i++)
        {
            if (items[i].IsFunction)
                throw new InvalidOperationException("FOTY0013: Atomization of a function item is not allowed.");
            parts[i] = Atomize(items[i]).ToString();
        }
        return string.Join(separator, parts);
    }

    /// <summary>
    /// Accumulates computed-constructor content items, applying the XQuery content rules:
    /// attributes only before any other content (XQTY0024), duplicate attribute detection
    /// (XQDY0025), array flattening, and single-space joining of adjacent atomic values.
    /// </summary>
    // Constructor-local namespace bindings (xmlns declarations of enclosing constructors)
    // propagate to a built element; prefixes the element itself declares (xmlns
    // attributes, computed namespace constructors in content, or the tag prefix) are
    // skipped so propagation neither duplicates them nor triggers the name-conflict
    // resolution reserved for real content declarations (K2-DirectConElemNamespace-77).
    private static void AppendConstructorLocalNamespaces(
        List<XdmContentItem> content, IReadOnlyList<XdmAttributeValue> attributes, EvaluationContext context,
        string? tagPrefix, IReadOnlyList<(string Prefix, string Uri)>? lexicalNamespaces = null)
    {
        var declared = new HashSet<string>(StringComparer.Ordinal);
        foreach (var attr in attributes)
        {
            if (attr.Prefix == "xmlns") declared.Add(attr.LocalName);
            else if (attr.LocalName == "xmlns" && attr.Prefix is null) declared.Add("");
        }
        foreach (var item in content)
            if (item.Kind == XdmContentKind.Namespace)
                declared.Add(item.Target ?? "");
        if (tagPrefix is not null)
            declared.Add(tagPrefix);
        foreach (var (prefix, uri) in lexicalNamespaces ?? context.ConstructorLocalNamespaces)
        {
            if (prefix.Length != 0 && uri.Length == 0) continue;
            if (!declared.Contains(prefix))
                content.Add(new XdmContentItem(XdmContentKind.Namespace, uri, null, prefix));
        }
    }

    private static void ApplyConstructionCopyMode(List<XdmContentItem> content, bool preserve, bool inherit, XdmConstructionMode mode)
    {
        for (int i = 0; i < content.Count; i++)
            if (content[i].Kind == XdmContentKind.Node)
                content[i] = content[i] with
                {
                    ConstructionMode = mode,
                    PreserveNamespaces = content[i].IsLiteralElement || preserve,
                    InheritNamespaces = content[i].IsLiteralElement || inherit
                };
    }

    private sealed class ComputedContentAccumulator
    {
        private readonly List<XdmAttributeValue> _attributes = new();
        private readonly HashSet<(string, string)> _seenAttrs = new();
        private readonly List<XdmContentItem> _content = new();
        private string? _pendingAtomic;
        private bool _lastWasAtomic;
        private bool _seenNonAttributeContent;
        private readonly bool _allowAttributes;
        private readonly string? _elementNamespaceUri;

        public ComputedContentAccumulator(bool allowAttributes = true, string? elementNamespaceUri = null)
        {
            _allowAttributes = allowAttributes;
            // Null: not constructing an element (no default-namespace conflict check);
            // empty: the constructed element is in no namespace.
            _elementNamespaceUri = elementNamespaceUri;
        }

        public List<XdmAttributeValue> Attributes => _attributes;
        public List<XdmContentItem> Content => _content;

        public void Add(XdmValue item, EvaluationContext context)
        {
            // A sequence member is flattened item by item (array members are sequences).
            if (item.IsSequence && item.SequenceValue is not null)
            {
                foreach (var inner in XdmSequence.FromSource(item.SequenceValue))
                    Add(inner, context);
                return;
            }
            if (item.IsNode && item.NodeValue.NodeKind == XdmNodeKind.Attribute)
            {
                // Document constructors accept no attributes at all (XPTY0004, XQuery §3.9.1.1);
                // in element content an attribute following other content is XQTY0024.
                if (!_allowAttributes)
                    throw new InvalidOperationException("XPTY0004: An attribute node is not allowed in document constructor content.");
                if (_seenNonAttributeContent)
                    throw new InvalidOperationException("XQTY0024: An attribute node in content must not follow other content.");
                var attrNode = item.NodeValue;
                string? itemNs = string.IsNullOrEmpty(attrNode.NamespaceUri) ? null : attrNode.NamespaceUri;
                if (attrNode.LocalName != "xmlns" && attrNode.Prefix != "xmlns" &&
                    !_seenAttrs.Add((attrNode.LocalName, itemNs ?? "")))
                {
                    throw new InvalidOperationException($"XQDY0025: Duplicate attribute '{attrNode.LocalName}'.");
                }
                _attributes.Add(new XdmAttributeValue(attrNode.LocalName, attrNode.Prefix, itemNs, attrNode.StringValue) { SourceNode = attrNode });
                return;
            }
            if (item.IsNode && item.NodeValue.NodeKind == XdmNodeKind.Namespace)
            {
                // A namespace node in content becomes a namespace declaration (XQDY0102 on
                // conflicting redeclaration of the same prefix). The node's name is the
                // bound prefix (empty for a default declaration); its string value is the URI.
                var nsNode = item.NodeValue;
                string declPrefix = nsNode.LocalName;
                string declUri = nsNode.StringValue;
                if (declPrefix.Length == 0 && _elementNamespaceUri is not null)
                {
                    // Spec bug 22032: a default namespace declaration conflicts with an
                    // element name in no namespace, and an empty-URI undeclaration conflicts
                    // with an element name in a namespace (XQDY0102).
                    if (_elementNamespaceUri.Length == 0 && declUri.Length > 0)
                        throw new InvalidOperationException("XQDY0102: A default namespace declaration must not be added to an element in no namespace.");
                    if (_elementNamespaceUri.Length > 0 && declUri.Length == 0)
                        throw new InvalidOperationException("XQDY0102: The default namespace must not be undeclared on an element in a namespace.");
                }
                if (context.TryResolveNamespace(declPrefix, out var existing) && existing != declUri)
                    throw new InvalidOperationException($"XQDY0102: The namespace prefix '{declPrefix}' is redeclared with a different URI.");
                if (declPrefix.Length == 0 && !string.IsNullOrEmpty(context.DefaultElementNamespace) && context.DefaultElementNamespace != declUri)
                    throw new InvalidOperationException("XQDY0102: The default namespace is redeclared with a different URI.");
                if (declPrefix.Length == 0)
                    context.DefaultElementNamespace = declUri.Length == 0 ? null : declUri;
                else
                    context.WithNamespace(declPrefix, declUri);
                _content.Add(new XdmContentItem(XdmContentKind.Namespace, declUri, null, declPrefix));
                // Namespace declarations are not "other content": they may interleave
                // freely with attributes at the start of the content (no XQTY0024).
                return;
            }
            if (item.IsNode && item.NodeValue.NodeKind is XdmNodeKind.Text)
            {
                // Text nodes merge with adjacent atomic text rather than being copied;
                // no separator is inserted at a text-node boundary.
                var textNodeValue = item.NodeValue.StringValue;
                _pendingAtomic = _pendingAtomic is null ? textNodeValue : _pendingAtomic + textNodeValue;
                _lastWasAtomic = false;
                _seenNonAttributeContent = true;
                return;
            }
            if (item.IsNode)
            {
                Flush();
                _content.Add(new XdmContentItem(XdmContentKind.Node, null, item));
                _seenNonAttributeContent = true;
                return;
            }
            if (item.IsFunction)
            {
                // XQTY0105: element content must not contain function items.
                throw new InvalidOperationException("XQTY0105: Element content must not contain a function item.");
            }
            if (item.IsArray && item.ArrayValue is not null)
            {
                foreach (var member in item.ArrayValue.Values)
                    Add(member, context);
                return;
            }

            // A single space separates two ADJACENT ATOMIC values only.
            var text = item.ToString();
            _pendingAtomic = _pendingAtomic is null ? text : _pendingAtomic + (_lastWasAtomic ? " " : "") + text;
            _lastWasAtomic = true;
            _seenNonAttributeContent = true;
        }

        public void Flush()
        {
            if (_pendingAtomic is not null)
            {
                _content.Add(new XdmContentItem(XdmContentKind.Text, _pendingAtomic));
                _pendingAtomic = null;
                _lastWasAtomic = false;
                _seenNonAttributeContent = true;
            }
        }
    }

    private static (string Local, string? Prefix, string? NamespaceUri) ResolveComputedName(
        ComputedConstructorInfo info, XdmValue nameValue, EvaluationContext context, string construct)
    {
        if (!info.HasNameExpression)
        {
            string? ns = info.NamespaceUri;
            if (ns is null && info.Prefix is not null)
            {
                if (!context.TryResolveNamespace(info.Prefix, out var resolved))
                    throw new InvalidOperationException($"XPST0081: Prefix '{info.Prefix}' is not declared.");
                ns = resolved;
            }
            // An unprefixed computed element name uses the default element namespace
            // (K2-InScopePrefixesFunc-12/13; attribute names never do).
            if (ns is null && construct == "element" && !string.IsNullOrEmpty(context.DefaultElementNamespace))
                ns = context.DefaultElementNamespace;
            return (info.LocalName!, info.Prefix, ns);
        }

        var atomized = Atomize(nameValue);
        if (atomized.IsUndefined)
            throw new InvalidOperationException($"XPTY0004: The computed {construct} name is the empty sequence.");
        if (atomized.Kind == XdmValueKind.QName)
        {
            var qn = atomized.QNameValue;
            var qPrefix = qn.Prefix.Length > 0 ? qn.Prefix : null;
            var qNs = qn.NamespaceUri.Length > 0 ? qn.NamespaceUri : null;
            ValidateComputedNamePrefix(qPrefix, qNs, construct);
            return (qn.LocalName, qPrefix, qNs);
        }

        var text = atomized.ToString().Trim();
        // Only xs:string / xs:untypedAtomic atoms are cast to a lexical QName; any other
        // atomic type (xs:integer, xs:date, xs:dateTime, ...) is a type error (XPTY0004).
        if (atomized.Kind != XdmValueKind.String)
            throw new InvalidOperationException($"XPTY0004: The computed {construct} name must be xs:QName, xs:string, or xs:untypedAtomic, not {atomized.Kind}.");
        // EQName braced form: Q{uri}local (empty URI means no namespace).
        if (text.StartsWith("Q{", StringComparison.Ordinal))
        {
            int closeBrace = text.IndexOf('}');
            if (closeBrace < 0 || closeBrace == text.Length - 1)
                throw new InvalidOperationException($"XQDY0074: Invalid {construct} name '{text}'.");
            var rawUri = text[2..closeBrace];
            // References are expanded by the string literal, not here; a literal
            // '{' can therefore appear in the value and is not permitted in the
            // URI part of the lexical EQName form.
            if (rawUri.Contains('{'))
                throw new InvalidOperationException($"XQDY0074: Invalid {construct} name '{text}'.");
            var uri = NormalizeEQNameUriText(rawUri);
            var local = text[(closeBrace + 1)..];
            if (!IsValidNcName(local))
                throw new InvalidOperationException($"XQDY0074: Invalid {construct} name '{text}'.");
            return (local, null, uri.Length == 0 ? null : uri);
        }

        int colon = text.IndexOf(':');
        if (colon >= 0)
        {
            var prefixPart = text[..colon];
            var localPart = text[(colon + 1)..];
            // The 'xmlns' prefix must not be used, whether or not it is declared
            // (XQDY0044 for attributes, XQDY0096 for elements).
            if (prefixPart == "xmlns")
                throw new InvalidOperationException($"{(construct == "attribute" ? "XQDY0044" : "XQDY0096")}: A computed {construct} name must not use the 'xmlns' prefix.");
            if (!context.TryResolveNamespace(prefixPart, out var pns))
                throw new InvalidOperationException($"XQDY0074: The prefix of the computed {construct} name '{text}' cannot be resolved.");
            if (!IsValidNcName(localPart))
                throw new InvalidOperationException($"XQDY0074: Invalid {construct} name '{text}'.");
            ValidateComputedNamePrefix(prefixPart, pns, construct);
            return (localPart, prefixPart, pns);
        }
        if (!IsValidNcName(text))
            throw new InvalidOperationException($"XQDY0074: Invalid {construct} name '{text}'.");
        // Unprefixed computed element names use the default element namespace; unprefixed
        // computed attribute names do not (currencysvg).
        if (construct == "attribute")
            return (text, null, null);
        return (text, null, string.IsNullOrEmpty(context.DefaultElementNamespace) ? null : context.DefaultElementNamespace);
    }

    // EQName URI normalization: trim and collapse internal whitespace runs to single spaces.
    private static string NormalizeEQNameUriText(string uri)
    {
        var parts = uri.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries);
        return string.Join(' ', parts);
    }

    // XQDY0044 (attributes) / XQDY0096 (elements): computed names must not misuse the xml/xmlns prefixes.
    private static void ValidateComputedNamePrefix(string? prefix, string? namespaceUri, string construct)
    {
        string code = construct == "attribute" ? "XQDY0044" : "XQDY0096";
        if (prefix == "xmlns")
            throw new InvalidOperationException($"{code}: A computed {construct} name must not use the 'xmlns' prefix.");
        if (prefix == "xml" && namespaceUri != "http://www.w3.org/XML/1998/namespace")
            throw new InvalidOperationException($"{code}: The 'xml' prefix in a computed {construct} name must be bound to the XML namespace URI.");
        if (prefix is not (null or "xml") && namespaceUri == "http://www.w3.org/XML/1998/namespace")
            throw new InvalidOperationException($"{code}: A computed {construct} name must not bind a non-'xml' prefix to the XML namespace URI.");
    }

    // Computed PI targets accept only string-like atomic values (xs:string,
    // xs:untypedAtomic, xs:NCName); other types such as xs:anyURI raise XPTY0004.
    private static bool IsValidPiTargetType(XdmValue value)
        => value.Kind == XdmValueKind.String
            && value.SchemaTypeName is null or "string" or "untypedAtomic" or "NCName";

    private static bool IsSupportedOrderByCollation(string collation)
    {
        if (collation == "http://www.w3.org/2005/xpath-functions/collation/codepoint")
            return true;
        if (collation == "http://www.w3.org/2005/xpath-functions/collation/html-ascii-case-insensitive")
            return true;
        if (collation == "http://www.w3.org/2005/xpath-functions/collation/unicode-case-insensitive")
            return true;
        if (collation == "http://www.w3.org/2010/09/qt-fots-catalog/collation/caseblind")
            return true;
        if (collation.StartsWith("http://www.w3.org/2013/collation/UCA", StringComparison.Ordinal))
            return true;
        return false;
    }

    private static bool IsGroupKeySlot(int slot, GroupByInfo info)
    {
        for (int i = 0; i < info.KeyIndices.Count; i++)
        {
            if (info.KeyIndices[i] == slot)
                return true;
        }
        return false;
    }

    private static bool GroupKeysEqual(XdmValue[] x, XdmValue[] y, GroupByInfo info, EvaluationContext context)
    {
        for (int i = 0; i < info.KeyIndices.Count; i++)
        {
            int keyIndex = info.KeyIndices[i];
            var keyX = keyIndex < x.Length ? x[keyIndex] : XdmValue.Undefined;
            var keyY = keyIndex < y.Length ? y[keyIndex] : XdmValue.Undefined;
            var collation = info.CollationUri[i] ?? context.DefaultCollation;
            if (!GroupKeyValuesEqual(keyX, keyY, collation, context))
                return false;
        }
        return true;
    }

    private static bool GroupKeyValuesEqual(XdmValue left, XdmValue right, string? collation, EvaluationContext context)
    {
        left = SingleGroupKeyItem(Atomize(left));
        right = SingleGroupKeyItem(Atomize(right));

        // Two empty grouping keys group together.
        if (left.IsUndefined || right.IsUndefined)
            return left.IsUndefined && right.IsUndefined;

        if (IsNumeric(left) && IsNumeric(right))
        {
            // Double.Equals treats NaN as equal to NaN, as XQuery grouping requires.
            return ToDouble(left).Equals(ToDouble(right));
        }

        // Date/time values group by their instant on the timeline (with implicit
        // timezone), not by lexical form. g* date values are stored as annotated
        // strings, so this check must precede the plain string comparison.
        var leftDateSub = GetDateTimeSubtype(left);
        var rightDateSub = GetDateTimeSubtype(right);
        if (leftDateSub is not null && rightDateSub is not null && leftDateSub == rightDateSub)
        {
            var cmp = CompareDateTimeValues(left, right, leftDateSub, GetImplicitTimezoneOffsetMinutes(context));
            if (cmp.HasValue)
                return cmp.Value == 0;
            return string.Equals(left.ToString(), right.ToString(), StringComparison.Ordinal);
        }

        if (left.Kind == XdmValueKind.String && right.Kind == XdmValueKind.String)
        {
            // Grouping compares strings with the spec collation (or the default collation).
            var effectiveCollation = collation is null ? context.DefaultCollation : ResolveCollationUri(collation, context.BaseUri);
            return CompareStrings(left.StringValue, right.StringValue, effectiveCollation ?? "", context) == 0;
        }

        if (left.Kind == XdmValueKind.Boolean && right.Kind == XdmValueKind.Boolean)
        {
            return left.BooleanValue == right.BooleanValue;
        }

        if (left.Kind == right.Kind)
        {
            return string.Equals(left.ToString(), right.ToString(), StringComparison.Ordinal);
        }

        return false;
    }

    private static XdmValue SingleGroupKeyItem(XdmValue value)
    {
        if (value.IsUndefined)
            return XdmValue.Undefined;
        if (!value.IsSequence || value.SequenceValue is null)
            return value;
        var items = MaterializeSequence(value);
        if (items.Length > 1)
            throw new InvalidOperationException("XPTY0004: A grouping key must evaluate to a single atomic value or the empty sequence.");
        return items.Length == 0 ? XdmValue.Undefined : items[0];
    }

    private static int CompareOrderByValues(XdmValue left, XdmValue right, EmptyOrder emptyOrder, string? collationUri, EvaluationContext context)
    {
        left = Atomize(left);
        right = Atomize(right);

        bool leftEmpty = left.IsUndefined || IsEmptySeq(left);
        bool rightEmpty = right.IsUndefined || IsEmptySeq(right);
        if (leftEmpty || rightEmpty)
        {
            if (leftEmpty && rightEmpty) return 0;
            int emptyRank = emptyOrder == EmptyOrder.Greatest ? 1 : -1;
            return leftEmpty ? emptyRank : -emptyRank;
        }

        if (left.IsSequence) left = FirstItemOrUndefined(left);
        if (right.IsSequence) right = FirstItemOrUndefined(right);

        if (left.IsUndefined || right.IsUndefined)
        {
            if (left.IsUndefined && right.IsUndefined) return 0;
            int emptyRank = emptyOrder == EmptyOrder.Greatest ? 1 : -1;
            return left.IsUndefined ? emptyRank : -emptyRank;
        }

        if (IsNumeric(left) && IsNumeric(right))
        {
            double l = ToDouble(left);
            double r = ToDouble(right);
            // NaN follows the empty-sequence ordering (least/greatest) rather than
            // comparing less than every other value.
            bool leftNaN = double.IsNaN(l);
            bool rightNaN = double.IsNaN(r);
            if (leftNaN || rightNaN)
            {
                if (leftNaN && rightNaN) return 0;
                int nanRank = emptyOrder == EmptyOrder.Greatest ? 1 : -1;
                return leftNaN ? nanRank : -nanRank;
            }
            return l.CompareTo(r);
        }

        // xs:hexBinary / xs:base64Binary (annotated strings) order by their decoded
        // octets; mixing binary types or binary with non-binary is a type error
        // (base64Binary-lt-15/gt-15).
        if (IsBinaryTypedString(left) || IsBinaryTypedString(right))
        {
            if (!IsBinaryTypedString(left) || !IsBinaryTypedString(right)
                || !string.Equals(left.SchemaTypeName, right.SchemaTypeName, StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidOperationException(
                    $"XPTY0004: Cannot compare {left.Kind} with {right.Kind} in an order by clause.");
            }
            return CompareBinaryValues(left, right);
        }

        if (left.Kind == XdmValueKind.String && right.Kind == XdmValueKind.String)
        {
            string effectiveCollation = ResolveCollationUri(collationUri ?? context.DefaultCollation ?? "", context.BaseUri);
            return CompareStrings(left.StringValue, right.StringValue, effectiveCollation, context);
        }

        if (left.Kind == XdmValueKind.Boolean && right.Kind == XdmValueKind.Boolean)
        {
            return left.BooleanValue.CompareTo(right.BooleanValue);
        }

        if (left.Kind == XdmValueKind.Integer && right.Kind == XdmValueKind.Integer)
        {
            return left.IntegerValue.CompareTo(right.IntegerValue);
        }

        // XQuery §3.8.3: values of type xs:untypedAtomic are cast to xs:string for the
        // purposes of order-by comparison (orderBy68).
        if (IsUntypedAtomicValue(left))
            left = XdmValue.FromString(left.StringValue);
        if (IsUntypedAtomicValue(right))
            right = XdmValue.FromString(right.StringValue);

        // Remaining atomic kinds are comparable only within the same type family
        // (xs:string with xs:anyURI; otherwise identical kinds). Cross-family pairs such
        // as xs:string vs xs:date raise XPTY0004 rather than comparing by string form.
        bool sameFamily = left.Kind == right.Kind
            || (left.Kind is XdmValueKind.String or XdmValueKind.Uri
                && right.Kind is XdmValueKind.String or XdmValueKind.Uri);
        if (!sameFamily)
        {
            throw new InvalidOperationException(
                $"XPTY0004: Cannot compare {left.Kind} with {right.Kind} in an order by clause.");
        }

        // Fallback: convert to string and compare.
        return string.CompareOrdinal(left.ToString(), right.ToString());
    }
}
