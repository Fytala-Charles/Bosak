// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 10 October 2026
// PURPOSE              : Opt-in controlled resource policy: one authority, no disk/network fallback, observable receipts (REQ-125 Slice B).
// SPECIAL NOTES        : Part of the Bosak XPath 3.1 implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 10-10-2026     | Creation (REQ-125 Slice B)                                                               |
//                      | Charles Korthout | 0.2   | 10-10-2026     | B-F1: authorization runs before the document cache; B-F2: concrete-route (purpose) pair  |
//                      | Charles Korthout | 0.3   | 10-10-2026     | B-F3: deferred document-cache approval receipts with digest-validated ServedFromCache    |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Security.Cryptography;

namespace Bosak.XPath.Runtime.Resources;

/// <summary>
/// One controlled resource policy: a single host authority (<see cref="IControlledResourceAuthority"/>)
/// consulted by every engine acquisition path, with denial, abstention and callback errors all
/// refusing the acquisition — never falling back to disk or network. The policy is strictly
/// opt-in: when no policy is attached to an <c>EvaluationContext</c> (or XSLT compiler), every
/// code path behaves exactly as before the policy existed.
/// </summary>
/// <remarks>
/// <para><b>Attachment.</b> Set <see cref="Bosak.XPath.Runtime.Vm.EvaluationContext.ResourcePolicy"/>
/// to cover runtime acquisition (fn:doc, document(), unparsed-text and variants, json-doc,
/// collections, xsl:source-document including the streaming path, and — through nested-context
/// inheritance — fn:transform, xsl:evaluate and streaming pipelines). Set
/// <c>Bosak.Xslt.Api.XsltCompiler.ResourcePolicy</c> to cover compile-time acquisition
/// (xsl:include, xsl:import, xsl:use-package packages, xsl:import-schema location hints,
/// compile-time parameter documents and static (use-when) evaluation).</para>
/// <para><b>Route support.</b> Routes the host does not implement are declared unsupported at
/// construction; the engine refuses acquisitions on them with code XV0005 — never silently
/// runnable without controls. <see cref="ControlledResourceRoute.ExtensionFunction"/> is
/// unsupported by default: the engine cannot intercept host-registered functions, so
/// policy-aware hosts must not register IO-capable extension functions under the controlled
/// profile.</para>
/// <para><b>Receipts.</b> Every acquisition attempt appends one immutable
/// <see cref="ControlledResourceReceipt"/> (thread-safe), carrying the credential-stripped
/// requested and effective URIs, the route, the outcome and — for approvals — the byte count
/// and SHA-256 of the exact bytes consumed.</para>
/// <para><b>Purpose vs. concrete route.</b> Acquisitions governed by a phase route — static
/// evaluation via <see cref="ControlledResourceRoute.StaticEvaluation"/> — present that route
/// as the decision route on the request and receipt, together with
/// <see cref="ControlledResourceRequest.ConcreteRoute"/> /
/// <see cref="ControlledResourceReceipt.ConcreteRoute"/> naming the underlying operation
/// (Document, TextResource, JsonResource or Collection). Both routes must be supported; a
/// refusal names the governing route.</para>
/// <para><b>Digest-validated document cache.</b> Document-route approvals consulted through
/// the cache path (<see cref="AcquireBytesForCacheServe"/> /
/// <see cref="RecordCacheServeApproval"/>) defer the approval receipt until the caller has
/// decided whether the approved bytes match its cached entry (SHA-256 and effective URI).
/// A match serves the cached node and marks the receipt
/// <see cref="ControlledResourceReceipt.ServedFromCache"/>; a mismatch parses the fresh bytes
/// and replaces the entry. Receipt and consumed content therefore always agree.</para>
/// <para><b>XML safety.</b> Approved XML bytes are parsed with DTD processing prohibited and
/// no external resolver, so the DTD/entity policy and limits apply to every XML acquisition
/// path, not only the principal stylesheet.</para>
/// </remarks>
public sealed class ControlledResourcePolicy
{
    /// <summary>Stable engine code surfaced when an acquisition is refused (denied, abstained, or the authority failed).</summary>
    public const string RefusedCode = "XV0004";

    /// <summary>Stable engine code surfaced when a route is not supported under the controlled profile.</summary>
    public const string UnsupportedCode = "XV0005";

    private readonly IControlledResourceAuthority _authority;
    private readonly HashSet<ControlledResourceRoute> _unsupportedRoutes;
    private readonly List<ControlledResourceReceipt> _receipts = new();
    private readonly object _receiptLock = new();

    /// <summary>
    /// Initializes a new controlled resource policy.
    /// </summary>
    /// <param name="authority">The host authority deciding every acquisition request. Must not be null.</param>
    /// <param name="unsupportedRoutes">
    /// Additional routes the host declares unsupported; acquisitions on them are refused with
    /// code XV0005. <see cref="ControlledResourceRoute.ExtensionFunction"/> is always treated as
    /// unsupported and needs not be listed.
    /// </param>
    /// <exception cref="ArgumentNullException"><paramref name="authority"/> is null.</exception>
    public ControlledResourcePolicy(
        IControlledResourceAuthority authority,
        IEnumerable<ControlledResourceRoute>? unsupportedRoutes = null)
    {
        _authority = authority ?? throw new ArgumentNullException(nameof(authority));
        _unsupportedRoutes = new HashSet<ControlledResourceRoute> { ControlledResourceRoute.ExtensionFunction };
        if (unsupportedRoutes is not null)
        {
            foreach (var route in unsupportedRoutes)
                _unsupportedRoutes.Add(route);
        }
    }

    /// <summary>Gets the host authority consulted for every acquisition request.</summary>
    public IControlledResourceAuthority Authority => _authority;

    /// <summary>
    /// Gets whether the supplied route is supported under this policy. Unsupported routes are
    /// refused explicitly (code XV0005) — never silently runnable without controls.
    /// </summary>
    /// <param name="route">The route to query.</param>
    /// <returns><c>true</c> when the route is supported; <c>false</c> when acquisitions on it are refused.</returns>
    public bool IsRouteSupported(ControlledResourceRoute route) => !_unsupportedRoutes.Contains(route);

    /// <summary>
    /// Gets the receipts recorded so far, in acquisition order. The returned list is a
    /// snapshot copy; receipt recording is thread-safe, so parallel or nested evaluations do
    /// not corrupt the record (but interleaving order of concurrent acquisitions is not
    /// guaranteed).
    /// </summary>
    public IReadOnlyList<ControlledResourceReceipt> Receipts
    {
        get
        {
            lock (_receiptLock)
                return _receipts.ToArray();
        }
    }

    /// <summary>
    /// Strips embedded credentials (the URI userinfo, for example <c>user:password@</c>) from
    /// an absolute URI so it is safe for diagnostics, receipts and messages. URIs without
    /// userinfo — and anything that does not parse as an absolute URI — are returned unchanged.
    /// </summary>
    /// <param name="uri">The URI to redact.</param>
    /// <returns>The URI with userinfo removed.</returns>
    public static string RedactCredentials(string uri)
    {
        if (string.IsNullOrEmpty(uri))
            return uri;
        if (!Uri.TryCreate(uri, UriKind.Absolute, out var parsed))
            return uri;
        if (string.IsNullOrEmpty(parsed.UserInfo))
            return uri;
        var builder = new UriBuilder(parsed)
        {
            UserName = string.Empty,
            Password = string.Empty,
        };
        return builder.Uri.AbsoluteUri;
    }

    /// <summary>
    /// Acquires the approved bytes for one resource, recording a receipt. Engine-facing: throws
    /// an <see cref="InvalidOperationException"/> carrying code XV0004 (refused: denied,
    /// abstained, approval malformed, or authority error) or XV0005 (route unsupported) when
    /// the acquisition cannot proceed. The caller must not fall back to disk or network.
    /// </summary>
    /// <param name="requestedUri">The resolved (absolute) requested URI.</param>
    /// <param name="route">The route (purpose) of the acquisition.</param>
    /// <param name="effectiveUri">Receives the credential-stripped effective URI to parse the bytes as.</param>
    /// <returns>The approved, authoritative bytes.</returns>
    internal byte[] AcquireBytes(string requestedUri, ControlledResourceRoute route, out string effectiveUri)
        => AcquireBytes(requestedUri, route, null, out effectiveUri);

    /// <summary>
    /// Acquires the approved bytes for one resource where a phase/purpose route governs a
    /// concrete operation (REQ-125 consumer review B-F2): <paramref name="route"/> is the
    /// decision route the authority sees (for example <see cref="ControlledResourceRoute.StaticEvaluation"/>)
    /// and <paramref name="concreteRoute"/> names the underlying operation (for example
    /// <see cref="ControlledResourceRoute.Document"/>). Both must be supported; both are
    /// recorded on the receipt.
    /// </summary>
    /// <param name="requestedUri">The resolved (absolute) requested URI.</param>
    /// <param name="route">The route (purpose) of the acquisition.</param>
    /// <param name="concreteRoute">The concrete operation behind <paramref name="route"/>; null when none.</param>
    /// <param name="effectiveUri">Receives the credential-stripped effective URI to parse the bytes as.</param>
    /// <returns>The approved, authoritative bytes.</returns>
    internal byte[] AcquireBytes(string requestedUri, ControlledResourceRoute route, ControlledResourceRoute? concreteRoute, out string effectiveUri)
    {
        var approval = Authorize(requestedUri, route, concreteRoute);
        if (approval.Bytes is not { } bytes)
            throw Refusal(route, concreteRoute, requestedUri, approval.EffectiveUri, "approval did not supply resource bytes");
        effectiveUri = RedactCredentials(approval.EffectiveUri ?? requestedUri);
        Record(route, concreteRoute, requestedUri, effectiveUri, ControlledResourceReceiptOutcome.Approved,
            byteCount: bytes.Length, sha256: ToSha256Hex(bytes), message: null);
        return bytes;
    }

    /// <summary>
    /// Document-cache acquisition path (REQ-125 consumer review B-F3): runs the full policy
    /// decision — unsupported-route check plus authority consult, refusal receipts included —
    /// and returns the approved bytes with their evidence, but DEFERS the approval receipt
    /// to <see cref="RecordCacheServeApproval"/>. The caller decides, by digest comparison
    /// against its cache, whether the bytes are served from cache or parsed fresh, and records
    /// the approval only then, so the receipt truthfully describes the content actually
    /// consumed (see <see cref="ControlledResourceReceipt.ServedFromCache"/>).
    /// </summary>
    /// <param name="requestedUri">The resolved (absolute) requested URI.</param>
    /// <param name="route">The route (purpose) of the acquisition.</param>
    /// <param name="concreteRoute">The concrete operation behind <paramref name="route"/>; null when none.</param>
    /// <param name="effectiveUri">Receives the credential-stripped effective URI.</param>
    /// <param name="byteCount">Receives the approved byte count.</param>
    /// <param name="sha256">Receives the lowercase hex SHA-256 of the approved bytes.</param>
    /// <returns>The approved, authoritative bytes.</returns>
    internal byte[] AcquireBytesForCacheServe(
        string requestedUri,
        ControlledResourceRoute route,
        ControlledResourceRoute? concreteRoute,
        out string effectiveUri,
        out long byteCount,
        out string sha256)
    {
        var approval = Authorize(requestedUri, route, concreteRoute);
        if (approval.Bytes is not { } bytes)
            throw Refusal(route, concreteRoute, requestedUri, approval.EffectiveUri, "approval did not supply resource bytes");
        effectiveUri = RedactCredentials(approval.EffectiveUri ?? requestedUri);
        byteCount = bytes.Length;
        sha256 = ToSha256Hex(bytes);
        return bytes;
    }

    /// <summary>
    /// Records the deferred approval receipt for a document-cache acquisition performed via
    /// <see cref="AcquireBytesForCacheServe"/>. <paramref name="servedFromCache"/> is <c>true</c>
    /// only when the caller served a cached node whose stored digest and effective URI match
    /// the approved bytes exactly.
    /// </summary>
    /// <param name="requestedUri">The resolved (absolute) requested URI.</param>
    /// <param name="route">The route (purpose) of the acquisition.</param>
    /// <param name="concreteRoute">The concrete operation behind <paramref name="route"/>; null when none.</param>
    /// <param name="effectiveUri">The credential-stripped effective URI.</param>
    /// <param name="byteCount">The approved byte count.</param>
    /// <param name="sha256">The lowercase hex SHA-256 of the approved bytes.</param>
    /// <param name="servedFromCache">Whether the approved content was served from the digest-validated cache.</param>
    internal void RecordCacheServeApproval(
        string requestedUri,
        ControlledResourceRoute route,
        ControlledResourceRoute? concreteRoute,
        string effectiveUri,
        long byteCount,
        string sha256,
        bool servedFromCache)
        => Record(route, concreteRoute, requestedUri, effectiveUri, ControlledResourceReceiptOutcome.Approved,
            byteCount, sha256, message: null, servedFromCache: servedFromCache);

    /// <summary>
    /// Acquires the approved member URIs of a collection, recording a receipt. Every member is
    /// authorized separately (tagged <see cref="ControlledResourceRoute.Collection"/>) before it
    /// is loaded. Engine-facing: throws with code XV0004/XV0005 on refusal; the caller must not
    /// fall back to directory enumeration or host hooks.
    /// </summary>
    /// <param name="requestedUri">The resolved (absolute) collection URI (empty for the default collection).</param>
    /// <param name="effectiveUri">Receives the credential-stripped effective collection URI.</param>
    /// <returns>The approved member URIs, in collection order.</returns>
    internal IReadOnlyList<string> AcquireCollectionMembers(string requestedUri, out string effectiveUri)
        => AcquireCollectionMembers(requestedUri, ControlledResourceRoute.Collection, null, out effectiveUri);

    /// <summary>
    /// Acquires the approved member URIs of a collection where a phase/purpose route governs
    /// the concrete collection operation; see the byte-acquiring overload for the contract.
    /// </summary>
    /// <param name="requestedUri">The resolved (absolute) collection URI (empty for the default collection).</param>
    /// <param name="route">The route (purpose) of the acquisition.</param>
    /// <param name="concreteRoute">The concrete operation behind <paramref name="route"/>; null when none.</param>
    /// <param name="effectiveUri">Receives the credential-stripped effective collection URI.</param>
    /// <returns>The approved member URIs, in collection order.</returns>
    internal IReadOnlyList<string> AcquireCollectionMembers(string requestedUri, ControlledResourceRoute route, ControlledResourceRoute? concreteRoute, out string effectiveUri)
    {
        var approval = Authorize(requestedUri, route, concreteRoute);
        if (approval.CollectionMembers is not { } members)
            throw Refusal(route, concreteRoute, requestedUri, approval.EffectiveUri,
                "approval did not supply collection members");
        effectiveUri = RedactCredentials(approval.EffectiveUri ?? requestedUri);
        Record(route, concreteRoute, requestedUri, effectiveUri,
            ControlledResourceReceiptOutcome.Approved, byteCount: null, sha256: null, message: null);
        return members;
    }

    /// <summary>
    /// Consults the authority for one request, classifying abstention and callback errors as
    /// refusals (controlled profile: abstain = deny). Records the corresponding receipt.
    /// Both the governing route and the concrete route (when supplied) must be supported.
    /// </summary>
    private ControlledResourceResponse Authorize(string requestedUri, ControlledResourceRoute route, ControlledResourceRoute? concreteRoute)
    {
        if (_unsupportedRoutes.Contains(route) || (concreteRoute.HasValue && _unsupportedRoutes.Contains(concreteRoute.Value)))
        {
            Record(route, concreteRoute, requestedUri, null, ControlledResourceReceiptOutcome.RefusedUnsupported,
                message: UnsupportedCode);
            throw new InvalidOperationException(
                $"{UnsupportedCode}: Controlled resource route '{route}' is not supported under the controlled profile: {RedactCredentials(requestedUri)}");
        }

        var request = new ControlledResourceRequest(route, requestedUri, concreteRoute);
        ControlledResourceResponse? response;
        try
        {
            response = _authority.Authorize(request);
        }
        catch (Exception ex)
        {
            Record(route, concreteRoute, requestedUri, null, ControlledResourceReceiptOutcome.AuthorityError, message: ex.GetType().Name);
            throw new InvalidOperationException(
                $"{RefusedCode}: Controlled resource authority failed for '{route}' ({request.RedactedUri}): {ex.GetType().Name}",
                ex);
        }

        if (response is null)
        {
            Record(route, concreteRoute, requestedUri, null, ControlledResourceReceiptOutcome.RefusedNoApproval, message: RefusedCode);
            throw new InvalidOperationException(
                $"{RefusedCode}: Controlled resource refused for '{route}' (no authority approval): {request.RedactedUri}");
        }

        if (response.IsDenied)
        {
            Record(route, concreteRoute, requestedUri, null, ControlledResourceReceiptOutcome.Denied, message: response.DenyReason);
            var reason = string.IsNullOrEmpty(response.DenyReason) ? string.Empty : $": {response.DenyReason}";
            throw new InvalidOperationException(
                $"{RefusedCode}: Controlled resource denied for '{route}': {request.RedactedUri}{reason}");
        }

        return response;
    }

    private InvalidOperationException Refusal(ControlledResourceRoute route, ControlledResourceRoute? concreteRoute, string requestedUri, string? effectiveUri, string detail)
    {
        var redacted = RedactCredentials(effectiveUri ?? requestedUri);
        Record(route, concreteRoute, requestedUri, redacted, ControlledResourceReceiptOutcome.Denied, message: detail);
        return new InvalidOperationException(
            $"{RefusedCode}: Controlled resource refused for '{route}' ({detail}): {redacted}");
    }

    private void Record(
        ControlledResourceRoute route,
        ControlledResourceRoute? concreteRoute,
        string requestedUri,
        string? effectiveUri,
        ControlledResourceReceiptOutcome outcome,
        long? byteCount = null,
        string? sha256 = null,
        string? message = null,
        bool servedFromCache = false)
    {
        var receipt = new ControlledResourceReceipt(
            route,
            RedactCredentials(requestedUri),
            effectiveUri is null ? null : RedactCredentials(effectiveUri),
            outcome,
            concreteRoute,
            byteCount,
            sha256,
            message,
            servedFromCache);
        lock (_receiptLock)
            _receipts.Add(receipt);
    }

    private static string ToSha256Hex(byte[] bytes) => Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
}
