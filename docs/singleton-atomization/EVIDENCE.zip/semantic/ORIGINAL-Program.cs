// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 16 November 2026
// PURPOSE              : Compares qualified singleton atomization with a bounded no-buffer prototype
// SPECIAL NOTES        : Unit tests verifying correctness of the underlying implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 16-11-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 16-11-2026     | Fix private-type fixture access and tuple member; guard logging allocation             |
// ===========================================================================================================================================================
using System.Reflection;
using System.Text.Json;
using System.Xml.Linq;
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Providers.Xml;
using Bosak.XPath.Runtime.Vm;

internal static class Program
{
    /// <summary>Runs the engine-bearing probe inside a catch boundary.</summary>
    /// <returns>Zero for success, otherwise two.</returns>
    public static int Main() { try { var t=typeof(Program).Assembly.GetType("Probe",true)!; Console.WriteLine(JsonSerializer.Serialize(t.GetMethod("Run")!.Invoke(null,null))); return 0; } catch(Exception e) { Console.Error.WriteLine(e); return 2; } }
}
internal static class Probe
{
    private static readonly Func<XdmValue,XdmValue> Baseline=Assembly.Load("Bosak.XPath.Runtime").GetType("Bosak.XPath.Runtime.Vm.VmEngine",true)!.GetMethod("Atomize",BindingFlags.Static|BindingFlags.NonPublic)!.CreateDelegate<Func<XdmValue,XdmValue>>();
    private static readonly Type Materialized=typeof(XdmValue).Assembly.GetType("Bosak.XPath.Core.Xdm.MaterializedSequence",true)!;
    private static XdmValue Sink;
    private static XdmValue Candidate(XdmValue value)
    {
        if(!value.IsSequence || value.SequenceValue is null || Materialized.IsInstanceOfType(value.SequenceValue)) return Baseline(value);
        int count=0;XdmValue first=default;
        foreach(var item in XdmSequence.FromSource(value.SequenceValue)) { if(count==0)first=item;count=checked(count+1); }
        if(count==0)return XdmValue.Undefined;
        if(count==1)return Candidate(first);
        throw new InvalidOperationException("XPTY0004: Atomization requires a singleton or empty sequence, but got a sequence of length "+count);
    }
    private static object Outcome(Func<XdmValue,XdmValue> call,XdmValue value)
    {
        try {var v=call(value);return new {kind=v.Kind.ToString(),text=v.ToString(),schema=v.SchemaTypeName,error=""};}
        catch(Exception e) {return new {kind="",text="",schema=(string?)null,error=e.GetType().FullName+":"+e.Message};}
    }
    /// <summary>Runs differential behavior controls and fixed allocation rows.</summary>
    /// <returns>The complete local diagnostic results.</returns>
    public static object Run()
    {
        var cases=new List<object>();
        void Compare(string name,Func<(XdmValue value,Source? source)> fixture,bool twice=false)
        {
            var left=fixture();var right=fixture();var a=Outcome(Baseline,left.value);var b=Outcome(Candidate,right.value);
            if(JsonSerializer.Serialize(a)!=JsonSerializer.Serialize(b) || JsonSerializer.Serialize(left.source?.Events)!=JsonSerializer.Serialize(right.source?.Events))throw new Exception("Mismatch "+name);
            if(twice) {a=Outcome(Baseline,left.value);b=Outcome(Candidate,right.value);if(JsonSerializer.Serialize(a)!=JsonSerializer.Serialize(b)||JsonSerializer.Serialize(left.source?.Events)!=JsonSerializer.Serialize(right.source?.Events))throw new Exception("Replay mismatch "+name);}
            cases.Add(new{name,result=a,events=left.source?.Events});
        }
        var values=new[]{XdmValue.Undefined,XdmValue.FromInteger(9),XdmValue.FromString("hello"),XdmValue.FromString("7","untypedAtomic"),XdmValue.FromNode(new XDocumentNode(new XElement("a","9"))),XdmValue.FromArray(new XdmArray()),XdmValue.FromArray(new XdmArray(new[]{XdmValue.FromInteger(7)})),XdmValue.FromArray(new XdmArray(new[]{XdmValue.FromInteger(7),XdmValue.FromInteger(8)})),XdmValue.FromMap(new XdmMap())};
        for(int i=0;i<values.Length;i++) {int k=i;Compare("scalar/"+i,()=> (values[k],null));Compare("lazy-single/"+i,()=>Make(new[]{values[k]}));Compare("materialized/"+i,()=> (XdmValue.FromSequence(Materialized.GetMethod("FromList")!.Invoke(null,new object[]{new[]{values[k]}}) is XdmSequence materialized ? materialized : throw new Exception("fixture")),null));}
        foreach(int n in new[]{0,1,2,5})foreach(string fault in new[]{"none","acquire","null","move0","moveEnd","current0","currentLast"})foreach(bool marked in new[]{false,true})
        {int size=n;string mode=fault;bool mark=marked;Compare($"source/{n}/{fault}/{marked}",()=>Make(Enumerable.Repeat(XdmValue.FromInteger(7),size).ToArray(),mode,mark),true);}
        Compare("nested-single",()=>Make(new[]{XdmValue.FromSequence(XdmSequence.Singleton(XdmValue.FromInteger(3)))}));
        var rows=new List<object>();
        foreach(int n in new[]{0,1,2})foreach(bool candidate in new[]{false,true})
        {
            var input=Make(Enumerable.Repeat(XdmValue.FromInteger(7),n).ToArray(),"none",false,false).Item1;Func<XdmValue,XdmValue> call=candidate?Candidate:Baseline;
            // Error creation dominates multi-item rows; retain them as semantic controls only.
            if(n>1)continue;
            for(int i=0;i<10000;i++)Sink=call(input);
            long before=GC.GetAllocatedBytesForCurrentThread();for(int i=0;i<100000;i++)Sink=call(input);long bytes=GC.GetAllocatedBytesForCurrentThread()-before;
            rows.Add(new{name=(candidate?"prototype":"baseline")+"/lazy/"+n,bytes,bytesPerCall=bytes/100000.0});
        }
        return new {success=true,engine=Assembly.Load("Bosak.XPath.Runtime").GetType("Bosak.XPath.Runtime.Vm.VmEngine",true)!.Assembly.GetName().Version!.ToString(),comparisonCases=cases.Count,cases,warmup=10000,iterations=100000,rows};
    }
    private static (XdmValue,Source) Make(XdmValue[] items,string fault="none",bool marked=false,bool log=true)
    {Source s=marked?new Marked(items,fault,log):new Source(items,fault,log);return(XdmValue.FromSequence(XdmSequence.FromSource(s)),s);}
    private class Source : IXdmSequence
    {
        internal readonly XdmValue[] Items;internal readonly string Fault;internal readonly bool Log;internal readonly List<string> Events=new();internal int Acquired;
        internal Source(XdmValue[] items,string fault,bool log) {Items=items;Fault=fault;Log=log;}
        internal void Event(string s) {if(Log)Events.Add(s);}
        /// <inheritdoc/>
        public bool TryGetLength(out int length) {throw new Exception("Unexpected length query");}
        /// <inheritdoc/>
        public IXdmSequenceEnumerator GetEnumerator() {Event("acquire");if(this is Marked && Interlocked.Increment(ref Acquired)>1)throw new InvalidOperationException("single-pass");if(Fault=="acquire")throw new InvalidOperationException("acquire");return Fault=="null"?null!:new Cursor(this);}
    }
    private sealed class Marked : Source,ISinglePassSequence {internal Marked(XdmValue[] items,string fault,bool log):base(items,fault,log) {}}
    private sealed class Cursor : IXdmSequenceEnumerator,IDisposable
    {
        private readonly Source S;private int I=-1;internal Cursor(Source s){S=s;}
        /// <inheritdoc/>
        public XdmValue Current { get {if(S.Log)S.Event("current/"+I);if(S.Fault=="current0"&&I==0 || S.Fault=="currentLast"&&I==S.Items.Length-1)throw new InvalidOperationException("current/"+I);return S.Items[I];} }
        /// <inheritdoc/>
        public bool MoveNext() {I++;if(S.Log)S.Event("move/"+I);if(S.Fault=="move0"&&I==0 || S.Fault=="moveEnd"&&I==S.Items.Length)throw new InvalidOperationException("move/"+I);return I<S.Items.Length;}
        /// <inheritdoc/>
        public void Dispose(){S.Event("dispose");}
    }
}
