from pathlib import Path
import json,os,sys,importlib.util,subprocess,hashlib
R=Path('D:/Development/Bosak');P=Path(__file__).resolve().parent
phase=sys.argv[1];attempt=sys.argv[2] if len(sys.argv)>2 else '';assert phase in ['normal','offline'];profile=P/('profile' if phase=='normal' else 'profile-offline');extensions=P/('extensions' if phase=='normal' else 'extensions-offline')
settings=profile/'User/settings.json';settings.parent.mkdir(parents=True,exist_ok=True);settings.write_text(json.dumps({'update.mode':'none','extensions.autoUpdate':False,'extensions.autoCheckUpdates':False,'telemetry.telemetryLevel':'off','security.workspace.trust.enabled':False,'workbench.startupEditor':'none','editor.snippetSuggestions':'top'}),encoding='utf-8')
args=['--user-data-dir='+str(profile),'--extensions-dir='+str(extensions),'--extensionDevelopmentPath='+str(P/'harness'),'--extensionTestsPath='+str(P/'harness/test.cjs'),'--skip-welcome','--skip-release-notes','--disable-workspace-trust','--disable-gpu','--new-window']
launcher=P/('launch-'+phase+attempt+'.ps1');quoted=', '.join("'"+x.replace("'","''")+"'" for x in args)
launcher.write_text("$ErrorActionPreference='Stop'\nRemove-Item Env:ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue\n$env:BOSAK_SNIPPET_PHASE='"+phase+"'\n$process=Start-Process -FilePath 'C:/Program Files/Microsoft VS Code/Code.exe' -ArgumentList @("+quoted+") -WindowStyle Hidden -PassThru -Wait\nexit $process.ExitCode\n",encoding='utf-8')
spec=importlib.util.spec_from_file_location('m',R/'.guard-tmp/allocation-refresh17-20261116/measure.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);support=m.module('support',m.R/'tools/xslt30_stack_profile.py')
receipt=support.bounded(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(launcher)],P,P/('EDITOR-LAUNCH-'+phase+attempt),150)
assert receipt['success'],'Retain failed editor receipt before changes/retry'
result=json.loads((P/('EDITOR-'+phase+'.json')).read_bytes());assert result['success'] and len(result['cases'])==5
print('Actual VS Code editor checks passed:',phase,len(result['cases']))
