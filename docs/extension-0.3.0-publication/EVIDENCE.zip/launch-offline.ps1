$ErrorActionPreference='Stop'
Remove-Item Env:ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue
$env:BOSAK_SNIPPET_PHASE='offline'
$process=Start-Process -FilePath 'C:/Program Files/Microsoft VS Code/Code.exe' -ArgumentList @('--user-data-dir=D:\Development\Bosak\.guard-tmp\extension-snippets-release-20261116\profile-offline', '--extensions-dir=D:\Development\Bosak\.guard-tmp\extension-snippets-release-20261116\extensions-offline', '--extensionDevelopmentPath=D:\Development\Bosak\.guard-tmp\extension-snippets-release-20261116\harness', '--extensionTestsPath=D:\Development\Bosak\.guard-tmp\extension-snippets-release-20261116\harness\test.cjs', '--skip-welcome', '--skip-release-notes', '--disable-workspace-trust', '--disable-gpu', '--new-window') -WindowStyle Hidden -PassThru -Wait
exit $process.ExitCode
