from pathlib import Path
import urllib.request,json,hashlib,time,datetime
P=Path(__file__).resolve().parent
for attempt in range(40):
 request=urllib.request.Request('https://marketplace.visualstudio.com/_apis/public/gallery/extensionquery?observation='+str(time.time_ns()),data=json.dumps({'filters':[{'criteria':[{'filterType':7,'value':'fytala.vscode-bosak'}]}],'flags':3}).encode(),headers={'Content-Type':'application/json','Accept':'application/json;api-version=7.2-preview.1'})
 with urllib.request.urlopen(request,timeout=30) as response:market=json.load(response)
 (P/f'marketplace-query-{attempt+1:02}.json').write_text(json.dumps(market,indent=2),encoding='utf-8')
 versions=[v for r in market['results'] for e in r.get('extensions',[]) for v in e.get('versions',[]) if v['version']=='0.3.0']
 if versions:
  url=next(f['source'] for f in versions[0]['files'] if f['assetType']=='Microsoft.VisualStudio.Services.VSIXPackage')
  with urllib.request.urlopen(url,timeout=60) as response:payload=response.read()
  (P/'marketplace-vscode-bosak-0.3.0.vsix').write_bytes(payload)
  approved=(P/'artifacts/vscode-bosak-0.3.0.vsix').read_bytes();assert payload==approved,'Marketplace bytes differ from approved VSIX'
  (P/'MARKETPLACE-VERIFICATION.json').write_text(json.dumps(dict(success=True,version='0.3.0',listed=True,url=url,sha256=hashlib.sha256(payload).hexdigest(),byteIdentical=True,observedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n',encoding='utf-8');print('Marketplace 0.3.0 listed; downloaded VSIX byte-identical.');break
 print('Marketplace version not yet visible',attempt+1,flush=True);time.sleep(45)
else:raise RuntimeError('Marketplace propagation verification timed out')
