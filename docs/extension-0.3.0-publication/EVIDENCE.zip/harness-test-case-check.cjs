const vscode = require('vscode');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const packet = path.resolve(__dirname, '..');
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
exports.run = async () => {
 const phase = process.env.BOSAK_SNIPPET_PHASE || 'normal';
 const rows = [];
 try {
  const extension = vscode.extensions.getExtension('fytala.vscode-bosak');
  assert.ok(extension, 'installed extension missing');
  assert.equal(extension.packageJSON.version, '0.3.0');
  assert.ok(extension.extensionPath.startsWith(packet), 'owner extension directory must not be used');
  assert.equal(extension.packageJSON.contributes.snippets.length, 3);
  if (phase === 'offline') assert.ok(!fs.existsSync(path.join(extension.extensionPath, 'server')), 'offline control must have no bundled server');
  const command = (name, args) => vscode.commands.executeCommand(name, args);
  const selected = editor => editor.document.getText(editor.selection);
  async function open(language, content = '') {
   await command('leaveSnippet');
   const document = await vscode.workspace.openTextDocument({language, content});
   return vscode.window.showTextDocument(document, {preview:false});
  }
  let editor = await open('xpath');
  await command('editor.action.insertSnippet', {langId:'xpath', name:'For expression'});
  assert.equal(editor.document.getText(), 'for $item in (1, 2, 3) return $item');
  assert.equal(selected(editor), 'item');
  await command('type', {text:'entry'});
  assert.equal(editor.document.getText(), 'for $entry in (1, 2, 3) return $entry');
  await command('jumpToNextSnippetPlaceholder');
  assert.equal(selected(editor), '1, 2, 3');
  await command('jumpToPrevSnippetPlaceholder');
  assert.equal(selected(editor), 'entry');
  await command('jumpToNextSnippetPlaceholder');
  await command('type', {text:'7, 8'});
  await command('jumpToNextSnippetPlaceholder');
  assert.ok(editor.selection.isEmpty);
  assert.equal(editor.document.offsetAt(editor.selection.active), editor.document.getText().length);
  assert.equal(editor.document.getText(), 'for $entry in (7, 8) return $entry');
  rows.push({case:'xpath registered insertion, linked edit, forward/backward stops, final cursor',text:editor.document.getText()});

  editor = await open('xquery');
  await command('editor.action.insertSnippet', {langId:'xquery', name:'FLWOR'});
  assert.equal(selected(editor), 'item');
  await command('type', {text:'entry'});
  await command('jumpToNextSnippetPlaceholder');
  await command('jumpToNextSnippetPlaceholder');
  assert.equal(selected(editor), 'value');
  await command('type', {text:'amount'});
  assert.match(editor.document.getText(), /let \$amount := \$entry/);
  assert.match(editor.document.getText(), /where \$amount gt 0/);
  assert.match(editor.document.getText(), /order by \$amount/);
  assert.match(editor.document.getText(), /return \$amount/);
  rows.push({case:'xquery registration and all dollar-prefixed mirrors',text:editor.document.getText()});

  editor = await open('xslt');
  await command('editor.action.insertSnippet', {langId:'xslt', name:'XSLT stylesheet'});
  assert.equal(selected(editor), '<result/>');
  await command('type', {text:'<output/>'});
  await command('jumpToNextSnippetPlaceholder');
  assert.ok(editor.selection.isEmpty);
  assert.equal(editor.document.offsetAt(editor.selection.active), editor.document.getText().length);
  assert.match(editor.document.getText(), /xmlns:xs="http:\/\/www.w3.org\/2001\/XMLSchema"/);
  assert.match(editor.document.getText(), /<output\/>/);
  rows.push({case:'xslt stylesheet registration, replacement and final cursor',text:editor.document.getText()});

  editor = await open('xslt', '<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:local="urn:local">\n\n</xsl:stylesheet>');
  editor.selection = new vscode.Selection(1,0,1,0);
  await command('editor.action.insertSnippet', {langId:'xslt', name:'Function'});
  await command('type', {text:'echo'});
  await command('jumpToNextSnippetPlaceholder');
  assert.equal(selected(editor), 'value');
  await command('type', {text:'argument'});
  assert.match(editor.document.getText(), /name="local:echo"/);
  assert.match(editor.document.getText(), /name="argument"/);
  assert.match(editor.document.getText(), /select="\$argument"/);
  rows.push({case:'xslt function namespace and literal-dollar mirror',text:editor.document.getText()});

  editor = await open('xpath');
  await command('type', {text:'bosak-map'});
  await command('editor.action.triggerSuggest');
  await wait(1500);
  await command('acceptSelectedSuggestion');
  assert.equal(editor.document.getText(), "map { 'key': 1 }");
  assert.equal(selected(editor), 'key');
  rows.push({case:'xpath prefix suggestion acceptance',text:editor.document.getText()});
  await command('leaveSnippet');
  fs.writeFileSync(path.join(packet, 'EDITOR-'+phase+'.json'), JSON.stringify({success:true,phase,vscodeVersion:vscode.version,extensionVersion:extension.packageJSON.version,extensionPath:extension.extensionPath,automatedEditorCommands:true,humanVisualAcceptance:false,cases:rows},null,2)+'\n');
 } catch (error) {
  fs.writeFileSync(path.join(packet, 'EDITOR-'+phase+'.json'), JSON.stringify({success:false,phase,cases:rows,error:String(error),stack:error.stack},null,2)+'\n');
  throw error;
 }
};
