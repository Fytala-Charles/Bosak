from pathlib import Path
import json,hashlib,zipfile,shutil
P=Path(__file__).resolve().parent;W=Path('D:/Development/Bosak/.worktrees/Bosak.SnippetRelease');D=W/'docs/extension-0.3.0-publication'
read=lambda p:json.loads(p.read_bytes())
assert read(P/'PUBLISHER.json')['conclusion']=='success'
assert read(P/'MARKETPLACE-VERIFICATION.json')['byteIdentical']
for f in ['EDITOR-normal.json','EDITOR-offline.json']:assert read(P/f)['success'] and len(read(P/f)['cases'])==5
D.mkdir(exist_ok=True)
for f in ['PREPARATION.json','PUBLISHER.json','MARKETPLACE-VERIFICATION.json','PR-CI.json','PR-SCHEMA.json','PR-STANDALONE.json','PR-MERGED.json','ARTIFACT-REVIEW.json','INSTALLED-PAYLOAD-VERIFICATION.json','EDITOR-normal.json','EDITOR-offline.json','EDITOR-LAUNCH-normal.json','EDITOR-LAUNCH-normal-electron-fixed.json','EDITOR-normal-case-check-failure.json','EDITOR-LAUNCH-normal-path-fixed.json','EDITOR-LAUNCH-offline.json','GITHUB-RELEASE.json']:
 shutil.copy2(P/f,D/f)
shutil.copy2(P/'artifacts/release-manifest.json',D/'RELEASE-MANIFEST.json')
with zipfile.ZipFile(D/'EVIDENCE.zip','w',zipfile.ZIP_DEFLATED) as z:
 for folder in ['harness']:
  for f in (P/folder).rglob('*'):
   if f.is_file():z.write(f,f.relative_to(P).as_posix())
 for pattern in ['marketplace-query-*.json','*.py','launch-*.ps1','harness-test-case-check.cjs','ARTIFACT-VERIFY.log']:
  for f in P.glob(pattern):z.write(f,f.name)
text='''# VS Code extension 0.3.0 publication — 16 November 2026

Extension **0.3.0** is published on the [Marketplace](https://marketplace.visualstudio.com/items?itemName=fytala.vscode-bosak), adding 20 snippets for XPath 3.1, XQuery 3.1 and XSLT 3.0. [User guide](../VSCODE_SNIPPETS.md).

All six exact-head PR checks passed before [PR #501](https://github.com/Fytala-Charles/Bosak/pull/501) merged at `046493f1d472968276f36c36d52d356630553718`. The original feature source and tag `vscode-v0.3.0` identify `1dbfbc34d4dd3c7844d399ac67aaf6a706c4301e`. Core/server remains 1.81.17; no engine source or public API changes, new NuGet packages or Core tag movement.

Hosted preparation [43883918663](https://github.com/Fytala-Charles/Bosak/actions/runs/43883918663) passed compilation, highlighting, launch/snippet controls and 111 language-server tests. The exact reviewed manifest SHA-256 is `32dcfde6954ad34048aec0f1a40166fd2e48a20ac4052cf2d56eb879ada0807d`. The VSIX is 4,810,616 bytes, SHA-256 `25216ff6067e585c3966bfec34901c173533678b6f027f286dc5219be0ca661e`.

An isolated VS Code 1.146.0 profile installed that hosted VSIX. All 295 installed payload files match, apart from installer package metadata. Five automated editor scenarios passed in both normal and server-unavailable profiles: registered XPath insertion/linked edit/forward-backward navigation/final cursor; XQuery dollar-prefixed mirrors; XSLT stylesheet insertion and final cursor; XSLT function parameter mirrors; actual prefix suggestion acceptance. The offline control moved only its isolated installed server directory. Owner profiles/extensions were untouched. This is actual editor-command automation, not human visual, accessibility or all-version acceptance.

Initial harness launches retained two setup failures: inherited ELECTRON_RUN_AS_NODE caused exit 9 before tests, then a case-sensitive drive-letter containment check refused the valid isolated installation. The corrected launcher changes only its child environment; normalized path containment retains workspace confinement. No product or VSIX changes were needed.

Publisher [43891666461](https://github.com/Fytala-Charles/Bosak/actions/runs/43891666461) verified and reused the same VSIX without rebuilding. A fresh Marketplace query lists 0.3.0 and the public download is byte-identical. The [extension GitHub release](https://github.com/Fytala-Charles/Bosak/releases/tag/vscode-v0.3.0) attaches that same VSIX; asset digest verified. Tag-triggered preparation is a separate validation artifact and was not used by the publisher.

Original local qualification remains in [the candidate dossier](../vscode-snippets/README.md): 26,488 solution tests plus 111 language-server tests, including 21 snippet expansions. Original fixture/test-expectation corrections remain unchanged there. This publication does not expand language, schema/provider or performance claims.

The immutable VSIX README retains its preparation-time development wording. Current repository documentation and the user guide reflect public delivery; the package was not rebuilt to change text. Raw VSIX files remain in the ignored local packet; JSON receipts and source-only EVIDENCE.zip retain verification. Run `python docs/extension-0.3.0-publication/verify.py` for offline evidence checks without launching the editor or publishing.
'''
(D/'README.md').write_text(text,encoding='utf-8')
guide=(W/'docs/vscode-snippets/README.md').read_text(encoding='utf-8').split('## Qualification')[0];guide=guide.replace('The development extension 0.3.0 adds 20 snippets for the existing XPath 3.1, XQuery 3.1 and XSLT 3.0 profiles. Marketplace 0.2.7 does not include this collection yet.','Extension **0.3.0** provides 20 snippets for XPath 3.1, XQuery 3.1 and XSLT 3.0. Install or update [Bosak XPath / XSLT](https://marketplace.visualstudio.com/items?itemName=fytala.vscode-bosak) in VS Code.');guide+='Validation and exact release identities are recorded in the [publication receipt](extension-0.3.0-publication/README.md).\n';(W/'docs/VSCODE_SNIPPETS.md').write_text(guide,encoding='utf-8')
def replace(file,old,new):
 p=W/file;b=p.read_bytes();assert old.encode() in b,file;p.write_bytes(b.replace(old.encode(),new.encode(),1))
replace('README.md','VS Code extension [0.2.7](docs/extension-0.2.7-publication/README.md) bundles engine/server 1.81.17.','VS Code extension [0.3.0](docs/extension-0.3.0-publication/README.md) bundles engine/server 1.81.17 and includes language snippets.')
replace('README.md','[Editor snippets](docs/vscode-snippets/README.md) | Development collection, prefixes and insertion guide.','[Editor snippets](docs/VSCODE_SNIPPETS.md) | Language snippets, prefixes and insertion guide.')
replace('ROADMAP.md','**VS Code extension 0.2.7** bundles engine/server 1.81.17; its [publication record](docs/extension-0.2.7-publication/README.md) records exact Marketplace verification.','**VS Code extension 0.3.0** bundles engine/server 1.81.17 and adds 20 language snippets; its [publication record](docs/extension-0.3.0-publication/README.md) records editor and exact Marketplace verification.')
replace('docs/ARCHITECTURE.md','The extension 0.3.0 candidate contributes language-scoped JSON snippets','Published extension 0.3.0 contributes language-scoped JSON snippets')
replace('docs/INTEGRATION.md','The extension 0.3.0 candidate adds 20 language-scoped snippets; published 0.2.7 remains the current Marketplace baseline.','Published extension 0.3.0 adds 20 language-scoped snippets; 0.2.7 is the previous Marketplace baseline. See the [current user guide](VSCODE_SNIPPETS.md).')
replace('docs/FEATURE_REQUESTS.md','Status: implemented candidate; local qualification passed, hosted review pending.','Status: implemented and published in extension 0.3.0 after hosted and actual editor qualification. [Publication receipt](extension-0.3.0-publication/README.md).')
replace('docs/FEATURE_REQUESTS.md','| Implemented candidate; review pending | Extension 0.3.0 |','| Implemented and published | Extension 0.3.0 |')
entry='## Extension snippets 0.3.0 published — 16 November 2026\n\nREQ-141 is delivered. [PR #501](https://github.com/Fytala-Charles/Bosak/pull/501) merged after all six checks passed. Hosted preparation43883918663 and exact-artifact publisher43891666461 passed; Marketplace download and GitHub asset match the reviewed VSIX. Five actual editor scenarios pass in each of two isolated VS Code1.146.0 profiles, including prefix suggestions, mirrors, forward/backward stops and final cursor, with and without bundled server. Core/server remains1.81.17; no NuGet or engine change. Earlier candidate notices are historical. [User guide](VSCODE_SNIPPETS.md) and [publication receipts](extension-0.3.0-publication/README.md).\n\n'
for f in ['docs/IMPLEMENTATION_STATUS.md','docs/DEVELOPMENT_HISTORY.md','docs/AGENT_HANDOVER.md']:
 p=W/f;p.write_bytes(entry.encode()+p.read_bytes())
p=W/'vscode-bosak/README.md';s=p.read_text(encoding='utf-8');start=s.index('## Development: snippets');end=s.index('## Current release (0.2.7)',start);s=s[:start]+'''## Current release (0.3.0)

Version 0.3.0 adds 20 XPath, XQuery and XSLT snippets with `bosak-` prefixes, editable defaults and linked names. Use Insert Snippet or Ctrl+Space, then Tab/Shift+Tab through placeholders. See the [user guide](../docs/VSCODE_SNIPPETS.md) and [verified publication](../docs/extension-0.3.0-publication/README.md). Bundles engine/server 1.81.17; requires .NET 10 for language-server features. Snippet insertion itself is independent of the server. Existing language/editor/profile limits remain.

'''+s[end:].replace('## Current release (0.2.7)','## Previous release (0.2.7)',1);p.write_text(s,encoding='utf-8')
replace('docs/RELEASING.md','Development extension 0.3.0 adds snippets; Core/server remains 1.81.17. Marketplace 0.2.7 is still the published baseline.','Published extension 0.3.0 adds snippets; Core/server remains 1.81.17. See the [verified delivery](extension-0.3.0-publication/README.md). Earlier candidate text records the original preparation scope.')
replace('docs/RELEASING.md','VS Code extension **0.2.7** is Marketplace-published and byte-verified. See the [extension receipt](extension-0.2.7-publication/README.md).','VS Code extension **0.3.0** is Marketplace-published and byte-verified. See the [extension receipt](extension-0.3.0-publication/README.md).')
p=W/'.gitattributes';p.write_bytes(p.read_bytes()+b'\n/docs/extension-0.3.0-publication/** -text whitespace=cr-at-eol\n')
print('Publication receipts and current user documentation prepared; original candidate dossier unchanged.')
