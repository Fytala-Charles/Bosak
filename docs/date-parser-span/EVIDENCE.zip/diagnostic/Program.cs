// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 14 November 2026
// PURPOSE              : Measures direct date-parser allocations in a guarded local diagnostic
// SPECIAL NOTES        : Unit tests verifying correctness of the underlying implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 14-11-2026     | Creation                                                                                 |
//                      | Charles Korthout | 0.2   | 14-11-2026     | Add isolated validator allocation rows.                                                  |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using System.Reflection;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Text.Json;
using Bosak.XPath.Core.Xdm;
internal static class Program
{
    /// <summary>Runs the guarded local reproduction.</summary>
    /// <returns>Zero on success, two for a caught failure.</returns>
    public static int Main()
    {
        try {
            var t=typeof(Program).Assembly.GetType("Rows",true)!;
            Console.WriteLine(JsonSerializer.Serialize(t.GetMethod("Run",BindingFlags.Static|BindingFlags.Public)!.Invoke(null,null)));
            return 0;
        } catch(Exception e) { Console.Error.WriteLine(e); return 2; }
    }
}
internal static class Rows
{
    private delegate bool Parse(string input,out XPathDateTime value,out bool hasTz);
    /// <summary>Measures fixed valid and rejected date inputs.</summary>
    /// <returns>Rows containing allocation and observed acceptance.</returns>
    public static object Run()
    {
        var vm=typeof(Bosak.XPath.Runtime.Vm.EvaluationContext).Assembly.GetType("Bosak.XPath.Runtime.Vm.VmEngine",true)!;
        var parse=vm.GetMethod("TryParseXPathDate",BindingFlags.NonPublic|BindingFlags.Static)!.CreateDelegate<Parse>();
        var rows=new List<object>();
        Parse candidate=Candidate.TryParseXPathDate;
        object Outcome(Parse p,string s) {
            try {bool ok=p(s,out var v,out bool tz);return new {ok,tz,v.Year,v.Month,v.Day,v.Hour,v.Minute,v.Second,v.Millisecond,v.TimezoneOffsetMinutes,v.HasTimezone};}
            catch(Exception e){return new {error=e.GetType().FullName,e.Message};}
        }
        var inputs=new List<string>{"", "2026-11-14\n","2026-11-14z","+2026-11-14","00000-01-01","2147483648-01-01","-2147483649-01-01","999999999999999999999-01-01","0000-02-29Z","-0004-02-29-00:00","2026-11-14+14:01","2026-11-14-14:00","2026-11-14+00:60","２０２６-１１-１４"};
        foreach(int year in new[]{-400,-100,-4,-1,0,1,4,100,400,1900,2000,2024,2026,9999,10000})
         foreach(int month in new[]{0,1,2,4,12,13})
          foreach(int day in new[]{0,1,28,29,30,31,32})
           foreach(string tz in new[]{"","Z","+05:30","-14:00","+14:01"})
            inputs.Add((year<0?"-"+(-year).ToString("D4"):year.ToString("D4"))+"-"+month.ToString("D2")+"-"+day.ToString("D2")+tz);
        foreach(var input in inputs)if(JsonSerializer.Serialize(Outcome(parse,input))!=JsonSerializer.Serialize(Outcome(candidate,input)))throw new Exception("Parity mismatch: "+input);
        int parityCases=inputs.Count;
        foreach(var c in new (string label,string input,bool expected)[]{
            ("date","2026-11-14",true),("utc","2026-11-14Z",true),
            ("offset","2026-11-14+05:30",true),("year-zero","0000-02-29Z",true),
            ("extended","10000-02-29Z",true),("negative-year","-0001-01-01Z",true),
            ("wrong-shape","not-a-date",false),("datetime-probe","2026-11-14T12:00:00Z",false),
            ("invalid-month","2026-13-14",false),("invalid-day","2026-02-29",false),
            ("invalid-zone","2026-11-14+14:01",false),("leading-plus","+2026-11-14",false)})
        {
            foreach(var variant in new[]{(label:"engine",call:parse),(label:"original-copy",call:candidate)})
        {
            var call=variant.call;
            for(int i=0;i<10000;i++) if(call(c.input,out _,out _)!=c.expected)throw new Exception("Warmup outcome changed: "+c.label);
            int accepted=0; long before=GC.GetAllocatedBytesForCurrentThread();
            for(int i=0;i<100000;i++)if(call(c.input,out _,out _))accepted++;
            long allocated=GC.GetAllocatedBytesForCurrentThread()-before;
            if(accepted!=(c.expected?100000:0))throw new Exception("Measured outcome changed: "+c.label);
            rows.Add(new {variant=variant.label,c.label,c.input,c.expected,accepted,iterations=100000,allocatedBytes=allocated,bytesPerCall=allocated/100000.0});
        }
        }
        return new {parityCases,runtime=Environment.Version.ToString(),engine=vm.Assembly.GetName().Version!.ToString(),rows};
    }
}

internal static class Candidate
{
    private static readonly Regex XPathDateRegex = new(
        @"^(?<year>[+-]?\d{4,})-(?<month>\d{2})-(?<day>\d{2})(?<tz>Z|[+-]\d{2}:\d{2})?$",
        RegexOptions.Compiled);

    internal static bool TryParseXPathDate(string s, out XPathDateTime xdt, out bool hasTz)
    {
        xdt = default;
        hasTz = false;
        var m = XPathDateRegex.Match(s);
        if (!m.Success) return false;

        string yearStr = m.Groups["year"].Value;
        long year = long.Parse(yearStr, CultureInfo.InvariantCulture);
        // Lexically valid but outside the implementation-defined year range: FODT0001
        // (date/time overflow), not FORG0001 (date-094e/f, date-095e/f).
        if (year > int.MaxValue || year < int.MinValue)
            throw new InvalidOperationException($"FODT0001: The year '{yearStr}' is outside the supported range.");
        // Reject + sign and leading zeros for years longer than 4 digits
        if (yearStr.StartsWith('+')) return false;
        if (yearStr.Length > 4 && yearStr[0] == '0') return false;

        int month = int.Parse(m.Groups["month"].Value, CultureInfo.InvariantCulture);
        int day = int.Parse(m.Groups["day"].Value, CultureInfo.InvariantCulture);
        if (month < 1 || month > 12) return false;
        if (day < 1 || day > 31) return false;
        if (day > DaysInMonth(year, month)) return false;

        int tzMinutes = 0;
        hasTz = m.Groups["tz"].Success;
        if (hasTz)
        {
            string tz = m.Groups["tz"].Value;
            if (tz == "Z" || tz == "z")
                tzMinutes = 0;
            else
            {
                if (!IsValidTimezone(tz)) return false;
                tzMinutes = ParseTimezoneOffset(tz);
            }
        }

        xdt = new XPathDateTime(year, month, day, 0, 0, 0, 0, tzMinutes, hasTz);
        return true;
    }
    private static int DaysInMonth(long year, int month)
    {
        return month switch
        {
            1 or 3 or 5 or 7 or 8 or 10 or 12 => 31,
            4 or 6 or 9 or 11 => 30,
            2 => IsLeapYear(year) ? 29 : 28,
            _ => 0
        };
    }
    private static bool IsLeapYear(long year)
    {
        if (year == 0) return true; // Year 0 is a leap year in XML Schema (proleptic Gregorian)
        if (year < 0) year = -year; // BCE leap years align with the negated year number
        return year % 4 == 0 && (year % 100 != 0 || year % 400 == 0);
    }
    private static bool IsValidTimezone(string tz)
    {
        // tz is like "+14:00" or "-05:00"
        int hours = int.Parse(tz[1..3], CultureInfo.InvariantCulture);
        int minutes = int.Parse(tz[4..6], CultureInfo.InvariantCulture);
        return hours <= 14 && !(hours == 14 && minutes > 0) && minutes <= 59;
    }
    private static int ParseTimezoneOffset(string tz)
    {
        // tz is like "+14:00" or "-05:00"
        bool negative = tz[0] == '-';
        var parts = tz[1..].Split(':');
        int hours = int.Parse(parts[0], CultureInfo.InvariantCulture);
        int minutes = int.Parse(parts[1], CultureInfo.InvariantCulture);
        int total = hours * 60 + minutes;
        return negative ? -total : total;
    }
}
