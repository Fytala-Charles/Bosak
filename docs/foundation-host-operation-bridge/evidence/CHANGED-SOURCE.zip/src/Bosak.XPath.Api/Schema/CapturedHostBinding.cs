// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 05 November 2026
// PURPOSE              : Binds private captured host producers to exact public sessions and serialized raw windows.
// SPECIAL NOTES        : Public surface API for compiling and evaluating XPath 3.1 expressions.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 05-11-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using System.Text.Json;
using Bosak.XPath.Core.Schema;
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Runtime.Vm;
namespace Bosak.XPath.Api.Schema;

/// <summary>Engine-only host/executable capability; caller descriptors cannot create public authority.</summary>
internal sealed class CapturedHostBinding
{
    internal const string Profile="bosak-internal-captured-host-v1";
    internal const string Descriptor="bosak-internal-captured-host-descriptor-v1";
    private readonly object _executable;
    private readonly int _bindings,_namespaces;
    internal QueryHostLanguage Host {get;}
    internal SchemaQueryEnvironment Environment {get;}
    internal SchemaQuerySession Session {get;}
    internal CapturedHostBinding(object executable,QueryHostLanguage host,SchemaQueryEnvironment captured,SchemaQueryLimits limits,int bindings,int namespaces)
    {
        ArgumentNullException.ThrowIfNull(executable);ArgumentNullException.ThrowIfNull(captured);limits.Validate();
        if(host is not(QueryHostLanguage.XQuery or QueryHostLanguage.Xslt))throw new ArgumentException("An upper host is required.",nameof(host));
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(bindings);ArgumentOutOfRangeException.ThrowIfNegativeOrZero(namespaces);
        _executable=executable;Host=host;_bindings=bindings;_namespaces=namespaces;
        Environment=new(captured.Namespaces,JsonSerializer.Serialize(new{format=Descriptor,profile=Profile,host=host.ToString(),captured=captured.Fingerprint,bindings,namespaces,limits.MaxOpenSnapshots,limits.MaxCachedValuesPerSnapshot,limits.MaxTypedValueAtoms,limits.MaxNumericDigits,limits.MaxDecimalScale}));
        Session=SchemaQuerySession.CreateHostCandidate(this,limits);
    }
    internal T Call<T>(SchemaQueryOperation operation,object executable,EvaluationContext? context,SchemaQuerySnapshot? match,
        SchemaQuerySnapshot? global,Func<Frame,T> producer)
    {
        ArgumentNullException.ThrowIfNull(operation);ArgumentNullException.ThrowIfNull(producer);
        var raw=operation.RequireHost(this);
        if(!ReferenceEquals(executable,_executable))throw new ArgumentException("Foreign captured executable.",nameof(executable));
        return raw.CallHost(this,guard=>
        {
            guard();if(match is not null)raw.RequireMember(match.Runtime);if(global is not null)raw.RequireMember(global.Runtime);
            var inputs=raw.CaptureInputs(context??new EvaluationContext(),_bindings,_namespaces);
            var matchRoot=match is null?null:raw.GetRoot(match.Runtime);var globalRoot=global is null?null:raw.GetRoot(global.Runtime);
            if(matchRoot is not null)raw.RequireNodeInput(inputs,matchRoot);if(globalRoot is not null)raw.RequireNodeInput(inputs,globalRoot);
            inputs.ValidateNodeInputs(raw);guard();
            var child=inputs.CreateContext();child.ResourcePolicy=SchemaProviderSessionBinding.ClosedResources();
            var frame=new Frame(child,matchRoot,globalRoot,guard);
            try{frame.Check();var result=producer(frame);frame.Check();return result;}
            finally{frame.Close();}
        });
    }
    internal sealed class Frame(EvaluationContext context,IXdmNode? match,IXdmNode? global,Action guard)
    {
        private int _closed;
        internal void Check(){ObjectDisposedException.ThrowIf(Volatile.Read(ref _closed)!=0,this);guard();ObjectDisposedException.ThrowIf(Volatile.Read(ref _closed)!=0,this);}
        internal EvaluationContext Context {get{Check();return context;}}
        internal IXdmNode? Match {get{Check();return match;}}
        internal IXdmNode? Global {get{Check();return global;}}
        internal void Close()=>Interlocked.Exchange(ref _closed,1);
    }
}
