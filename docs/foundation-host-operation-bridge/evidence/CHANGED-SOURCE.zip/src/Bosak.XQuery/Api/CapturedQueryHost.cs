// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 05 November 2026
// PURPOSE              : Executes captured XQuery through the exact public session raw operation.
// SPECIAL NOTES        : Part of the Bosak XPath 3.1 implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 05-11-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using Bosak.XPath.Api.Schema;
using Bosak.XPath.Core.Schema;
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Runtime.Vm;
namespace Bosak.XQuery.Api;

/// <summary>Private production bridge; the public XQuery facade is a separate slice.</summary>
internal sealed class CapturedQueryHost
{
    private readonly XQueryExecutable _executable;
    private readonly CapturedHostBinding _binding;
    internal Bosak.XPath.Api.Schema.SchemaQuerySession Session=>_binding.Session;
    private CapturedQueryHost(XQueryExecutable executable,SchemaQueryEnvironment environment,SchemaQueryLimits limits,int bindings,int namespaces)
    {_executable=executable;_binding=new(executable,QueryHostLanguage.XQuery,environment,limits,bindings,namespaces);}
    internal static CapturedQueryHost? Compile(string query,XQueryCompiler compiler,SchemaQueryLimits limits,int bindings,int namespaces,bool xml11=false)
    {
        ArgumentNullException.ThrowIfNull(query);ArgumentNullException.ThrowIfNull(compiler);limits.Validate();ArgumentOutOfRangeException.ThrowIfNegativeOrZero(bindings);ArgumentOutOfRangeException.ThrowIfNegativeOrZero(namespaces);
        return compiler.TryCaptureSchemaCompilation(query,xml11,out var executable,out var environment,out _)?new(executable!,environment!,limits,bindings,namespaces):null;
    }
    internal T Use<T>(SchemaQueryOperation operation,EvaluationContext context,Func<XdmValue,Action,T> consume)
    {
        ArgumentNullException.ThrowIfNull(consume);
        return _binding.Call(operation,_executable,context,null,null,frame=>
        {frame.Check();var value=_executable.EvaluateIsolatedContext(frame.Context);frame.Check();var result=consume(value,frame.Check);frame.Check();return result;});
    }
}
