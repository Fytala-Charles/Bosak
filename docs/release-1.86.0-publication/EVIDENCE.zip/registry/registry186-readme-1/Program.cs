// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 25 November 2026
// PURPOSE              : Runs a packaged README example against the exact candidate feed.
// SPECIAL NOTES        : Foundation types for the XQuery Data Model; used by all higher layers.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 25-11-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using Bosak.XPath.Core.Xdm;

var legacy = XdmValue.FromDateTime(new DateTimeOffset(2000, 1, 2, 3, 4, 5, TimeSpan.Zero));
var exact = XdmValue.FromExactCalendar(XdmExactCalendarValue.Parse(
    "2000-01-02T03:04:05.000000001Z", XdmExactCalendarKind.DateTime, 256, 256));
Console.WriteLine(XdmCalendarInterop.CompareXPath(legacy, exact, 0)); // -1
