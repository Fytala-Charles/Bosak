from pathlib import Path,PurePosixPath
import json,subprocess,urllib.request,urllib.error,hashlib,zipfile,datetime,time
P=Path(__file__).resolve().parent;prep=P.parent/'coverage-release-186';R=Path('D:/Development/Bosak/.worktrees/Core.Release186Verified');repo='Fytala-Charles/Bosak'
def sha(b):return hashlib.sha256(b).hexdigest()
run=json.loads(subprocess.check_output(['gh','run','view','45663011066','--repo',repo,'--json','status,conclusion,jobs,url,headSha']))
(P/'PUBLISHER.json').write_text(json.dumps(run,indent=2))
assert run['status']=='completed' and run['conclusion']=='success'
assert run['headSha']=='2d353912954f03caa44ba2d6e96a8a6224a077d5'
assert {j['name']:j['conclusion'] for j in run['jobs']}=={'prepare':'skipped','publish':'success'}
review=json.loads((prep/'PUBLICATION-REVIEW.json').read_text());out=P/'signed-packages';out.mkdir(exist_ok=True);records=[]
for item in review['artifacts']:
 name=item['file'].removesuffix('.1.86.0.nupkg');low=name.lower();url=f'https://api.nuget.org/v3-flatcontainer/{low}/1.86.0/{low}.1.86.0.nupkg'
 for attempt in range(40):
  try:
   with urllib.request.urlopen(url,timeout=30) as r:data=r.read()
   break
  except urllib.error.HTTPError as e:
   if e.code!=404 or attempt==39:raise
   print('Waiting for NuGet indexing: '+name,flush=True);time.sleep(30)
 target=out/item['file'];target.write_bytes(data);original=prep/'hosted-artifacts'/item['file'];assert sha(original.read_bytes())==item['sha256']
 entries=[]
 with zipfile.ZipFile(original) as a,zipfile.ZipFile(target) as b:
  an=a.namelist();bn=b.namelist();assert len(set(an))==len(an) and len(set(bn))==len(bn)
  assert set(bn)==set(an)|{'.signature.p7s'} and '.signature.p7s' not in an
  for n in an:
   assert not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts and '\\' not in n
   x=a.read(n);assert x==b.read(n),(name,n)
   entries.append(dict(path=n,sha256=sha(x)))
 with (P/(name+'-signature.log')).open('w',encoding='utf-8') as f:subprocess.run(['dotnet','nuget','verify','--all',str(target)],stdout=f,stderr=subprocess.STDOUT,check=True)
 records.append(dict(id=name,version='1.86.0',url=url,unsignedSha256=item['sha256'],signedSha256=sha(data),signatureVerified=True,payloadExactlyMatches=True,entries=entries))
 print('PASS signed exact payload '+name,flush=True)
(P/'SIGNED-PAYLOADS.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceCommit=review['sourceCommit'],manifestSha256=review['manifestSha256'],publisherRun=45663011066,packages=records),indent=2))
# Reuse reviewed source templates with only the official public registry configured.
env={**__import__('os').environ,'RELEASE_LANE':'registry186','RELEASE_SOURCE_ROOT':str(R),'RELEASE_FEED':str(out)}
local='<add key="reviewed" value="\'+str(feed)+\'"/>'
for script in ['consumer-checks.py','readme-examples.py']:
 text=(prep/script).read_text(encoding='utf-8');assert local in text
 text=text.replace(local,'')
 adapted=P/('registry-'+script);adapted.write_text(text,encoding='utf-8')
 subprocess.run(['python',str(adapted)],env=env,check=True)
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
import xml.etree.ElementTree as ET
c=[ET.parse(t).find('.//t:Counters',ns).attrib for t in (prep/'registry186-calendar-results').glob('*.trx')]
assert sum(int(x['passed']) for x in c)==73 and all(x['failed']=='0' for x in c)
for target in ['registry186-consumer-smoke','registry186-consumer-calendar','registry186-readme-0','registry186-readme-1']:
 config=(prep/target/'NuGet.Config').read_text();assert 'reviewed' not in config and 'https://api.nuget.org/v3/index.json' in config
(P/'VERIFIED.json').write_text(json.dumps(dict(success=True,version='1.86.0',publisherRun=45663011066,sourceCommit=review['sourceCommit'],manifestSha256=review['manifestSha256'],signedPackages=10,exactPayloads=10,registryOnlyRestore=True,smokePassed=53,calendarPassed=73,readmeExamplesPassed=2,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2))
print('PASS all publication and fresh registry-only consumer checks',flush=True)
