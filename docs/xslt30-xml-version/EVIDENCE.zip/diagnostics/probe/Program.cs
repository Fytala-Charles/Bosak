// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 12 November 2026
// PURPOSE              : Trace namespace metadata through unchanged XML-version transformation paths.
// SPECIAL NOTES        : Read-only diagnostic over sealed public candidate assemblies; catches failures.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 12-11-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Reflection;
using System.Text.Json;
using System.Xml.Linq;
using Bosak.XPath.Providers.Xml;
using Bosak.Xslt.Api;
using Bosak.Xslt.Runtime;

try
{
    var corpus = args[0];
    var numbers = new[] { "026", "028", "031", "032", "035", "037", "039", "042" };
    var observations = new List<object>();
    foreach (var number in numbers)
    {
        var path = Path.Combine(corpus, "tests/misc/xml-version/xml-version-" + number + ".xsl");
        var document = Xml11Loader.Load(path, LoadOptions.PreserveWhitespace | LoadOptions.SetBaseUri | LoadOptions.SetLineInfo);
        var loaded = Snapshot(document);
        var executable = new XsltCompiler().Compile(document, new Uri(path).AbsoluteUri);
        var source = XDocumentNode.Wrap(XDocument.Parse("<root/>"));
        var raw = executable.Transform(source);
        var properties = executable.LastResultDocumentProperties ?? executable.OutputProperties;
        var underlying = raw.IsNode && raw.NodeValue is XDocumentNode node ? node.UnderlyingObject : null;
        var serialized = ResultTreeSerializer.Serialize(raw, properties);
        observations.Add(new { number, loaded, result = Snapshot(underlying), properties.Version,
            properties.UndeclarePrefixes, serialized, apiSerialized = executable.TransformToString(source) });
    }
    Console.WriteLine(JsonSerializer.Serialize(observations, new JsonSerializerOptions { WriteIndented = true }));
}
catch (Exception error)
{
    Console.Error.WriteLine(error);
    Environment.ExitCode = 1;
}

static object[] Snapshot(XObject? value)
{
    var elements = value is XDocument document ? document.Descendants()
        : value is XElement element ? element.DescendantsAndSelf() : Enumerable.Empty<XElement>();
    return elements.Select(e => new
    {
        path = string.Join("/", e.AncestorsAndSelf().Reverse().Select(a => a.Name.LocalName)),
        attributes = e.Attributes().Where(a => a.IsNamespaceDeclaration)
            .Select(a => new { name = a.Name.ToString(), a.Value }).ToArray(),
        metadata = e.Annotations<object>()
            .Where(a => a.GetType().Name.Contains("Namespace") || a.GetType().Name.Contains("Prefix"))
            .Select(a => new
            {
                type = a.GetType().Name,
                values = a.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public)
                    .ToDictionary(p => p.Name, p => p.GetValue(a))
            }).ToArray()
    }).Cast<object>().ToArray();
}
