﻿from pathlib import Path
p=Path(__file__).resolve().parent;old=p.parent/'xslt30-error-oracle-20261112'
s=(old/'render.cjs').read_text(encoding='utf-8')
s=s.replace(str(old/'render').replace('\\','/'),str(p/'render').replace('\\','/'))
s=s.replace("const files = [", "const files = ['docs/xslt30-analyze-string-fix/README.md', ",1)
s=s.replace('docs/xslt30-error-oracle/DOCUMENTATION-CHECKS.json','docs/xslt30-analyze-string-fix/DOCUMENTATION-CHECKS.json')
s=s.replace("date: '2026-11-12'","date: '2026-11-13'")
(p/'render.cjs').write_text(s,encoding='utf-8')
