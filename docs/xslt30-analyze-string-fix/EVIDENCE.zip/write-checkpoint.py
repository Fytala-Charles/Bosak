from pathlib import Path
root=Path('D:/Development/Bosak/.worktrees/Bosak.AnalyzeStringErrors');here=root/'docs/xslt30-analyze-string-fix'
(here/'README.md').write_text('''# Scoped analyze-string error reporting — 13 November 2026

The reviewed correction maps regex preparation failures to `XTDE1140` and invalid flags to `XTDE1145` only within `xsl:analyze-string`. Select/regex/flags AVT evaluation and matching/non-matching child execution retain their original XPath errors. The shared XPath RegexHelper and the production legacy matcher are unchanged. Preparation, child validation and native regex construction keep their original order.

The [immutable adoption record](ADOPTION.json) precedes implementation and pins XSLT 3.0 Recommendation 8 June 2017, sections 2.14 and 17.1. Development Core/server metadata is 1.81.6, unpublished; published Core1.81.2 and extension0.2.6 remain unchanged.

Fourteen focused tests pass, including named `xsl:catch` patterns and the exact standard namespace/local name, native pattern construction, literal quote-mode behavior, both AVT error codes and both child callbacks in tree/typed evaluation. Identical sources against nine sealed1.81.5 assemblies produce four regression failures and ten protective/happy-path passes. The source of those tests is hash-bound to the baseline result.

Fresh solution, frozen-gate, targeted/oracle and complete standalone qualification are pending. No admission, fixture edit, new skip or gate-budget/ruleset change is proposed. The adopted required gate stays10,221/0/4,380; the579-case error set remains excluded. The diagnostic exact-identity audit will separately verify that the two original cases no longer use legacy aliases.
''',encoding='utf-8')
summary=('The [scoped analyze-string reporting correction](xslt30-analyze-string-fix/README.md) maps only effective regex/flags preparation errors to XTDE1140/XTDE1145. '
 'XPath errors from select/AVTs, child callbacks and ordinary functions retain their identities. Child-validation/native-construction order and the shared RegexHelper/legacy matcher are unchanged. '
 'Fourteen focused cases pass; identical sources against the sealed1.81.5 baseline yield four failures and ten passes. '
 'Fresh full qualification is pending. Development Core/server1.81.6 is unpublished; no gate admission, fixture/skip/budget/ruleset change or public signature addition.')
for name in ['docs/ARCHITECTURE.md','docs/INTEGRATION.md','docs/FEATURE_REQUESTS.md']:
 p=root/name;data=p.read_bytes();marker=b'</div>';pos=data.index(marker)+len(marker);p.write_bytes(data[:pos]+('\n\n## Scoped regex reporting checkpoint — 13 November 2026\n\n'+summary+'\n').encode()+data[pos:])
for name in ['docs/AGENT_HANDOVER.md','docs/IMPLEMENTATION_STATUS.md','docs/DEVELOPMENT_HISTORY.md']:
 p=root/name;data=p.read_bytes();p.write_bytes(('# Scoped analyze-string reporting — 13 November 2026\n\n'+summary+'\n\n'
 'PR480 merged at2e5abb5112f7ce422caa11d930d87b8e3c263b6b after all six checks passed; hosted artifact independently reconciles10,221/0/4,380. '
 'Worktree `.worktrees/Bosak.AnalyzeStringErrors`, branch `fix/xslt-analyze-string-errors`, base2e5abb51. Candidate checkpoint is the commit containing this entry. '
 'Adoption was recorded before code; tests and all C# license/history headers are current. Preserve the owner checkout and all earlier sealed dossiers. '
 'Do not claim completion or publication until fresh solution/frozen/standalone qualification succeeds.\n\n---\n\n').encode()+data)
p=root/'docs/ARCHITECTURE.md';data=p.read_bytes();old=b'Core/server development metadata is now **1.81.5**, an unpublished follow-up for the [final standalone corrections](xslt30-final-cases/README.md), based on merged PRs #474 and #475.';assert old in data;data=data.replace(old,b'Core/server development metadata is now **1.81.6**, an unpublished follow-up for the [scoped analyze-string reporting correction](xslt30-analyze-string-fix/README.md).',1);p.write_bytes(data)
p=root/'docs/INTEGRATION.md';data=p.read_bytes();old=b'Core/server development metadata is 1.81.5 for the unpublished [final standalone corrections](xslt30-final-cases/README.md), following merged PRs #474 and #475;';assert old in data;data=data.replace(old,b'Core/server development metadata is 1.81.6 for the unpublished [scoped analyze-string reporting correction](xslt30-analyze-string-fix/README.md);',1);p.write_bytes(data)
p=root/'docs/FEATURE_REQUESTS.md';data=p.read_bytes();data=data.replace(b'Last updated: 2026-11-12',b'Last updated: 2026-11-13',1);p.write_bytes(data)
print('Recorded qualified-scope boundaries and pending checks before clean candidate build.')
