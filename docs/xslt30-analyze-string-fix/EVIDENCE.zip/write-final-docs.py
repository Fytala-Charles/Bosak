from pathlib import Path
import json,hashlib,csv
p=Path(__file__).resolve().parent;r=Path('D:/Development/Bosak/.worktrees/Bosak.AnalyzeStringErrors');q=p.parent/'xslt30-analyze-string-qualified-20261113';h=r/'docs/xslt30-analyze-string-fix'
g=json.loads((q/'GATE.json').read_text());run=json.loads((q/'RUN.json').read_text());assert g['success'] and run['success']
tests=json.loads((p/'TEST-SUMMARY.json').read_text());assert tests['solutionTests']==26373
summary=f'''The [scoped analyze-string correction](xslt30-analyze-string-fix/README.md) reports XTDE1140/XTDE1145 for invalid effective regex/flags while preserving XPath errors from AVTs, child instructions and ordinary functions. Fourteen focused tests pass; identical sources against sealed 1.81.5 binaries give four expected failures and ten passes. All 26,373 solution cases pass across the retained restricted run and authorized 47-case database retry; 90 separate language-server tests pass. Frozen QT3 remains 31,397/0/424 and selected qt4 remains 8,941/0/1,918 (including 11 experimental passes), with every skip name/reason unchanged. The complete clean-source standalone gate remains 10,221/0/4,380 in {run['elapsedSeconds']:.3f} seconds, all 14,601 cases accounted for, with unchanged fixtures/runtime and original 1,200-second/8 GiB bounds.\n\nThe original 579-case error audit remains 513/0/66. Only error-1140a and error-1145a change reported identities, now the expected local codes without legacy aliases; named xsl:catch controls independently prove the standard QNames. Remaining 29 code differences, 23 uncoded reports and 55 execute-call/static-label observations still require review. Compile is public; TransformObserved is an internal capture helper; these call boundaries are not normative phase verdicts. No cases are admitted. Development Core/server 1.81.6 is unpublished; no public signature, fixture, skip, gate-budget or ruleset change.\n\n'''
# Replace only this step's preliminary introduction, preserving historical tails.
for name in ['docs/AGENT_HANDOVER.md','docs/IMPLEMENTATION_STATUS.md','docs/DEVELOPMENT_HISTORY.md']:
 f=r/name;data=f.read_bytes();marker=b'#';cut=data.index(b'\n#',data.index(b'Fresh full qualification')) if b'Fresh full qualification' in data else -1
 # The checkpoint prefix ends at its explicit source sentence before the old heading.
 first_old=data.find(b'\n#',data.find(b'50c9')) if b'50c9' in data else -1
 # Select exact bytes created by write-checkpoint.py: inspect its known 8-line prefix.
 lines=data.splitlines(keepends=True);prefix=b''.join(lines[:8]);assert b'Fresh full qualification is pending' in prefix
 title=lines[0].decode('utf-8').rstrip('\r\n')
 f.write_bytes((title+'\n\n'+summary+'Clean semantic candidate: `50c9fd762fb12704dbd670b8f49f1415d70d2bfa`, based on merged PR #480 `2e5abb5112f7ce422caa11d930d87b8e3c263b6b`; source worktree `.worktrees/Bosak.AnalyzeStringErrors`. Original owner checkout and sealed dossiers remain unchanged.\n\n').encode()+data[len(prefix):])
for name in ['docs/ARCHITECTURE.md','docs/INTEGRATION.md','docs/FEATURE_REQUESTS.md']:
 f=r/name;data=f.read_bytes();start=data.index(b'The [scoped analyze-string reporting correction]');end=data.index(b'\n\n',start)
 assert b'pending' in data[start:end]
 data=data[:start]+summary.rstrip().encode()+data[end:]
 data=data.replace(b'Scoped regex reporting checkpoint',b'Scoped regex reporting qualification',1)
 f.write_bytes(data)
f=r/'docs/CONFORMANCE.md';data=f.read_bytes();data=data.replace(b'Last updated: 12 November 2026.',b'Last updated: 13 November 2026.',1)
data=data.replace(b'No standalone required gate is adopted.',b'These qualification receipts preceded the operational adoption recorded below.',1)
needle=b'## Adopted standalone CI gate';assert needle in data
addition=('## Scoped analyze-string reporting follow-up\n\n'+summary).encode();data=data.replace(needle,addition+needle,1);f.write_bytes(data)
f=r/'docs/DOCUMENTATION_RENDERER_TEST.md';f.write_bytes(('# Scoped reporting renderer check — 13 November 2026\n\nThe [reporting-fix receipt](xslt30-analyze-string-fix/DOCUMENTATION-CHECKS.json) verifies rendered regression/original-case tables, complete pinned-gate counts, exclusion links and preserved historical/Fytala content. No screenshot/PDF acceptance is asserted.\n\n').encode()+f.read_bytes())
readme=f'''# Scoped analyze-string error reporting — 13 November 2026

Invalid effective regular expressions in `xsl:analyze-string` now report `XTDE1140`; invalid flags report `XTDE1145`. The correction is limited to regex preparation. Select and regex/flags AVT evaluation, matching/non-matching children and ordinary XPath functions keep their own errors. Child validation and native regex construction retain their original order. The shared XPath regex helper and legacy conformance matcher are unchanged.

The [adoption record](ADOPTION.json), recorded before implementation, pins [XSLT 3.0 Recommendation 8 June 2017](https://www.w3.org/TR/2017/REC-xslt-30-20170608/), sections 2.14 and 17.1. No intentional deviation is adopted. Development Core/server **1.81.6 is unpublished**; published Core 1.81.2 and extension 0.2.6 are unchanged. Public signatures are unchanged; the two error identities are observable behavior changes.

| Original pinned case | Previous report | Corrected report | Audit acceptance |
|---|---|---|---|
| error-1140a | FORX0002 | XTDE1140 | Direct local-code match; no legacy alias |
| error-1145a | FORX0001 | XTDE1145 | Direct local-code match; no legacy alias |

The diagnostic observer uses the same sources as the sealed prior audit, bound to nine freshly built candidate assemblies. Removing instrumentation restores the production runner exactly. All 579 statuses and 66 raw skip reasons are unchanged: **513 passed / 0 failed / 66 excluded**. Only the two rows above change reported identities. Local code properties do not independently prove namespaces; separate named `xsl:catch` tests assert both the standard error namespace and local name. Public `Compile` and internal `TransformObserved` call boundaries are observations, not normative phase verdicts.

| Verification | Result |
|---|---|
| Identical 14 tests against sealed 1.81.5 assemblies | 4 expected failures; 10 protective/happy-path passes |
| Candidate focused tests | 14 passed; zero failed/skipped |
| Complete solution, ten projects | 26,373 distinct cases pass across original run and database retry; includes 8,348 XSLT cases |
| Separate language-server tests | 90 passed |
| Frozen QT3 | 31,397 passed / 0 failed / 424 excluded; all skip names/reasons unchanged |
| Selected qt4 | 8,941 passed / 0 failed / 1,918 excluded; includes 11 experimental passes; all skip names/reasons unchanged |
| Full pinned standalone XSLT 3.0 | **10,221 passed / 0 failed / 4,380 excluded**, all 14,601 identities accounted for |
| Independent error classifier controls | 16 passed |

The initial restricted solution run failed 45 database cases during localhost `HttpListener` setup; the authorized retry passes all 47 database cases. The original failure log is retained. Other solution projects, including all 8,348 XSLT cases, pass in the original invocation. No tests are counted twice. The 14 focused tests cover validation/native-regex failures, valid segment order, quote mode, both AVTs and both child callbacks in tree/typed-sequence routes. The baseline and candidate use identical test-source bytes.

The standalone gate qualifies clean semantic commit **50c9fd762fb12704dbd670b8f49f1415d70d2bfa**, based on PR #480 merge **2e5abb5112f7ce422caa11d930d87b8e3c263b6b**, against immutable `w3c/xslt30-test@fddf1cf920087e791f13315d68dfbe874d97dc56`. Windows/Release, Legacy processor, Xslt30 catalog profile, basic/non-schema-aware; the original 1,200-second watchdog and 8 GiB job limit remain. It completes in **{run['elapsedSeconds']:.3f} seconds**, with unchanged owned/source corpus bytes and runtime hashes, no missing/unselected cases and no fixture edits. Diagnostic timing is not performance acceptance. Later delivery changes only documentation/evidence. Runtime binaries remain in the local qualified packet; the archive retains hashes, transcripts, complete ledgers and source snapshots.

All [4,380 named exclusions and reasons](skips.csv) remain unchanged. The `error` set remains excluded from the required gate; measuring its 579 cases does not admit them. The [prior error-audit skip explanation table](../xslt30-error-audit/README.md) covers the same 66 exclusions. Remaining 29 code differences and 23 uncoded reports (52 observed tolerance branches), plus 55 overlapping execute-call/static-label observations, require fixture/spec review. They are not blanket defect verdicts. No gate/ruleset, fixture, skip, package-publication or complete-conformance claim follows.

[Results](RESULTS.json), [case comparison](CASE-COMPARISON.json), [evidence archive](EVIDENCE.zip), [manifest](MANIFEST.json), [renderer receipt](DOCUMENTATION-CHECKS.json). Run `python docs/xslt30-analyze-string-fix/verify.py` for independent replay of the regression baseline, original-case identities, frozen gates, every standalone case and the unchanged exclusions. Historical dossiers and the earlier rejected timeout retain their own evidence.
'''
(h/'README.md').write_text(readme,encoding='utf-8')
for name in ['REPORT.json','CASE-COMPARISON.json']: (h/name).write_bytes((p/name).read_bytes())
results=dict(date='2026-11-13',sourceCommit=run['sourceCommit'],sourceBaseCommit='2e5abb5112f7ce422caa11d930d87b8e3c263b6b',developmentVersion='1.81.6',published=False,counts=g['counts'],totalCases=14601,elapsedSeconds=run['elapsedSeconds'],solutionTests=26373,xsltTestsIncluded=8348,languageServerTests=90,focusedTests=14,baselineExpectedFailures=4,baselinePasses=10,targetedErrorCounts={'Passed':513,'Failed':0,'Skipped':66},admittedCases=0,fixtureAndRuntimeUnchanged=True)
(h/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
rows=list(csv.DictReader((q/'outcomes.csv').open(encoding='utf-8')))
with (h/'skips.csv').open('w',newline='',encoding='utf-8') as stream:
 w=csv.DictWriter(stream,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(row for row in rows if row['status']=='Skipped')
print('Final measured documentation prepared.')
