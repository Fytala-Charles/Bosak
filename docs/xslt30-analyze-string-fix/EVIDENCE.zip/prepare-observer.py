﻿from pathlib import Path
import shutil,hashlib,json,subprocess,xml.etree.ElementTree as ET
p=Path(__file__).resolve().parent;old=p.parent/'xslt30-error-oracle-20261112';root=Path('D:/Development/Bosak/.worktrees/Bosak.AnalyzeStringErrors')
for name in ['classifier.py','run-selected.py'] :shutil.copyfile(old/name,p/name)
for name in ['run-controls.py','prepare-measurement.py','analyze.py']:
 s=(old/name).read_text().replace('Bosak.XsltErrorOracle','Bosak.AnalyzeStringErrors')
 s=s.replace("engineSourceCommit='df16de7f39a556c6f9afea3eee9f61ef9bbc602e'","engineSourceCommit='50c9fd762fb12704dbd670b8f49f1415d70d2bfa'")
 s=s.replace("sourceBaseCommit='065db051f18b6b427c7fab83e840f4ce7547f11c'","sourceBaseCommit='50c9fd762fb12704dbd670b8f49f1415d70d2bfa'")
 (p/name).write_text(s,encoding='utf-8')
diag=p/'diagnostic';diag.mkdir()
for name in ['Program.cs','TraceHelpers.cs']:shutil.copyfile(old/'diagnostic'/name,diag/name)
production=root/'tests/Bosak.Xslt.Conformance/Program.cs'
assert production.read_bytes()==(Path('D:/Development/Bosak/.worktrees/Bosak.XsltErrorOracle')/'tests/Bosak.Xslt.Conformance/Program.cs').read_bytes()
project=ET.Element('Project',Sdk='Microsoft.NET.Sdk');props=ET.SubElement(project,'PropertyGroup')
for key,value in [('OutputType','Exe'),('TargetFramework','net10.0'),('AssemblyName','Bosak.Xslt.Conformance'),('ImplicitUsings','enable'),('Nullable','enable'),('GenerateDocumentationFile','true')]:ET.SubElement(props,key).text=value
refs=ET.SubElement(project,'ItemGroup');engine={}
for path in sorted((root/'tests/Bosak.Xslt.Conformance/bin/Release/net10.0').glob('Bosak.*.dll')):
 if path.name=='Bosak.Xslt.Conformance.dll':continue
 engine[path.name]=hashlib.sha256(path.read_bytes()).hexdigest()
 ref=ET.SubElement(refs,'Reference',Include=path.stem);ET.SubElement(ref,'HintPath').text=str(path)
assert len(engine)==9
ET.indent(project);ET.ElementTree(project).write(diag/'Diagnostic.csproj',encoding='unicode')
with (p/'DIAGNOSTIC-BUILD.log').open('xb') as log:r=subprocess.run(['dotnet','build',str(diag/'Diagnostic.csproj'),'-c','Release'],stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
assert all(hashlib.sha256((diag/'bin/Release/net10.0'/name).read_bytes()).hexdigest()==h for name,h in engine.items())
record=dict(engineSourceCommit='50c9fd762fb12704dbd670b8f49f1415d70d2bfa',engineHashes=engine,engineBinariesUnchanged=True,productionRunnerUnchanged=True,observerSourcesIdenticalToSealedAudit=True,diagnosticSources={n:hashlib.sha256((diag/n).read_bytes()).hexdigest() for n in ['Program.cs','TraceHelpers.cs']},originalRunnerSourceSha256=hashlib.sha256(production.read_bytes()).hexdigest())
(p/'DIAGNOSTIC-IDENTITY.json').write_text(json.dumps(record,indent=2)+'\n')
print('Observer built against nine candidate assemblies; original observer source unchanged.')
