﻿from pathlib import Path
p=Path(__file__).resolve().parent;f=Path('D:/Development/Bosak/.worktrees/Bosak.AnalyzeStringErrors/docs/xslt30-analyze-string-fix/verify.py')
s=f.read_text();s=s.replace("  assert archive.read(label+'-SKIPS.txt')==archive.read('frozen-baseline/'+label+'-SKIPS.txt')","  assert transcript(label+'-SKIPS.txt').replace('\\r\\n','\\n')==transcript('frozen-baseline/'+label+'-SKIPS.txt').replace('\\r\\n','\\n')")
f.write_text(s)
