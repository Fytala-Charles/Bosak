from pathlib import Path
import hashlib,importlib.util,json,re
packet=Path(__file__).resolve().parent;prior=packet.parent/'xslt30-static-errors-20261112'
root=Path('D:/Development/Bosak/.worktrees/Bosak.AnalyzeStringErrors')
original=(prior/'RUNNER-SOURCE.cs').read_text(encoding='utf-8')
observed=(packet/'diagnostic/Program.cs').read_text(encoding='utf-8')
restored=observed.replace('partial class Program','class Program',1)
restored=restored.replace('        if (args.Length == 1 && args[0] == "--oracle-controls") { AuditRunControls(); return; }\n','',1)
restored=''.join(line for line in restored.splitlines(True) if not (line.lstrip().startswith(('_auditCase =','_auditPhase =','AuditWrite("normal-result",','AuditException(ex);')) or ('Charles Korthout | 3.82' in line)))
restored=re.sub(r'return AuditMatch\(expectedCode, ex, "[^"]+", (true|false|matches)\);',r'return \1;',restored)
assert restored==original
spec=importlib.util.spec_from_file_location('reference',root/'docs/xslt30-qualification/report.py');ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref)
import csv
old=list(csv.DictReader((prior/'outcomes.csv').open(encoding='utf-8',newline='')))
plan=json.loads((packet/'measurement/PLAN.json').read_text())
rows=ref.parse(plan,(packet/'measurement/stdout.log').read_text(encoding='utf-8-sig'),True)
raw={r['test']:r for r in rows}
assert len(raw)==579
assert all(raw[r['test']]['status']==r['status'] for r in old)
assert all(raw[r['test']]['reason']==r['recorded_reason'] for r in old if r['status']=='Skipped')
record=dict(observerRemovalExactlyRestoresOriginalSource=True,all579LegacyStatusesIdentical=True,all66RawSkipReasonsIdentical=True,
 originalNormalizedSourceSha256=hashlib.sha256(original.encode()).hexdigest(),restoredNormalizedSourceSha256=hashlib.sha256(restored.encode()).hexdigest(),
 scope='Structural source equivalence plus outcome parity; no change to original matcher conditions, return values, engine/profile flags or fixture selection')
(packet/'INSTRUMENTATION-VERIFICATION.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print('Removing observer instrumentation exactly restores the original runner source; all579 statuses and66 raw skip reasons match.')
