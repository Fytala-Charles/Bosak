﻿from pathlib import Path
import json
p=Path(__file__).resolve().parent;q=p.parent/'xslt30-analyze-string-qualified-20261113'
r=json.loads((q/'RUN.json').read_text(encoding='utf-8'));g=json.loads((q/'GATE.json').read_text(encoding='utf-8'));assert r['success'] and g['success']
body=f'''Invalid regex syntax and flags in `xsl:analyze-string` leaked XPath `FORX0002`/`FORX0001` reports. Translate those preparation failures to XSLT `XTDE1140`/`XTDE1145`, while preserving errors from select/AVTs, child callbacks and ordinary XPath functions. Shared regex helpers, child-validation order and the legacy conformance matcher remain unchanged.

Fourteen new tests prove the standard error QNames through named `xsl:catch`, valid segment/quote behavior and AVT/child boundaries. Identical sources against sealed 1.81.5 binaries produce four expected failures and ten passes. The original `error-1140a`/`error-1145a` fixtures now report exact local codes without aliases; all 579 audit statuses and 66 exclusions remain unchanged (513/0/66).

Validation:

- Release solution/runner builds pass. All 26,373 solution cases pass across the retained restricted run and authorized 47-case localhost database retry; 90 separate language-server tests pass.
- Frozen QT3 stays 31,397/0/424; selected qt4 stays 8,941/0/1,918, including 11 experimental passes. Every skip name and reason matches.
- The complete pinned standalone gate stays **10,221/0/4,380**, all 14,601 case identities accounted for in {r['elapsedSeconds']:.3f}s, unchanged corpus/runtime bytes, original 1,200-second/8 GiB limits.
- Six historical dossiers verify. New dossier includes immutable specification adoption, failing baseline, original-case traces, source/runtime seals, complete gate ledger, renderer checks and read-only replay.

Development Core/server patch 1.81.6 remains unpublished. No public signature, fixture, skip policy, gate/ruleset or admission change. Remaining 29 reported-code differences and 23 uncoded reports require review; this is not a complete-conformance claim.

Evidence: [scoped reporting dossier](docs/xslt30-analyze-string-fix/README.md). Clean semantic qualification commit: `50c9fd762fb12704dbd670b8f49f1415d70d2bfa`; subsequent delivery changes only documentation/evidence.
'''
(p/'PR-BODY.md').write_text(body,encoding='utf-8')
