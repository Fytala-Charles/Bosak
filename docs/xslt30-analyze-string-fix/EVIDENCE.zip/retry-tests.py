from pathlib import Path
import subprocess
p=Path(__file__).resolve().parent
root=Path('D:/Development/Bosak/.worktrees/Bosak.AnalyzeStringErrors')
for name,args in [('DATABASE-RETRY',['dotnet','test','tests/Bosak.XPath.Providers.Database.Tests','-c','Release','--no-build']),('LSP',['dotnet','test','tests/Bosak.LanguageServer.Tests','-c','Release'])]:
 print('Starting '+name,flush=True)
 with (p/(name+'.log')).open('xb') as log:r=subprocess.run(args,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 print(name+' exit '+str(r.returncode),flush=True)
 assert r.returncode==0

