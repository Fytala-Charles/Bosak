﻿from pathlib import Path
p=Path(__file__).resolve().parent;root=Path('D:/Development/Bosak/.worktrees/Bosak.AnalyzeStringErrors');here=root/'docs/xslt30-analyze-string-fix'
s=(root/'docs/xslt30-error-oracle/verify.py').read_text(encoding='utf-8')
s=s[:s.index(" resolution=read('CANDIDATE-RESOLUTION.json')")]
s=s.replace('"""Read-only replay of observed identities; never changes gate acceptance."""','"""Replay scoped reporting regressions, original-case identities and the unchanged pinned gate."""')
s=s.replace("'reported-code-exact':445","'reported-code-exact':447").replace("'reported-code-mismatch':31","'reported-code-mismatch':29")
s+=''' comparison=read('CASE-COMPARISON.json')
 assert set(comparison['onlyChangedReportedIdentities'])=={'error-1140a','error-1145a'}
 prior=list(csv.DictReader(io.StringIO(archive.read('previous-observer/outcomes.csv').decode('utf-8'))))
 previous={r['test']:r for r in prior}
 changed={n for n,row in by_name.items() if any(row[k]!=previous[n][k] for k in ['actual_code','identity_kind','identity_origin','catalog_code_assessment','legacy_branch'])}
 assert changed=={'error-1140a','error-1145a'}
 for name,code in [('error-1140a','XTDE1140'),('error-1145a','XTDE1145')]:
  row=by_name[name];assert row['actual_code']==code and row['catalog_code_assessment']=='reported-code-exact' and row['legacy_branch']=='message-code-substring'
 baseline=read('BASELINE-IDENTITY.json')
 assert hashlib.sha256(archive.read('source/AnalyzeStringErrorCodeTests.cs')).hexdigest()==baseline['regressionSourceSha256']
 assert baseline['allNineMatchQualified1815'] and baseline['testExitCode']==1
 def transcript(name):
  data=archive.read(name);return data.decode('utf-16') if data.startswith((b'\\xff\\xfe',b'\\xfe\\xff')) else data.decode('utf-8-sig')
 assert re.search(r'Failed:\\s+4, Passed:\\s+10, Skipped:\\s+0',transcript('BASELINE-TEST.log'))
 assert re.search(r'Failed:\\s+0, Passed:\\s+14, Skipped:\\s+0',transcript('FOCUSED-TEST.log'))
 tests=read('TEST-SUMMARY.json');assert tests['solutionTests']==26373 and tests['xsltTests']==8348 and tests['languageServerTests']==90
 assert tests['allCasesPassAcrossRetainedOriginalAndDatabaseRetry'] and tests['initialRestrictedDatabaseFailures']==45
 unit=transcript('UNIT.log');projects=re.findall(r'(Passed!|Failed!)\\s+- Failed:\\s+(\\d+), Passed:\\s+(\\d+), Skipped:\\s+(\\d+), Total:\\s+(\\d+).*?- ([\\w.]+)\\.dll',unit)
 assert len(projects)==10 and sum(int(r[4]) for r in projects)==26373
 assert [r[-1] for r in projects if r[0]=='Failed!']==['Bosak.XPath.Providers.Database.Tests']
 assert re.search(r'Failed:\\s+0, Passed:\\s+47, Skipped:\\s+0',transcript('DATABASE-RETRY.log'))
 assert re.search(r'Failed:\\s+0, Passed:\\s+90, Skipped:\\s+0',transcript('LSP.log'))
 for label,passed,skipped in [('QT3',31397,424),('QT4',8941,1918)]:
  text=transcript(label+'.log')
  for key,value in [('Passed',passed),('Failed',0),('Skipped',skipped)]:assert re.search(r'^'+key+r':\\s*'+str(value)+r'\\s*$',text,re.M)
  assert archive.read(label+'-SKIPS.txt')==archive.read('frozen-baseline/'+label+'-SKIPS.txt')
 assert 'Experimental-level (XPath40Experimental) passes: 11' in transcript('QT4.log')
 qualified=read('qualification/GATE.json');full=read('qualification/RUN.json');plan=read('qualification/PLAN.json')
 assert qualified['success'] and full['success'] and full['status']=='Completed' and full['completeCatalogCounts']
 assert full['sourceCommit']==plan['sourceCommit']==qualified['sourceCommit']=='50c9fd762fb12704dbd670b8f49f1415d70d2bfa'
 assert full['corpusCommit']=='fddf1cf920087e791f13315d68dfbe874d97dc56'
 assert full['timeoutSeconds']==1200 and full['memoryLimitBytes']==8589934592
 for name in ['stdout.log','stderr.log']:assert hashlib.sha256(archive.read('qualification/'+name)).hexdigest()==full[name+'Sha256']
 assert read('qualification/CORPUS-BEFORE.json')==read('qualification/CORPUS-AFTER.json')
 assert qualified['runtimeUnchanged'] and qualified['sourceCorpusUnchanged'] and not any(qualified['corpusDifferences'].values())
 spec=importlib.util.spec_from_file_location('gate',here.parents[1]/'tools/xslt30_gate.py');gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
 policy,_,_,skips=gate.baseline()
 replay=gate.reconcile(plan,full,transcript('qualification/stdout.log'),skips,policy)
 saved=list(csv.DictReader(io.StringIO(archive.read('qualification/outcomes.csv').decode('utf-8'))))
 assert replay==saved and len(saved)==14601
 assert qualified['counts']=={'Passed':10221,'Failed':0,'Skipped':4380}
 candidate=read('qualification/RUNTIME-HASHES.json')
 assert all(candidate[n]==h for n,h in identity['engineHashes'].items())
 assert read('ADOPTION.json')['beforeImplementation'] and read('ADOPTION.json')['intentionalDeviations']==[]
print('Verified 14 reporting tests and failing baseline; 26,373 solution cases across localhost retry; 90 LSP; exact frozen gates; unchanged 14,601-case standalone gate; two original cases report exact local codes without aliases.')
print('Remaining 29 code differences and 23 uncoded reports require review. No case admission, exclusion change, package publication or complete-conformance claim.')
'''
(here/'verify.py').write_text(s,encoding='utf-8')
print('Prepared read-only replay verifier.')
