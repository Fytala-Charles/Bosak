﻿from pathlib import Path
import csv,hashlib,json,re,zipfile,io
p=Path(__file__).resolve().parent;old=p.parent/'xslt30-error-oracle-20261112'
rows=list(csv.DictReader((p/'outcomes.csv').open()));before=list(csv.DictReader((old/'outcomes.csv').open()))
a={r['test']:r for r in rows};b={r['test']:r for r in before}
assert a.keys()==b.keys()
changed=[n for n in a if any(a[n][k]!=b[n][k] for k in ['actual_code','identity_kind','identity_origin','catalog_code_assessment','legacy_branch'])]
assert set(changed)=={'error-1140a','error-1145a'}
assert all(a[n]['status']==b[n]['status'] and a[n]['reason']==b[n]['reason'] for n in a)
for n,code in [('error-1140a','XTDE1140'),('error-1145a','XTDE1145')]:
 assert a[n]['actual_code']==code and a[n]['catalog_code_assessment']=='reported-code-exact' and a[n]['legacy_branch']=='message-code-substring'
records=dict(onlyChangedReportedIdentities=changed,all579StatusesAndSkipReasonsUnchanged=True,remainingCodeDifferences=29,remainingUncodedReports=23,remainingToleranceBranches=52,namespaceProof='The original fixtures expose local ErrorCode properties. Separate named xsl:catch regression tests prove standard namespace and local name.',cases=[dict(test=n,before={k:b[n][k] for k in ['actual_code','catalog_code_assessment','legacy_branch']},after={k:a[n][k] for k in ['actual_code','catalog_code_assessment','legacy_branch']}) for n in changed])
(p/'CASE-COMPARISON.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records,indent=2))
