import collections,csv,hashlib,importlib.util,json,xml.etree.ElementTree as ET,zipfile
from pathlib import Path
packet=Path(__file__).resolve().parent;measurement=packet/'measurement';prior=packet.parent/'xslt30-static-errors-20261112'
root=Path('D:/Development/Bosak/.worktrees/Bosak.AnalyzeStringErrors')
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
classifier=module('classifier',packet/'classifier.py');gate=module('gate',root/'tools/xslt30_gate.py');reference=module('reference',root/'docs/xslt30-qualification/report.py')
assert not (packet/'REPORT.json').exists()
plan=json.loads((measurement/'PLAN.json').read_text());run=json.loads((measurement/'RUN.json').read_text())
assert run['success'] and run['sourceCommit'] is None
old=list(csv.DictReader((prior/'outcomes.csv').open(encoding='utf-8',newline='')))
current=reference.parse(plan,(measurement/'stdout.log').read_text(encoding='utf-8-sig'),True)
assert {(r['test'],r['status']) for r in old}=={(r['test'],r['status']) for r in current}
events=[]
for line in (measurement/'stderr.log').read_text(encoding='utf-8-sig').splitlines():
 assert line.startswith('AUDIT '),line
 events.append(json.loads(line[6:]))
grouped=collections.defaultdict(list)
for event in events:grouped[event['caseName']].append(event)
ns={'t':'http://www.w3.org/2012/10/xslt-test-catalog'}
definition=measurement/'corpus'/plan['sets'][0]['file']
assert gate.digest(definition)==plan['sets'][0]['sha256']
cases={c.get('name'):c for c in ET.parse(definition).getroot().findall('t:test-case',ns)}
records=[];chains=[]
for baseline in old:
 name=baseline['test'];observed=grouped.get(name,[])
 row=dict(baseline,api_boundary='',legacy_branch='',legacy_expected='',identity_kind='',identity_origin='',actual_namespace='',actual_code='',catalog_code_assessment='',allowed_error_codes='',static_labeled_alternatives_only=False)
 if baseline['status']=='Skipped':
  assert not observed;row['catalog_code_assessment']='skipped'
 else:
  exceptions=[e for e in observed if e['kind']=='exception'];normal=[e for e in observed if e['kind']=='normal-result']
  assert len(exceptions)+len(normal)==1 and not(exceptions and normal),name
  if normal:
   row.update(api_boundary=normal[0]['phase'],legacy_branch='normal-result-assertions',catalog_code_assessment='normal-result')
   assert not [e for e in observed if e['kind']=='match']
  else:
   event=exceptions[0];chain=event['data']['chain'];assert chain and not event['data']['truncated']
   accepted=[e for e in observed if e['kind']=='match' and e['data']['accepted']];assert len(accepted)==1,name
   match=accepted[0]['data'];error=chain[0];identity=classifier.identity(error)
   result=cases[name].find('t:result',ns);assert result is not None
   direct=result.find('t:error',ns)
   if direct is not None:allowed=[direct.get('code')]
   else:
    any_of=result.find('t:any-of',ns);assert any_of is not None,name
    assert all(e.tag.rsplit('}',1)[-1] in ['error','assert-xml','assert','assert-serialization-error','assert-string-value','serialization-matches','assert-empty','assert-eq','all-of'] for e in any_of)
    # Match only directly declared error alternatives, as the retained runner does.
    allowed=[e.get('code') for e in any_of if e.tag.rsplit('}',1)[-1] in ['error','assert-serialization-error']]
   assert allowed,name
   assessment=classifier.combine(allowed,error)
   static_only=all(c is not None and c.startswith(('XTSE','XPST','XQST')) for c in allowed)
   row.update(api_boundary=event['phase'],legacy_branch=match['branch'],legacy_expected=match['expected'] or '',
    identity_kind=identity['kind'],identity_origin=identity.get('origin',''),actual_namespace=identity.get('namespace',''),
    actual_code=identity.get('local',''),catalog_code_assessment=assessment,allowed_error_codes=' | '.join(c or '(unspecified)' for c in allowed),
    static_labeled_alternatives_only=static_only)
   chains.append(dict(test=name,apiBoundary=event['phase'],exceptionChain=chain,acceptedLegacyMatch=match,
    allMatchAttempts=[e['data'] for e in observed if e['kind']=='match'],allowedErrorCodes=allowed,
    primaryIdentity=identity,catalogCodeAssessment=assessment,staticLabeledAlternativesOnly=static_only))
 records.append(row)
assert len(records)==579 and len(grouped)==513
fields=list(records[0])
for filename,subset in [('outcomes.csv',records),('review-candidates.csv',[r for r in records if r['status']=='Passed' and r['catalog_code_assessment'] not in ['qname-exact','reported-code-exact','normal-result','wildcard']]),
 ('late-static-labels.csv',[r for r in records if r['api_boundary']=='execute-call' and r['static_labeled_alternatives_only']])]:
 with (packet/filename).open('w',encoding='utf-8',newline='') as stream:
  writer=csv.DictWriter(stream,fieldnames=fields,lineterminator='\n');writer.writeheader();writer.writerows(subset)
(packet/'exceptions.json').write_text(json.dumps(chains,indent=2)+'\n',encoding='utf-8')
before=json.loads((measurement/'CORPUS-BEFORE.json').read_text());after=gate.inventory(measurement/'corpus')
gate.write_json(measurement/'CORPUS-AFTER.json',after)
assert before==after==gate.inventory(prior/'corpus')
runtime=gate.runtime_hashes(measurement/'runtime');assert runtime==json.loads((measurement/'RUNTIME-HASHES.json').read_text())
identity=json.loads((packet/'DIAGNOSTIC-IDENTITY.json').read_text());assert all(runtime[n]==digest for n,digest in identity['engineHashes'].items())
assert gate.baseline()[0]['counts']=={'Passed':10221,'Failed':0,'Skipped':4380}
summary=dict(legacyCounts={k:sum(r['status']==k for r in records) for k in ['Passed','Failed','Skipped']},
 totalCases=579,allLegacyOutcomesIdentical=True,events=dict(collections.Counter(e['kind'] for e in events)),
 observedApiBoundaries=dict(collections.Counter(r['api_boundary'] for r in records if r['status']=='Passed')),
 acceptedLegacyBranches=dict(collections.Counter(r['legacy_branch'] for r in records if r['status']=='Passed')),
 catalogCodeAssessments=dict(collections.Counter(r['catalog_code_assessment'] for r in records)),
 lateStaticLabelCandidates=sum(r['api_boundary']=='execute-call' and r['static_labeled_alternatives_only'] for r in records),
 controlsPassed=json.loads((packet/'CONTROLS.json').read_text())['success'],
 nineEngineAssembliesUnchanged=True,corpusAndRuntimeUnchanged=True,gateUnchanged=True,
 elapsedSeconds=run['elapsedSeconds'],normativeDefectVerdicts=False,
 scope='Reported identities and entry-point call boundaries: public Compile, internal TransformObserved capture helper; not normative phases. Local code properties do not independently prove a namespace. Remaining catalog differences require fixture/spec review; no admission.')
assert summary['legacyCounts']=={'Passed':513,'Failed':0,'Skipped':66}
gate.write_json(packet/'REPORT.json',summary)
print(json.dumps(summary,indent=2))
