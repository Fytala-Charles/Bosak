﻿from pathlib import Path
p=Path(__file__).resolve().parent;f=p/'write-final-docs.py';s=f.read_text();needle="needle=b'## Adopted standalone CI gate';assert needle in data";assert needle in s
s=s.replace(needle,"data=data.replace(b'No standalone required gate is adopted.',b'These qualification receipts preceded the operational adoption recorded below.',1)\n"+needle)
f.write_text(s,encoding='utf-8')
