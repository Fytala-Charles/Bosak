﻿from pathlib import Path
import subprocess,json
r=Path('D:/Development/Bosak/.worktrees/Bosak.AnalyzeStringErrors');p=Path(__file__).resolve().parent
checks=[]
with (p/'HISTORICAL-VERIFICATION.log').open('xb') as log:
 for name in ['xslt30-qualification','xslt30-isolation-candidate','xslt30-xml-version','xslt30-final-cases','xslt30-error-audit','xslt30-error-oracle']:
  script=r/'docs'/name/'verify.py'
  if not script.exists():continue
  result=subprocess.run(['python',str(script)],cwd=r,stdout=log,stderr=subprocess.STDOUT)
  checks.append(dict(dossier=name,exitCode=result.returncode))
(p/'HISTORICAL-VERIFICATION.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2));assert all(x['exitCode']==0 for x in checks)
