﻿from pathlib import Path
import hashlib,json,re
p=Path(__file__).resolve().parent;root=Path('D:/Development/Bosak/.worktrees/Bosak.AnalyzeStringErrors')
unit=(p/'UNIT.log').read_text(encoding='utf-8-sig')
rows=re.findall(r'(Passed!|Failed!)\s+- Failed:\s+(\d+), Passed:\s+(\d+), Skipped:\s+(\d+), Total:\s+(\d+).*?- ([\w.]+)\.dll',unit)
assert len(rows)==10
failed=[r for r in rows if r[0]=='Failed!'];assert len(failed)==1 and failed[0][-1]=='Bosak.XPath.Providers.Database.Tests' and failed[0][1:5]==('45','2','0','47')
retry=(p/'DATABASE-RETRY.log').read_text(encoding='utf-8-sig');assert re.search(r'Failed:\s+0, Passed:\s+47, Skipped:\s+0, Total:\s+47',retry)
assert sum(int(r[4]) for r in rows)==26373
assert re.search(r'Failed:\s+0, Passed:\s+90, Skipped:\s+0, Total:\s+90',(p/'LSP.log').read_text(encoding='utf-8-sig'))
baseline=json.loads((p/'BASELINE-IDENTITY.json').read_text());assert hashlib.sha256((root/'tests/Bosak.Xslt.Tests/AnalyzeStringErrorCodeTests.cs').read_bytes()).hexdigest()==baseline['regressionSourceSha256']
record=dict(solutionTests=26373,xsltTests=8348,languageServerTests=90,allCasesPassAcrossRetainedOriginalAndDatabaseRetry=True,initialRestrictedDatabaseFailures=45,databaseRetryPasses=47,reason='Initial restricted localhost HttpListener handle failure; authorized unsandboxed retry passes every database case.',testProjects=[dict(project=r[-1],total=int(r[4]),originalFailed=int(r[1])) for r in rows],testSourceUnchangedFromFailingBaseline=True)
(p/'TEST-SUMMARY.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
