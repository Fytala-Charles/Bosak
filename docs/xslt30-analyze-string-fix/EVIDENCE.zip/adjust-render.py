﻿from pathlib import Path
p=Path(__file__).resolve().parent;f=p/'render.cjs';s=f.read_text(encoding='utf-8')
needle="  if (file === 'docs/xslt30-error-oracle/README.md') {"
new="""  if (file === 'docs/xslt30-analyze-string-fix/README.md') {
    if (tokens.filter(t=>t.type==='table_open').length !== 2) throw Error('Reporting-fix case/verification tables missing');
    for (const value of ['XTDE1140','XTDE1145','26,373','8,348','10,221 passed / 0 failed / 4,380 excluded','No tests are counted twice','internal','unpublished']) if (!rendered.includes(value)) throw Error('Reporting-fix result/scope missing: '+value);
  }
"""+needle
assert needle in s;s=s.replace(needle,new,1);f.write_text(s,encoding='utf-8')
