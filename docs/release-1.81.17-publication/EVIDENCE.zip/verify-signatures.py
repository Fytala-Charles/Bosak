from pathlib import Path
import importlib.util,json
R=Path('D:/Development/Bosak');P=Path(__file__).resolve().parent;service=json.loads((P/'SERVICE-VERIFICATION.json').read_bytes());assert service['allTenVerified'];paths=[str(P/'delivered'/(row['package']+'.1.81.17.nupkg')) for row in service['rows']]
spec=importlib.util.spec_from_file_location('m',R/'.guard-tmp/allocation-refresh17-20261116/measure.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);support=m.module('support',m.R/'tools/xslt30_stack_profile.py')
receipt=support.bounded(['C:/Program Files/dotnet/dotnet.exe','nuget','verify','--all',*paths],P,P/'SIGNATURE-VERIFY',120);assert receipt['success'],'Retain signature verification failure for inspection'
(P/'SIGNATURE-VERIFICATION.json').write_text(json.dumps(dict(success=True,packages=10,commandReceipt='SIGNATURE-VERIFY.json',source='NuGet.org delivered nupkg files',allPackageSignaturesVerified=True),indent=2)+'\n',encoding='utf-8');print('All ten NuGet-delivered package signatures verified.')
