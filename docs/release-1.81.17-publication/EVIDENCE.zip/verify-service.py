from pathlib import Path
import urllib.request,urllib.error,zipfile,io,json,hashlib,datetime,time,concurrent.futures,gzip
P=Path(__file__).resolve().parent;B=P.parent;out=P/'delivered';out.mkdir();attempts=P/'service-attempts';attempts.mkdir();manifest=json.loads((B/'packages/release-manifest.json').read_bytes());names=[x['file'].removesuffix('.1.81.17.nupkg') for x in manifest['artifacts']]
def fetch(url):
 request=urllib.request.Request(url,headers={'User-Agent':'BosakPublicationVerification/1.81.17','Cache-Control':'no-cache','Accept-Encoding':'identity'})
 with urllib.request.urlopen(request,timeout=30) as response:
  data=response.read();return gzip.decompress(data) if response.headers.get('Content-Encoding')=='gzip' else data

def check(name):
 ident=name.lower();base='https://api.nuget.org/v3-flatcontainer/'+ident;filename=name+'.1.81.17.nupkg';url=base+'/1.81.17/'+filename.lower();row=dict(package=name,version='1.81.17',url=url,observedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 try:
  indexBytes=fetch(base+'/index.json');index=json.loads(indexBytes);(out/(ident+'-index.json')).write_bytes(indexBytes);row['versionListed']='1.81.17' in index['versions']
  target=out/filename;data=target.read_bytes() if target.exists() else fetch(url)
  with zipfile.ZipFile(B/'packages'/filename) as before,zipfile.ZipFile(io.BytesIO(data)) as after:
   expected=set(before.namelist());actual=set(after.namelist());assert len(actual)==len(after.namelist()),name+':duplicate entries'
   missing=expected-actual;extra=actual-expected;changed=[n for n in expected&actual if before.read(n)!=after.read(n)]
   assert not missing and not changed and extra.issubset({'.signature.p7s'}),str((name,missing,extra,changed))
   row.update(downloaded=True,sha256=hashlib.sha256(data).hexdigest(),approvedUnsignedSha256=hashlib.sha256((B/'packages'/filename).read_bytes()).hexdigest(),payloadEntriesMatchApprovedArtifact=True,addedEntries=sorted(extra),repositorySignaturePresent='.signature.p7s' in actual)
  target.write_bytes(data)
  registrationBytes=fetch('https://api.nuget.org/v3/registration5-gz-semver2/'+ident+'/1.81.17.json');registration=json.loads(registrationBytes);(out/(ident+'-registration.json')).write_bytes(registrationBytes);row['registrationListed']=registration.get('listed') is True
  row['verified']=row['versionListed'] and row['registrationListed'] and row['payloadEntriesMatchApprovedArtifact']
 except urllib.error.HTTPError as error:
  if error.code!=404:raise
  row.update(verified=False,httpStatus=404)
 return row

deadline=time.monotonic()+1800;number=0
while time.monotonic()<deadline:
 number+=1
 with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:rows=list(pool.map(check,names))
 snapshot=dict(observedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),attempt=number,allTenVerified=all(x['verified'] for x in rows),rows=rows);(attempts/(str(number).zfill(3)+'.json')).write_text(json.dumps(snapshot,indent=2)+'\n',encoding='utf-8');(P/'SERVICE-LATEST.json').write_text(json.dumps(snapshot,indent=2)+'\n',encoding='utf-8');print('Verified/listed:',sum(x['verified'] for x in rows),'/10',flush=True)
 if snapshot['allTenVerified']:(P/'SERVICE-VERIFICATION.json').write_text(json.dumps(snapshot,indent=2)+'\n',encoding='utf-8');break
 time.sleep(45)
else:raise SystemExit('Service visibility deadline reached; preserve observations, no republishing inferred')
