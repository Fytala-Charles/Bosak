from pathlib import Path
import json,hashlib,subprocess,zipfile,importlib.util,os
P=Path(__file__).resolve().parent;W=Path('D:/Development/Bosak/.worktrees/Bosak.Release18117');B=P.parent;C=P/'consumer'
def read(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
verified=read(B/'ARTIFACT-VERIFICATION.json');service=read(P/'SERVICE-VERIFICATION.json');assert service['allTenVerified'];assert verified['success'];manifest=verified['manifest'];names=[x['file'].removesuffix('.1.81.17.nupkg') for x in manifest['artifacts']];assert len(names)==10
packageHashes={x['file']:x['sha256'] for x in manifest['artifacts']}
for n,h in packageHashes.items():assert sha(B/'packages'/n)==h
review=dict(sourceCommit=verified['sourceCommit'],preparationRunId=verified['preparationRunId'],manifestSha256=verified['manifestSha256'],consumerSourceSha256=sha(C/'Program.cs'),consumerProjectSha256=sha(C/'Consumer.csproj'),nugetConfigSha256=sha(P/'NuGet.Config'),packageHashes=packageHashes,packageSources=['https://api.nuget.org/v3/index.json'],cache=str(P/'consumer-cache'),projectReferences=False,workloadRuns=1,timeoutSeconds=120,memoryLimitBytes=8589934592,expectedCases=53,liveDatabaseAcceptance=False,publicationAuthorized=False)
(P/'CONSUMER-REVIEW.json').write_text(json.dumps(review,indent=2)+'\n',encoding='utf-8')
env=os.environ.copy();env['NUGET_PACKAGES']=str(P/'consumer-cache');env['DOTNET_CLI_TELEMETRY_OPTOUT']='1'
for label,args in [('CONSUMER-RESTORE',['dotnet','restore',str(C/'Consumer.csproj'),'--configfile',str(P/'NuGet.Config'),'--packages',str(P/'consumer-cache'),'--no-cache','-p:ImportDirectoryBuildProps=false','-p:ImportDirectoryBuildTargets=false']),('CONSUMER-BUILD',['dotnet','build',str(C/'Consumer.csproj'),'-c','Release','--no-restore','-p:UseSharedCompilation=false','-p:ImportDirectoryBuildProps=false','-p:ImportDirectoryBuildTargets=false'])]:
 with (P/(label+'.log')).open('xb') as log:subprocess.run(args,cwd=C,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
assets=read(C/'obj/project.assets.json');assert set(assets['libraries'])=={n+'/1.81.17' for n in names};assert all(v['type']=='package' for v in assets['libraries'].values());assert len(assets['packageFolders'])==1 and Path(next(iter(assets['packageFolders']))).resolve()==(P/'consumer-cache').resolve()
output=C/'bin/Release/net10.0';expectedDlls={}
for name in names:
 package=B/'packages'/(name+'.1.81.17.nupkg');assert sha(P/'consumer-cache'/name.lower()/'1.81.17'/(name.lower()+'.1.81.17.nupkg'))==sha(P/'delivered'/(name+'.1.81.17.nupkg'))
 with zipfile.ZipFile(package) as z:expectedDlls[name]=hashlib.sha256(z.read('lib/net10.0/'+name+'.dll')).hexdigest()
 assert sha(output/(name+'.dll'))==expectedDlls[name]
spec=importlib.util.spec_from_file_location('measurement',Path('D:/Development/Bosak/.guard-tmp/allocation-refresh17-20261116/measure.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);support=m.module('support',m.R/'tools/xslt30_stack_profile.py');pin=read(Path('D:/Development/Bosak/.guard-tmp/allocation-refresh17-20261116/measurement/CASE-COST-PIN.json'));support.native_files(pin)
(P/'CONSUMER-PRELAUNCH.json').write_text(json.dumps(dict(reviewSha256=sha(P/'CONSUMER-REVIEW.json'),sourceSha256=sha(C/'Program.cs'),consumerBinarySha256=sha(output/'ReleaseConsumer.dll'),packageDlls=expectedDlls,nativePinsVerified=True),indent=2)+'\n',encoding='utf-8')
receipt=support.bounded([pin['nativeFiles']['dotnet.exe']['path'],'exec','--fx-version','10.0.11','--roll-forward','Disable',str(output/'ReleaseConsumer.dll')],P,P/'CONSUMER-RUN',120);assert receipt['success'],'Retain original failed smoke; inspect before advancing'
result=read(P/'CONSUMER-RUN.stdout.log');assert result['success'] and result['passed']==53 and result['failed']==0 and len(result['assemblies'])==10
for item in result['assemblies']:
 assert item['sha256']==expectedDlls[item['name']] and Path(item['path']).resolve().is_relative_to(output.resolve()) and item['version']=='1.81.17.0'
for name,h in expectedDlls.items():assert sha(output/(name+'.dll'))==h
for n,h in packageHashes.items():assert sha(B/'packages'/n)==h
assert sha(C/'Program.cs')==review['consumerSourceSha256'] and sha(B/'packages/release-manifest.json')==review['manifestSha256']
(P/'CONSUMER-RESULTS.json').write_text(json.dumps(dict(success=True,result=result,exactPackageCacheVerified=True,loadedDllsMatchReviewedPackages=True,sourceAndArtifactsUnchanged=True,nativeRuntime='10.0.11',publicationAuthorized=False),indent=2)+'\n',encoding='utf-8');print('Fresh NuGet.org consumer:',result['passed'],'passed; ten loaded assemblies/cache packages match reviewed artifact.')
