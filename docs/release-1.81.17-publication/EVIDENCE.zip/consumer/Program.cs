// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 16 November 2026
// PURPOSE              : Checks exact release packages through finite isolated consumer scenarios
// SPECIAL NOTES        : Unit tests verifying correctness of the underlying implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 16-11-2026     | Creation                                                                                 |
//                      | Charles Korthout | 0.2   | 16-11-2026     | Select id explicitly in the namespace-bearing streaming fixture.                       |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using System.Reflection;
using System.Text.Json;
using System.Security.Cryptography;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using Bosak.XPath.Api;
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Runtime.Vm;
using Bosak.XPath.Providers.Xml;
using Bosak.XPath.Providers.Streaming;
using Bosak.XPath.Providers.Database;
using Bosak.XQuery.Api;
using Bosak.Xslt.Api;

internal static class Program
{
    /// <summary>Executes engine-bearing smoke checks inside an exception boundary.</summary>
    /// <returns>Zero on success, otherwise two.</returns>
    public static int Main(){try{var type=typeof(Program).Assembly.GetType("Consumer",true)!;Console.WriteLine(JsonSerializer.Serialize(type.GetMethod("Run")!.Invoke(null,null)));return 0;}catch(Exception error){Console.Error.WriteLine(error);return 2;}}
}
internal static class Consumer
{
    private const string Xml="<root xmlns:p='urn:p'><record id='1'><n>7</n></record><record id='2'><n>8</n></record></root>";
    private static readonly List<string> Cases=new();
    private static void Check(string name,bool value){if(!value)throw new InvalidOperationException(name);Cases.Add(name);}
    private static XdmValue Eval(string text,EvaluationContext? context=null)=>XPath31Expression.Compile(text).Evaluate(context??new EvaluationContext());
    private static List<XdmValue> Pull(XdmSequence input){var result=new List<XdmValue>();foreach(var v in input)result.Add(v);return result;}
    private static IXdmNode One(XdmSequence input)=>Pull(input).Single().NodeValue;
    private static void CheckStream(string prefix,IXdmNode document)
    {
        var root=One(document.Children(XdmNodeKind.Element));var records=root.Children(XdmNodeKind.Element).GetEnumerator();Check(prefix+"/first",records.MoveNext());
        var held=records.Current.NodeValue;var attributes=held.Axis(XdmAxis.Attribute);var first=One(attributes);
        Check(prefix+"/attribute",first.StringValue=="1" && first.IsSameNode(One(attributes)));
        Check(prefix+"/namespace",Pull(held.Axis(XdmAxis.Namespace)).Any(v=>v.NodeValue.StringValue=="urn:p"));
        Check(prefix+"/second",records.MoveNext() && One(records.Current.NodeValue.Attributes("id","")).StringValue=="2");
        Check(prefix+"/held-record",first.StringValue=="1" && One(held.Children(XdmNodeKind.Element)).StringValue=="7");
        Check(prefix+"/end",!records.MoveNext());
    }
    private static void DatabaseFixture()
    {
        var portProbe=new TcpListener(IPAddress.Loopback,0);portProbe.Start();int port=((IPEndPoint)portProbe.LocalEndpoint).Port;portProbe.Stop();
        using var listener=new HttpListener();listener.Prefixes.Add($"http://127.0.0.1:{port}/");listener.Start();
        var requests=new List<string>();var server=Task.Run(async()=>{
            for(int i=0;i<2;i++)
            {
                var request=await listener.GetContextAsync().WaitAsync(TimeSpan.FromSeconds(10));
                try{requests.Add(request.Request.RawUrl??"");var bytes=Encoding.UTF8.GetBytes(Xml);request.Response.StatusCode=200;request.Response.ContentType="application/xml";request.Response.ContentLength64=bytes.Length;await request.Response.OutputStream.WriteAsync(bytes);}finally{request.Response.Close();}
            }
        });
        try
        {
            var options=new DatabaseLoaderOptions();options.BaseX.EndpointBase=$"http://127.0.0.1:{port}/rest";
            var materialized=DatabaseDocumentLoader.Load("basex://fixture/db/doc.xml",options);
            Check("database/materialized-load",Eval("sum(/root/record/n ! xs:integer(.))",new EvaluationContext().WithFocus(XdmValue.FromNode(materialized),1,1)).IntegerValue==15);
            CheckStream("database/streaming",DatabaseDocumentLoader.LoadStreaming("basex://fixture/db/doc.xml",options));
            server.GetAwaiter().GetResult();Check("database/rest-paths",requests.SequenceEqual(new[]{"/rest/db/doc.xml","/rest/db/doc.xml"}));
            var fallback=new XDocumentNode(XDocument.Parse("<fallback/>"));int calls=0;var dispatch=DatabaseDocumentLoader.Dispatch(uri=>{calls++;return fallback;},options);
            Check("database/non-database-dispatch",ReferenceEquals(fallback,dispatch("memory:fixture"))&&calls==1);
        }
        finally{listener.Stop();try{server.Wait(TimeSpan.FromSeconds(2));}catch(AggregateException){}}
    }
    /// <summary>Runs bounded smoke checks against only the reviewed package cohort.</summary>
    /// <returns>Case results and exact loaded assembly identities.</returns>
    public static object Run()
    {
        Check("xpath/arithmetic",Eval("2+2").IntegerValue==4);Check("xpath/empty",Eval("count(())").IntegerValue==0);Check("xpath/map",Eval("map:get(map{'a':42},'a')").IntegerValue==42);
        foreach(var c in new[]{("2026-11-16",true),("0000-02-29Z",true),(" 2026-11-16+05:30 ",true),("10000-01-01",true),("-0004-02-29",true),("1900-02-29",false),("2026-11-16+14:01",false),("2026-11-16z",false)})
        {
            var context=new EvaluationContext().WithVariable("s",XdmValue.FromString(c.Item1));Check("date/castable/"+c.Item1,Eval("$s castable as xs:date",context).BooleanValue==c.Item2);
            if(c.Item2)Check("date/construct/"+c.Item1,Eval("xs:date($s)",context).Kind==XdmValueKind.Date);
            else{bool refused=false;try{Eval("xs:date($s)",context);}catch(Exception error){refused=error.Message.Contains("FORG0001",StringComparison.Ordinal);}Check("date/refusal/"+c.Item1,refused);}
        }
        Check("date/empty",Eval("empty(xs:date(()))").BooleanValue);
        Check("xquery/flwor",new XQueryCompiler().Compile("sum(for $x in (1,2,3) return $x*2)").Evaluate(new XQueryContext()).IntegerValue==12);
        Check("xquery/empty",new XQueryCompiler().Compile("count(for $x in () return $x)").Evaluate(new XQueryContext()).IntegerValue==0);
        var sheet=new XsltCompiler().Compile("""<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xs="http://www.w3.org/2001/XMLSchema"><xsl:output method="text"/><xsl:template match="/"><xsl:value-of select="sum(root/record/n ! xs:integer(.))"/></xsl:template><xsl:template name="main"><xsl:value-of select="6*7"/></xsl:template></xsl:stylesheet>""");
        Check("xslt/sourcefree",sheet.TransformToString(null,initialTemplate:"main")=="42");Check("xslt/materialized",sheet.TransformToString(new XDocumentNode(XDocument.Parse(Xml)))=="15");
        using(var stream=new MemoryStream(Encoding.UTF8.GetBytes(Xml))){Check("xslt/streaming",sheet.TransformStreamingToString(stream)=="15");Check("xslt/input-ownership",stream.CanRead);}
        using(var reader=XmlReader.Create(new StringReader(Xml))){CheckStream("provider",XmlStreamingProvider.Load(reader));Check("provider/reader-ownership",reader.ReadState!=ReadState.Closed);}
        Check("database/schemes",DatabaseDocumentLoader.Handles("basex://fixture/db")&&DatabaseDocumentLoader.Handles("exist://fixture/db")&&DatabaseDocumentLoader.Handles("marklogic://fixture/db")&&!DatabaseDocumentLoader.Handles("memory:fixture"));
        DatabaseFixture();
        var names=new[]{"Bosak.XPath.Api","Bosak.XPath.Compiler","Bosak.XPath.Core","Bosak.XPath.Parser","Bosak.XPath.Providers","Bosak.XPath.Runtime","Bosak.XPath.Standard","Bosak.XQuery","Bosak.Xslt","Bosak.XPath.Providers.Database"};
        var identities=names.Select(name=>{var assembly=Assembly.Load(name);Check("assembly/"+name,assembly.GetName().Version!.ToString()=="1.81.17.0");return new{name,version=assembly.GetName().Version!.ToString(),path=assembly.Location,sha256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(assembly.Location))).ToLowerInvariant()};}).ToArray();
        return new{success=true,passed=Cases.Count,failed=0,cases=Cases,assemblies=identities,framework=Environment.Version.ToString(),databaseScope="Loopback BaseX REST fixture plus scheme/dispatch checks; no live BaseX/eXist/MarkLogic acceptance",schemaAwareAcceptance=false,performanceGuarantee=false,packagePublicationAuthorized=false};
    }
}
