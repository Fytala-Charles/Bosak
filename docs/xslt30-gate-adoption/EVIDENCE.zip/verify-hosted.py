"""Retain and independently replay the first hosted gate before adoption."""
import hashlib,importlib.util,json,subprocess,zipfile
from pathlib import Path
packet=Path(__file__).resolve().parent
root=Path('D:/Development/Bosak/.worktrees/Bosak.XsltGate')
repo='Fytala-Charles/Bosak'
def gh(*args): return subprocess.check_output(['gh',*args])
artifacts=json.loads(gh('api',f'repos/{repo}/actions/runs/43291936231/artifacts'))
artifact=next(a for a in artifacts['artifacts'] if a['name']=='xslt30-pinned-gate')
data=gh('api',f'repos/{repo}/actions/artifacts/{artifact["id"]}/zip')
name=packet/'HOSTED-PR477.zip'
assert not name.exists()
name.write_bytes(data)
assert 'sha256:'+hashlib.sha256(data).hexdigest()==artifact['digest']
(packet/'HOSTED-ARTIFACT.json').write_text(json.dumps(artifact,indent=2)+'\n',encoding='utf-8')
spec=importlib.util.spec_from_file_location('gate',root/'tools/xslt30_gate.py')
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
policy,_,inputs,skips=gate.baseline()
with zipfile.ZipFile(name) as archive:
    read=lambda n:json.loads(archive.read(n))
    result,run,plan=read('GATE.json'),read('RUN.json'),read('PLAN.json')
    assert result['success'] and run['success'] and result['counts']==policy['counts']
    assert not any(result['corpusDifferences'].values()) and result['sourceCorpusUnchanged'] and result['runtimeUnchanged']
    assert read('CORPUS-BEFORE.json')==inputs==read('CORPUS-AFTER.json')
    for filename in ['stdout.log','stderr.log']:
        assert hashlib.sha256(archive.read(filename)).hexdigest()==run[filename+'Sha256']
    rows=gate.reconcile(plan,run,archive.read('stdout.log').decode('utf-8-sig'),skips,policy)
    assert len(rows)==14601
    source=json.loads(gh('api',f'repos/{repo}/git/commits/{run["sourceCommit"]}'))
    head_tree=subprocess.check_output(['git','-C',str(root),'rev-parse','1ce924dcf44997d48646b21cbb947667dbf13183^{tree}'],text=True).strip()
    assert source['tree']['sha']==head_tree
    receipt=dict(success=True,counts=result['counts'],totalCases=len(rows),elapsedSeconds=run['elapsedSeconds'],
        sourceCommit=run['sourceCommit'],sourceTree=head_tree,prHeadTreeIdentical=True,
        corpusUnchanged=True,runtimeUnchanged=True,artifactSha256=hashlib.sha256(data).hexdigest())
(packet/'HOSTED-VERIFICATION.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,indent=2))
