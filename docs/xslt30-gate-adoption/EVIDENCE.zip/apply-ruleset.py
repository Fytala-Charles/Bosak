"""Apply the authorized additive rule only after verifying merge, CI and concurrency."""
import json,subprocess
from pathlib import Path
packet=Path(__file__).resolve().parent
repo='Fytala-Charles/Bosak'
endpoint=f'repos/{repo}/rulesets/22255065'
def gh(*args):return json.loads(subprocess.check_output(['gh',*args],encoding='utf-8'))
before=json.loads((packet/'RULESET-BEFORE.json').read_text(encoding='utf-8'))
payload=json.loads((packet/'RULESET-PAYLOAD.json').read_text(encoding='utf-8'))
assert not (packet/'RULESET-AFTER.json').exists()
pr=gh('pr','view','477','--repo',repo,'--json','state,headRefOid,statusCheckRollup')
assert pr['state']=='MERGED' and pr['headRefOid']=='1ce924dcf44997d48646b21cbb947667dbf13183'
assert len(pr['statusCheckRollup'])==6 and all(c['conclusion']=='SUCCESS' for c in pr['statusCheckRollup'])
assert json.loads((packet/'HOSTED-VERIFICATION.json').read_text())['success']
current=gh('api',endpoint)
assert current==before,'Concurrent ruleset change; preserve it rather than overwrite'
after=gh('api','--method','PUT',endpoint,'--input',str(packet/'RULESET-PAYLOAD.json'))
(packet/'RULESET-AFTER.json').write_text(json.dumps(after,indent=2)+'\n',encoding='utf-8')
for key in ['name','target','enforcement','conditions','bypass_actors']:
    assert after[key]==before[key]
old={r['type']:r for r in before['rules']}
new={r['type']:r for r in after['rules']}
assert all(new[k]==v for k,v in old.items())
assert set(new)==set(old)|{'required_status_checks'}
rule=new['required_status_checks']['parameters']
assert rule['required_status_checks']==payload['rules'][-1]['parameters']['required_status_checks']
assert rule['strict_required_status_checks_policy'] is False
live=gh('api',f'repos/{repo}/rules/branches/main')
required=next(r for r in live if r['type']=='required_status_checks')
assert required['ruleset_id']==22255065 and required['parameters']['required_status_checks']==rule['required_status_checks']
(packet/'LIVE-MAIN-RULES.json').write_text(json.dumps(live,indent=2)+'\n',encoding='utf-8')
(packet/'RULESET-VERIFICATION.json').write_text(json.dumps(dict(success=True,originalRulesPreserved=True,
    conditionsAndBypassActorsPreserved=True,activeOnMain=True,requiredCheck=rule['required_status_checks'][0]),indent=2)+'\n',encoding='utf-8')
print('Required gate is active on main; original PR/deletion rules, scope and bypass actors are unchanged.')
