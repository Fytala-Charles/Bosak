"""Prepare one additive required-check rule, retaining the live ruleset unchanged."""
import copy,json,subprocess
from pathlib import Path
packet=Path(__file__).resolve().parent
repo='Fytala-Charles/Bosak'
def gh(*args):
    return json.loads(subprocess.check_output(['gh',*args],encoding='utf-8'))
before=gh('api',f'repos/{repo}/rulesets/22255065')
assert not (packet/'RULESET-BEFORE.json').exists()
checks=gh('api',f'repos/{repo}/commits/1ce924dcf44997d48646b21cbb947667dbf13183/check-runs')
name='Standalone XSLT 3.0 (pinned basic profile)'
check=next(c for c in checks['check_runs'] if c['name']==name)
assert check['app']['slug']=='github-actions'
fields=['name','target','enforcement','conditions','bypass_actors','rules']
payload={k:copy.deepcopy(before[k]) for k in fields}
assert not any(r['type']=='required_status_checks' for r in payload['rules'])
payload['rules'].append(dict(type='required_status_checks',parameters=dict(
    required_status_checks=[dict(context=name,integration_id=check['app']['id'])],
    strict_required_status_checks_policy=False)))
for filename,data in [('RULESET-BEFORE.json',before),('RULESET-PAYLOAD.json',payload),('CHECK-SOURCE.json',check)]:
    (packet/filename).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print('Prepared additive check rule; original deletion/PR rules, conditions and bypass actors preserved.')
