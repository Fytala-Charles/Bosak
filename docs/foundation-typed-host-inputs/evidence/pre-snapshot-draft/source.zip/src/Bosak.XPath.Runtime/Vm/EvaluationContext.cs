// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 19 mei 2026
// PURPOSE              : Runtime evaluation context for XPath expressions. Holds the focus (context item, position, size),...
// SPECIAL NOTES        : Part of the Bosak XPath 3.1 implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      | Charles Korthout | 0.1   | 19-05-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 19-05-2026     | Added document cache and loader for fn:doc / fn:collection                             |
//                      | Charles Korthout | 0.3   | 22-05-2026     | Added stable current-dateTime/date/time snapshot                                       |
//                      | Charles Korthout | 0.4   | 22-05-2026     | Added decimal-format support for fn:format-number                                      |
//                      | Charles Korthout | 0.5   | 24-05-2026     | Added SnapshotVariables / RestoreVariables for lexical scoping                         |
//                      | Charles Korthout | 0.6   | 27-05-2026     | Added DefaultCollation property and WithDefaultCollation helper                        |
//                      | Charles Korthout | 0.7   | 30-05-2026     | Added BackwardsCompatible property for XPath 1.0 general-comparison coercion rules     |
//                      | Charles Korthout | 0.8   | 10-06-2026     | Added LazyVariableResolver and _evaluatedLazyGlobals for deferred XSLT globals         |
//                      | Charles Korthout | 0.9   | 11-06-2026     | TryResolveNamespace resolves predefined xml prefix to XML namespace URI                 |
//                      | Charles Korthout | 1.0   | 13-06-2026     | Added ImplicitTimezoneOffsetMinutes property (defaults to UTC)                          |
//                      | Charles Korthout | 1.1   | 19-07-2026     | CurrentDateTimeSnapshot initializes implicit timezone from snapshot offset when not set |
//                      | Charles Korthout | 1.1   | 13-06-2026     | Added RegexGroups property for xsl:analyze-string / regex-group()                       |
//                      | Charles Korthout | 1.2   | 24-06-2026     | Added DefiningElementDefaultNamespace for element-available default namespace            |
//                      | Charles Korthout | 1.3   | 24-06-2026     | Added DocumentPostProcessor for XSLT whitespace stripping on loaded documents          |
//                      | Charles Korthout | 1.4   | 25-06-2026     | Added InitialTemplateCallParameters/TunnelParameters for named-template entry points   |
//                      | Charles Korthout | 1.5   | 25-06-2026     | Added RegisterDocument to pre-cache source documents for fn:doc identity               |
//                      | Charles Korthout | 1.6   | 25-06-2026     | Added IsStaticEvaluation flag for use-when/static-expression function libraries        |
//                      | Charles Korthout | 1.7   | 26-06-2026     | Added SnapshotLazyGlobals/RestoreLazyGlobals to isolate function-local lazy variables  |
//                      | Charles Korthout | 1.8   | 29-06-2026     | Added SkipLazyGlobalCacheOnce and TryGetBoundVariable for deferred locals              |
//                      | Charles Korthout | 2.0   | 26-06-2026     | Added CurrentOutputUri for fn:current-output-uri                                       |
//                      | Charles Korthout | 1.9   | 26-06-2026     | File-not-found document loads report FODC0002 so xsl:catch can match                    |
//                      | Charles Korthout | 2.1   | 15-07-2026     | Added ResourceUriMapper to redirect published http: resource URIs to local files        |
//                      | Charles Korthout | 2.2   | 15-07-2026     | Added XsltVersion override for fn:system-property('xsl:version')                       |
//                      | Charles Korthout | 2.3   | 18-07-2026     | Added Collections dictionary for fn:collection/fn:uri-collection resolution             |
//                      | Charles Korthout | 2.4   | 20-07-2026     | Added IsXsltMode to expose XSLT-only functions (fn:current, fn:system-property) only in XSLT mode |
//                      | Charles Korthout | 2.5   | 21-07-2026     | Convert UriFormatException/IOException/XmlException to FODC0005/FODC0002 in LoadDocument |
//                      | Charles Korthout | 2.6   | 25-07-2026     | TryResolveFunction falls back to variadic signatures (fn:concat#N for any N >= 2)      |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.7   | 25-07-2026     | Added ElementConstructorHook and ContentNodeConstructorHook for XQuery constructors    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.8   | 25-07-2026     | Added RemoveNamespace; predefined xsi and local namespace prefixes                     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.9   | 25-07-2026     | Added AttributeConstructorHook and DocumentConstructorHook                             |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.10  | 25-07-2026     | Added StaticOutputParameters for XQuery output declarations                            |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.11  | 29-07-2026     | WithNamespace removes the binding on zero-length URI (namespace undeclaration) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.12  | 29-07-2026     | Constructor-local namespace tracking for materialization on built elements |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.13  | 01-08-2026     | Added XQueryModuleSources registry for fn:load-xquery-module resolution |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.14  | 01-08-2026     | Snapshot/restore helpers for module-local decimal formats |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.15  | 15-08-2026     | Added CollectionValues for query-based environment collections in QT3 harness        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.16  | 26-08-2026     | Honor SkipLazyGlobalCacheOnce in TryGetVariable so suppressions don't pollute cache     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.16  | 26-08-2026     | Added DocumentLoaded callback so XSLT can detect XTDE1500 read/write conflicts            |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.17  | 01-09-2026     | Added FunctionLookupInterceptor so XSLT package scopes can filter fn:function-lookup      |
//                      |==================|=======|================|=========================================================================================
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.18  | 02-09-2026     | AccumulatorValueCopier hook so fn:copy-of/fn:snapshot carry accumulator values (accumulator-046/064)|
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.19  | 02-09-2026     | XQueryModuleLoader delegate: hosts supply fn:load-xquery-module's implementation on the context |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.20  | 05-09-2026     | LoadDocument registers loaded trees so cross-tree document order follows load order (evaluate-002) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.21  | 05-09-2026     | Document cache keyed by (URI, DocumentLoadPolicy) so XSLT packages keep distinct stripped trees (document-2401/2402, collection-006) |
//                      | Charles Korthout | 2.22  | 09-09-2026     | Added UnsuppliedExternalVariables (XPDY0002 for declared-but-unbound externals)          |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.23  | 09-09-2026     | XML doc coverage on public API (Beta review)                                             |
//                      | Charles Korthout | 2.24  | 09-09-2026     | Perf: InstallStandardFunctionTable clone-install; indexed variadic resolution (no full-t |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.25  | 16-09-2026     | Streaming Phase C: StreamingDocumentLoader hook for streamable xsl:source-document     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.26  | 21-09-2026     | InStreamingMapContext flag: map constructors inside XSLT streaming constructs raise  |
//                      |                  |       |                | XTDE3365 instead of XQDY0137 on duplicate keys (si-fork-814)                          |
//                      | Charles Korthout | 2.27  | 21-09-2026     | API freeze stage C: pruned engine-state members to internal                             |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.28  | 22-09-2026     | REQ-098 seam H3: ConstructedElementProcessor/ConstructedDocumentProcessor hooks         |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.29  | 01-10-2026     | InStreamedPipeline flag: path-step document-order normalization is suppressed inside    |
//                      |                  |       |                | streamable xsl:source-document bodies (sf-reverse-001)                                   |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.30  | 01-10-2026     | LoadDocument reports FODC0005 for URI references with raw backslashes (non-stream-006)   |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.31  | 01-10-2026     | Backslash FODC0005 check moved to the fn:doc/fn:document/xsl:source-document entry       |
//                      |                  |       |                | points: internal callers (collections, loaders) pass platform paths with backslashes     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.32  | 03-10-2026     | REQ-119: IsSchemaAware flag (set by schema-aware hosts) so fn:json-to-xml can raise    |
//                      |                  |       |                | FOJS0004 for validate:=true() on a non-schema-aware processor                            |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.33  | 03-10-2026     | REQ-120 Slice 3: additive CollectionLoader host hook (SemVer minor) returning member     |
//                      |                  |       |                | document URIs for fn:collection / fn:uri-collection; RegisterTree contract documented    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.34  | 08-10-2026     | REQ-118: internal IsXPath40 flag (4.0-S0 gate) stamped by the Api layer so               |
//                      |                  |       |                | FunctionLibrary.Populate can hide XPath 4.0-only functions from 3.1 contexts             |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.35  | 09-10-2026     | REQ-123: internal IsXPath40Experimental flag (4.0-Exp S1) — exposes                       |
//                      |                  |       |                | IsXPath40ExperimentalOnly functions at the experimental compatibility level              |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.36  | 16-10-2026     | REQ-123 PR1131: TryGetDirectVariable for lexical let scoping (SaveVariables must not   |
//                      |                  |       |                | trigger lazy global resolution — K2-FunctionProlog-15)                                   |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.37  | 10-10-2026     | REQ-125 Slice B: ResourcePolicy + controlled LoadDocument (authority-approved bytes,     |
//                      |                  |       |                | no disk/network fallback, DTD-prohibited parse, per-route purpose tagging)               |
//                      | Charles Korthout | 2.38  | 10-10-2026     | B-F1: policy decision runs before the document cache; cache key carries policy identity  |
//                      |                  |       |                | + route; B-F2: static-phase loads request StaticEvaluation purpose with concrete route   |
//                      | Charles Korthout | 2.39  | 10-10-2026     | B-F3: controlled cache entries store content SHA-256 + effective URI; hits are digest-    |
//                      |                  |       |                | validated and receipts carry ServedFromCache; changed bytes/effective URI refresh        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.40  | 10-10-2026     | REQ-125 Slice D: internal ExecutionGate (token/deadline/operation-budget checkpoints)     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.41  | 11-10-2026     | Preserve and enforce frozen profile boundaries in mixed-version XSLT execution.        |
//                      | Charles Korthout | 2.42  | 13-10-2026     | Store package-local nominative record identities for host type resolution.               |
//                      | Charles Korthout | 2.43 | 13-10-2026     | Store package-local enumeration aliases for XSLT declaration conversion
//                      | Charles Korthout | 2.44 | 13-10-2026     | Store structural binding aliases alongside enumeration aliases
//                      | Charles Korthout | 2.45 | 13-10-2026     | Carry a package-local host callback for nominative record coercion
//                      | Charles Korthout | 2.46 | 13-10-2026     | Distinguish nominative record casting from coercion in the host callback
//                      | Charles Korthout | 2.47  | 15-10-2026     | Snapshot and restore hidden bound aliases without capturing ordinary function registries. |
//                      | Charles Korthout | 2.48  | 18-10-2026     | Correct build-warning documentation and nullable-flow diagnostics.                     |
//                      |==================|=======|================|=========================================================================================

//                      | Charles Korthout | 2.49  | 28-10-2026     | Add internal semantic-focus resolution and per-variable lazy-cache invalidation for XQuery. |
//                      | Charles Korthout | 2.50  | 01-11-2026     | Add nonreflective bounded private input capture. |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Runtime.Functions;
using Bosak.XPath.Runtime.Resources;
using Bosak.XPath.Providers.Xml;
using System.IO;
using System.Xml;
using System.Xml.Schema;

namespace Bosak.XPath.Runtime.Vm;

/// <summary>
/// Runtime evaluation context for XPath expressions.
/// Holds the focus (context item, position, size), variable bindings,
/// namespace resolution, and function libraries.
/// </summary>
public sealed class EvaluationContext
{
    // Focus
    private XdmValue _contextItem;
    private int _contextPosition;
    private int _contextSize;

    // Current item for fn:current() (XSLT current node)
    private XdmValue _currentItem = XdmValue.Undefined;

    // Variable bindings: QName key -> XdmValue
    private readonly Dictionary<(string LocalName, string NamespaceUri), XdmValue> _variables;

    // Cache for evaluated lazy variables (e.g. XSLT global variables with sequence constructors).
    // Survives RestoreVariables so once-evaluated globals remain available across template scopes.
    private readonly Dictionary<(string LocalName, string NamespaceUri), XdmValue> _evaluatedLazyGlobals;

    /// <summary>
    /// Optional callback for lazy variable resolution. Invoked when a variable is not found
    /// in <see cref="_variables"/> but a lazy resolver is registered. This enables XSLT global
    /// variables with sequence constructors to be evaluated on first reference.
    /// </summary>
    public Func<string, string, XdmValue?>? LazyVariableResolver { get; set; }

    /// <summary>
    /// When true, values returned by <see cref="LazyVariableResolver"/> are not cached in
    /// <see cref="_evaluatedLazyGlobals"/>. Used by XSLT function calls to keep function-local
    /// lazy variables from leaking into the global cache.
    /// </summary>
    internal bool SuppressLazyGlobalCaching { get; set; }

    /// <summary>
    /// When set to <c>true</c>, the next value returned by <see cref="LazyVariableResolver"/>
    /// will not be cached in <see cref="_evaluatedLazyGlobals"/>, but the flag is then reset.
    /// This allows a resolver to suppress caching for a specific resolution (e.g. a function-local
    /// variable) while still letting globals cache normally.
    /// </summary>
    internal bool SkipLazyGlobalCacheOnce { get; set; }

    /// <summary>
    /// When true, the lazy variable resolver will only evaluate globals that have a <c>@select</c>
    /// attribute. Globals with sequence-constructor bodies are left unresolved. This is used during
    /// pattern validation so that globals whose value depends on the source document or template
    /// matching are not materialized prematurely.
    /// </summary>
    internal bool SuppressLazySequenceConstructorGlobals { get; set; }

    /// <summary>
    /// When true, <c>Bosak.XPath.Standard.Functions.FunctionLibrary.Populate</c> will not
    /// be called automatically by <c>XPath31Expression.Evaluate</c>. Used by XSLT's
    /// <c>xsl:evaluate</c> to supply a restricted function library.
    /// </summary>
    internal bool SkipStandardFunctionPopulation { get; set; }

    /// <summary>
    /// Names of variables declared <c>external</c> in the XQuery prolog for which the host
    /// supplied no value and no default exists. Referencing such a variable is a dynamic
    /// error (XPDY0002), not a static "not defined" error (XPST0008) — XQuery 3.1 §4.16.
    /// </summary>
    public HashSet<(string LocalName, string NamespaceUri)> UnsuppliedExternalVariables { get; } = new();

    /// <summary>
    /// Optional collation-aware string comparer used by XPath comparison operators.
    /// Arguments are (left, right, collationUri); returns a value with the same sign
    /// conventions as <see cref="string.Compare(string, string)"/>.
    /// </summary>
    public Func<string, string, string, int>? CollationComparer { get; set; }

    /// <summary>
    /// Provider hook for XQuery element constructors. When set, the ConstructElement
    /// opcode builds nodes through it; when null, element construction raises an error.
    /// The API layers register an XDocument-based implementation by default.
    /// </summary>
    public Func<XdmElementSpec, IXdmNode>? ElementConstructorHook { get; set; }

    /// <summary>
    /// Provider hook for standalone comment and processing-instruction constructors.
    /// The API layers register an XDocument-based implementation by default.
    /// </summary>
    public Func<XdmContentItem, IXdmNode>? ContentNodeConstructorHook { get; set; }

    /// <summary>
    /// Provider hook for computed attribute constructors (free-standing attribute nodes).
    /// The API layers register an XDocument-based implementation by default.
    /// </summary>
    public Func<XdmAttributeValue, IXdmNode>? AttributeConstructorHook { get; set; }

    /// <summary>
    /// Provider hook for computed document constructors. The API layers register an
    /// XDocument-based implementation by default.
    /// </summary>
    public Func<IReadOnlyList<XdmContentItem>, IXdmNode>? DocumentConstructorHook { get; set; }

    /// <summary>
    /// Static output declarations from an XQuery prolog (<c>declare option output:* "..."</c>),
    /// keyed by (namespace URI, local name). QName-valued parameters
    /// (cdata-section-elements, suppress-indentation) carry space-separated expanded
    /// <c>{uri}local</c> tokens. Consumed by <c>fn:serialize</c> as default serialization
    /// parameters.
    /// </summary>
    internal IReadOnlyDictionary<(string NamespaceUri, string LocalName), string>? StaticOutputParameters { get; set; }

    // Namespace prefixes
    private readonly Dictionary<string, string> _namespaces;

    // Function libraries, indexed by (namespace, localName, arity)
    private Dictionary<(string, string, int), FunctionSignature> _functions;

    // Variadic function index: (namespace, localName) -> minimum declared arity, so an
    // exact-arity lookup miss resolves variadic candidates without a full table scan.
    private readonly Dictionary<(string, string), int> _variadicMinArity = new();

    // Document cache for fn:doc / fn:collection identity.
    // Legacy (no controlled policy) entries are keyed by (URI, load policy) exactly as
    // before REQ-125: the policy slot lets an XSLT host keep a distinct stripped tree per
    // distinct xsl:strip-space / xsl:preserve-space rule set (XSLT 3.0 §2.13.4), and the
    // two trailing slots are (null, Document) constants. Legacy entries never carry digest
    // evidence (null slots) — the legacy path never consults it.
    // Controlled-profile entries add the effective policy identity (the ControlledResourcePolicy
    // instance, which owns its authority) and the purpose route: cached content must never
    // bypass the requested route's authority decision or unsupported-route check (consumer
    // review B-F1), and content approved for one route or authority is never served to a
    // different route or authority. Each controlled entry also stores the SHA-256 of the
    // bytes its node was parsed from and the effective URI they were acquired under: a cache
    // hit is served only when the newly approved bytes digest-match the entry (and the
    // effective URI agrees), otherwise the fresh bytes are parsed and the entry replaced —
    // so the acquisition receipt always describes the content actually returned
    // (consumer review B-F3).
    private readonly Dictionary<(string Uri, object? LoadPolicy, object? ControlledPolicy, ControlledResourceRoute Route), DocumentCacheEntry> _documentCache;

    /// <summary>
    /// One document-cache entry: the parsed node plus, for controlled-profile entries, the
    /// provenance evidence (SHA-256 of the bytes the node was parsed from, and the effective
    /// URI they were acquired under). Legacy entries leave both null.
    /// </summary>
    private sealed class DocumentCacheEntry
    {
        public DocumentCacheEntry(IXdmNode node, string? sha256, string? effectiveUri)
        {
            Node = node;
            Sha256 = sha256;
            EffectiveUri = effectiveUri;
        }

        public IXdmNode Node { get; }

        /// <summary>SHA-256 of the bytes <see cref="Node"/> was parsed from; null for legacy entries.</summary>
        public string? Sha256 { get; }

        /// <summary>Effective URI the bytes were acquired under; null for legacy entries.</summary>
        public string? EffectiveUri { get; }
    }

    // XML Schema set for schema-aware kind tests and typed values.
    private XmlSchemaSet? _schemaSet;

    /// <summary>
    /// Optional resolver used to load schemas referenced by <c>import schema</c>.
    /// Arguments are the target namespace URI and the ordered location hints;
    /// returns a stream for the schema content or null when the schema cannot be located.
    /// </summary>
    public Func<string, IReadOnlyList<string>, Stream?>? SchemaResolver { get; set; }

    // Stable snapshot for current-dateTime / current-date / current-time
    private DateTimeOffset? _currentDateTimeSnapshot;
    private bool _implicitTimezoneOffsetSet;

    // Decimal formats for fn:format-number
    private DecimalFormat _defaultDecimalFormat = new();
    private readonly Dictionary<(string LocalName, string NamespaceUri), DecimalFormat> _namedDecimalFormats;

    /// <summary>
    /// Creates an evaluation context with an empty focus, no variables, and the predefined
    /// namespace bindings (<c>xml</c>, <c>xs</c>, <c>xsi</c>, <c>fn</c>, <c>math</c>,
    /// <c>map</c>, <c>array</c>, <c>local</c>, <c>err</c>).
    /// </summary>
    public EvaluationContext()
    {
        _contextItem = XdmValue.Undefined;
        _contextPosition = 0;
        _contextSize = 0;
        _variables = new Dictionary<(string, string), XdmValue>();
        _evaluatedLazyGlobals = new Dictionary<(string, string), XdmValue>();
        _namespaces = new Dictionary<string, string>
        {
            ["xml"] = "http://www.w3.org/XML/1998/namespace",
            ["xs"] = "http://www.w3.org/2001/XMLSchema",
            ["xsi"] = "http://www.w3.org/2001/XMLSchema-instance",
            ["fn"] = "http://www.w3.org/2005/xpath-functions",
            ["math"] = "http://www.w3.org/2005/xpath-functions/math",
            ["map"] = "http://www.w3.org/2005/xpath-functions/map",
            ["array"] = "http://www.w3.org/2005/xpath-functions/array",
            ["local"] = "http://www.w3.org/2005/xquery-local-functions",
            ["err"] = "http://www.w3.org/2005/xqt-errors"
        };
        _functions = new Dictionary<(string, string, int), FunctionSignature>();
        _documentCache = new Dictionary<(string Uri, object? LoadPolicy, object? ControlledPolicy, ControlledResourceRoute Route), DocumentCacheEntry>();
        _namedDecimalFormats = new Dictionary<(string, string), DecimalFormat>();
    }

    /// <summary>Captures the bounded data-only profile; services and populated execution state refuse.</summary>
    internal SchemaOperationInputs CaptureSchemaInputs(Func<IXdmNode, bool> ownsNode, int maxBindings, int maxNamespaces)
    {
        ArgumentNullException.ThrowIfNull(ownsNode);
        if (maxBindings <= 0) throw new ArgumentOutOfRangeException(nameof(maxBindings));
        if (maxNamespaces <= 0) throw new ArgumentOutOfRangeException(nameof(maxNamespaces));
        if (LazyVariableResolver is not null || SuppressLazyGlobalCaching || SkipLazyGlobalCacheOnce
            || SuppressLazySequenceConstructorGlobals || SkipStandardFunctionPopulation || UnsuppliedExternalVariables.Count != 0
            || CollationComparer is not null || ElementConstructorHook is not null || ContentNodeConstructorHook is not null
            || AttributeConstructorHook is not null || DocumentConstructorHook is not null || StaticOutputParameters is not null
            || _evaluatedLazyGlobals.Count != 0 || _functions.Count != 0 || _variadicMinArity.Count != 0 || _documentCache.Count != 0
            || _schemaSet is not null || SchemaResolver is not null || _currentDateTimeSnapshot is not null
            || _implicitTimezoneOffsetSet || _implicitTimezoneOffsetMinutes != 0 || _namedDecimalFormats.Count != 0
            || CurrentOutputUri is not null || IsStaticEvaluation || IsXPath40 || IsXPath40Experimental || IsXsltMode
            || NamedRecordCoercion is not null || !EmptyOrdinal(NamedRecordTypes) || !EmptyOrdinal(BindingItemTypes)
            || InStreamingMapContext || InStreamedPipeline || Xml11Mode || RegexGroups is not null || ResourcePolicy is not null
            || ExecutionGate is not null || DocumentLoader is not null || StreamingDocumentLoader is not null || ResourceUriMapper is not null
            || CollectionLoader is not null || Collections.Count != 0 || CollectionValues.Count != 0 || XQueryModuleSources.Count != 0
            || XQueryModuleLoader is not null || DocumentPostProcessor is not null || ConstructedElementProcessor is not null
            || ConstructedDocumentProcessor is not null || DocumentLoadPolicy is not null || BackwardsCompatible || XsltVersion is not null
            || InitialTemplateCallParameters is not null || InitialTemplateTunnelParameters is not null || DocumentLoaded is not null
            || AccumulatorValueCopier is not null || InitialFocusResolver is not null || !_currentItem.IsUndefined
            || _constructorLocalNamespaces.Count != 0 || FunctionLookupInterceptor is not null || !DefaultFormat(_defaultDecimalFormat))
            throw new NotSupportedException("Context services or nondefault execution state require a separate capture profile.");
        if (_variables.Count > maxBindings || _namespaces.Count > maxNamespaces)
            throw new NotSupportedException("Input binding or namespace limit reached.");
        if (_contextItem.IsUndefined ? _contextPosition != 0 || _contextSize != 0
            : !_contextItem.IsNode || _contextPosition < 1 || _contextSize < _contextPosition)
            throw new NotSupportedException("Invalid bounded node focus.");
        if (_contextItem.IsNode && !ownsNode(_contextItem.NodeValue!))
            throw new NotSupportedException("Unadmitted focus node.");
        foreach (var value in _variables.Values)
        {
            if (value.IsNode)
            {
                if (!ownsNode(value.NodeValue!)) throw new NotSupportedException("Unadmitted variable node.");
            }
            else if (value.Kind is not (XdmValueKind.Integer or XdmValueKind.Decimal or XdmValueKind.Double
                or XdmValueKind.Float or XdmValueKind.Boolean or XdmValueKind.String))
                throw new NotSupportedException("Only direct scalar or admitted node bindings are supported.");
        }
        return new SchemaOperationInputs(_contextItem, _contextPosition, _contextSize, _variables.ToArray(), _namespaces.ToArray(),
            BaseUri, DefaultElementNamespace, DefiningElementDefaultNamespace, DefaultCollation);

        static bool EmptyOrdinal<T>(IReadOnlyDictionary<string, T> values)
            => values is Dictionary<string, T> dictionary && values.GetType() == typeof(Dictionary<string, T>) && dictionary.Count == 0
                && (ReferenceEquals(dictionary.Comparer, StringComparer.Ordinal) || ReferenceEquals(dictionary.Comparer, EqualityComparer<string>.Default));
        static bool DefaultFormat(DecimalFormat? value) => value is not null && value.DecimalSeparator == "." && value.GroupingSeparator == ","
            && value.Digit == "#" && value.ZeroDigit == "0" && value.PatternSeparator == ";" && value.MinusSign == "-"
            && value.Percent == "%" && value.PerMille == "\u2030" && value.Infinity == "Infinity" && value.NaN == "NaN" && value.ExponentSeparator == "e";
    }

    /// <summary>
    /// Optional base URI used to resolve relative document URIs.
    /// </summary>
    public string? BaseUri { get; set; }

    /// <summary>
    /// The URI of the current output destination in XSLT. Empty or null when the
    /// evaluation is in a temporary output state (e.g., inside xsl:variable, a
    /// stylesheet function, a sort key, or a pattern predicate).
    /// </summary>
    internal string? CurrentOutputUri { get; set; }

    /// <summary>
    /// When true, the expression is being evaluated in a static context (e.g. a
    /// <c>use-when</c> attribute or a static variable select expression). Function
    /// availability checks restrict the function library to context-independent
    /// functions.
    /// </summary>
    public bool IsStaticEvaluation { get; set; }

    /// <summary>
    /// When true, the host compilation targeted XPath 4.0 and the standard function
    /// table may expose XPath 4.0-only functions. The Api layer
    /// (<c>XPath31Expression</c>) stamps this from
    /// <c>CompileOptions.Compatibility</c> before populating the context. XSLT
    /// selects frozen 4.0 for expressions owned by effective-version 4.0 elements;
    /// earlier XSLT elements and XQuery 3.1 retain their existing 3.1 profile.
    /// The Runtime layer cannot reference the Api enum
    /// (<c>XPathCompatibility</c>) due to project layering, so
    /// the version knowledge crosses the layer boundary as this flag (REQ-118
    /// version gate, slice 4.0-S0).
    /// </summary>
    internal bool IsXPath40 { get; set; }

    // Package-local nominative record identities installed by the XSLT host.
    internal IReadOnlyDictionary<string, XdmRecordType> NamedRecordTypes { get; set; }
        = new Dictionary<string, XdmRecordType>(StringComparer.Ordinal);

    internal Func<XdmRecordType, XdmMap, bool, XdmMap>? NamedRecordCoercion { get; set; }

    // Package-local item-type binding aliases installed by the XSLT host.
    internal IReadOnlyDictionary<string, string> BindingItemTypes { get; set; }
        = new Dictionary<string, string>(StringComparer.Ordinal);

    internal bool TryResolveNamedRecordType(string name, string? defaultNamespace, out XdmRecordType? type)
    {
        type = null;
        if (!IsXPath40)
            return false;
        var key = name.Trim();
        if (!key.StartsWith("Q{", StringComparison.Ordinal))
        {
            var colon = key.IndexOf(':');
            var ns = defaultNamespace ?? string.Empty;
            if (colon >= 0)
            {
                if (!TryResolveNamespace(key[..colon], out ns))
                    return false;
                key = key[(colon + 1)..];
            }
            key = $"Q{{{ns}}}{key}";
        }
        return NamedRecordTypes.TryGetValue(key, out type);
    }

    /// <summary>
    /// When true, the standard function table may additionally expose
    /// not-yet-stabilized XPath 4.0 draft additions (functions marked
    /// <c>FunctionSignature.IsXPath40ExperimentalOnly</c>). Stamped by the Api layer
    /// from <c>CompileOptions.Compatibility &gt;= XPathCompatibility.XPath40Experimental</c>;
    /// XSLT and XQuery hosts leave it <c>false</c>. Implies <see cref="IsXPath40"/>
    /// (REQ-123, 4.0-Exp S1).
    /// </summary>
    internal bool IsXPath40Experimental { get; set; }

    /// <summary>
    /// When true, the evaluation is being performed by the XSLT processor and
    /// XSLT-only functions such as <c>fn:current</c> and <c>fn:system-property</c>
    /// are available. XPath-only contexts leave this false.
    /// </summary>
    internal bool IsXsltMode { get; set; }

    /// <summary>
    /// When true, map constructors are evaluated inside an XSLT streaming construct
    /// (e.g. an <c>xsl:fork</c> branch), where a duplicate key raises the XSLT error
    /// XTDE3365 instead of the XQuery map-constructor error XQDY0137 (XSLT 3.0 §19
    /// streamability rules; si-fork-814). Set and restored by the XSLT engine.
    /// </summary>
    internal bool InStreamingMapContext { get; set; }

    /// <summary>
    /// When true, the evaluation runs inside a <c>streamable="yes"</c>
    /// <c>xsl:source-document</c> body. Within a streamed pipeline the engine keeps
    /// order-sensitive sequences (for example the result of <c>fn:reverse</c>) in
    /// encounter order instead of re-sorting path-step results into document order,
    /// matching the XSLT 3.0 streaming reference behavior (sf-reverse-001). Set and
    /// restored by the XSLT engine.
    /// </summary>
    internal bool InStreamedPipeline { get; set; }

    /// <summary>
    /// When true, XML 1.1 semantics apply: prefixed namespace undeclarations
    /// (<c>xmlns:p=""</c>) are accepted in element constructors instead of raising
    /// XQST0085. This is set by the host based on the document's declared XML version.
    /// </summary>
    public bool Xml11Mode { get; set; }

    /// <summary>
    /// The implicit timezone offset in minutes used when a date, time, or dateTime value
    /// has no explicit timezone. Defaults to UTC (0 minutes).
    /// </summary>
    public int ImplicitTimezoneOffsetMinutes
    {
        get => _implicitTimezoneOffsetMinutes;
        set
        {
            _implicitTimezoneOffsetMinutes = value;
            _implicitTimezoneOffsetSet = true;
        }
    }
    private int _implicitTimezoneOffsetMinutes;

    /// <summary>
    /// Captured substring values for the current <c>xsl:analyze-string</c> matching substring,
    /// indexed by group number (0 is the whole match). Used by <c>regex-group()</c>.
    /// </summary>
    internal string[]? RegexGroups { get; set; }

    /// <summary>
    /// Optional controlled resource policy (REQ-125 Slice B). When set, every document load
    /// through <see cref="LoadDocument(string, ControlledResourceRoute)"/> is authorized by the
    /// policy's host authority: approved bytes are parsed with DTD processing prohibited and
    /// no disk/network fallback is performed on denial, abstention or callback errors. When
    /// null (the default), behavior is unchanged. Nested evaluation contexts (fn:transform,
    /// xsl:evaluate, streaming pipelines) inherit the same policy instance so receipts and
    /// refusals stay authoritative across nesting.
    /// </summary>
    public ControlledResourcePolicy? ResourcePolicy { get; set; }

    /// <summary>
    /// Optional execution gate (REQ-125 Slice D): cooperative cancellation token, wall-clock
    /// deadline and engine-operation budget for one controlled run. When set, engine checkpoint
    /// seams observe it and terminate the run with a classified interrupt when a control trips.
    /// When null (the default), no checkpoint overhead exists. Nested evaluation contexts
    /// (fn:transform) inherit the same gate instance so nested calls share the remaining budget
    /// and deadline; a gate is stamped for the duration of one run only and cleared afterwards,
    /// so sequential reuse of a context never leaks state between runs.
    /// </summary>
    internal ExecutionGate? ExecutionGate { get; set; }

    /// <summary>
    /// Custom document loader. If null, fn:doc will throw unless the API layer provides one.
    /// </summary>
    public Func<string, IXdmNode>? DocumentLoader { get; set; }

    /// <summary>
    /// Optional loader for <c>xsl:source-document streamable="yes"</c>: receives the absolute,
    /// resource-mapped document URI and returns a forward-only (burst-mode) streamed document
    /// node, typically via <c>XmlStreamingProvider.Load</c>. When null, the XSLT engine opens
    /// <c>file:</c> URIs and local paths itself. Streamed documents are never cached because
    /// they are single-pass.
    /// </summary>
    public Func<string, IXdmNode>? StreamingDocumentLoader { get; set; }

    /// <summary>
    /// Optional mapper that translates a requested resource URI (for example an <c>http:</c> URI
    /// published by a test suite) to a local file path. Returns <c>null</c> when the URI is not
    /// mapped. Consulted by fn:doc, fn:json-doc, fn:unparsed-text(-available/-lines), and
    /// fn:transform's stylesheet-location before any filesystem/network access.
    /// </summary>
    public Func<string, string?>? ResourceUriMapper { get; set; }

    /// <summary>
    /// Optional host hook that resolves a collection URI to the member document URIs of the
    /// collection (for example <c>basex://host/db/coll</c> → the document URIs listed by the
    /// database's REST API). Consulted by fn:collection and fn:uri-collection when the
    /// collection is neither a precomputed environment collection
    /// (<see cref="CollectionValues"/>) nor a registered collection (<see cref="Collections"/>).
    /// </summary>
    /// <remarks>
    /// <para>
    /// The delegate receives the collection URI exactly as requested, absolutized against
    /// <see cref="BaseUri"/> when relative; for <c>fn:collection()</c> with no argument it
    /// receives the empty string (the default collection). Query and fragment components
    /// (for example <c>?select=*.xml</c>) are passed through unstripped — interpreting them
    /// is the hook's responsibility.
    /// </para>
    /// <para>
    /// Return the member document URIs (or absolute file paths) in the collection's
    /// document order; each member is then loaded through <see cref="LoadDocument(string)"/>, so
    /// document identity caching, the per-load-policy cache, and whitespace/strip-space
    /// post-processing behave exactly as for documents loaded by fn:doc. Cross-tree document
    /// order follows load order (the creation-sequence model): the order in which the member
    /// URIs are returned is the order in which the documents enter the creation sequence, so
    /// the hook controls the collection's document-order story. Return <c>null</c> to decline
    /// the URI (falling through to the built-in directory collections and then FODC0002);
    /// return an empty list for a collection that exists but contains no documents.
    /// </para>
    /// <para>
    /// Member load failures surface with the same FODC0002/FODC0005 mapping as fn:doc.
    /// The hook is additive: when unset, collection resolution is bit-identical to a host
    /// that never sets it.
    /// </para>
    /// </remarks>
    public Func<string, IReadOnlyList<string>?>? CollectionLoader { get; set; }

    /// <summary>
    /// Collection URI resolver. Keys are absolute collection URIs (the empty string key
    /// designates the default collection); values are the absolute URIs or file paths of the
    /// documents in the collection. Used by fn:collection and fn:uri-collection.
    /// </summary>
    internal Dictionary<string, IReadOnlyList<string>> Collections { get; } = new();

    /// <summary>
    /// Precomputed collection values declared by environment &lt;collection&gt;&lt;query&gt; elements.
    /// Keys are collection URIs (empty string for the default collection); values are the
    /// already-evaluated XDM sequences. Checked before <see cref="Collections"/> by
    /// fn:collection / fn:uri-collection.
    /// </summary>
    internal Dictionary<string, XdmValue> CollectionValues { get; } = new();

    /// <summary>
    /// XQuery library-module sources available to fn:load-xquery-module, keyed by the
    /// module's target namespace URI. Each entry lists candidate sources with an optional
    /// location hint (matched by the import's <c>at</c> clause or the load options'
    /// <c>location-hints</c>). When no candidate matches a requested URI, the loader falls
    /// back to treating the URI as a filesystem path relative to the static base URI.
    /// </summary>
    internal Dictionary<string, List<(string? Location, string Source)>> XQueryModuleSources { get; } = new(StringComparer.Ordinal);

    /// <summary>
    /// Host-language loader for <c>fn:load-xquery-module</c> (F&amp;O 3.1 §15.3.1). The
    /// standard function library always registers a resolvable stub for the two arities;
    /// the stub dispatches through this delegate at invocation time, so hosts that
    /// support module loading (XQuery, XSLT) set it on their evaluation context. A null
    /// loader makes every invocation raise FOQM0001. The delegate survives repeated
    /// re-population of the standard function library (which would otherwise overwrite a
    /// registry-level replacement), because it lives on the context, not in the registry.
    /// </summary>
    internal XPathFunction? XQueryModuleLoader { get; set; }

    /// <summary>
    /// Optional post-processor applied to documents loaded through <see cref="DocumentLoader"/>.
    /// Used by XSLT to apply xsl:strip-space / xsl:preserve-space rules to documents
    /// returned by fn:doc and fn:document.
    /// </summary>
    public Func<IXdmNode, IXdmNode>? DocumentPostProcessor { get; set; }

    /// <summary>
    /// Optional processor invoked by XSLT after an element's content has been fully
    /// constructed (attributes and children attached). Consulted only when non-null;
    /// invoked exactly once per constructed element, bottom-up (innermost element first),
    /// with the constructed element node. Intended for schema annotation of constructed
    /// nodes (e.g. attaching PSVI via <c>XdmSchemaAnnotator.ValidateSubtree</c>); core
    /// behavior is bit-identical when unset.
    /// </summary>
    public Action<IXdmNode>? ConstructedElementProcessor { get; set; }

    /// <summary>
    /// Optional processor invoked by XSLT at a result-document boundary, after the final
    /// result document has been assembled. Consulted only when non-null; invoked with the
    /// constructed document node. Intended for schema annotation of the complete result
    /// tree; core behavior is bit-identical when unset.
    /// </summary>
    public Action<IXdmNode>? ConstructedDocumentProcessor { get; set; }

    /// <summary>
    /// Optional identity object describing the whitespace-stripping policy of the code
    /// currently performing a document load (XSLT 3.0 §2.13.4: the strip/preserve rules
    /// of the package whose code calls fn:doc / fn:document / fn:collection apply).
    /// The document cache is keyed by (URI, policy), so the same URI loaded under
    /// different policies yields distinct trees. The default (null) is the host's
    /// default policy, shared with documents registered via <see cref="RegisterDocument"/>.
    /// </summary>
    internal object? DocumentLoadPolicy { get; set; }

    /// <summary>
    /// When true, XPath comparisons use XSLT 1.0 / XPath 1.0 backwards-compatible
    /// coercion rules (e.g., string-to-boolean, number-to-boolean in general comparisons).
    /// </summary>
    public bool BackwardsCompatible { get; set; }

    /// <summary>
    /// Optional override for the effective XSLT version reported by
    /// <c>fn:system-property('xsl:version')</c> during a transformation.
    /// </summary>
    internal double? XsltVersion { get; set; }

    /// <summary>
    /// The default element namespace URI for unprefixed element and type names.
    /// When set, <see cref="TryResolveNamespace"/> returns this value for the empty prefix.
    /// </summary>
    public string? DefaultElementNamespace { get; set; }

    /// <summary>
    /// The default namespace URI of the element that contains the XPath expression.
    /// Used by XSLT's <c>fn:element-available</c> to expand unprefixed lexical QNames
    /// per the XSLT specification, which differs from the XPath default element namespace.
    /// </summary>
    public string? DefiningElementDefaultNamespace { get; set; }

    /// <summary>
    /// Optional call parameters supplied for the initial named-template entry point.
    /// Keys are expanded QNames in Clark notation (<c>{uri}local</c> or <c>local</c>);
    /// values are the corresponding XDM values.
    /// </summary>
    internal Dictionary<string, XdmValue>? InitialTemplateCallParameters { get; set; }

    /// <summary>
    /// Optional tunnel parameters supplied for the initial named-template entry point.
    /// Keys are expanded QNames in Clark notation (<c>{uri}local</c> or <c>local</c>);
    /// values are the corresponding XDM values.
    /// </summary>
    internal Dictionary<string, XdmValue>? InitialTemplateTunnelParameters { get; set; }

    /// <summary>
    /// Optional callback invoked with the resolved absolute URI whenever a document
    /// is loaded or registered. Used by XSLT to detect XTDE1500 read/write conflicts.
    /// </summary>
    public Action<string>? DocumentLoaded { get; set; }

    /// <summary>
    /// Loads a document by URI, using the cache and <see cref="DocumentLoader"/>.
    /// </summary>
    /// <param name="uri">The document URI; relative URIs are resolved against <see cref="BaseUri"/>.</param>
    /// <returns>The (cached) document node for the URI.</returns>
    /// <exception cref="InvalidOperationException">No document loader is configured, or the
    /// document cannot be loaded (reported with error code FODC0002 or FODC0005).</exception>
    /// <remarks>
    /// Documents backed by <c>XDocumentNode</c> are eagerly registered in the global
    /// creation sequence in load order, so cross-tree document order follows load order.
    /// Foreign node providers (any other <see cref="IXdmNode"/> implementation) keep their
    /// own document-order story: they are cached and returned unchanged, and cross-tree
    /// ordering then follows the provider's <see cref="IXdmNode.DocumentOrder"/> semantics
    /// rather than the load sequence — providers that need creation-sequence ordering must
    /// implement it themselves.
    /// </remarks>
    public IXdmNode LoadDocument(string uri)
        => LoadDocument(uri, ControlledResourceRoute.Document);

    /// <summary>
    /// Loads a document by URI for the supplied acquisition route, using the cache and —
    /// unless a <see cref="ResourcePolicy"/> is attached — <see cref="DocumentLoader"/>.
    /// </summary>
    /// <param name="uri">The document URI; relative URIs are resolved against <see cref="BaseUri"/>.</param>
    /// <param name="route">The acquisition route (purpose) the load is performed for; recorded on
    /// the policy receipts when a controlled policy is attached. Under a controlled policy the
    /// route's decision (authority approval or unsupported-route refusal) runs on every call,
    /// before any cached content is served, and the cache is scoped to the policy identity and
    /// route; during static evaluation (<see cref="IsStaticEvaluation"/>) the governing route is
    /// <see cref="ControlledResourceRoute.StaticEvaluation"/> with the requested route preserved
    /// as the concrete route.</param>
    /// <returns>The (cached) document node for the URI.</returns>
    /// <remarks>
    /// Under a controlled policy, cache hits are digest-validated (REQ-125 consumer review B-F3):
    /// each controlled cache entry remembers the SHA-256 of the bytes its node was parsed from
    /// and the effective URI they were acquired under. A repeated load is served from the cache
    /// — preserving document identity — only while the newly approved bytes digest-match the
    /// entry and the effective URI agrees; the approval receipt is then marked
    /// <see cref="ControlledResourceReceipt.ServedFromCache"/>. When the authority approves
    /// different bytes or a different effective URI for the same key, the fresh bytes are parsed
    /// into a new node that replaces the entry, so the receipt always describes the content
    /// actually returned. The no-policy path is unchanged: the cache serves the URI's tree
    /// regardless of content changes.
    /// </remarks>
    /// <exception cref="InvalidOperationException">No document loader is configured, the document
    /// cannot be loaded (FODC0002/FODC0005), or — under a controlled policy — the authority refused
    /// the acquisition (XV0004/XV0005). A refusal never triggers a disk/network fallback.</exception>
    public IXdmNode LoadDocument(string uri, ControlledResourceRoute route)
    {
        if (ResourcePolicy is { } policy)
            return LoadDocumentControlled(uri, route, policy);

        if (DocumentLoader is null)
            throw new InvalidOperationException($"No document loader configured. Cannot load document: {uri}");

        IXdmNode node;
        try
        {
            // Backslash (URI-reference) validation lives at the fn:doc/fn:document and
            // xsl:source-document entry points, not here: internal callers (collections,
            // loaders) pass platform file paths that legitimately contain backslashes.

            if (!Uri.IsWellFormedUriString(uri, UriKind.Absolute) && !string.IsNullOrEmpty(BaseUri))
            {
                uri = new Uri(new Uri(BaseUri), uri).AbsoluteUri;
            }

            if (_documentCache.TryGetValue((uri, DocumentLoadPolicy, null, ControlledResourceRoute.Document), out var cached))
            {
                DocumentLoaded?.Invoke(uri);
                return cached.Node;
            }

            // A resource mapper may redirect published (e.g. http:) URIs to local files;
            // the cache key remains the originally requested URI.
            var loadUri = ResourceUriMapper?.Invoke(uri) ?? uri;
            node = DocumentLoader(loadUri);
        }
        catch (FileNotFoundException)
        {
            throw new InvalidOperationException($"FODC0002: Document not available: {uri}");
        }
        catch (DirectoryNotFoundException)
        {
            throw new InvalidOperationException($"FODC0002: Document not available: {uri}");
        }
        catch (UriFormatException)
        {
            throw new InvalidOperationException($"FODC0005: Invalid document URI: {uri}");
        }
        catch (IOException)
        {
            throw new InvalidOperationException($"FODC0002: Document not available: {uri}");
        }
        catch (XmlException)
        {
            throw new InvalidOperationException($"FODC0002: Document not available: {uri}");
        }

        return CacheLoadedDocument((uri, DocumentLoadPolicy, null, ControlledResourceRoute.Document), uri, node);
    }

    /// <summary>
    /// Controlled-profile load: the policy's authority supplies authoritative bytes (or refuses);
    /// the legacy mapper/loader — and therefore any disk/network fallback — is never consulted,
    /// and the approved bytes are parsed with DTD processing prohibited.
    /// </summary>
    /// <remarks>
    /// The policy decision (unsupported-route check plus authority consult, with its receipt)
    /// runs on every call, BEFORE the document cache is consulted: a control that executes only
    /// on cache misses cannot enforce the per-route contract (consumer review B-F1). The cache
    /// key carries the effective policy identity (the policy instance, which owns its authority)
    /// and the purpose route, so content approved under one policy or route is never served to
    /// another. During static evaluation (<see cref="IsStaticEvaluation"/>) the governing
    /// purpose route is <see cref="ControlledResourceRoute.StaticEvaluation"/> and the requested
    /// route is preserved as the concrete route on the request and receipt (consumer review B-F2).
    /// <para>Cache hits are digest-validated (consumer review B-F3): each controlled entry stores
    /// the SHA-256 of the bytes its node was parsed from and the effective URI they were acquired
    /// under. The approval receipt is deferred until after the comparison — a matching entry is
    /// served unchanged (document identity preserved) with <see cref="ControlledResourceReceipt.ServedFromCache"/>
    /// set, while changed bytes or a changed effective URI are parsed into a fresh node that
    /// replaces the entry. The receipt therefore always describes the content actually returned.</para>
    /// </remarks>
    private IXdmNode LoadDocumentControlled(string uri, ControlledResourceRoute route, ControlledResourcePolicy policy)
    {
        if (!Uri.IsWellFormedUriString(uri, UriKind.Absolute) && !string.IsNullOrEmpty(BaseUri))
            uri = new Uri(new Uri(BaseUri), uri).AbsoluteUri;

        var (purpose, concrete) = ControlledRouteFor(route);

        // Authorization first — never served from cache without the route's own decision.
        // The approval receipt is deferred: it is recorded only once the cache comparison
        // below has decided whether the cached node or the fresh bytes are consumed (B-F3).
        var bytes = policy.AcquireBytesForCacheServe(uri, purpose, concrete, out var effectiveUri, out var byteCount, out var sha256);

        var key = (uri, (object?)DocumentLoadPolicy, (object?)policy, purpose);
        if (_documentCache.TryGetValue(key, out var entry)
            && entry.Sha256 is not null
            && entry.Sha256 == sha256
            && string.Equals(entry.EffectiveUri, effectiveUri, StringComparison.Ordinal))
        {
            // Digest-validated hit: the cached node was parsed from exactly these bytes under
            // this effective URI — receipt and content agree.
            policy.RecordCacheServeApproval(uri, purpose, concrete, effectiveUri, byteCount, sha256, servedFromCache: true);
            DocumentLoaded?.Invoke(uri);
            return entry.Node;
        }

        policy.RecordCacheServeApproval(uri, purpose, concrete, effectiveUri, byteCount, sha256, servedFromCache: false);
        var node = Bosak.XPath.Providers.Xml.XDocumentProvider.LoadControlled(bytes, effectiveUri);
        return CacheLoadedDocument(key, uri, node, sha256, effectiveUri);
    }

    /// <summary>
    /// Maps a requested acquisition route to the route pair the controlled policy decides on:
    /// during static evaluation the governing purpose route is
    /// <see cref="ControlledResourceRoute.StaticEvaluation"/> and the requested route is kept
    /// as the concrete operation; otherwise the requested route decides, with no concrete route.
    /// </summary>
    internal (ControlledResourceRoute Purpose, ControlledResourceRoute? Concrete) ControlledRouteFor(ControlledResourceRoute route)
        => IsStaticEvaluation && route != ControlledResourceRoute.StaticEvaluation
            ? (ControlledResourceRoute.StaticEvaluation, (ControlledResourceRoute?)route)
            : (route, null);

    /// <summary>
    /// Shared post-load tail: whitespace/strip-space post-processing, eager creation-sequence
    /// registration for XDocument-backed trees, document caching and the DocumentLoaded callback.
    /// </summary>
    /// <param name="key">The cache key (URI, load policy, controlled policy, route) to store the node under.</param>
    /// <param name="uri">The originally requested URI (after absolutization), for the DocumentLoaded callback.</param>
    /// <param name="node">The freshly loaded document node.</param>
    /// <param name="sha256">The SHA-256 of the bytes <paramref name="node"/> was parsed from; null on the legacy path.</param>
    /// <param name="effectiveUri">The effective URI the bytes were acquired under; null on the legacy path.</param>
    private IXdmNode CacheLoadedDocument(
        (string Uri, object? LoadPolicy, object? ControlledPolicy, ControlledResourceRoute Route) key,
        string uri,
        IXdmNode node,
        string? sha256 = null,
        string? effectiveUri = null)
    {
        if (DocumentPostProcessor != null)
            node = DocumentPostProcessor(node);
        // Eagerly assign the creation sequence so cross-tree document order follows
        // load order instead of first document-order access (evaluate-002).
        if (node is XDocumentNode xdn)
        {
            if (xdn.UnderlyingObject is System.Xml.Linq.XDocument xdoc)
                XDocumentNode.RegisterTree(xdoc);
            else if (xdn.UnderlyingObject is System.Xml.Linq.XElement xelem)
                XDocumentNode.RegisterTree(xelem);
        }
        _documentCache[key] = new DocumentCacheEntry(node, sha256, effectiveUri);
        DocumentLoaded?.Invoke(uri);
        return node;
    }

    /// <summary>
    /// Optional hook invoked by <c>fn:copy-of</c> / <c>fn:snapshot</c> after copying a node,
    /// so the XSLT layer can attach accumulator values to the copy (XSLT 3.0 §19.2:
    /// accumulator values are copied by those functions). Arguments are the source node and
    /// the copy root node.
    /// </summary>
    internal Action<IXdmNode, IXdmNode>? AccumulatorValueCopier { get; set; }

    /// <summary>
    /// Registers a document node under the supplied URI without invoking <see cref="DocumentLoader"/>.
    /// Used by XSLT to make the source document available to <c>fn:doc</c> via its document URI.
    /// </summary>
    /// <param name="uri">The absolute URI to register.</param>
    /// <param name="node">The document node to associate with the URI.</param>
    public void RegisterDocument(string uri, IXdmNode node)
    {
        if (!string.IsNullOrEmpty(uri))
        {
            _documentCache[(uri, null, null, ControlledResourceRoute.Document)] = new DocumentCacheEntry(node, null, null);
            DocumentLoaded?.Invoke(uri);
        }
    }

    // ------------------------------------------------------------------
    // Focus
    // ------------------------------------------------------------------

    /// <summary>Resolves an initial focus when a semantic read finds it absent.</summary>
    internal Action? InitialFocusResolver { get; set; }

    /// <summary>Reads the context item, resolving a pending initial focus if necessary.</summary>
    /// <returns>The resolved context item, or undefined when focus remains absent.</returns>
    internal XdmValue ResolveContextItem()
    {
        if (_contextItem.IsUndefined) InitialFocusResolver?.Invoke();
        return _contextItem;
    }

    /// <summary>Invalidates one cached global before a new explicit-context query evaluation.</summary>
    /// <param name="localName">The variable local name.</param>
    /// <param name="namespaceUri">The variable namespace.</param>
    internal void InvalidateLazyGlobal(string localName, string namespaceUri)
        => _evaluatedLazyGlobals.Remove((localName, namespaceUri));

    /// <summary>The context item (the value of the <c>.</c> expression); undefined when there is no focus.</summary>
    public XdmValue ContextItem => _contextItem;

    /// <summary>The context position: the 1-based position of the context item in the focus sequence.</summary>
    public int ContextPosition => _contextPosition;

    /// <summary>The context size: the number of items in the focus sequence.</summary>
    public int ContextSize => _contextSize;

    /// <summary>
    /// The current item for fn:current(). In XSLT this is the node matched by the
    /// current template rule or selected by xsl:for-each / xsl:apply-templates.
    /// </summary>
    public XdmValue CurrentItem => _currentItem;

    /// <summary>Sets the focus (context item, position, and size) and returns this context.</summary>
    /// <param name="item">The context item.</param>
    /// <param name="position">The 1-based context position.</param>
    /// <param name="size">The context size.</param>
    /// <returns>This context, for fluent chaining.</returns>
    public EvaluationContext WithFocus(XdmValue item, int position, int size)
    {
        _contextItem = item;
        _contextPosition = position;
        _contextSize = size;
        return this;
    }

    /// <summary>Sets the current item used by <c>fn:current()</c> and returns this context.</summary>
    /// <param name="item">The new current item.</param>
    /// <returns>This context, for fluent chaining.</returns>
    public EvaluationContext WithCurrentItem(XdmValue item)
    {
        _currentItem = item;
        return this;
    }

    // ------------------------------------------------------------------
    // Variables
    // ------------------------------------------------------------------

    /// <summary>Binds a variable to a value and returns this context.</summary>
    /// <param name="localName">The variable's local name.</param>
    /// <param name="value">The value to bind.</param>
    /// <param name="namespaceUri">The variable's namespace URI (empty for no namespace).</param>
    /// <returns>This context, for fluent chaining.</returns>
    public EvaluationContext WithVariable(string localName, XdmValue value, string namespaceUri = "")
    {
        _variables[(localName, namespaceUri)] = value;
        return this;
    }

    /// <summary>
    /// Attempts to resolve a variable, consulting the direct bindings, the evaluated
    /// lazy-global cache, and finally <see cref="LazyVariableResolver"/> (whose result is
    /// cached unless lazy caching is suppressed).
    /// </summary>
    /// <param name="localName">The variable's local name.</param>
    /// <param name="value">The bound value when found.</param>
    /// <param name="namespaceUri">The variable's namespace URI (empty for no namespace).</param>
    /// <returns><c>true</c> when the variable is bound.</returns>
    public bool TryGetVariable(string localName, out XdmValue value, string namespaceUri = "")
    {
        if (_variables.TryGetValue((localName, namespaceUri), out value))
            return true;

        if (_evaluatedLazyGlobals.TryGetValue((localName, namespaceUri), out value))
            return true;

        if (LazyVariableResolver != null)
        {
            var lazyValue = LazyVariableResolver(localName, namespaceUri);
            if (lazyValue != null)
            {
                value = lazyValue.Value;
                if (!SuppressLazyGlobalCaching && !SkipLazyGlobalCacheOnce)
                    _evaluatedLazyGlobals[(localName, namespaceUri)] = value;
                SkipLazyGlobalCacheOnce = false;
                return true;
            }
        }

        return false;
    }

    /// <summary>
    /// Captures the current lazy-global cache so it can be restored later. This lets
    /// XSLT function calls isolate function-local lazy variables from the global cache.
    /// </summary>
    /// <returns>A token whose <see cref="IDisposable.Dispose"/> restores the saved cache.</returns>
    internal IDisposable SnapshotLazyGlobals()
    {
        var saved = new Dictionary<(string LocalName, string NamespaceUri), XdmValue>(_evaluatedLazyGlobals);
        return new LazyGlobalsRestorer(this, saved);
    }

    private sealed class LazyGlobalsRestorer : IDisposable
    {
        private readonly EvaluationContext _context;
        private readonly Dictionary<(string LocalName, string NamespaceUri), XdmValue> _saved;

        public LazyGlobalsRestorer(EvaluationContext context, Dictionary<(string LocalName, string NamespaceUri), XdmValue> saved)
        {
            _context = context;
            _saved = saved;
        }

        public void Dispose()
        {
            _context._evaluatedLazyGlobals.Clear();
            foreach (var kv in _saved)
                _context._evaluatedLazyGlobals[kv.Key] = kv.Value;
        }
    }

    /// <summary>
    /// Attempts to resolve a variable from the direct binding dictionary only, without
    /// consulting the evaluated lazy-global cache or the <see cref="LazyVariableResolver"/>.
    /// The VM's lexical let scoping (SaveVariables/RestoreVariables) uses this so capturing
    /// a variable's current binding never triggers lazy global evaluation: an in-flight
    /// global with the same name would otherwise be reported as a circular dependency
    /// (K2-FunctionProlog-15).
    /// </summary>
    /// <param name="localName">The variable's local name.</param>
    /// <param name="value">The directly bound value when found.</param>
    /// <param name="namespaceUri">The variable's namespace URI (empty for no namespace).</param>
    /// <returns><c>true</c> when the variable has a direct binding.</returns>
    internal bool TryGetDirectVariable(string localName, out XdmValue value, string namespaceUri = "")
        => _variables.TryGetValue((localName, namespaceUri), out value);

    /// <summary>Removes a variable binding, if present.</summary>
    /// <param name="localName">The variable's local name.</param>
    /// <param name="namespaceUri">The variable's namespace URI (empty for no namespace).</param>
    /// <returns><c>true</c> when a binding was removed.</returns>
    public bool RemoveVariable(string localName, string namespaceUri = "")
        => _variables.Remove((localName, namespaceUri));

    /// <summary>
    /// Looks up a variable in the direct variable dictionary and the evaluated lazy-global
    /// cache without invoking <see cref="LazyVariableResolver"/>. Used by the XSLT global
    /// variable resolver to avoid recursive re-entry through its own resolver.
    /// </summary>
    /// <param name="localName">The variable's local name.</param>
    /// <param name="value">The bound value when found.</param>
    /// <param name="namespaceUri">The variable's namespace URI (empty for no namespace).</param>
    /// <returns><c>true</c> when the variable is bound.</returns>
    public bool TryGetBoundVariable(string localName, out XdmValue value, string namespaceUri = "")
    {
        if (_variables.TryGetValue((localName, namespaceUri), out value))
            return true;

        if (_evaluatedLazyGlobals.TryGetValue((localName, namespaceUri), out value))
            return true;

        return false;
    }

    /// <summary>
    /// Creates a snapshot of all current variable bindings.
    /// </summary>
    /// <returns>A copy of the current bindings, keyed by (local name, namespace URI).</returns>
    internal Dictionary<(string LocalName, string NamespaceUri), XdmValue> SnapshotVariables()
        => new Dictionary<(string, string), XdmValue>(_variables);

    /// <summary>
    /// Restores variable bindings from a snapshot, removing any variables added since.
    /// </summary>
    /// <param name="snapshot">A snapshot previously produced by <see cref="SnapshotVariables"/>.</param>
    internal void RestoreVariables(Dictionary<(string LocalName, string NamespaceUri), XdmValue> snapshot)
    {
        _variables.Clear();
        foreach (var (key, value) in snapshot)
            _variables[key] = value;
    }

    // ------------------------------------------------------------------
    // Namespaces
    // ------------------------------------------------------------------

    /// <summary>
    /// Binds a namespace prefix to a URI and returns this context. A zero-length URI on a
    /// non-empty prefix undeclares the prefix (XQuery namespace undeclaration).
    /// </summary>
    /// <param name="prefix">The namespace prefix (empty for the default namespace).</param>
    /// <param name="namespaceUri">The namespace URI to bind; empty undeclares the prefix.</param>
    /// <returns>This context, for fluent chaining.</returns>
    public EvaluationContext WithNamespace(string prefix, string namespaceUri)
    {
        // A zero-length URI undeclares the prefix (XQuery namespace undeclaration).
        if (namespaceUri.Length == 0 && prefix.Length > 0)
            _namespaces.Remove(prefix);
        else
            _namespaces[prefix] = namespaceUri;
        return this;
    }

    /// <summary>Removes a namespace prefix binding (used for namespace undeclarations).</summary>
    /// <param name="prefix">The prefix to remove.</param>
    /// <returns>This context, for fluent chaining.</returns>
    public EvaluationContext RemoveNamespace(string prefix)
    {
        _namespaces.Remove(prefix);
        return this;
    }

    // ------------------------------------------------------------------
    // Schemas
    // ------------------------------------------------------------------

    /// <summary>
    /// Gets or sets the compiled XML Schema set available to schema-aware operations.
    /// </summary>
    public XmlSchemaSet? SchemaSet
    {
        get => _schemaSet;
        set => _schemaSet = value;
    }

    /// <summary>
    /// Whether the host processor is schema-aware. Set by schema-aware hosts
    /// (e.g. an <c>XsltCompiler</c> compiled with <c>SchemaAware = true</c>); functions
    /// whose behavior is defined conditionally on schema-awareness consult this flag
    /// (fn:json-to-xml validate:=true() raises FOJS0004 otherwise).
    /// </summary>
    public bool IsSchemaAware { get; set; }

    /// <summary>
    /// Looks up a global element declaration in the compiled schema set, if any.
    /// </summary>
    /// <param name="namespaceUri">The declaration's target namespace URI.</param>
    /// <param name="localName">The declaration's local name.</param>
    /// <returns>The global element declaration, or <c>null</c> when not present.</returns>
    public XmlSchemaElement? GetSchemaElement(string namespaceUri, string localName)
        => _schemaSet?.GlobalElements[new XmlQualifiedName(localName, namespaceUri)] as XmlSchemaElement;

    /// <summary>
    /// Looks up a global attribute declaration in the compiled schema set, if any.
    /// </summary>
    /// <param name="namespaceUri">The declaration's target namespace URI.</param>
    /// <param name="localName">The declaration's local name.</param>
    /// <returns>The global attribute declaration, or <c>null</c> when not present.</returns>
    public XmlSchemaAttribute? GetSchemaAttribute(string namespaceUri, string localName)
        => _schemaSet?.GlobalAttributes[new XmlQualifiedName(localName, namespaceUri)] as XmlSchemaAttribute;

    /// <summary>
    /// Looks up a global type definition in the compiled schema set, if any.
    /// </summary>
    /// <param name="namespaceUri">The type's target namespace URI.</param>
    /// <param name="localName">The type's local name.</param>
    /// <returns>The global type definition, or <c>null</c> when not present.</returns>
    public XmlSchemaType? GetSchemaType(string namespaceUri, string localName)
        => _schemaSet?.GlobalTypes[new XmlQualifiedName(localName, namespaceUri)] as XmlSchemaType;

    // Constructor-local namespace declarations (xmlns on enclosing constructors, applied
    // via the DeclareNamespace opcode). Elements built inside a constructor materialize
    // these bindings; the element's own declarations win (K2-InScopePrefixesFunc-18).
    private readonly List<(string Prefix, string Uri)> _constructorLocalNamespaces = new();

    /// <summary>The constructor-local namespace bindings currently in effect.</summary>
    public IReadOnlyList<(string Prefix, string Uri)> ConstructorLocalNamespaces => _constructorLocalNamespaces;

    /// <summary>The number of constructor-local bindings (for snapshot/restore).</summary>
    public int ConstructorLocalNamespaceCount => _constructorLocalNamespaces.Count;

    /// <summary>
    /// Records a constructor-local namespace declaration; an empty URI undeclares the
    /// prefix (removing any earlier local binding of the same prefix).
    /// </summary>
    /// <param name="prefix">The namespace prefix being declared (empty for the default namespace).</param>
    /// <param name="uri">The namespace URI; empty removes the local binding.</param>
    public void AddConstructorLocalNamespace(string prefix, string uri)
    {
        for (int i = _constructorLocalNamespaces.Count - 1; i >= 0; i--)
        {
            if (_constructorLocalNamespaces[i].Prefix == prefix)
            {
                _constructorLocalNamespaces.RemoveAt(i);
                break;
            }
        }
        if (uri.Length > 0)
            _constructorLocalNamespaces.Add((prefix, uri));
    }

    /// <summary>Drops constructor-local bindings recorded after the given snapshot point.</summary>
    /// <param name="count">The binding count previously read from <see cref="ConstructorLocalNamespaceCount"/>.</param>
    public void TruncateConstructorLocalNamespaces(int count)
    {
        if (_constructorLocalNamespaces.Count > count)
            _constructorLocalNamespaces.RemoveRange(count, _constructorLocalNamespaces.Count - count);
    }

    /// <summary>
    /// Resolves a namespace prefix to its URI. The empty prefix resolves to
    /// <see cref="DefaultElementNamespace"/> when set, and the <c>xml</c> prefix always
    /// resolves to the XML namespace URI.
    /// </summary>
    /// <param name="prefix">The prefix to resolve (empty for the default element namespace).</param>
    /// <param name="namespaceUri">The resolved namespace URI when found.</param>
    /// <returns><c>true</c> when the prefix is bound.</returns>
    public bool TryResolveNamespace(string prefix, out string namespaceUri)
    {
        if (prefix == "" && !string.IsNullOrEmpty(DefaultElementNamespace))
        {
            namespaceUri = DefaultElementNamespace;
            return true;
        }
        if (prefix == "xml")
        {
            namespaceUri = "http://www.w3.org/XML/1998/namespace";
            return true;
        }
        return _namespaces.TryGetValue(prefix, out namespaceUri!);
    }

    /// <summary>
    /// Returns a snapshot of the current namespace bindings.
    /// </summary>
    /// <returns>A copy of the current prefix-to-URI bindings.</returns>
    internal Dictionary<string, string> SnapshotNamespaces()
        => new(_namespaces);

    /// <summary>
    /// Restores namespace bindings from a snapshot, discarding any bindings
    /// added since the snapshot was taken.
    /// </summary>
    /// <param name="snapshot">A snapshot previously produced by <see cref="SnapshotNamespaces"/>.</param>
    internal void RestoreNamespaces(Dictionary<string, string> snapshot)
    {
        _namespaces.Clear();
        foreach (var kv in snapshot)
            _namespaces[kv.Key] = kv.Value;
    }

    // ------------------------------------------------------------------
    // Functions
    // ------------------------------------------------------------------

    /// <summary>
    /// Registers a function signature under its (namespace URI, local name, arity) key,
    /// replacing any existing registration, and returns this context.
    /// </summary>
    /// <param name="signature">The function signature to register.</param>
    /// <returns>This context, for fluent chaining.</returns>
    public EvaluationContext RegisterFunction(FunctionSignature signature)
    {
        var key = (signature.NamespaceUri, signature.LocalName, signature.Arity);
        _functions[key] = signature;
        if (signature.IsVariadic)
        {
            var variadicKey = (signature.NamespaceUri, signature.LocalName);
            if (!_variadicMinArity.TryGetValue(variadicKey, out var min) || signature.Arity < min)
                _variadicMinArity[variadicKey] = signature.Arity;
        }
        return this;
    }

    /// <summary>
    /// Installs a standard function table, preserving any non-standard registrations.
    /// On an empty registry this is a single dictionary copy (much cheaper than hundreds
    /// of individual <see cref="RegisterFunction"/> insertions); on an already populated
    /// registry the standard entries overwrite in place, matching the historical
    /// <c>FunctionLibrary.Populate</c> semantics.
    /// </summary>
    /// <param name="template">The shared standard function table to install (never mutated).</param>
    internal void InstallStandardFunctionTable(Dictionary<(string NamespaceUri, string LocalName, int Arity), FunctionSignature> template)
    {
        if (_functions.Count == 0)
        {
            _functions = new Dictionary<(string, string, int), FunctionSignature>(template);
            RebuildVariadicIndex();
            return;
        }
        foreach (var kvp in template)
            _functions[kvp.Key] = kvp.Value;
        foreach (var ((ns, name, arity), sig) in template)
        {
            if (!sig.IsVariadic) continue;
            var variadicKey = (ns, name);
            if (!_variadicMinArity.TryGetValue(variadicKey, out var min) || arity < min)
                _variadicMinArity[variadicKey] = arity;
        }
    }

    /// <summary>
    /// Optional interceptor consulted by <c>fn:function-lookup</c> before the dynamic
    /// registry. The interceptor receives the context, namespace URI, local name, and arity,
    /// and returns the lookup result (<see cref="XdmValue.Undefined"/> for "not found"), or
    /// <c>null</c> to decline and let the standard registry resolution run. XSLT package
    /// scopes install an interceptor so the lookup sees the declaring package's own
    /// declarations rather than overrides contributed by using packages.
    /// </summary>
    public Func<EvaluationContext, string, string, int, XdmValue?>? FunctionLookupInterceptor { get; set; }

    /// <summary>
    /// Resolves a function by namespace URI, local name, and arity. When no exact-arity
    /// registration exists, a variadic signature whose declared arity is not greater than
    /// the requested arity matches (e.g. <c>fn:concat</c> resolves for any arity ≥ 2).
    /// </summary>
    /// <param name="namespaceUri">The function's namespace URI.</param>
    /// <param name="localName">The function's local name.</param>
    /// <param name="arity">The number of arguments at the call site.</param>
    /// <param name="signature">The resolved signature when found.</param>
    /// <returns><c>true</c> when a matching function is registered.</returns>
    public bool TryResolveFunction(string namespaceUri, string localName, int arity, out FunctionSignature signature)
    {
        if (_functions.TryGetValue((namespaceUri, localName, arity), out signature!))
            return (!signature.IsXPath40Only || IsXPath40)
                && (!signature.IsXPath40ExperimentalOnly || IsXPath40Experimental);
        // Variadic fallback via the (namespace, localName) index: a variadic signature
        // accepts any arity >= its minimum declared arity (e.g. fn:concat#99 resolves
        // against the variadic fn:concat registration).
        if (_variadicMinArity.TryGetValue((namespaceUri, localName), out var minVariadicArity))
        {
            if (arity >= minVariadicArity
                && _functions.TryGetValue((namespaceUri, localName, minVariadicArity), out signature!)
                && (!signature.IsXPath40Only || IsXPath40)
                && (!signature.IsXPath40ExperimentalOnly || IsXPath40Experimental))
                return true;
            // Rare: the minimum-arity variadic slot was explicitly unregistered — rescan
            // for another variadic registration of the same name.
            foreach (var ((ns, name, candidateArity), sig) in _functions)
            {
                if (ns == namespaceUri && name == localName && sig.IsVariadic && arity >= candidateArity
                    && (!sig.IsXPath40Only || IsXPath40)
                    && (!sig.IsXPath40ExperimentalOnly || IsXPath40Experimental))
                {
                    signature = sig;
                    return true;
                }
            }
        }
        signature = null!;
        return false;
    }

    /// <summary>
    /// Removes a registered function signature, if present.
    /// </summary>
    /// <param name="namespaceUri">The function's namespace URI.</param>
    /// <param name="localName">The function's local name.</param>
    /// <param name="arity">The function's arity.</param>
    /// <returns><c>true</c> when a registration was removed.</returns>
    public bool UnregisterFunction(string namespaceUri, string localName, int arity)
    {
        bool removed = _functions.Remove((namespaceUri, localName, arity));
        if (removed && _variadicMinArity.TryGetValue((namespaceUri, localName), out var min) && min == arity)
        {
            // Recompute the minimum from the remaining variadic registrations (removals are rare).
            int? newMin = null;
            foreach (var ((ns, name, candidateArity), sig) in _functions)
            {
                if (ns == namespaceUri && name == localName && sig.IsVariadic)
                    newMin = newMin is null ? candidateArity : Math.Min(newMin.Value, candidateArity);
            }
            if (newMin is null)
                _variadicMinArity.Remove((namespaceUri, localName));
            else
                _variadicMinArity[(namespaceUri, localName)] = newMin.Value;
        }
        return removed;
    }

    /// <summary>Captures hidden aliases whose targets have lexical function-item identity.</summary>
    /// <returns>The alias snapshot, or null when no lexical alias is registered.</returns>
    internal Dictionary<(string NamespaceUri, string LocalName, int Arity), FunctionSignature>? SnapshotBoundFunctionAliases()
    {
        Dictionary<(string NamespaceUri, string LocalName, int Arity), FunctionSignature>? snapshot = null;
        foreach (var (key, signature) in _functions)
            if (signature.IsHiddenFromFunctionLookup && signature.FunctionItemTarget is { IsBoundFunctionItem: true })
                (snapshot ??= new())[key] = signature;
        return snapshot;
    }

    /// <summary>Restores only hidden lexical aliases, leaving ordinary function bindings intact.</summary>
    /// <param name="snapshot">The aliases to restore, or null to remove the current aliases.</param>
    internal void RestoreBoundFunctionAliases(Dictionary<(string NamespaceUri, string LocalName, int Arity), FunctionSignature>? snapshot)
    {
        if (SnapshotBoundFunctionAliases() is { } current)
            foreach (var key in current.Keys)
                UnregisterFunction(key.NamespaceUri, key.LocalName, key.Arity);
        if (snapshot is not null)
            foreach (var signature in snapshot.Values)
                RegisterFunction(signature);
    }

    /// <summary>
    /// Returns a shallow copy of the currently registered function signatures.
    /// </summary>
    /// <returns>A copy of the function registry, keyed by (namespace URI, local name, arity).</returns>
    internal Dictionary<(string NamespaceUri, string LocalName, int Arity), FunctionSignature> SnapshotFunctions()
        => new Dictionary<(string, string, int), FunctionSignature>(_functions);

    /// <summary>
    /// Replaces the current function library with the supplied snapshot.
    /// </summary>
    /// <param name="snapshot">A snapshot previously produced by <see cref="SnapshotFunctions"/>.</param>
    internal void RestoreFunctions(Dictionary<(string NamespaceUri, string LocalName, int Arity), FunctionSignature> snapshot)
    {
        _functions.Clear();
        _variadicMinArity.Clear();
        foreach (var (key, value) in snapshot)
            _functions[key] = value;
        RebuildVariadicIndex();
    }

    /// <summary>
    /// Removes all registered functions.
    /// </summary>
    public void ClearFunctions()
    {
        _functions.Clear();
        _variadicMinArity.Clear();
    }

    private void RebuildVariadicIndex()
    {
        foreach (var ((ns, name, arity), sig) in _functions)
        {
            if (!sig.IsVariadic) continue;
            var variadicKey = (ns, name);
            if (!_variadicMinArity.TryGetValue(variadicKey, out var min) || arity < min)
                _variadicMinArity[variadicKey] = arity;
        }
    }

    // ------------------------------------------------------------------
    // Decimal Formats
    // ------------------------------------------------------------------

    /// <summary>The unnamed (default) decimal format used by <c>fn:format-number</c>.</summary>
    public DecimalFormat DefaultDecimalFormat
    {
        get => _defaultDecimalFormat;
        set => _defaultDecimalFormat = value;
    }

    /// <summary>
    /// Registers a decimal format and returns this context; a null or empty name replaces
    /// the default decimal format, otherwise the format is registered under the name in
    /// no namespace.
    /// </summary>
    /// <param name="name">The format's local name, or null/empty for the default format.</param>
    /// <param name="format">The decimal format to register.</param>
    /// <returns>This context, for fluent chaining.</returns>
    public EvaluationContext WithDecimalFormat(string? name, DecimalFormat format)
    {
        if (string.IsNullOrEmpty(name))
        {
            _defaultDecimalFormat = format;
        }
        else
        {
            _namedDecimalFormats[(name, "")] = format;
        }
        return this;
    }

    /// <summary>Registers a named decimal format under an expanded QName and returns this context.</summary>
    /// <param name="localName">The format's local name.</param>
    /// <param name="namespaceUri">The format's namespace URI.</param>
    /// <param name="format">The decimal format to register.</param>
    /// <returns>This context, for fluent chaining.</returns>
    public EvaluationContext WithDecimalFormat(string localName, string namespaceUri, DecimalFormat format)
    {
        _namedDecimalFormats[(localName, namespaceUri)] = format;
        return this;
    }

    /// <summary>
    /// Looks up a named decimal format by lexical name; a prefixed name is resolved
    /// against the in-scope namespaces.
    /// </summary>
    /// <param name="name">The format name, optionally prefixed.</param>
    /// <returns>The registered format, or <c>null</c> when not found.</returns>
    public DecimalFormat? GetDecimalFormat(string name)
    {
        // Try empty namespace first (local name)
        if (_namedDecimalFormats.TryGetValue((name, ""), out var fmt))
            return fmt;

        // Try as prefixed name: resolve prefix using namespaces
        if (name.Contains(':'))
        {
            int colon = name.IndexOf(':');
            string prefix = name.Substring(0, colon);
            string local = name.Substring(colon + 1);
            if (TryResolveNamespace(prefix, out var ns))
            {
                if (_namedDecimalFormats.TryGetValue((local, ns), out fmt))
                    return fmt;
            }
        }

        return null;
    }

    /// <summary>Looks up a named decimal format by expanded QName.</summary>
    /// <param name="localName">The format's local name.</param>
    /// <param name="namespaceUri">The format's namespace URI.</param>
    /// <returns>The registered format, or <c>null</c> when not found.</returns>
    public DecimalFormat? GetDecimalFormat(string localName, string namespaceUri)
    {
        if (_namedDecimalFormats.TryGetValue((localName, namespaceUri), out var fmt))
            return fmt;
        return null;
    }

    /// <summary>
    /// Copies the current named decimal formats for save/restore around module-context
    /// switches (a library module's decimal-format declarations apply only within that module).
    /// </summary>
    /// <returns>A copy of the named decimal formats, keyed by (local name, namespace URI).</returns>
    internal Dictionary<(string LocalName, string NamespaceUri), DecimalFormat> SnapshotDecimalFormats()
        => new(_namedDecimalFormats);

    /// <summary>Replaces the named decimal formats with a previously snapshotted set.</summary>
    /// <param name="snapshot">A snapshot previously produced by <see cref="SnapshotDecimalFormats"/>.</param>
    internal void RestoreDecimalFormats(Dictionary<(string LocalName, string NamespaceUri), DecimalFormat> snapshot)
    {
        _namedDecimalFormats.Clear();
        foreach (var kv in snapshot)
            _namedDecimalFormats[kv.Key] = kv.Value;
    }

    // ------------------------------------------------------------------
    // Default Collation
    // ------------------------------------------------------------------

    /// <summary>
    /// The default collation URI used by the two-argument forms of string functions such
    /// as <c>fn:compare</c>, <c>fn:contains</c>, and <c>fn:starts-with</c>. The empty
    /// string selects the codepoint collation.
    /// </summary>
    public string DefaultCollation { get; set; } = string.Empty;

    /// <summary>Sets the default collation URI and returns this context.</summary>
    /// <param name="collation">The collation URI to make the default.</param>
    /// <returns>This context, for fluent chaining.</returns>
    public EvaluationContext WithDefaultCollation(string collation)
    {
        DefaultCollation = collation;
        return this;
    }

    /// <summary>
    /// Returns a stable snapshot of the current date/time for the lifetime of this context.
    /// Used by fn:current-dateTime, fn:current-date, and fn:current-time.
    /// Also initializes the implicit timezone from the snapshot's offset when it has
    /// not been explicitly set.
    /// </summary>
    public DateTimeOffset CurrentDateTimeSnapshot
    {
        get
        {
            if (!_currentDateTimeSnapshot.HasValue)
            {
                var now = System.DateTimeOffset.Now;
                _currentDateTimeSnapshot = now;
                if (!_implicitTimezoneOffsetSet)
                {
                    _implicitTimezoneOffsetMinutes = (int)now.Offset.TotalMinutes;
                }
            }
            return _currentDateTimeSnapshot.Value;
        }
    }
}
