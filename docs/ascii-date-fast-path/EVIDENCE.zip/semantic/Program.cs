// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 16 November 2026
// PURPOSE              : Compares qualified date parsing with a valid ASCII date fast-path prototype
// SPECIAL NOTES        : Unit tests verifying correctness of the underlying implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 16-11-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using System.Reflection;
using System.Text.Json;
using System.Text;
using System.Security.Cryptography;
using System.Globalization;
using Bosak.XPath.Core.Xdm;

internal static class Program
{
    /// <summary>Executes the engine-bearing diagnostic inside an exception boundary.</summary>
    /// <returns>Zero on success, otherwise two.</returns>
    public static int Main(){try{var t=typeof(Program).Assembly.GetType("Probe",true)!;Console.WriteLine(JsonSerializer.Serialize(t.GetMethod("Run")!.Invoke(null,null)));return 0;}catch(Exception e){Console.Error.WriteLine(e);return 2;}}
}
internal static class Probe
{
    private delegate bool TryDate(string? text,out XPathDateTime value,out bool hasTimezone);
    private static readonly Type Vm=Assembly.Load("Bosak.XPath.Runtime").GetType("Bosak.XPath.Runtime.Vm.VmEngine",true)!;
    private static readonly TryDate Baseline=Vm.GetMethod("TryParseXPathDate",BindingFlags.NonPublic|BindingFlags.Static)!.CreateDelegate<TryDate>();
    private static readonly Func<long,int,int> Days=Vm.GetMethod("DaysInMonth",BindingFlags.NonPublic|BindingFlags.Static)!.CreateDelegate<Func<long,int,int>>();
    private static XPathDateTime Sink;private static bool SuccessSink,TimezoneSink;
    private static bool Digit(char c)=>c>='0' && c<='9';
    private static bool Candidate(string? text,out XPathDateTime value,out bool hasTimezone)
    {
        if(text is null || text.Length is not (10 or 11 or 16))return Baseline(text,out value,out hasTimezone);
        var s=text.AsSpan();
        if(s[4]!='-' || s[7]!='-' || !Digit(s[0]) || !Digit(s[1]) || !Digit(s[2]) || !Digit(s[3]) || !Digit(s[5]) || !Digit(s[6]) || !Digit(s[8]) || !Digit(s[9]))return Baseline(text,out value,out hasTimezone);
        int year=(s[0]-'0')*1000+(s[1]-'0')*100+(s[2]-'0')*10+s[3]-'0';
        int month=(s[5]-'0')*10+s[6]-'0';int day=(s[8]-'0')*10+s[9]-'0';
        if(month<1 || month>12 || day<1 || day>Days(year,month))return Baseline(text,out value,out hasTimezone);
        int offset=0;
        if(s.Length==11 && s[10]!='Z')return Baseline(text,out value,out hasTimezone);
        if(s.Length==16)
        {
            if(s[10] is not ('+' or '-') || s[13]!=':' || !Digit(s[11]) || !Digit(s[12]) || !Digit(s[14]) || !Digit(s[15]))return Baseline(text,out value,out hasTimezone);
            int hours=(s[11]-'0')*10+s[12]-'0';int minutes=(s[14]-'0')*10+s[15]-'0';
            if(hours>14 || minutes>59 || hours==14 && minutes!=0)return Baseline(text,out value,out hasTimezone);
            offset=(hours*60+minutes)*(s[10]=='-'?-1:1);
        }
        hasTimezone=s.Length!=10;value=new XPathDateTime(year,month,day,0,0,0,0,offset,hasTimezone);return true;
    }
    private static string Outcome(TryDate parse,string? input)
    {
        var value=default(XPathDateTime);bool timezone=false,success=false;string? error=null;
        try{success=parse(input,out value,out timezone);}catch(Exception e){error=e.GetType().FullName+":"+e.Message;}
        return JsonSerializer.Serialize(new{success,timezone,value.Year,value.Month,value.Day,value.Hour,value.Minute,value.Second,value.Millisecond,value.TimezoneOffsetMinutes,value.HasTimezone,error});
    }
    private static string Compare(string? input)
    {
        var a=Outcome(Baseline,input);var b=Outcome(Candidate,input);if(a!=b)throw new Exception("Mismatch for "+JsonSerializer.Serialize(input)+": "+a+" / "+b);return a;
    }
    /// <summary>Runs deterministic differential parsing and bounded allocation controls.</summary>
    /// <returns>Scenario identities, outcome digest and allocation rows.</returns>
    public static object Run()
    {
        var inputs=new List<string?>();var zones=new[]{"","Z","+00:00","-00:00","+14:00","-14:00","+05:30","+14:01"};
        foreach(int year in new[]{0,1,4,100,400,1900,2000,2024,2026,9999})foreach(int month in Enumerable.Range(0,14))foreach(int day in Enumerable.Range(0,33))foreach(string zone in zones)inputs.Add($"{year:D4}-{month:D2}-{day:D2}"+zone);
        inputs.AddRange(new string?[]{null,""," ","2026-11-16z","2026-11-16\n","2026-11-16Z\n"," 2026-11-16","2026-11-16 ","+2026-11-16","-0001-01-01","-0000-02-29","10000-01-01","00001-01-01","2147483647-01-01","2147483648-01-01","-2147483648-01-01","9223372036854775807-01-01","9223372036854775808-01-01","2026-1-01","2026-01-1","2026-01-01+15:00","2026-01-01+00:60","2026-01-01+0:00","2026-01-01+00:0","2026-01-01+00:00x","2026-01-01T00:00:00","2026-01-01\r\n","2026-01-01\0"});
        string canonical="2026-11-16+05:30";
        for(int i=0;i<canonical.Length;i++)foreach(char replacement in new[]{'x','\u0661','\uFF11','\0',' '}){var chars=canonical.ToCharArray();chars[i]=replacement;inputs.Add(new string(chars));}
        using var digest=IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
        foreach(string? input in inputs){string result=Compare(input);var record=Encoding.UTF8.GetBytes(JsonSerializer.Serialize(input)+"\t"+result+"\n");digest.AppendData(record);}
        int localeCases=0;var saved=CultureInfo.CurrentCulture;
        try{foreach(string locale in new[]{"fr-FR","tr-TR","ar-SA"}){CultureInfo.CurrentCulture=CultureInfo.GetCultureInfo(locale);foreach(var input in inputs.TakeLast(110)){Compare(input);localeCases++;}}}finally{CultureInfo.CurrentCulture=saved;}
        var tasks=Enumerable.Range(0,8).Select(worker=>Task.Run(()=>{for(int i=0;i<128;i++)Compare(inputs[(worker*128+i)%inputs.Count]);})).ToArray();Task.WaitAll(tasks);
        var rows=new List<object>();
        foreach(var input in Array.Empty<string>())foreach(bool candidate in new[]{false,true})
        {
            TryDate parse=candidate?Candidate:Baseline;for(int i=0;i<10000;i++)SuccessSink=parse(input,out Sink,out TimezoneSink);
            long before=GC.GetAllocatedBytesForCurrentThread();for(int i=0;i<100000;i++)SuccessSink=parse(input,out Sink,out TimezoneSink);long bytes=GC.GetAllocatedBytesForCurrentThread()-before;
            rows.Add(new{name=(candidate?"prototype/":"baseline/")+input,bytes,bytesPerCall=bytes/100000.0,success=SuccessSink,timezone=TimezoneSink});
        }
        GC.KeepAlive(Sink);
        return new{success=true,engine=Vm.Assembly.GetName().Version!.ToString(),comparisonCases=inputs.Count,localeCases,concurrentCases=1024,allOutStatesAndErrorsEqual=true,outcomeDigest=Convert.ToHexString(digest.GetHashAndReset()).ToLowerInvariant(),warmup=10000,iterations=100000,rows};
    }
}
