// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 20 mei 2026
// PURPOSE              : Compares actual Bosak execution results against QT3 expected assertions.
// SPECIAL NOTES        : Unit tests verifying correctness of the underlying implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 20-05-2026     | Creation                                                                                 |
//                      | Charles Korthout | 0.2   | 21-05-2026     | assert-true/assert-false unwrap singleton sequences                                    |
//                      | Charles Korthout | 0.3   | 22-05-2026     | Fixed ValuesEqual cross-type numeric comparison (Integer vs Double/Float)            |
//                      | Charles Korthout | 0.4   | 22-05-2026     | Added Duration serialization and type matching for dayTimeDuration/yearMonthDuration  |
//                      | Charles Korthout | 0.5   | 22-05-2026     | Fixed Double/Float serialization to use XdmValue.ToString for canonical formatting       |
//                      | Charles Korthout | 0.6   | 27-05-2026     | DeepEqual: single-item sequence is equivalent to bare item (XDM semantics)               |
//                      | Charles Korthout | 0.7   | 01-06-2026     | assert-string-value respects normalize-space="true"; added NormalizeSpace helper        |
//                      | Charles Korthout | 0.8   | 05-06-2026     | ValuesEqual now compares QNames by namespace URI and local name (ignores prefix)         |
//                      | Charles Korthout | 0.9   | 15-07-2026     | assert-count reads element text (was missing attribute); assert-permutation implemented  |
//                      | Charles Korthout | 1.0   | 15-07-2026     | DeepEqual treats Undefined and empty sequence as equal (fn-parse-json-007)               |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.1   | 15-07-2026     | Canonical assert-xml (sorted attrs, self-closing empties, Clark names with ignore-prefixes); actual nodes canonicalized from tree (CR fidelity); assert contexts pre-bind j
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.2   | 15-07-2026     | assert-type xs:decimal accepts xs:integer values (FOTS instance-of semantics)            |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.3   | 17-07-2026     | assert-string-value: prefer exact match, then newline-collapsed match (fn:unparsed-text raw text) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.4   | 21-07-2026     | ToXmlString copies in-scope namespaces; NormalizeXml wraps multi-root fragments for canonical comparison |
//                      | Charles Korthout | 1.5   | 21-07-2026     | Load assert-xml expected output from external file when file attribute is present        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.6   | 21-07-2026     | Serialize extended-year date/time values via XdmValue.ToString                          |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.7   | 21-07-2026     | assert-deep-eq evaluates the whole element text as one XPath expression                 |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.8   | 25-07-2026     | Canonical serialization skips empty namespace undeclarations                            |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.9   | 25-07-2026     | serialization-matches/assert-serialization(-error) assertions with flags and not        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.0   | 27-07-2026     | assert expressions also evaluate with the query result as the context item              |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.1   | 28-07-2026     | Canonical comparison omits redundant namespace declarations |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.2   | 07-08-2026     | assert-type accepts empty-sequence() and optional cardinalities for empty results (fn-function-name-013/014) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.3   | 15-08-2026     | assert-eq unwraps singleton sequences so single-item QName sequences compare correctly |
//                      | Charles Korthout | 2.4   | 17-08-2026     | NormalizeXml strips trailing whitespace after the last element in multi-root fragments (d1e74610) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.5   | 21-08-2026     | NormalizeXml falls back to XML 1.1 parsing; canonical serialization decodes encoded names |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.6   | 07-09-2026     | Strict error-code matching: removed lenient InvalidOperationException fallback in        |
//                      |                  |       |                | CompareError (REQ-082 QT3 follow-up)                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.7   | 07-09-2026     | CompareError matches XPathErrorException.CodeLocalName structurally (FOER0000 family)   |
//                      | Charles Korthout | 2.8   | 09-09-2026     | CompareError matches Q{uri}local expectation form against XPathErrorException structured |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.9   | 16-09-2026     | CompareAssertEmpty peeks one item for lazy (unknown-length) sequences instead of         |
//                      |                  |       |                | failing them outright (REQ-085 wave 5: node tests are lazy-filtered now)                 |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 3.0   | 09-10-2026     | AssertCompatibility static (default XPath31): the qt4 harness sets XPath40 so asserts    |
//                      |                  |       |                | may use 4.0-only functions (char) and string templates (REQ-123 parse-csv slice)         |
//                      |------------------|-------|----------------|------------------------------------------------------------------------------------------|
//                      | Charles Korthout | 3.1   | 09-10-2026     | Recursive entity decoding under the DecodeEntitiesInTestExpressions flag: string-      |
//                      |                  |       |                | valued asserts (assert/assert-eq/assert-deep-eq/assert-type/assert-count/assert-string-  |
//                      |                  |       |                | value/serialization-matches) are expanded a second time; assert-xml/assert-serialization |
//                      |                  |       |                | stay single-expanded (REQ-123 element-to-map slice)                                     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 3.2   | 10-10-2026     | assert-type xs:unsignedLong accepts decimal-backed values carrying the annotation        |
//                      |                  |       |                | (values above long.MaxValue; REQ-123 focus-constructors slice)                          |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;
using Bosak.XPath.Api;
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Providers.Xml;
using Bosak.XPath.Runtime.Vm;
using Bosak.XPath.Standard.Functions;

namespace Bosak.XPath.Conformance;

internal static class ResultComparer
{
    private static readonly XNamespace Ns = "http://www.w3.org/2010/09/qt-fots-catalog";

    /// <summary>
    /// Compatibility level used to compile <c>assert-*</c> expression assertions.
    /// The QT3 harness leaves this at <see cref="XPathCompatibility.XPath31"/>; the qt4
    /// harness sets <see cref="XPathCompatibility.XPath40"/> so assertions may use 4.0
    /// functions (fn:char) and string templates.
    /// </summary>
    public static XPathCompatibility AssertCompatibility { get; set; } = XPathCompatibility.XPath31;

    private static CompileOptions AssertCompileOptions => new() { Compatibility = AssertCompatibility };

    private static XPath31Expression CompileAssert(string expression)
        => XPath31Expression.Compile(expression, AssertCompileOptions);

    public static TestOutcome Compare(XElement resultElement, XdmValue actual, Exception? caughtException, string baseDirectory,
        IReadOnlyDictionary<(string NamespaceUri, string LocalName), string>? outputParameters = null)
    {
        var assertions = resultElement.Elements().ToList();
        if (assertions.Count == 0)
        {
            return new TestOutcome(TestOutcomeKind.Skipped, "No assertion in result");
        }

        // Handle wrapper elements: all-of, any-of
        if (assertions.Count == 1)
        {
            var wrapper = assertions[0];
            if (wrapper.Name == Ns + "all-of")
            {
                return CompareAllOf(wrapper.Elements(), actual, caughtException, baseDirectory, outputParameters);
            }
            if (wrapper.Name == Ns + "any-of")
            {
                return CompareAnyOf(wrapper.Elements(), actual, caughtException, baseDirectory, outputParameters);
            }
        }

        return CompareAssertion(assertions[0], actual, caughtException, baseDirectory, outputParameters);
    }

    private static TestOutcome CompareAllOf(IEnumerable<XElement> assertions, XdmValue actual, Exception? caughtException, string baseDirectory,
        IReadOnlyDictionary<(string NamespaceUri, string LocalName), string>? outputParameters)
    {
        foreach (var assertion in assertions)
        {
            var outcome = CompareAssertion(assertion, actual, caughtException, baseDirectory, outputParameters);
            if (outcome.Kind != TestOutcomeKind.Passed)
                return outcome;
        }
        return new TestOutcome(TestOutcomeKind.Passed, null);
    }

    private static TestOutcome CompareAnyOf(IEnumerable<XElement> assertions, XdmValue actual, Exception? caughtException, string baseDirectory,
        IReadOnlyDictionary<(string NamespaceUri, string LocalName), string>? outputParameters)
    {
        var failures = new List<string>();
        foreach (var assertion in assertions)
        {
            var outcome = CompareAssertion(assertion, actual, caughtException, baseDirectory, outputParameters);
            if (outcome.Kind == TestOutcomeKind.Passed)
                return outcome;
            failures.Add(outcome.Message ?? "failed");
        }
        return new TestOutcome(TestOutcomeKind.Failed, $"any-of: none matched. [{string.Join("; ", failures)}]");
    }

    // Negated assertions: every inner assertion must FAIL for the test to pass.
    private static TestOutcome CompareNot(IEnumerable<XElement> assertions, XdmValue actual, Exception? caughtException, string baseDirectory,
        IReadOnlyDictionary<(string NamespaceUri, string LocalName), string>? outputParameters)
    {
        foreach (var assertion in assertions)
        {
            var outcome = CompareAssertion(assertion, actual, caughtException, baseDirectory, outputParameters);
            if (outcome.Kind == TestOutcomeKind.Passed)
                return new TestOutcome(TestOutcomeKind.Failed, $"not: inner assertion '{assertion.Name.LocalName}' unexpectedly passed");
        }
        return new TestOutcome(TestOutcomeKind.Passed, null);
    }

    private static TestOutcome CompareAssertion(XElement assertion, XdmValue actual, Exception? caughtException, string baseDirectory,
        IReadOnlyDictionary<(string NamespaceUri, string LocalName), string>? outputParameters)
    {
        var name = assertion.Name.LocalName;

        // String-valued assertions of the qt4 suite follow the recursive entity
        // convention: catalog content is entity-expanded once by XML parsing and a
        // second time here (e.g. &amp;amp; -> &amp; -> &), matching the test-expression
        // expansion in TestCase (map-to-element-014 vs fn-iri-to-uri-18A ground truth).
        // assert-xml/assert-serialization stay single-expanded (they are XML documents).
        if (TestCase.DecodeEntitiesInTestExpressions &&
            name is "assert" or "assert-eq" or "assert-deep-eq" or "assert-type" or "assert-count" or "assert-string-value" or "serialization-matches")
        {
            assertion = new XElement(assertion.Name, assertion.Attributes(), TestCase.DecodeEntities(assertion.Value));
        }

        return name switch
        {
            "assert-eq" => CompareAssertEq(assertion.Value, actual, caughtException),
            "assert-true" => CompareAssertTrue(actual, caughtException),
            "assert-false" => CompareAssertFalse(actual, caughtException),
            "assert-string-value" => CompareAssertStringValue(assertion, actual, caughtException),
            "assert-empty" => CompareAssertEmpty(actual, caughtException),
            "error" => CompareError((string?)assertion.Attribute("code") ?? "", caughtException),
            "assert-serialization-error" => CompareSerializationError((string?)assertion.Attribute("code") ?? "", actual, caughtException, outputParameters, baseDirectory),
            "serialization-matches" => CompareSerializationMatches(assertion.Value, (string?)assertion.Attribute("flags") ?? "", actual, caughtException, outputParameters, baseDirectory),
            "assert-serialization" => CompareAssertSerialization(assertion.Value, actual, caughtException, outputParameters, baseDirectory),
            "assert-type" => CompareAssertType(assertion.Value, actual, caughtException),
            "assert-xml" => CompareAssertXml(assertion, actual, caughtException, baseDirectory),
            "assert-deep-eq" => CompareAssertDeepEq(assertion, actual, caughtException),
            "all-of" => CompareAllOf(assertion.Elements(), actual, caughtException, baseDirectory, outputParameters),
            "any-of" => CompareAnyOf(assertion.Elements(), actual, caughtException, baseDirectory, outputParameters),
            "not" => CompareNot(assertion.Elements(), actual, caughtException, baseDirectory, outputParameters),
            "assert-count" => CompareAssertCount((string?)assertion.Attribute("count") ?? assertion.Value.Trim(), actual, caughtException),
            "assert-permutation" => CompareAssertPermutation(assertion, actual, caughtException),
            "assert" => CompareAssert(assertion.Value, actual, caughtException),
            _ => new TestOutcome(TestOutcomeKind.Skipped, $"Unknown assertion: {name}"),
        };
    }

    /// <summary>
    /// Creates the evaluation context for compiling FOTS assertion expressions.
    /// Beyond the engine's predefined namespaces, QT3 drivers are expected to
    /// pre-bind the j prefix (the XML representation of JSON); several tests use
    /// it in assertions without a declared environment namespace (json-to-xml-008/009).
    /// </summary>
    private static EvaluationContext NewAssertContext()
    {
        var ctx = new EvaluationContext();
        FunctionLibrary.Populate(ctx);
        return ctx.WithNamespace("j", "http://www.w3.org/2005/xpath-functions");
    }

    private static TestOutcome CompareAssertEq(string expectedExpr, XdmValue actual, Exception? caughtException)
    {
        if (caughtException is not null)
            return new TestOutcome(TestOutcomeKind.Failed, $"Unexpected error: {caughtException.Message}");

        try
        {
            var ctx = NewAssertContext();
            var expected = CompileAssert(expectedExpr).Evaluate(ctx);
            // assert-eq compares values: a singleton sequence is equivalent to its single item
            // (e.g. fn:node-name() returning a sequence of one QName vs the expected QName).
            if (ValuesEqual(UnwrapSingleton(actual), UnwrapSingleton(expected)))
                return new TestOutcome(TestOutcomeKind.Passed, null);

            return new TestOutcome(TestOutcomeKind.Failed,
                $"assert-eq failed. Expected: {SerializeValue(expected)}, Got: {SerializeValue(actual)}");
        }
        catch (Exception ex)
        {
            return new TestOutcome(TestOutcomeKind.Skipped, $"Could not evaluate expected expression '{expectedExpr}': {ex.Message}");
        }
    }

    /// <summary>
    /// If the value is a singleton sequence, returns its single item; otherwise returns the value as-is.
    /// Used by assert-true and assert-false to handle functions that return a singleton sequence.
    /// </summary>
    private static XdmValue UnwrapSingleton(XdmValue value)
    {
        if (value.Kind == XdmValueKind.Sequence && value.SequenceValue is not null &&
            value.SequenceValue.TryGetLength(out var len) && len == 1)
        {
            foreach (var item in XdmSequence.FromSource(value.SequenceValue))
                return item;
        }
        return value;
    }

    private static TestOutcome CompareAssertTrue(XdmValue actual, Exception? caughtException)
    {
        if (caughtException is not null)
            return new TestOutcome(TestOutcomeKind.Failed, $"Unexpected error: {caughtException.Message}");

        var value = UnwrapSingleton(actual);
        if (!value.IsUndefined && value.Kind == XdmValueKind.Boolean && value.BooleanValue)
            return new TestOutcome(TestOutcomeKind.Passed, null);

        return new TestOutcome(TestOutcomeKind.Failed, $"assert-true failed. Got: {SerializeValue(actual)}");
    }

    private static TestOutcome CompareAssertFalse(XdmValue actual, Exception? caughtException)
    {
        if (caughtException is not null)
            return new TestOutcome(TestOutcomeKind.Failed, $"Unexpected error: {caughtException.Message}");

        var value = UnwrapSingleton(actual);
        if (!value.IsUndefined && value.Kind == XdmValueKind.Boolean && !value.BooleanValue)
            return new TestOutcome(TestOutcomeKind.Passed, null);

        return new TestOutcome(TestOutcomeKind.Failed, $"assert-false failed. Got: {SerializeValue(actual)}");
    }

    private static TestOutcome CompareAssertStringValue(XElement assertion, XdmValue actual, Exception? caughtException)
    {
        if (caughtException is not null)
            return new TestOutcome(TestOutcomeKind.Failed, $"Unexpected error: {caughtException.Message}");

        string expected = assertion.Value;
        string actualStr = SerializeValue(actual);
        bool doNormalize = assertion.Attribute("normalize-space")?.Value == "true";

        if (doNormalize)
        {
            expected = NormalizeSpace(expected);
            actualStr = NormalizeSpace(actualStr);
        }
        else
        {
            // Some expected values contain literal newlines (e.g. fn:unparsed-text
            // raw text results) while others contain formatting newlines introduced
            // by XML indentation. Try the exact value first, then fall back to a
            // version where newlines are collapsed to a single space.
            if (actualStr == expected)
                return new TestOutcome(TestOutcomeKind.Passed, null);
            expected = expected.Replace("\r\n", "\n").Replace("\n", " ");
        }

        if (actualStr == expected)
            return new TestOutcome(TestOutcomeKind.Passed, null);

        return new TestOutcome(TestOutcomeKind.Failed, $"assert-string-value failed. Expected: '{expected}', Got: '{actualStr}'");
    }

    private static string NormalizeSpace(string input)
    {
        if (string.IsNullOrEmpty(input))
            return string.Empty;

        var sb = new System.Text.StringBuilder(input.Length);
        bool inWhitespace = true; // skip leading whitespace
        foreach (char c in input)
        {
            if (char.IsWhiteSpace(c))
            {
                inWhitespace = true;
            }
            else
            {
                if (inWhitespace && sb.Length > 0)
                    sb.Append(' ');
                sb.Append(c);
                inWhitespace = false;
            }
        }
        return sb.ToString();
    }

    private static TestOutcome CompareAssertEmpty(XdmValue actual, Exception? caughtException)
    {
        if (caughtException is not null)
            return new TestOutcome(TestOutcomeKind.Failed, $"Unexpected error: {caughtException.Message}");

        if (actual.IsUndefined)
            return new TestOutcome(TestOutcomeKind.Passed, null);

        if (actual.IsSequence && actual.SequenceValue is not null)
        {
            if (actual.SequenceValue.TryGetLength(out var len))
            {
                if (len == 0)
                    return new TestOutcome(TestOutcomeKind.Passed, null);
            }
            else
            {
                // Lazy sequence: length is unknown — peek one item to detect emptiness.
                var enumerator = XdmSequence.FromSource(actual.SequenceValue).GetEnumerator();
                if (!enumerator.MoveNext())
                    return new TestOutcome(TestOutcomeKind.Passed, null);
            }
        }

        return new TestOutcome(TestOutcomeKind.Failed, $"assert-empty failed. Got: {SerializeValue(actual)}");
    }

    private static TestOutcome CompareError(string expectedCode, Exception? caughtException)
    {
        if (caughtException is null)
            return new TestOutcome(TestOutcomeKind.Failed, $"Expected error {expectedCode} but succeeded");

        // Wildcard: any error outcome is acceptable.
        if (expectedCode is "*" or "")
            return new TestOutcome(TestOutcomeKind.Passed, null);

        // Strict matching (REQ-082 QT3 follow-up, 2026-09-07): the declared error code
        // must appear in the exception message. The previous lenient fallback accepted
        // any InvalidOperationException, masking wrong-code passes.
        // Structured match first: XPathErrorException (fn:error, xqt errors) carries the
        // code explicitly — its Message is the description only (FOER0000 family).
        for (Exception? cur = caughtException; cur is not null; cur = cur.InnerException)
        {
            if (cur is not XPathErrorException xee)
                continue;
            if (xee.CodeLocalName.Equals(expectedCode, StringComparison.OrdinalIgnoreCase))
                return new TestOutcome(TestOutcomeKind.Passed, null);
            // EQName expectation form Q{uri}local matches the structured code's namespace + local.
            if (expectedCode.StartsWith("Q{", StringComparison.Ordinal)
                && expectedCode.IndexOf('}') is int closeBrace && closeBrace > 2
                && xee.CodeNamespaceUri.Equals(expectedCode[2..closeBrace], StringComparison.Ordinal)
                && xee.CodeLocalName.Equals(expectedCode[(closeBrace + 1)..], StringComparison.OrdinalIgnoreCase))
                return new TestOutcome(TestOutcomeKind.Passed, null);
        }

        string message = caughtException.Message;
        if (message.Contains(expectedCode, StringComparison.OrdinalIgnoreCase))
            return new TestOutcome(TestOutcomeKind.Passed, null);

        return new TestOutcome(TestOutcomeKind.Failed, $"Expected error {expectedCode}, got: {message}");
    }

    // Serializes the actual result through fn:serialize (the error assertion targets the
    // serialization step, which may fail even when evaluation succeeded). The query's static
    // output declarations (declare option output:*) flow in via outputParameters; relative
    // parameter-document URIs resolve against the test-set directory.
    private static string SerializeActual(XdmValue actual,
        IReadOnlyDictionary<(string NamespaceUri, string LocalName), string>? outputParameters,
        string baseDirectory)
    {
        var ctx = NewAssertContext();
        ctx.BaseUri = new Uri(baseDirectory + Path.DirectorySeparatorChar).AbsoluteUri;
        if (outputParameters is not null)
            ctx.StaticOutputParameters = outputParameters;
        ctx.WithVariable("bosak_ser_result", actual);
        return CompileAssert("fn:serialize($bosak_ser_result)").Evaluate(ctx).ToString();
    }

    private static TestOutcome CompareSerializationError(string expectedCode, XdmValue actual, Exception? caughtException,
        IReadOnlyDictionary<(string NamespaceUri, string LocalName), string>? outputParameters, string baseDirectory)
    {
        // The error may already have surfaced during evaluation.
        if (caughtException is not null)
            return CompareError(expectedCode, caughtException);
        try
        {
            _ = SerializeActual(actual, outputParameters, baseDirectory);
            return new TestOutcome(TestOutcomeKind.Failed, $"Expected serialization error {expectedCode} but succeeded");
        }
        catch (Exception ex)
        {
            return CompareError(expectedCode, ex);
        }
    }

    private static TestOutcome CompareSerializationMatches(string pattern, string flags, XdmValue actual, Exception? caughtException,
        IReadOnlyDictionary<(string NamespaceUri, string LocalName), string>? outputParameters, string baseDirectory)
    {
        if (caughtException is not null)
            return new TestOutcome(TestOutcomeKind.Failed, $"Unexpected error: {caughtException.Message}");
        try
        {
            var serialized = SerializeActual(actual, outputParameters, baseDirectory);
            // The 'q' flag (as in fn:matches) quotes the pattern: a literal substring match.
            if (flags.Contains('q'))
            {
                return serialized.Contains(pattern, StringComparison.Ordinal)
                    ? new TestOutcome(TestOutcomeKind.Passed, null)
                    : new TestOutcome(TestOutcomeKind.Failed, $"serialization-matches failed. Pattern: '{pattern}', Got: '{serialized}'");
            }
            var options = RegexOptions.Singleline;
            if (flags.Contains('i')) options |= RegexOptions.IgnoreCase;
            if (flags.Contains('x')) options |= RegexOptions.IgnorePatternWhitespace;
            if (flags.Contains('m')) options &= ~RegexOptions.Singleline;
            return Regex.IsMatch(serialized, pattern, options)
                ? new TestOutcome(TestOutcomeKind.Passed, null)
                : new TestOutcome(TestOutcomeKind.Failed, $"serialization-matches failed. Pattern: '{pattern}', Got: '{serialized}'");
        }
        catch (Exception ex)
        {
            return new TestOutcome(TestOutcomeKind.Failed, $"serialization-matches error: {ex.Message}");
        }
    }

    private static TestOutcome CompareAssertSerialization(string expected, XdmValue actual, Exception? caughtException,
        IReadOnlyDictionary<(string NamespaceUri, string LocalName), string>? outputParameters, string baseDirectory)
    {
        if (caughtException is not null)
            return new TestOutcome(TestOutcomeKind.Failed, $"Unexpected error: {caughtException.Message}");
        try
        {
            var serialized = SerializeActual(actual, outputParameters, baseDirectory);
            return string.Equals(serialized, expected, StringComparison.Ordinal)
                ? new TestOutcome(TestOutcomeKind.Passed, null)
                : new TestOutcome(TestOutcomeKind.Failed, $"assert-serialization failed. Expected: '{expected}', Got: '{serialized}'");
        }
        catch (Exception ex)
        {
            return new TestOutcome(TestOutcomeKind.Failed, $"assert-serialization error: {ex.Message}");
        }
    }

    private static bool ValuesEqual(XdmValue a, XdmValue b)
    {
        // Handle undefined (empty sequence)
        if (a.IsUndefined && b.IsUndefined)
            return true;
        if (a.IsUndefined || b.IsUndefined)
            return false;

        // For atomic values, compare by string representation as a heuristic
        // This is not fully spec-correct but works for most assert-eq cases
        string sa = SerializeValue(a);
        string sb = SerializeValue(b);
        if (sa == sb)
            return true;

        // DateTime/Date/Time value comparison: compare instants (timezone-independent).
        // For extended years that cannot be represented by DateTimeOffset, fall back to
        // canonical string comparison (same lexical form => same value).
        if (a.Kind == XdmValueKind.DateTime && b.Kind == XdmValueKind.DateTime)
        {
            var aXdt = a.DateTimeXPathValue;
            var bXdt = b.DateTimeXPathValue;
            if (aXdt.IsRepresentableAsDateTimeOffset && bXdt.IsRepresentableAsDateTimeOffset)
                return a.DateTimeValue == b.DateTimeValue;
            return SerializeValue(a) == SerializeValue(b);
        }
        if (a.Kind == XdmValueKind.Date && b.Kind == XdmValueKind.Date)
        {
            var aXdt = a.DateXPathValue;
            var bXdt = b.DateXPathValue;
            if (aXdt.IsRepresentableAsDateTimeOffset && bXdt.IsRepresentableAsDateTimeOffset)
                return a.DateValue == b.DateValue;
            return SerializeValue(a) == SerializeValue(b);
        }
        if (a.Kind == XdmValueKind.Time && b.Kind == XdmValueKind.Time)
        {
            var aXdt = a.TimeXPathValue;
            var bXdt = b.TimeXPathValue;
            if (aXdt.IsRepresentableAsDateTimeOffset && bXdt.IsRepresentableAsDateTimeOffset)
                return a.TimeValue == b.TimeValue;
            return SerializeValue(a) == SerializeValue(b);
        }

        // QName comparison: compare namespace URI and local name (prefix is ignored per XPath spec)
        if (a.Kind == XdmValueKind.QName && b.Kind == XdmValueKind.QName)
        {
            return a.QNameValue.NamespaceUri == b.QNameValue.NamespaceUri
                && a.QNameValue.LocalName == b.QNameValue.LocalName;
        }

        // Numeric value comparison: decimals may differ in trailing zeros (13 vs 13.0)
        bool aIsNumeric = a.Kind is XdmValueKind.Integer or XdmValueKind.Decimal or XdmValueKind.Double or XdmValueKind.Float;
        bool bIsNumeric = b.Kind is XdmValueKind.Integer or XdmValueKind.Decimal or XdmValueKind.Double or XdmValueKind.Float;
        if (aIsNumeric && bIsNumeric)
        {
            bool aIsNaN = a.Kind is XdmValueKind.Double or XdmValueKind.Float && double.IsNaN(a.DoubleValue);
            bool bIsNaN = b.Kind is XdmValueKind.Double or XdmValueKind.Float && double.IsNaN(b.DoubleValue);
            if (aIsNaN && bIsNaN) return true;
            if (aIsNaN || bIsNaN) return false;

            if (a.Kind == XdmValueKind.Double || b.Kind == XdmValueKind.Double)
            {
                double da = a.Kind == XdmValueKind.Double ? a.DoubleValue
                          : a.Kind == XdmValueKind.Integer ? a.IntegerValue
                          : a.Kind == XdmValueKind.Decimal ? (double)a.DecimalValue
                          : a.DoubleValue;
                double db = b.Kind == XdmValueKind.Double ? b.DoubleValue
                          : b.Kind == XdmValueKind.Integer ? b.IntegerValue
                          : b.Kind == XdmValueKind.Decimal ? (double)b.DecimalValue
                          : b.DoubleValue;
                return da == db;
            }

            if (a.Kind == XdmValueKind.Float || b.Kind == XdmValueKind.Float)
            {
                float fa = a.Kind == XdmValueKind.Float ? (float)a.DoubleValue
                         : a.Kind == XdmValueKind.Integer ? a.IntegerValue
                         : a.Kind == XdmValueKind.Decimal ? (float)a.DecimalValue
                         : (float)a.DoubleValue;
                float fb = b.Kind == XdmValueKind.Float ? (float)b.DoubleValue
                         : b.Kind == XdmValueKind.Integer ? b.IntegerValue
                         : b.Kind == XdmValueKind.Decimal ? (float)b.DecimalValue
                         : (float)b.DoubleValue;
                return fa == fb;
            }

            if (a.Kind == XdmValueKind.Decimal || b.Kind == XdmValueKind.Decimal)
            {
                decimal da = a.Kind == XdmValueKind.Decimal ? a.DecimalValue
                           : a.Kind == XdmValueKind.Integer ? a.IntegerValue
                           : (decimal)a.DoubleValue;
                decimal db = b.Kind == XdmValueKind.Decimal ? b.DecimalValue
                           : b.Kind == XdmValueKind.Integer ? b.IntegerValue
                           : (decimal)b.DoubleValue;
                return da == db;
            }

            double dva = a.Kind == XdmValueKind.Integer ? a.IntegerValue : a.DoubleValue;
            double dvb = b.Kind == XdmValueKind.Integer ? b.IntegerValue : b.DoubleValue;
            return dva == dvb;
        }

        return false;
    }

    private static string SerializeValue(XdmValue value)
    {
        if (value.IsUndefined)
            return "";

        if (value.IsSequence && value.SequenceValue is not null)
        {
            var items = new List<string>();
            foreach (var item in XdmSequence.FromSource(value.SequenceValue))
            {
                items.Add(SerializeSingle(item));
            }
            return string.Join(" ", items);
        }

        return SerializeSingle(value);
    }

    private static string SerializeSingle(XdmValue value)
    {
        if (value.IsUndefined)
            return "";
        if (value.IsNode)
            return value.NodeValue?.StringValue ?? "";
        if (value.IsAtomic)
        {
            if (value.Kind == XdmValueKind.Boolean)
                return value.BooleanValue ? "true" : "false";
            if (value.Kind == XdmValueKind.Double || value.Kind == XdmValueKind.Float)
            {
                return value.ToString();
            }
            if (value.Kind == XdmValueKind.Integer)
                return value.IntegerValue.ToString(System.Globalization.CultureInfo.InvariantCulture);
            if (value.Kind == XdmValueKind.Decimal)
                return FormatCanonicalDecimal(value.DecimalValue);
            if (value.Kind == XdmValueKind.String)
                return value.StringValue;
            if (value.Kind is XdmValueKind.DateTime or XdmValueKind.Date or XdmValueKind.Time)
                return value.ToString();
            if (value.Kind == XdmValueKind.Duration)
                return value.DurationValue;
            return value.ToString();
        }
        return value.ToString();
    }

    private static TestOutcome CompareAssertType(string expectedType, XdmValue actual, Exception? caughtException)
    {
        if (caughtException is not null)
            return new TestOutcome(TestOutcomeKind.Failed, $"assert-type failed. Unexpected error: {caughtException.Message}");

        // Parse cardinality suffix
        bool allowMany = expectedType.EndsWith("*");
        bool allowOneOrMore = expectedType.EndsWith("+");
        bool allowZeroOrOne = expectedType.EndsWith("?");
        string baseType = expectedType.TrimEnd('*', '+', '?');

        // empty-sequence() is satisfied precisely by the empty sequence
        // (fn-function-name-013/014: fn:function-name of an anonymous function).
        if (baseType == "empty-sequence()")
        {
            bool isEmpty = actual.IsUndefined ||
                (actual.IsSequence && actual.SequenceValue is not null &&
                 !XdmSequence.FromSource(actual.SequenceValue).GetEnumerator().MoveNext());
            return isEmpty
                ? new TestOutcome(TestOutcomeKind.Passed, null)
                : new TestOutcome(TestOutcomeKind.Failed, $"assert-type failed. Expected {expectedType}, got non-empty sequence");
        }

        if (actual.IsUndefined)
        {
            // The empty sequence also satisfies any optional cardinality (* or ?).
            if (allowMany || allowZeroOrOne)
                return new TestOutcome(TestOutcomeKind.Passed, null);
            return new TestOutcome(TestOutcomeKind.Failed, $"assert-type failed. Expected {expectedType}, got empty sequence");
        }

        // Materialize sequence to check cardinality and item types
        List<XdmValue> items = new();
        if (actual.IsSequence && actual.SequenceValue is not null)
        {
            foreach (var item in XdmSequence.FromSource(actual.SequenceValue))
                items.Add(item);
        }
        else
        {
            items.Add(actual);
        }

        if (allowMany)
        {
            // Any cardinality allowed
        }
        else if (allowOneOrMore)
        {
            if (items.Count == 0)
                return new TestOutcome(TestOutcomeKind.Failed, $"assert-type failed. Expected {expectedType}, got empty sequence");
        }
        else if (allowZeroOrOne)
        {
            if (items.Count > 1)
                return new TestOutcome(TestOutcomeKind.Failed, $"assert-type failed. Expected {expectedType}, got {items.Count} items");
        }
        else
        {
            if (items.Count != 1)
                return new TestOutcome(TestOutcomeKind.Failed, $"assert-type failed. Expected {expectedType}, got {items.Count} items");
        }

        foreach (var item in items)
        {
            if (!ItemMatchesType(item, baseType, expectedType))
                return new TestOutcome(TestOutcomeKind.Failed, $"assert-type failed. Expected {expectedType}, got {item.Kind}");
        }

        return new TestOutcome(TestOutcomeKind.Passed, null);
    }

    private static bool ItemMatchesType(XdmValue item, string baseType, string fullType)
    {
        // Parameterized types (function/map/array and other parenthesized forms) go
        // through the engine's instance-of with the full type expression.
        if (baseType.Contains('('))
            return EngineMatchesType(item, fullType);
        return ItemMatchesType(item, baseType);
    }

    private static bool EngineMatchesType(XdmValue item, string fullType)
    {
        try
        {
            var ctx = NewAssertContext();
            ctx.WithVariable("result", item);
            var result = CompileAssert($"$result instance of {fullType}").Evaluate(ctx);
            return result.BooleanValue;
        }
        catch
        {
            return true; // lenient for unparseable type expressions
        }
    }

    private static bool ItemMatchesType(XdmValue item, string typeName)
    {
        string normalized = typeName.ToLowerInvariant().Replace("xs:", "").Replace(" ", "");

        if (normalized == "item")
            return !item.IsUndefined;

        if (normalized.StartsWith("document-node()"))
            return item.IsNode && item.NodeValue?.NodeKind == XdmNodeKind.Document;

        return normalized switch
        {
            "string" => item.Kind == XdmValueKind.String,
            // xs:unsignedLong values above long.MaxValue are decimal-backed (long is the
            // engine's integer representation) but carry the xs:unsignedLong annotation.
            "unsignedlong" => item.Kind == XdmValueKind.Integer
                || (item.Kind == XdmValueKind.Decimal
                    && string.Equals(item.SchemaTypeName, "unsignedlong", StringComparison.OrdinalIgnoreCase)),
            "integer" or "int" or "long" or "short" or "byte"
                or "unsignedshort" or "unsignedint" or "unsignedbyte"
                or "positiveinteger" or "negativeinteger" or "nonpositiveinteger" or "nonnegativeinteger"
                => item.Kind == XdmValueKind.Integer,
            // xs:integer is a subtype of xs:decimal, so integer values match xs:decimal
            // (assert-type is an instance-of check per the FOTS specification).
            "decimal" => item.Kind is XdmValueKind.Decimal or XdmValueKind.Integer,
            "double" => item.Kind == XdmValueKind.Double,
            "float" => item.Kind == XdmValueKind.Float,
            "boolean" => item.Kind == XdmValueKind.Boolean,
            "datetime" => item.Kind == XdmValueKind.DateTime,
            "date" => item.Kind == XdmValueKind.Date,
            "time" => item.Kind == XdmValueKind.Time,
            "duration" or "daytimeduration" or "yearmonthduration" => item.Kind == XdmValueKind.Duration,
            "qname" => item.Kind == XdmValueKind.QName,
            "node" => item.IsNode,
            "anyatomictype" => item.IsAtomic,
            "base64binary" or "hexbinary" => item.Kind == XdmValueKind.String, // approximate
            _ => true // lenient for unimplemented types
        };
    }

    private static string FormatDoubleString(string s)
    {
        // XPath serialization does not use '+' in exponent: E+308 -> E308
        return s.Replace("E+", "E");
    }

    private static string FormatCanonicalDecimal(decimal value)
    {
        string s = value.ToString(System.Globalization.CultureInfo.InvariantCulture);
        if (s.Contains('.'))
        {
            s = s.TrimEnd('0').TrimEnd('.');
        }
        return string.IsNullOrEmpty(s) ? "0" : s;
    }

    private static TestOutcome CompareAssert(string assertExpr, XdmValue actual, Exception? caughtException)
    {
        if (caughtException is not null)
            return new TestOutcome(TestOutcomeKind.Failed, $"Unexpected error: {caughtException.Message}");

        try
        {
            var ctx = NewAssertContext();
            ctx = ctx.WithVariable("result", actual);
            // FOTS assertions may also address the result through the context item
            // (absolute paths such as /result/impl in prod/ModuleImport).
            if (!actual.IsUndefined)
                ctx = ctx.WithFocus(actual, 1, 1);
            var result = CompileAssert(assertExpr).Evaluate(ctx);
            // FOTS assert expressions are truthy: the effective boolean value decides.
            if (EffectiveBooleanValue(result))
                return new TestOutcome(TestOutcomeKind.Passed, null);
            return new TestOutcome(TestOutcomeKind.Failed, $"assert failed. Expression: {assertExpr}, Got: {SerializeValue(result)}");
        }
        catch (Exception ex)
        {
            return new TestOutcome(TestOutcomeKind.Failed, $"assert evaluation failed: {ex.Message}");
        }
    }

    private static TestOutcome CompareAssertCount(string expectedCountStr, XdmValue actual, Exception? caughtException)
    {
        if (caughtException is not null)
            return new TestOutcome(TestOutcomeKind.Failed, $"Unexpected error: {caughtException.Message}");

        if (!int.TryParse(expectedCountStr, out int expectedCount))
            return new TestOutcome(TestOutcomeKind.Skipped, $"Invalid assert-count value: {expectedCountStr}");

        int actualCount = 0;
        if (actual.IsUndefined)
            actualCount = 0;
        else if (actual.IsSequence && actual.SequenceValue is not null)
        {
            foreach (var _ in XdmSequence.FromSource(actual.SequenceValue))
                actualCount++;
        }
        else
            actualCount = 1;

        if (actualCount == expectedCount)
            return new TestOutcome(TestOutcomeKind.Passed, null);

        return new TestOutcome(TestOutcomeKind.Failed, $"assert-count failed. Expected: {expectedCount}, Got: {actualCount}");
    }

    private static TestOutcome CompareAssertDeepEq(XElement assertion, XdmValue actual, Exception? caughtException)
    {
        if (caughtException is not null)
            return new TestOutcome(TestOutcomeKind.Failed, $"Unexpected error: {caughtException.Message}");

        var expectedExpr = assertion.Value.Trim();
        if (string.IsNullOrEmpty(expectedExpr))
            return new TestOutcome(TestOutcomeKind.Skipped, "assert-deep-eq: no expected expressions");

        try
        {
            var ctx = NewAssertContext();
            var expectedValue = CompileAssert(expectedExpr).Evaluate(ctx);
            var expectedItems = MaterializeValue(expectedValue);
            var actualItems = MaterializeValue(actual);

            if (expectedItems.Count != actualItems.Count)
                return new TestOutcome(TestOutcomeKind.Failed, $"assert-deep-eq failed. Expected {expectedItems.Count} items, got {actualItems.Count}");

            for (int i = 0; i < expectedItems.Count; i++)
            {
                if (!DeepEqual(expectedItems[i], actualItems[i]))
                    return new TestOutcome(TestOutcomeKind.Failed, $"assert-deep-eq failed at item {i}. Expected: {SerializeValue(expectedItems[i])}, Got: {SerializeValue(actualItems[i])}");
            }

            return new TestOutcome(TestOutcomeKind.Passed, null);
        }
        catch (Exception ex)
        {
            return new TestOutcome(TestOutcomeKind.Skipped, $"Could not evaluate assert-deep-eq: {ex.Message}");
        }
    }

    private static TestOutcome CompareAssertPermutation(XElement assertion, XdmValue actual, Exception? caughtException)
    {
        if (caughtException is not null)
            return new TestOutcome(TestOutcomeKind.Failed, $"Unexpected error: {caughtException.Message}");

        var expectedExpr = assertion.Value.Trim();
        if (string.IsNullOrEmpty(expectedExpr))
            return new TestOutcome(TestOutcomeKind.Skipped, "assert-permutation: no expected expression");

        try
        {
            var ctx = NewAssertContext();
            var expectedItems = MaterializeValue(CompileAssert(expectedExpr).Evaluate(ctx));
            var actualItems = MaterializeValue(actual);

            if (expectedItems.Count != actualItems.Count)
                return new TestOutcome(TestOutcomeKind.Failed, $"assert-permutation failed. Expected {expectedItems.Count} items, got {actualItems.Count}");

            // Order-insensitive multiset match using deep-equal semantics.
            var remaining = new List<XdmValue>(expectedItems);
            foreach (var actualItem in actualItems)
            {
                int match = remaining.FindIndex(e => DeepEqual(e, actualItem));
                if (match < 0)
                    return new TestOutcome(TestOutcomeKind.Failed, $"assert-permutation failed. No expected match for: {SerializeValue(actualItem)}");
                remaining.RemoveAt(match);
            }

            return new TestOutcome(TestOutcomeKind.Passed, null);
        }
        catch (Exception ex)
        {
            return new TestOutcome(TestOutcomeKind.Skipped, $"Could not evaluate assert-permutation: {ex.Message}");
        }
    }

    private static bool EffectiveBooleanValue(XdmValue value)
    {
        if (value.IsUndefined)
            return false;
        if (value.Kind == XdmValueKind.Boolean)
            return value.BooleanValue;
        if (value.IsNode)
            return true;
        if (value.IsSequence && value.SequenceValue is not null)
        {
            var items = MaterializeValue(value);
            if (items.Count == 0)
                return false;
            if (items[0].IsNode)
                return true;
            if (items.Count > 1)
                return false; // EBV error for multiple atomics; treat as not-true
            return AtomicEffectiveBooleanValue(items[0]);
        }
        return AtomicEffectiveBooleanValue(value);
    }

    private static bool AtomicEffectiveBooleanValue(XdmValue value) => value.Kind switch
    {
        XdmValueKind.Boolean => value.BooleanValue,
        XdmValueKind.String => value.StringValue.Length > 0,
        XdmValueKind.Integer => value.IntegerValue != 0,
        XdmValueKind.Decimal => value.DecimalValue != 0,
        XdmValueKind.Double => value.DoubleValue != 0 && !double.IsNaN(value.DoubleValue),
        XdmValueKind.Float => value.DoubleValue != 0 && !double.IsNaN(value.DoubleValue),
        _ => false
    };

    private static List<XdmValue> MaterializeValue(XdmValue value)
    {
        var result = new List<XdmValue>();
        if (value.IsUndefined)
            return result;
        if (value.IsSequence && value.SequenceValue is not null)
        {
            foreach (var item in XdmSequence.FromSource(value.SequenceValue))
                result.Add(item);
        }
        else
        {
            result.Add(value);
        }
        return result;
    }

    private static TestOutcome CompareAssertXml(XElement assertion, XdmValue actual, Exception? caughtException, string baseDirectory)
    {
        if (caughtException is not null)
            return new TestOutcome(TestOutcomeKind.Failed, $"Unexpected error: {caughtException.Message}");

        string expectedXml = assertion.Value;
        string? file = (string?)assertion.Attribute("file");
        if (!string.IsNullOrEmpty(file))
        {
            try
            {
                string path = Path.GetFullPath(file, baseDirectory);
                expectedXml = File.ReadAllText(path);
            }
            catch (Exception ex)
            {
                return new TestOutcome(TestOutcomeKind.Failed, $"assert-xml file load failed: {ex.Message}");
            }
        }

        bool ignorePrefixes = (string?)assertion.Attribute("ignore-prefixes") == "true";

        string expectedNorm = NormalizeXml(expectedXml, ignorePrefixes);
        string actualNorm = NormalizeActualXml(actual, ignorePrefixes);

        if (expectedNorm == actualNorm)
            return new TestOutcome(TestOutcomeKind.Passed, null);

        return new TestOutcome(TestOutcomeKind.Failed,
            $"assert-xml failed. Expected: {expectedNorm}, Got: {actualNorm}");
    }

    /// <summary>
    /// Serializes the actual result for assert-xml comparison. Nodes are written
    /// with an XmlWriter that synthesizes namespace declarations (constructed trees
    /// carry none as attributes) and entitizes newlines, so a CR in content is
    /// written as &amp;#xD; and survives the re-parse (json-to-xml-048) instead of
    /// being normalized to LF as with the default XNode.ToString serialization.
    /// </summary>
    private static string NormalizeActualXml(XdmValue actual, bool ignorePrefixes)
    {
        if (actual.IsNode && actual.NodeValue is XDocumentNode xdn)
        {
            try
            {
                var sb = new StringBuilder();
                var settings = new XmlWriterSettings
                {
                    OmitXmlDeclaration = true,
                    ConformanceLevel = ConformanceLevel.Fragment,
                    NewLineHandling = NewLineHandling.Entitize
                };
                using (var writer = XmlWriter.Create(sb, settings))
                {
                    switch (xdn.UnderlyingObject)
                    {
                        // Unwrap the synthetic document wrapper like ToXmlString does.
                        case XDocument wrapped when wrapped.Root?.Name.LocalName == "__xdm_doc__":
                            foreach (var child in wrapped.Root.Nodes())
                                child.WriteTo(writer);
                            break;
                        case XDocument doc:
                            foreach (var child in doc.Nodes())
                                child.WriteTo(writer);
                            break;
                        case XNode xnode:
                            xnode.WriteTo(writer);
                            break;
                        default:
                            // Attributes and other non-XNode values use the generic serializer.
                            return NormalizeXml(SerializeToXml(actual), ignorePrefixes);
                    }
                }
                return NormalizeXml(sb.ToString(), ignorePrefixes);
            }
            catch
            {
                // Content the writer rejects (e.g. characters invalid in XML) falls
                // back to the generic serialization.
                return NormalizeXml(SerializeToXml(actual), ignorePrefixes);
            }
        }
        return NormalizeXml(SerializeToXml(actual), ignorePrefixes);
    }

    private static string SerializeToXml(XdmValue value)
    {
        if (value.IsUndefined)
            return "";

        if (value.IsSequence && value.SequenceValue is not null)
        {
            var parts = new List<string>();
            foreach (var item in XdmSequence.FromSource(value.SequenceValue))
                parts.Add(SerializeSingleToXml(item));
            return string.Join("", parts);
        }

        return SerializeSingleToXml(value);
    }

    private static string SerializeSingleToXml(XdmValue value)
    {
        if (value.IsNode)
            return value.NodeValue?.ToXmlString() ?? "";
        return SerializeSingle(value);
    }

    private static string NormalizeXml(string xml, bool ignorePrefixes)
    {
        if (string.IsNullOrWhiteSpace(xml))
            return "";

        try
        {
            var doc = XDocument.Parse(xml, LoadOptions.PreserveWhitespace);
            return CanonicalSerialize(doc.Root!, ignorePrefixes);
        }
        catch
        {
            // Multi-root fragments are not valid XDocument/XElement input, but they
            // commonly occur in assert-xml results (e.g. union/intersect of several
            // element nodes). Wrap the fragment in a temporary root, canonicalize,
            // and strip the wrapper tags so attribute order is normalized.
            try
            {
                const string wrapper = "__x__";
                string wrapped = $"<{wrapper}>{xml}</{wrapper}>";
                var doc = XDocument.Parse(wrapped, LoadOptions.PreserveWhitespace);
                return ExtractWrappedCanonical(xml, doc.Root!, wrapper, ignorePrefixes);
            }
            catch
            {
                // XML 1.1-only name characters (e.g. U+037F, U+017F) cannot be parsed
                // by .NET's XML 1.0 reader. Force XML 1.1 parsing and decode the names
                // during canonicalization.
                try
                {
                    var doc = Xml11Loader.ParseXml11(xml, LoadOptions.PreserveWhitespace);
                    return CanonicalSerialize(doc.Root!, ignorePrefixes);
                }
                catch
                {
                    try
                    {
                        const string wrapper = "__x__";
                        string wrapped = $"<{wrapper}>{xml}</{wrapper}>";
                        var doc = Xml11Loader.ParseXml11(wrapped, LoadOptions.PreserveWhitespace);
                        return ExtractWrappedCanonical(xml, doc.Root!, wrapper, ignorePrefixes);
                    }
                    catch
                    {
                        // If wrapping also fails, try as a single element for backward compatibility.
                        try
                        {
                            var el = XElement.Parse(xml, LoadOptions.PreserveWhitespace);
                            return CanonicalSerialize(el, ignorePrefixes);
                        }
                        catch
                        {
                            return xml;
                        }
                    }
                }
            }
        }
    }

    private static string ExtractWrappedCanonical(string originalXml, XElement wrappedRoot, string wrapper, bool ignorePrefixes)
    {
        string canonical = CanonicalSerialize(wrappedRoot, ignorePrefixes);
        string startTag = $"<{wrapper}>";
        string endTag = $"</{wrapper}>";
        int start = canonical.IndexOf(startTag, StringComparison.Ordinal);
        int end = canonical.LastIndexOf(endTag, StringComparison.Ordinal);
        if (start >= 0 && end > start)
        {
            string extracted = canonical.Substring(start + startTag.Length, end - start - startTag.Length);
            // Strip trailing whitespace that is only formatting after the last element
            // (e.g. a newline before ]]> in the expected CDATA). Real text content after
            // the final element is preserved because we only trim when the last non-space
            // character is the closing '>' of an element.
            if (!string.IsNullOrWhiteSpace(extracted))
            {
                int lastNonSpace = extracted.Length - 1;
                while (lastNonSpace >= 0 && char.IsWhiteSpace(extracted[lastNonSpace]))
                    lastNonSpace--;
                if (lastNonSpace >= 0 && extracted[lastNonSpace] == '>')
                    extracted = extracted.Substring(0, lastNonSpace + 1);
            }
            return extracted;
        }
        return canonical;
    }

    /// <summary>
    /// Serializes an element in a canonical form for assert-xml comparison
    /// (json-to-xml-014/034): attributes are sorted (namespace declarations first,
    /// then by name), empty elements use the self-closing form, and character
    /// escaping is normalized, so differences that are insignificant per the XML
    /// Infoset (attribute order, empty-tag style, escape spelling) do not affect
    /// the comparison. With ignore-prefixes, names are compared in {uri}local
    /// (Clark) form so the same namespace may be bound to any prefix
    /// (json-to-xml-024).
    /// </summary>
    private static string CanonicalSerialize(XElement root, bool ignorePrefixes)
    {
        var sb = new StringBuilder();
        CanonicalSerializeNode(root, sb, ignorePrefixes);
        return sb.ToString();
    }

    private static void CanonicalSerializeNode(XNode node, StringBuilder sb, bool ignorePrefixes, Dictionary<string, string>? nsScope = null)
    {
        switch (node)
        {
            case XElement el:
                sb.Append('<').Append(CanonicalName(el.Name, ignorePrefixes));
                var attrs = el.Attributes().ToList();
                // Descendants see this element's in-scope bindings on top of the ancestors'.
                var childScope = new Dictionary<string, string>(nsScope ?? new Dictionary<string, string>(StringComparer.Ordinal), StringComparer.Ordinal);
                if (!ignorePrefixes)
                {
                    // Empty namespace undeclarations (xmlns="" / xmlns:p="") are no-ops for
                    // comparison; they are output only when needed for inheritance fixup.
                    foreach (var a in attrs.Where(a => a.IsNamespaceDeclaration && a.Value.Length > 0).OrderBy(a => a.Name.ToString(), StringComparer.Ordinal))
                    {
                        // Namespace fixup: a declaration identical to one already in scope
                        // is redundant and omitted (K2-DirectConElemNamespace-27/42/43).
                        var declPrefix = a.Name.LocalName == "xmlns" ? "" : a.Name.LocalName;
                        if (!childScope.TryGetValue(declPrefix, out var inScope) || inScope != a.Value)
                        {
                            childScope[declPrefix] = a.Value;
                            CanonicalSerializeAttribute(sb, a, false);
                        }
                    }
                }
                foreach (var a in attrs.Where(a => !a.IsNamespaceDeclaration).OrderBy(a => a.Name.ToString(), StringComparer.Ordinal))
                    CanonicalSerializeAttribute(sb, a, ignorePrefixes);
                if (!el.Nodes().Any())
                {
                    sb.Append("/>");
                }
                else
                {
                    sb.Append('>');
                    foreach (var child in el.Nodes())
                        CanonicalSerializeNode(child, sb, ignorePrefixes, childScope);
                    sb.Append("</").Append(CanonicalName(el.Name, ignorePrefixes)).Append('>');
                }
                break;
            case XText t: // XText covers XCData (CDATA serializes as text for comparison)
                EscapeXmlText(sb, t.Value);
                break;
            case XComment c:
                sb.Append("<!--").Append(c.Value).Append("-->");
                break;
            case XProcessingInstruction pi:
                sb.Append("<?").Append(pi.Target).Append(' ').Append(pi.Data).Append("?>");
                break;
        }
    }

    private static string CanonicalName(XName name, bool ignorePrefixes)
    {
        string localName = Xml11NameCodec.DecodeName(name.LocalName);
        if (ignorePrefixes && name.NamespaceName.Length > 0)
            return "{" + name.NamespaceName + "}" + localName;

        string original = name.ToString();
        if (original.Contains(':'))
        {
            int colon = original.IndexOf(':');
            string prefix = original.Substring(0, colon);
            return prefix + ":" + localName;
        }
        return localName;
    }

    private static void CanonicalSerializeAttribute(StringBuilder sb, XAttribute a, bool ignorePrefixes)
    {
        sb.Append(' ').Append(CanonicalName(a.Name, ignorePrefixes)).Append("=\"");
        EscapeXmlAttribute(sb, a.Value);
        sb.Append('"');
    }

    private static void EscapeXmlText(StringBuilder sb, string value)
    {
        foreach (var c in value)
        {
            switch (c)
            {
                case '&': sb.Append("&amp;"); break;
                case '<': sb.Append("&lt;"); break;
                case '>': sb.Append("&gt;"); break;
                case '\r': sb.Append("&#xD;"); break;
                default: sb.Append(c); break;
            }
        }
    }

    private static void EscapeXmlAttribute(StringBuilder sb, string value)
    {
        foreach (var c in value)
        {
            switch (c)
            {
                case '&': sb.Append("&amp;"); break;
                case '<': sb.Append("&lt;"); break;
                case '"': sb.Append("&quot;"); break;
                case '\r': sb.Append("&#xD;"); break;
                case '\n': sb.Append("&#xA;"); break;
                case '\t': sb.Append("&#x9;"); break;
                default: sb.Append(c); break;
            }
        }
    }

    private static void StripNamespaceDeclarations(XElement element)
    {
        var nsAttrs = element.Attributes().Where(a => a.IsNamespaceDeclaration).ToList();
        foreach (var attr in nsAttrs)
            attr.Remove();
        foreach (var child in element.Elements())
            StripNamespaceDeclarations(child);
    }

    private static bool DeepEqual(XdmValue a, XdmValue b)
    {
        if (a.IsUndefined && b.IsUndefined)
            return true;
        // The empty sequence compares equal regardless of representation — Undefined
        // (fn:parse-json null values) vs an empty XdmSequence (fn-parse-json-007).
        if (a.IsUndefined && b.IsSequence)
            return MaterializeValue(b).Count == 0;
        if (b.IsUndefined && a.IsSequence)
            return MaterializeValue(a).Count == 0;
        if (a.IsUndefined || b.IsUndefined)
            return false;

        // Sequences
        if (a.IsSequence && b.IsSequence)
        {
            var itemsA = MaterializeValue(a);
            var itemsB = MaterializeValue(b);
            if (itemsA.Count != itemsB.Count)
                return false;
            for (int i = 0; i < itemsA.Count; i++)
                if (!DeepEqual(itemsA[i], itemsB[i]))
                    return false;
            return true;
        }
        if (a.IsSequence)
        {
            var itemsA = MaterializeValue(a);
            if (itemsA.Count == 1)
                return DeepEqual(itemsA[0], b);
            return false;
        }
        if (b.IsSequence)
        {
            var itemsB = MaterializeValue(b);
            if (itemsB.Count == 1)
                return DeepEqual(a, itemsB[0]);
            return false;
        }

        // Maps
        if (a.Kind == XdmValueKind.Map && b.Kind == XdmValueKind.Map)
        {
            var mapA = a.MapValue;
            var mapB = b.MapValue;
            if (mapA.Count != mapB.Count)
                return false;
            foreach (var key in mapA.Keys)
            {
                if (!mapB.TryGetValue(key, out var vb))
                    return false;
                if (!mapA.TryGetValue(key, out var va))
                    return false;
                if (!DeepEqual(va, vb))
                    return false;
            }
            return true;
        }
        if (a.Kind == XdmValueKind.Map || b.Kind == XdmValueKind.Map)
            return false;

        // Arrays
        if (a.Kind == XdmValueKind.Array && b.Kind == XdmValueKind.Array)
        {
            var arrA = a.ArrayValue;
            var arrB = b.ArrayValue;
            if (arrA.Count != arrB.Count)
                return false;
            for (int i = 0; i < arrA.Count; i++)
                if (!DeepEqual(arrA.Get(i), arrB.Get(i)))
                    return false;
            return true;
        }
        if (a.Kind == XdmValueKind.Array || b.Kind == XdmValueKind.Array)
            return false;

        // Nodes: compare by string value
        if (a.IsNode && b.IsNode)
            return a.NodeValue?.StringValue == b.NodeValue?.StringValue;

        // Atomic values
        if (a.Kind is XdmValueKind.Integer or XdmValueKind.Decimal or XdmValueKind.Double or XdmValueKind.Float &&
            b.Kind is XdmValueKind.Integer or XdmValueKind.Decimal or XdmValueKind.Double or XdmValueKind.Float)
        {
            bool aIsNaN = a.Kind is XdmValueKind.Double or XdmValueKind.Float && double.IsNaN(a.DoubleValue);
            bool bIsNaN = b.Kind is XdmValueKind.Double or XdmValueKind.Float && double.IsNaN(b.DoubleValue);
            if (aIsNaN && bIsNaN) return true;

            if (a.Kind == XdmValueKind.Float || b.Kind == XdmValueKind.Float)
            {
                float fa = a.Kind == XdmValueKind.Integer ? a.IntegerValue : a.Kind == XdmValueKind.Decimal ? (float)a.DecimalValue : (float)a.DoubleValue;
                float fb = b.Kind == XdmValueKind.Integer ? b.IntegerValue : b.Kind == XdmValueKind.Decimal ? (float)b.DecimalValue : (float)b.DoubleValue;
                return fa == fb;
            }
            if (a.Kind == XdmValueKind.Double || b.Kind == XdmValueKind.Double)
            {
                double da = a.Kind == XdmValueKind.Integer ? a.IntegerValue : a.Kind == XdmValueKind.Decimal ? (double)a.DecimalValue : a.DoubleValue;
                double db = b.Kind == XdmValueKind.Integer ? b.IntegerValue : b.Kind == XdmValueKind.Decimal ? (double)b.DecimalValue : b.DoubleValue;
                return da == db;
            }
            decimal ma = a.Kind == XdmValueKind.Integer ? a.IntegerValue : a.DecimalValue;
            decimal mb = b.Kind == XdmValueKind.Integer ? b.IntegerValue : b.DecimalValue;
            return ma == mb;
        }

        if (a.Kind != b.Kind)
            return false;

        return ValuesEqual(a, b);
    }
}
