// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 19 mei 2026
// PURPOSE              : Source file for ParserTests in the Development project
// SPECIAL NOTES        : Unit tests verifying correctness of the underlying implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 19-05-2026     | Creation                                                                                 |
//                      | Charles Korthout | 0.2   | 26-06-2026     | Added URI-qualified wildcard node-test parsing tests                                     |
//                      | Charles Korthout | 0.3   | 15-07-2026     | UnaryLookup parsing, keyword/qualified lookup keys, placeholder-vs-lookup disambiguation |
//                      | Charles Korthout | 0.4   | 19-07-2026     | Reserved function names in function calls and named function references raise XPST0003   |
//                      | Charles Korthout | 0.5   | 19-07-2026     | Removed function-call reserved-name tests; kept named-function-reference tests           |
//                      | Charles Korthout | 0.6   | 20-07-2026     | Added LetExpr and consecutive-let-keyword regression tests                               |
//                      | Charles Korthout | 0.7   | 20-07-2026     | Added TreatExpr and unclosed-sequence-type-paren regression tests                      |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.8   | 22-08-2026     | Added cast-as followed by +/* operator regression tests                                 |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.9   | 23-08-2026     | Added keyword-as-unprefixed-function-name regression tests                             |
//                      | Charles Korthout | 0.10  | 21-09-2026     | API freeze stage A: ParseException renamed to XPathParseException                      |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.11  | 16-10-2026     | REQ-123 PR1131: destructuring let AST shape tests (seq/array/map kinds, whole/variable  |
//                      |                  |       |                | types) + 3.1 XPST0003 gates and empty-pattern rejection                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Parser;
using Bosak.XPath.Parser.Ast;
using Xunit;

namespace Bosak.XPath.Parser.Tests;

public class ParserTests
{
    private static T AssertParse<T>(string xpath) where T : XPathAstNode
    {
        var node = XPathParser.Parse(xpath);
        Assert.IsType<T>(node);
        return (T)node;
    }

    // ------------------------------------------------------------------
    // Literals
    // ------------------------------------------------------------------

    [Fact]
    public void IntegerLiteral()
    {
        var node = AssertParse<IntegerLiteralNode>("42");
        Assert.Equal(42, node.Value);
    }

    [Fact]
    public void DecimalLiteral()
    {
        var node = AssertParse<DecimalLiteralNode>("3.14");
        Assert.Equal(3.14m, node.Value);
    }

    [Fact]
    public void DoubleLiteral()
    {
        var node = AssertParse<DoubleLiteralNode>("1.5e10");
        Assert.Equal(1.5e10, node.Value);
    }

    [Fact]
    public void StringLiteral_DoubleQuotes()
    {
        var node = AssertParse<StringLiteralNode>("\"hello\"");
        Assert.Equal("hello", node.Value);
    }

    [Fact]
    public void StringLiteral_SingleQuotes()
    {
        var node = AssertParse<StringLiteralNode>("'world'");
        Assert.Equal("world", node.Value);
    }

    // ------------------------------------------------------------------
    // Variables & Context
    // ------------------------------------------------------------------

    [Fact]
    public void VariableReference()
    {
        var node = AssertParse<VariableReferenceNode>("$x");
        Assert.Equal("x", node.LocalName);
        Assert.Null(node.Prefix);
    }

    [Fact]
    public void VariableReference_QName()
    {
        var node = AssertParse<VariableReferenceNode>("$ns:var");
        Assert.Equal("var", node.LocalName);
        Assert.Equal("ns", node.Prefix);
    }

    [Theory]
    [InlineData("mod")]
    [InlineData("div")]
    [InlineData("and")]
    [InlineData("or")]
    [InlineData("union")]
    [InlineData("intersect")]
    [InlineData("except")]
    [InlineData("to")]
    [InlineData("instance")]
    [InlineData("treat")]
    [InlineData("castable")]
    [InlineData("cast")]
    [InlineData("if")]
    [InlineData("then")]
    [InlineData("else")]
    [InlineData("for")]
    [InlineData("let")]
    [InlineData("in")]
    [InlineData("return")]
    [InlineData("some")]
    [InlineData("every")]
    [InlineData("satisfies")]
    [InlineData("function")]
    [InlineData("map")]
    [InlineData("array")]
    [InlineData("try")]
    [InlineData("catch")]
    [InlineData("eq")]
    [InlineData("ne")]
    [InlineData("lt")]
    [InlineData("le")]
    [InlineData("gt")]
    [InlineData("ge")]
    [InlineData("is")]
    public void VariableReference_KeywordName(string keyword)
    {
        var node = AssertParse<VariableReferenceNode>($"${keyword}");
        Assert.Equal(keyword, node.LocalName);
        Assert.Null(node.Prefix);
    }

    [Fact]
    public void ContextItem()
    {
        AssertParse<ContextItemNode>(".");
    }

    [Fact]
    public void ParenthesizedExpr()
    {
        var node = AssertParse<ParenthesizedExprNode>("(42)");
        Assert.IsType<IntegerLiteralNode>(node.Expression);
    }

    // ------------------------------------------------------------------
    // Path expressions
    // ------------------------------------------------------------------

    [Fact]
    public void AbsolutePath_RootOnly()
    {
        var node = AssertParse<PathExprNode>("/");
        Assert.True(node.IsAbsolute);
        Assert.Empty(node.Steps);
    }

    [Fact]
    public void AbsolutePath_SingleStep()
    {
        var node = AssertParse<PathExprNode>("/foo");
        Assert.True(node.IsAbsolute);
        Assert.Single(node.Steps);
        var step = Assert.IsType<StepNode>(node.Steps[0]);
        Assert.Equal(XdmAxis.Child, step.Axis);
    }

    [Fact]
    public void RelativePath_TwoSteps()
    {
        var node = AssertParse<PathExprNode>("foo/bar");
        Assert.False(node.IsAbsolute);
        Assert.Equal(2, node.Steps.Count);
    }

    [Fact]
    public void DescendantOrSelf_DoubleSlash()
    {
        var node = AssertParse<PathExprNode>("//foo");
        Assert.True(node.IsAbsolute);
        Assert.Equal(2, node.Steps.Count);
        var first = Assert.IsType<StepNode>(node.Steps[0]);
        Assert.Equal(XdmAxis.DescendantOrSelf, first.Axis);
    }

    [Fact]
    public void AbbreviatedParent()
    {
        var step = AssertParse<StepNode>("..");
        Assert.Equal(XdmAxis.Parent, step.Axis);
    }

    [Fact]
    public void AbbreviatedAttribute()
    {
        var step = AssertParse<StepNode>("@href");
        Assert.Equal(XdmAxis.Attribute, step.Axis);
    }

    [Fact]
    public void ExplicitAxis()
    {
        var step = AssertParse<StepNode>("child::foo");
        Assert.Equal(XdmAxis.Child, step.Axis);
    }

    [Fact]
    public void AxisStep_WithPredicate()
    {
        var step = AssertParse<StepNode>("foo[1]");
        Assert.Single(step.Predicates);
    }

    [Fact]
    public void Predicate_OnParent()
    {
        var step = AssertParse<StepNode>("..[1]");
        Assert.Single(step.Predicates);
    }

    [Fact]
    public void KindTest_Attribute_DefaultAxis()
    {
        // XPath 2.0 §3.2.1.1: attribute() defaults to attribute axis
        var step = AssertParse<StepNode>("attribute()");
        Assert.Equal(XdmAxis.Attribute, step.Axis);
        Assert.Equal(NameTestKind.KindTest, step.NodeTest.Kind);
        Assert.Equal("attribute", step.NodeTest.Name);
    }

    [Fact]
    public void KindTest_NamespaceNode_DefaultAxis()
    {
        // XPath 2.0 §3.2.1.1: namespace-node() defaults to namespace axis
        var step = AssertParse<StepNode>("namespace-node()");
        Assert.Equal(XdmAxis.Namespace, step.Axis);
        Assert.Equal(NameTestKind.KindTest, step.NodeTest.Kind);
        Assert.Equal("namespace-node", step.NodeTest.Name);
    }

    [Fact]
    public void KindTest_Text_DefaultAxisIsChild()
    {
        // text() still defaults to child axis
        var step = AssertParse<StepNode>("text()");
        Assert.Equal(XdmAxis.Child, step.Axis);
        Assert.Equal(NameTestKind.KindTest, step.NodeTest.Kind);
        Assert.Equal("text", step.NodeTest.Name);
    }

    [Fact]
    public void KindTest_Attribute_ExplicitAxis()
    {
        // Explicit child::attribute() keeps child axis
        var step = AssertParse<StepNode>("child::attribute()");
        Assert.Equal(XdmAxis.Child, step.Axis);
    }

    // ------------------------------------------------------------------
    // Function calls
    // ------------------------------------------------------------------

    [Fact]
    public void FunctionCall_NoArgs()
    {
        var node = AssertParse<FunctionCallNode>("true()");
        Assert.Equal("true", node.LocalName);
        Assert.Empty(node.Arguments);
    }

    [Fact]
    public void FunctionCall_WithArgs()
    {
        var node = AssertParse<FunctionCallNode>("concat('a', 'b')");
        Assert.Equal("concat", node.LocalName);
        Assert.Equal(2, node.Arguments.Count);
    }

    [Fact]
    public void FunctionCall_QName()
    {
        var node = AssertParse<FunctionCallNode>("fn:string(1)");
        Assert.Equal("string", node.LocalName);
        Assert.Equal("fn", node.Prefix);
    }

    [Fact]
    public void NamedFunctionRef()
    {
        var node = AssertParse<NamedFunctionRefNode>("abs#1");
        Assert.Equal("abs", node.LocalName);
        Assert.Equal(1, node.Arity);
    }

    [Theory]
    [InlineData("attribute#0")]
    [InlineData("comment#0")]
    [InlineData("document-node#0")]
    [InlineData("element#0")]
    [InlineData("empty-sequence#0")]
    [InlineData("item#0")]
    [InlineData("namespace-node#0")]
    [InlineData("node#0")]
    [InlineData("processing-instruction#0")]
    [InlineData("schema-attribute#0")]
    [InlineData("schema-element#0")]
    [InlineData("switch#0")]
    public void NamedFunctionRef_ReservedName_RaisesXPST0003(string expr)
    {
        var ex = Assert.Throws<XPathParseException>(() => XPathParser.Parse(expr));
        Assert.Contains("XPST0003", ex.Message);
    }

    // ------------------------------------------------------------------
    // Binary operators
    // ------------------------------------------------------------------

    [Fact]
    public void AdditiveExpr()
    {
        var node = AssertParse<BinaryExpressionNode>("1 + 2");
        Assert.Equal(BinaryOperator.Plus, node.Operator);
    }

    [Fact]
    public void MultiplicativeExpr()
    {
        var node = AssertParse<BinaryExpressionNode>("3 * 4");
        Assert.Equal(BinaryOperator.Multiply, node.Operator);
    }

    [Fact]
    public void ComparisonExpr_General()
    {
        var node = AssertParse<BinaryExpressionNode>("1 = 2");
        Assert.Equal(BinaryOperator.Equal, node.Operator);
    }

    [Fact]
    public void ComparisonExpr_Value()
    {
        var node = AssertParse<BinaryExpressionNode>("1 eq 2");
        Assert.Equal(BinaryOperator.Eq, node.Operator);
    }

    [Fact]
    public void AndExpr()
    {
        var node = AssertParse<BinaryExpressionNode>("true() and false()");
        Assert.Equal(BinaryOperator.And, node.Operator);
    }

    [Fact]
    public void OrExpr()
    {
        var node = AssertParse<BinaryExpressionNode>("true() or false()");
        Assert.Equal(BinaryOperator.Or, node.Operator);
    }

    [Fact]
    public void UnionExpr()
    {
        var node = AssertParse<BinaryExpressionNode>("$a | $b");
        Assert.Equal(BinaryOperator.Union, node.Operator);
    }

    [Fact]
    public void IntersectExpr()
    {
        var node = AssertParse<BinaryExpressionNode>("$a intersect $b");
        Assert.Equal(BinaryOperator.Intersect, node.Operator);
    }

    [Fact]
    public void RangeExpr()
    {
        var node = AssertParse<RangeExpressionNode>("1 to 10");
        Assert.IsType<IntegerLiteralNode>(node.From);
        Assert.IsType<IntegerLiteralNode>(node.To);
    }

    [Fact]
    public void StringConcatExpr()
    {
        var node = AssertParse<BinaryExpressionNode>("'a' || 'b'");
        Assert.Equal(BinaryOperator.StringConcat, node.Operator);
    }

    [Fact]
    public void ArrowExpr()
    {
        var node = AssertParse<ArrowExprNode>("$x => upper-case()");
        Assert.IsType<VariableReferenceNode>(node.Source);
        Assert.IsType<FunctionCallNode>(node.Target);
    }

    // ------------------------------------------------------------------
    // Unary operators
    // ------------------------------------------------------------------

    [Fact]
    public void UnaryMinus()
    {
        var node = AssertParse<UnaryExpressionNode>("-5");
        Assert.Equal(UnaryOperator.Minus, node.Operator);
    }

    [Fact]
    public void UnaryPlus()
    {
        var node = AssertParse<UnaryExpressionNode>("+3");
        Assert.Equal(UnaryOperator.Plus, node.Operator);
    }

    // ------------------------------------------------------------------
    // Sequence
    // ------------------------------------------------------------------

    [Fact]
    public void SequenceExpr()
    {
        var node = AssertParse<SequenceExpressionNode>("1, 2, 3");
        Assert.Equal(3, node.Expressions.Count);
    }

    // ------------------------------------------------------------------
    // Conditional
    // ------------------------------------------------------------------

    [Fact]
    public void IfExpr()
    {
        var node = AssertParse<IfExpressionNode>("if ($x) then 1 else 0");
        Assert.IsType<VariableReferenceNode>(node.Condition);
        Assert.IsType<IntegerLiteralNode>(node.ThenBranch);
        Assert.IsType<IntegerLiteralNode>(node.ElseBranch);
    }

    // ------------------------------------------------------------------
    // FLWOR
    // ------------------------------------------------------------------

    [Fact]
    public void ForExpr()
    {
        var node = AssertParse<ForExpressionNode>("for $i in 1 to 10 return $i");
        Assert.Single(node.Bindings);
        Assert.IsType<RangeExpressionNode>(node.Bindings[0].Expression);
    }

    [Fact]
    public void LetExpr()
    {
        var node = AssertParse<LetExpressionNode>("let $x := 1 return $x");
        Assert.Single(node.Bindings);
        Assert.IsType<IntegerLiteralNode>(node.Bindings[0].Expression);
    }

    [Fact]
    public void LetExpr_ConsecutiveLetKeywords_RaiseXPST0003()
    {
        // Regression for QT3 LetExpr020a: XPath does not allow multiple let clauses.
        var expr = "let $a := 1 let $b := $a let $c := $a+$b return ($c)";
        var ex = Assert.Throws<XPathParseException>(() => XPathParser.Parse(expr));
        Assert.Contains("XPST0003", ex.Message);
    }

    [Fact]
    public void QuantifiedExpr_Some()
    {
        var node = AssertParse<QuantifiedExpressionNode>("some $x in (1,2,3) satisfies $x gt 0");
        Assert.Equal(QuantifierKind.Some, node.Quantifier);
    }

    [Fact]
    public void QuantifiedExpr_Every()
    {
        var node = AssertParse<QuantifiedExpressionNode>("every $x in (1,2,3) satisfies $x gt 0");
        Assert.Equal(QuantifierKind.Every, node.Quantifier);
    }

    // ------------------------------------------------------------------
    // Type expressions
    // ------------------------------------------------------------------

    [Fact]
    public void CastExpr()
    {
        var node = AssertParse<CastNode>("$x cast as xs:string");
        Assert.IsType<VariableReferenceNode>(node.Expression);
        Assert.Equal("string", node.TypeName);
        Assert.Equal("xs", node.Prefix);
    }

    [Fact]
    public void CastExpr_FollowedByAdditiveOperator_ParsesAsBinaryExpression()
    {
        // Regression for QT3 op-numeric-add-13: the '+' after the cast target type is the
        // additive operator, not an occurrence indicator.
        var node = AssertParse<BinaryExpressionNode>("15 cast as xs:integer + 15");
        Assert.IsType<CastNode>(node.Left);
        Assert.Equal(BinaryOperator.Plus, node.Operator);
    }

    [Fact]
    public void CastExpr_FollowedByStarOperator_ParsesAsBinaryExpression()
    {
        // The '*' after the cast target type can be the multiplication operator when an operand follows.
        var node = AssertParse<BinaryExpressionNode>("3 cast as xs:integer * 4");
        Assert.IsType<CastNode>(node.Left);
        Assert.Equal(BinaryOperator.Multiply, node.Operator);
    }

    [Fact]
    public void CastExpr_StarOccurrenceIndicatorWithoutOperand_RaisesXPST0003()
    {
        // Standalone '*' after a SingleType is still a syntax error (K-SeqExprCast-1).
        var ex = Assert.Throws<XPathParseException>(() => XPathParser.Parse("'string' cast as xs:string*"));
        Assert.Contains("XPST0003", ex.Message);
    }

    [Fact]
    public void CastExpr_PlusOccurrenceIndicatorWithoutOperand_RaisesXPST0003()
    {
        // Standalone '+' after a SingleType is still a syntax error (K-SeqExprCast-2).
        var ex = Assert.Throws<XPathParseException>(() => XPathParser.Parse("'string' cast as xs:string+"));
        Assert.Contains("XPST0003", ex.Message);
    }

    [Fact]
    public void InstanceOfExpr()
    {
        var node = AssertParse<InstanceOfNode>("$x instance of xs:integer");
        Assert.IsType<VariableReferenceNode>(node.Expression);
    }

    [Fact]
    public void TreatExpr()
    {
        var node = AssertParse<TreatNode>("$x treat as xs:integer");
        Assert.IsType<VariableReferenceNode>(node.Expression);
        Assert.Equal("integer", node.TypeName);
    }

    [Fact]
    public void TreatExpr_UnclosedTypeParens_RaiseXPST0003()
    {
        // Regression for QT3 K-SeqExprTreat-16: missing closing paren in sequence type.
        var expr = "3 treat as item(";
        var ex = Assert.Throws<XPathParseException>(() => XPathParser.Parse(expr));
        Assert.Contains("XPST0003", ex.Message);
    }

    // ------------------------------------------------------------------
    // XPath 3.1 constructors
    // ------------------------------------------------------------------

    [Fact]
    public void MapConstructor()
    {
        var node = AssertParse<MapConstructorNode>("map { 'a': 1, 'b': 2 }");
        Assert.Equal(2, node.Entries.Count);
    }

    [Fact]
    public void SquareArrayConstructor()
    {
        var node = AssertParse<ArrayConstructorNode>("[1, 2, 3]");
        Assert.Equal(3, node.Items.Count);
        Assert.True(node.IsSquare);
    }

    [Fact]
    public void CurlyArrayConstructor()
    {
        var node = AssertParse<ArrayConstructorNode>("array { $seq }");
        Assert.Single(node.Items);
        Assert.False(node.IsSquare);
    }

    // ------------------------------------------------------------------
    // Complex expressions
    // ------------------------------------------------------------------

    [Fact]
    public void ComplexPath_WithPredicates()
    {
        var node = AssertParse<PathExprNode>("//book[price gt 10]/title");
        Assert.True(node.IsAbsolute);
        Assert.Equal(3, node.Steps.Count);
    }

    [Fact]
    public void ComplexArithmetic_WithPath()
    {
        var node = AssertParse<BinaryExpressionNode>("count(//item) + 1");
        Assert.Equal(BinaryOperator.Plus, node.Operator);
    }

    [Fact]
    public void ComplexConditional_InPath()
    {
        var node = AssertParse<PostfixPredicateNode>("$x[if (@y) then @y else 'default']");
        Assert.IsType<VariableReferenceNode>(node.Expression);
    }

    [Fact]
    public void UriQualifiedNameWildcard_EmptyUri()
    {
        var step = AssertParse<StepNode>("@Q{}*");
        Assert.Equal(XdmAxis.Attribute, step.Axis);
        Assert.Equal(NameTestKind.NamespaceAny, step.NodeTest.Kind);
        Assert.Equal("", step.NodeTest.NamespaceUri);
    }

    [Fact]
    public void UriQualifiedNameWildcard_NonEmptyUri()
    {
        var step = AssertParse<StepNode>("Q{http://example.com}*");
        Assert.Equal(XdmAxis.Child, step.Axis);
        Assert.Equal(NameTestKind.NamespaceAny, step.NodeTest.Kind);
        Assert.Equal("http://example.com", step.NodeTest.NamespaceUri);
    }

    [Fact]
    public void UnaryLookup_OnContextItem()
    {
        var node = AssertParse<LookupNode>("?name");
        Assert.IsType<ContextItemNode>(node.Expression);
        Assert.IsType<StringLiteralNode>(node.Key);
    }

    [Fact]
    public void UnaryLookup_Wildcard()
    {
        var node = AssertParse<LookupWildcardNode>("?*");
        Assert.IsType<ContextItemNode>(node.Expression);
    }

    [Fact]
    public void UnaryLookup_EmptyParenKey()
    {
        var node = AssertParse<LookupNode>("?()");
        Assert.IsType<ContextItemNode>(node.Expression);
        Assert.IsType<SequenceExpressionNode>(node.Key);
    }

    [Fact]
    public void PostfixLookup_KeywordKey()
    {
        // Keyword NCNames are valid lookup keys (Lookup-155: map{'or':true()}?or).
        var node = AssertParse<LookupNode>("map{'or':true()}?or");
        var key = Assert.IsType<StringLiteralNode>(node.Key);
        Assert.Equal("or", key.Value);
    }

    [Fact]
    public void PostfixLookup_QualifiedNameKey_IsStaticError()
    {
        Assert.Throws<XPathParseException>(() => XPathParser.Parse("map{'a':1}?xs:integer"));
        Assert.Throws<XPathParseException>(() => XPathParser.Parse("map{'a':1}?Q{}integer"));
    }

    [Fact]
    public void ArgumentList_PlaceholderVsUnaryLookup()
    {
        // Bare '?' is a placeholder; '?1' and '?()' are unary lookups.
        var call = AssertParse<FunctionCallNode>("fn:contains(?, 'a')");
        Assert.IsType<ArgumentPlaceholderNode>(call.Arguments[0]);
        var call2 = AssertParse<FunctionCallNode>("fn:exists(?())");
        Assert.IsType<LookupNode>(call2.Arguments[0]);
    }

    [Theory]
    [InlineData("and")]
    [InlineData("or")]
    [InlineData("div")]
    [InlineData("mod")]
    [InlineData("idiv")]
    [InlineData("union")]
    [InlineData("intersect")]
    [InlineData("except")]
    [InlineData("to")]
    [InlineData("eq")]
    [InlineData("ne")]
    [InlineData("lt")]
    [InlineData("le")]
    [InlineData("gt")]
    [InlineData("ge")]
    [InlineData("is")]
    [InlineData("instance")]
    [InlineData("of")]
    [InlineData("treat")]
    [InlineData("cast")]
    [InlineData("castable")]
    [InlineData("as")]
    [InlineData("then")]
    [InlineData("else")]
    [InlineData("for")]
    [InlineData("let")]
    [InlineData("some")]
    [InlineData("every")]
    [InlineData("in")]
    [InlineData("return")]
    [InlineData("satisfies")]
    [InlineData("try")]
    [InlineData("catch")]
    [InlineData("validate")]
    public void Keyword_FunctionCall_Allowed(string keyword)
    {
        // xquery30keywords5: most XPath/XQuery keywords can be used as unprefixed
        // function names when followed by '(' in a primary-expression context.
        var node = XPathParser.Parse($"{keyword}()", allowFullFlwor: true);
        var call = Assert.IsType<FunctionCallNode>(node);
        Assert.Equal(keyword, call.LocalName);
    }

    [Theory]
    [InlineData("and")]
    [InlineData("or")]
    [InlineData("div")]
    [InlineData("for")]
    [InlineData("try")]
    [InlineData("validate")]
    public void Keyword_NamedFunctionRef_Allowed(string keyword)
    {
        // Keywords can also be used as named function references when followed by '#'.
        var node = XPathParser.Parse($"{keyword}#0", allowFullFlwor: true);
        var nf = Assert.IsType<NamedFunctionRefNode>(node);
        Assert.Equal(keyword, nf.LocalName);
        Assert.Equal(0, nf.Arity);
    }

    [Fact]
    public void ValidateExpression_StillParsed_WithBrace()
    {
        // validate{...} must remain a validate expression, not a function call.
        var node = XPathParser.Parse("validate{<a/>}", allowFullFlwor: true);
        Assert.IsType<ValidateExpressionNode>(node);
    }

    [Fact]
    public void QuantifiedExpression_StillParsed_WithVariableBinding()
    {
        // some $x in ... satisfies ... must remain a quantified expression, not a function call.
        var node = XPathParser.Parse("some $x in (1,2) satisfies $x gt 0", allowFullFlwor: true);
        Assert.IsType<QuantifiedExpressionNode>(node);
    }

    [Fact]
    public void TryCatchExpression_StillParsed_WithBrace()
    {
        // try{...} catch * {...} must remain a try/catch expression, not a function call.
        var node = XPathParser.Parse("try{1 div 0}catch *{0}", allowFullFlwor: true);
        Assert.IsType<TryCatchNode>(node);
    }

    [Fact]
    public void FlworExpression_StillParsed_WithVariableBinding()
    {
        // for $x in ... return ... must remain a FLWOR expression, not a function call.
        // A simple for clause is represented directly as a ForExpressionNode.
        var node = XPathParser.Parse("for $x in 1 to 3 return $x", allowFullFlwor: true);
        Assert.IsType<ForExpressionNode>(node);
    }

    // ------------------------------------------------------------------
    // REQ-123 PR1131: XPath 4.0 destructuring let bindings
    // ------------------------------------------------------------------

    [Fact]
    public void LetDestructuringSequence_ParsesVariablesAndWholeType()
    {
        var node = XPathParser.Parse("let $($x, $y as xs:integer, $z) as xs:double* := (1, 2, 3) return $x", xpath40: true);
        var let = Assert.IsType<LetExpressionNode>(node);
        var binding = Assert.Single(let.Bindings);
        Assert.Equal(LetDestructuringKind.Sequence, binding.Destructuring);
        Assert.Equal(3, binding.DestructuringVariables?.Count);
        Assert.Equal("x", binding.VariableName);
        Assert.Collection(binding.DestructuringVariables!,
            v => { Assert.Equal("x", v.VariableName); Assert.Null(v.DeclaredType); },
            v =>
            {
                Assert.Equal("y", v.VariableName);
                Assert.NotNull(v.DeclaredType);
                Assert.Equal("integer", v.DeclaredType!.TypeName);
                Assert.Equal("xs", v.DeclaredType.Prefix);
                Assert.Equal(OccurrenceIndicator.One, v.DeclaredType.Occurrence);
            },
            v => { Assert.Equal("z", v.VariableName); Assert.Null(v.DeclaredType); });
        Assert.NotNull(binding.DeclaredType);
        Assert.Equal("double", binding.DeclaredType!.TypeName);
        Assert.Equal(OccurrenceIndicator.ZeroOrMore, binding.DeclaredType.Occurrence);
    }

    [Fact]
    public void LetDestructuringArray_ParsesBracketKind()
    {
        var node = XPathParser.Parse("let $[$first, $second] := [1, 2] return $first", xpath40: true);
        var let = Assert.IsType<LetExpressionNode>(node);
        var binding = Assert.Single(let.Bindings);
        Assert.Equal(LetDestructuringKind.Array, binding.Destructuring);
        Assert.Null(binding.DeclaredType);
        Assert.Collection(binding.DestructuringVariables!,
            v => Assert.Equal("first", v.VariableName),
            v => Assert.Equal("second", v.VariableName));
    }

    [Fact]
    public void LetDestructuringMap_ParsesBraceKindAndWholeType()
    {
        var node = XPathParser.Parse("let ${$a, $ns:b as xs:string} as map(*) := map { 'a': 1 } return $a", xpath40: true);
        var let = Assert.IsType<LetExpressionNode>(node);
        var binding = Assert.Single(let.Bindings);
        Assert.Equal(LetDestructuringKind.Map, binding.Destructuring);
        Assert.Equal("map(*)", binding.DeclaredType!.TypeName);
        Assert.Equal(OccurrenceIndicator.One, binding.DeclaredType.Occurrence);
        Assert.Collection(binding.DestructuringVariables!,
            v => { Assert.Equal("a", v.VariableName); Assert.Null(v.VariablePrefix); },
            v =>
            {
                Assert.Equal("b", v.VariableName);
                Assert.Equal("ns", v.VariablePrefix);
                Assert.NotNull(v.DeclaredType);
                Assert.Equal("string", v.DeclaredType!.TypeName);
            });    }

    [Theory]
    [InlineData("let $(x) := (1) return $x")]
    [InlineData("let $[x] := [1] return $x")]
    [InlineData("let ${x} := map {'x': 1} return $x")]
    [InlineData("let $v as xs:double := 42 return $v")]
    public void LetDestructuring_XPath31_ThrowsXpst0003(string expression)
    {
        var ex = Assert.Throws<XPathParseException>(() => XPathParser.Parse(expression));
        Assert.Contains("XPST0003", ex.Message);
    }

    [Theory]
    [InlineData("let $() := (1) return 1")]
    [InlineData("let $[] := [1] return 1")]
    [InlineData("let ${} := map { 'x': 1 } return 1")]
    public void LetDestructuring_EmptyPattern_ThrowsXpst0003(string expression)
    {
        var ex = Assert.Throws<XPathParseException>(() => XPathParser.Parse(expression, xpath40: true));
        Assert.Contains("XPST0003", ex.Message);
    }
}
