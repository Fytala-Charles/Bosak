// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 10 October 2026
// PURPOSE              : Read-only capability descriptor advertising what the authoring surface supports.
// SPECIAL NOTES        : Part of the Bosak XSLT 3.0 processor — source-preserving authoring API for visual designers.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 10-10-2026     | Creation                                                                                 |
//                      | Charles Korthout | 0.2   | 10-10-2026     | REQ-124 acceptance F2: collections wrapped in Array.AsReadOnly over private storage      |
//                      | Charles Korthout | 0.4   | 17-10-2026     | REQ-129: advertise separately bounded readable insertion support.
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.3   | 15-10-2026     | REQ-128: bounded insertion and immutable candidate descriptors.                           |
// ===========================================================================================================================================================
//                      | Charles Korthout | 0.5   | 17-10-2026     | REQ-130: independently advertise bounded value-of deletion.                              |
//                      | Charles Korthout | 0.6   | 17-10-2026     | REQ-131: independently advertise bounded literal-text insertion.                       |
//                      | Charles Korthout | 0.7   | 18-10-2026     | REQ-132: additive literal element insertion with exact candidate provenance.             |
// ===========================================================================================================================================================
//                      | Charles Korthout | 0.8   | 18-10-2026     | REQ-133: independently advertise literal text body replacement.                         |

//                      | Charles Korthout | 0.9   | 19-10-2026     | REQ-134: separately bounded literal text deletion.                                      |

//                      | Charles Korthout | 1.0   | 20-10-2026     | REQ-135: advertise complete literal attribute lifecycle.                                 |

//                      | Charles Korthout | 1.3   | 25-10-2026     | REQ-138: advertise coordinated operations and independent resource bounds. |

using System.Reflection;

//                      | Charles Korthout | 1.1   | 23-10-2026     | REQ-136: independent lifecycle capabilities and bounds. |

//                      | Charles Korthout | 1.2   | 24-10-2026     | REQ-137: independent reorder capability, profile and bounds. |

namespace Bosak.Xslt.Authoring;

/// <summary>
/// The fidelity modes one authoring surface can offer. Bosak authoring is lossless-only: untouched
/// regions are always produced from the retained original bytes, never re-serialized.
/// </summary>
public enum AuthoringFidelityMode
{
    /// <summary>Untouched regions export byte-for-byte from the retained envelope; only declared affected spans are spliced.</summary>
    LosslessByteExport,
}

/// <summary>
/// A read-only, exception-free description of what the Bosak authoring surface supports, so a consumer
/// (for example a visual designer) can adapt its UI without probing APIs by trial and error. All
/// members are static and side-effect free; the descriptor holds no mutable state and reflects the
/// engine build it ships in. Values here are contractual: the capabilities advertised are exactly the
/// behaviors implemented by <see cref="AuthoringSource"/>, <see cref="XsltAuthoring"/>,
/// <see cref="AuthoringInspector"/> and <see cref="AuthoringSnapshot"/>.
/// </summary>
public static class AuthoringCapabilities
{
    /// <summary>Gets whether the bounded conditional Wrap operation is implemented.</summary>
    public static bool SupportsConditionalWrapping => true;
    /// <summary>Gets whether independent conditional Unwrap is implemented.</summary>
    public static bool SupportsConditionalUnwrapping => true;
    /// <summary>Gets whether the cancellable restricted expression overload is implemented.</summary>
    public static bool SupportsBoundedExpressionSlotReplacement => true;
    /// <summary>Gets the dependency-free Legacy-host conditional lifecycle profile.</summary>
    public static string ConditionalWrapperProfile => "ConditionalLiteralLifecycleV1";
    /// <summary>Gets the separately advertised restricted expression profile.</summary>
    public static string BoundedExpressionSlotReplacementProfile => "BoundedPrincipalExpressionV1";
    /// <summary>Gets the independent original and candidate physical byte bound.</summary>
    public static int MaxConditionalSourceBytes => 8388608;
    /// <summary>Gets the condition UTF-16 unit bound.</summary>
    public static int MaxConditionalConditionUnits => 65536;
    /// <summary>Gets the encoded escaped condition byte bound.</summary>
    public static int MaxConditionalEscapedConditionBytes => 1048576;
    /// <summary>Gets the selected prefix UTF-16 unit bound.</summary>
    public static int MaxConditionalPrefixUnits => 256;
    /// <summary>Gets the combined encoded opening and closing markup bound.</summary>
    public static int MaxConditionalMarkupBytes => 1052672;
    /// <summary>Gets each graph descriptor bound.</summary>
    public static int MaxConditionalNodes => 65536;
    /// <summary>Gets each graph attribute bound.</summary>
    public static int MaxConditionalAttributes => 65536;
    /// <summary>Gets the maximum descriptor depth.</summary>
    public static int MaxConditionalDepth => 256;
    /// <summary>Gets the cumulative complete copied evidence budget.</summary>
    public static int MaxConditionalEvidenceBytes => 33554432;
    /// <summary>Gets strict encodings shared by conditional and bounded expression profiles; UTF-16 requires BOM.</summary>
    public static IReadOnlyList<string> ConditionalWrapperSupportedEncodings { get; } = Array.AsReadOnly(new[] { "UTF-8", "UTF-16LE", "UTF-16BE" });

    /// <summary>Gets whether bounded direction-bound adjacent literal element exchanges are supported.</summary>
    public static bool SupportsLiteralElementReordering => true;
    /// <summary>Gets the independent original and candidate physical byte bound for reordering.</summary>
    public static int MaxLiteralElementReorderSourceBytes => 8_388_608;
    /// <summary>Gets the combined subtree and separator physical byte bound for reordering.</summary>
    public static int MaxLiteralElementReorderExchangeBytes => 8_388_608;
    /// <summary>Gets the cumulative complete copied review evidence byte bound for reordering.</summary>
    public static int MaxLiteralElementReorderEvidenceBytes => 16_777_216;
    /// <summary>Gets the independent original and candidate descriptor count bound for reordering.</summary>
    public static int MaxLiteralElementReorderNodes => 65_536;
    /// <summary>Gets the independent original and candidate attribute count bound for reordering.</summary>
    public static int MaxLiteralElementReorderAttributes => 65_536;
    /// <summary>Gets the maximum descriptor traversal depth for reordering.</summary>
    public static int MaxLiteralElementReorderDepth => 256;
    /// <summary>Gets immutable reorder encodings; UTF-16 requires a matching BOM/declaration.</summary>
    public static IReadOnlyList<string> LiteralElementReorderSupportedEncodings { get; } = Array.AsReadOnly(new[] { "UTF-8", "UTF-16LE", "UTF-16BE" });
    /// <summary>Gets the initial reorder coverage: dependency-free explicit 3.0/4.0 Legacy authoring host, no-namespace literal parent and adjacent children, creation-compatible literal ancestry, REQ-136 closed vocabulary, absent or ordinary lexical whitespace separator; no CDATA or preserved-space.</summary>
    public static string LiteralElementReorderProfile => "LiteralSiblingExchangeV1";

    /// <summary>Gets the independent REQ-136 SupportsLiteralElementRename capability or bound.</summary>
    public static bool SupportsLiteralElementRename => true;
    /// <summary>Gets the independent REQ-136 SupportsLiteralElementDeletion capability or bound.</summary>
    public static bool SupportsLiteralElementDeletion => true;
    /// <summary>Gets the independent REQ-136 MaxLiteralElementLifecycleSourceBytes capability or bound.</summary>
    public static int MaxLiteralElementLifecycleSourceBytes => 8_388_608;
    /// <summary>Gets the independent REQ-136 MaxLiteralElementLocalNameUnits capability or bound.</summary>
    public static int MaxLiteralElementLocalNameUnits => 1_024;
    /// <summary>Gets the independent REQ-136 MaxLiteralElementLocalNameBytes capability or bound.</summary>
    public static int MaxLiteralElementLocalNameBytes => 1_024;
    /// <summary>Gets the independent REQ-136 MaxLiteralElementLifecycleNodes capability or bound.</summary>
    public static int MaxLiteralElementLifecycleNodes => 65_536;
    /// <summary>Gets the independent REQ-136 MaxLiteralElementLifecycleAttributes capability or bound.</summary>
    public static int MaxLiteralElementLifecycleAttributes => 65_536;
    /// <summary>Gets the independent REQ-136 MaxLiteralElementLifecycleDepth capability or bound.</summary>
    public static int MaxLiteralElementLifecycleDepth => 256;
    /// <summary>Gets the independent REQ-136 MaxLiteralElementLifecycleEvidenceBytes capability or bound.</summary>
    public static int MaxLiteralElementLifecycleEvidenceBytes => 16_777_216;

    /// <summary>Gets whether the complete literal attribute lifecycle is available.</summary>
    public static bool SupportsLiteralAttributeLifecycle => true;
    /// <summary>Gets the independent original and final physical source byte limit.</summary>
    public static int MaxLiteralAttributeSourceBytes => 8_388_608;
    /// <summary>Gets immutable supported encodings; UTF-16 requires a matching BOM.</summary>
    public static IReadOnlyList<string> LiteralAttributeSupportedEncodings { get; } = Array.AsReadOnly(new[] { "UTF-8", "UTF-16LE", "UTF-16BE" });

    /// <summary>Gets whether bounded literal text instruction deletion is implemented.</summary>
    public static bool SupportsTextDeletion => true;
    /// <summary>Gets the original and final physical byte bound, including BOM.</summary>
    public static int MaxTextDeletionSourceBytes => 8_388_608;
    /// <summary>Gets immutable deletion encodings; UTF-16 requires a matching BOM/declaration.</summary>
    public static IReadOnlyList<string> TextDeletionSupportedEncodings { get; } =
        Array.AsReadOnly(new[] { "UTF-8", "UTF-16LE", "UTF-16BE" });

    /// <summary>Gets whether bounded literal text body replacement is implemented.</summary>
    public static bool SupportsTextBodyReplacement => true;
    /// <summary>Gets the original and final physical byte bound, including BOM.</summary>
    public static int MaxTextBodyReplacementSourceBytes => 8_388_608;
    /// <summary>Gets immutable replacement encodings; UTF-16 requires a matching BOM/declaration.</summary>
    public static IReadOnlyList<string> TextBodyReplacementSupportedEncodings { get; } =
        Array.AsReadOnly(new[] { "UTF-8", "UTF-16LE", "UTF-16BE" });

    /// <summary>Gets whether bounded no-namespace literal element insertion is available.</summary>
    public static bool SupportsLiteralElementInsertion => true;
    /// <summary>Gets whether explicit readable literal element layout is available.</summary>
    public static bool SupportsReadableLiteralElementInsertion => true;
    /// <summary>Gets the original and complete candidate physical byte limit, including BOM.</summary>
    public static int MaxLiteralElementInsertionSourceBytes => 8_388_608;
    /// <summary>Gets immutable literal element encodings; UTF-16 requires a matching BOM/declaration.</summary>
    public static IReadOnlyList<string> LiteralElementInsertionSupportedEncodings { get; } =
        Array.AsReadOnly(new[] { "UTF-8", "UTF-16LE", "UTF-16BE" });


    /// <summary>Gets whether bounded literal xsl:text insertion is supported.</summary>
    public static bool SupportsTextInsertion => true;

    /// <summary>Gets whether explicit readable literal-text insertion is supported.</summary>
    public static bool SupportsReadableTextInsertion => true;

    /// <summary>Gets the maximum original and candidate text-insertion source bytes, including BOM.</summary>
    public static int MaxTextInsertionSourceBytes => 8_388_608;

    /// <summary>Gets whether bounded instruction-only value-of deletion is available.</summary>
    public static bool SupportsValueOfDeletion => true;

    /// <summary>Gets the maximum original and candidate deletion source bytes, including BOM.</summary>
    public static int MaxValueOfDeletionSourceBytes => 8_388_608;

    /// <summary>Gets whether bounded source-preserving value-of insertion is implemented.</summary>
    public static bool SupportsValueOfInsertion => true;

    /// <summary>Gets whether explicit readable insertion layout and complete edit evidence are available.</summary>
    public static bool SupportsReadableValueOfInsertion => true;

    /// <summary>Gets the separate insertion limit for both original and candidate bytes, including BOM.</summary>
    public static int MaxValueOfInsertionSourceBytes => 8_388_608;

    /// <summary>Gets the insertion encodings; UTF-16 requires a matching BOM.</summary>
    public static IReadOnlyList<string> ValueOfInsertionSupportedEncodings { get; } =
        Array.AsReadOnly(new[] { "UTF-8", "UTF-16LE", "UTF-16BE" });

    /// <summary>Gets whether source-preserving inspection of a stylesheet and its modules is available.</summary>
    public static bool SupportsInspection => true;

    /// <summary>
    /// Gets whether expression-slot replacement is supported: <see cref="AuthoringSnapshot.ProposeExpressionEdit(AuthoringEditProposal)"/>
    /// accepts proposals targeting attributes classified as <see cref="AuthoringAttributeSlotKind.Expression"/>.
    /// </summary>
    public static bool SupportsExpressionSlotReplacement => true;

    /// <summary>
    /// Gets whether pattern-slot replacement is supported. <see cref="AuthoringAttributeSlotKind.Pattern"/>
    /// slots (for example <c>xsl:template/@match</c>) are inspectable but not editable in this version;
    /// proposing an edit on one yields <see cref="AuthoringEditFailureKind.SlotNotEditable"/>.
    /// </summary>
    public static bool SupportsPatternSlotReplacement => false;

    /// <summary>
    /// Gets whether attribute-value-template slot replacement is supported. <see cref="AuthoringAttributeSlotKind.Avt"/>
    /// slots are inspectable but not editable in this version.
    /// </summary>
    public static bool SupportsAvtSlotReplacement => false;

    /// <summary>
    /// Gets whether qualified-name slot replacement is supported. <see cref="AuthoringAttributeSlotKind.QName"/>
    /// slots (for example <c>xsl:call-template/@name</c>) are inspectable but not editable in this version.
    /// </summary>
    public static bool SupportsQNameSlotReplacement => false;

    private static readonly AuthoringFidelityMode[] FidelityModesBacking =
        { AuthoringFidelityMode.LosslessByteExport };

    /// <summary>
    /// Gets the offered fidelity modes. Bosak authoring offers <see cref="AuthoringFidelityMode.LosslessByteExport"/>
    /// only: there is no re-serializing export path.
    /// </summary>
    /// <remarks>
    /// The collection is immutable: it is a read-only wrapper over privately retained storage, so
    /// consumers cannot obtain or mutate the backing array, and concurrent reads are safe.
    /// </remarks>
    public static IReadOnlyList<AuthoringFidelityMode> FidelityModes { get; } =
        Array.AsReadOnly(FidelityModesBacking);

    private static readonly string[] SupportedEncodingsBacking =
        {
            "UTF-8",
            "UTF-16LE",
            "UTF-16BE",
            "UTF-32LE",
            "UTF-32BE",
            "ISO-8859-1",
            "US-ASCII",
        };

    /// <summary>
    /// Gets the canonical names of the encodings authoring accepts, matching
    /// <see cref="AuthoringSource.TryCreate"/> detection exactly: a byte-order mark (UTF-8, UTF-16 LE/BE,
    /// UTF-32 LE/BE), else the <c>encoding</c> pseudo-attribute of an XML declaration (any of the names
    /// listed here), else UTF-8. Any other declared encoding name is refused with
    /// <see cref="AuthoringFailureKind.UnsupportedEncoding"/>; invalid byte sequences are refused with
    /// <see cref="AuthoringFailureKind.InvalidSourceBytes"/>. Detection notes: UTF-16 and UTF-32 are
    /// recognized via BOM; without a BOM their declarations are not byte-detectable and the bytes are
    /// treated as UTF-8 (which fails strict validation). US-ASCII input is validated strictly.
    /// </summary>
    /// <remarks>
    /// The collection is immutable: it is a read-only wrapper over privately retained storage, so
    /// consumers cannot obtain or mutate the backing array, and concurrent reads are safe.
    /// </remarks>
    public static IReadOnlyList<string> SupportedEncodings { get; } =
        Array.AsReadOnly(SupportedEncodingsBacking);

    /// <summary>
    /// Gets the maximum number of modules (including the principal) one snapshot inspects. References
    /// beyond the bound are recorded as unresolved edges with a diagnostic. Matches
    /// <see cref="AuthoringInspectionOptions.MaxModuleCount"/>.
    /// </summary>
    public static int MaxModuleCount => 256;

    private static readonly string[] DocumentedLimitsBacking =
        {
            "Internal DTD subsets are refused: module parsing is strict XML 1.0 without DTD processing.",
            "XML 1.1 declarations are refused by inspection parsing; derived compilation resolves included modules through the Xml11Loader XML 1.1 compatibility path.",
            "UTF-16 and UTF-32 modules are recognized via byte-order mark only; without a BOM the encoding declaration is not detectable and the bytes decode (and fail) as UTF-8.",
            "Node identities are snapshot-scoped: a descriptor id is reliable only within the snapshot that issued it and must not be reused against a candidate or a later inspection.",
            "Edit candidates are valid only against the snapshot they were derived from; a late proposal still resolves against the snapshot it is submitted to.",
            "Attribute editability is limited to Expression slots; Pattern, AVT and QName slots are inspectable but refuse edits.",
            "Snapshots and candidates are pure managed state: they hold no unmanaged resources, need no disposal, never mutate, and are safe to share across threads.",
        };

    /// <summary>
    /// Gets the human-readable documented limits a consumer should surface in diagnostics or settings UI.
    /// </summary>
    /// <remarks>
    /// The collection is immutable: it is a read-only wrapper over privately retained storage, so
    /// consumers cannot obtain or mutate the backing array, and concurrent reads are safe.
    /// </remarks>
    public static IReadOnlyList<string> DocumentedLimits { get; } =
        Array.AsReadOnly(DocumentedLimitsBacking);

    /// <summary>
    /// Gets the version policy: XSLT 3.0 / XPath 3.1 is the delivered surface; XPath 4.0 grammar surfaces
    /// are gated by the engine version policy and are opted into per expression slot from the module's
    /// effective version (see <c>CompileOptions.Compatibility</c>).
    /// </summary>
    public static string VersionPolicy =>
        "XSLT 3.0 / XPath 3.1 first; XPath 4.0 surfaces are gated by the engine version policy " +
        "(CompileOptions.Compatibility, driven by the module effective version).";

    /// <summary>
    /// Gets the simple name of the engine assembly the authoring surface ships in, for binding logs
    /// (for example <c>Bosak.Xslt</c>).
    /// </summary>
    public static string EngineAssemblyName => typeof(AuthoringCapabilities).Assembly.GetName().Name ?? "Bosak.Xslt";

    /// <summary>
    /// Gets the engine assembly version a consumer is bound to: the informational (file) version when
    /// available, otherwise the assembly name version. Deterministic per build; intended for binding logs.
    /// </summary>
    public static string EngineVersion
    {
        get
        {
            var assembly = typeof(AuthoringCapabilities).Assembly;
            var informational = assembly
                .GetCustomAttribute<AssemblyInformationalVersionAttribute>()
                ?.InformationalVersion;
            return string.IsNullOrEmpty(informational)
                ? assembly.GetName().Version?.ToString() ?? "unknown"
                : informational;
        }
    }
}
