// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 25 mei 2026
// PURPOSE              : Compiles XSLT match patterns into executable node predicates.
// SPECIAL NOTES        : Part of the Bosak XPath 3.1 implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      | Charles Korthout | 0.1   | 25-05-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 27-05-2026     | Added // prefix support in match patterns                                                |
//                      | Charles Korthout | 0.3   | 28-05-2026     | Added smart split, axis steps, node tests, set ops, variable patterns                    |
//                      | Charles Korthout | 0.4   | 31-05-2026     | Fixed bare predicate patterns ([foo]) compiling as self::node()[foo]                     |
//                      | Charles Korthout | 0.5   | 01-06-2026     | Axis-context predicate evaluation in path patterns; descendant:: direct-child fix      |
//                      | Charles Korthout | 0.6   | 01-06-2026     | Wrap compiled patterns with CurrentItem so fn:current() returns candidate node         |
//                      | Charles Korthout | 0.7   | 01-06-2026     | Propagate static XPath/XSLT errors (XPST/XTSE/XPTY) from pattern predicates            |
//                      | Charles Korthout | 0.8   | 01-06-2026     | Fix namespace wildcard patterns (prefix:* and Q{uri}*) in node tests                   |
//                      | Charles Korthout | 0.9   | 10-06-2026     | Fix node() and . patterns to only match nodes, not atomic values                       |
//                      | Charles Korthout | 0.9   | 05-06-2026     | Static pattern validation (XTSE0340/XPST0017) for invalid constructs                   |
//                      | Charles Korthout | 1.0   | 05-06-2026     | Reject /[predicate] (XTSE0340); allow doc()/root() at pattern start                    |
//                      | Charles Korthout | 0.9   | 05-06-2026     | stepContextNode set from step-before-last, not first step; fixes match-125             |
//                      | Charles Korthout | 1.1   | 05-06-2026     | Added CompileAtomicMatch for .[expr] predicate patterns; fixes match-127/128/130       |
//                      | Charles Korthout | 1.2   | 07-06-2026     | CompileAtomicMatch: runtime numeric predicate check, whitespace/dot tolerance; +11 tests|
//                      | Charles Korthout | 1.3   | 07-06-2026     | attribute(*, type) comma-split in CompileNodeTest; fixes next-match-011                 |
//                      | Charles Korthout | 1.4   | 07-06-2026     | IsStaticError no longer treats XPTY as static; StripXPathComments now public            |
//                      | Charles Korthout | 1.5   | 09-06-2026     | Compile-time predicate validation via dry-run against dummy node; fixes match-040      |
//                      | Charles Korthout | 1.6   | 11-06-2026     | Removed over-restrictive key() second-arg check; allow literals/exprs in patterns      |
//                       | Charles Korthout | 1.7   | 11-06-2026     | Save/restore focus in WrapWithCurrentItem to protect caller context item                |
//                       | Charles Korthout | 1.8   | 11-06-2026     | Restored key() second-arg restriction to literal/variable reference in patterns        |
//                      | Charles Korthout | 1.9   | 13-06-2026     | Empty-URI EQName support in ParseQName (Q{}local)                                       |
//                      | Charles Korthout | 2.0   | 13-06-2026     | Disallow current-merge-group/current-merge-key in match patterns                        |
//                      | Charles Korthout | 2.1   | 13-06-2026     | match="." matches atomic items as well as nodes                                         |
//                      | Charles Korthout | 2.2   | 13-06-2026     | WrapWithCurrentItem clears regex-group state for pattern evaluation                     |
//                      | Charles Korthout | 2.3   | 13-06-2026     | Route attribute patterns with predicates through CompilePredicatePattern               |
//                      | Charles Korthout | 2.4   | 26-06-2026     | Support document-node(element(E)) match patterns                                        |
//                      | Charles Korthout | 2.5   | 26-06-2026     | Check URI for doc()/document() match patterns                                           |
//                      | Charles Korthout | 2.6   | 05-07-2026     | Disallow reverse axes in match patterns (XTSE0340); fixes version-023a                |
//                      | Charles Korthout | 2.7   | 14-07-2026     | namespace-node() match pattern support; fixes snapshot-0102a                           |
//                      | Charles Korthout | 2.8   | 01-08-2026     | union/intersect/except after / @ :: are NameTests, not operators; fixes match-038      |
//                      | Charles Korthout | 2.9   | 25-08-2026     | XTSE0340 validation for numeric pattern starts/steps and PI NCName arguments          |
//                      | Charles Korthout | 3.0   | 26-08-2026     | Propagate XTDE0640 circularity errors from pattern predicates                           |
//                      |==================|=======|================|=========================================================================================
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 3.1  | 02-09-2026     | XTSE3470/XTSE3500 for current-merge-group()/current-merge-key() in match patterns (merge-057/058)|
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 3.2   | 09-09-2026     | XML doc coverage on public API (Beta review)                                           |
//                      | Charles Korthout | 3.3   | 09-09-2026     | Perf: construct via the shared XDocumentNode wrapper cache                               |
//                      | Charles Korthout | 3.4   | 21-09-2026     | API freeze stage B: internalized                                                       |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 3.5   | 21-09-2026     | API freeze stage D: EffectiveBooleanValue -> GetEffectiveBooleanValue call sites         |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 3.6   | 23-09-2026     | schema-element()/schema-attribute() kind tests in match patterns                       |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 3.7   | 24-09-2026     | REQ-104 (PA-2): CompilePatternXPath carries the validation context's schema set so    |
//                      |                  |       |                | schema kind tests parse in schema-aware stylesheets                                     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 3.8   | 24-09-2026     | REQ-105 (PA-3): schema-aware type dispatch for element(N,T)/attribute(N,T) match      |
//                      |                  |       |                | patterns; built-in type resolution in IsSchemaTypeCompatible                            |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 3.9   | 29-09-2026     | element-with-id(...) patterns (match-054/055); '..' top-level step is XTSE0340        |
//                      |                  |       |                | (match-213); typed-mode compile: top-level QName rewritten as schema-element(QName)   |
//                      |                  |       |                | for strict/lax modes + GetSchemaRewriteableQNames for the XTSE3105 static check       |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 3.10  | 30-09-2026     | REQ-114/PB-3 C9: document-node(element(E[,T])) patterns enforce exactly one element     |
//                      |                  |       |                | child + no text children; built-in xs: typed attribute/element patterns no longer      |
//                      |                  |       |                | require an in-scope schema set (validation-1401, import-schema-055, conflict-1402)     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 3.11  | 02-10-2026     | PC-1 W5: XSLT 3.0 §10.1.4 relaxation — key() 2nd pattern argument may be a context-       |
//                      |                  |       |                | dependent step (@id), evaluated per candidate node (stream-211); 40+2 stays XTSE0340   |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 3.12  | 02-10-2026     | PC-1 W7-4: non-positional simple-step predicates self-evaluate on streamed nodes       |
//                      |                  |       |                | (IStreamingNode) instead of re-enumerating the consumed child axis from the parent     |
//                      |                  |       |                | (si-group-054/056 streamed group-starting-with)                                        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 3.13  | 08-10-2026     | REQ-118 4.0-S3b: StringTemplateNode rejected in patterns like other non-pattern forms    |
//                      |==================|=======|================|=========================================================================================
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 3.14  | 08-10-2026     | REQ-118 4.0-S4: PipelineExprNode ReadsPosition
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 3.15  | 10-10-2026     | REQ-125 review F2: Compile accepts in-scope namespace bindings; ParseQName resolves   |
//                      |                  |       |                | prefixed QNames against them (XPST0081 when unbound); runtime prefix-resolved paths   |
//                      |                  |       |                | keep the historical drop-prefix behavior because bindings are never supplied there    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 3.16  | 11-10-2026     | Carry effective XPath profiles into pattern predicate compilation.                      |
//                      | Charles Korthout | 3.17  | 13-10-2026     | Compile XPath 4.0 type patterns with declaring type and namespace scopes.                 |
//                      | Charles Korthout | 3.18  | 13-10-2026     | Match XPath 4.0 wildcard and union names in element/attribute kind-test patterns.
//                      | Charles Korthout | 3.19  | 13-10-2026     | Preserve 4.0 static context while compiling parenthesized union alternatives.
//                      | Charles Korthout | 3.20  | 13-10-2026     | Match named processing instructions in 4.0 forward-axis node tests.
//                      | Charles Korthout | 3.21  | 13-10-2026     | Validate parenthesized 4.0 item patterns and restrict outer patterns to nodes.
//                      | Charles Korthout | 3.22  | 13-10-2026     | Ignore predicate, string and URI slashes when classifying 4.0 outer filters.
//                      | Charles Korthout | 3.23  | 13-10-2026     | Match delimiters outside strings and EQName URIs in pattern compilation.
//                      | Charles Korthout | 3.24  | 13-10-2026     | Split pattern operators outside quoted content, URI names and nested expressions.
//                      | Charles Korthout | 3.25  | 13-10-2026     | Evaluate mixed 4.0 intersect/except pattern chains from left to right.
//                      | Charles Korthout | 3.26  | 13-10-2026     | Match 4.0 set-pattern axis operands against the candidate node.
//                      | Charles Korthout | 3.27  | 13-10-2026     | Validate 4.0 template pattern prefixes eagerly using lexer tokens.                     |
//                      | Charles Korthout | 3.28  | 14-10-2026     | Retain namespace-free function identity and host scope.                                  |
//                      | Charles Korthout | 3.29  | 16-10-2026     | Compile bounded string-key map patterns in the XSLT 4.0 profile.                         |
//                      | Charles Korthout | 3.30  | 16-10-2026     | Compose map entry sequence cardinality, nested patterns and map-focus predicates.         |
//                      | Charles Korthout | 3.31  | 16-10-2026     | Match current atomic type patterns and validate atomic alternatives.                      |
//                      | Charles Korthout | 3.32  | 16-10-2026     | Match named record patterns using existing record identity and instance checks.           |
//                      | Charles Korthout | 3.33  | 16-10-2026     | Match every array member using shared nested sequence-pattern checks.                     |
//                      | Charles Korthout | 3.34  | 22-10-2026     | Locate predicate brackets outside EQName namespace literals and quoted content.         |
// ===========================================================================================================================================================

using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using Bosak.XPath.Api;
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Parser.Ast;
using Bosak.XPath.Providers.Streaming;
using Bosak.XPath.Providers.Xml;
using Bosak.XPath.Runtime.Vm;
using Bosak.XPath.Standard.Functions;
using Bosak.Xslt.Stylesheet;

namespace Bosak.Xslt.Patterns;

/// <summary>
/// Signature for a compiled match pattern predicate.
/// Receives the candidate node and the current evaluation context (needed for variable reference patterns).
/// </summary>
internal delegate bool PatternPredicate(XdmValue item, EvaluationContext context);

/// <summary>
/// Compiles XSLT match patterns (e.g. <c>foo[bar]</c>, <c>*</c>, <c>@id | ref</c>)
/// into <c>PatternPredicate</c> predicates.
/// </summary>
internal sealed class PatternCompiler
{
    private static readonly Regex UnionPattern = new(@"\s*\|\s*", RegexOptions.Compiled);

    private readonly EvaluationContext? _validationContext;
    private readonly Func<string, string, int, IReadOnlyList<string>?>? _functionParameterNames;
    private readonly Func<string, string, int, int?>? _functionMinimumArity;
    private string? _defaultElementNamespace;
    private IReadOnlyDictionary<string, string>? _namespaces;
    private ModeTyped? _typedMode;

    /// <summary>
    /// Whether the validation context carries a compiled schema set. TemplateRule only
    /// compiles strict/lax typed-mode pattern variants when a schema set is in scope.
    /// </summary>
    public bool HasSchemaSet => _validationContext?.SchemaSet is not null;

    /// <summary>
    /// Creates a pattern compiler.
    /// </summary>
    /// <param name="validationContext">Optional evaluation context used when validating pattern predicates at compile time.</param>
    /// <param name="functionParameterNames">Host function parameter identities for keyword binding.</param>
    /// <param name="functionMinimumArity">Host function availability and required arity.</param>
    public PatternCompiler(EvaluationContext? validationContext = null,
        Func<string, string, int, IReadOnlyList<string>?>? functionParameterNames = null,
        Func<string, string, int, int?>? functionMinimumArity = null)
    {
        _validationContext = validationContext;
        _functionParameterNames = functionParameterNames;
        _functionMinimumArity = functionMinimumArity;
    }

    private XPathCompatibility _compatibility = XPathCompatibility.XPath31;
    private IReadOnlyDictionary<string, string>? _itemTypeAliases;
    private IReadOnlySet<string>? _namedRecordTypeNames;

    /// <summary>
    /// Compiles an XPath expression with the current default element namespace and profile.
    /// </summary>
    private XPath31Expression CompilePatternXPath(string expression)
    {
        // REQ-104: carry the validation context's compiled schema set so
        // schema-element()/schema-attribute() pattern tests parse in schema-aware
        // stylesheets; REQ-100 evaluates the declaration against the same set at
        // match time. Without a schema set the parse is unchanged (XPST0008).
        var schemaSet = _validationContext?.SchemaSet;
        if (_compatibility == XPathCompatibility.XPath31 && _namespaces is null && string.IsNullOrEmpty(_defaultElementNamespace) && schemaSet is null)
            return XPath31Expression.Compile(expression);
        var options = new CompileOptions
        {
            Compatibility = _compatibility,
            DefaultElementNamespace = _defaultElementNamespace,
            SchemaSet = schemaSet,
            Namespaces = _namespaces,
            FunctionParameterNames = _functionParameterNames,
            FunctionMinimumArity = _functionMinimumArity,
            ItemTypeAliases = _itemTypeAliases,
            NamedRecordTypeNames = _namedRecordTypeNames,
        };
        return XPath31Expression.Compile(expression, options);
    }

    /// <summary>
    /// Extracts an IXdmNode from an XdmValue candidate, returning null if the value is not a node.
    /// </summary>
    private static IXdmNode? AsNode(XdmValue item)
        => item.IsNode ? item.NodeValue : null;

    /// <summary>
    /// Static validation for constructs that must be rejected at compile time.
    /// May be called directly from the stylesheet loader for early XTSE0340 reporting.
    /// The supplied pattern must already have XPath comments stripped and be trimmed.
    /// </summary>
    /// <param name="trimmed">The comment-stripped pattern text.</param>
    /// <param name="compatibility">The declaring expression profile.</param>
    public static void ValidatePatternSyntax(string trimmed, XPathCompatibility compatibility = XPathCompatibility.XPath31)
    {
        if (compatibility >= XPathCompatibility.XPath40)
        {
            foreach (var op in new[] { "|", "union", "intersect", "except" })
            {
                var operands = SplitPatternTopLevel(trimmed, op);
                if (operands.Length > 1 && operands.Any(p => StringKeyMapPattern.StartsMapPattern(p) || AtomicPattern.StartsAtomicPattern(p) || RecordPattern.StartsRecordPattern(p) || ArrayPattern.StartsArrayPattern(p)))
                    throw new InvalidOperationException("XTSE0340: Set-pattern operands require node patterns; enclose non-node patterns in parentheses.");
            }
        }
        if (StringKeyMapPattern.StartsMapPattern(trimmed))
        {
            if (compatibility < XPathCompatibility.XPath40)
                throw new InvalidOperationException("XTSE0340: Map patterns require XSLT 4.0.");
            _ = StringKeyMapPattern.Parse(trimmed);
            return;
        }
        if (AtomicPattern.StartsAtomicPattern(trimmed))
        {
            if (compatibility < XPathCompatibility.XPath40)
                throw new InvalidOperationException("XTSE0340: Atomic patterns require XSLT 4.0.");
            _ = AtomicPattern.Parse(trimmed);
            return;
        }
        if (RecordPattern.StartsRecordPattern(trimmed))
        {
            if (compatibility < XPathCompatibility.XPath40)
                throw new InvalidOperationException("XTSE0340: Record patterns require XSLT 4.0.");
            _ = RecordPattern.Parse(trimmed);
            return;
        }
        if (ArrayPattern.StartsArrayPattern(trimmed))
        {
            if (compatibility < XPathCompatibility.XPath40)
                throw new InvalidOperationException("XTSE0340: Array patterns require XSLT 4.0.");
            _ = ArrayPattern.Parse(trimmed);
            return;
        }
        // 1.  Disallowed functions at pattern start (XTSE0340).
        //     Node tests (document-node, element, attribute, text, comment,
        //     processing-instruction, node, schema-element, schema-attribute,
        //     namespace-node) and the functions key() / id() / doc() / root() are
        //     allowed at the very start of a pattern. After a leading '/' or '//',
        //     only node-test functions are permitted; key()/id()/doc()/root() are not.
        {
            bool hadLeadingSlash = false;
            var afterSlash = trimmed;
            if (afterSlash.StartsWith("//"))
            {
                hadLeadingSlash = true;
                afterSlash = afterSlash[2..].TrimStart();
            }
            else if (afterSlash.StartsWith("/"))
            {
                hadLeadingSlash = true;
                afterSlash = afterSlash[1..].TrimStart();
            }

            // Strip axis prefix (e.g., child::, attribute::, descendant::)
            var axisColon = afterSlash.IndexOf("::", StringComparison.Ordinal);
            if (axisColon > 0)
            {
                var axisName = afterSlash[..axisColon];
                if (IsAxisName(axisName))
                    afterSlash = afterSlash[(axisColon + 2)..];
            }

            // Match:  name(...) at the very start
            if (afterSlash.Length > 0 && char.IsLetter(afterSlash[0]))
            {
                var lexicalStart = MaskEQNameUris(afterSlash);
                var paren = lexicalStart.IndexOf('(');
                if (paren > 0)
                {
                    var firstSpecial = lexicalStart.IndexOfAny(new[] { ' ', '/', '|', '[', '@' });
                    if (firstSpecial < 0 || firstSpecial > paren)
                    {
                        var funcName = afterSlash[..paren];
                        var nodeTestFunctions = new HashSet<string>(StringComparer.Ordinal)
                        {
                            "document-node", "element", "attribute", "text",
                            "comment", "processing-instruction", "node",
                            "schema-element", "schema-attribute", "namespace-node"
                        };
                        var allowedAtStart = new HashSet<string>(nodeTestFunctions, StringComparer.Ordinal)
                        {
                            "key", "id", "element-with-id", "doc", "root"
                        };
                        if (!allowedAtStart.Contains(funcName))
                        {
                            throw new InvalidOperationException("XTSE0340: Function call not allowed at the start of a pattern.");
                        }
                        if (hadLeadingSlash && !nodeTestFunctions.Contains(funcName))
                        {
                            throw new InvalidOperationException("XTSE0340: Function call not allowed after a leading '/' in a pattern.");
                        }
                    }
                }
            }
        }

        // 2.  A pattern must not start with a numeric literal or expression (XTSE0340).
        //     This catches patterns such as "2+2" which are XPath expressions, not patterns.
        ValidatePatternStart(trimmed);

        // 3.  A path step must not be a numeric literal (XTSE0340).
        //     Examples: "name/1223", "1/2".
        ValidateNumericPathSteps(trimmed);

        // 3b. The argument of processing-instruction() must be a string literal or an NCName (XTSE0340).
        ValidateProcessingInstructionNames(trimmed);

        // 3c. A top-level path step must not be ".." (XTSE0340).
        //     Examples: "/..", "foo/..", "//..". A ".." inside a predicate,
        //     parentheses, or a string literal is not a top-level step.
        ValidateNoParentSteps(trimmed);

        // 4.  Invalid predicate patterns (XTSE0340).
        {
            // Parenthesized predicate pattern (.[...])
            if (compatibility < XPathCompatibility.XPath40 && (trimmed.StartsWith("(.[") || trimmed.Contains("|(.[")))
            {
                throw new InvalidOperationException("XTSE0340: Parenthesized predicate pattern is not a valid pattern.");
            }
            // Leading lone slash with predicate: /[expr] or //[expr]
            if (trimmed.StartsWith("/[") || trimmed.StartsWith("//["))
            {
                throw new InvalidOperationException("XTSE0340: Filtered leading lone slash is not a valid pattern.");
            }
        }

        // 4.  Union pattern constraints:
        //     a) Union of node pattern and type pattern is not allowed.
        //     b) Predicate patterns (.[...]) are not valid as union operands.
        {
            var branches = SplitTopLevel(trimmed, '|');
            if (compatibility >= XPathCompatibility.XPath40 && branches.Length > 1 &&
                branches.Any(branch => branch.TrimStart().StartsWith('~') || branch.TrimStart().StartsWith('.')))
                throw new InvalidOperationException("XTSE0340: Union operands require node patterns; enclose item patterns in parentheses.");
            if (branches.Length > 1)
            {
                bool hasNodePattern = false;
                bool hasTypePattern = false;
                bool hasPredicatePattern = false;
                foreach (var b in branches)
                {
                    var s = b.Trim();
                    if (LooksLikeTypePattern(s))
                        hasTypePattern = true;
                    else
                        hasNodePattern = true;
                    if (s.StartsWith(".["))
                        hasPredicatePattern = true;
                }
                if (compatibility < XPathCompatibility.XPath40 && hasNodePattern && hasTypePattern)
                {
                    throw new InvalidOperationException("XTSE0340: Union of node pattern and type pattern is not allowed.");
                }
                if (compatibility < XPathCompatibility.XPath40 && hasPredicatePattern)
                {
                    throw new InvalidOperationException("XTSE0340: Predicate pattern is not allowed in a union.");
                }
            }
        }

        // 5.  Restricted arguments for key() in patterns (XTSE0340 / XPST0017).
        //     XSLT 2.0/3.0 require the second argument of key() within a match pattern
        //     to be a string literal or a variable reference; arbitrary expressions are
        //     not allowed.
        ValidateKeyFunctionArguments(trimmed);

        // 6.  Disallow current-group() and current-grouping-key() in patterns.
        if (ContainsFunctionCall(trimmed, "current-group"))
            throw new InvalidOperationException("XTSE1060: current-group() is not allowed in a match pattern");
        if (ContainsFunctionCall(trimmed, "current-grouping-key"))
            throw new InvalidOperationException("XTSE1070: current-grouping-key() is not allowed in a match pattern");
        if (ContainsFunctionCall(trimmed, "current-merge-group"))
            throw new InvalidOperationException("XTSE3470: current-merge-group() is not allowed in a match pattern");
        if (ContainsFunctionCall(trimmed, "current-merge-key"))
            throw new InvalidOperationException("XTSE3500: current-merge-key() is not allowed in a match pattern");

        // 7.  Disallow reverse axes at the top level of a step (XTSE0340).
        //     Allowed axes in match patterns are child, attribute, descendant,
        //     descendant-or-self, self, and namespace.
        ValidatePatternAxes(trimmed);

        // 8.  Undeclared function in predicate (XPST0017).
        //     NOTE: Accurate detection requires stylesheet context (declared functions,
        //     namespace prefixes). The XPath compiler currently does not validate
        //     function existence at compile time, so this check is deferred to runtime.
        //     When the XPath compiler gains static function resolution, this should be
        //     re-enabled with proper context.

    }

    /// <summary>
    /// Throws <c>XTSE0340</c> when the pattern starts with a numeric literal or expression,
    /// which can never be a valid pattern.
    /// </summary>
    private static void ValidatePatternStart(string trimmed)
    {
        var afterPrefix = trimmed;
        if (afterPrefix.StartsWith("//"))
            afterPrefix = afterPrefix[2..].TrimStart();
        else if (afterPrefix.StartsWith("/"))
            afterPrefix = afterPrefix[1..].TrimStart();

        // Strip axis prefix (e.g., child::, attribute::, descendant::)
        var axisColon = afterPrefix.IndexOf("::", StringComparison.Ordinal);
        if (axisColon > 0)
        {
            var axisName = afterPrefix[..axisColon];
            if (IsAxisName(axisName))
                afterPrefix = afterPrefix[(axisColon + 2)..];
        }

        if (afterPrefix.Length > 0 && IsNumericLiteralStart(afterPrefix))
            throw new InvalidOperationException("XTSE0340: A pattern must not start with a numeric literal or expression.");
    }

    /// <summary>
    /// Returns <c>true</c> when the supplied string begins with a numeric literal token.
    /// A leading '-' or '.' is only treated as part of the literal when followed by a digit.
    /// </summary>
    private static bool IsNumericLiteralStart(string text)
    {
        int i = 0;
        if (i < text.Length && text[i] == '-')
        {
            i++;
            if (i >= text.Length || !char.IsDigit(text[i]))
                return false;
        }
        else if (i < text.Length && text[i] == '.')
        {
            i++;
            if (i >= text.Length || !char.IsDigit(text[i]))
                return false;
        }
        else if (i < text.Length && char.IsDigit(text[i]))
        {
            // ok
        }
        else
        {
            return false;
        }

        bool hasDigit = false;
        while (i < text.Length && char.IsDigit(text[i]))
        {
            hasDigit = true;
            i++;
        }
        if (i < text.Length && text[i] == '.')
        {
            i++;
            while (i < text.Length && char.IsDigit(text[i]))
                i++;
        }
        return hasDigit;
    }

    /// <summary>
    /// Scans a pattern at top level for path steps that are numeric literals and
    /// throws <c>XTSE0340</c> if one is found.
    /// </summary>
    private static void ValidateNumericPathSteps(string trimmed)
    {
        var stripped = StripStringLiterals(trimmed);
        int qDepth = 0;
        int depth = 0;
        for (int i = 0; i < stripped.Length; i++)
        {
            char c = stripped[i];
            if (c == 'Q' && i + 1 < stripped.Length && stripped[i + 1] == '{')
            {
                qDepth++;
                i++;
                continue;
            }
            if (qDepth > 0)
            {
                if (c == '}') qDepth--;
                continue;
            }
            if (c == '[' || c == '(')
            {
                depth++;
                continue;
            }
            if (c == ']' || c == ')')
            {
                depth--;
                continue;
            }
            if (depth != 0)
                continue;
            if (c == '/')
            {
                int j = i + 1;
                while (j < stripped.Length && char.IsWhiteSpace(stripped[j])) j++;
                if (j < stripped.Length && IsNumericLiteralStart(stripped[j..]))
                    throw new InvalidOperationException("XTSE0340: A path step must not be a numeric literal.");
            }
        }
    }

    /// <summary>
    /// Validates that no top-level path step of the pattern is exactly <c>..</c> (XTSE0340).
    /// Catches patterns such as <c>/..</c>, <c>foo/..</c>, and <c>//..</c>; a <c>..</c>
    /// inside a predicate, parentheses, or a string literal is not a top-level step and
    /// is allowed.
    /// </summary>
    private static void ValidateNoParentSteps(string trimmed)
    {
        var stripped = StripStringLiterals(trimmed);
        int qDepth = 0;
        int depth = 0;
        int stepStart = 0;
        for (int i = 0; i <= stripped.Length; i++)
        {
            if (i < stripped.Length)
            {
                char c = stripped[i];
                if (c == 'Q' && i + 1 < stripped.Length && stripped[i + 1] == '{')
                {
                    qDepth++;
                    i++;
                    continue;
                }
                if (qDepth > 0)
                {
                    if (c == '}') qDepth--;
                    continue;
                }
                if (c == '[' || c == '(' || c == '{')
                {
                    depth++;
                    continue;
                }
                if (c == ']' || c == ')' || c == '}')
                {
                    depth--;
                    continue;
                }
                if (depth != 0 || c != '/')
                    continue;
            }
            // Top-level '/' (or end of pattern): check the step that ends here.
            if (stripped.AsSpan(stepStart, i - stepStart).Trim().SequenceEqual(".."))
                throw new InvalidOperationException("XTSE0340: '..' is not allowed as a step in a match pattern.");
            // Skip the second '/' of '//' (an empty middle step is not an error).
            if (i + 1 < stripped.Length && stripped[i] == '/' && stripped[i + 1] == '/')
                i++;
            stepStart = i + 1;
        }
    }

    /// <summary>
    /// Validates that every occurrence of <c>processing-instruction()</c> in a pattern
    /// uses either a string literal or a valid NCName as its argument.
    /// Throws <c>XTSE0340</c> for arguments containing a colon or starting with a digit.
    /// </summary>
    private static void ValidateProcessingInstructionNames(string trimmed)
    {
        const string func = "processing-instruction(";
        var stripped = StripStringLiterals(trimmed);
        int i = 0;
        while (i < stripped.Length)
        {
            int idx = stripped.IndexOf(func, i, StringComparison.Ordinal);
            if (idx < 0) break;
            // Ensure it is a whole function name, not part of a longer name.
            if (idx > 0 && IsNameChar(stripped[idx - 1]))
            {
                i = idx + 1;
                continue;
            }
            int open = idx + func.Length - 1;
            int close = FindMatchingParen(stripped, open);
            if (close < 0) break;
            var arg = stripped[(open + 1)..close].Trim();
            if (!string.IsNullOrEmpty(arg))
            {
                bool isStringLiteral = arg.Length >= 2 &&
                    ((arg[0] == '\'' && arg[^1] == '\'') || (arg[0] == '"' && arg[^1] == '"'));
                if (!isStringLiteral && (arg.Contains(':') || IsNumericLiteralStart(arg)))
                    throw new InvalidOperationException("XTSE0340: The argument of processing-instruction() must be a string literal or an NCName.");
            }
            i = close + 1;
        }
    }

    /// <summary>
    /// Scans a pattern for disallowed axes that appear outside predicates at the
    /// top level of a step and throws <c>XTSE0340</c> if one is found.
    /// </summary>
    private static void ValidatePatternAxes(string pattern)
    {
        var disallowedAxes = new HashSet<string>(StringComparer.Ordinal)
        {
            "preceding-sibling", "following-sibling", "preceding", "following",
            "ancestor", "ancestor-or-self", "parent"
        };

        int depth = 0;
        for (int i = 0; i < pattern.Length; i++)
        {
            char c = pattern[i];
            if (c == '[' || c == '(')
            {
                depth++;
                continue;
            }
            if (c == ']' || c == ')')
            {
                depth--;
                continue;
            }
            if (depth != 0)
                continue;
            if (c == ':' && i + 1 < pattern.Length && pattern[i + 1] == ':')
            {
                // Scan backwards for the axis name (letters and hyphen).
                int start = i - 1;
                while (start >= 0 && (char.IsLetter(pattern[start]) || pattern[start] == '-'))
                    start--;
                start++;
                var axis = pattern[start..i];
                if (disallowedAxes.Contains(axis))
                    throw new InvalidOperationException($"XTSE0340: The '{axis}' axis is not allowed in a match pattern");
            }
        }
    }

    /// <summary>
    /// Validates that every occurrence of key() in a pattern uses an allowed
    /// second argument (literal, variable reference, or parenthesized sequence).
    /// </summary>
    private static void ValidateKeyFunctionArguments(string pattern)
    {
        int i = 0;
        while (i < pattern.Length)
        {
            int start = pattern.IndexOf("key(", i, StringComparison.Ordinal);
            if (start < 0) break;

            int close = FindMatchingParen(pattern, start + 3);
            if (close > 0)
            {
                var args = pattern[(start + 4)..close];
                var firstComma = FindTopLevelComma(args);
                if (firstComma >= 0)
                {
                    var rest = args[(firstComma + 1)..];
                    var secondComma = FindTopLevelComma(rest);
                    var secondArg = (secondComma >= 0 ? rest[..secondComma] : rest).Trim();
                    if (!IsAllowedKeyPatternArgument(secondArg))
                    {
                        throw new InvalidOperationException("XTSE0340: The second argument of key() in a pattern must be a literal, variable reference, or parenthesized sequence.");
                    }
                }
                i = close + 1;
            }
            else
            {
                break;
            }
        }
    }

    private static bool IsAllowedKeyPatternArgument(string arg)
    {
        if (string.IsNullOrEmpty(arg))
            return false;

        // String literals and variable references are always allowed.
        if (arg[0] == '\'' || arg[0] == '\"' || arg[0] == '$')
            return true;

        // Parenthesized sequence constructor (e.g. composite key tuples).
        if (arg[0] == '(' && FindMatchingParen(arg, 0) == arg.Length - 1)
            return true;

        // XSLT 3.0 §10.1.4 relaxes the XSLT 2.0 constraint: the second argument may be a
        // context-dependent step such as @id or child::item, evaluated with the candidate
        // node as the context item (stream-211's item[key('change', @id, $doc2)]/foo).
        // General expressions (e.g. 40+2) remain XTSE0340 (match-079/080).
        if (IsContextDependentKeyArgument(arg))
            return true;

        // Numeric literals (integer/decimal), optionally negative.
        int pos = 0;
        if (arg[0] == '-')
        {
            if (arg.Length == 1)
                return false;
            pos = 1;
        }
        bool hasDigits = false;
        while (pos < arg.Length && char.IsDigit(arg[pos]))
        {
            hasDigits = true;
            pos++;
        }
        if (pos < arg.Length && arg[pos] == '.')
        {
            pos++;
            while (pos < arg.Length && char.IsDigit(arg[pos]))
            {
                hasDigits = true;
                pos++;
            }
        }
        return hasDigits && pos == arg.Length;
    }

    /// <summary>Whether the key() second argument is a context-dependent step — a bare
    /// axis step (@id, child::item), the context item (.), or a filtered form of either —
    /// which XSLT 3.0 §10.1.4 permits in a pattern and the predicate machinery evaluates
    /// per candidate node. Anything that does not parse, or parses to a non-step shape
    /// (arithmetic, function calls, sequences), is not allowed.</summary>
    private static bool IsContextDependentKeyArgument(string arg)
    {
        XPathAstNode ast;
        try
        {
            // This is a shape check; CompilePatternXPath enforces the owning profile.
            ast = XPathParser.Parse(arg, xpath40: true);
        }
        catch (Exception)
        {
            return false;
        }
        return IsStepShapedKeyArgument(ast);
    }

    private static bool IsStepShapedKeyArgument(XPathAstNode node) => node switch
    {
        ParenthesizedExprNode p => IsStepShapedKeyArgument(p.Expression),
        StepNode => true,
        ContextItemNode => true,
        PostfixPredicateNode pp => IsStepShapedKeyArgument(pp.Expression),
        _ => false,
    };

    /// <summary>Whether a pattern predicate cannot act as a positional predicate and
    /// does not read the focus position/size anywhere: its value depends only on the
    /// candidate node. Such a predicate may be evaluated as
    /// <c>self::node()[pred]</c> on the candidate itself, which is the only option for
    /// streamed nodes whose parents cannot re-enumerate consumed child axes.</summary>
    private bool IsNonPositionalPredicateExpr(string predicateExpr)
    {
        XPathAstNode ast;
        try
        {
            ast = XPathParser.Parse(predicateExpr, xpath40: _compatibility >= XPathCompatibility.XPath40);
        }
        catch (Exception)
        {
            return false;
        }

        static bool ReadsPosition(XPathAstNode node) => node switch
        {
            FunctionCallNode f => (f.LocalName is "position" or "last" && f.Prefix is null or "" or "fn")
                || f.Arguments.Any(ReadsPosition),
            NamedFunctionRefNode rf => rf.LocalName is "position" or "last" && rf.Prefix is null or "" or "fn",
            ArrowExprNode a => ReadsPosition(a.Source) || ReadsPosition(a.Target),
            PipelineExprNode p => ReadsPosition(p.Source) || ReadsPosition(p.Target),
            StepNode s => s.Predicates.Any(ReadsPosition),
            PathExprNode p => p.Steps.Any(ReadsPosition),
            PostfixPredicateNode pp => ReadsPosition(pp.Expression) || ReadsPosition(pp.Predicate),
            PredicateNode pd => ReadsPosition(pd.Expression),
            ParenthesizedExprNode par => ReadsPosition(par.Expression),
            SequenceExpressionNode seq => seq.Expressions.Any(ReadsPosition),
            RangeExpressionNode r => ReadsPosition(r.From) || ReadsPosition(r.To),
            IfExpressionNode i => ReadsPosition(i.Condition) || ReadsPosition(i.ThenBranch) || ReadsPosition(i.ElseBranch),
            BinaryExpressionNode b => ReadsPosition(b.Left) || ReadsPosition(b.Right),
            UnaryExpressionNode u => ReadsPosition(u.Operand),
            CastNode c => ReadsPosition(c.Expression),
            CastableNode ca => ReadsPosition(ca.Expression),
            InstanceOfNode io => ReadsPosition(io.Expression),
            TreatNode t => ReadsPosition(t.Expression),
            LetExpressionNode l => l.Bindings.Any(x => ReadsPosition(x.Expression)) || ReadsPosition(l.Body),
            ForExpressionNode f => f.Bindings.Any(x => ReadsPosition(x.Expression)) || ReadsPosition(f.ReturnExpression),
            QuantifiedExpressionNode q => q.Bindings.Any(x => ReadsPosition(x.Expression)) || ReadsPosition(q.SatisfiesExpression),
            LookupNode lk => ReadsPosition(lk.Expression) || ReadsPosition(lk.Key),
            LookupWildcardNode lw => ReadsPosition(lw.Expression),
            DynamicFunctionCallNode d => ReadsPosition(d.Function) || d.Arguments.Any(ReadsPosition),
            InlineFunctionNode inf => ReadsPosition(inf.Body),
            MapConstructorNode m => m.Entries.Any(e => ReadsPosition(e.Key) || ReadsPosition(e.Value)),
            ArrayConstructorNode a => a.Items.Any(ReadsPosition),
            TryCatchNode t => ReadsPosition(t.TryExpression) || t.Clauses.Any(c => ReadsPosition(c.Expression)),
            // Conservative: any exotic form (FLWOR, constructors, switch/typeswitch,
            // validate, string constructors, ...) blocks self-evaluation.
            _ => node is FlworClauseNode or FlworExpressionNode or SwitchExpressionNode or TypeswitchExpressionNode
                or ValidateExpressionNode or StringConstructorNode or StringTemplateNode or DirectElementConstructorNode
                or ComputedElementConstructorNode or ComputedAttributeConstructorNode
                or ComputedDocumentConstructorNode or ComputedTextConstructorNode or ComputedCommentConstructorNode
                or ComputedPIConstructorNode or ComputedNamespaceConstructorNode or DirectCommentNode
                or DirectProcessingInstructionNode or SignificantTextNode,
        };

        static bool GuaranteedNonNumeric(XPathAstNode node) => node switch
        {
            BinaryExpressionNode b => b.Operator is BinaryOperator.Or or BinaryOperator.And
                or BinaryOperator.Eq or BinaryOperator.Ne or BinaryOperator.Lt or BinaryOperator.Le
                or BinaryOperator.Gt or BinaryOperator.Ge or BinaryOperator.Equal or BinaryOperator.NotEqual
                or BinaryOperator.LessThan or BinaryOperator.LessThanOrEqual or BinaryOperator.GreaterThan
                or BinaryOperator.GreaterThanOrEqual or BinaryOperator.Is or BinaryOperator.Precedes
                or BinaryOperator.Follows,
            ParenthesizedExprNode par => GuaranteedNonNumeric(par.Expression),
            StepNode => true,
            ContextItemNode => true,
            BooleanLiteralNode => true,
            _ => false,
        };

        return GuaranteedNonNumeric(ast) && !ReadsPosition(ast);
    }

    /// <summary>
    /// Returns true when the supplied pattern contains a call to the named function,
    /// ignoring occurrences inside string literals.
    /// </summary>
    private static bool ContainsFunctionCall(string pattern, string name)
    {
        var stripped = StripStringLiterals(pattern);
        int i = 0;
        while (i < stripped.Length)
        {
            int idx = stripped.IndexOf(name + "(", i, StringComparison.Ordinal);
            if (idx < 0) return false;
            // Ensure the match is not part of a longer name.
            if ((idx == 0 || !IsNameChar(stripped[idx - 1])) &&
                (idx + name.Length < stripped.Length && stripped[idx + name.Length] == '('))
            {
                return true;
            }
            i = idx + 1;
        }
        return false;
    }

    /// <summary>
    /// Returns a copy of the pattern with the contents of string literals replaced by spaces,
    /// so that literal text does not interfere with syntactic checks.
    /// </summary>
    private static string StripStringLiterals(string pattern)
    {
        var sb = new System.Text.StringBuilder(pattern.Length);
        char? inString = null;
        for (int i = 0; i < pattern.Length; i++)
        {
            char c = pattern[i];
            if (inString == null)
            {
                if (c == '\'' || c == '"')
                {
                    inString = c;
                    sb.Append(c);
                }
                else
                {
                    sb.Append(c);
                }
            }
            else
            {
                if (c == inString.Value)
                {
                    // Handle doubled quote inside string literal.
                    if (i + 1 < pattern.Length && pattern[i + 1] == inString.Value)
                    {
                        sb.Append(c);
                        sb.Append(c);
                        i++;
                    }
                    else
                    {
                        inString = null;
                        sb.Append(c);
                    }
                }
                else
                {
                    sb.Append(' ');
                }
            }
        }
        return sb.ToString();
    }

    private static bool IsNameChar(char c)
        => char.IsLetterOrDigit(c) || c == '_' || c == '-' || c == '.';

    /// <summary>
    /// Determines whether a pattern branch looks like a type pattern.
    /// </summary>
    private static bool LooksLikeTypePattern(string branch)
    {
        var s = branch.Trim();
        // .[. instance of xs:integer] or (.[. instance of xs:integer])
        if (s.StartsWith("(.[") || (s.StartsWith(".[") && s.Contains("instance of")))
            return true;
        // element(foo) or attribute(bar) etc.
        if (s.StartsWith("element(") || s.StartsWith("attribute(") ||
            s.StartsWith("text(") || s.StartsWith("comment(") ||
            s.StartsWith("processing-instruction(") || s.StartsWith("document-node(") ||
            s.StartsWith("node("))
        {
            // These are actually node tests, not type patterns.
            return false;
        }
        // type-name like xs:integer, but not node kinds
        // For simplicity, check if it matches the "instance of" form or starts with a type name.
        if (s.Contains("instance of"))
            return true;
        return false;
    }

    /// <summary>
    /// Checks whether a string is a valid XPath axis name.
    /// </summary>
    private static bool IsAxisName(string name)
    {
        return name == "child" || name == "descendant" || name == "attribute" ||
               name == "self" || name == "descendant-or-self" || name == "following-sibling" ||
               name == "following" || name == "namespace" || name == "parent" ||
               name == "ancestor" || name == "preceding-sibling" || name == "preceding" ||
               name == "ancestor-or-self";
    }

    /// <summary>
    /// Checks whether a namespace URI is a standard XPath / XSLT namespace.
    /// </summary>
    private static bool IsStandardNamespace(string ns)
    {
        return ns == "http://www.w3.org/2005/xpath-functions" ||
               ns == "http://www.w3.org/2005/xpath-functions/math" ||
               ns == "http://www.w3.org/2005/xpath-functions/map" ||
               ns == "http://www.w3.org/2005/xpath-functions/array" ||
               ns == "http://www.w3.org/2001/XMLSchema" ||
               ns == "http://www.w3.org/1999/XSL/Transform" ||
               ns == "http://www.w3.org/XML/1998/namespace";
    }

    /// <summary>
    /// Compiles a match pattern string into a predicate function.
    /// </summary>
    /// <param name="pattern">The match pattern (XPath comments stripped by the caller or here).</param>
    /// <param name="defaultElementNamespace">The xpath-default-namespace in scope, if any.</param>
    /// <param name="typedMode">
    /// When the pattern is compiled for a strict or lax typed mode, a plain QName at the
    /// top level of the pattern (or of a union branch, or after a leading <c>/</c> or <c>//</c>)
    /// is interpreted as <c>schema-element(QName)</c> per XSLT 3.0 §5.5.3. Null compiles
    /// the default (untyped) semantics.
    /// </param>
    /// <param name="namespaces">
    /// Optional in-scope namespace bindings used to resolve <c>prefix:local</c> QNames that
    /// appear verbatim in the pattern text. Runtime callers pass prefix-resolved
    /// (<c>Q{{uri}}local</c>) patterns and leave this null; static validation passes the
    /// slot's real bindings so undeclared prefixes are rejected (XPST0081).
    /// </param>
    /// <param name="compatibility">The owning expression profile; nested compilation inherits it.</param>
    /// <param name="itemTypeAliases">Expanded types in the declaring package.</param>
    /// <param name="namedRecordTypeNames">Known nominative record names in that package.</param>
    public PatternPredicate Compile(
        string pattern,
        string? defaultElementNamespace = null,
        ModeTyped? typedMode = null,
        IReadOnlyDictionary<string, string>? namespaces = null,
        XPathCompatibility? compatibility = null,
        IReadOnlyDictionary<string, string>? itemTypeAliases = null,
        IReadOnlySet<string>? namedRecordTypeNames = null)
    {
        _defaultElementNamespace = defaultElementNamespace;
        var savedCompatibility = _compatibility;
        _compatibility = compatibility ?? _compatibility;
        var savedTypedMode = _typedMode;
        var savedNamespaces = _namespaces;
        var savedAliases = _itemTypeAliases;
        var savedRecords = _namedRecordTypeNames;
        _itemTypeAliases = itemTypeAliases;
        _namedRecordTypeNames = namedRecordTypeNames;
        _typedMode = typedMode;
        _namespaces = namespaces;
        try
        {
            var trimmed = StripXPathComments(pattern).Trim();

            // Normalize top-level "union" to "|" so both syntaxes split uniformly.
            var unionParts = SplitTopLevel(trimmed, "union");
            if (unionParts.Length > 1)
            {
                trimmed = string.Join("|", unionParts);
            }

            ValidatePatternSyntax(trimmed, _compatibility);

            var branches = SplitTopLevel(trimmed, '|');
            if (branches.Length == 1)
            {
                var atomic = CompileAtomicMatch(branches[0]);
                if (atomic != null)
                    return WrapWithCurrentItem(atomic);
                return WrapWithCurrentItem(CompileSinglePattern(branches[0]));
            }

            var compiledBranches = branches.Select(b =>
            {
                var atomic = CompileAtomicMatch(b);
                return atomic ?? CompileSinglePattern(b);
            }).ToArray();
            return WrapWithCurrentItem((item, ctx) => compiledBranches.Any(b => b(item, ctx)));
        }
        finally
        {
            _compatibility = savedCompatibility;
            _typedMode = savedTypedMode;
            _namespaces = savedNamespaces;
            _itemTypeAliases = savedAliases;
            _namedRecordTypeNames = savedRecords;
        }
    }

    /// <summary>Separates a type from trailing predicates while preserving quoted fields and EQNames.</summary>
    internal static (string Type, string Predicates) GetTypePatternParts(string pattern)
    {
        var text = StripXPathComments(pattern).Trim();
        if (!text.StartsWith('~')) throw new InvalidOperationException("XTSE0340: Expected a type pattern.");
        int depth = 0;
        char quote = '\0';
        bool eqName = false;
        for (int i = 1; i < text.Length; i++)
        {
            char c = text[i];
            if (quote != '\0')
            {
                if (c == quote)
                {
                    if (i + 1 < text.Length && text[i + 1] == quote) i++;
                    else quote = '\0';
                }
                continue;
            }
            if (eqName) { if (c == '}') eqName = false; continue; }
            if (c == '{' && i > 0 && text[i - 1] == 'Q') { eqName = true; continue; }
            if (c is '\'' or '"') { quote = c; continue; }
            if (c == '(') depth++;
            else if (c == ')') depth--;
            else if (c == '[' && depth == 0) return (text[1..i].Trim(), text[i..]);
        }
        return (text[1..].Trim(), string.Empty);
    }

    /// <summary>
    /// Compiles an atomic-value matcher for predicate patterns (.[expr]).
    /// Returns null if the pattern is not a predicate pattern that can match atomic values.
    /// </summary>
    /// <param name="pattern">The candidate predicate or type pattern.</param>
    /// <returns>The matcher, or null when the pattern requires node-path compilation.</returns>
    public PatternPredicate? CompileAtomicMatch(string pattern)
    {
        var trimmed = StripXPathComments(pattern).Trim();

        if (StringKeyMapPattern.StartsMapPattern(trimmed))
        {
            if (_compatibility < XPathCompatibility.XPath40)
                throw new InvalidOperationException("XTSE0340: Map patterns require XSLT 4.0.");
            var map = StringKeyMapPattern.Parse(trimmed);
            var outer = map.Predicates.Length > 0 ? CompileAtomicMatch("." + map.Predicates) : null;
            return map.Compile(CompileSequencePattern, outer);
        }

        if (AtomicPattern.StartsAtomicPattern(trimmed))
        {
            if (_compatibility < XPathCompatibility.XPath40)
                throw new InvalidOperationException("XTSE0340: Atomic patterns require XSLT 4.0.");
            var atomic = AtomicPattern.Parse(trimmed);
            var types = atomic.ResolveTypes(ResolvePatternTypeName);
            var type = types.Length == 1 ? types[0] : "(" + string.Join("|", types) + ")";
            var test = CompilePatternXPath(". instance of " + type);
            var outer = atomic.Predicates.Length > 0 ? CompileAtomicMatch("." + atomic.Predicates) : null;
            return (item, context) => !item.IsNode && !item.IsMap && !item.IsArray && !item.IsFunction &&
                test.Evaluate(context.WithFocus(item, 1, 1)).BooleanValue && (outer is null || outer(item, context));
        }

        if (RecordPattern.StartsRecordPattern(trimmed))
        {
            if (_compatibility < XPathCompatibility.XPath40)
                throw new InvalidOperationException("XTSE0340: Record patterns require XSLT 4.0.");
            var record = RecordPattern.Parse(trimmed);
            var type = ResolvePatternTypeName(record.Name).Trim();
            while (type.StartsWith('(') && FindMatchingParen(type, 0) == type.Length - 1)
                type = type[1..^1].Trim();
            var parsed = XPathParser.Parse("() instance of " + type, schemaAware: HasSchemaSet, xpath40: true);
            if (parsed is not InstanceOfNode { Occurrence: OccurrenceIndicator.One } instance ||
                (_namedRecordTypeNames?.Contains(instance.TypeName) != true && !Regex.IsMatch(instance.TypeName, @"^record\s*\(")))
                throw new InvalidOperationException("XTSE0340: A record pattern name must resolve to a record type.");
            // The type compiler validates the complete structural type and retains nominal identity.
            var test = CompilePatternXPath(". instance of " + type);
            var outer = record.Predicates.Length > 0 ? CompileAtomicMatch("." + record.Predicates) : null;
            return (item, context) => item.IsMap &&
                test.Evaluate(context.WithFocus(item, 1, 1)).BooleanValue && (outer is null || outer(item, context));
        }

        if (ArrayPattern.StartsArrayPattern(trimmed))
        {
            if (_compatibility < XPathCompatibility.XPath40)
                throw new InvalidOperationException("XTSE0340: Array patterns require XSLT 4.0.");
            var array = ArrayPattern.Parse(trimmed);
            var members = CompileSequencePattern(array.Members);
            var outer = array.Predicates.Length > 0 ? CompileAtomicMatch("." + array.Predicates) : null;
            return (item, context) =>
            {
                if (!item.IsArray) return false;
                foreach (var member in item.ArrayValue.Values)
                    if (!members(member, context)) return false;
                return outer is null || outer(item, context);
            };
        }

        // In 4.0 parentheses introduce an XNode pattern, even when the contained pattern accepts any item.
        if (_compatibility >= XPathCompatibility.XPath40 && trimmed.StartsWith('('))
            return null;

        // Strip outer parentheses
        if (trimmed.StartsWith('('))
        {
            int close = FindMatchingParen(trimmed, 0);
            if (close == trimmed.Length - 1)
                trimmed = trimmed[1..close].Trim();
        }

        bool isTypePattern = trimmed.StartsWith('~');
        if (isTypePattern)
        {
            if (_compatibility < XPathCompatibility.XPath40)
                throw new InvalidOperationException("XTSE0340: Type patterns require XSLT 4.0.");
            var (type, typePredicates) = GetTypePatternParts(trimmed);
            // Validate a complete ItemType, rather than admitting an arbitrary XPath expression.
            var parsed = XPathParser.Parse("() instance of " + type, schemaAware: HasSchemaSet, xpath40: true);
            if (parsed is not InstanceOfNode instance || instance.Occurrence != OccurrenceIndicator.One || instance.TypeName == "empty-sequence()")
                throw new InvalidOperationException("XTSE0340: A type pattern requires a single item type.");
            trimmed = ".[. instance of " + type + "]" + typePredicates;
        }

        // Only predicate patterns can match atomic values
        // Tolerate whitespace between '.' and '[' (e.g. ". [expr]" after comment stripping)
        if (!trimmed.StartsWith("."))
            return null;
        int afterDot = 1;
        while (afterDot < trimmed.Length && char.IsWhiteSpace(trimmed[afterDot]))
            afterDot++;
        if (afterDot >= trimmed.Length || trimmed[afterDot] != '[')
            return null;

        // Extract all predicates after the leading '.'
        var predicates = new List<string>();
        string rest = trimmed[1..].TrimStart();
        while (rest.StartsWith('['))
        {
            int close = FindMatchingBracket(rest, 0);
            if (close < 0)
            {
                if (isTypePattern) throw new InvalidOperationException("XTSE0340: Unclosed type-pattern predicate.");
                return null;
            }
            predicates.Add(rest[1..close].Trim());
            rest = rest[(close + 1)..].TrimStart();
        }

        if (predicates.Count == 0)
            return null;

        // If there's anything after the predicates (e.g. /child::x), atomic values
        // cannot match, so let the normal node-based path handle it.
        if (!string.IsNullOrEmpty(rest))
        {
            if (isTypePattern) throw new InvalidOperationException("XTSE0340: Unexpected text after a type pattern.");
            return null;
        }

        // XSLT 3.0 §6.4: numeric predicate 1 always matches; any other numeric value never matches.
        // Pre-compile all predicates; apply numeric semantics at runtime for variable expressions.
        var compiledPredicates = new List<(string expr, bool isLiteralOne, bool isLiteralNever)>();
        foreach (var pred in predicates)
        {
            var stripped = StripXPathComments(pred).Trim();
            if (int.TryParse(stripped, out int n))
            {
                if (n != 1)
                    compiledPredicates.Add((pred, false, true)); // literal != 1: never matches
                else
                    compiledPredicates.Add((pred, true, false)); // literal 1: no-op
                continue;
            }
            compiledPredicates.Add((pred, false, false)); // non-literal: evaluate at runtime
        }

        // Pre-compile XPath expressions for non-literal predicates
        var predCompilers = compiledPredicates.Select(p => CompilePatternXPath(p.expr)).ToList();

        return (item, ctx) =>
        {
            var savedItem = ctx.ContextItem;
            var savedPos = ctx.ContextPosition;
            var savedSize = ctx.ContextSize;
            try
            {
                for (int i = 0; i < compiledPredicates.Count; i++)
                {
                    var (expr, isLiteralOne, isLiteralNever) = compiledPredicates[i];
                    if (isLiteralNever)
                        return false;
                    if (isLiteralOne)
                        continue;

                    var result = predCompilers[i].Evaluate(ctx.WithFocus(item, 1, 1));

                    // XSLT 3.0 §6.4: numeric predicate 1 always matches; any other numeric value never matches.
                    if (result.Kind == XdmValueKind.Integer)
                    {
                        if (result.IntegerValue != 1)
                            return false;
                        continue; // 1 is a no-op
                    }
                    if (result.Kind == XdmValueKind.Decimal)
                    {
                        if (result.DecimalValue != 1m)
                            return false;
                        continue;
                    }
                    if (result.Kind == XdmValueKind.Double || result.Kind == XdmValueKind.Float)
                    {
                        if (result.DoubleValue != 1.0)
                            return false;
                        continue;
                    }

                    if (!result.GetEffectiveBooleanValue())
                        return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                if (IsStaticError(ex)) throw;
                return false;
            }
            finally
            {
                ctx.WithFocus(savedItem, savedPos, savedSize);
            }
        };
    }

    /// <summary>Resolves a pattern type EQName and expands a bound item-type alias.</summary>
    private string ResolvePatternTypeName(string name)
    {
        string key;
        if (name.StartsWith("Q{", StringComparison.Ordinal)) key = name;
        else
        {
            var colon = name.IndexOf(':');
            var prefix = colon < 0 ? "" : name[..colon];
            var ns = colon < 0 ? _defaultElementNamespace ?? "" :
                _namespaces?.GetValueOrDefault(prefix) ?? (prefix == "xs" ? XmlSchema.Namespace : null);
            if (ns is null) throw new InvalidOperationException("XPST0081: Unknown pattern type prefix: " + prefix);
            key = "Q{" + ns + "}" + (colon < 0 ? name : name[(colon + 1)..]);
        }
        return _itemTypeAliases?.GetValueOrDefault(key) ?? key;
    }

    /// <summary>Compiles a nested sequence pattern, checking cardinality without coercing its items.</summary>
    private PatternPredicate CompileSequencePattern(string text)
    {
        text = text.Trim();
        int minimum = 1, maximum = 1;
        PatternPredicate? matcher;
        if (ArrayPattern.IsEmptySequence(text))
        {
            minimum = maximum = 0;
            matcher = null;
        }
        else
        {
            if (text.Length > 1 && (text[^1] is '?' or '+' ||
                (text[^1] == '*' && !text.EndsWith(":*", StringComparison.Ordinal) && !text.EndsWith("}*", StringComparison.Ordinal))))
            {
                char occurrence = text[^1];
                text = text[..^1].TrimEnd();
                minimum = occurrence == '+' ? 1 : 0;
                maximum = occurrence == '?' ? 1 : int.MaxValue;
            }
            if (text.Length == 0 || text.EndsWith('?') || text.EndsWith('+') ||
                text.EndsWith("**", StringComparison.Ordinal) || ArrayPattern.IsEmptySequence(text))
                throw new InvalidOperationException("XTSE0340: Invalid nested sequence pattern.");
            ValidateSequencePatternDelimiters(text);
            matcher = Compile(text, _defaultElementNamespace, _typedMode, _namespaces, _compatibility,
                _itemTypeAliases, _namedRecordTypeNames);
        }
        return (value, context) =>
        {
            if (value.IsUndefined) return minimum == 0;
            if (!value.IsSequence)
                return maximum >= 1 && matcher is not null && matcher(value, context);
            int count = 0;
            foreach (var item in XdmSequence.FromSource(value.SequenceValue!))
            {
                if (count == maximum || matcher is null || !matcher(item, context)) return false;
                count++;
            }
            return count >= minimum;
        };
    }

    /// <summary>Rejects incomplete nested patterns before the permissive legacy node-pattern compiler.</summary>
    private static void ValidateSequencePatternDelimiters(string text)
    {
        var delimiters = new Stack<char>();
        char quote = '\0';
        bool uri = false;
        for (int i = 0; i < text.Length; i++)
        {
            char c = text[i];
            if (quote != '\0')
            {
                if (c == quote)
                {
                    if (i + 1 < text.Length && text[i + 1] == quote) i++;
                    else quote = '\0';
                }
                continue;
            }
            if (uri) { if (c == '}') uri = false; continue; }
            if (c == 'Q' && i + 1 < text.Length && text[i + 1] == '{') { uri = true; i++; continue; }
            if (c is '\'' or '"') { quote = c; continue; }
            if (c is '(' or '[' or '{') delimiters.Push(c);
            else if (c is ')' or ']' or '}')
            {
                char expected = c == ')' ? '(' : c == ']' ? '[' : '{';
                if (delimiters.Count == 0 || delimiters.Pop() != expected)
                    throw new InvalidOperationException("XTSE0340: Unbalanced nested sequence pattern delimiters.");
            }
        }
        if (delimiters.Count != 0 || quote != '\0' || uri)
            throw new InvalidOperationException("XTSE0340: Unclosed nested sequence pattern delimiter.");
    }

    /// <summary>
    /// Wraps a compiled pattern so that <c>fn:current()</c> returns the candidate node
    /// being tested, as required by XSLT match-pattern semantics. Also clears the
    /// <c>regex-group()</c> state so patterns cannot see captured substrings from an
    /// enclosing <c>xsl:analyze-string</c>.
    /// </summary>
    private static PatternPredicate WrapWithCurrentItem(PatternPredicate inner)
    {
        return (item, ctx) =>
        {
            var savedCurrent = ctx.CurrentItem;
            var savedItem = ctx.ContextItem;
            var savedPos = ctx.ContextPosition;
            var savedSize = ctx.ContextSize;
            var savedRegexGroups = ctx.RegexGroups;
            try
            {
                ctx.WithCurrentItem(item);
                ctx.RegexGroups = null;
                return inner(item, ctx);
            }
            finally
            {
                ctx.WithCurrentItem(savedCurrent);
                ctx.WithFocus(savedItem, savedPos, savedSize);
                ctx.RegexGroups = savedRegexGroups;
            }
        };
    }

    private PatternPredicate CompileSinglePattern(string pattern)
    {
        var trimmed = pattern.Trim();

        if (_compatibility >= XPathCompatibility.XPath40)
        {
            var operators = new List<string>();
            var operands = SplitPatternTopLevel(trimmed, "intersect", "except", operators);
            if (operands.Length > 1)
            {
                if (operands.All(HasPatternPathOperator))
                    return CompileSetPattern(trimmed);
                var compiled = operands.Select(CompileSinglePattern).ToArray();
                return (item, ctx) =>
                {
                    if (!item.IsNode || !compiled[0](item, ctx)) return false;
                    for (int i = 1; i < compiled.Length; i++)
                    {
                        bool matches = compiled[i](item, ctx);
                        if (operators[i - 1] == "intersect" ? !matches : matches) return false;
                    }
                    return true;
                };
            }
        }

        // Handle top-level except (not inside parentheses/brackets)
        var exceptParts = SplitTopLevel(trimmed, "except");
        if (exceptParts.Length >= 2)
        {
            // Use XPath-from-root only when all branches are path expressions or axis steps.
            // Simple patterns like 'foo' or '@*' must use pattern-based matching.
            if (exceptParts.All(p => p.Contains("::") || p.Contains('/')))
                return CompileSetPattern(trimmed);

            var first = CompileSinglePattern(exceptParts[0]);
            var rest = exceptParts[1..].Select(p => CompileSinglePattern(p)).ToArray();
            return (item, ctx) =>
            {
                if (!first(item, ctx)) return false;
                foreach (var r in rest)
                    if (r(item, ctx)) return false;
                return true;
            };
        }

        // Handle top-level intersect
        var intersectParts = SplitTopLevel(trimmed, "intersect");
        if (intersectParts.Length >= 2)
        {
            // Use XPath-from-root only when all branches are path expressions or axis steps.
            // Simple patterns like 'foo' or '@*' must use pattern-based matching.
            if (intersectParts.All(p => p.Contains("::") || p.Contains('/')))
                return CompileSetPattern(trimmed);

            var first = CompileSinglePattern(intersectParts[0]);
            var rest = intersectParts[1..].Select(p => CompileSinglePattern(p)).ToArray();
            return (item, ctx) =>
            {
                if (!first(item, ctx)) return false;
                foreach (var r in rest)
                    if (!r(item, ctx)) return false;
                return true;
            };
        }

        // Handle // prefix (e.g. //foo, //foo[bar]) — matches any descendant
        // Per XSLT spec, //P only matches nodes in a tree rooted at a document node.
        if (trimmed.StartsWith("//"))
        {
            var innerPattern = CompileSinglePattern(trimmed[2..].Trim());
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                // Walk to the root; //P only matches if root is a document node
                var root = node;
                while (root.Parent != null)
                    root = root.Parent;
                if (root.NodeKind != XdmNodeKind.Document)
                    return false;
                return innerPattern(item, ctx);
            };
        }
        // Handle / prefix (e.g. /doc) — matches from the root
        else if (trimmed.StartsWith('/'))
        {
            trimmed = trimmed[1..].Trim();
            if (string.IsNullOrEmpty(trimmed))
                return (item, ctx) =>
                {
                    var node = AsNode(item);
                    if (node == null) return false;
                    return node.NodeKind == XdmNodeKind.Document;
                };

            // For multi-step rooted paths like /*/* or /doc/foo, the document-root check
            // must apply to the first step (the root element), not the candidate node.
            bool isMultiStep = false;
            int braceDepth = 0;
            for (int pi = 0; pi < trimmed.Length; pi++)
            {
                if (trimmed[pi] == 'Q' && pi + 1 < trimmed.Length && trimmed[pi + 1] == '{')
                {
                    braceDepth++;
                    pi++;
                }
                else if (braceDepth > 0 && trimmed[pi] == '}')
                {
                    braceDepth--;
                }
                else if (braceDepth == 0 && trimmed[pi] == '/')
                {
                    isMultiStep = true;
                    break;
                }
            }

            if (isMultiStep)
            {
                return CompilePathPattern(trimmed, rootAtDocument: true);
            }

            var inner = CompileSinglePattern(trimmed);
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return inner(item, ctx) && node.Parent?.NodeKind == XdmNodeKind.Document;
            };
        }

        // Variable reference pattern: $var or $var/path
        if (trimmed.StartsWith('$'))
        {
            return CompileVariablePattern(trimmed);
        }

        // Document/root pattern with path: doc('uri')/foo, root()/foo
        if ((trimmed.StartsWith("doc(") || trimmed.StartsWith("document(") || trimmed.StartsWith("root(")) && trimmed.Contains('/'))
        {
            return CompileDocumentPathPattern(trimmed);
        }

        // Simple document pattern: doc('uri') or document('uri')
        if (trimmed.StartsWith("doc(") && trimmed.EndsWith(')'))
        {
            var docUri = TryGetStringLiteral(ExtractFunctionArg(trimmed));
            if (!string.IsNullOrEmpty(docUri))
            {
                return (item, ctx) =>
                {
                    var node = AsNode(item);
                    if (node == null || node.NodeKind != XdmNodeKind.Document) return false;
                    return MatchesDocumentUri(node, docUri, ctx);
                };
            }
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return node.NodeKind == XdmNodeKind.Document;
            };
        }
        if (trimmed.StartsWith("document(") && trimmed.EndsWith(')'))
        {
            var docUri = TryGetStringLiteral(ExtractFunctionArg(trimmed));
            if (!string.IsNullOrEmpty(docUri))
            {
                return (item, ctx) =>
                {
                    var node = AsNode(item);
                    if (node == null || node.NodeKind != XdmNodeKind.Document) return false;
                    return MatchesDocumentUri(node, docUri, ctx);
                };
            }
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return node.NodeKind == XdmNodeKind.Document;
            };
        }

        // Parenthesized pattern: (pattern) or (pattern)[predicate]
        if (trimmed.StartsWith('('))
        {
            int closeParen = FindMatchingParen(trimmed, 0);
            if (closeParen > 0)
            {
                string inside = trimmed[1..closeParen].Trim();
                string after = closeParen + 1 < trimmed.Length ? trimmed[(closeParen + 1)..].Trim() : "";

                var innerPattern = _compatibility >= XPathCompatibility.XPath40
                    ? Compile(inside, _defaultElementNamespace, _typedMode, _namespaces, _compatibility,
                        _itemTypeAliases, _namedRecordTypeNames)
                    : Compile(inside);

                if (string.IsNullOrEmpty(after))
                    return _compatibility >= XPathCompatibility.XPath40
                        ? (item, ctx) => item.IsNode && innerPattern(item, ctx)
                        : innerPattern;

                // After the parens there might be predicates or path continuations
                if (after.StartsWith('['))
                {
                    return CompileParenthesizedWithPredicates(innerPattern, inside, after);
                }
                if (after.StartsWith('/'))
                {
                    // (pattern)/step — combine as path
                    return CompilePathPattern(trimmed);
                }
            }
        }

        // Attribute pattern with predicates (@*[pred], @name[pred]): route through
        // CompilePredicatePattern so the predicate is evaluated against the candidate.
        if (trimmed.StartsWith('@') && FindPredicateStart(trimmed) >= 0)
        {
            return CompilePredicatePattern(trimmed);
        }

        // Attribute pattern: @name or @*
        if (trimmed.StartsWith('@'))
        {
            var name = trimmed[1..].Trim();
            return CompileAttributePattern(name);
        }

        // Path pattern: a/b or a/b/c (but not axis steps handled above)
        // Ignore '/' inside Q{uri} braces.
        bool hasPathSlash = false;
        int qDepth = 0;
        for (int pi = 0; pi < trimmed.Length; pi++)
        {
            if (trimmed[pi] == 'Q' && pi + 1 < trimmed.Length && trimmed[pi + 1] == '{')
            {
                qDepth++;
                pi++;
            }
            else if (qDepth > 0 && trimmed[pi] == '}')
            {
                qDepth--;
            }
            else if (qDepth == 0 && trimmed[pi] == '/')
            {
                hasPathSlash = true;
                break;
            }
        }
        if (_compatibility >= XPathCompatibility.XPath40)
            hasPathSlash = HasPatternPathOperator(trimmed);
        if (hasPathSlash && !trimmed.StartsWith("processing-instruction"))
        {
            return CompilePathPattern(trimmed);
        }

        // Predicate pattern: foo[bar]
        if (FindPredicateStart(trimmed) >= 0)
        {
            return CompilePredicatePattern(trimmed);
        }

        // Simple element name or wildcard, or axis step without predicate
        return CompileElementPattern(trimmed);
    }

    /// <summary>
    /// Compiles a variable reference pattern ($var) or variable path pattern ($var/foo).
    /// </summary>
    private PatternPredicate CompileVariablePattern(string pattern)
    {
        // Check if there's a path after the variable name
        int slashIdx = FindTopLevelSlash(pattern);
        if (slashIdx > 0)
        {
            string varPart = pattern[..slashIdx].Trim();
            string pathPart = pattern[slashIdx..].Trim();

            // Compile the path part as a pattern that would match from the variable's nodes
            var pathPattern = CompileSinglePattern(pathPart.TrimStart('/'));

            // Evaluate: match node N if N matches pathPattern and some node in $var is an ancestor
            var compiledVarCheck = CompilePatternXPath(varPart);
            bool isDescendant = pathPart.StartsWith("//");
            string pathNoSlash = pathPart.TrimStart('/').TrimStart('/');
            var pathCompiled = CompilePatternXPath(pathNoSlash);

            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                try
                {
                    var varResult = compiledVarCheck.Evaluate(ctx);
                    if (!varResult.IsSequence && !varResult.IsNode)
                        return false;

                    // Check if node matches the path pattern
                    if (!pathPattern(item, ctx))
                        return false;

                    // Check if any node in the variable is an ancestor (or self) of node
                    if (varResult.IsSequence && varResult.SequenceValue != null)
                    {
                        foreach (var seqItem in XdmSequence.FromSource(varResult.SequenceValue))
                        {
                            if (!seqItem.IsNode || seqItem.NodeValue is not IXdmNode vn)
                                continue;
                            if (isDescendant)
                            {
                                var current = node;
                                while (current != null)
                                {
                                    if (current.IsSameNode(vn))
                                        return true;
                                    current = current.Parent;
                                }
                            }
                            else
                            {
                                if (node.Parent != null && node.Parent.IsSameNode(vn))
                                    return true;
                            }
                        }
                    }
                    else if (varResult.IsNode && varResult.NodeValue is IXdmNode vn2)
                    {
                        if (isDescendant)
                        {
                            var current = node;
                            while (current != null)
                            {
                                if (current.IsSameNode(vn2))
                                    return true;
                                current = current.Parent;
                            }
                        }
                        else
                        {
                            if (node.Parent != null && node.Parent.IsSameNode(vn2))
                                return true;
                        }
                    }
                    return false;
                }
                catch (Exception ex)
                {
                    if (IsStaticError(ex)) throw;
                    return false;
                }
            };
        }

        // Simple variable reference: $var
        var compiledVar = CompilePatternXPath(pattern);
        return (item, ctx) =>
        {
            var node = AsNode(item);
            if (node == null) return false;
            try
            {
                var result = compiledVar.Evaluate(ctx);
                if (result.IsSequence && result.SequenceValue != null)
                {
                    foreach (var seqItem in XdmSequence.FromSource(result.SequenceValue))
                    {
                        if (seqItem.IsNode && seqItem.NodeValue is IXdmNode n && n.IsSameNode(node))
                            return true;
                    }
                }
                else if (result.IsNode && result.NodeValue is IXdmNode n2 && n2.IsSameNode(node))
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                if (IsStaticError(ex)) throw;
                return false;
            }
        };
    }

    /// <summary>
    /// Compiles a document pattern with a path: doc('uri')/foo or doc('uri')//foo.
    /// </summary>
    private PatternPredicate CompileDocumentPathPattern(string pattern)
    {
        // Find the first / that separates the doc() call from the path
        int parenDepth = 0;
        int slashIdx = -1;
        for (int i = 0; i < pattern.Length; i++)
        {
            char c = pattern[i];
            if (c == '(') parenDepth++;
            else if (c == ')') parenDepth--;
            else if (c == '/' && parenDepth == 0)
            {
                slashIdx = i;
                break;
            }
        }

        if (slashIdx < 0)
        {
            // No slash found — simple document or root pattern
            if (pattern.StartsWith("root("))
            {
                return (item, ctx) =>
                {
                    var node = AsNode(item);
                    if (node == null) return false;
                    var current = node;
                    while (current.Parent != null) current = current.Parent;
                    return current.IsSameNode(node);
                };
            }
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return node.NodeKind == XdmNodeKind.Document;
            };
        }

        string docPart = pattern[..slashIdx].Trim();
        string pathPart = pattern[slashIdx..].Trim();

        // Compile the full path as an XPath expression: (docPart)pathPart
        // This correctly handles multi-step paths, predicates, and descendant axes.
        var fullPathCompiled = CompilePatternXPath($"({docPart}){pathPart}");

        return (item, ctx) =>
        {
            var node = AsNode(item);
            if (node == null) return false;
            var savedItem = ctx.ContextItem;
            var savedPos = ctx.ContextPosition;
            var savedSize = ctx.ContextSize;
            try
            {
                var result = fullPathCompiled.Evaluate(ctx.WithFocus(XdmValue.FromNode(node), 1, 1));
                if (result.Kind == XdmValueKind.Sequence && result.SequenceValue != null)
                {
                    foreach (var seqItem in XdmSequence.FromSource(result.SequenceValue))
                    {
                        if (seqItem.IsNode && seqItem.NodeValue is IXdmNode n && n.IsSameNode(node))
                            return true;
                    }
                }
                else if (result.IsNode && result.NodeValue is IXdmNode n2 && n2.IsSameNode(node))
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                if (IsStaticError(ex)) throw;
                return false;
            }
            finally
            {
                ctx.WithFocus(savedItem, savedPos, savedSize);
            }
        };
    }

    /// <summary>
    /// Compiles a top-level except or intersect pattern as an XPath expression
    /// evaluated from the root of the candidate node.
    /// </summary>
    private PatternPredicate CompileSetPattern(string pattern)
    {
        var compiled = CompilePatternXPath(pattern);
        return (item, ctx) =>
        {
            var node = AsNode(item);
            if (node == null) return false;
            try
            {
                var root = node;
                while (root.Parent != null)
                    root = root.Parent;
                var result = compiled.Evaluate(ctx.WithFocus(XdmValue.FromNode(root), 1, 1));
                if (result.Kind == XdmValueKind.Sequence && result.SequenceValue != null)
                {
                    foreach (var seqItem in XdmSequence.FromSource(result.SequenceValue))
                    {
                        if (seqItem.IsNode && seqItem.NodeValue is IXdmNode n && n.IsSameNode(node))
                            return true;
                    }
                }
                else if (result.IsNode && result.NodeValue is IXdmNode n2 && n2.IsSameNode(node))
                {
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                if (IsStaticError(ex)) throw;
                return false;
            }
        };
    }

    /// <summary>
    /// Compiles a simple path pattern like <c>a/b</c> or <c>a/b/c</c>.
    /// The last step is the node test; preceding steps are ancestor checks.
    /// </summary>
    private PatternPredicate CompilePathPattern(string pattern, bool rootAtDocument = false)
    {
        var steps = new List<string>();
        var separators = new List<bool>(); // true = /, false = //
        int i = 0;

        while (i < pattern.Length)
        {
            bool isDirect = true;
            if (i > 0)
            {
                if (i + 1 < pattern.Length && pattern[i] == '/' && pattern[i + 1] == '/')
                {
                    isDirect = false;
                    i += 2;
                }
                else if (pattern[i] == '/')
                {
                    isDirect = true;
                    i++;
                }
            }

            int start = i;
            int depth = 0;
            int qBraceDepth = 0;
            while (i < pattern.Length)
            {
                char c = pattern[i];
                if (qBraceDepth > 0)
                {
                    if (c == '}') qBraceDepth--;
                    i++;
                    continue;
                }
                if (c == 'Q' && i + 1 < pattern.Length && pattern[i + 1] == '{')
                {
                    qBraceDepth++;
                    i += 2;
                    continue;
                }
                if (c == '(' || c == '[') depth++;
                else if (c == ')' || c == ']') depth--;
                else if (depth == 0 && (pattern[i] == '/' || (i + 1 < pattern.Length && pattern[i] == '/' && pattern[i + 1] == '/')))
                    break;
                i++;
            }

            var step = pattern[start..i].Trim();
            if (!string.IsNullOrEmpty(step))
            {
                if (steps.Count > 0)
                    separators.Add(isDirect);
                steps.Add(step);
            }
        }

        if (steps.Count == 0)
            return (item, ctx) => false;

        // Expand parenthesized union steps into multiple path patterns.
        // For example, x/(child::a|descendant::b) becomes x/child::a | x/descendant::b.
        for (int sIdx = 0; sIdx < steps.Count; sIdx++)
        {
            var step = steps[sIdx];
            if (step.StartsWith('('))
            {
                int closeParen = FindMatchingParen(step, 0);
                if (closeParen == step.Length - 1)
                {
                    string inside = step[1..closeParen].Trim();
                    var unionBranches = SplitTopLevel(inside, '|');
                    if (unionBranches.Length > 1)
                    {
                        var expandedPatterns = new List<string>();
                        foreach (var branch in unionBranches)
                        {
                            var newSteps = new List<string>(steps);
                            newSteps[sIdx] = branch.Trim();
                            var sb = new System.Text.StringBuilder();
                            for (int ns = 0; ns < newSteps.Count; ns++)
                            {
                                if (ns > 0)
                                    sb.Append(separators[ns - 1] ? "/" : "//");
                                sb.Append(newSteps[ns]);
                            }
                            expandedPatterns.Add(sb.ToString());
                        }
                        var compiledBranches = expandedPatterns.Select(p => CompileSinglePattern(p)).ToArray();
                        return (item, ctx) => compiledBranches.Any(b => b(item, ctx));
                    }
                }
            }
        }

        // For steps containing except/intersect (e.g., x/(descendant::a except child::a)),
        // compile the entire path as XPath and evaluate from the root.
        for (int sIdx = 0; sIdx < steps.Count; sIdx++)
        {
            var step = steps[sIdx];
            if (step.StartsWith('('))
            {
                int closeParen = FindMatchingParen(step, 0);
                if (closeParen == step.Length - 1)
                {
                    string inside = step[1..closeParen].Trim();
                    var exceptBranches = SplitTopLevel(inside, "except");
                    var intersectBranches = SplitTopLevel(inside, "intersect");
                    if (exceptBranches.Length >= 2 || intersectBranches.Length >= 2)
                    {
                        var sb = new System.Text.StringBuilder();
                        for (int ns = 0; ns < steps.Count; ns++)
                        {
                            if (ns > 0)
                                sb.Append(separators[ns - 1] ? "/" : "//");
                            sb.Append(steps[ns]);
                        }
                        var compiledPath = CompilePatternXPath(sb.ToString());

                        // For parentless nodes, the first step may need child-or-top semantics.
                        // Compile a self-axis variant and union the results.
                        XPath31Expression? compiledSelfPath = null;
                        if (steps.Count > 0 && !steps[0].Contains("::"))
                        {
                            var selfSb = new System.Text.StringBuilder();
                            selfSb.Append("self::").Append(steps[0]);
                            for (int ns = 1; ns < steps.Count; ns++)
                            {
                                selfSb.Append(separators[ns - 1] ? "/" : "//");
                                selfSb.Append(steps[ns]);
                            }
                            compiledSelfPath = CompilePatternXPath(selfSb.ToString());
                        }

                        return (item, ctx) =>
                        {
                            var node = AsNode(item);
                            if (node == null) return false;
                            try
                            {
                                var root = node;
                                while (root.Parent != null)
                                    root = root.Parent;
                                var result = compiledPath.Evaluate(ctx.WithFocus(XdmValue.FromNode(root), 1, 1));
                                if (result.Kind == XdmValueKind.Sequence && result.SequenceValue != null)
                                {
                                    foreach (var seqItem in XdmSequence.FromSource(result.SequenceValue))
                                    {
                                        if (seqItem.IsNode && seqItem.NodeValue is IXdmNode n && n.IsSameNode(node))
                                            return true;
                                    }
                                }
                                else if (result.IsNode && result.NodeValue is IXdmNode n2 && n2.IsSameNode(node))
                                {
                                    return true;
                                }

                                if (compiledSelfPath != null)
                                {
                                    var selfResult = compiledSelfPath.Evaluate(ctx.WithFocus(XdmValue.FromNode(root), 1, 1));
                                    if (selfResult.Kind == XdmValueKind.Sequence && selfResult.SequenceValue != null)
                                    {
                                        foreach (var seqItem in XdmSequence.FromSource(selfResult.SequenceValue))
                                        {
                                            if (seqItem.IsNode && seqItem.NodeValue is IXdmNode n && n.IsSameNode(node))
                                                return true;
                                        }
                                    }
                                    else if (selfResult.IsNode && selfResult.NodeValue is IXdmNode n2 && n2.IsSameNode(node))
                                    {
                                        return true;
                                    }
                                }
                                return false;
                            }
                            catch (Exception ex)
                            {
                                if (IsStaticError(ex)) throw;
                                return false;
                            }
                        };
                    }
                }
            }
        }

        // Determine the effective axis of each step so we can handle descendant::
        // correctly in ancestor checks (a/descendant::b should match deep descendants).
        var stepAxes = new List<string>();
        foreach (var step in steps)
        {
            if (step.Contains("::"))
            {
                int axisEnd = step.IndexOf("::");
                stepAxes.Add(step[..axisEnd].Trim().ToLowerInvariant());
            }
            else
            {
                stepAxes.Add("child");
            }
        }

        string lastStepStr = steps[^1];
        bool lastStepHasPredicate = FindPredicateStart(lastStepStr) >= 0;

        // Simple element/attribute predicates are handled correctly by CompilePredicatePattern
        // because it evaluates child::base[pred] from the parent. Axis steps and other
        // complex patterns need axis-context evaluation for correct position()/last() semantics.
        bool isSimpleStep = !lastStepStr.Contains("::") && !lastStepStr.StartsWith('$') && !lastStepStr.StartsWith('(');
        bool lastStepNeedsAxisContext = lastStepHasPredicate && !isSimpleStep;

        XPath31Expression? lastStepAxisExpr = null;
        PatternPredicate? lastStepPredicate = null;
        XPath31Expression? lastStepSetExpr = null;

        // Detect parenthesized except/intersect in the last step.
        // These must be evaluated from the matching ancestor context, not the candidate.
        if (lastStepStr.StartsWith('('))
        {
            int closeParen = FindMatchingParen(lastStepStr, 0);
            if (closeParen == lastStepStr.Length - 1)
            {
                string inside = lastStepStr[1..closeParen].Trim();
                var exceptBranches = SplitTopLevel(inside, "except");
                var intersectBranches = SplitTopLevel(inside, "intersect");
                if (exceptBranches.Length >= 2 || intersectBranches.Length >= 2)
                {
                    lastStepSetExpr = CompilePatternXPath(inside);
                }
            }
        }

        if (lastStepSetExpr == null && lastStepNeedsAxisContext && lastStepStr.Contains("::"))
        {
            lastStepAxisExpr = CompilePatternXPath(lastStepStr);
        }
        else if (lastStepSetExpr == null && lastStepHasPredicate)
        {
            lastStepPredicate = CompilePredicatePattern(lastStepStr);
        }
        else if (lastStepSetExpr == null)
        {
            lastStepPredicate = CompileSinglePattern(lastStepStr);
        }

        // Compile ancestor checks for preceding steps
        var ancestorTests = new List<PatternPredicate>();
        for (int s = steps.Count - 2; s >= 0; s--)
        {
            if (FindPredicateStart(steps[s]) >= 0)
                ancestorTests.Add(CompilePredicatePattern(steps[s]));
            else
                ancestorTests.Add(CompileSinglePattern(steps[s]));
        }

        return (item, ctx) =>
        {
            var node = AsNode(item);
            if (node == null) return false;
            // For simple or non-predicated last steps, check before ancestor walk
            if (lastStepPredicate != null && !lastStepPredicate(item, ctx))
                return false;

            // For descendant-or-self and self axes, the candidate itself may serve as
            // the matching node for preceding steps (e.g., x/descendant-or-self::x).
            bool lastAxisIncludesSelf = stepAxes.Count > 0 &&
                (stepAxes[^1] == "descendant-or-self" || stepAxes[^1] == "self");
            var current = lastAxisIncludesSelf ? node : node.Parent;
            IXdmNode? stepContextNode = null;

            for (int s = steps.Count - 2; s >= 0; s--)
            {
                var test = ancestorTests[steps.Count - 2 - s];
                // If the next step uses descendant or descendant-or-self axis,
                // treat a / separator as non-direct so we walk up the tree.
                bool direct = separators[s]
                    && stepAxes[s + 1] != "descendant"
                    && stepAxes[s + 1] != "descendant-or-self";

                if (direct)
                {
                    if (current == null || !test(XdmValue.FromNode(current), ctx))
                        return false;
                    if (s == steps.Count - 2)
                        stepContextNode = current;
                    current = current.Parent;
                }
                else
                {
                    bool found = false;
                    while (current != null)
                    {
                        if (test(XdmValue.FromNode(current), ctx))
                        {
                            found = true;
                            if (s == steps.Count - 2)
                                stepContextNode = current;
                            current = current.Parent;
                            break;
                        }
                        current = current.Parent;
                    }
                    if (!found)
                        return false;
                }
            }

            // For axis-step predicates, evaluate the last step XPath from the matching
            // ancestor context so position() and last() reflect the correct list position.
            if (lastStepAxisExpr != null)
            {
                var savedItem = ctx.ContextItem;
                var savedPos = ctx.ContextPosition;
                var savedSize = ctx.ContextSize;
                try
                {
                    var focusNode = stepContextNode ?? node.Parent;
                    if (focusNode == null)
                        return false;

                    var result = lastStepAxisExpr.Evaluate(ctx.WithFocus(XdmValue.FromNode(focusNode), 1, 1));
                    if (result.Kind == XdmValueKind.Sequence && result.SequenceValue != null)
                    {
                        foreach (var seqItem in XdmSequence.FromSource(result.SequenceValue))
                        {
                            if (seqItem.IsNode && seqItem.NodeValue is IXdmNode n && n.IsSameNode(node))
                                return true;
                        }
                        return false;
                    }
                    else if (result.IsNode && result.NodeValue is IXdmNode n2 && n2.IsSameNode(node))
                    {
                        return true;
                    }
                    return false;
                }
                catch (Exception ex)
                {
                    if (IsStaticError(ex)) throw;
                    return false;
                }
                finally
                {
                    ctx.WithFocus(savedItem, savedPos, savedSize);
                }
            }

            // For parenthesized except/intersect in the last step, evaluate the set
            // expression from the matching ancestor context.
            if (lastStepSetExpr != null)
            {
                var savedItem = ctx.ContextItem;
                var savedPos = ctx.ContextPosition;
                var savedSize = ctx.ContextSize;
                try
                {
                    var focusNode = stepContextNode ?? node.Parent;
                    if (focusNode == null)
                        return false;

                    var result = lastStepSetExpr.Evaluate(ctx.WithFocus(XdmValue.FromNode(focusNode), 1, 1));
                    if (result.Kind == XdmValueKind.Sequence && result.SequenceValue != null)
                    {
                        foreach (var seqItem in XdmSequence.FromSource(result.SequenceValue))
                        {
                            if (seqItem.IsNode && seqItem.NodeValue is IXdmNode n && n.IsSameNode(node))
                                return true;
                        }
                        return false;
                    }
                    else if (result.IsNode && result.NodeValue is IXdmNode n2 && n2.IsSameNode(node))
                    {
                        return true;
                    }
                    return false;
                }
                catch (Exception ex)
                {
                    if (IsStaticError(ex)) throw;
                    return false;
                }
                finally
                {
                    ctx.WithFocus(savedItem, savedPos, savedSize);
                }
            }

            if (rootAtDocument)
            {
                if (separators.Count > 0 && !separators[0])
                {
                    // Indirect path after first step (//): any matching ancestor is fine,
                    // but the root element must match the first step.
                    var root = node;
                    while (root.Parent != null)
                        root = root.Parent;
                    IXdmNode? rootElement = null;
                    foreach (var child in root.Axis(XdmAxis.Child))
                    {
                        if (child.IsNode)
                        {
                            rootElement = child.NodeValue;
                            break;
                        }
                    }
                    if (rootElement == null)
                        return false;

                    var firstStepTest = steps.Count > 1 ? ancestorTests[^1] : lastStepPredicate;
                    if (firstStepTest == null || !firstStepTest(XdmValue.FromNode(rootElement), ctx))
                        return false;
                }
                else
                {
                    // Direct path after first step (/): the matched ancestor must be the
                    // root element. After walking ancestors, 'current' is the parent of the
                    // node that matched the first step, which must be the document node.
                    if (current?.NodeKind != XdmNodeKind.Document)
                        return false;
                }
            }

            return true;
        };
    }

    private PatternPredicate CompileElementPattern(string name)
    {
        // Handle axis steps: axis::nodetest
        var axisText = _compatibility >= XPathCompatibility.XPath40 ? MaskEQNameUris(name) : name;
        if (axisText.Contains("::", StringComparison.Ordinal))
        {
            int colonIdx = axisText.IndexOf("::", StringComparison.Ordinal);
            string axis = name[..colonIdx].Trim();
            string nodeTest = name[(colonIdx + 2)..].Trim();
            return CompileAxisStep(axis, nodeTest);
        }

        if (name == "*")
        {
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return node.NodeKind == XdmNodeKind.Element;
            };
        }

        if (name.StartsWith("*:"))
        {
            string local = name[2..];
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return node.NodeKind == XdmNodeKind.Element && node.LocalName == local;
            };
        }

        if (name == "node()")
        {
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return node.NodeKind is not XdmNodeKind.Document
                    and not XdmNodeKind.Attribute
                    and not XdmNodeKind.Namespace;
            };
        }

        if (name == "namespace-node()")
        {
            // A namespace-node() pattern is equivalent to the axis step
            // namespace::namespace-node(): it matches any namespace node.
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return node.NodeKind == XdmNodeKind.Namespace;
            };
        }

        if (name == ".")
        {
            // match="." matches any item (node or atomic) in XSLT 3.0.
            return (item, ctx) => true;
        }

        if (name == "text()")
        {
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return node.NodeKind == XdmNodeKind.Text;
            };
        }

        if (name == "comment()")
        {
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return node.NodeKind == XdmNodeKind.Comment;
            };
        }

        if (name == "processing-instruction()")
        {
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return node.NodeKind == XdmNodeKind.ProcessingInstruction;
            };
        }

        if (name.StartsWith("document-node(") && name.EndsWith(')'))
        {
            var arg = ExtractFunctionArg(name);
            if (string.IsNullOrEmpty(arg))
            {
                return (item, ctx) =>
                {
                    var node = AsNode(item);
                    if (node == null) return false;
                    return node.NodeKind == XdmNodeKind.Document;
                };
            }

            var elementTest = CompileElementPattern(arg);
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null || node.NodeKind != XdmNodeKind.Document)
                    return false;

                // XPath 3.1 §2.5.4: the document node must have exactly one element child,
                // no text-node children, and that element must satisfy the inner test
                // (import-schema-055, validation-1401).
                IXdmNode? root = null;
                int elementCount = 0;
                foreach (var child in node.Children())
                {
                    if (child.NodeValue?.NodeKind == XdmNodeKind.Element)
                    {
                        elementCount++;
                        root ??= child.NodeValue;
                    }
                    else if (child.NodeValue?.NodeKind == XdmNodeKind.Text)
                    {
                        return false;
                    }
                }
                if (elementCount != 1 || root is null)
                    return false;
                return elementTest(XdmValue.FromNode(root), ctx);
            };
        }

        if (name.StartsWith("processing-instruction("))
        {
            // processing-instruction(name) or processing-instruction('name')
            var piName = ExtractFunctionArg(name);
            if (string.IsNullOrEmpty(piName))
                return (item, ctx) =>
                {
                    var node = AsNode(item);
                    if (node == null) return false;
                    return node.NodeKind == XdmNodeKind.ProcessingInstruction;
                };
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return node.NodeKind == XdmNodeKind.ProcessingInstruction &&
                node.LocalName == piName.Trim('\'');
            };
        }

        if (name == "root()")
        {
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                var current = node;
                while (current.Parent != null) current = current.Parent;
                return current.IsSameNode(node);
            };
        }

        if (name == "element()")
        {
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return node.NodeKind == XdmNodeKind.Element;
            };
        }

        if (name.StartsWith("element("))
        {
            var arg = ExtractFunctionArg(name);
            // element(name) or element(QName); may include a type argument: element(name, type).
            // The type argument is enforced only in schema-aware stylesheets (REQ-105);
            // without a schema set the pattern matches by name/kind only, as before.
            var (nameArg, typeArg) = SplitKindTestArgs(arg);
            var typeCheck = CompileKindTestTypeCheck(typeArg, isElement: true);
            if (string.IsNullOrEmpty(nameArg) || nameArg == "*")
                return (item, ctx) =>
                {
                    var node = AsNode(item);
                    if (node == null) return false;
                    return node.NodeKind == XdmNodeKind.Element && (typeCheck is null || typeCheck(node));
                };
            if (_compatibility >= XPathCompatibility.XPath40)
            {
                var nameCheck = CompileKindTestNameCheck(nameArg, isElement: true);
                return (item, ctx) => item.IsNode && item.NodeValue.NodeKind == XdmNodeKind.Element
                    && nameCheck(item.NodeValue) && (typeCheck is null || typeCheck(item.NodeValue));
            }
            var (ns, local) = ParseQName(nameArg);
            if (string.IsNullOrEmpty(ns))
            {
                var defaultNs = _defaultElementNamespace ?? "";
                return (item, ctx) =>
                {
                    var node = AsNode(item);
                    if (node == null) return false;
                    return node.NodeKind == XdmNodeKind.Element && node.NamespaceUri == defaultNs && node.LocalName == local && (typeCheck is null || typeCheck(node));
                };
            }
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return node.NodeKind == XdmNodeKind.Element && node.NamespaceUri == ns && node.LocalName == local && (typeCheck is null || typeCheck(node));
            };
        }

        if (name.StartsWith("schema-element("))
        {
            var arg = ExtractFunctionArg(name);
            var (declNs, declLocal) = ParseQName(arg);
            if (string.IsNullOrEmpty(declNs))
                declNs = _defaultElementNamespace ?? "";
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return MatchesSchemaElement(node, declNs, declLocal);
            };
        }

        if (name.StartsWith("schema-attribute("))
        {
            var arg = ExtractFunctionArg(name);
            var (declNs, declLocal) = ParseQName(arg);
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return MatchesSchemaAttribute(node, declNs, declLocal);
            };
        }

        if (name == "attribute()")
        {
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return node.NodeKind == XdmNodeKind.Attribute;
            };
        }

        if (name.StartsWith("attribute("))
        {
            var arg = ExtractFunctionArg(name);
            // attribute(name) or attribute(QName); may include a type argument: attribute(name, type).
            // The type argument is enforced only in schema-aware stylesheets (REQ-105);
            // without a schema set the pattern matches by name/kind only, as before.
            var (nameArg, typeArg) = SplitKindTestArgs(arg);
            var typeCheck = CompileKindTestTypeCheck(typeArg, isElement: false);
            if (string.IsNullOrEmpty(nameArg) || nameArg == "*")
                return (item, ctx) =>
                {
                    var node = AsNode(item);
                    if (node == null) return false;
                    return node.NodeKind == XdmNodeKind.Attribute && (typeCheck is null || typeCheck(node));
                };
            if (_compatibility >= XPathCompatibility.XPath40)
            {
                var nameCheck = CompileKindTestNameCheck(nameArg, isElement: false);
                return (item, ctx) => item.IsNode && item.NodeValue.NodeKind == XdmNodeKind.Attribute
                    && nameCheck(item.NodeValue) && (typeCheck is null || typeCheck(item.NodeValue));
            }
            var (ns, local) = ParseQName(nameArg);
            if (string.IsNullOrEmpty(ns))
            {
                if (typeCheck is not null)
                {
                    // Typed form: an unprefixed attribute name is in no namespace
                    // (the xpath-default-namespace does not apply — match-205/206/207).
                    return (item, ctx) =>
                    {
                        var node = AsNode(item);
                        if (node == null) return false;
                        return node.NodeKind == XdmNodeKind.Attribute && node.NamespaceUri.Length == 0 && node.LocalName == local && typeCheck(node);
                    };
                }
                return (item, ctx) =>
                {
                    var node = AsNode(item);
                    if (node == null) return false;
                    return node.NodeKind == XdmNodeKind.Attribute && node.LocalName == local;
                };
            }
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return node.NodeKind == XdmNodeKind.Attribute && node.NamespaceUri == ns && node.LocalName == local && (typeCheck is null || typeCheck(node));
            };
        }

        // id('x', $y) pattern — id() may return multiple nodes; check membership.
        if (name.StartsWith("id(") && name.EndsWith(')'))
        {
            var compiledId = CompilePatternXPath(name);
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                try
                {
                    var result = compiledId.Evaluate(ctx.WithFocus(XdmValue.FromNode(node), 1, 1));
                    if (result.IsSequence && result.SequenceValue != null)
                    {
                        foreach (var seqItem in XdmSequence.FromSource(result.SequenceValue))
                        {
                            if (seqItem.IsNode && seqItem.NodeValue is IXdmNode n && n.IsSameNode(node))
                                return true;
                        }
                    }
                    else if (result.IsNode && result.NodeValue is IXdmNode n2 && n2.IsSameNode(node))
                    {
                        return true;
                    }
                    return false;
                }
                catch (Exception ex)
                {
                    if (IsStaticError(ex)) throw;
                    return false;
                }
            };
        }

        // element-with-id('x') / element-with-id('x', $doc) pattern (XSLT 3.0 §5.5.3) —
        // equivalent to id() but only matches element nodes; check membership.
        if (name.StartsWith("element-with-id(") && name.EndsWith(')'))
        {
            var compiledElementWithId = CompilePatternXPath(name);
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null || node.NodeKind != XdmNodeKind.Element) return false;
                try
                {
                    var result = compiledElementWithId.Evaluate(ctx.WithFocus(XdmValue.FromNode(node), 1, 1));
                    if (result.IsSequence && result.SequenceValue != null)
                    {
                        foreach (var seqItem in XdmSequence.FromSource(result.SequenceValue))
                        {
                            if (seqItem.IsNode && seqItem.NodeValue is IXdmNode n && n.IsSameNode(node))
                                return true;
                        }
                    }
                    else if (result.IsNode && result.NodeValue is IXdmNode n2 && n2.IsSameNode(node))
                    {
                        return true;
                    }
                    return false;
                }
                catch (Exception ex)
                {
                    if (IsStaticError(ex)) throw;
                    return false;
                }
            };
        }

        // key('k', 'v') pattern — key() may return multiple nodes; check membership.
        if (name.StartsWith("key(") && name.EndsWith(')'))
        {
            var compiledKey = CompilePatternXPath(name);
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                try
                {
                    var result = compiledKey.Evaluate(ctx.WithFocus(XdmValue.FromNode(node), 1, 1));
                    if (result.IsSequence && result.SequenceValue != null)
                    {
                        foreach (var seqItem in XdmSequence.FromSource(result.SequenceValue))
                        {
                            if (seqItem.IsNode && seqItem.NodeValue is IXdmNode n && n.IsSameNode(node))
                                return true;
                        }
                    }
                    else if (result.IsNode && result.NodeValue is IXdmNode n2 && n2.IsSameNode(node))
                    {
                        return true;
                    }
                    return false;
                }
                catch (Exception ex)
                {
                    if (IsStaticError(ex)) throw;
                    return false;
                }
            };
        }

        // Qualified name: prefix:local or Q{uri}local
        var (nsUri, localName) = ParseQName(name);

        // XSLT 3.0 §5.5.3: in a strict typed mode a plain QName at the top level of the
        // pattern (or union branch, or after a leading / or //) is interpreted as
        // schema-element(QName). In a lax mode the same applies, except that a QName with
        // no element declaration in the schema set falls back to plain name matching.
        if (localName != "*" && _typedMode is ModeTyped.Strict or ModeTyped.Lax
            && _validationContext?.SchemaSet is not null)
        {
            var schemaNs = string.IsNullOrEmpty(nsUri) ? (_defaultElementNamespace ?? "") : nsUri;
            var hasDeclaration = _validationContext.GetSchemaElement(schemaNs, localName) is not null;
            if (_typedMode == ModeTyped.Strict || hasDeclaration)
            {
                return (item, ctx) =>
                {
                    var node = AsNode(item);
                    return node != null && MatchesSchemaElement(node, schemaNs, localName);
                };
            }
        }

        if (string.IsNullOrEmpty(nsUri))
        {
            var defaultNs = _defaultElementNamespace ?? "";
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return node.NodeKind == XdmNodeKind.Element &&
                node.LocalName == localName &&
                node.NamespaceUri == defaultNs;
            };
        }

        if (localName == "*")
        {
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return node.NodeKind == XdmNodeKind.Element &&
                node.NamespaceUri == nsUri;
            };
        }

        return (item, ctx) =>
        {
            var node = AsNode(item);
            if (node == null) return false;
            return node.NodeKind == XdmNodeKind.Element &&
            node.NamespaceUri == nsUri &&
            node.LocalName == localName;
        };
    }

    private PatternPredicate CompileAxisStep(string axis, string nodeTest)
    {
        axis = axis.ToLowerInvariant();

        switch (axis)
        {
            case "self":
                var selfTest = CompileNodeTestPredicate(nodeTest);
                return (item, ctx) =>
                {
                    var node = AsNode(item);
                    if (node == null) return false;
                    return selfTest(node);
                };

            case "child":
                var childTest = CompileNodeTestPredicate(nodeTest);
                return (item, ctx) =>
                {
                    var node = AsNode(item);
                    if (node == null) return false;
                    return node.NodeKind != XdmNodeKind.Document
                    && node.NodeKind != XdmNodeKind.Attribute
                    && node.NodeKind != XdmNodeKind.Namespace
                    && childTest(node);
                };

            case "descendant":
                // In a pattern step, descendant::foo matches foo that has an ancestor
                // that matches the preceding step. Since this is used as a step in a path,
                // we just test the node against the node test.
                var descTest = CompileNodeTestPredicate(nodeTest);
                return (item, ctx) =>
                {
                    var node = AsNode(item);
                    if (node == null) return false;
                    return descTest(node);
                };

            case "descendant-or-self":
                var dosTest = CompileNodeTestPredicate(nodeTest);
                return (item, ctx) =>
                {
                    var node = AsNode(item);
                    if (node == null) return false;
                    return dosTest(node);
                };

            case "attribute":
                var attrTest = CompileAttributeNodeTest(nodeTest);
                return (item, ctx) =>
                {
                    var node = AsNode(item);
                    if (node == null) return false;
                    return attrTest(node);
                };

            case "parent":
            case "ancestor":
            case "following-sibling":
            case "preceding-sibling":
            case "following":
            case "preceding":
            case "ancestor-or-self":
                // These axes are not allowed in patterns per XSLT spec,
                // but we compile them as node tests for graceful handling.
                var fallbackTest = CompileNodeTestPredicate(nodeTest);
                return (item, ctx) =>
                {
                    var node = AsNode(item);
                    if (node == null) return false;
                    return fallbackTest(node);
                };

            case "namespace":
                if (nodeTest == "*")
                    return (item, ctx) =>
                    {
                        var node = AsNode(item);
                        if (node == null) return false;
                        return node.NodeKind == XdmNodeKind.Namespace;
                    };
                return (item, ctx) =>
                {
                    var node = AsNode(item);
                    if (node == null) return false;
                    return node.NodeKind == XdmNodeKind.Namespace && node.LocalName == nodeTest;
                };

            default:
                var defaultTest = CompileNodeTestPredicate(nodeTest);
                return (item, ctx) =>
                {
                    var node = AsNode(item);
                    if (node == null) return false;
                    return defaultTest(node);
                };
        }
    }

    private Func<IXdmNode, bool> CompileNodeTestPredicate(string nodeTest)
    {
        if (nodeTest == "*")
            return node => node.NodeKind == XdmNodeKind.Element;
        if (nodeTest.StartsWith("*:"))
        {
            string local = nodeTest[2..];
            return node => node.NodeKind == XdmNodeKind.Element && node.LocalName == local;
        }
        if (nodeTest == "node()")
            return node => true;
        if (nodeTest == "text()")
            return node => node.NodeKind == XdmNodeKind.Text;
        if (nodeTest == "comment()")
            return node => node.NodeKind == XdmNodeKind.Comment;
        if (nodeTest == "processing-instruction()")
            return node => node.NodeKind == XdmNodeKind.ProcessingInstruction;
        if (_compatibility >= XPathCompatibility.XPath40 && nodeTest.StartsWith("processing-instruction(", StringComparison.Ordinal))
        {
            var target = ExtractFunctionArg(nodeTest).Trim();
            if (target.Length >= 2 && target[0] is '\'' or '"')
                target = target[1..^1];
            return node => node.NodeKind == XdmNodeKind.ProcessingInstruction && node.LocalName == target;
        }
        if (nodeTest == "element()")
            return node => node.NodeKind == XdmNodeKind.Element;
        if (nodeTest == "document-node()")
            return node => node.NodeKind == XdmNodeKind.Document;

        if (nodeTest.StartsWith("element("))
        {
            var arg = ExtractFunctionArg(nodeTest);
            // element(name) or element(QName); may include a type argument: element(name, type).
            // The type argument is enforced only in schema-aware stylesheets (REQ-105).
            var (nameArg, typeArg) = SplitKindTestArgs(arg);
            var typeCheck = CompileKindTestTypeCheck(typeArg, isElement: true);
            if (string.IsNullOrEmpty(nameArg) || nameArg == "*")
                return node => node.NodeKind == XdmNodeKind.Element && (typeCheck is null || typeCheck(node));
            if (_compatibility >= XPathCompatibility.XPath40)
            {
                var nameCheck = CompileKindTestNameCheck(nameArg, isElement: true);
                return node => node.NodeKind == XdmNodeKind.Element && nameCheck(node)
                    && (typeCheck is null || typeCheck(node));
            }
            var (ns, local) = ParseQName(nameArg);
            if (string.IsNullOrEmpty(ns))
            {
                var defaultNs = _defaultElementNamespace ?? "";
                return node => node.NodeKind == XdmNodeKind.Element && node.NamespaceUri == defaultNs && node.LocalName == local && (typeCheck is null || typeCheck(node));
            }
            return node => node.NodeKind == XdmNodeKind.Element && node.NamespaceUri == ns && node.LocalName == local && (typeCheck is null || typeCheck(node));
        }

        if (nodeTest.StartsWith("schema-element("))
        {
            var arg = ExtractFunctionArg(nodeTest);
            var (declNs, declLocal) = ParseQName(arg);
            if (string.IsNullOrEmpty(declNs))
                declNs = _defaultElementNamespace ?? "";
            return node => MatchesSchemaElement(node, declNs, declLocal);
        }

        var (nsUri, localName) = ParseQName(nodeTest);
        if (string.IsNullOrEmpty(nsUri))
        {
            var defaultNs = _defaultElementNamespace ?? "";
            return node => node.NodeKind == XdmNodeKind.Element && node.LocalName == localName && node.NamespaceUri == defaultNs;
        }
        if (localName == "*")
            return node => node.NodeKind == XdmNodeKind.Element && node.NamespaceUri == nsUri;
        return node => node.NodeKind == XdmNodeKind.Element && node.NamespaceUri == nsUri && node.LocalName == localName;
    }

    private Func<IXdmNode, bool> CompileAttributeNodeTest(string nodeTest)
    {
        if (nodeTest == "*")
            return node => node.NodeKind == XdmNodeKind.Attribute;
        if (nodeTest.StartsWith("*:"))
        {
            string local = nodeTest[2..];
            return node => node.NodeKind == XdmNodeKind.Attribute && node.LocalName == local;
        }
        if (nodeTest == "node()")
            return node => node.NodeKind == XdmNodeKind.Attribute;
        if (nodeTest == "text()")
            return node => node.NodeKind == XdmNodeKind.Attribute; // Unusual but valid
        if (nodeTest == "comment()")
            return node => node.NodeKind == XdmNodeKind.Attribute;
        if (nodeTest == "processing-instruction()")
            return node => node.NodeKind == XdmNodeKind.Attribute;
        if (nodeTest == "element()")
            return node => node.NodeKind == XdmNodeKind.Attribute;

        if (nodeTest.StartsWith("schema-attribute("))
        {
            var arg = ExtractFunctionArg(nodeTest);
            var (declNs, declLocal) = ParseQName(arg);
            // Unprefixed attribute names have no namespace (XPath default element namespace does not apply).
            return node => MatchesSchemaAttribute(node, declNs, declLocal);
        }

        if (nodeTest.StartsWith("attribute("))
        {
            var arg = ExtractFunctionArg(nodeTest);
            // attribute(name) or attribute(QName); may include a type argument: attribute(name, type).
            // The type argument is enforced only in schema-aware stylesheets (REQ-105).
            var (nameArg, typeArg) = SplitKindTestArgs(arg);
            var typeCheck = CompileKindTestTypeCheck(typeArg, isElement: false);
            if (string.IsNullOrEmpty(nameArg) || nameArg == "*")
                return node => node.NodeKind == XdmNodeKind.Attribute && (typeCheck is null || typeCheck(node));
            if (_compatibility >= XPathCompatibility.XPath40)
            {
                var nameCheck = CompileKindTestNameCheck(nameArg, isElement: false);
                return node => node.NodeKind == XdmNodeKind.Attribute && nameCheck(node)
                    && (typeCheck is null || typeCheck(node));
            }
            var (attrNs, attrLocal) = ParseQName(nameArg);
            // Unprefixed attribute names have no namespace (XPath default element namespace does not apply).
            if (string.IsNullOrEmpty(attrNs))
                return node => node.NodeKind == XdmNodeKind.Attribute && node.NamespaceUri.Length == 0 && node.LocalName == attrLocal && (typeCheck is null || typeCheck(node));
            return node => node.NodeKind == XdmNodeKind.Attribute && node.NamespaceUri == attrNs && node.LocalName == attrLocal && (typeCheck is null || typeCheck(node));
        }

        var (nsUri, localName) = ParseQName(nodeTest);
        if (string.IsNullOrEmpty(nsUri))
            return node => node.NodeKind == XdmNodeKind.Attribute && node.LocalName == localName && node.NamespaceUri == "";
        if (localName == "*")
            return node => node.NodeKind == XdmNodeKind.Attribute && node.NamespaceUri == nsUri;
        return node => node.NodeKind == XdmNodeKind.Attribute && node.NamespaceUri == nsUri && node.LocalName == localName;
    }

    private PatternPredicate CompileAttributePattern(string name)
    {
        if (name == "*")
        {
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return node.NodeKind == XdmNodeKind.Attribute;
            };
        }

        if (name.StartsWith("*:"))
        {
            string localName2 = name[2..];
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return node.NodeKind == XdmNodeKind.Attribute && node.LocalName == localName2;
            };
        }

        // namespace::* 
        if (name == "namespace::*")
        {
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return node.NodeKind == XdmNodeKind.Namespace;
            };
        }

        if (name.StartsWith("schema-attribute("))
        {
            var arg = ExtractFunctionArg(name);
            var (declNs, declLocal) = ParseQName(arg);
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return MatchesSchemaAttribute(node, declNs, declLocal);
            };
        }

        var (ns, local) = ParseQName(name);

        if (string.IsNullOrEmpty(ns))
        {
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return node.NodeKind == XdmNodeKind.Attribute &&
                node.LocalName == local &&
                node.NamespaceUri == "";
            };
        }

        if (local == "*")
        {
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                return node.NodeKind == XdmNodeKind.Attribute &&
                node.NamespaceUri == ns;
            };
        }

        return (item, ctx) =>
        {
            var node = AsNode(item);
            if (node == null) return false;
            return node.NodeKind == XdmNodeKind.Attribute &&
            node.NamespaceUri == ns &&
            node.LocalName == local;
        };
    }

    /// <summary>
    /// Returns the expanded names of the plain-QName steps that a strict/lax typed mode
    /// would interpret as <c>schema-element(QName)</c>: a branch consisting of exactly
    /// one QName step, at the top level of the pattern or of a union branch, optionally
    /// after a leading <c>//</c>. Path patterns (<c>a/b</c>), wildcards, kind tests, and
    /// axis steps are not rewriteable and are not returned. The pattern must already be
    /// prefix-resolved (Q{{uri}}local form) as done by TemplateRule.
    /// </summary>
    public static IReadOnlyList<(string NamespaceUri, string LocalName)> GetSchemaRewriteableQNames(string resolvedPattern, string? defaultElementNamespace)
    {
        var result = new List<(string NamespaceUri, string LocalName)>();
        var trimmed = StripXPathComments(resolvedPattern).Trim();
        foreach (var branch in SplitTopLevel(trimmed, '|'))
        {
            var step = branch.Trim();
            if (step.StartsWith("//"))
                step = step[2..].Trim();
            if (!IsPlainQNameStep(step))
                continue;
            var (ns, local) = ParseQName(step, null);
            result.Add((string.IsNullOrEmpty(ns) ? (defaultElementNamespace ?? "") : ns, local));
        }
        return result;
    }

    /// <summary>
    /// Returns true when the step is exactly one lexical QName (<c>prefix:local</c>,
    /// <c>Q{{uri}}local</c>, or unprefixed <c>local</c>): no wildcards, predicates,
    /// parentheses, axes, or operators.
    /// </summary>
    private static bool IsPlainQNameStep(string step)
    {
        if (step.Length == 0)
            return false;
        if (!char.IsLetter(step[0]) && step[0] != '_')
            return false;
        foreach (char c in step)
        {
            if (c is '*' or '(' or ')' or '[' or ']' or '/' or '|' or '@' or ',')
                return false;
        }
        return true;
    }

    /// <summary>
    /// Matches an element node against a <c>schema-element(N)</c> kind test in a match pattern,
    /// using the schema set captured in the validation context. Mirrors
    /// <c>VmEngine.MatchesSchemaElement</c>: substitution-group walk, nillability, and type
    /// derivation checks. Returns false (never throws) when no schema set is available or the
    /// declaration is absent.
    /// </summary>
    private bool MatchesSchemaElement(IXdmNode node, string targetNs, string targetLocal)
    {
        if (node.NodeKind != XdmNodeKind.Element)
            return false;

        var context = _validationContext;
        if (context?.SchemaSet is null)
            return false;

        var targetDecl = context.GetSchemaElement(targetNs, targetLocal);
        if (targetDecl is null)
            return false;

        var nodeDeclName = node.SchemaElementDeclaration;
        if (nodeDeclName is null)
            return false;

        var actualDecl = context.GetSchemaElement(nodeDeclName.Value.NamespaceUri, nodeDeclName.Value.LocalName);
        if (actualDecl is null)
            return false;

        if (nodeDeclName.Value.NamespaceUri != targetNs || nodeDeclName.Value.LocalName != targetLocal)
        {
            var currentDecl = actualDecl;
            while (currentDecl != null)
            {
                var sg = currentDecl.SubstitutionGroup;
                if (sg is null || sg.IsEmpty)
                    return false;
                if (sg.Namespace == targetNs && sg.Name == targetLocal)
                    break;
                currentDecl = context.GetSchemaElement(sg.Namespace, sg.Name);
            }
            if (currentDecl is null)
                return false;
        }

        if (node.IsNilled)
            return actualDecl.IsNillable;

        // XmlSchemaElement.SchemaType is null for type-referenced declarations; the
        // post-compilation ElementSchemaType carries the effective type (REQ-105).
        var targetType = targetDecl.ElementSchemaType ?? targetDecl.SchemaType;
        if (targetType is null)
            return true;

        // The annotation names the node's type; an anonymous type has no name, in which
        // case the governing declaration's own type is the annotation (validation-0501).
        var actualType = ResolveSchemaTypeAnnotation(context, node.SchemaTypeAnnotation)
            ?? actualDecl.ElementSchemaType ?? actualDecl.SchemaType;
        return actualType is not null
            && XmlSchemaType.IsDerivedFrom(actualType, targetType, XmlSchemaDerivationMethod.Empty);
    }

    /// <summary>
    /// Matches an attribute node against a <c>schema-attribute(N)</c> kind test in a match pattern,
    /// using the schema set captured in the validation context. Mirrors
    /// <c>VmEngine.MatchesSchemaAttribute</c>. Returns false (never throws) when no schema set
    /// is available or the declaration is absent. An attribute validated by named type alone
    /// (no governing declaration, e.g. a constructed <c>xsl:attribute</c> with a
    /// <c>type</c> attribute) matches when its expanded name equals the declaration name and
    /// its type annotation is derived from the declared type (match-191).
    /// </summary>
    private bool MatchesSchemaAttribute(IXdmNode node, string targetNs, string targetLocal)
    {
        if (node.NodeKind != XdmNodeKind.Attribute)
            return false;

        var context = _validationContext;
        if (context?.SchemaSet is null)
            return false;

        var targetDecl = context.GetSchemaAttribute(targetNs, targetLocal);
        if (targetDecl is null)
            return false;

        // XmlSchemaAttribute.SchemaType is null for type-referenced declarations; the
        // post-compilation AttributeSchemaType carries the effective type (REQ-105).
        var targetType = targetDecl.AttributeSchemaType ?? targetDecl.SchemaType;

        var nodeDeclName = node.SchemaAttributeDeclaration;
        if (nodeDeclName is null)
        {
            // No governing declaration (validated by named type only): match by name and
            // by type derivation from the declared type.
            if (node.NamespaceUri != targetNs || node.LocalName != targetLocal)
                return false;
            return IsSchemaTypeCompatible(node.SchemaTypeAnnotation, targetType, context);
        }
        if (nodeDeclName.Value.NamespaceUri != targetNs || nodeDeclName.Value.LocalName != targetLocal)
            return false;

        // The annotation names the node's type; an anonymous type has no name, in which
        // case the governing declaration's own type is the annotation.
        var nodeDecl = context.GetSchemaAttribute(nodeDeclName.Value.NamespaceUri, nodeDeclName.Value.LocalName);
        var actualType = ResolveSchemaTypeAnnotation(context, node.SchemaTypeAnnotation)
            ?? nodeDecl?.AttributeSchemaType ?? nodeDecl?.SchemaType;
        return actualType is not null && targetType is not null
            && XmlSchemaType.IsDerivedFrom(actualType, targetType, XmlSchemaDerivationMethod.Empty);
    }

    /// <summary>
    /// Returns true when the node's schema type annotation is the same as or derived from
    /// the supplied target schema type.
    /// </summary>
    private static bool IsSchemaTypeCompatible((string NamespaceUri, string LocalName)? typeAnnotation, XmlSchemaType? targetType, EvaluationContext context)
    {
        if (targetType is null)
            return true;
        if (typeAnnotation is not { } annotation)
            return false;
        if (annotation.NamespaceUri == targetType.QualifiedName.Namespace && annotation.LocalName == targetType.QualifiedName.Name)
            return true;
        // Resolve through the built-in type table as well: XmlSchemaSet.GlobalTypes does not
        // surface the built-in XML Schema types, so a node annotated xs:NMTOKEN must still be
        // found to derive from xs:token (match-208).
        var actualType = ResolveSchemaType(context, annotation.NamespaceUri, annotation.LocalName);
        if (actualType is null)
            return false;
        return XmlSchemaType.IsDerivedFrom(actualType, targetType, XmlSchemaDerivationMethod.Empty);
    }

    /// <summary>
    /// Resolves a schema type by expanded name. User-defined types come from the in-scope
    /// compiled schema set; the built-in XML Schema types are not surfaced by
    /// <see cref="XmlSchemaSet.GlobalTypes"/> and are resolved from the System.Xml.Schema
    /// built-in type table instead.
    /// </summary>
    /// <param name="context">The evaluation context carrying the in-scope schema set.</param>
    /// <param name="namespaceUri">The type's namespace URI.</param>
    /// <param name="localName">The type's local name.</param>
    /// <returns>The resolved type definition, or <c>null</c> when the name is unknown.</returns>
    private static XmlSchemaType? ResolveSchemaType(EvaluationContext context, string namespaceUri, string localName)
    {
        if (context.GetSchemaType(namespaceUri, localName) is { } fromSet)
            return fromSet;
        if (namespaceUri != XmlSchema.Namespace)
            return null;
        var qualifiedName = new XmlQualifiedName(localName, namespaceUri);
        if (XmlSchemaType.GetBuiltInSimpleType(qualifiedName) is { } builtInSimple)
            return builtInSimple;
        if (XmlSchemaType.GetBuiltInComplexType(qualifiedName) is { } builtInComplex)
            return builtInComplex;
        // XPath type-hierarchy members that are not XSD 1.0 built-ins.
        return localName switch
        {
            "anyAtomicType" => XmlSchemaType.GetBuiltInSimpleType(XmlTypeCode.AnyAtomicType),
            "untypedAtomic" => XmlSchemaType.GetBuiltInSimpleType(XmlTypeCode.UntypedAtomic),
            "dayTimeDuration" => XmlSchemaType.GetBuiltInSimpleType(XmlTypeCode.DayTimeDuration),
            "yearMonthDuration" => XmlSchemaType.GetBuiltInSimpleType(XmlTypeCode.YearMonthDuration),
            _ => null,
        };
    }

    /// <summary>
    /// Resolves a node's schema type annotation to a type definition, returning
    /// <c>null</c> for absent or anonymous (unnamed) annotations.
    /// </summary>
    /// <param name="context">The evaluation context carrying the in-scope schema set.</param>
    /// <param name="annotation">The node's type annotation, or <c>null</c>.</param>
    /// <returns>The resolved type definition, or <c>null</c>.</returns>
    private static XmlSchemaType? ResolveSchemaTypeAnnotation(EvaluationContext context, (string NamespaceUri, string LocalName)? annotation)
        => annotation is { } a && a.LocalName.Length > 0
            ? ResolveSchemaType(context, a.NamespaceUri, a.LocalName)
            : null;

    /// <summary>Compiles 4.0 kind-test name alternatives with independent namespace and local wildcards.</summary>
    private Func<IXdmNode, bool> CompileKindTestNameCheck(string name, bool isElement)
    {
        // Validate NameTestUnion grammar before interpreting the individual alternatives.
        if (ItemTypeAliasExpansion.Expand((isElement ? "element(" : "attribute(") + name + ")", value => value) is null)
            throw new InvalidOperationException("XPST0003: Invalid wildcard or union name in a node kind test.");
        var alternatives = SplitTopLevel(name, '|').Select(part =>
        {
            var text = part.Trim();
            if (text == "*") return (Namespace: (string?)null, Local: "*");
            if (text.StartsWith("*:", StringComparison.Ordinal)) return (Namespace: (string?)null, Local: text[2..]);
            var (ns, local) = ParseQName(text);
            if (ns.Length == 0 && !text.StartsWith("Q{", StringComparison.Ordinal) && !text.Contains(':'))
                ns = isElement ? _defaultElementNamespace ?? string.Empty : string.Empty;
            return (Namespace: (string?)ns, Local: local);
        }).ToArray();
        return node => alternatives.Any(test => (test.Namespace is null || node.NamespaceUri == test.Namespace)
            && (test.Local == "*" || node.LocalName == test.Local));
    }

    /// <summary>
    /// Splits the argument of an <c>element(...)</c> / <c>attribute(...)</c> kind test into
    /// the name part and the optional schema type part, e.g. <c>element(N, T)</c> yields
    /// <c>("N", "T")</c>. The separating comma is found at the top level of the argument.
    /// </summary>
    /// <param name="arg">The raw kind-test argument text.</param>
    /// <returns>The name (or wildcard) part, and the type part when a comma is present.</returns>
    private (string NameArg, string? TypeArg) SplitKindTestArgs(string arg)
    {
        int comma = FindTopLevelComma(_compatibility >= XPathCompatibility.XPath40 ? MaskEQNameUris(arg) : arg);
        if (comma < 0)
            return (arg.Trim(), null);
        return (arg[..comma].Trim(), arg[(comma + 1)..].Trim());
    }

    /// <summary>
    /// Compiles the optional schema type argument of an <c>element(N, T)</c> /
    /// <c>attribute(N, T)</c> kind test into a node predicate enforcing the type at match
    /// time. Returns <c>null</c> when no type argument is present or when no schema set is
    /// in scope — a basic (non-schema-aware) processor ignores the type argument entirely.
    /// Built-in <c>xs:</c> type names are resolved without an in-scope schema set, so a
    /// schema-aware stylesheet without imports still honors typed patterns
    /// (conflict-resolution-1402). A trailing <c>?</c> on the type name allows nilled
    /// elements to match.
    /// </summary>
    /// <param name="typeArg">The type part of the kind test, or <c>null</c> when absent.</param>
    /// <param name="isElement">True for an element kind test, false for an attribute kind test.</param>
    /// <returns>A predicate over the candidate node, or <c>null</c> when no type check applies.</returns>
    private Func<IXdmNode, bool>? CompileKindTestTypeCheck(string? typeArg, bool isElement)
    {
        if (string.IsNullOrEmpty(typeArg))
            return null;
        var context = _validationContext;

        var typeName = typeArg.Trim();
        bool nillable = false;
        if (typeName.EndsWith('?'))
        {
            nillable = true;
            typeName = typeName[..^1].TrimEnd();
        }
        if (typeName.Length == 0)
            return null;

        var (targetNs, targetLocal) = ParseQName(typeName);
        if (targetNs.Length == 0 && !typeName.StartsWith("Q{", StringComparison.Ordinal))
        {
            if (!typeName.Contains(':'))
            {
                // Unprefixed type names expand against the xpath-default-namespace (match-165).
                targetNs = _defaultElementNamespace ?? "";
            }
            else
            {
                // A prefixed name that survived prefix resolution has an unbound prefix:
                // the type cannot resolve, so the kind test never matches.
                return node => false;
            }
        }
        if (targetLocal.Length == 0)
            return node => false;

        // Without an in-scope schema set only built-in xs: types can be resolved; a
        // user-defined type name is ignored, as on a basic processor.
        if (context?.SchemaSet is null && ResolveBuiltInSchemaType(targetNs, targetLocal) is null)
            return null;

        var ns = targetNs;
        var local = targetLocal;
        return node => MatchesTypeAnnotation(node, isElement, ns, local, nillable);
    }

    /// <summary>
    /// Resolves a built-in XML Schema type by expanded name without requiring an evaluation
    /// context: the XSD 1.0 built-in type table plus the XPath-only type-hierarchy members
    /// (<c>xs:anyAtomicType</c>, <c>xs:untypedAtomic</c>, <c>xs:dayTimeDuration</c>,
    /// <c>xs:yearMonthDuration</c>).
    /// </summary>
    /// <param name="namespaceUri">The type's namespace URI.</param>
    /// <param name="localName">The type's local name.</param>
    /// <returns>The built-in type definition, or <c>null</c> when the name is not a built-in type.</returns>
    private static XmlSchemaType? ResolveBuiltInSchemaType(string namespaceUri, string localName)
    {
        if (namespaceUri != XmlSchema.Namespace)
            return null;
        var qualifiedName = new XmlQualifiedName(localName, namespaceUri);
        if (XmlSchemaType.GetBuiltInSimpleType(qualifiedName) is { } builtInSimple)
            return builtInSimple;
        if (XmlSchemaType.GetBuiltInComplexType(qualifiedName) is { } builtInComplex)
            return builtInComplex;
        return localName switch
        {
            "anyAtomicType" => XmlSchemaType.GetBuiltInSimpleType(XmlTypeCode.AnyAtomicType),
            "untypedAtomic" => XmlSchemaType.GetBuiltInSimpleType(XmlTypeCode.UntypedAtomic),
            "dayTimeDuration" => XmlSchemaType.GetBuiltInSimpleType(XmlTypeCode.DayTimeDuration),
            "yearMonthDuration" => XmlSchemaType.GetBuiltInSimpleType(XmlTypeCode.YearMonthDuration),
            _ => null,
        };
    }

    /// <summary>
    /// Returns true when the node's schema type annotation is the same as, or derived from,
    /// the named target type, per <c>element(N, T)</c> / <c>attribute(N, T)</c> kind-test
    /// semantics (XPath 3.1 §2.5.4). A nilled element matches only when the type name carried
    /// the <c>?</c> nillable marker. A node without a type annotation (unvalidated, or
    /// annotations stripped via <c>input-type-annotations="strip"</c>) matches an element
    /// target of <c>xs:untyped</c>/<c>xs:anyType</c>, or an attribute target of
    /// <c>xs:untypedAtomic</c> and its supertypes.
    /// </summary>
    /// <param name="node">The candidate node (element or attribute).</param>
    /// <param name="isElement">True when matching an element, false for an attribute.</param>
    /// <param name="targetNs">The expanded namespace URI of the target type.</param>
    /// <param name="targetLocal">The local name of the target type.</param>
    /// <param name="nillable">True when the type name carried the <c>?</c> nillable marker.</param>
    /// <returns>True when the node's type annotation satisfies the typed kind test.</returns>
    private bool MatchesTypeAnnotation(IXdmNode node, bool isElement, string targetNs, string targetLocal, bool nillable)
    {
        // The validation context may be absent (built-in xs: type checks compiled without
        // an in-scope schema set, conflict-resolution-1402); built-in names still resolve.
        var context = _validationContext;

        XmlSchemaType? ResolveType(string ns, string local) => context is not null
            ? ResolveSchemaType(context, ns, local)
            : ResolveBuiltInSchemaType(ns, local);

        if (isElement && node.IsNilled)
            return nillable;

        bool targetIsSchemaNamespace = targetNs == XmlSchema.Namespace;

        if (node.SchemaTypeAnnotation is not { } actual)
        {
            if (!targetIsSchemaNamespace)
                return false;
            return isElement
                ? targetLocal is "untyped" or "anyType"
                : targetLocal is "untypedAtomic" or "anyAtomicType" or "anySimpleType" or "anyType";
        }

        if (actual.NamespaceUri == targetNs && actual.LocalName == targetLocal)
            return true;

        // xs:anySimpleType and xs:anyAtomicType head the simple-type hierarchy, but
        // System.Xml.Schema does not model derivation into them; match them structurally.
        if (targetIsSchemaNamespace && targetLocal is "anySimpleType" or "anyAtomicType")
        {
            if (ResolveType(actual.NamespaceUri, actual.LocalName) is not XmlSchemaSimpleType simple)
                return false;
            return targetLocal == "anySimpleType" || simple.Datatype?.Variety == XmlSchemaDatatypeVariety.Atomic;
        }

        var targetType = ResolveType(targetNs, targetLocal);
        if (targetType is null)
            return false;
        return context is not null
            ? IsSchemaTypeCompatible(actual, targetType, context)
            : IsBuiltInSchemaTypeCompatible(actual, targetType);
    }

    /// <summary>
    /// Context-free variant of <see cref="IsSchemaTypeCompatible"/> used when no validation
    /// context exists: only built-in type annotations can be resolved, through the built-in
    /// type table.
    /// </summary>
    /// <param name="typeAnnotation">The node's schema type annotation.</param>
    /// <param name="targetType">The resolved target schema type.</param>
    /// <returns>True when the annotation derives from the target type.</returns>
    private static bool IsBuiltInSchemaTypeCompatible((string NamespaceUri, string LocalName) typeAnnotation, XmlSchemaType targetType)
    {
        if (typeAnnotation.NamespaceUri == targetType.QualifiedName.Namespace
            && typeAnnotation.LocalName == targetType.QualifiedName.Name)
            return true;
        var actualType = ResolveBuiltInSchemaType(typeAnnotation.NamespaceUri, typeAnnotation.LocalName);
        return actualType is not null
            && XmlSchemaType.IsDerivedFrom(actualType, targetType, XmlSchemaDerivationMethod.Empty);
    }

    /// <summary>Finds a predicate bracket outside EQName namespace literals and quoted strings.</summary>
    private static int FindPredicateStart(string pattern)
    {
        char quote = '\0';
        bool uri = false;
        for (int i = 0; i < pattern.Length; i++)
        {
            char c = pattern[i];
            if (uri)
            {
                if (c == '}') uri = false;
                continue;
            }
            if (quote != '\0')
            {
                if (c == quote)
                {
                    if (i + 1 < pattern.Length && pattern[i + 1] == quote) i++;
                    else quote = '\0';
                }
                continue;
            }
            if (c is '\'' or '"') { quote = c; continue; }
            if (c == 'Q' && i + 1 < pattern.Length && pattern[i + 1] == '{') { uri = true; i++; continue; }
            if (c == '[') return i;
        }
        return -1;
    }

    private PatternPredicate CompilePredicatePattern(string pattern)
    {
        int bracketOpen = FindPredicateStart(pattern);
        if (bracketOpen < 0)
            return CompileSinglePattern(pattern);

        // Find matching close bracket
        int bracketClose = FindMatchingBracket(pattern, bracketOpen);
        if (bracketClose < 0 || bracketClose < bracketOpen)
            throw new InvalidOperationException($"Invalid pattern: {pattern}");

        string basePattern = pattern[..bracketOpen].Trim();
        string predicateExpr = pattern[(bracketOpen + 1)..bracketClose].Trim();
        string remaining = bracketClose + 1 < pattern.Length ? pattern[(bracketClose + 1)..] : "";

        // Static validation: dry-run predicate against a dummy node to catch XPST0017
        // and other static errors in predicates that might never be evaluated at runtime.
        // Suppress evaluation of sequence-constructor globals during validation so globals
        // whose value depends on the source document or pattern matching are not
        // materialized prematurely (error-0640d), while @select-only globals are still
        // evaluated normally.
        if (_validationContext != null)
        {
            var savedSuppress = _validationContext.SuppressLazySequenceConstructorGlobals;
            _validationContext.SuppressLazySequenceConstructorGlobals = true;
            try
            {
                var dummyNode = XDocumentNode.Wrap(new XElement("__dummy__"));
                var validationExpr = CompilePatternXPath($"boolean({predicateExpr})");
                validationExpr.Evaluate(_validationContext.WithFocus(XdmValue.FromNode(dummyNode), 1, 1));
            }
            catch (Exception ex) when (IsStaticError(ex))
            {
                throw;
            }
            catch
            {
                // Ignore dynamic errors (type errors, missing nodes, etc.) —
                // these are legitimate for a dummy context and do not indicate
                // a static pattern problem.
            }
            finally
            {
                _validationContext.SuppressLazySequenceConstructorGlobals = savedSuppress;
            }
        }

        // Special case: .[predicate] or [predicate] matches any node where the predicate is true.
        // Handle . with trailing comments: strip leading '.' and check the rest is only comments/whitespace.
        bool IsDotPattern(string bp)
        {
            var t = bp.Trim();
            if (t == ".") return true;
            if (t.StartsWith("."))
            {
                // After '.', the rest should be whitespace and/or XPath comments
                int i = 1;
                while (i < t.Length)
                {
                    if (char.IsWhiteSpace(t[i])) { i++; continue; }
                    if (i + 1 < t.Length && t[i] == '(' && t[i + 1] == ':')
                    {
                        // Skip comment
                        i += 2;
                        int depth = 1;
                        while (i < t.Length && depth > 0)
                        {
                            if (i + 1 < t.Length && t[i] == ':' && t[i + 1] == ')') { depth--; i += 2; }
                            else if (i + 1 < t.Length && t[i] == '(' && t[i + 1] == ':') { depth++; i += 2; }
                            else i++;
                        }
                        continue;
                    }
                    return false;
                }
                return true;
            }
            return false;
        }

        if (IsDotPattern(basePattern) || string.IsNullOrEmpty(basePattern))
        {
            var fullPredicate = $"self::node()[{predicateExpr}]{remaining}";
            var dotCompiled = CompilePatternXPath(fullPredicate);
            var atomicPredicate = string.IsNullOrEmpty(predicateExpr) ? "true()" : $"boolean({predicateExpr})";
            var atomicCompiled = CompilePatternXPath(atomicPredicate);

            return (item, ctx) =>
            {
                var savedItem = ctx.ContextItem;
                var savedPos = ctx.ContextPosition;
                var savedSize = ctx.ContextSize;
                try
                {
                    if (!item.IsNode)
                    {
                        var atomicResult = atomicCompiled.Evaluate(ctx.WithFocus(item, 1, 1));
                        return atomicResult.GetEffectiveBooleanValue();
                    }

                    var result = dotCompiled.Evaluate(ctx.WithFocus(item, 1, 1));
                    return result.GetEffectiveBooleanValue();
                }
                catch (Exception ex)
                {
                    if (IsStaticError(ex)) throw;
                    return false;
                }
                finally
                {
                    ctx.WithFocus(savedItem, savedPos, savedSize);
                }
            };
        }

        var basePredicate = CompileSinglePattern(basePattern);

        // For simple element/attribute patterns with predicates, evaluate from the parent
        // so that position() and last() reflect the node's position among its siblings.
        // Kind tests may carry Q{uri} names whose URI contains '.', '/' etc.; mask the URI
        // parts before the structural check so typed kind tests with predicates take this
        // path as well (match-197).
        string structuralBase = IsKindTestPattern(basePattern) ? MaskEQNameUris(basePattern) : basePattern;
        bool isSimpleElement = !structuralBase.Contains('/') && !structuralBase.Contains('|') && !structuralBase.Contains("::") && !basePattern.StartsWith('$') && !basePattern.StartsWith('(') && !basePattern.StartsWith('@') && !structuralBase.Contains('.');
        bool isSimpleAttribute = !structuralBase.Contains('/') && !structuralBase.Contains('|') && !structuralBase.Contains("::") && basePattern.StartsWith('@');

        // Function-call patterns like root(), doc(), id(), key() are not valid node tests
        // and cannot be used in child::/attribute:: axis steps. Kind tests (node(), element() etc.) are OK.
        if ((isSimpleElement || isSimpleAttribute) && basePattern.Contains('(') && basePattern.EndsWith(')') && !IsKindTestPattern(basePattern))
        {
            isSimpleElement = false;
            isSimpleAttribute = false;
        }

        if (isSimpleElement || isSimpleAttribute)
        {
            string axisStep;
            if (basePattern == "attribute()" || basePattern.StartsWith("attribute("))
                axisStep = $"attribute::{basePattern}[{predicateExpr}]{remaining}";
            else if (basePattern == "namespace-node()" || basePattern.StartsWith("namespace-node("))
                axisStep = $"namespace::{basePattern}[{predicateExpr}]{remaining}";
            else if (isSimpleAttribute)
                axisStep = $"attribute::{basePattern[1..]}[{predicateExpr}]{remaining}";
            else
                axisStep = $"child::{basePattern}[{predicateExpr}]{remaining}";
            var compiledStep = CompilePatternXPath(axisStep);
            var fallbackPred = CompilePatternXPath($"self::node()[{predicateExpr}]{remaining}");
            // Streamed parents cannot re-enumerate their children (the population pass
            // already consumed the forward-only child pump). For non-positional
            // predicates the predicate value depends only on the candidate node, so
            // self::node()[pred] is equivalent to child::base[pred] + identity check
            // and can be evaluated directly on the node (si-group-054/056). A trailing
            // path/predicate after the bracket (e.g. [@a][1]) may need sibling-list
            // context and keeps the parent-based evaluation.
            bool selfEvaluateOnStream = remaining.Length == 0 && IsNonPositionalPredicateExpr(predicateExpr);

            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                if (!basePredicate(item, ctx))
                    return false;

                var parent = node.Parent;
                var savedItem = ctx.ContextItem;
                var savedPos = ctx.ContextPosition;
                var savedSize = ctx.ContextSize;
                try
                {
                    if (selfEvaluateOnStream && node is IStreamingNode)
                    {
                        var selfResult = fallbackPred.Evaluate(ctx.WithFocus(XdmValue.FromNode(node), 1, 1));
                        return selfResult.GetEffectiveBooleanValue();
                    }

                    XdmValue result;
                    if (parent == null)
                    {
                        // Parentless node: evaluate predicate directly (position() is 1/1)
                        result = fallbackPred.Evaluate(ctx.WithFocus(XdmValue.FromNode(node), 1, 1));
                        return result.GetEffectiveBooleanValue();
                    }

                    result = compiledStep.Evaluate(ctx.WithFocus(XdmValue.FromNode(parent), 1, 1));

                    if (result.Kind == XdmValueKind.Sequence && result.SequenceValue != null)
                    {
                        foreach (var seqItem in XdmSequence.FromSource(result.SequenceValue))
                        {
                            if (seqItem.IsNode && seqItem.NodeValue is IXdmNode n && n.IsSameNode(node))
                                return true;
                        }
                    }
                    else if (result.IsNode && result.NodeValue is IXdmNode n2 && n2.IsSameNode(node))
                    {
                        return true;
                    }
                    return false;
                }
                catch (Exception ex)
                {
                    if (IsStaticError(ex)) throw;
                    return false;
                }
                finally
                {
                    ctx.WithFocus(savedItem, savedPos, savedSize);
                }
            };
        }

        // For complex base patterns (unions, variable refs, parenthesized), evaluate predicate
        // with the node as focus. This means position()/last() will be 1/1, which is a limitation
        // for patterns like (foo|baz)[position()=2], but handles the common case of (foo|baz)[*].
        string predXPath = $"self::node()[{predicateExpr}]{remaining}";
        var compiledPred = CompilePatternXPath(predXPath);

        return (item, ctx) =>
        {
            var node = AsNode(item);
            if (node == null) return false;
            if (!basePredicate(item, ctx))
                return false;

            var savedItem = ctx.ContextItem;
            var savedPos = ctx.ContextPosition;
            var savedSize = ctx.ContextSize;
            try
            {
                var result = compiledPred.Evaluate(ctx.WithFocus(XdmValue.FromNode(node), 1, 1));
                return result.GetEffectiveBooleanValue();
            }
            catch (Exception ex)
            {
                if (IsStaticError(ex)) throw;
                return false;
            }
            finally
            {
                ctx.WithFocus(savedItem, savedPos, savedSize);
            }
        };
    }

    private PatternPredicate CompileParenthesizedWithPredicates(PatternPredicate innerPattern, string inside, string after)
    {
        // after starts with [predicate...]
        int bracketOpen = after.IndexOf('[');
        if (bracketOpen < 0)
            return innerPattern;

        int bracketClose = FindMatchingBracket(after, bracketOpen);
        if (bracketClose < 0)
            return innerPattern;

        string predicateExpr = after[(bracketOpen + 1)..bracketClose].Trim();
        string remaining = bracketClose + 1 < after.Length ? after[(bracketClose + 1)..] : "";

        // If the inner pattern is a path expression (contains /), the predicate applies
        // to the sequence selected by the path, not to self::node(). For example,
        // (doc/descendant::foo)[2] must match the 2nd foo descendant of doc.
        bool isPathExpression = _compatibility >= XPathCompatibility.XPath40
            ? HasPatternPathOperator(inside)
            : inside.Contains('/');
        if (isPathExpression)
        {
            var compiledPath = CompilePatternXPath($"({inside})[{predicateExpr}]{remaining}");
            return (item, ctx) =>
            {
                var node = AsNode(item);
                if (node == null) return false;
                try
                {
                    var root = node;
                    while (root.Parent != null)
                        root = root.Parent;
                    var result = compiledPath.Evaluate(ctx.WithFocus(XdmValue.FromNode(root), 1, 1));
                    if (result.Kind == XdmValueKind.Sequence && result.SequenceValue != null)
                    {
                        foreach (var seqItem in XdmSequence.FromSource(result.SequenceValue))
                        {
                            if (seqItem.IsNode && seqItem.NodeValue is IXdmNode n && n.IsSameNode(node))
                                return true;
                        }
                    }
                    else if (result.IsNode && result.NodeValue is IXdmNode n2 && n2.IsSameNode(node))
                    {
                        return true;
                    }
                    return false;
                }
                catch (Exception ex)
                {
                    if (IsStaticError(ex)) throw;
                    return false;
                }
            };
        }

        var compiledPred = CompilePatternXPath($"self::node()[{predicateExpr}]{remaining}");

        return (item, ctx) =>
        {
            var node = AsNode(item);
            if (node == null) return false;
            if (!innerPattern(item, ctx))
                return false;

            try
            {
                var result = compiledPred.Evaluate(ctx.WithFocus(XdmValue.FromNode(node), 1, 1));
                return result.GetEffectiveBooleanValue();
            }
            catch (Exception ex)
            {
                if (IsStaticError(ex)) throw;
                return false;
            }
        };
    }

    // ------------------------------------------------------------------
    // Helper methods
    // ------------------------------------------------------------------

    /// <summary>Finds path slashes outside predicates, string literals and EQName namespace URIs.</summary>
    private static bool HasPatternPathOperator(string text)
    {
        int predicateDepth = 0;
        char quote = '\0';
        bool uri = false;
        for (int i = 0; i < text.Length; i++)
        {
            char c = text[i];
            if (quote != '\0')
            {
                if (c == quote)
                {
                    if (i + 1 < text.Length && text[i + 1] == quote) i++;
                    else quote = '\0';
                }
                continue;
            }
            if (uri) { if (c == '}') uri = false; continue; }
            if (c == 'Q' && i + 1 < text.Length && text[i + 1] == '{') { uri = true; i++; continue; }
            if (c is '\'' or '"') { quote = c; continue; }
            if (c == '[') predicateDepth++;
            else if (c == ']') predicateDepth--;
            else if (c == '/' && predicateDepth == 0) return true;
        }
        return false;
    }

    /// <summary>
    /// Splits text on separator only at the top level (not inside parentheses, brackets, or braces).
    /// </summary>
    private static string[] SplitTopLevel(string text, char separator)
        => SplitPatternTopLevel(text, separator.ToString());

    /// <summary>Splits word operators outside nested syntax without interpreting node names as operators.</summary>
    private static string[] SplitTopLevel(string text, string separator)
        => SplitPatternTopLevel(text, separator);

    /// <summary>Splits top-level operators while preserving strings, EQName URIs and complete name tokens.</summary>
    internal static string[] SplitPatternTopLevel(string text, string separator, string? alternative = null, List<string>? operators = null)
    {
        var parts = new List<string>();
        int start = 0, depth = 0;
        char quote = '\0';
        bool uri = false;
        bool word = separator.Length > 1;
        static bool IsNameCharacter(char c) => char.IsLetterOrDigit(c) || c is '_' or '-' or '.' or ':';
        for (int i = 0; i < text.Length; i++)
        {
            char c = text[i];
            if (quote != '\0')
            {
                if (c == quote)
                {
                    if (i + 1 < text.Length && text[i + 1] == quote) i++;
                    else quote = '\0';
                }
                continue;
            }
            if (uri) { if (c == '}') uri = false; continue; }
            if (c == 'Q' && i + 1 < text.Length && text[i + 1] == '{') { uri = true; i++; continue; }
            if (c is '\'' or '"') { quote = c; continue; }
            if (c is '(' or '[' or '{') { depth++; continue; }
            if (c is ')' or ']' or '}') { depth--; continue; }
            if (depth != 0) continue;
            string token = text.AsSpan(i).StartsWith(separator, StringComparison.Ordinal) ? separator
                : alternative is not null && text.AsSpan(i).StartsWith(alternative, StringComparison.Ordinal) ? alternative : string.Empty;
            if (token.Length == 0) continue;
            if (word)
            {
                if (i == 0 || (i == start && operators is null) || (i > 0 && IsNameCharacter(text[i - 1])) ||
                    (i + token.Length < text.Length && IsNameCharacter(text[i + token.Length]))) continue;
                int previous = i - 1;
                while (previous >= start && char.IsWhiteSpace(text[previous])) previous--;
                if ((previous < start && operators is null) || (previous >= start && text[previous] is '/' or '@' or ':')) continue;
            }
            parts.Add(text[start..i].Trim());
            operators?.Add(token);
            start = i + token.Length;
            i += token.Length - 1;
        }
        parts.Add(text[start..].Trim());
        if (operators is not null && operators.Count > 0 && parts.Any(string.IsNullOrEmpty))
            throw new InvalidOperationException("XTSE0340: A set pattern requires an operand on each side of its operator.");
        return parts.Where(part => !string.IsNullOrEmpty(part)).ToArray();
    }

    /// <summary>
    /// Finds the index of the matching closing parenthesis for the paren at startIndex.
    /// Returns -1 if not found.
    /// </summary>
    private static int FindMatchingParen(string text, int startIndex)
        => FindMatchingDelimiter(text, startIndex, '(', ')');

    /// <summary>Finds a closing bracket outside string literals and EQName namespace URIs.</summary>
    private static int FindMatchingBracket(string text, int startIndex)
        => FindMatchingDelimiter(text, startIndex, '[', ']');

    /// <summary>Matches nested delimiters without interpreting quoted or URI characters as syntax.</summary>
    internal static int FindMatchingDelimiter(string text, int startIndex, char opening, char closing)
    {
        if (startIndex < 0 || startIndex >= text.Length || text[startIndex] != opening) return -1;
        int depth = 1;
        char quote = '\0';
        bool uri = false;
        for (int i = startIndex + 1; i < text.Length; i++)
        {
            char c = text[i];
            if (quote != '\0')
            {
                if (c == quote)
                {
                    if (i + 1 < text.Length && text[i + 1] == quote) i++;
                    else quote = '\0';
                }
                continue;
            }
            if (uri) { if (c == '}') uri = false; continue; }
            if (c == 'Q' && i + 1 < text.Length && text[i + 1] == '{') { uri = true; i++; continue; }
            if (c is '\'' or '"') { quote = c; continue; }
            if (c == opening) depth++;
            else if (c == closing && --depth == 0) return i;
        }
        return -1;
    }

    /// <summary>
    /// Checks if the outermost parentheses in text are balanced and at the end (modulo whitespace).
    /// </summary>
    private static bool IsBalancedAtEnd(string text, char open, char close)
    {
        if (text[0] != open) return false;
        int depth = 1;
        for (int i = 1; i < text.Length; i++)
        {
            if (text[i] == open) depth++;
            else if (text[i] == close) depth--;
            if (depth == 0)
            {
                // Check if only whitespace follows
                for (int j = i + 1; j < text.Length; j++)
                    if (!char.IsWhiteSpace(text[j])) return false;
                return true;
            }
        }
        return false;
    }

    /// <summary>
    /// Finds the first '/' at top level (not inside parentheses or brackets).
    /// </summary>
    private static int FindTopLevelSlash(string text)
    {
        int depth = 0;
        for (int i = 0; i < text.Length; i++)
        {
            char c = text[i];
            if (c == '(' || c == '[') depth++;
            else if (c == ')' || c == ']') depth--;
            else if (c == '/' && depth == 0)
                return i;
        }
        return -1;
    }

    /// <summary>
    /// Returns the literal string value of a single-quoted or double-quoted XPath string literal.
    /// </summary>
    private static string? TryGetStringLiteral(string text)
    {
        var t = text.Trim();
        if (t.Length >= 2)
        {
            char q = t[0];
            if ((q == '\'' || q == '"') && t[^1] == q)
                return t[1..^1];
        }
        return null;
    }

    /// <summary>
    /// Resolves a relative URI from a doc()/document() pattern against the evaluation base URI
    /// and checks whether the candidate document node has the same document URI.
    /// </summary>
    private static bool MatchesDocumentUri(IXdmNode node, string relativeUri, EvaluationContext ctx)
    {
        var baseUri = ctx.BaseUri;
        if (string.IsNullOrEmpty(baseUri))
            return false;
        string absolute;
        try
        {
            absolute = new Uri(new Uri(baseUri), relativeUri).AbsoluteUri;
        }
        catch
        {
            return false;
        }
        return string.Equals(node.DocumentUri, absolute, StringComparison.Ordinal);
    }

    /// <summary>
    /// Extracts the argument from a function-like syntax: func(arg).
    /// Handles nested parens.
    /// </summary>
    private static string ExtractFunctionArg(string text)
    {
        int open = text.IndexOf('(');
        if (open < 0) return "";
        int close = FindMatchingParen(text, open);
        if (close < 0) return "";
        return text[(open + 1)..close].Trim();
    }

    /// <summary>Rejects unavailable prefixes in a pattern before runtime compilation.</summary>
    /// <param name="pattern">The pattern source.</param>
    /// <param name="namespaces">The declaring applicable static namespace bindings.</param>
    public static void ValidateNamespacePrefixes(string pattern, IReadOnlyDictionary<string, string> namespaces)
    {
        var lexer = new Bosak.XPath.Parser.Lexer.XPathLexer(pattern, xpath40: true);
        while (true)
        {
            var token = lexer.NextToken();
            if (token.Kind == Bosak.XPath.Parser.Lexer.TokenKind.Eof) return;
            if (token.Kind != Bosak.XPath.Parser.Lexer.TokenKind.Name) continue;
            var name = token.Text(pattern);
            if (name.StartsWith("Q{")) continue;
            int colon = name.IndexOf(':');
            if (colon < 0)
            {
                // A prefixed wildcard is tokenized as Name, Colon, Star.
                var lookahead = lexer;
                var separator = lookahead.NextToken();
                var wildcard = lookahead.NextToken();
                if (separator.Kind != Bosak.XPath.Parser.Lexer.TokenKind.Colon
                    || wildcard.Kind != Bosak.XPath.Parser.Lexer.TokenKind.Star
                    || separator.Start != token.Start + token.Length
                    || wildcard.Start != separator.Start + separator.Length) continue;
                colon = name.Length;
            }
            var prefix = name[..colon].ToString();
            if (!namespaces.ContainsKey(prefix))
                throw new InvalidOperationException($"XPST0081: No namespace declaration for prefix '{prefix}' in pattern.");
        }
    }

    private (string NamespaceUri, string LocalName) ParseQName(string name) => ParseQName(name, _namespaces);

    /// <summary>
    /// Parses a qualified name into (namespaceUri, localName).
    /// Supports prefix:local and Q{uri}local syntax.
    /// The empty URI form Q{}local is permitted and means "no namespace".
    /// When in-scope namespace bindings are supplied (static validation), a prefixed name is
    /// resolved against them and an unbound prefix is a static error (XPST0081); without
    /// bindings the historical contract applies — runtime callers pass prefix-resolved
    /// patterns, so a surviving prefix yields the empty namespace URI.
    /// </summary>
    private static (string NamespaceUri, string LocalName) ParseQName(
        string name, IReadOnlyDictionary<string, string>? namespaces)
    {
        if (name.StartsWith("Q{"))
        {
            int closeBrace = name.IndexOf('}');
            if (closeBrace >= 2)
            {
                var ns = name[2..closeBrace];
                var local = name[(closeBrace + 1)..];
                return (ns, local);
            }
        }

        int colon = name.IndexOf(':');
        if (colon > 0)
        {
            var prefix = name[..colon];
            var local = name[(colon + 1)..];
            if (namespaces is not null)
            {
                if (!namespaces.TryGetValue(prefix, out var resolved))
                {
                    throw new InvalidOperationException(
                        $"XPST0081: No namespace declaration for prefix '{prefix}' in pattern QName '{name}'.");
                }

                return (resolved, local);
            }

            return (string.Empty, local);
        }

        return (string.Empty, name);
    }

    /// <summary>
    /// Returns whether an exception represents a static XPath or XSLT error that should
    /// propagate rather than being treated as a non-matching pattern.
    /// </summary>
    private static bool IsStaticError(Exception ex)
    {
        var msg = ex.Message;
        // XPTY errors during pattern evaluation are dynamic errors, not static errors.
        // In XSLT match patterns, dynamic errors are treated as "does not match".
        // XTDE0640 (circularity) is non-recoverable and must propagate.
        return msg.Contains("XPST") || msg.Contains("XTSE") || msg.StartsWith("XTDE0640:", StringComparison.Ordinal);
    }

    /// <summary>
    /// Returns whether the pattern base is a kind test (node(), element(), etc.) rather than
    /// a function call pattern like root() or doc().
    /// </summary>
    private static bool IsKindTestPattern(string name)
    {
        if (!name.Contains('(') || !name.EndsWith(')')) return false;
        int open = name.IndexOf('(');
        string testName = name[..open];
        return testName switch
        {
            "node" or "text" or "comment" or "processing-instruction" or "element" or "attribute" or "schema-element" or "schema-attribute" or "document-node" => true,
            _ => false
        };
    }

    /// <summary>
    /// Removes XPath comments <c>(: ... :)</c> from the text, preserving string literals.
    /// </summary>
    public static string StripXPathComments(string text)
    {
        var sb = new System.Text.StringBuilder();
        int i = 0;
        while (i < text.Length)
        {
            char c = text[i];
            // Preserve string literals
            if (c == '\'' || c == '"')
            {
                char quote = c;
                sb.Append(c);
                i++;
                while (i < text.Length && text[i] != quote)
                {
                    sb.Append(text[i]);
                    i++;
                }
                if (i < text.Length)
                {
                    sb.Append(text[i]);
                    i++;
                }
                continue;
            }
            // Skip comment
            if (i + 1 < text.Length && text[i] == '(' && text[i + 1] == ':')
            {
                i += 2;
                int depth = 1;
                while (i < text.Length && depth > 0)
                {
                    if (i + 1 < text.Length && text[i] == ':' && text[i + 1] == ')')
                    {
                        depth--;
                        i += 2;
                    }
                    else if (i + 1 < text.Length && text[i] == '(' && text[i + 1] == ':')
                    {
                        depth++;
                        i += 2;
                    }
                    else
                    {
                        i++;
                    }
                }
                continue;
            }
            sb.Append(c);
            i++;
        }
        return sb.ToString();
    }

    /// <summary>
    /// Finds the first comma at top level (not inside parentheses or brackets).
    /// Returns -1 if not found.
    /// </summary>
    private static int FindTopLevelComma(string text)
    {
        int depth = 0;
        for (int i = 0; i < text.Length; i++)
        {
            char c = text[i];
            if (c == '(' || c == '[') depth++;
            else if (c == ')' || c == ']') depth--;
            else if (c == ',' && depth == 0)
                return i;
        }
        return -1;
    }

    /// <summary>
    /// Replaces the URI part of every <c>Q{uri}local</c> EQName with spaces, so that
    /// structural character checks ('/', '.', '|', '::') are not confused by URI contents.
    /// </summary>
    private static string MaskEQNameUris(string text)
    {
        if (!text.Contains("Q{", StringComparison.Ordinal))
            return text;
        var chars = text.ToCharArray();
        for (int i = 0; i + 1 < chars.Length; i++)
        {
            if (chars[i] == 'Q' && chars[i + 1] == '{')
            {
                int close = text.IndexOf('}', i + 2);
                if (close < 0)
                    break;
                for (int j = i + 2; j < close; j++)
                    chars[j] = ' ';
                i = close;
            }
        }
        return new string(chars);
    }
}
