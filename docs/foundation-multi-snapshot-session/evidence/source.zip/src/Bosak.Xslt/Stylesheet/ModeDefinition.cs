// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 mei 2026
// PURPOSE              : Represents a parsed xsl:mode declaration with on-no-match behavior.
// SPECIAL NOTES        : Part of the Bosak XPath 3.1 implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      | Charles Korthout | 0.1   | 26-05-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 05-06-2026     | Added OnMultipleMatch enum and parsing for xsl:mode on-multiple-match                  |
//                      | Charles Korthout | 0.3   | 07-06-2026     | Added DeepSkip to OnNoMatch enum and parsing; fixes next-match-034                     |
//                      | Charles Korthout | 0.4   | 08-06-2026     | FromElement expands mode name QNames to Clark notation                                 |
//                      | Charles Korthout | 0.5   | 09-06-2026     | Added NormalizeModeName; trim whitespace from mode/on-no-match attribute values       |
//                      | Charles Korthout | 0.6   | 11-06-2026     | Added use-accumulators parsing                                                          |
//                      | Charles Korthout | 0.7   | 30-06-2026     | Default on-no-match is text-only-copy per XSLT 3.0 spec; fixes match-241               |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.8  | 02-09-2026     | ModeDefinition tracks explicitly-specified attributes; GetModeDefinition merges per attribute by import precedence (accumulator-023)|
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.9   | 09-09-2026     | XML doc coverage on public API (Beta review)                                           |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.0   | 17-09-2026     | SpecifiedValues + ConflictsWith/MergeSamePrecedence: XTSE0545 only for same-attribute value conflicts; same-precedence declarations merge per attribute (mode-1903) |
//                      | Charles Korthout | 1.1   | 21-09-2026     | API freeze stage B: internalized                                                       |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.2   | 29-09-2026     | @typed parsed into ModeTyped enum (yes/true/1/strict, no/false/0, lax, unspecified);  |
//                      |                  |       |                | QName→schema-element rewriting in strict/lax modes (match-218/219/220/221/222/243/244)|
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.3   | 01-10-2026     | ConflictsWith takes resolvedAttributes: conflicts on attributes explicitly specified  |
//                      | Charles Korthout | 1.4   | 13-10-2026     | Resolve XSLT 4.0 mode declarations using fixed namespace bindings.                       |
//                      | Charles Korthout | 1.5   | 13-10-2026     | Reject explicit empty names while retaining unnamed mode declarations.                  |
//                      |                  |       |                | by a higher-import-precedence declaration are resolved (mode-1505 vs mode-1506)          |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.6   | 14-10-2026     | Retain module fixed mode identities independently of local earlier grammar.                |
//                      | Charles Korthout | 1.7   | 18-10-2026     | Correct build-warning documentation and nullable-flow diagnostics.                     |
//                      |==================|=======|================|=========================================================================================

// ===========================================================================================================================================================

using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace Bosak.Xslt.Stylesheet;

/// <summary>
/// Specifies the built-in template rule behavior when no explicit template matches a node.
/// </summary>
internal enum OnNoMatch
{
    /// <summary>Shallow-copy the node.</summary>
    ShallowCopy,
    /// <summary>Skip the element node, apply-templates to children only.</summary>
    ShallowSkip,
    /// <summary>Copy only text nodes, ignore elements.</summary>
    TextOnlyCopy,
    /// <summary>Deep-copy the entire subtree.</summary>
    DeepCopy,
    /// <summary>Skip the element node and all descendants.</summary>
    DeepSkip,
    /// <summary>Throw an error when no template matches.</summary>
    Fail
}

/// <summary>
/// Specifies the behavior when multiple template rules match with the same priority.
/// </summary>
internal enum OnMultipleMatch
{
    /// <summary>Use the last matching template (default in XSLT 3.0).</summary>
    UseLast,
    /// <summary>Throw an error when multiple templates have the same priority.</summary>
    Fail
}

/// <summary>
/// Specifies the visibility of an <c>xsl:mode</c> declaration.
/// </summary>
internal enum ModeVisibility
{
    /// <summary>Visible to stylesheets that import this one.</summary>
    Public,
    /// <summary>Visible only within this stylesheet package.</summary>
    Private,
    /// <summary>Visible but cannot be overridden.</summary>
    Final,
    /// <summary>Must be overridden by an importing stylesheet.</summary>
    Abstract
}

/// <summary>
/// Specifies the value of the <c>xsl:mode/@typed</c> attribute (XSLT 3.0 §3.5).
/// <c>yes</c>/<c>true</c>/<c>1</c> are synonyms of <see cref="Strict"/>;
/// <c>no</c>/<c>false</c>/<c>0</c> are synonyms of <see cref="Untyped"/>.
/// </summary>
internal enum ModeTyped
{
    /// <summary>The attribute is absent or <c>unspecified</c>: no typed-mode semantics.</summary>
    Unspecified,
    /// <summary>Nodes must be schema-validated; top-level QName patterns mean schema-element(QName).</summary>
    Strict,
    /// <summary>Like strict, but a QName with no element declaration matches by name alone.</summary>
    Lax,
    /// <summary>Nodes must be untyped; schema-dependent patterns raise XTTE3110 on typed nodes.</summary>
    Untyped
}

/// <summary>
/// Represents a parsed xsl:mode declaration.
/// </summary>
internal sealed class ModeDefinition
{
    /// <summary>The mode name (empty string for the default mode).</summary>
    public string Name { get; }

    /// <summary>The behavior when no template matches a node.</summary>
    public OnNoMatch OnNoMatch { get; }

    /// <summary>The behavior when multiple templates match with the same priority.</summary>
    public OnMultipleMatch OnMultipleMatch { get; }

    /// <summary>The visibility of the mode.</summary>
    public ModeVisibility Visibility { get; }

    /// <summary>The typed-mode semantics of the mode (xsl:mode/@typed).</summary>
    public ModeTyped Typed { get; }

    /// <summary>Whether to emit a warning when no template matches a node.</summary>
    public bool WarningOnNoMatch { get; }

    /// <summary>Whether to emit a warning when multiple templates match with the same priority.</summary>
    public bool WarningOnMultipleMatch { get; }

    /// <summary>Whether the mode is declared streamable.</summary>
    public bool Streamable { get; }

    /// <summary>The accumulator names (as Clark names) that are applicable to this mode.</summary>
    public IReadOnlySet<string> UseAccumulators { get; }

    /// <summary>Whether this mode uses all accumulators.</summary>
    public bool UseAllAccumulators { get; }

    /// <summary>The attribute names explicitly specified on the xsl:mode declaration.</summary>
    public IReadOnlySet<string> SpecifiedAttributes { get; }

    /// <summary>
    /// The raw values of the attributes explicitly specified on the xsl:mode declaration,
    /// keyed by attribute name. Used for XTSE0545 conflict detection: two declarations of
    /// the same mode at the same import precedence conflict only when they explicitly
    /// supply different values for the same attribute; attributes specified on only one
    /// declaration are merged (mode-1903 vs mode-1502/1510/1904).
    /// </summary>
    public IReadOnlyDictionary<string, string> SpecifiedValues { get; }

    /// <summary>
    /// Creates a mode definition with private visibility and no warnings, accumulators, or streaming.
    /// </summary>
    /// <param name="name">The mode name (empty string for the unnamed mode).</param>
    /// <param name="onNoMatch">The behavior when no template matches a node.</param>
    /// <param name="onMultipleMatch">The behavior when multiple templates match with the same priority.</param>
    public ModeDefinition(string name, OnNoMatch onNoMatch, OnMultipleMatch onMultipleMatch = OnMultipleMatch.UseLast)
        : this(name, onNoMatch, onMultipleMatch, ModeVisibility.Private, ModeTyped.Unspecified, false, false, false, new HashSet<string>(), false)
    {
    }

    /// <summary>
    /// Creates a mode definition with all <c>xsl:mode</c> attributes specified explicitly.
    /// </summary>
    /// <param name="name">The mode name (empty string for the unnamed mode).</param>
    /// <param name="onNoMatch">The behavior when no template matches a node.</param>
    /// <param name="onMultipleMatch">The behavior when multiple templates match with the same priority.</param>
    /// <param name="visibility">The visibility of the mode.</param>
    /// <param name="typed">The typed-mode semantics of the mode.</param>
    /// <param name="warningOnNoMatch">Whether to emit a warning when no template matches a node.</param>
    /// <param name="warningOnMultipleMatch">Whether to emit a warning when multiple templates match with the same priority.</param>
    /// <param name="streamable">Whether the mode is declared streamable.</param>
    /// <param name="useAccumulators">The accumulator names (Clark notation) applicable to this mode.</param>
    /// <param name="useAllAccumulators">Whether this mode uses all accumulators.</param>
    /// <param name="specifiedAttributes">The attribute names explicitly specified on the xsl:mode declaration; defaults to an empty set.</param>
    /// <param name="specifiedValues">The explicit mode attribute values used during module merging.</param>
    public ModeDefinition(string name, OnNoMatch onNoMatch, OnMultipleMatch onMultipleMatch, ModeVisibility visibility, ModeTyped typed, bool warningOnNoMatch, bool warningOnMultipleMatch, bool streamable, IReadOnlySet<string> useAccumulators, bool useAllAccumulators, IReadOnlySet<string>? specifiedAttributes = null, IReadOnlyDictionary<string, string>? specifiedValues = null)
    {
        Name = name;
        OnNoMatch = onNoMatch;
        OnMultipleMatch = onMultipleMatch;
        Visibility = visibility;
        Typed = typed;
        WarningOnNoMatch = warningOnNoMatch;
        WarningOnMultipleMatch = warningOnMultipleMatch;
        Streamable = streamable;
        UseAccumulators = useAccumulators;
        UseAllAccumulators = useAllAccumulators;
        SpecifiedAttributes = specifiedAttributes ?? new HashSet<string>();
        SpecifiedValues = specifiedValues ?? new Dictionary<string, string>();
    }

    /// <summary>
    /// Whether two declarations of the same mode at the same import precedence conflict
    /// (XTSE0545): they explicitly supply different values for the same attribute.
    /// Attributes named in <paramref name="resolvedAttributes"/> are excluded: a
    /// higher-import-precedence declaration explicitly specifying the attribute
    /// resolves the conflict (XSLT 3.0 §6.6.1; mode-1505 vs mode-1506).
    /// use-accumulators values are compared as sets of resolved (Clark) accumulator names,
    /// so differing prefixes or token order for the same accumulators do not conflict
    /// (mode-1514), while the same prefixes naming different accumulators do (mode-1515).
    /// </summary>
    public bool ConflictsWith(ModeDefinition other, IReadOnlySet<string>? resolvedAttributes = null)
    {
        foreach (var (attr, value) in SpecifiedValues)
        {
            if (resolvedAttributes != null && resolvedAttributes.Contains(attr))
                continue;
            if (!other.SpecifiedValues.TryGetValue(attr, out var otherValue))
                continue;
            if (attr == "use-accumulators")
            {
                if (UseAllAccumulators != other.UseAllAccumulators
                    || !UseAccumulators.SetEquals(other.UseAccumulators))
                    return true;
            }
            else if (!string.Equals(value, otherValue, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }
        return false;
    }

    /// <summary>
    /// Merges two non-conflicting declarations of the same mode at the same import
    /// precedence: each attribute is taken from the declaration that specifies it
    /// explicitly, the later declaration winning for attributes both specify.
    /// </summary>
    public static ModeDefinition MergeSamePrecedence(ModeDefinition first, ModeDefinition second)
    {
        bool FromSecond(string attr) => second.SpecifiedAttributes.Contains(attr);
        var specified = new HashSet<string>(first.SpecifiedAttributes, StringComparer.Ordinal);
        specified.UnionWith(second.SpecifiedAttributes);
        var values = new Dictionary<string, string>(first.SpecifiedValues, StringComparer.Ordinal);
        foreach (var (attr, value) in second.SpecifiedValues)
            values[attr] = value;
        return new ModeDefinition(
            first.Name,
            FromSecond("on-no-match") ? second.OnNoMatch : first.OnNoMatch,
            FromSecond("on-multiple-match") ? second.OnMultipleMatch : first.OnMultipleMatch,
            FromSecond("visibility") ? second.Visibility : first.Visibility,
            FromSecond("typed") ? second.Typed : first.Typed,
            FromSecond("warning-on-no-match") ? second.WarningOnNoMatch : first.WarningOnNoMatch,
            FromSecond("warning-on-multiple-match") ? second.WarningOnMultipleMatch : first.WarningOnMultipleMatch,
            FromSecond("streamable") ? second.Streamable : first.Streamable,
            FromSecond("use-accumulators") ? second.UseAccumulators : first.UseAccumulators,
            FromSecond("use-accumulators") ? second.UseAllAccumulators : first.UseAllAccumulators,
            specified,
            values);
    }

    /// <summary>
    /// Parses an xsl:mode element into a <see cref="ModeDefinition"/>.
    /// </summary>
    public static ModeDefinition? FromElement(XElement element, bool isPackage)
    {
        var name = ExpandModeName(element.Attribute("name")?.Value?.Trim() ?? "", element);
        var onNoMatch = element.Attribute("on-no-match")?.Value?.Trim()?.ToLowerInvariant() switch
        {
            "shallow-copy" => OnNoMatch.ShallowCopy,
            "shallow-skip" => OnNoMatch.ShallowSkip,
            "text-only-copy" => OnNoMatch.TextOnlyCopy,
            "deep-copy" => OnNoMatch.DeepCopy,
            "deep-skip" => OnNoMatch.DeepSkip,
            "fail" => OnNoMatch.Fail,
            _ => OnNoMatch.TextOnlyCopy
        };
        var onMultipleMatch = element.Attribute("on-multiple-match")?.Value?.Trim()?.ToLowerInvariant() switch
        {
            "fail" => OnMultipleMatch.Fail,
            _ => OnMultipleMatch.UseLast
        };

        var visibilityAttr = element.Attribute("visibility")?.Value?.Trim()?.ToLowerInvariant();
        var visibility = visibilityAttr switch
        {
            "public" => ModeVisibility.Public,
            "private" => ModeVisibility.Private,
            "final" => ModeVisibility.Final,
            "abstract" => ModeVisibility.Abstract,
            null or "" => string.IsNullOrEmpty(name)
                ? ModeVisibility.Private
                : isPackage ? ModeVisibility.Private : ModeVisibility.Public,
            _ => throw new InvalidOperationException("XTSE0020")
        };

        // The unnamed mode can only be private; public/final/abstract are not allowed.
        if (string.IsNullOrEmpty(name) && visibility != ModeVisibility.Private)
            throw new InvalidOperationException("XTSE0020");

        // A named mode cannot be abstract.
        if (!string.IsNullOrEmpty(name) && visibility == ModeVisibility.Abstract)
            throw new InvalidOperationException("XTSE0020");

        var typed = ParseTypedAttribute(element);

        var warningOnNoMatch = ParseYesNoAttribute(element, "warning-on-no-match");
        var warningOnMultipleMatch = ParseYesNoAttribute(element, "warning-on-multiple-match");
        var streamable = ParseYesNoAttribute(element, "streamable");

        var useAllAccumulators = false;
        var useAccumulators = new HashSet<string>();
        var useAccAttr = element.Attribute("use-accumulators")?.Value;
        if (!string.IsNullOrWhiteSpace(useAccAttr))
        {
            foreach (var token in useAccAttr.Split(new[] { ' ', '\t', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries))
            {
                var t = token.Trim();
                if (t == "#all")
                {
                    useAllAccumulators = true;
                }
                else if (!string.IsNullOrEmpty(t))
                {
                    useAccumulators.Add(ResolveAccumulatorName(t, element));
                }
            }
        }

        var specified = new HashSet<string>(StringComparer.Ordinal);
        var specifiedValues = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (var attr in element.Attributes())
        {
            if (!attr.IsNamespaceDeclaration && string.IsNullOrEmpty(attr.Name.NamespaceName))
            {
                specified.Add(attr.Name.LocalName);
                specifiedValues[attr.Name.LocalName] = attr.Value.Trim();
            }
        }

        return new ModeDefinition(name, onNoMatch, onMultipleMatch, visibility, typed, warningOnNoMatch, warningOnMultipleMatch, streamable, useAccumulators, useAllAccumulators, specified, specifiedValues);
    }

    private static bool ParseYesNoAttribute(XElement element, string attributeName)
    {
        var value = element.Attribute(attributeName)?.Value?.Trim();
        if (string.IsNullOrEmpty(value))
            return false;
        // Values are case-sensitive: only the lower-case/standard forms are allowed.
        if (value is "yes" or "true" or "1")
            return true;
        if (value is "no" or "false" or "0")
            return false;
        throw new InvalidOperationException("XTSE0020");
    }

    /// <summary>
    /// Parses the xsl:mode/@typed attribute into a <see cref="ModeTyped"/> value.
    /// The tokens are whitespace-trimmed and case-sensitive: yes/true/1 → strict,
    /// no/false/0 → untyped, plus strict, lax, and unspecified. Any other value
    /// is a static error (XTSE0020).
    /// </summary>
    private static ModeTyped ParseTypedAttribute(XElement element)
    {
        var value = element.Attribute("typed")?.Value?.Trim();
        if (string.IsNullOrEmpty(value))
            return ModeTyped.Unspecified;
        return value switch
        {
            "yes" or "true" or "1" or "strict" => ModeTyped.Strict,
            "no" or "false" or "0" => ModeTyped.Untyped,
            "lax" => ModeTyped.Lax,
            "unspecified" => ModeTyped.Unspecified,
            _ => throw new InvalidOperationException("XTSE0020")
        };
    }

    private static string ExpandModeName(string mode, XElement element)
    {
        // xsl:mode/@name may be absent (the unnamed mode) or a valid QName; the special
        // mode tokens #current, #default, #all, and #unnamed are not permitted here.
        if (mode is "#current" or "#default" or "#all" or "#unnamed")
            throw new InvalidOperationException($"XTSE0020: Invalid mode name '{mode}' in xsl:mode/@name.");

        if (Stylesheet.UsesApplicableModeNamespaces(element) && (mode.Length != 0 || element.Attribute("name") is not null))
            return Stylesheet.ExpandModeQName(element, mode);

        int colon = mode.IndexOf(':');
        if (colon < 0)
            return NormalizeModeName(mode);

        var prefix = mode.Substring(0, colon);
        var local = mode.Substring(colon + 1);

        var current = element;
        while (current != null)
        {
            foreach (var attr in current.Attributes())
            {
                if (attr.IsNamespaceDeclaration && attr.Name.LocalName == prefix)
                {
                    return NormalizeModeName($"{{{attr.Value}}}{local}");
                }
            }
            current = current.Parent;
        }
        return NormalizeModeName(mode);
    }

    /// <summary>
    /// Resolves an accumulator name (EQName) to Clark notation.
    /// A lexical QName without a prefix is in no namespace; the default namespace is not used.
    /// </summary>
    private static string ResolveAccumulatorName(string name, XElement element)
    {
        if (name.StartsWith("Q{") && name.Length > 2)
        {
            // EQName form: convert Q{uri}local to the Clark form used for accumulator names.
            int closeBrace = name.IndexOf('}');
            if (closeBrace > 2)
                return $"{{{name[2..closeBrace]}}}{name[(closeBrace + 1)..]}";
            return NormalizeModeName(name);
        }

        int colon = name.IndexOf(':');
        if (colon < 0)
            return NormalizeModeName(name);

        var prefix = name.Substring(0, colon);
        var local = name.Substring(colon + 1);

        var current = element;
        while (current != null)
        {
            foreach (var attr in current.Attributes())
            {
                if (attr.IsNamespaceDeclaration && attr.Name.LocalName == prefix)
                {
                    return NormalizeModeName($"{{{attr.Value}}}{local}");
                }
            }
            current = current.Parent;
        }
        return NormalizeModeName(name);
    }

    /// <summary>
    /// Normalizes a mode name so that <c>Q{{}}local</c> or <c>{{}}local</c>
    /// (empty namespace URI) is treated the same as <c>local</c>.
    /// </summary>
    public static string NormalizeModeName(string mode)
    {
        // #unnamed is the unnamed mode
        if (mode == "#unnamed")
            return "";
        // Q{}local → local
        if (mode.Length > 3 && mode.StartsWith("Q{") && mode[2] == '}')
            return mode.Substring(3);
        // {}local → local
        if (mode.Length > 2 && mode[0] == '{' && mode[1] == '}')
            return mode.Substring(2);
        return mode;
    }
}
