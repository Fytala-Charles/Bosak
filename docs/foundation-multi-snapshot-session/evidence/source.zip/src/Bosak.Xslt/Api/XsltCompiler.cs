// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 25 mei 2026
// PURPOSE              : Entry point for compiling XSLT stylesheets into executable transform objects.
// SPECIAL NOTES        : Part of the Bosak XPath 3.1 implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 25-05-2026     | Creation                                                                                 |
//                      | Charles Korthout | 0.2   | 24-05-2026     | Added IXsltUriResolver support for xsl:import/xsl:include                              |
//                      | Charles Korthout | 0.3   | 31-05-2026     | Added IXsltMessageListener support for xsl:message                                      |
//                      | Charles Korthout | 0.4   | 11-06-2026     | Resolve external DTDs when compiling stylesheets from strings                           |
//                      | Charles Korthout | 0.5   | 24-06-2026     | Preserve XDocument base URI via LoadOptions.SetBaseUri for document() resolution       |
//                      | Charles Korthout | 0.6   | 26-06-2026     | Added TreatRecoverableAmbiguousMatchAsError for test-harness error dependencies        |
//                      | Charles Korthout | 0.7   | 22-09-2026     | REQ-097 schema-aware seam H1/H2: SchemaAware, SchemaResolver, SchemaSet options          |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.8   | 02-10-2026     | validation-0201: EnvironmentSchemaSet (role=secondary host schemas) — source-validation |
//                      |                  |       |                | context only, never part of construction/result-validation scope                       |
//                      | Charles Korthout | 0.9   | 10-10-2026     | REQ-125 Slice B: ResourcePolicy - controlled compile-time acquisition (include/import,   |
//                      |                  |       |                | packages, import-schema, parameter documents, static evaluation); default null unchanged  |
//                      | Charles Korthout | 0.10  | 16-10-2026     | Add opt-in processor profile captured independently of stylesheet versions.              |
// ===========================================================================================================================================================

using System.Xml.Linq;
using System.Xml.Schema;
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Providers.Xml;
using Bosak.XPath.Runtime.Resources;

namespace Bosak.Xslt.Api;

/// <summary>
/// Compiles XSLT 2.0/3.0 stylesheets into <see cref="XsltExecutable"/> instances.
/// </summary>
public sealed class XsltCompiler
{
    /// <summary>
    /// Selects processor compatibility independently of stylesheet version declarations.
    /// Defaults to <see cref="XsltProcessorProfile.Legacy"/>; the experimental
    /// <see cref="XsltProcessorProfile.Xslt40Draft"/> profile uses a 4.0 forward-compatibility
    /// ceiling and frozen XPath 4.0. The setting is captured by each compilation, including
    /// its imported, included and used-package modules. It does not enable experimental XPath features.
    /// </summary>
    public XsltProcessorProfile ProcessorProfile { get; set; }

    /// <summary>
    /// Optional URI resolver for xsl:import and xsl:include. Defaults to <see cref="FileSystemUriResolver"/>.
    /// </summary>
    public IXsltUriResolver? UriResolver { get; set; }

    /// <summary>
    /// Optional controlled resource policy (REQ-125 Slice B) covering compile-time
    /// acquisition: <c>xsl:include</c>/<c>xsl:import</c> modules, <c>xsl:use-package</c>
    /// packages, <c>xsl:import-schema</c> location hints, compile-time
    /// <c>parameter-document</c> resources and resources referenced by static
    /// (<c>use-when</c>) evaluation. When set, the policy's host authority supplies
    /// authoritative bytes for every acquisition and no disk/network fallback is performed;
    /// approved module bytes win over conflicting content on disk. When null (the default),
    /// compilation resolves modules through <see cref="UriResolver"/> exactly as before.
    /// </summary>
    public ControlledResourcePolicy? ResourcePolicy { get; set; }

    /// <summary>
    /// Opt-in schema-aware compilation mode (XSLT 3.0 "schema-aware processor"). When
    /// <c>false</c> (the default), stylesheets containing <c>xsl:import-schema</c>,
    /// <c>validation="strict"</c>, or <c>@type</c> are rejected with XTSE1650/XTSE1660
    /// exactly as before. When <c>true</c>, <c>xsl:import-schema</c> declarations are
    /// compiled into a merged schema set (see <see cref="SchemaResolver"/> and
    /// <see cref="SchemaSet"/>) that is in scope during the transformation. The core
    /// performs no license validation; this flag simply declares that the host provides
    /// schema-aware processing.
    /// </summary>
    public bool SchemaAware { get; set; }

    /// <summary>
    /// Optional resolver supplying schema documents for <c>xsl:import-schema</c> when
    /// <see cref="SchemaAware"/> is true. Arguments are the target namespace URI and the
    /// ordered <c>schema-location</c> hints from the declaration; the returned stream is
    /// parsed as the schema document. When the resolver returns null (or is unset),
    /// locations are resolved as URIs relative to the declaring module's base URI.
    /// Same contract as <see cref="Bosak.XPath.Runtime.Vm.EvaluationContext.SchemaResolver"/>.
    /// </summary>
    public Func<string, IReadOnlyList<string>, Stream?>? SchemaResolver { get; set; }

    /// <summary>
    /// Optional pre-built schema set made in-scope for a schema-aware compilation
    /// (lowest import precedence). Namespaces already present in this set need not be
    /// re-declared via <c>xsl:import-schema</c>. These components count as part of the
    /// stylesheet's in-scope schema definitions: they are visible to validation of
    /// constructed and result trees (unlike <see cref="EnvironmentSchemaSet"/>).
    /// This maps to the W3C test-catalog <c>role="stylesheet-import"</c> semantics.
    /// </summary>
    public XmlSchemaSet? SchemaSet { get; set; }

    /// <summary>
    /// Optional pre-built schema set holding "secondary" environment schemas
    /// (W3C test-catalog <c>role="secondary"</c>): visible to compilation and to
    /// source-document validation, but never part of the stylesheet's in-scope schema
    /// definitions — validation of constructed/result trees (xsl:validation, xsl:type,
    /// result-document validation) does not see these components (XSLT 3.0 §11.9
    /// scoping; validation-0201).
    /// </summary>
    public XmlSchemaSet? EnvironmentSchemaSet { get; set; }

    /// <summary>
    /// Optional listener for xsl:message output. When unset, xsl:message output is discarded.
    /// </summary>
    public IXsltMessageListener? MessageListener { get; set; }

    /// <summary>
    /// Optional externally supplied values for static <c>xsl:param</c> declarations.
    /// Keys are <c>(local-name, namespace-uri)</c> tuples; values are used during static
    /// evaluation instead of the parameter's default <c>@select</c> expression.
    /// </summary>
    public Dictionary<(string LocalName, string NamespaceUri), XdmValue>? StaticParameters { get; set; }

    /// <summary>
    /// When true, an ambiguous template match is treated as a fatal error (XTRE0540)
    /// instead of being resolved by the last-wins recovery rule. This is used by test
    /// harnesses that declare an <c>on-multiple-match="error"</c> dependency.
    /// </summary>
    public bool TreatRecoverableAmbiguousMatchAsError { get; set; }

    /// <summary>
    /// Strategy used to select a package version when an <c>xsl:use-package</c> version
    /// range matches multiple registered packages. Defaults to
    /// <see cref="PackageVersionResolutionStrategy.Highest"/>.
    /// </summary>
    public PackageVersionResolutionStrategy PackageVersionResolutionStrategy { get; set; } = PackageVersionResolutionStrategy.Highest;

    /// <summary>
    /// Compiles an XSLT stylesheet from an XML string.
    /// </summary>
    /// <param name="xsl">The XSLT stylesheet as an XML string.</param>
    /// <param name="baseUri">Optional base URI for resolving xsl:import and xsl:include.</param>
    /// <returns>An executable stylesheet.</returns>
    /// <exception cref="ArgumentOutOfRangeException">The processor profile is not a defined value.</exception>
    public XsltExecutable Compile(string xsl, string? baseUri = null)
    {
        var doc = Xml11Loader.Parse(xsl,
            LoadOptions.PreserveWhitespace | LoadOptions.SetLineInfo | LoadOptions.SetBaseUri,
            baseUri ?? "");
        return Compile(doc, baseUri);
    }

    /// <summary>
    /// Compiles an XSLT stylesheet from an <see cref="XDocument"/>.
    /// </summary>
    /// <param name="document">The parsed XSLT stylesheet.</param>
    /// <param name="baseUri">Optional base URI for resolving xsl:import and xsl:include.</param>
    /// <returns>An executable stylesheet.</returns>
    /// <exception cref="ArgumentOutOfRangeException">The processor profile is not a defined value.</exception>
    public XsltExecutable Compile(XDocument document, string? baseUri = null)
    {
        if (!Enum.IsDefined(ProcessorProfile))
            throw new ArgumentOutOfRangeException(nameof(ProcessorProfile), ProcessorProfile, "Unknown XSLT processor profile.");
        var resolver = UriResolver ?? new FileSystemUriResolver();
        var schemaState = new Stylesheet.SchemaImportState
        {
            SchemaAware = SchemaAware,
            SchemaResolver = SchemaResolver,
            CompilerSchemaSet = SchemaSet,
            EnvironmentSchemaSet = EnvironmentSchemaSet,
            ResourcePolicy = ResourcePolicy,
        };
        var stylesheet = new Stylesheet.Stylesheet(document, baseUri, resolver, externalStaticParameters: StaticParameters, packageVersionResolutionStrategy: PackageVersionResolutionStrategy, schemaState: schemaState, processorProfile: ProcessorProfile);
        return new XsltExecutable(stylesheet, MessageListener, TreatRecoverableAmbiguousMatchAsError);
    }

    /// <summary>
    /// Compiles an XSLT stylesheet from an XDM node.
    /// </summary>
    /// <param name="node">The stylesheet node.</param>
    /// <param name="baseUri">Optional base URI for resolving xsl:import and xsl:include.</param>
    /// <returns>An executable stylesheet.</returns>
    public XsltExecutable Compile(IXdmNode node, string? baseUri = null)
    {
        // TODO: Convert IXdmNode back to XDocument for parsing
        throw new NotImplementedException("Compile from IXdmNode is not yet implemented.");
    }
}
