// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 24 mei 2026
// PURPOSE              : Per-document index for xsl:key / key() lookups.
// SPECIAL NOTES        : Part of the Bosak XPath 3.1 implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 24-05-2026     | Creation                                                                                 |
//                      | Charles Korthout | 0.2   | 08-06-2026     | Added TotalEntryCount, ClearKey, BuildSingleKey for iterative cross-key builds          |
//                      | Charles Korthout | 0.3   | 11-06-2026     | Expanded key names, default namespace, globals before build, no implicit clear           |
//                      | Charles Korthout | 0.4   | 11-06-2026     | Store typed key values; attribute nodes indexed; dedupe entries                         |
//                      | Charles Korthout | 0.5   | 11-06-2026     | Document-order lookup results; composite key support                                     |
//                      | Charles Korthout | 0.6   | 24-06-2026     | Pass DefiningElementDefaultNamespace when compiling key use expressions                |
//                      | Charles Korthout | 0.7   | 26-06-2026     | Per-key-name effective collation for key-value comparison; XTSE1220 detection           |
//                      | Charles Korthout | 0.8   | 29-08-2026     | Index namespace nodes; set fn:current() during xsl:key/@use evaluation (key-058/087/090).|
//                      | Charles Korthout | 0.9   | 21-09-2026     | API freeze stage B: internalized                                                       |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.10  | 24-09-2026     | REQ-106 (PA-3): key values atomize schema-annotated nodes to their PSVI typed value    |
//                      |                  |       |                | (NOTATION-typed attributes index by QName value — notation-0305)                       |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.11  | 01-10-2026     | Match patterns compiled with the evaluation context so schema-element() in xsl:key/@match|
//                      |                  |       |                | sees the in-scope schema set (validation-0202)                                         |
//                      |==================|=======|================|=========================================================================================
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.12  | 14-10-2026     | Compile key match/use with declaring namespaces and local grammar; reuse host compiler.    |
// ===========================================================================================================================================================

using System.Globalization;
using System.Xml.Linq;
using Bosak.XPath.Api;
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Runtime.Vm;
using Bosak.XPath.Standard.Functions;

namespace Bosak.Xslt.Runtime;

/// <summary>
/// Maintains a per-document index for <c>xsl:key</c> / <c>key()</c> lookups.
/// </summary>
internal sealed class KeyIndex
{
    private readonly record struct KeyEntry(bool IsComposite, XdmValue[] KeyValues, IXdmNode Node);

    // key name → entries
    private readonly Dictionary<string, List<KeyEntry>> _index = new();

    // key name → effective collation URI used for key-value comparison
    private readonly Dictionary<string, string> _keyCollations = new();

    /// <summary>
    /// Returns the total number of (keyName, keyValue, node) entries in the index.
    /// </summary>
    public int TotalEntryCount
    {
        get
        {
            int count = 0;
            foreach (var entries in _index.Values)
                count += entries.Count;
            return count;
        }
    }

    /// <summary>
    /// Adds a node under the given key name with a single typed key value.
    /// </summary>
    public void Add(string keyName, XdmValue keyValue, IXdmNode node)
    {
        Add(keyName, false, [keyValue], node);
    }

    /// <summary>
    /// Adds a node under the given key name with a composite (sequence) key value.
    /// </summary>
    public void AddComposite(string keyName, XdmValue[] keyValues, IXdmNode node)
    {
        Add(keyName, true, keyValues, node);
    }

    private void Add(string keyName, bool isComposite, XdmValue[] keyValues, IXdmNode node)
    {
        if (keyValues.Length == 0)
            return;

        if (!_index.TryGetValue(keyName, out var entries))
        {
            entries = new List<KeyEntry>();
            _index[keyName] = entries;
        }

        foreach (var entry in entries)
        {
            if (entry.IsComposite != isComposite)
                continue;
            if (!entry.Node.IsSameNode(node))
                continue;
            if (entry.KeyValues.Length != keyValues.Length)
                continue;
            bool same = true;
            for (int i = 0; i < keyValues.Length; i++)
            {
                if (!KeyValuesEqual(entry.KeyValues[i], keyValues[i], GetCollation(keyName)))
                {
                    same = false;
                    break;
                }
            }
            if (same)
                return;
        }

        entries.Add(new KeyEntry(isComposite, keyValues, node));
    }

    /// <summary>
    /// Removes all entries for the specified key name.
    /// </summary>
    public void ClearKey(string keyName)
    {
        if (_index.TryGetValue(keyName, out var entries))
        {
            entries.Clear();
        }
    }

    /// <summary>
    /// Records the effective collation URI used for comparisons of the specified key name.
    /// </summary>
    public void SetCollation(string keyName, string collation)
    {
        _keyCollations[keyName] = collation;
    }

    private string GetCollation(string keyName)
        => _keyCollations.TryGetValue(keyName, out var collation) ? collation : string.Empty;

    /// <summary>
    /// Looks up nodes by key name and typed key value using XPath <c>eq</c>-style comparison.
    /// Results are returned in document order and deduplicated.
    /// </summary>
    public IEnumerable<IXdmNode> Lookup(string keyName, XdmValue keyValue)
    {
        if (!_index.TryGetValue(keyName, out var entries))
            yield break;

        var matches = new List<KeyEntry>();
        foreach (var entry in entries)
        {
            if (entry.IsComposite)
                continue;
            if (KeyValuesEqual(entry.KeyValues[0], keyValue, GetCollation(keyName)))
                matches.Add(entry);
        }

        matches.Sort((a, b) => a.Node.DocumentOrder.CompareTo(b.Node.DocumentOrder));
        var seen = new HashSet<IXdmNode>();
        foreach (var entry in matches)
        {
            if (seen.Add(entry.Node))
                yield return entry.Node;
        }
    }

    /// <summary>
    /// Looks up nodes by key name and a composite key tuple.
    /// Results are returned in document order and deduplicated.
    /// </summary>
    public IEnumerable<IXdmNode> LookupComposite(string keyName, XdmValue[] keyValues)
    {
        if (keyValues.Length == 0)
            yield break;

        if (!_index.TryGetValue(keyName, out var entries))
            yield break;

        var matches = new List<KeyEntry>();
        foreach (var entry in entries)
        {
            if (!entry.IsComposite)
                continue;
            if (entry.KeyValues.Length != keyValues.Length)
                continue;
            bool same = true;
            for (int i = 0; i < keyValues.Length; i++)
            {
                if (!KeyValuesEqual(entry.KeyValues[i], keyValues[i], GetCollation(keyName)))
                {
                    same = false;
                    break;
                }
            }
            if (same)
                matches.Add(entry);
        }

        matches.Sort((a, b) => a.Node.DocumentOrder.CompareTo(b.Node.DocumentOrder));
        var seen = new HashSet<IXdmNode>();
        foreach (var entry in matches)
        {
            if (seen.Add(entry.Node))
                yield return entry.Node;
        }
    }

    /// <summary>
    /// Compares two key values using the same rules as the XPath <c>eq</c> operator,
    /// including untyped-atomic casting, numeric promotion, and the supplied collation
    /// for string comparisons.
    /// </summary>
    private static bool KeyValuesEqual(XdmValue a, XdmValue b, string collation)
    {
        if (a.IsUndefined || b.IsUndefined)
            return false;

        var aKind = a.Kind;
        var bKind = b.Kind;

        // Both numeric: compare numeric values.
        if (IsNumeric(aKind) && IsNumeric(bKind))
        {
            double da = aKind switch
            {
                XdmValueKind.Integer => a.IntegerValue,
                XdmValueKind.Decimal => (double)a.DecimalValue,
                _ => a.DoubleValue
            };
            double db = bKind switch
            {
                XdmValueKind.Integer => b.IntegerValue,
                XdmValueKind.Decimal => (double)b.DecimalValue,
                _ => b.DoubleValue
            };
            if (double.IsNaN(da) || double.IsNaN(db))
                return false;
            return da == db;
        }

        // Same kind exact comparison.
        if (aKind == bKind)
        {
            switch (aKind)
            {
                case XdmValueKind.String:
                    return FunctionLibrary.CompareStrings(a.ToString(), b.ToString(), collation) == 0;
                case XdmValueKind.Boolean:
                    return a.ToString() == b.ToString();
                case XdmValueKind.DateTime:
                case XdmValueKind.Date:
                case XdmValueKind.Time:
                    return NormalizeDateTime(a, aKind) == NormalizeDateTime(b, bKind);
                case XdmValueKind.Duration:
                    return string.Equals(a.ToString(), b.ToString(), StringComparison.Ordinal);
                case XdmValueKind.QName:
                    var qa = a.QNameValue;
                    var qb = b.QNameValue;
                    return qa.LocalName == qb.LocalName && qa.NamespaceUri == qb.NamespaceUri;
                case XdmValueKind.Uri:
                    return FunctionLibrary.CompareStrings(a.ToString(), b.ToString(), collation) == 0;
            }
        }

        // untypedAtomic on either side: cast to the other operand's type.
        if (IsUntypedAtomic(a))
            return UntypedAtomicEqualsOther(a, b, collation);
        if (IsUntypedAtomic(b))
            return UntypedAtomicEqualsOther(b, a, collation);

        // String / URI cross-comparison.
        if ((aKind == XdmValueKind.String || aKind == XdmValueKind.Uri) &&
            (bKind == XdmValueKind.String || bKind == XdmValueKind.Uri))
        {
            return FunctionLibrary.CompareStrings(a.ToString(), b.ToString(), collation) == 0;
        }

        return false;
    }

    private static bool IsNumeric(XdmValueKind kind)
        => kind is XdmValueKind.Integer or XdmValueKind.Decimal or XdmValueKind.Double or XdmValueKind.Float;

    private static bool IsUntypedAtomic(XdmValue value)
        => value.Kind == XdmValueKind.String &&
           string.Equals(value.SchemaTypeName, "untypedAtomic", StringComparison.OrdinalIgnoreCase);

    private static DateTimeOffset NormalizeDateTime(XdmValue value, XdmValueKind kind)
    {
        var dt = kind switch
        {
            XdmValueKind.DateTime => value.DateTimeValue,
            XdmValueKind.Date => value.DateValue,
            XdmValueKind.Time => value.TimeValue,
            _ => throw new InvalidOperationException()
        };
        return dt.ToUniversalTime();
    }

    private static bool UntypedAtomicEqualsOther(XdmValue untyped, XdmValue other, string collation)
    {
        // XSLT key() treats xs:untypedAtomic values as strings for comparison purposes:
        // they match string lookups but do not cast to numeric, boolean, or date/time types.
        var s = untyped.ToString();
        if (other.Kind is XdmValueKind.String or XdmValueKind.Uri)
            return FunctionLibrary.CompareStrings(s, other.ToString(), collation) == 0;
        return false;
    }

    /// <summary>
    /// Builds the index for a source document against the given stylesheet key definitions.
    /// </summary>
    public static KeyIndex Build(IXdmNode sourceDocument, IEnumerable<Stylesheet.KeyDefinition> keyDefinitions, EvaluationContext context)
        => Build(sourceDocument, keyDefinitions, context, new KeyIndex());

    /// <summary>
    /// Builds the index into an existing <see cref="KeyIndex"/> instance, allowing
    /// recursive <c>key()</c> calls inside <c>xsl:key/@use</c> to access already-built keys.
    /// </summary>
    public static KeyIndex Build(IXdmNode sourceDocument, IEnumerable<Stylesheet.KeyDefinition> keyDefinitions, EvaluationContext context, KeyIndex index)
    {
        var patternCompiler = new Patterns.PatternCompiler(context);

        foreach (var keyDef in keyDefinitions)
        {
            BuildSingleKey(sourceDocument, keyDef, context, index, patternCompiler);
        }

        return index;
    }

    /// <summary>
    /// Builds a single key definition into the given index, walking the document tree once.
    /// </summary>
    /// <param name="sourceDocument">The document to index.</param>
    /// <param name="keyDef">The declaring key definition.</param>
    /// <param name="context">The evaluation context whose focus is restored after indexing.</param>
    /// <param name="index">The target index.</param>
    /// <param name="expressionCompiler">The host compiler for declaration-context use expressions.</param>
    public static void BuildSingleKey(IXdmNode sourceDocument, Stylesheet.KeyDefinition keyDef, EvaluationContext context, KeyIndex index,
        Func<string, XElement, XPath31Expression>? expressionCompiler = null)
    {
        var patternCompiler = new Patterns.PatternCompiler(context);
        BuildSingleKey(sourceDocument, keyDef, context, index, patternCompiler, expressionCompiler);
    }

    private static void BuildSingleKey(IXdmNode sourceDocument, Stylesheet.KeyDefinition keyDef, EvaluationContext context, KeyIndex index,
        Patterns.PatternCompiler patternCompiler, Func<string, XElement, XPath31Expression>? expressionCompiler = null)
    {
        var declaration = keyDef.Element ?? keyDef.Stylesheet.Root;
        var defaultNs = Stylesheet.Stylesheet.GetXPathDefaultNamespace(declaration);
        var compiledMatch = CompileMatch(keyDef, patternCompiler, defaultNs);
        var useExpr = string.IsNullOrEmpty(keyDef.Use)
            ? null
            : expressionCompiler is not null ? expressionCompiler(keyDef.Use, declaration)
                : CompileUseExpression(keyDef, defaultNs, context);

        IndexNodes(sourceDocument, keyDef.Name, compiledMatch, useExpr, keyDef.Composite, context, index);
    }

    private static Patterns.PatternPredicate CompileMatch(Stylesheet.KeyDefinition keyDef, Patterns.PatternCompiler compiler, string? defaultNs)
    {
        var declaration = keyDef.Element ?? keyDef.Stylesheet.Root;
        var namespaces = Stylesheet.Stylesheet.GetApplicableStaticNamespaces(declaration);
        var compatibility = keyDef.Stylesheet.GetXPathCompatibility(declaration);
        var owner = keyDef.Stylesheet.OwningPackage ?? keyDef.Stylesheet;
        Patterns.PatternCompiler.ValidateNamespacePrefixes(keyDef.Match, namespaces);
        return compiler.Compile(keyDef.Match, defaultNs, namespaces: namespaces, compatibility: compatibility,
            itemTypeAliases: compatibility >= XPathCompatibility.XPath40 ? owner.GetBindingItemTypes() : null,
            namedRecordTypeNames: compatibility >= XPathCompatibility.XPath40 ? owner.GetNamedRecordTypes().Keys.ToHashSet(StringComparer.Ordinal) : null);
    }

    private static XPath31Expression CompileUseExpression(Stylesheet.KeyDefinition keyDef, string? defaultElementNamespace, EvaluationContext context)
    {
        var declaration = keyDef.Element ?? keyDef.Stylesheet.Root;
        var options = new CompileOptions
        {
            DefaultElementNamespace = defaultElementNamespace,
            DefiningElementDefaultNamespace = declaration.GetDefaultNamespace().NamespaceName,
            Namespaces = Stylesheet.Stylesheet.GetApplicableStaticNamespaces(declaration),
            Compatibility = keyDef.Stylesheet.GetXPathCompatibility(declaration),
            BackwardsCompatible = keyDef.Stylesheet.GetEffectiveVersion(declaration) < 2.0,
            SchemaSet = context.SchemaSet
        };
        return XPath31Expression.Compile(keyDef.Use!, options);
    }

    /// <summary>
    /// Builds a single key definition whose use value is supplied by a callback rather than @use.
    /// </summary>
    public static void BuildSingleKey(IXdmNode sourceDocument, Stylesheet.KeyDefinition keyDef, EvaluationContext context, KeyIndex index, Func<IXdmNode, XdmValue> useEvaluator)
    {
        var patternCompiler = new Patterns.PatternCompiler(context);
        var defaultNs = Bosak.Xslt.Stylesheet.Stylesheet.GetXPathDefaultNamespace(keyDef.Element!);
        var compiledMatch = CompileMatch(keyDef, patternCompiler, defaultNs);

        IndexNodes(sourceDocument, keyDef.Name, compiledMatch, useEvaluator, keyDef.Composite, context, index);
    }

    private static void IndexNodes(IXdmNode node, string keyName, Patterns.PatternPredicate match, XPath31Expression? useExpr, bool composite, EvaluationContext context, KeyIndex index)
    {
        TryIndexNode(node, keyName, match, useExpr, composite, context, index);

        if (node.NodeKind == XdmNodeKind.Element)
        {
            // Attributes can match xsl:key/@match patterns such as @id.
            foreach (var attr in node.Attributes())
            {
                if (attr.IsNode && attr.NodeValue != null)
                    TryIndexNode(attr.NodeValue, keyName, match, useExpr, composite, context, index);
            }

            // Namespace nodes can match xsl:key/@match patterns such as namespace-node().
            foreach (var ns in node.Axis(XdmAxis.Namespace))
            {
                if (ns.IsNode && ns.NodeValue != null)
                    TryIndexNode(ns.NodeValue, keyName, match, useExpr, composite, context, index);
            }
        }

        foreach (var child in node.Axis(XdmAxis.Child))
        {
            if (child.NodeValue != null)
                IndexNodes(child.NodeValue, keyName, match, useExpr, composite, context, index);
        }
    }

    private static void IndexNodes(IXdmNode node, string keyName, Patterns.PatternPredicate match, Func<IXdmNode, XdmValue> useEvaluator, bool composite, EvaluationContext context, KeyIndex index)
    {
        TryIndexNode(node, keyName, match, useEvaluator, composite, context, index);

        if (node.NodeKind == XdmNodeKind.Element)
        {
            foreach (var attr in node.Attributes())
            {
                if (attr.IsNode && attr.NodeValue != null)
                    TryIndexNode(attr.NodeValue, keyName, match, useEvaluator, composite, context, index);
            }

            foreach (var ns in node.Axis(XdmAxis.Namespace))
            {
                if (ns.IsNode && ns.NodeValue != null)
                    TryIndexNode(ns.NodeValue, keyName, match, useEvaluator, composite, context, index);
            }
        }

        foreach (var child in node.Axis(XdmAxis.Child))
        {
            if (child.NodeValue != null)
                IndexNodes(child.NodeValue, keyName, match, useEvaluator, composite, context, index);
        }
    }

    private static void TryIndexNode(IXdmNode node, string keyName, Patterns.PatternPredicate match, XPath31Expression? useExpr, bool composite, EvaluationContext context, KeyIndex index)
    {
        if (match(XdmValue.FromNode(node), context))
        {
            // XSLT 3.0 says the node being indexed is the current item for the
            // xsl:key/@use expression, so fn:current() returns that node.
            var savedItem = context.ContextItem;
            var savedPosition = context.ContextPosition;
            var savedSize = context.ContextSize;
            var savedCurrent = context.CurrentItem;
            try
            {
                context.WithFocus(XdmValue.FromNode(node), 1, 1)
                       .WithCurrentItem(XdmValue.FromNode(node));

                var keyValues = useExpr != null
                    ? useExpr.Evaluate(context)
                    : XdmValue.Undefined;
                AddKeyValues(index, keyName, keyValues, node, composite, context.BackwardsCompatible);
            }
            finally
            {
                context.WithFocus(savedItem, savedPosition, savedSize)
                       .WithCurrentItem(savedCurrent);
            }
        }
    }

    private static void TryIndexNode(IXdmNode node, string keyName, Patterns.PatternPredicate match, Func<IXdmNode, XdmValue> useEvaluator, bool composite, EvaluationContext context, KeyIndex index)
    {
        if (match(XdmValue.FromNode(node), context))
        {
            var savedItem = context.ContextItem;
            var savedPosition = context.ContextPosition;
            var savedSize = context.ContextSize;
            var savedCurrent = context.CurrentItem;
            try
            {
                context.WithFocus(XdmValue.FromNode(node), 1, 1)
                       .WithCurrentItem(XdmValue.FromNode(node));

                var keyValues = useEvaluator(node);
                AddKeyValues(index, keyName, keyValues, node, composite, context.BackwardsCompatible);
            }
            finally
            {
                context.WithFocus(savedItem, savedPosition, savedSize)
                       .WithCurrentItem(savedCurrent);
            }
        }
    }

    private static void AddKeyValues(KeyIndex index, string keyName, XdmValue keyValues, IXdmNode node, bool composite, bool backwardsCompatible = false)
    {
        if (keyValues.IsUndefined)
            return;

        var items = new List<XdmValue>();
        if (keyValues.IsSequence && keyValues.SequenceValue != null)
        {
            foreach (var item in XdmSequence.FromSource(keyValues.SequenceValue))
            {
                if (!item.IsUndefined)
                    items.Add(AtomizeKeyValue(item, backwardsCompatible));
            }
        }
        else
        {
            items.Add(AtomizeKeyValue(keyValues, backwardsCompatible));
        }

        if (items.Count == 0)
            return;

        if (composite)
        {
            index.AddComposite(keyName, items.ToArray(), node);
        }
        else
        {
            foreach (var item in items)
                index.Add(keyName, item, node);
        }
    }

    private static XdmValue AtomizeKeyValue(XdmValue value, bool backwardsCompatible)
    {
        if (value.IsNode)
        {
            // Schema-annotated nodes contribute their PSVI typed value (e.g. a NOTATION-typed
            // attribute indexes by its QName value — notation-0305); unvalidated nodes atomize
            // to xs:untypedAtomic. XPath 1.0 backwards compatibility keeps the string form.
            var node = value.NodeValue;
            if (!backwardsCompatible && node.SchemaTypeAnnotation is not null && !node.HasNoTypedValue)
            {
                var typed = node.TypedValue;
                if (!(typed.Kind == XdmValueKind.String && typed.SchemaTypeName is null))
                    return typed;
            }
            return XdmValue.FromString(value.ToString(), "untypedAtomic");
        }
        // XPath 1.0 backwards compatibility: key values are strings.
        if (backwardsCompatible)
            return XdmValue.FromString(value.ToString(), "untypedAtomic");
        return value;
    }

}
