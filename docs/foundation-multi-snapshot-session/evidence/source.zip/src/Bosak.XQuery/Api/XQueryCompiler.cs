// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 06 June 2026
// PURPOSE              : Compiles XQuery 3.1 source into an executable query plan.
// SPECIAL NOTES        : Part of the Bosak XQuery 3.1 implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 06-06-2026     | Creation — placeholder skeleton                                                          |
//                      | Charles Korthout | 1.0   | 22-07-2026     | Wired to XPath parser, optimizer, IR lowerer, and VM                                    |
//                      | Charles Korthout | 1.1   | 22-07-2026     | Resolve function namespaces inside FlworExpressionNode clauses                        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.2   | 25-07-2026     | Resolve function namespaces inside GroupByClauseNode specs                              |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.3   | 25-07-2026     | Resolve function namespaces inside WindowClauseNode conditions                          |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.4   | 25-07-2026     | Optional window end condition                                                           |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.5   | 25-07-2026     | Resolve function namespaces inside DirectElementConstructorNode parts                   |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.6   | 25-07-2026     | Resolve function namespaces inside computed constructors                                |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.7   | 25-07-2026     | Resolve function namespaces inside switch/typeswitch expressions                        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.8   | 25-07-2026     | Optional XML 1.1 line-ending normalization flag threaded to the parser                  |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.9   | 26-07-2026     | Compile prolog declare function/variable bodies into CompiledUserFunction/CompiledUserVariable records |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.0   | 27-07-2026     | Library modules: WithModule catalog, transitive import graph (XQST0059), visibility validation, per-module compilation |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.1   | 27-07-2026     | Namespace resolution traversal for multi-clause TryCatchNode |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.2   | 27-07-2026     | Namespace resolution traversal for StringConstructorNode |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.3   | 27-07-2026     | Thread prolog default order empty into the IR lowerer |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.4   | 29-07-2026     | WithEnforcedType wraps typed variable initializers with a strict EnforceType check |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.5   | 29-07-2026     | Variable initializers exclude the variable being declared (XPST0008 self-reference) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.6   | 01-08-2026     | Registered module sources flow to the executable for fn:load-xquery-module           |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.7   | 01-08-2026     | ModuleRuntimeContext carries decimal formats for module-local format declarations    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.8   | 07-08-2026     | Library-module context item type declarations flow to the executable for initial context item validation (contextDecl-054) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 2.9   | 07-08-2026     | Statically unresolvable names collected from all bodies flow to the executable's evaluation-time check |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 3.0   | 22-08-2026     | Resolve function namespaces inside XQuery validate expressions |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 3.1   | 07-09-2026     | Static name-test validation (XPST0081/XPST0008) of the main module body against the p... |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 3.2   | 07-09-2026     | WithNamespace seeds host-environment namespace bindings into the static context (prolog wins) |
//                      | Charles Korthout | 3.3   | 21-09-2026     | API freeze stage A: ParseException renamed to XPathParseException                      |
//                      | Charles Korthout | 3.4   | 21-09-2026     | API freeze stage C: internalized XQueryModuleSource record                              |
//                      |==================|=======|================|=========================================================================================
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 3.5   | 08-10-2026     | REQ-118 4.0-S4: ResolveFunctionNamespaces for PipelineExprNode
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 3.5   | 28-10-2026     | Compile main context initializers with complete prolog visibility (1.30.0).              |
//                      | Charles Korthout | 3.6   | 28-10-2026     | Retain every library context constraint with its declaring type namespace (1.30.1).      |
//                      | Charles Korthout | 3.7   | 28-10-2026     | Compile module-local namespace-copy modes for bodies, initializers and functions (1.31.0). |
//                      | Charles Korthout | 3.8   | 28-10-2026     | Compile declaring-module construction modes for bodies and declarations (1.32.0). |
//                      | Charles Korthout | 3.9  | 28-10-2026     | Implement statically validated ignored-pragma fallback and raw scanning (1.33.0). |
//                      | Charles Korthout | 3.10  | 01-11-2026     | Freeze private registered modules and namespace settings before binding. |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using Bosak.XPath.Api;
using Bosak.XPath.Compiler.Ir;
using Bosak.XPath.Compiler.Optimizer;
using Bosak.XPath.Compiler;
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Parser;
using Bosak.XPath.Parser.Ast;
using Bosak.XPath.Runtime.Vm;
using Bosak.XQuery.Compiler;

using System.Text.Json;

namespace Bosak.XQuery.Api;

/// <summary>A library module source registered with the compiler: its target namespace URI,
/// an optional location hint (matched by <c>import module ... at "..."</c>), and the source text.</summary>
internal sealed record XQueryModuleSource(string Uri, string? Location, string Source);

/// <summary>
/// Compiles XQuery 3.1 source text into an <see cref="XQueryExecutable"/> that can be executed repeatedly.
/// </summary>
public sealed class XQueryCompiler
{
    private readonly List<XQueryModuleSource> _moduleSources = new();
    private readonly Dictionary<string, string> _externalNamespaces = new(StringComparer.Ordinal);

    /// <summary>
    /// Registers a library module source that can satisfy a module import of
    /// <paramref name="uri"/> (optionally selected by a <paramref name="location"/> hint).
    /// </summary>
    /// <param name="uri">The module's target namespace URI.</param>
    /// <param name="source">The library module source text (<c>module namespace ...;</c>).</param>
    /// <param name="location">An optional location hint matched by the import's <c>at</c> clause.</param>
    /// <returns>The same compiler, for chaining.</returns>
    public XQueryCompiler WithModule(string uri, string source, string? location = null)
    {
        ArgumentNullException.ThrowIfNull(uri);
        ArgumentNullException.ThrowIfNull(source);
        _moduleSources.Add(new XQueryModuleSource(
            XQueryParser.NormalizeModuleUri(uri),
            location is null ? null : XQueryParser.NormalizeModuleUri(location),
            source));
        return this;
    }

    /// <summary>
    /// Declares a namespace binding in the static context of the compiled query, as a
    /// host environment would (e.g. QT3 test drivers pre-binding environment namespaces).
    /// A binding declared by the query prolog itself takes precedence over an external one.
    /// </summary>
    /// <param name="prefix">The namespace prefix to bind.</param>
    /// <param name="uri">The namespace URI the prefix expands to.</param>
    /// <returns>The same compiler, for chaining.</returns>
    public XQueryCompiler WithNamespace(string prefix, string uri)
    {
        ArgumentNullException.ThrowIfNull(prefix);
        ArgumentNullException.ThrowIfNull(uri);
        _externalNamespaces[prefix] = uri;
        return this;
    }

    /// <summary>
    /// Compiles the supplied XQuery source text.
    /// </summary>
    /// <param name="query">The XQuery 3.1 source text.</param>
    /// <param name="xml11LineEndings">When true, string literals get XML 1.1 line-ending normalization.</param>
    /// <returns>An executable query plan.</returns>
    public XQueryExecutable Compile(string query, bool xml11LineEndings = false)
    {
        ArgumentException.ThrowIfNullOrEmpty(query);

        // 1. Parse the XQuery module (prolog + query body).
        var parseResult = XQueryParser.Parse(query, xml11LineEndings);
        // XPST0003: a library module cannot be evaluated as a query.
        if (parseResult.IsLibraryModule)
            throw new XPathParseException("XPST0003: A library module ('module namespace ...') cannot be evaluated as a query.", 0);

        // 1b. External (host-environment) namespace bindings seed the static context;
        // prolog declarations take precedence and are never overwritten.
        if (_externalNamespaces.Count > 0)
        {
            var seeded = parseResult.StaticContext;
            foreach (var (prefix, uri) in _externalNamespaces)
            {
                if (!seeded.Namespaces.ContainsKey(prefix))
                    seeded = seeded.WithNamespace(prefix, uri);
            }
            if (!ReferenceEquals(seeded, parseResult.StaticContext))
                parseResult = new XQueryParseResult(seeded, parseResult.Body, parseResult.IsLibraryModule);
        }

        // 2. Load the transitive closure of imported library modules, keyed by target namespace.
        var moduleGraph = new Dictionary<string, List<XQueryParseResult>>(StringComparer.Ordinal);
        var loadedSources = new Dictionary<string, HashSet<string>>(StringComparer.Ordinal);
        var loading = new HashSet<string>(StringComparer.Ordinal);
        foreach (var import in parseResult.StaticContext.ImportedModules)
            LoadModuleNamespace(import.NamespaceUri, import.LocationHints, moduleGraph, loadedSources, loading, xml11LineEndings);
        var moduleNamespaces = new HashSet<string>(moduleGraph.Keys, StringComparer.Ordinal);

        // 3. Resolve function-call namespaces using the static context derived from the prolog.
        var resolvedBody = ResolveFunctionNamespaces(parseResult.Body, parseResult.StaticContext);

        // 3c. Static name-test validation (XPST0081 for undeclared prefixes; XPST0008 for
        //     schema-aware kind tests) against the prolog's statically known namespaces.
        StaticNameTestValidator.Validate(resolvedBody, prefix =>
            parseResult.StaticContext.Namespaces.TryGetValue(prefix, out var nsUri) ? nsUri : null);

        // 3b. Validate module-namespace references (public visibility, imports not transitive)
        //     and collect statically unresolvable names for the evaluation-time check.
        var unresolvedNames = new ModuleVisibilityValidator.UnresolvedNameReferences();
        var mainVisibility = BuildVisibility(parseResult.StaticContext, moduleGraph);
        unresolvedNames.Merge(ModuleVisibilityValidator.Validate(
            resolvedBody, parseResult.StaticContext, moduleNamespaces,
            mainVisibility.Functions, mainVisibility.Variables));

        // 4. Optimize the AST.
        var optimizer = new XPathOptimizer();
        var optimized = optimizer.Optimize(resolvedBody);

        // 4b. Compile user-declared function and variable bodies through the same pipeline.
        var userFunctions = new List<CompiledUserFunction>();
        var userVariables = new List<CompiledUserVariable>();
        CompileModuleDeclarations(
            parseResult.StaticContext, moduleGraph, moduleNamespaces, mainVisibility,
            optimizer, userFunctions, userVariables, moduleRuntimeContext: null, unresolvedNames);

        // 4c. Compile every loaded library module's declarations with its own static context.
        foreach (var (ns, modules) in moduleGraph)
        {
            foreach (var libModule in modules)
            {
                var libContext = libModule.StaticContext;
                var libVisibility = BuildVisibility(libContext, moduleGraph);
                var libRuntimeContext = new ModuleRuntimeContext(
                    libContext.Namespaces, libContext.BaseUri,
                    libContext.DefaultElementNamespace, libContext.DefaultCollation,
                    libContext.DecimalFormats, libContext.DeclaredDefaultDecimalFormat);
                CompileModuleDeclarations(
                    libContext, moduleGraph, moduleNamespaces, libVisibility,
                    optimizer, userFunctions, userVariables, libRuntimeContext, unresolvedNames);
            }
        }

        // 5. Lower to IR.
        var lowerer = new IrLowerer { DefaultEmptyOrder = ToEmptyOrder(parseResult.StaticContext.DefaultEmptyOrderLeast), PreserveNamespaces = parseResult.StaticContext.PreserveNamespaces ?? true, InheritNamespaces = parseResult.StaticContext.InheritNamespaces ?? true, ConstructionMode = parseResult.StaticContext.ConstructionMode ?? XdmConstructionMode.Preserve };
        var module = lowerer.Lower(optimized);

        // The context item type declared by each loaded library module constrains the
        // initial context item at evaluation time (XQuery 3.1 §4.14; contextDecl-054).
        var libraryModuleContextItemTypes = moduleGraph.Values
            .SelectMany(modules => modules)
            .Where(m => m.StaticContext.ContextItemTypeName is not null)
            .Select(m => new LibraryContextItemConstraint(m.StaticContext))
            .ToList();

        IrModule? contextInitializer = null;
        if (parseResult.StaticContext.ContextDeclaration?.Initializer is { } initializer)
        {
            var resolvedInitializer = ResolveFunctionNamespaces(initializer, parseResult.StaticContext);
            StaticNameTestValidator.Validate(resolvedInitializer, prefix =>
                parseResult.StaticContext.Namespaces.TryGetValue(prefix, out var uri) ? uri : null);
            unresolvedNames.Merge(ModuleVisibilityValidator.Validate(
                resolvedInitializer, parseResult.StaticContext, moduleNamespaces,
                mainVisibility.Functions, mainVisibility.Variables));
            contextInitializer = new IrLowerer { DefaultEmptyOrder = ToEmptyOrder(parseResult.StaticContext.DefaultEmptyOrderLeast), PreserveNamespaces = parseResult.StaticContext.PreserveNamespaces ?? true, InheritNamespaces = parseResult.StaticContext.InheritNamespaces ?? true, ConstructionMode = parseResult.StaticContext.ConstructionMode ?? XdmConstructionMode.Preserve }
                .Lower(optimizer.Optimize(resolvedInitializer));
        }

        return new XQueryExecutable(module, parseResult.StaticContext, userFunctions, userVariables, _moduleSources, libraryModuleContextItemTypes, unresolvedNames, contextInitializer);
    }

    internal bool TryCaptureSchemaCompilation(string query, bool xml11LineEndings, out XQueryExecutable? executable,
        out SchemaQueryEnvironment? environment, out string? unsupported)
    {
        executable = null; environment = null; unsupported = null;
        var modules = _moduleSources.ToArray();
        var namespaces = _externalNamespaces.ToArray();
        if (XQueryParser.Parse(query, xml11LineEndings).StaticContext.ImportedSchemas.Count != 0
            || modules.Any(m => XQueryParser.Parse(m.Source, xml11LineEndings).StaticContext.ImportedSchemas.Count != 0))
        { unsupported = "Schema imports need a separate immutable provider capture profile."; return false; }
        var frozen = new XQueryCompiler();
        foreach (var pair in namespaces) frozen._externalNamespaces.Add(pair.Key, pair.Value);
        // Registered records already contain normalized URIs; do not normalize them twice.
        frozen._moduleSources.AddRange(modules);
        executable = frozen.Compile(query, xml11LineEndings);
        environment = executable.CaptureSchemaEnvironment(JsonSerializer.Serialize(new
        {
            query, xml11LineEndings,
            namespaces = namespaces.OrderBy(p => p.Key, StringComparer.Ordinal).Select(p => new[] { p.Key, p.Value }).ToArray(),
            modules = modules.Select(m => new { m.Uri, m.Location, m.Source }).ToArray()
        }));
        return true;
    }

    private static EmptyOrder? ToEmptyOrder(bool? least)
        => least is null ? null : (least.Value ? EmptyOrder.Least : EmptyOrder.Greatest);

    /// <summary>The runtime static-context snapshot of a library module, applied around the
    /// execution of its function bodies and global variable initializers (null for the main module).</summary>
    internal sealed record ModuleRuntimeContext(
        IReadOnlyDictionary<string, string> Namespaces,
        string? BaseUri,
        string? DefaultElementNamespace,
        string? DefaultCollation,
        IReadOnlyDictionary<(string LocalName, string NamespaceUri), DecimalFormat> DecimalFormats,
        DecimalFormat? DeclaredDefaultDecimalFormat);

    private sealed record VisibilitySet(
        HashSet<(string Ns, string Local, int Arity)> Functions,
        HashSet<(string Ns, string Local)> Variables);

    // Resolves one module import to registered sources and parses them, recursing into the
    // imports of every newly loaded module. Import cycles between modules are legal and
    // terminate through the in-progress set. Multiple modules may share one target namespace;
    // a namespace already in the graph is extended incrementally when a later import (via a
    // different route, with different location hints) names additional sources.
    private void LoadModuleNamespace(
        string ns,
        IReadOnlyList<string> locationHints,
        Dictionary<string, List<XQueryParseResult>> graph,
        Dictionary<string, HashSet<string>> loadedSources,
        HashSet<string> loading,
        bool xml11LineEndings)
    {
        if (!loading.Add(ns))
            return; // import cycle in progress; the namespace is already being loaded
        try
        {
            var candidates = _moduleSources.Where(m => m.Uri == ns).ToList();
            if (locationHints.Count > 0)
            {
                var hinted = candidates
                    .Where(m => m.Location is not null && locationHints.Contains(m.Location, StringComparer.Ordinal))
                    .ToList();
                if (hinted.Count > 0)
                    candidates = hinted;
            }

            var seen = loadedSources.TryGetValue(ns, out var existingSeen)
                ? existingSeen
                : (loadedSources[ns] = new HashSet<string>(StringComparer.Ordinal));
            var loaded = graph.TryGetValue(ns, out var existingLoaded)
                ? existingLoaded
                : (graph[ns] = new List<XQueryParseResult>());

            var added = new List<XQueryParseResult>();
            foreach (var candidate in candidates)
            {
                if (!seen.Add(candidate.Source))
                    continue;
                var parsed = XQueryParser.Parse(candidate.Source, xml11LineEndings);
                // A module whose own target namespace does not match the import is not a candidate.
                if (!parsed.IsLibraryModule || parsed.StaticContext.ModuleNamespaceUri != ns)
                {
                    seen.Remove(candidate.Source);
                    continue;
                }
                loaded.Add(parsed);
                added.Add(parsed);
            }
            // XQST0059: the import cannot be satisfied by any registered module.
            if (loaded.Count == 0)
                throw new XPathParseException($"XQST0059: Unable to locate a library module with target namespace '{ns}'.", 0);

            // XQST0034/XQST0049: modules sharing one target namespace must not declare the
            // same function (name+arity) or variable.
            var functionKeys = new HashSet<(string, int)>();
            var variableKeys = new HashSet<string>(StringComparer.Ordinal);
            foreach (var module in loaded)
            {
                foreach (var fn in module.StaticContext.UserFunctions)
                {
                    if (!functionKeys.Add((fn.LocalName, fn.Parameters.Count)))
                        throw new XPathParseException($"XQST0034: Function '{fn.LocalName}' with arity {fn.Parameters.Count} is declared more than once in module namespace '{ns}'.", fn.Position);
                }
                foreach (var v in module.StaticContext.UserVariables)
                {
                    if (!variableKeys.Add(v.LocalName))
                        throw new XPathParseException($"XQST0049: Variable '${v.LocalName}' is declared more than once in module namespace '{ns}'.", v.Position);
                }
            }

            foreach (var module in added)
            {
                foreach (var import in module.StaticContext.ImportedModules)
                    LoadModuleNamespace(import.NamespaceUri, import.LocationHints, graph, loadedSources, loading, xml11LineEndings);
            }
        }
        finally
        {
            loading.Remove(ns);
        }
    }

    // Builds the visible declarations for one module: its own declarations (public and
    // private) plus the public declarations of all loaded modules in the namespaces it
    // directly imports. Also enforces XQST0034/XQST0049 collisions between the module's
    // own declarations and the declarations exposed by its imports.
    private static VisibilitySet BuildVisibility(
        XQueryStaticContext context,
        IReadOnlyDictionary<string, List<XQueryParseResult>> graph)
    {
        var functions = new HashSet<(string, string, int)>();
        var variables = new HashSet<(string, string)>();
        foreach (var fn in context.UserFunctions)
            functions.Add((fn.NamespaceUri, fn.LocalName, fn.Parameters.Count));
        foreach (var v in context.UserVariables)
            variables.Add((v.NamespaceUri, v.LocalName));

        foreach (var import in context.ImportedModules)
        {
            if (!graph.TryGetValue(import.NamespaceUri, out var modules))
                continue;
            foreach (var module in modules)
            {
                // A module that (transitively) imports its own target namespace must not
                // collide with itself (XQST0093a: self-import is legal).
                if (ReferenceEquals(module.StaticContext, context))
                    continue;
                foreach (var fn in module.StaticContext.UserFunctions)
                {
                    if (fn.IsPrivate)
                        continue;
                    // XQST0034: an own declaration collides with an imported one.
                    if (context.UserFunctions.Any(own =>
                            own.LocalName == fn.LocalName && own.NamespaceUri == fn.NamespaceUri
                            && own.Parameters.Count == fn.Parameters.Count))
                    {
                        throw new XPathParseException($"XQST0034: Function '{fn.LocalName}' with arity {fn.Parameters.Count} is declared more than once.", fn.Position);
                    }
                    functions.Add((fn.NamespaceUri, fn.LocalName, fn.Parameters.Count));
                }
                foreach (var v in module.StaticContext.UserVariables)
                {
                    if (v.IsPrivate)
                        continue;
                    // XQST0049: an own declaration collides with an imported one.
                    if (context.UserVariables.Any(own => own.LocalName == v.LocalName && own.NamespaceUri == v.NamespaceUri))
                        throw new XPathParseException($"XQST0049: Variable '${v.LocalName}' is declared more than once.", v.Position);
                    variables.Add((v.NamespaceUri, v.LocalName));
                }
            }
        }
        return new VisibilitySet(functions, variables);
    }

    // Validates and compiles one module's user-declared functions and variables. Bodies are
    // compiled with the declaring module's static context; library module declarations carry
    // the module's runtime context so their bodies execute with its namespaces and base URI.
    private static void CompileModuleDeclarations(
        XQueryStaticContext context,
        IReadOnlyDictionary<string, List<XQueryParseResult>> moduleGraph,
        HashSet<string> moduleNamespaces,
        VisibilitySet visibility,
        XPathOptimizer optimizer,
        List<CompiledUserFunction> userFunctions,
        List<CompiledUserVariable> userVariables,
        ModuleRuntimeContext? moduleRuntimeContext,
        ModuleVisibilityValidator.UnresolvedNameReferences unresolvedNames)
    {
        foreach (var fn in context.UserFunctions)
        {
            var fnBodyAst = ResolveFunctionNamespaces(fn.Body, context);
            StaticNameTestValidator.ValidatePragmas(fnBodyAst, prefix => context.Namespaces.TryGetValue(prefix, out var uri) ? uri : null);
            unresolvedNames.Merge(ModuleVisibilityValidator.Validate(
                fnBodyAst, context, moduleNamespaces, visibility.Functions, visibility.Variables,
                fn.Parameters.Select(p => p.Name)));
            var fnModule = new IrLowerer { DefaultEmptyOrder = ToEmptyOrder(context.DefaultEmptyOrderLeast), PreserveNamespaces = context.PreserveNamespaces ?? true, InheritNamespaces = context.InheritNamespaces ?? true, ConstructionMode = context.ConstructionMode ?? XdmConstructionMode.Preserve }
                .Lower(optimizer.Optimize(fnBodyAst));
            userFunctions.Add(new CompiledUserFunction(
                fn.LocalName,
                fn.NamespaceUri,
                fn.Parameters.Select(p => p.Name).ToList(),
                fn.Parameters.Select(p => p.TypeName).ToList(),
                fn.ReturnType,
                fnModule,
                moduleRuntimeContext?.Namespaces,
                moduleRuntimeContext?.BaseUri,
                moduleRuntimeContext?.DefaultElementNamespace,
                moduleRuntimeContext?.DefaultCollation,
                moduleRuntimeContext?.DecimalFormats,
                moduleRuntimeContext?.DeclaredDefaultDecimalFormat));
        }
        foreach (var v in context.UserVariables)
        {
            IrModule? varModule = null;
            if (v.Body is not null)
            {
                var varBodyAst = ResolveFunctionNamespaces(v.Body, context);
                StaticNameTestValidator.ValidatePragmas(varBodyAst, prefix => context.Namespaces.TryGetValue(prefix, out var uri) ? uri : null);
                // A variable is not in scope within its own initializer (XPST0008,
                // K-InternalVariablesWith-15b).
                unresolvedNames.Merge(ModuleVisibilityValidator.Validate(
                    varBodyAst, context, moduleNamespaces, visibility.Functions, visibility.Variables,
                    excludeVariable: (v.LocalName, v.NamespaceUri)));
                varModule = new IrLowerer { DefaultEmptyOrder = ToEmptyOrder(context.DefaultEmptyOrderLeast), PreserveNamespaces = context.PreserveNamespaces ?? true, InheritNamespaces = context.InheritNamespaces ?? true, ConstructionMode = context.ConstructionMode ?? XdmConstructionMode.Preserve }
                    .Lower(optimizer.Optimize(varBodyAst));
                // A declared type is enforced strictly on the initializer: atomization plus
                // an instance check — no casts or promotions (XPTY0004, K2-ExternalVariablesWith-12..19).
                if (v.TypeName is not null)
                    varModule = WithEnforcedType(varModule, v.TypeName);
            }
            userVariables.Add(new CompiledUserVariable(
                v.LocalName, v.NamespaceUri, v.TypeName, varModule, v.IsExternal,
                moduleRuntimeContext?.Namespaces,
                moduleRuntimeContext?.BaseUri,
                moduleRuntimeContext?.DefaultElementNamespace,
                moduleRuntimeContext?.DefaultCollation,
                moduleRuntimeContext?.DecimalFormats,
                moduleRuntimeContext?.DeclaredDefaultDecimalFormat));
        }
    }

    // Splits a trailing occurrence indicator off a sequence-type text.
    private static (string TypeName, OccurrenceIndicator Occurrence) SplitOccurrence(string typeText)
    {
        var t = typeText.Trim();
        if (t.EndsWith('?')) return (t[..^1].TrimEnd(), OccurrenceIndicator.ZeroOrOne);
        if (t.EndsWith('*')) return (t[..^1].TrimEnd(), OccurrenceIndicator.ZeroOrMore);
        if (t.EndsWith('+')) return (t[..^1].TrimEnd(), OccurrenceIndicator.OneOrMore);
        return (t, OccurrenceIndicator.One);
    }

    // Appends an EnforceType check for the module's result register before its final Return.
    private static IrModule WithEnforcedType(IrModule module, string typeText)
    {
        var (typeName, occurrence) = SplitOccurrence(typeText);
        var instructions = module.Instructions.ToArray().ToList();
        var pool = module.LiteralPool.ToArray().ToList();
        var returnInstr = instructions[^1];
        pool.Add(new EnforceTypeInfo(typeName, occurrence, "XPTY0004"));
        instructions.Insert(instructions.Count - 1,
            new IrInstruction(IrOpCode.EnforceType, returnInstr.RegisterA, 0, 0, pool.Count - 1));
        return new IrModule(instructions.ToArray(), pool.ToArray(), module.MaxRegisterCount);
    }

    private const string DefaultFunctionNamespace = "http://www.w3.org/2005/xpath-functions";

    private static string? ResolvePrefix(string? prefix, XQueryStaticContext context)
    {
        if (string.IsNullOrEmpty(prefix))
            return context.DefaultFunctionNamespace ?? DefaultFunctionNamespace;

        if (context.Namespaces.TryGetValue(prefix, out var nsUri))
            return nsUri;

        return null;
    }

    private static XPathAstNode ResolveFunctionNamespaces(XPathAstNode node, XQueryStaticContext context)
    {
        return node switch
        {
            FunctionCallNode fc => ResolveFunctionCall(fc, context),
            NamedFunctionRefNode nf => ResolveNamedFunctionRef(nf, context),
            ParenthesizedExprNode p => p with { Expression = ResolveFunctionNamespaces(p.Expression, context) },
            PredicateNode pred => pred with { Expression = ResolveFunctionNamespaces(pred.Expression, context) },
            StepNode step => step with { Predicates = step.Predicates.Select(p => ResolveFunctionNamespaces(p, context)).ToList() },
            PathExprNode path => path with { Steps = path.Steps.Select(s => ResolveFunctionNamespaces(s, context)).ToList() },
            SequenceExpressionNode seq => seq with { Expressions = seq.Expressions.Select(e => ResolveFunctionNamespaces(e, context)).ToList() },
            RangeExpressionNode range => range with { From = ResolveFunctionNamespaces(range.From, context), To = ResolveFunctionNamespaces(range.To, context) },
            IfExpressionNode ife => ife with { Condition = ResolveFunctionNamespaces(ife.Condition, context), ThenBranch = ResolveFunctionNamespaces(ife.ThenBranch, context), ElseBranch = ResolveFunctionNamespaces(ife.ElseBranch, context) },
            ForExpressionNode fe => fe with { Bindings = fe.Bindings.Select(b => b with { Expression = ResolveFunctionNamespaces(b.Expression, context) }).ToList(), ReturnExpression = ResolveFunctionNamespaces(fe.ReturnExpression, context) },
            LetExpressionNode le => le with { Bindings = le.Bindings.Select(b => b with { Expression = ResolveFunctionNamespaces(b.Expression, context) }).ToList(), Body = ResolveFunctionNamespaces(le.Body, context) },
            QuantifiedExpressionNode qe => qe with { Bindings = qe.Bindings.Select(b => b with { Expression = ResolveFunctionNamespaces(b.Expression, context) }).ToList(), SatisfiesExpression = ResolveFunctionNamespaces(qe.SatisfiesExpression, context) },
            BinaryExpressionNode bin => bin with { Left = ResolveFunctionNamespaces(bin.Left, context), Right = ResolveFunctionNamespaces(bin.Right, context) },
            FlworExpressionNode flwor => flwor with
            {
                Clauses = flwor.Clauses.Select(c => ResolveFlworClause(c, context)).ToList(),
                ReturnExpression = ResolveFunctionNamespaces(flwor.ReturnExpression, context)
            },
            UnaryExpressionNode un => un with { Operand = ResolveFunctionNamespaces(un.Operand, context) },
            CastNode cast => cast with { Expression = ResolveFunctionNamespaces(cast.Expression, context) },
            CastableNode castable => castable with { Expression = ResolveFunctionNamespaces(castable.Expression, context) },
            InstanceOfNode io => io with { Expression = ResolveFunctionNamespaces(io.Expression, context) },
            TreatNode treat => treat with { Expression = ResolveFunctionNamespaces(treat.Expression, context) },
            ArrowExprNode arrow => arrow with { Source = ResolveFunctionNamespaces(arrow.Source, context), Target = ResolveFunctionNamespaces(arrow.Target, context) },
            PipelineExprNode pipeline => pipeline with { Source = ResolveFunctionNamespaces(pipeline.Source, context), Target = ResolveFunctionNamespaces(pipeline.Target, context) },
            TryCatchNode tc => tc with
            {
                TryExpression = ResolveFunctionNamespaces(tc.TryExpression, context),
                Clauses = tc.Clauses.Select(c => c with { Expression = ResolveFunctionNamespaces(c.Expression, context) }).ToList()
            },
            ValidateExpressionNode v => v with { Expression = ResolveFunctionNamespaces(v.Expression, context) },
            ExtensionExpressionNode e => e with { Expression = ResolveFunctionNamespaces(e.Expression, context) },
            StringConstructorNode sc => sc with { Parts = sc.Parts.Select(p => ResolveFunctionNamespaces(p, context)).ToList() },
            LookupNode lookup => lookup with { Expression = ResolveFunctionNamespaces(lookup.Expression, context), Key = ResolveFunctionNamespaces(lookup.Key, context) },
            LookupWildcardNode lw => lw with { Expression = ResolveFunctionNamespaces(lw.Expression, context) },
            InlineFunctionNode inf => inf with { Body = ResolveFunctionNamespaces(inf.Body, context) },
            DirectElementConstructorNode elem => elem with
            {
                Attributes = elem.Attributes.Select(a => a with
                {
                    ValueParts = a.ValueParts.Select(p => ResolveFunctionNamespaces(p, context)).ToList()
                }).ToList(),
                Content = elem.Content.Select(p => ResolveFunctionNamespaces(p, context)).ToList()
            },
            ComputedElementConstructorNode n => n with
            {
                NameExpression = n.NameExpression is null ? null : ResolveFunctionNamespaces(n.NameExpression, context),
                ContentExpression = ResolveFunctionNamespaces(n.ContentExpression, context)
            },
            ComputedAttributeConstructorNode n => n with
            {
                NameExpression = n.NameExpression is null ? null : ResolveFunctionNamespaces(n.NameExpression, context),
                ValueExpression = ResolveFunctionNamespaces(n.ValueExpression, context)
            },
            ComputedDocumentConstructorNode n => n with { ContentExpression = ResolveFunctionNamespaces(n.ContentExpression, context) },
            ComputedTextConstructorNode n => n with { ValueExpression = ResolveFunctionNamespaces(n.ValueExpression, context) },
            ComputedCommentConstructorNode n => n with { ValueExpression = ResolveFunctionNamespaces(n.ValueExpression, context) },
            ComputedPIConstructorNode n => n with
            {
                TargetExpression = n.TargetExpression is null ? null : ResolveFunctionNamespaces(n.TargetExpression, context),
                ValueExpression = ResolveFunctionNamespaces(n.ValueExpression, context)
            },
            ComputedNamespaceConstructorNode n => n with
            {
                PrefixExpression = n.PrefixExpression is null ? null : ResolveFunctionNamespaces(n.PrefixExpression, context),
                UriExpression = ResolveFunctionNamespaces(n.UriExpression, context)
            },
            SwitchExpressionNode sw => sw with
            {
                Operand = ResolveFunctionNamespaces(sw.Operand, context),
                Cases = sw.Cases.Select(c => c with
                {
                    Values = c.Values.Select(v => ResolveFunctionNamespaces(v, context)).ToList(),
                    Return = ResolveFunctionNamespaces(c.Return, context)
                }).ToList(),
                Default = ResolveFunctionNamespaces(sw.Default, context)
            },
            TypeswitchExpressionNode ts => ts with
            {
                Operand = ResolveFunctionNamespaces(ts.Operand, context),
                Cases = ts.Cases.Select(c => c with { Return = ResolveFunctionNamespaces(c.Return, context) }).ToList(),
                Default = ResolveFunctionNamespaces(ts.Default, context)
            },
            MapConstructorNode mc => mc with { Entries = mc.Entries.Select(e => e with { Key = ResolveFunctionNamespaces(e.Key, context), Value = ResolveFunctionNamespaces(e.Value, context) }).ToList() },
            ArrayConstructorNode ac => ac with { Items = ac.Items.Select(i => ResolveFunctionNamespaces(i, context)).ToList() },
            PostfixPredicateNode pp => pp with { Expression = ResolveFunctionNamespaces(pp.Expression, context), Predicate = ResolveFunctionNamespaces(pp.Predicate, context) },
            DynamicFunctionCallNode dfc => dfc with { Function = ResolveFunctionNamespaces(dfc.Function, context), Arguments = dfc.Arguments.Select(a => ResolveFunctionNamespaces(a, context)).ToList() },
            _ => node
        };
    }

    private static FunctionCallNode ResolveFunctionCall(FunctionCallNode node, XQueryStaticContext context)
    {
        var nsUri = string.IsNullOrEmpty(node.NamespaceUri)
            ? ResolvePrefix(node.Prefix, context)
            : node.NamespaceUri;
        return node with
        {
            Arguments = node.Arguments.Select(a => ResolveFunctionNamespaces(a, context)).ToList(),
            NamespaceUri = nsUri
        };
    }

    private static FlworClauseNode ResolveFlworClause(FlworClauseNode clause, XQueryStaticContext context)
    {
        return clause switch
        {
            ForClauseNode forClause => forClause with
            {
                Bindings = forClause.Bindings.Select(b => b with
                {
                    Expression = ResolveFunctionNamespaces(b.Expression, context)
                }).ToList()
            },
            LetClauseNode letClause => letClause with
            {
                Bindings = letClause.Bindings.Select(b => b with
                {
                    Expression = ResolveFunctionNamespaces(b.Expression, context)
                }).ToList()
            },
            WhereClauseNode whereClause => whereClause with
            {
                Condition = ResolveFunctionNamespaces(whereClause.Condition, context)
            },
            OrderByClauseNode orderClause => orderClause with
            {
                Specs = orderClause.Specs.Select(s => s with
                {
                    KeyExpression = ResolveFunctionNamespaces(s.KeyExpression, context)
                }).ToList()
            },
            GroupByClauseNode groupClause => groupClause with
            {
                Specs = groupClause.Specs.Select(s => s with
                {
                    KeyExpression = s.KeyExpression is null ? null : ResolveFunctionNamespaces(s.KeyExpression, context)
                }).ToList()
            },
            WindowClauseNode windowClause => windowClause with
            {
                InExpression = ResolveFunctionNamespaces(windowClause.InExpression, context),
                StartCondition = windowClause.StartCondition with
                {
                    WhenExpression = ResolveFunctionNamespaces(windowClause.StartCondition.WhenExpression, context)
                },
                EndCondition = windowClause.EndCondition is null
                    ? null
                    : windowClause.EndCondition with
                    {
                        WhenExpression = ResolveFunctionNamespaces(windowClause.EndCondition.WhenExpression, context)
                    }
            },
            _ => clause
        };
    }

    private static NamedFunctionRefNode ResolveNamedFunctionRef(NamedFunctionRefNode node, XQueryStaticContext context)
    {
        var nsUri = string.IsNullOrEmpty(node.NamespaceUri)
            ? ResolvePrefix(node.Prefix, context)
            : node.NamespaceUri;
        return node with { NamespaceUri = nsUri };
    }
}
