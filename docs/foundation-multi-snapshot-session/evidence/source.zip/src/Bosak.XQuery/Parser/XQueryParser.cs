// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 22 July 2026
// PURPOSE              : Parses an XQuery 3.1 module into a static context and an executable query body.
// SPECIAL NOTES        : Part of the Bosak XQuery 3.1 implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
//                      |                  |       |                | default collation                                                                      |
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 22-07-2026     | Creation — prolog-less delegation to XPathParser                                        |
//                      | Charles Korthout | 0.2   | 22-07-2026     | Parse XQuery body with allowFullFlwor=true to enable full FLWOR                          |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.3   | 25-07-2026     | Parse 'declare base-uri' prolog declarations                                            |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.4   | 25-07-2026     | Version/encoding validation; XPST0003 syntax codes; char refs; xquery-name backtrack    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.5   | 25-07-2026     | Parse declare option (output declarations) with QName/EQName option names               |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.6   | 26-07-2026     | declare function / declare variable prolog parsing with XQST0034/0039/0045/0049 and XPST0003 validations |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.7   | 27-07-2026     | Library module declaration, import module, %public/%private annotations (XQST0047/0048/0070/0088/0106/0116) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.8   | 27-07-2026     | declare ordering (XQST0065) and declare default order empty (XQST0069) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.9   | 29-07-2026     | Variable initializers parsed as ExprSingle; element/attribute type +/* occurrence rejected (XPST0003) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.0   | 29-07-2026     | XQST0033 duplicate namespace declarations; XQST0070 reserved xml/xmlns checks; two-phase prolog ordering |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.1   | 29-07-2026     | Unsupported collation is XQST0038; empty default function namespace is XQST0060 |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.2   | 29-07-2026     | XQST0070 reserved dfn; external fn decls; comments stripped from type text; constructor span skipping |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.3   | 01-08-2026     | Library-module context item declaration type recorded for fn:load-xquery-module      |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.4   | 01-08-2026     | declare decimal-format (XQST0097/0098/0111/0114) and boundary-space (XQST0068)      |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.5   | 07-08-2026     | base-uri URILiteral whitespace-normalized per fn:normalize-space (base-URI-18/22/23)  |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.6   | 07-08-2026     | Version declaration without 'version' clause: 'xquery encoding "utf-8";' (XQuery 3.0+) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.7   | 14-08-2026     | Store default collation URI resolved against the static base URI (K-CollationProlog-1) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.8   | 18-08-2026     | XQST0070 for default element namespace bound to XML/XMLNS namespace                    |
//                      | Charles Korthout | 1.9   | 19-08-2026     | Parse 'import schema default element namespace' and apply it to static context        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.10  | 03-09-2026     | Warning-free build: CA1831 AsSpan instead of Range string indexer                     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.11  | 09-09-2026     | Typed function test (args other than '*') requires an 'as' return type (hof-910)      |
//                      | Charles Korthout | 1.12  | 09-09-2026     | XQST0098 for exponent-separator == digit sign; XQST0058 for duplicate schema-import targ |
//                      | Charles Korthout | 1.13  | 21-09-2026     | API freeze stage A: ParseException renamed to XPathParseException                      |
//                      | Charles Korthout | 1.14  | 21-09-2026     | API freeze stage A: reduced accessibility (internalized Parser/Compiler types)         |
//                      | Charles Korthout | 1.15  | 21-09-2026     | API freeze stage C: internalized XQueryParser and XQueryParseResult                     |
//                      | Charles Korthout | 1.16  | 10-10-2026     | REQ-123 compare-tail slice: unicode-case-insensitive collation recognized in prolog    |
//                      |                  |       |                | default collation                                                                      |
//                      |==================|=======|================|=========================================================================================
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.17  | 28-10-2026     | Report XQST0099 for duplicate library context declarations (1.29.3).                    |
//                      | Charles Korthout | 1.18  | 28-10-2026     | Parse typed main-module context item values/defaults and retain library restrictions.    |
//                      | Charles Korthout | 1.19  | 28-10-2026     | Parse copy-namespaces modes, ordering and duplicate XQST0055 (1.31.0). |
//                      | Charles Korthout | 1.20  | 28-10-2026     | Parse strip/preserve, ordering and duplicate XQST0067 (1.32.0). |
//                      | Charles Korthout | 1.21  | 28-10-2026     | Implement statically validated ignored-pragma fallback and raw scanning (1.33.0). |
// ===========================================================================================================================================================

using Bosak.XPath.Core.Xdm;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text;
using Bosak.XPath.Parser;
using Bosak.XPath.Parser.Ast;
using Bosak.XPath.Parser.Lexer;
using Bosak.XPath.Runtime.Vm;

namespace Bosak.XQuery.Compiler;

/// <summary>
/// Parses XQuery 3.1 source text into a static context and an XPath-compatible AST body.
/// The parser owns the XQuery top-level grammar (version declaration, prolog, and query body)
/// and delegates expression parsing to the proven XPath parser.
/// </summary>
internal sealed class XQueryParser
{
    private readonly string _source;
    private int _position;

    private XQueryParser(string source)
    {
        _source = source;
        _position = 0;
    }

    /// <summary>
    /// Parses the supplied XQuery source text.
    /// </summary>
    /// <param name="source">The XQuery source text.</param>
    /// <param name="xml11LineEndings">When true, string literals get XML 1.1 line-ending normalization.</param>
    /// <returns>A parse result containing the static context and the query body AST.</returns>
    public static XQueryParseResult Parse(string source, bool xml11LineEndings = false)
    {
        var parser = new XQueryParser(source) { _xml11LineEndings = xml11LineEndings };
        return parser.ParseModule();
    }

    private XQueryParseResult ParseModule()
    {
        var context = new XQueryStaticContext();

        SkipWhitespace();

        // Optional version declaration: "xquery version '...';" or "xquery version '...' encoding '...';".
        // A leading name 'xquery' that is not followed by 'version' is a path expression,
        // not a version declaration (e.g. 'xquery gt xquery').
        int beforeVersionDecl = _position;
        bool versionDeclParsed = false;
        bool xqueryKeyword = TryMatchLiteral("xquery");
        if (xqueryKeyword && TryMatchLiteral("version"))
        {
            SkipWhitespace();
            var versionLiteral = ReadStringLiteral();
            SkipWhitespace();

            // XQST0031: only XQuery versions supported by this implementation are accepted.
            if (versionLiteral is not ("1.0" or "3.0" or "3.1"))
                throw new XPathParseException($"XQST0031: XQuery version '{versionLiteral}' is not supported.", _position);

            if (TryMatchLiteral("encoding"))
            {
                SkipWhitespace();
                var encoding = ReadStringLiteral();
                // XQST0087: the encoding name must match the XML EncName production.
                if (!IsValidEncodingName(encoding))
                    throw new XPathParseException($"XQST0087: Encoding '{encoding}' is not supported.", _position);
                SkipWhitespace();
            }

            ExpectChar(';');
            SkipWhitespace();
            versionDeclParsed = true;
        }
        else if (xqueryKeyword && TryMatchLiteral("encoding"))
        {
            // XQuery 3.0+: the 'version' clause may be omitted — 'xquery encoding "utf-8";'
            // is a valid version declaration (version_declaration-023-v3). The leading
            // 'xquery' was already consumed by the failed first alternative.
            SkipWhitespace();
            var encoding = ReadStringLiteral();
            // XQST0087: the encoding name must match the XML EncName production.
            if (!IsValidEncodingName(encoding))
                throw new XPathParseException($"XQST0087: Encoding '{encoding}' is not supported.", _position);
            SkipWhitespace();
            ExpectChar(';');
            SkipWhitespace();
            versionDeclParsed = true;
        }
        if (!versionDeclParsed)
        {
            _position = beforeVersionDecl;
        }

        // Optional library module declaration: 'module namespace prefix = "uri";'.
        // Only a library module carries one; XQueryCompiler rejects it for a main module.
        int beforeModuleDecl = _position;
        if (TryMatchLiteral("module") && TryMatchLiteral("namespace"))
        {
            SkipWhitespace();
            string modulePrefix = ReadNCName();
            SkipWhitespace();
            ExpectLiteral("=");
            SkipWhitespace();
            string moduleNs = NormalizeModuleUri(ReadStringLiteral());
            SkipWhitespace();
            ExpectChar(';');
            // XQST0088: the target namespace of a library module must not be empty.
            if (moduleNs.Length == 0)
                throw new XPathParseException("XQST0088: The target namespace of a library module must not be a zero-length string.", _position);
            // The module declaration also binds its prefix in the module's own static context.
            context = context.WithModuleNamespace(moduleNs).WithNamespace(modulePrefix, moduleNs);
            _isLibraryModule = true;
            SkipWhitespace();
        }
        else
        {
            _position = beforeModuleDecl;
        }

        // Prolog parsing is intentionally minimal in this first iteration.
        // We only consume namespace declarations that are needed for the
        // XPath parser's static context.
        while (TryParsePrologDeclaration(ref context)
               || TryParseSchemaImport(ref context)
               || TryParseModuleImport(ref context)
               || TryParseFunctionDeclaration(ref context)
               || TryParseVariableDeclaration(ref context))
        {
            SkipWhitespace();
        }

        // Deferred option-prefix resolution: a prefix undeclared after the whole
        // prolog is XPST0081 (an option that precedes namespace declarations was
        // already rejected with XPST0003 by the ordering check).
        foreach (var (prefix, local, value, position) in _pendingOptions)
        {
            if (!context.Namespaces.TryGetValue(prefix, out var deferredNs))
                throw new XPathParseException($"XPST0081: Prefix '{prefix}' is not declared.", position);
            ValidateOutputOption(context, local, deferredNs, position);
            context = context.WithOption(local, deferredNs, value);
        }

        // The rest of the source is the query body (an Expr) — a library module has none.
        int bodyStart = _position;
        var remaining = _source[bodyStart..];
        if (_isLibraryModule)
        {
            // XQST0048: every function and variable declared in a library module must be
            // in the module's target namespace.
            string targetNs = context.ModuleNamespaceUri!;
            foreach (var fn in context.UserFunctions)
            {
                if (fn.NamespaceUri != targetNs)
                    throw new XPathParseException($"XQST0048: Function '{fn.LocalName}' is not in the library module's target namespace '{targetNs}'.", fn.Position);
            }
            foreach (var v in context.UserVariables)
            {
                if (v.NamespaceUri != targetNs)
                    throw new XPathParseException($"XQST0048: Variable '${v.LocalName}' is not in the library module's target namespace '{targetNs}'.", v.Position);
            }
            // XQST0108: an output declaration must not appear in a library module.
            foreach (var (local, optionNs, _) in context.Options)
            {
                if (optionNs == "http://www.w3.org/2010/xslt-xquery-serialization")
                    throw new XPathParseException($"XQST0108: An output declaration ('{local}') must not appear in a library module.", _position);
            }
            // XPST0003: a library module must not contain a query body expression.
            if (!string.IsNullOrWhiteSpace(StripComments(remaining)))
                throw new XPathParseException("XPST0003: A library module must not contain a query body expression.", _position);
            return new XQueryParseResult(context, new SequenceExpressionNode(Array.Empty<XPathAstNode>()), isLibraryModule: true);
        }
        if (string.IsNullOrWhiteSpace(remaining))
            throw new XPathParseException("XPST0003: Query body is missing.", _position);

        var bodyAst = XPathParser.Parse(remaining, allowFullFlwor: true, xml11LineEndings: _xml11LineEndings,
            boundarySpaceStrip: _boundarySpaceStrip);
        return new XQueryParseResult(context, bodyAst);
    }

    private bool TryParseModuleImport(ref XQueryStaticContext context)
    {
        int savedPosition = _position;
        SkipWhitespace();
        if (!TryMatchLiteral("import") || !TryMatchLiteral("module"))
        {
            // 'import schema' and bare 'import' used as a name are not module imports.
            _position = savedPosition;
            return false;
        }

        // XQuery prolog ordering: imports are phase-1 declarations and must precede
        // variable, function, option, and context item declarations.
        if (_seenSecondPhaseDecl)
            throw new XPathParseException("XPST0003: Module imports must precede variable, function, option, and context item declarations.", _position);

        SkipWhitespace();
        string? importPrefix = null;
        if (TryMatchLiteral("namespace"))
        {
            SkipWhitespace();
            importPrefix = ReadNCName();
            SkipWhitespace();
            ExpectLiteral("=");
            SkipWhitespace();
        }
        string importNs = NormalizeModuleUri(ReadStringLiteral());
        var locationHints = new List<string>();
        SkipWhitespace();
        if (TryMatchLiteral("at"))
        {
            do
            {
                SkipWhitespace();
                locationHints.Add(NormalizeModuleUri(ReadStringLiteral()));
                SkipWhitespace();
            } while (TryMatchChar(','));
        }
        ExpectChar(';');

        // XQST0088: the target namespace of a module import must not be empty.
        if (importNs.Length == 0)
            throw new XPathParseException("XQST0088: The target namespace of a module import must not be a zero-length string.", _position);
        // XQST0070: the prefixes xml and xmlns must not be (re)bound by a module import.
        if (importPrefix == "xmlns"
            || (importPrefix == "xml" && importNs != "http://www.w3.org/XML/1998/namespace"))
        {
            throw new XPathParseException($"XQST0070: The prefix '{importPrefix}' must not be bound by a module import.", _position);
        }
        // XQST0047: one module must not import the same target namespace twice.
        if (context.ImportedModules.Any(m => m.NamespaceUri == importNs))
            throw new XPathParseException($"XQST0047: The module namespace '{importNs}' is imported more than once.", _position);

        if (importPrefix is not null)
            context = context.WithNamespace(importPrefix, importNs);
        context = context.WithImportedModule(new ModuleImport(importPrefix, importNs, locationHints, _position));
        return true;
    }

    private bool TryParseSchemaImport(ref XQueryStaticContext context)
    {
        int savedPosition = _position;
        SkipWhitespace();
        if (!TryMatchLiteral("import") || !TryMatchLiteral("schema"))
        {
            _position = savedPosition;
            return false;
        }

        // Schema imports are phase-1 declarations and must precede variable, function, option,
        // and context item declarations.
        if (_seenSecondPhaseDecl)
            throw new XPathParseException("XPST0003: Schema imports must precede variable, function, option, and context item declarations.", _position);

        SkipWhitespace();
        string? importPrefix = null;
        string? importNs = null;
        bool isDefaultElementNamespace = false;
        if (TryMatchLiteral("namespace"))
        {
            SkipWhitespace();
            importPrefix = ReadNCName();
            SkipWhitespace();
            ExpectLiteral("=");
            SkipWhitespace();
            importNs = NormalizeModuleUri(ReadStringLiteral());
            SkipWhitespace();
        }
        else if (TryMatchPhrase("default", "element", "namespace"))
        {
            SkipWhitespace();
            importNs = NormalizeModuleUri(ReadStringLiteral());
            SkipWhitespace();
            isDefaultElementNamespace = true;
        }
        else
        {
            SkipWhitespace();
            importNs = NormalizeModuleUri(ReadStringLiteral());
            SkipWhitespace();
        }

        var locationHints = new List<string>();
        if (TryMatchLiteral("at"))
        {
            do
            {
                SkipWhitespace();
                locationHints.Add(NormalizeModuleUri(ReadStringLiteral()));
                SkipWhitespace();
            } while (TryMatchChar(','));
        }
        ExpectChar(';');

        // XQST0057: a schema import that specifies a prefix must not specify the empty target namespace.
        if (importPrefix is not null && importNs == "")
            throw new XPathParseException("XQST0057: A schema import must not bind a prefix to the empty namespace URI.", _position);
        // XQST0070: the prefixes xml and xmlns must not be (re)bound by a schema import.
        if (importPrefix == "xmlns"
            || (importPrefix == "xml" && importNs != "http://www.w3.org/XML/1998/namespace"))
        {
            throw new XPathParseException($"XQST0070: The prefix '{importPrefix}' must not be bound by a schema import.", _position);
        }
        // XQST0059: a schema import must have a target namespace or be default element namespace.
        if (importNs is null)
            throw new XPathParseException("XPST0003: A schema import must specify a target namespace or 'default element namespace'.", _position);

        if (importPrefix is not null)
            context = context.WithNamespace(importPrefix, importNs);
        else if (isDefaultElementNamespace)
            context = context.WithDefaultElementNamespace(importNs);
        // XQST0058: a prolog must not contain two schema imports with the same target
        // namespace (schema-import-2, XQST0058 in misc-CombinedErrorCodes).
        foreach (var existing in context.ImportedSchemas)
        {
            if (string.Equals(existing.NamespaceUri ?? "", importNs, StringComparison.Ordinal))
                throw new XPathParseException($"XQST0058: More than one schema import specifies the target namespace '{importNs}'.", _position);
        }
        context = context.WithImportedSchema(new SchemaImport(importPrefix, importNs, locationHints, _position));
        return true;
    }

    private bool TryParsePrologDeclaration(ref XQueryStaticContext context)
    {
        int savedPosition = _position;
        SkipWhitespace();

        if (!TryMatchLiteral("declare"))
        {
            _position = savedPosition;
            return false;
        }

        if (TryMatchPhrase("namespace"))
        {
            // XQuery prolog ordering (two-phase grammar): namespace declarations are
            // phase-1 declarations and must precede variable, function, option, and
            // context item declarations (K2-NamespaceProlog-14).
            if (_seenSecondPhaseDecl)
                throw new XPathParseException("XPST0003: Namespace declarations must precede variable, function, option, and context item declarations.", _position);
            SkipWhitespace();
            string prefix = ReadNCName();
            SkipWhitespace();
            ExpectLiteral("=");
            SkipWhitespace();
            string uri = ReadStringLiteral();
            SkipWhitespace();
            ExpectChar(';');
            // XQST0070: the prefix xml must not be (re)declared at all and the prefix
            // xmlns must not be declared or undeclared (K2-NamespaceProlog-6/7/15,
            // namespaceDecl-3/5); no prefix may be bound to the XML or XMLNS namespace
            // names (namespaceDecl-4).
            if (prefix is "xml" or "xmlns")
                throw new XPathParseException($"XQST0070: The namespace prefix '{prefix}' must not be declared.", _position);
            if (uri is "http://www.w3.org/XML/1998/namespace" or "http://www.w3.org/2000/xmlns/")
                throw new XPathParseException($"XQST0070: The namespace '{uri}' must not be bound to the prefix '{prefix}'.", _position);
            // XQST0033: a prefix must not be declared twice in one prolog — an
            // undeclaration counts as a declaration (K2-NamespaceProlog-1/2/3).
            if (!_declaredNamespacePrefixes.Add(prefix))
                throw new XPathParseException($"XQST0033: The namespace prefix '{prefix}' is declared more than once.", _position);
            context = context.WithNamespace(prefix, uri);
            return true;
        }

        if (TryMatchPhrase("default", "element", "namespace"))
        {
            if (_seenSecondPhaseDecl)
                throw new XPathParseException("XPST0003: Namespace declarations must precede variable, function, option, and context item declarations.", _position);
            SkipWhitespace();
            string uri = ReadStringLiteral();
            SkipWhitespace();
            ExpectChar(';');
            // XQST0070: the default element namespace must not be the XML or XMLNS
            // namespace (defaultnamespacedeclerr-3/5/7).
            if (uri is "http://www.w3.org/XML/1998/namespace" or "http://www.w3.org/2000/xmlns/")
                throw new XPathParseException($"XQST0070: The default element namespace must not be the reserved namespace '{uri}'.", _position);
            // XQST0066: the default element namespace must not be declared twice.
            if (context.DefaultElementNamespace is not null)
                throw new XPathParseException("XQST0066: More than one default element namespace declaration.", _position);
            context = context.WithDefaultElementNamespace(uri);
            return true;
        }

        if (TryMatchPhrase("default", "function", "namespace"))
        {
            if (_seenSecondPhaseDecl)
                throw new XPathParseException("XPST0003: Namespace declarations must precede variable, function, option, and context item declarations.", _position);
            SkipWhitespace();
            string uri = ReadStringLiteral();
            SkipWhitespace();
            ExpectChar(';');
            // XQST0060: the default function namespace must not be a zero-length string
            // (unlike the default element namespace, it cannot be undeclared).
            if (uri.Length == 0)
                throw new XPathParseException("XQST0060: The default function namespace must not be a zero-length string.", _position);
            // XQST0070: the default function namespace must not be the XML or XMLNS
            // namespace (defaultnamespacedeclerr-4/6/8). The XML Schema namespaces are
            // legal here (hof-007 uses xs:date via the default function namespace).
            if (uri is "http://www.w3.org/XML/1998/namespace" or "http://www.w3.org/2000/xmlns/")
            {
                throw new XPathParseException($"XQST0070: The default function namespace must not be the reserved namespace '{uri}'.", _position);
            }
            // XQST0066: the default function namespace must not be declared twice.
            if (context.DefaultFunctionNamespace is not null
                && context.DefaultFunctionNamespace != "http://www.w3.org/2005/xpath-functions")
                throw new XPathParseException("XQST0066: More than one default function namespace declaration.", _position);
            context = context.WithDefaultFunctionNamespace(uri);
            return true;
        }

        if (TryMatchPhrase("default", "collation"))
        {
            if (_seenSecondPhaseDecl)
                throw new XPathParseException("XPST0003: Setter declarations must precede variable, function, option, and context item declarations.", _position);
            SkipWhitespace();
            string uri = ReadStringLiteral();
            SkipWhitespace();
            ExpectChar(';');
            // XQST0038: duplicate default collation declaration.
            if (context.DefaultCollation is not null)
                throw new XPathParseException("XQST0038: More than one default collation declaration.", _position);
            // XQST0038: the collation must be known to the implementation (XQST0038_3,
            // XQST0046_06 — an unsupported or malformed collation URI is the same error).
            // Store the resolved absolute URI so fn:default-collation() reports it correctly.
            string resolvedUri = ResolveCollationUri(uri, context.BaseUri);
            if (!IsSupportedCollation(resolvedUri))
                throw new XPathParseException($"XQST0038: Collation '{uri}' is not supported.", _position);
            context = context.WithDefaultCollation(resolvedUri);
            return true;
        }

        if (TryMatchPhrase("default", "order", "empty"))
        {
            if (_seenSecondPhaseDecl)
                throw new XPathParseException("XPST0003: Setter declarations must precede variable, function, option, and context item declarations.", _position);
            SkipWhitespace();
            var emptyMode = ReadNCName();
            if (emptyMode is not ("least" or "greatest"))
                throw new XPathParseException($"XPST0003: Expected 'least' or 'greatest' after 'declare default order empty' but found '{emptyMode}'.", _position);
            SkipWhitespace();
            ExpectChar(';');
            // XQST0069: the default order for empty sequences must not be declared twice.
            if (context.DefaultEmptyOrderLeast is not null)
                throw new XPathParseException("XQST0069: More than one 'declare default order empty' declaration.", _position);
            context = context.WithDefaultEmptyOrderLeast(emptyMode == "least");
            return true;
        }

        if (TryMatchPhrase("ordering"))
        {
            if (_seenSecondPhaseDecl)
                throw new XPathParseException("XPST0003: Setter declarations must precede variable, function, option, and context item declarations.", _position);
            SkipWhitespace();
            var mode = ReadNCName();
            if (mode is not ("ordered" or "unordered"))
                throw new XPathParseException($"XPST0003: Expected 'ordered' or 'unordered' after 'declare ordering' but found '{mode}'.", _position);
            SkipWhitespace();
            ExpectChar(';');
            // XQST0065: the ordering mode must not be declared twice.
            if (_seenOrderingDecl)
                throw new XPathParseException("XQST0065: More than one ordering mode declaration.", _position);
            _seenOrderingDecl = true;
            return true;
        }

        if (TryMatchPhrase("boundary-space"))
        {
            if (_seenSecondPhaseDecl)
                throw new XPathParseException("XPST0003: Setter declarations must precede variable, function, option, and context item declarations.", _position);
            SkipWhitespace();
            var spaceMode = ReadNCName();
            if (spaceMode is not ("strip" or "preserve"))
                throw new XPathParseException($"XPST0003: Expected 'strip' or 'preserve' after 'declare boundary-space' but found '{spaceMode}'.", _position);
            SkipWhitespace();
            ExpectChar(';');
            // XQST0068: the boundary-space policy must not be declared twice (boundaryspacedeclerr-1).
            if (context.BoundarySpaceStrip is not null)
                throw new XPathParseException("XQST0068: More than one boundary-space declaration.", _position);
            context = context.WithBoundarySpace(spaceMode == "strip");
            _boundarySpaceStrip = spaceMode == "strip";
            return true;
        }

        if (TryMatchPhrase("default", "decimal-format"))
        {
            if (_seenSecondPhaseDecl)
                throw new XPathParseException("XPST0003: Setter declarations must precede variable, function, option, and context item declarations.", _position);
            ParseDecimalFormatDeclaration(ref context, isDefault: true);
            return true;
        }

        if (TryMatchPhrase("decimal-format"))
        {
            if (_seenSecondPhaseDecl)
                throw new XPathParseException("XPST0003: Setter declarations must precede variable, function, option, and context item declarations.", _position);
            ParseDecimalFormatDeclaration(ref context, isDefault: false);
            return true;
        }

        if (TryMatchPhrase("base-uri"))
        {
            if (_seenSecondPhaseDecl)
                throw new XPathParseException("XPST0003: Setter declarations must precede variable, function, option, and context item declarations.", _position);
            SkipWhitespace();
            // URILiteral whitespace is normalized per the fn:normalize-space rules
            // (XQ 3.1 §2.4.5): leading/trailing whitespace is stripped and internal
            // whitespace runs (incl. character references such as &#xa;) collapse
            // to a single space (base-URI-18/22/23).
            string uri = NormalizeModuleUri(ReadStringLiteral());
            SkipWhitespace();
            ExpectChar(';');
            // XQST0032: the base URI must not be declared twice.
            if (context.BaseUri is not null)
                throw new XPathParseException("XQST0032: More than one base URI declaration.", _position);
            context = context.WithBaseUri(uri);
            return true;
        }

        if (TryMatchPhrase("option"))
        {
            SkipWhitespace();
            var (prefix, local, eqNameUri) = ReadQName();
            SkipWhitespace();
            string value = ReadStringLiteral();
            SkipWhitespace();
            ExpectChar(';');
            _seenSecondPhaseDecl = true;
            if (eqNameUri is null && prefix is not null && !context.Namespaces.ContainsKey(prefix))
            {
                // The prefix may be declared by a later namespace declaration — but that
                // is an ordering violation (XPST0003); otherwise it is undeclared (XPST0081).
                _pendingOptions.Add((prefix, local, value, _position));
                return true;
            }
            string optionNs = eqNameUri ?? (prefix is null ? string.Empty : context.Namespaces[prefix]);
            ValidateOutputOption(context, local, optionNs, _position);
            context = context.WithOption(local, optionNs, value);
            return true;
        }

        if (TryMatchLiteral("construction"))
        {
            if (_seenSecondPhaseDecl)
                throw new XPathParseException("XPST0003: Construction must precede variable, function, option, and context item declarations.", _position);
            if (context.ConstructionMode.HasValue)
                throw new XPathParseException("XQST0067: More than one construction declaration.", _position);
            XdmConstructionMode mode;
            if (TryMatchLiteral("preserve")) mode = XdmConstructionMode.Preserve;
            else if (TryMatchLiteral("strip")) mode = XdmConstructionMode.Strip;
            else throw new XPathParseException("XPST0003: Expected strip or preserve.", _position);
            SkipWhitespace();
            ExpectChar(';');
            context = context.WithConstructionMode(mode);
            return true;
        }

        if (TryMatchLiteral("copy-namespaces"))
        {
            if (_seenSecondPhaseDecl)
                throw new XPathParseException("XPST0003: Copy-namespaces must precede variable, function, option, and context item declarations.", _position);
            if (context.PreserveNamespaces.HasValue)
                throw new XPathParseException("XQST0055: More than one copy-namespaces declaration.", _position);
            bool preserve;
            if (TryMatchLiteral("preserve")) preserve = true;
            else if (TryMatchLiteral("no-preserve")) preserve = false;
            else throw new XPathParseException("XPST0003: Expected preserve or no-preserve.", _position);
            SkipWhitespace();
            ExpectChar(',');
            bool inherit;
            if (TryMatchLiteral("inherit")) inherit = true;
            else if (TryMatchLiteral("no-inherit")) inherit = false;
            else throw new XPathParseException("XPST0003: Expected inherit or no-inherit.", _position);
            SkipWhitespace();
            ExpectChar(';');
            context = context.WithCopyNamespaces(preserve, inherit);
            return true;
        }

        // ContextItemDecl uses ItemType, not SequenceType: top-level occurrence
        // indicators and empty-sequence() are not permitted.
        if (TryMatchPhrase("context", "item"))
        {
            SkipWhitespace();
            string? contextItemType = null;
            if (TryMatchLiteral("as"))
            {
                SkipWhitespace();
                int typeStart = _position;
                ReadItemTypeText(contextItem: true);
                contextItemType = StripComments(_source[typeStart.._position]).Trim();
                if (contextItemType.StartsWith("empty-sequence(", StringComparison.Ordinal))
                    throw new XPathParseException("XPST0003: Context item declarations require ItemType.", typeStart);
            }
            SkipWhitespace();
            bool isExternal = TryMatchLiteral("external");
            SkipWhitespace();
            XPathAstNode? initializer = null;
            if (!isExternal || TryMatchLiteral(":="))
            {
                if (!isExternal) ExpectLiteral(":=");
                SkipWhitespace();
                initializer = ReadExpressionTo(';');
                SkipWhitespace();
            }
            ExpectChar(';');
            if (_seenContextItemDecl)
                throw new XPathParseException("XQST0099: More than one context item declaration in a module.", _position);
            _seenContextItemDecl = true;
            _seenSecondPhaseDecl = true;
            if (_isLibraryModule)
            {
                if (initializer is not null)
                    throw new XPathParseException("XQST0113: A context item declaration in a library module must not specify an initial or default value.", _position);
                context = context.WithContextItemType(contextItemType);
            }
            else
            {
                context = context.WithContextDeclaration(new ContextItemDeclaration(contextItemType ?? "item()", initializer, isExternal));
            }
            return true;
        }

        // Not a recognized prolog declaration; stop consuming prolog items.
        _position = savedPosition;
        return false;
    }

    /// <summary>
    /// Parses a decimal-format declaration (named or default form) after the
    /// <c>declare (default )?decimal-format</c> keywords, applying the XQuery 3.1 §4.10
    /// validations: unknown property XPST0003, multi-character value XQST0097, duplicate
    /// property XQST0114, conflicting separator values XQST0098, duplicate declaration XQST0111.
    /// </summary>
    private void ParseDecimalFormatDeclaration(ref XQueryStaticContext context, bool isDefault)
    {
        SkipWhitespace();
        string? fmtLocal = null;
        string? fmtNs = null;
        if (!isDefault)
        {
            var (prefix, local, eqNameUri) = ReadQName();
            fmtLocal = local;
            fmtNs = eqNameUri ?? (prefix is null ? string.Empty
                : context.Namespaces.TryGetValue(prefix, out var prefixNs) ? prefixNs
                : throw new XPathParseException($"XPST0081: Prefix '{prefix}' is not declared.", _position));
            SkipWhitespace();
            // A bare name with no property bindings uses all defaults.
            if (_position < _source.Length && _source[_position] == ';')
            {
                _position++;
                RegisterDecimalFormat(ref context, isDefault, fmtLocal, fmtNs, new DecimalFormat());
                return;
            }
        }

        var format = new DecimalFormat();
        var seenProps = new HashSet<string>(StringComparer.Ordinal);
        while (true)
        {
            string prop = ReadNCName();
            // XQST0114: a decimal-format property must not appear twice in one declaration.
            if (!seenProps.Add(prop))
                throw new XPathParseException($"XQST0114: The decimal-format property '{prop}' is specified more than once.", _position);
            SkipWhitespace();
            ExpectLiteral("=");
            SkipWhitespace();
            string value = ReadStringLiteral();
            SkipWhitespace();
            // XQST0097: single-character properties hold exactly one character
            // (infinity and NaN are multi-character strings by design); zero-digit must
            // additionally be a character with digit value 0 (decimal-format-909err/910err/35),
            // and the picture digit sign must not itself be a digit.
            switch (prop)
            {
                case "decimal-separator": format.DecimalSeparator = CheckSingleChar(prop, value); break;
                case "grouping-separator": format.GroupingSeparator = CheckSingleChar(prop, value); break;
                case "infinity": format.Infinity = value; break;
                case "minus-sign": format.MinusSign = CheckSingleChar(prop, value); break;
                case "NaN": format.NaN = value; break;
                case "percent": format.Percent = CheckSingleChar(prop, value); break;
                case "per-mille": format.PerMille = CheckSingleChar(prop, value); break;
                case "zero-digit":
                    if (value.Length != 1 || char.GetNumericValue(value[0]) != 0.0)
                        throw new XPathParseException($"XQST0097: The zero-digit property value '{value}' is not a character with digit value 0.", _position);
                    format.ZeroDigit = value;
                    break;
                case "digit":
                    if (value.Length != 1 || char.IsDigit(value[0]))
                        throw new XPathParseException($"XQST0097: The digit property value '{value}' must be a single non-digit character.", _position);
                    format.Digit = value;
                    break;
                case "pattern-separator": format.PatternSeparator = CheckSingleChar(prop, value); break;
                case "exponent-separator": format.ExponentSeparator = CheckSingleChar(prop, value); break;
                default:
                    // currency-symbol (an XSLT-only property) and any other name are
                    // not valid in an XQuery decimal format (decimal-format-07).
                    throw new XPathParseException($"XPST0003: Unknown decimal-format property '{prop}'.", _position);
            }
            if (_position < _source.Length && _source[_position] == ';')
            {
                _position++;
                break;
            }
        }

        // XQST0098: the two separators must be distinct and must not be digits
        // (decimal-format-901err/912err); the exponent separator must not be the percent
        // or per-mille character either (numberformat111 — ambiguous in pictures).
        if (format.DecimalSeparator == format.GroupingSeparator
            || IsDigitChar(format.DecimalSeparator) || IsDigitChar(format.GroupingSeparator))
            throw new XPathParseException("XQST0098: The decimal-separator and grouping-separator must be different characters and must not be digits.", _position);
        if (format.ExponentSeparator == format.Percent || format.ExponentSeparator == format.PerMille)
            throw new XPathParseException("XQST0098: The exponent-separator must not be the percent or per-mille character.", _position);
        // numberformat126: the exponent-separator must not be the digit sign either
        // (it would be ambiguous with a mandatory-digit placeholder in a picture).
        if (format.ExponentSeparator == format.Digit)
            throw new XPathParseException("XQST0098: The exponent-separator must not be the digit sign.", _position);

        RegisterDecimalFormat(ref context, isDefault, fmtLocal, fmtNs, format);
    }

    private void RegisterDecimalFormat(ref XQueryStaticContext context, bool isDefault, string? fmtLocal, string? fmtNs, DecimalFormat format)
    {
        if (isDefault)
        {
            // XQST0111: the default decimal format must not be declared twice
            // (decimal-format-903err).
            if (context.DeclaredDefaultDecimalFormat is not null)
                throw new XPathParseException("XQST0111: More than one default decimal-format declaration.", _position);
            context = context.WithDeclaredDefaultDecimalFormat(format);
        }
        else
        {
            // XQST0111: a named decimal format must not be declared twice
            // (decimal-format-904err).
            if (context.DecimalFormats.ContainsKey((fmtLocal!, fmtNs!)))
                throw new XPathParseException($"XQST0111: The decimal format '{fmtLocal}' is declared more than once.", _position);
            context = context.WithDecimalFormat(fmtLocal!, fmtNs!, format);
        }
    }

    private string CheckSingleChar(string prop, string value)
    {
        if (value.Length != 1)
            throw new XPathParseException($"XQST0097: The decimal-format property '{prop}' value '{value}' is not exactly one character.", _position);
        return value;
    }

    private static bool IsDigitChar(string s)
        => s.Length == 1 && char.IsDigit(s[0]);

    private bool TryParseFunctionDeclaration(ref XQueryStaticContext context)
    {
        int savedPosition = _position;
        SkipWhitespace();
        if (!TryMatchLiteral("declare"))
        {
            _position = savedPosition;
            return false;
        }
        var annotations = ReadAnnotations();
        if (!TryMatchLiteral("function"))
        {
            _position = savedPosition;
            return false;
        }
        bool isPrivate = ValidateAnnotations(context, annotations, isFunction: true);

        SkipWhitespace();
        var (prefix, local, eqNameUri) = ReadQName();
        string fnNs = eqNameUri
            ?? (prefix is null
                ? context.DefaultFunctionNamespace ?? "http://www.w3.org/2005/xpath-functions"
                : context.Namespaces.TryGetValue(prefix, out var declaredFnNs)
                    ? declaredFnNs
                    : throw new XPathParseException($"XPST0081: Prefix '{prefix}' is not declared.", _position));

        SkipWhitespace();
        ExpectChar('(');
        var parameters = new List<UserFunctionParameter>();
        SkipWhitespace();
        if (!TryMatchChar(')'))
        {
            do
            {
                SkipWhitespace();
                ExpectChar('$');
                var paramName = ReadQNameText();
                SkipWhitespace();
                string? paramType = null;
                if (TryMatchLiteral("as"))
                {
                    SkipWhitespace();
                    paramType = ReadSequenceTypeText();
                }
                parameters.Add(new UserFunctionParameter(paramName, paramType));
                SkipWhitespace();
            } while (TryMatchChar(','));
            ExpectChar(')');
        }
        SkipWhitespace();
        string? returnType = null;
        if (TryMatchLiteral("as"))
        {
            SkipWhitespace();
            returnType = ReadSequenceTypeText();
        }
        SkipWhitespace();
        // External function declarations ('external' in place of the body) are not
        // supported; the reserved-namespace check still applies first (K2-Axes-99: an
        // unprefixed name lands in the reserved fn namespace — XQST0045).
        if (TryMatchLiteral("external"))
        {
            SkipWhitespace();
            ExpectChar(';');
            if (IsReservedFunctionNamespace(fnNs))
                throw new XPathParseException($"XQST0045: Functions must not be declared in the reserved namespace '{fnNs}'.", _position);
            throw new XPathParseException($"XPST0017: External function declarations are not supported ('{local}').", _position);
        }
        var body = ReadBracedExpression();
        SkipWhitespace();
        ExpectChar(';');

        // XQST0039: two parameters of one function must not have the same name.
        if (parameters.Select(p => p.Name).Distinct().Count() != parameters.Count)
            throw new XPathParseException($"XQST0039: Function '{local}' declares a parameter name more than once.", _position);
        // XQST0034: the same function name and arity must not be declared twice.
        if (context.UserFunctions.Any(f => f.LocalName == local && f.NamespaceUri == fnNs && f.Parameters.Count == parameters.Count))
            throw new XPathParseException($"XQST0034: Function '{local}' with arity {parameters.Count} is declared more than once.", _position);
        // XQST0045: functions must not be declared in a reserved function namespace.
        if (IsReservedFunctionNamespace(fnNs))
        {
            throw new XPathParseException($"XQST0045: Functions must not be declared in the reserved namespace '{fnNs}'.", _position);
        }
        // XPST0003: reserved function names cannot be declared as user functions.
        if (prefix is null && ReservedFunctionNames.Contains(local))
            throw new XPathParseException($"XPST0003: '{local}' is a reserved function name and cannot be declared.", _position);
        context = context.WithUserFunction(new UserFunctionDeclaration(local, fnNs, parameters, returnType, body, _position, isPrivate));
        _seenSecondPhaseDecl = true;
        return true;
    }

    private static bool IsReservedFunctionNamespace(string ns)
        => ns is "http://www.w3.org/2005/xpath-functions"
            or "http://www.w3.org/2005/xpath-functions/math"
            or "http://www.w3.org/2005/xpath-functions/map"
            or "http://www.w3.org/2005/xpath-functions/array"
            or "http://www.w3.org/2001/XMLSchema"
            or "http://www.w3.org/2001/XMLSchema-instance"
            or "http://www.w3.org/XML/1998/namespace"
            or "http://www.w3.org/2000/xmlns/";

    private bool TryParseVariableDeclaration(ref XQueryStaticContext context)
    {
        int savedPosition = _position;
        SkipWhitespace();
        if (!TryMatchLiteral("declare"))
        {
            _position = savedPosition;
            return false;
        }
        var annotations = ReadAnnotations();
        if (!TryMatchLiteral("variable"))
        {
            _position = savedPosition;
            return false;
        }
        bool isPrivate = ValidateAnnotations(context, annotations, isFunction: false);

        SkipWhitespace();
        ExpectChar('$');
        var (prefix, local, eqNameUri) = ReadQName();
        string varNs = eqNameUri
            ?? (prefix is null
                ? string.Empty
                : context.Namespaces.TryGetValue(prefix, out var declaredVarNs)
                    ? declaredVarNs
                    : throw new XPathParseException($"XPST0081: Prefix '{prefix}' is not declared.", _position));
        SkipWhitespace();
        string? varType = null;
        if (TryMatchLiteral("as"))
        {
            SkipWhitespace();
            varType = ReadSequenceTypeText();
        }
        SkipWhitespace();

        XPathAstNode? varBody = null;
        bool isExternal = false;
        if (TryMatchLiteral("external"))
        {
            isExternal = true;
            SkipWhitespace();
            // An external declaration may carry a default value.
            if (TryMatchLiteral(":="))
            {
                SkipWhitespace();
                varBody = ReadExpressionTo(';');
                SkipWhitespace();
            }
        }
        else
        {
            ExpectLiteral(":=");
            SkipWhitespace();
            varBody = ReadExpressionTo(';');
            SkipWhitespace();
        }
        ExpectChar(';');

        // XQST0049: the same variable name must not be declared twice.
        if (context.UserVariables.Any(v => v.LocalName == local && v.NamespaceUri == varNs))
            throw new XPathParseException($"XQST0049: Variable '${local}' is declared more than once.", _position);
        context = context.WithUserVariable(new UserVariableDeclaration(local, varNs, varType, varBody, isExternal, _position, isPrivate));
        _seenSecondPhaseDecl = true;
        return true;
    }

    // Reads a sequence of annotations ('%' EQName ('(' Literal (',' Literal)* ')')?) after
    // 'declare'. Annotation arguments must be literals (XPST0003 otherwise); the annotations
    // themselves are validated only once the declaration kind is known (ValidateAnnotations).
    private List<(string? Prefix, string Local, string? NamespaceUri, int Position)> ReadAnnotations()
    {
        var annotations = new List<(string? Prefix, string Local, string? NamespaceUri, int Position)>();
        while (true)
        {
            SkipWhitespace();
            if (_position >= _source.Length || _source[_position] != '%')
                break;
            _position++;
            var (prefix, local, eqNameUri) = ReadQName();
            annotations.Add((prefix, local, eqNameUri, _position));
            SkipWhitespace();
            if (_position < _source.Length && _source[_position] == '(')
            {
                _position++;
                SkipWhitespace();
                if (TryMatchChar(')'))
                    continue;
                while (true)
                {
                    SkipWhitespace();
                    ReadAnnotationArgumentLiteral();
                    SkipWhitespace();
                    if (TryMatchChar(','))
                        continue;
                    ExpectChar(')');
                    break;
                }
            }
        }
        return annotations;
    }

    // Annotation arguments are restricted to string and numeric literals.
    private void ReadAnnotationArgumentLiteral()
    {
        if (_position >= _source.Length)
            throw new XPathParseException("XPST0003: Expected a literal in annotation arguments.", _position);
        char c = _source[_position];
        if (c is '"' or '\'')
        {
            ReadStringLiteral();
            return;
        }
        int start = _position;
        while (_position < _source.Length && char.IsAsciiDigit(_source[_position]))
            _position++;
        if (_position < _source.Length && _source[_position] == '.')
        {
            _position++;
            while (_position < _source.Length && char.IsAsciiDigit(_source[_position]))
                _position++;
        }
        if (_position < _source.Length && _source[_position] is 'e' or 'E')
        {
            _position++;
            if (_position < _source.Length && _source[_position] is '+' or '-')
                _position++;
            while (_position < _source.Length && char.IsAsciiDigit(_source[_position]))
                _position++;
        }
        if (_position == start)
            throw new XPathParseException("XPST0003: Annotation arguments must be literals.", start);
    }

    // Validates the annotations on a declaration and returns whether it is private:
    //   - %public/%private (unprefixed or in the XQuery namespace) set visibility; more than
    //     one visibility annotation on a single declaration is XQST0106 (function) or
    //     XQST0116 (variable);
    //   - annotations in a reserved namespace (fn, math, map, array, xs, xsi, xml, xmlns) or
    //     unknown annotations in the XQuery namespace are XQST0045;
    //   - annotations in any other (bound) namespace are ignored.
    private bool ValidateAnnotations(
        XQueryStaticContext context,
        List<(string? Prefix, string Local, string? NamespaceUri, int Position)> annotations,
        bool isFunction)
    {
        int visibilityCount = 0;
        bool isPrivate = false;
        foreach (var (prefix, local, eqNameUri, position) in annotations)
        {
            string? ns = eqNameUri
                ?? (prefix is null
                    ? null
                    : context.Namespaces.TryGetValue(prefix, out var annotationNs)
                        ? annotationNs
                        : throw new XPathParseException($"XPST0081: Prefix '{prefix}' is not declared.", position));
            // XQST0045: annotations must not be in a reserved namespace.
            if (ns is "http://www.w3.org/2005/xpath-functions"
                or "http://www.w3.org/2005/xpath-functions/math"
                or "http://www.w3.org/2005/xpath-functions/map"
                or "http://www.w3.org/2005/xpath-functions/array"
                or "http://www.w3.org/2001/XMLSchema"
                or "http://www.w3.org/2001/XMLSchema-instance"
                or "http://www.w3.org/XML/1998/namespace"
                or "http://www.w3.org/2000/xmlns/")
            {
                throw new XPathParseException($"XQST0045: Annotation '%{local}' is in the reserved namespace '{ns}'.", position);
            }
            // Unprefixed annotation names are in the XQuery namespace, where only the
            // reserved visibility annotations are defined; anything else is XQST0045.
            if (ns is null or "http://www.w3.org/2012/xquery")
            {
                if (local is not ("public" or "private"))
                    throw new XPathParseException($"XQST0045: Unknown annotation '%{local}' in the XQuery namespace.", position);
                visibilityCount++;
                isPrivate = local == "private";
            }
            // Annotations in other namespaces are implementation-defined and ignored.
        }
        if (visibilityCount > 1)
        {
            throw new XPathParseException(
                isFunction
                    ? "XQST0106: A function declaration must not contain more than one %public or %private annotation."
                    : "XQST0116: A variable declaration must not contain more than one %public or %private annotation.",
                _position);
        }
        return isPrivate;
    }

    // Module namespace URIs, location hints, and base URI declarations get whitespace
    // normalization: leading and trailing whitespace is removed and internal whitespace
    // runs collapse to a single space.
    internal static string NormalizeModuleUri(string uri)
    {
        var trimmed = uri.Trim();
        var sb = new StringBuilder(trimmed.Length);
        bool inWhitespaceRun = false;
        foreach (char c in trimmed)
        {
            if (c is ' ' or '\t' or '\r' or '\n')
            {
                inWhitespaceRun = true;
                continue;
            }
            if (inWhitespaceRun)
            {
                sb.Append(' ');
                inWhitespaceRun = false;
            }
            sb.Append(c);
        }
        return sb.ToString();
    }

    // Phase-2 prolog declarations (context item, function, variable, option) close the
    // phase-1 window: afterwards namespace/setter/import declarations are XPST0003.
    private bool _seenSecondPhaseDecl;
    private bool _seenContextItemDecl;
    private bool _seenOrderingDecl;
    // Prefixes bound by 'declare namespace' in this prolog (XQST0033 duplicate detection).
    private readonly HashSet<string> _declaredNamespacePrefixes = new(StringComparer.Ordinal);
    private bool _isLibraryModule;
    private bool _xml11LineEndings;
    // Boundary-space policy from the prolog (declare boundary-space strip|preserve);
    // the spec default is strip. Threaded into constructor scans of this module.
    private bool _boundarySpaceStrip = true;
    private readonly List<(string Prefix, string Local, string Value, int Position)> _pendingOptions = new();

    // Matches a sequence of prolog keywords, each separated by optional whitespace/comments.
    // On failure the position is restored to the phrase start so the next alternative
    // phrase can be attempted.
    private bool TryMatchPhrase(params string[] words)
    {
        int start = _position;
        foreach (var word in words)
        {
            if (!TryMatchLiteral(word))
            {
                _position = start;
                return false;
            }
        }
        return true;
    }

    // XQST0109/XQST0110 validation for output declarations in the serialization namespace.
    private void ValidateOutputOption(XQueryStaticContext context, string local, string optionNs, int position)
    {
        if (optionNs != "http://www.w3.org/2010/xslt-xquery-serialization")
            return;
        if (!SerializationParameterNames.Contains(local))
            throw new XPathParseException($"XQST0109: Unknown serialization parameter '{local}'.", position);
        if (context.Options.Any(o => o.NamespaceUri == optionNs && o.LocalName == local))
            throw new XPathParseException($"XQST0110: Duplicate output declaration for serialization parameter '{local}'.", position);
    }

    // ------------------------------------------------------------------
    // Lexical helpers
    // ------------------------------------------------------------------

    private static bool IsValidEncodingName(string encoding)
    {
        // XML EncName: [A-Za-z] ([A-Za-z0-9._] | '-')*
        if (encoding.Length == 0 || !char.IsAsciiLetter(encoding[0]))
            return false;
        foreach (char c in encoding)
        {
            if (!char.IsAsciiLetterOrDigit(c) && c is not ('.' or '_' or '-'))
                return false;
        }
        return true;
    }

    private static bool IsSupportedCollation(string collation)
    {
        if (collation == "http://www.w3.org/2005/xpath-functions/collation/codepoint")
            return true;
        if (collation == "http://www.w3.org/2005/xpath-functions/collation/html-ascii-case-insensitive")
            return true;
        if (collation == "http://www.w3.org/2005/xpath-functions/collation/unicode-case-insensitive")
            return true;
        if (collation == "http://www.w3.org/2010/09/qt-fots-catalog/collation/caseblind")
            return true;
        if (collation.StartsWith("http://www.w3.org/2013/collation/UCA", StringComparison.Ordinal))
            return true;
        return false;
    }

    private static string ResolveCollationUri(string collation, string? baseUri)
    {
        if (string.IsNullOrEmpty(collation))
            return string.Empty;
        if (Uri.IsWellFormedUriString(collation, UriKind.Absolute))
            return collation;
        if (!string.IsNullOrEmpty(baseUri) &&
            Uri.TryCreate(new Uri(baseUri), collation, out var resolved))
        {
            return resolved.AbsoluteUri;
        }
        return collation;
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private void SkipWhitespace()
    {
        while (_position < _source.Length)
        {
            if (char.IsWhiteSpace(_source[_position]))
            {
                _position++;
                continue;
            }
            // XQuery comments (: ... :) nest and are whitespace to the prolog parser.
            if (_position + 1 < _source.Length && _source[_position] == '(' && _source[_position + 1] == ':')
            {
                int depth = 1;
                _position += 2;
                while (_position < _source.Length && depth > 0)
                {
                    if (_position + 1 < _source.Length && _source[_position] == '(' && _source[_position + 1] == ':')
                    {
                        depth++;
                        _position += 2;
                    }
                    else if (_position + 1 < _source.Length && _source[_position] == ':' && _source[_position + 1] == ')')
                    {
                        depth--;
                        _position += 2;
                    }
                    else
                    {
                        _position++;
                    }
                }
                continue;
            }
            break;
        }
    }

    private bool TryMatchLiteral(string literal)
    {
        int savedPosition = _position;
        SkipWhitespace();
        if (_source.AsSpan(_position).StartsWith(literal.AsSpan(), StringComparison.Ordinal))
        {
            int end = _position + literal.Length;
            // Ensure the match is a whole keyword/phrase boundary.
            if (end < _source.Length && IsNameChar(_source[end]))
            {
                _position = savedPosition;
                return false;
            }
            _position = end;
            return true;
        }
        _position = savedPosition;
        return false;
    }

    private void ExpectLiteral(string literal)
    {
        SkipWhitespace();
        if (!_source.AsSpan(_position).StartsWith(literal.AsSpan(), StringComparison.Ordinal))
            throw new XPathParseException($"XPST0003: Expected '{literal}'.", _position);
        _position += literal.Length;
    }

    private void ExpectChar(char c)
    {
        SkipWhitespace();
        if (_position >= _source.Length || _source[_position] != c)
            throw new XPathParseException($"XPST0003: Expected '{c}'.", _position);
        _position++;
    }

    private string ReadStringLiteral()
    {
        SkipWhitespace();
        if (_position >= _source.Length)
            throw new XPathParseException("XPST0003: Expected string literal.", _position);

        char quote = _source[_position];
        if (quote != '"' && quote != '\'')
            throw new XPathParseException("XPST0003: Expected string literal.", _position);

        _position++;
        var value = new StringBuilder();
        while (_position < _source.Length)
        {
            char c = _source[_position];
            if (c == quote)
            {
                // Check for doubled quote escape
                if (_position + 1 < _source.Length && _source[_position + 1] == quote)
                {
                    value.Append(quote);
                    _position += 2;
                    continue;
                }
                _position++;
                return value.ToString();
            }
            // XQuery string literals support predefined entity and character references;
            // a raw '&' that forms no valid reference is XPST0003.
            if (c == '&')
            {
                value.Append(ExpandCharReference());
                continue;
            }
            value.Append(c);
            _position++;
        }
        throw new XPathParseException("XPST0003: Unterminated string literal.", _position);
    }

    private string ExpandCharReference()
    {
        // _position is at the '&'.
        int start = _position;
        int semi = _source.IndexOf(';', _position + 1);
        if (semi < 0)
            throw new XPathParseException("XPST0003: Unterminated entity or character reference in string literal.", start);
        var reference = _source[(_position + 1)..semi];
        string result = reference switch
        {
            "amp" => "&",
            "lt" => "<",
            "gt" => ">",
            "quot" => "\"",
            "apos" => "'",
            _ when reference.StartsWith("#x", StringComparison.Ordinal) &&
                   int.TryParse(reference[2..], NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var hex) &&
                   hex is >= 0 and <= 0x10FFFF => char.ConvertFromUtf32(hex),
            _ when reference.StartsWith('#') &&
                   int.TryParse(reference[1..], NumberStyles.Integer, CultureInfo.InvariantCulture, out var dec) &&
                   dec is >= 0 and <= 0x10FFFF => char.ConvertFromUtf32(dec),
            _ => throw new XPathParseException($"XPST0003: Invalid entity or character reference '&{reference};' in string literal.", start)
        };
        _position = semi + 1;
        return result;
    }

    private string ReadNCName()
    {
        SkipWhitespace();
        if (_position >= _source.Length || !IsNameStartChar(_source[_position]))
            throw new XPathParseException("XPST0003: Expected NCName.", _position);

        int start = _position;
        _position++;
        while (_position < _source.Length && IsNameChar(_source[_position]))
            _position++;

        return _source[start.._position];
    }

    /// <summary>
    /// Known serialization parameter names for output declarations (XQST0109 validation).
    /// </summary>
    private static readonly HashSet<string> SerializationParameterNames = new(StringComparer.Ordinal)
    {
        "method", "version", "encoding", "indent", "omit-xml-declaration", "standalone",
        "item-separator", "media-type", "doctype-system", "doctype-public", "normalization-form",
        "json-node-output-method", "html-version", "allow-duplicate-names", "byte-order-mark",
        "escape-uri-attributes", "include-content-type", "undeclare-prefixes",
        "cdata-section-elements", "suppress-indentation", "parameter-document"
    };

    /// <summary>
    /// Reserved function names (kind-test names and keywords) that cannot be declared as
    /// unprefixed user functions.
    /// </summary>
    private static readonly HashSet<string> ReservedFunctionNames = new(StringComparer.Ordinal)
    {
        "attribute", "comment", "document-node", "element", "empty-sequence",
        "function", "if", "item", "namespace-node", "node", "processing-instruction",
        "schema-attribute", "schema-element", "switch", "text", "typeswitch",
        "array", "map"
    };

    // Reads a lexical QName (NCName, prefix:NCName, or Q{uri}NCName) without resolving prefixes.
    private (string? Prefix, string Local, string? NamespaceUri) ReadQName()
    {
        string first = ReadNCName();
        if (first == "Q" && _position < _source.Length && _source[_position] == '{')
        {
            int close = _source.IndexOf('}', _position);
            if (close < 0)
                throw new XPathParseException("XPST0003: Unterminated braced URI literal in EQName.", _position);
            var uri = _source[(_position + 1)..close];
            _position = close + 1;
            return (null, ReadNCName(), uri);
        }
        if (_position < _source.Length && _source[_position] == ':'
            && _position + 1 < _source.Length && _source[_position + 1] != '=')
        {
            _position++;
            return (first, ReadNCName(), null);
        }
        return (null, first, null);
    }

    // Reads a lexical QName and returns it in lexical form (prefix:local or Q{uri}local).
    private string ReadQNameText()
    {
        var (prefix, local, nsUri) = ReadQName();
        if (nsUri is not null)
            return $"Q{{{nsUri}}}{local}";
        return prefix is null ? local : $"{prefix}:{local}";
    }

    // Reads a sequence type in lexical form: an item type (with optional parenthesized
    // arguments) possibly unioned with '|', followed by an optional occurrence indicator.
    private string ReadSequenceTypeText()
    {
        SkipWhitespace();
        int start = _position;
        ReadItemTypeText();
        while (TryMatchChar('|'))
            ReadItemTypeText();
        if (_position < _source.Length && _source[_position] is '?' or '*' or '+')
            _position++;
        // The raw slice may contain XQuery comments that SkipWhitespace stepped over
        // (Axes089: "$square as xs:integer (: range 0 to 63 :)") — they are not part of
        // the type text.
        var text = StripComments(_source[start.._position]).Trim();
        // XPST0003: empty-sequence() must not carry an occurrence indicator.
        if (text.StartsWith("empty-sequence(", StringComparison.Ordinal)
            && text.Length > "empty-sequence()".Length)
        {
            throw new XPathParseException("XPST0003: empty-sequence() must not have an occurrence indicator.", start);
        }
        return text;
    }

    private void ReadItemTypeText(bool contextItem = false)
    {
        SkipWhitespace();
        // Parenthesized item type: '(' ItemType ('|' ItemType)* ')' — e.g. a function
        // test used as a declared return type: (function(xs:string) as xs:string*).
        if (TryMatchChar('('))
        {
            ReadItemTypeText(contextItem);
            while (TryMatchChar('|'))
            {
                if (contextItem)
                    throw new XPathParseException("XPST0003: Context item declarations require one ItemType.", _position);
                ReadItemTypeText();
            }
            SkipWhitespace();
            ExpectChar(')');
            return;
        }
        int nameStart = _position;
        while (_position < _source.Length && (IsNameChar(_source[_position]) || _source[_position] == ':' || _source[_position] == '{'))
        {
            if (_source[_position] == '{')
            {
                int close = _source.IndexOf('}', _position);
                if (close < 0)
                    throw new XPathParseException("XPST0003: Unterminated EQName in sequence type.", _position);
                _position = close + 1;
            }
            else
            {
                _position++;
            }
        }
        if (_position == nameStart)
            throw new XPathParseException("XPST0003: Expected item type.", _position);
        var itemTypeName = _source[nameStart.._position];
        // Optional parenthesized arguments: (), (*), (element-name), (*:name), etc.
        bool isTypedFunctionTest = false;
        SkipWhitespace();
        if (_position < _source.Length && _source[_position] == '(')
        {
            if (contextItem && itemTypeName == "empty-sequence")
                throw new XPathParseException("XPST0003: Context item declarations require ItemType.", nameStart);
            int contentStart = _position + 1;
            int depth = 0;
            do
            {
                if (_position >= _source.Length)
                    throw new XPathParseException("XPST0003: Unterminated '(' in sequence type.", _position);
                if (_source[_position] == '(') depth++;
                else if (_source[_position] == ')') depth--;
                _position++;
            } while (depth > 0);
            // Inside a kind test (element/attribute/schema-element/schema-attribute), the
            // optional type name must not carry an occurrence indicator ('*' or '+';
            // '?' is the XSD 1.1 nullable-type marker and is allowed — K2-ExternalVariablesWith-22a/23 vs 24..27).
            if (itemTypeName is "element" or "attribute" or "schema-element" or "schema-attribute")
            {
                var trimmed = _source[contentStart..(_position - 1)].Trim();
                bool badOccurrence = trimmed.Length > 0 && trimmed[^1] == '+';
                bool badStar = trimmed.Length > 1 && trimmed[^1] == '*'
                    && !trimmed.EndsWith(":*", StringComparison.Ordinal)
                    && !trimmed.EndsWith("}*", StringComparison.Ordinal);
                if (badOccurrence || badStar)
                    throw new XPathParseException($"XPST0003: An occurrence indicator ('*' or '+') is not allowed inside the {itemTypeName}() type.", nameStart);
            }
            // A function test that lists argument types (anything other than the
            // any-function form function(*)) is a TypedFunctionTest and requires an
            // 'as' return type (hof-910).
            if (itemTypeName == "function"
                && _source[contentStart..(_position - 1)].Trim() != "*")
            {
                isTypedFunctionTest = true;
            }
        }
        // Function tests may carry a return type: function(xs:integer) as xs:integer.
        SkipWhitespace();
        if (TryMatchLiteral("as"))
        {
            SkipWhitespace();
            ReadSequenceTypeText();
        }
        else if (isTypedFunctionTest)
        {
            throw new XPathParseException("XPST0003: A function test with argument types requires an 'as' return type.", nameStart);
        }
    }

    // Reads '{' Expr '}' and parses the enclosed expression with the XPath parser.
    private XPathAstNode ReadBracedExpression()
    {
        ExpectChar('{');
        int start = _position;
        int depth = 1;
        while (_position < _source.Length && depth > 0)
        {
            char c = _source[_position];
            if (c == '(' && _position + 1 < _source.Length && _source[_position + 1] == '#')
            {
                _position += XPathLexer.ScanPragmaLength(_source.AsSpan(_position));
                continue;
            }

            if (c == '<')
            {
                // Direct element constructor: skip the whole span (K2-Axes-1/2).
                int ctorLength = XPathLexer.ScanDirectConstructorLength(_source.AsSpan(_position));
                if (ctorLength > 0)
                {
                    _position += ctorLength;
                    continue;
                }
            }
            if (c == '\'' || c == '"')
            {
                SkipStringLiteral(c);
                continue;
            }
            if (c == '(' && _position + 1 < _source.Length && _source[_position + 1] == ':')
            {
                SkipComment();
                continue;
            }
            if (c == '{') depth++;
            else if (c == '}') depth--;
            _position++;
        }
        if (depth > 0)
            throw new XPathParseException("XPST0003: Unterminated '{' in function declaration.", _position);
        var inner = _source[start..(_position - 1)];
        // An empty (or comment-only) function body is the empty sequence (XQuery 3.1).
        if (string.IsNullOrWhiteSpace(StripComments(inner)))
            return new SequenceExpressionNode(Array.Empty<XPathAstNode>());
        return XPathParser.Parse(inner, allowFullFlwor: true, xml11LineEndings: _xml11LineEndings,
            boundarySpaceStrip: _boundarySpaceStrip);
    }

    // Scans an expression up to the top-level terminator and parses it with the XPath parser.
    // Variable initializers and context-item initial values are ExprSingle per the grammar:
    // a top-level comma is a syntax error (K2-ExternalVariablesWith-11).
    private XPathAstNode ReadExpressionTo(char terminator)
    {
        int start = _position;
        int depth = 0;
        while (_position < _source.Length)
        {
            char c = _source[_position];
            if (c == '(' && _position + 1 < _source.Length && _source[_position + 1] == '#')
            {
                _position += XPathLexer.ScanPragmaLength(_source.AsSpan(_position));
                continue;
            }

            if (c == '<')
            {
                // Direct element constructor: skip the whole span so apostrophes and
                // quotes in text content are not mistaken for string delimiters
                // (K2-Axes-1/2). '<' that does not begin a valid constructor is an operator.
                int ctorLength = XPathLexer.ScanDirectConstructorLength(_source.AsSpan(_position));
                if (ctorLength > 0)
                {
                    _position += ctorLength;
                    continue;
                }
            }
            if (c == '\'' || c == '"')
            {
                SkipStringLiteral(c);
                continue;
            }
            if (c == '(' && _position + 1 < _source.Length && _source[_position + 1] == ':')
            {
                SkipComment();
                continue;
            }
            if (c == terminator && depth == 0)
            {
                var inner = _source[start.._position];
                return XPathParser.ParseExprSingle(inner, allowFullFlwor: true, xml11LineEndings: _xml11LineEndings,
                    boundarySpaceStrip: _boundarySpaceStrip);
            }
            if (c is '(' or '[' or '{') depth++;
            else if (c is ')' or ']' or '}') depth--;
            _position++;
        }
        throw new XPathParseException($"XPST0003: Expected expression before '{terminator}'.", _position);
    }

    private void SkipStringLiteral(char quote)
    {
        _position++;
        while (_position < _source.Length)
        {
            if (_source[_position] == quote)
            {
                if (_position + 1 < _source.Length && _source[_position + 1] == quote)
                {
                    _position += 2;
                    continue;
                }
                _position++;
                return;
            }
            _position++;
        }
    }

    private void SkipComment()
    {
        int depth = 1;
        _position += 2; // at '(:'
        while (_position < _source.Length && depth > 0)
        {
            if (_position + 1 < _source.Length && _source[_position] == '(' && _source[_position + 1] == ':')
            {
                depth++;
                _position += 2;
            }
            else if (_position + 1 < _source.Length && _source[_position] == ':' && _source[_position + 1] == ')')
            {
                depth--;
                _position += 2;
            }
            else
            {
                _position++;
            }
        }
    }

    private bool TryMatchChar(char c)
    {
        SkipWhitespace();
        if (_position < _source.Length && _source[_position] == c)
        {
            _position++;
            return true;
        }
        return false;
    }

    // Removes XQuery comments (possibly nested) from a text span.
    private static string StripComments(string text)
    {
        var sb = new System.Text.StringBuilder(text.Length);
        int i = 0;
        while (i < text.Length)
        {
            if (i + 1 < text.Length && text[i] == '(' && text[i + 1] == ':')
            {
                int depth = 1;
                i += 2;
                while (i < text.Length && depth > 0)
                {
                    if (i + 1 < text.Length && text[i] == '(' && text[i + 1] == ':') { depth++; i += 2; }
                    else if (i + 1 < text.Length && text[i] == ':' && text[i + 1] == ')') { depth--; i += 2; }
                    else i++;
                }
            }
            else
            {
                sb.Append(text[i]);
                i++;
            }
        }
        return sb.ToString();
    }

    private static bool IsNameStartChar(char c)
    {
        // Simplified NCName start char check (XPath 1.0-compatible subset plus common Unicode).
        return char.IsLetter(c) || c == '_';
    }

    private static bool IsNameChar(char c)
    {
        return char.IsLetterOrDigit(c) || c == '_' || c == '.' || c == '-';
    }
}

/// <summary>
/// The result of parsing an XQuery module.
/// </summary>
internal sealed class XQueryParseResult
{
    /// <summary>
    /// The static context derived from the prolog.
    /// </summary>
    public XQueryStaticContext StaticContext { get; }

    /// <summary>
    /// The query body expression AST (the empty sequence for a library module).
    /// </summary>
    internal XPathAstNode Body { get; }

    /// <summary>
    /// True when the source was a library module (<c>module namespace ...;</c>) rather
    /// than a main module.
    /// </summary>
    public bool IsLibraryModule { get; }

    internal XQueryParseResult(XQueryStaticContext staticContext, XPathAstNode body, bool isLibraryModule = false)
    {
        StaticContext = staticContext;
        Body = body;
        IsLibraryModule = isLibraryModule;
    }
}
