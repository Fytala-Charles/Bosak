// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 22 July 2026
// PURPOSE              : Holds the static context accumulated from an XQuery prolog (namespaces, defaults, variables, functions).
// SPECIAL NOTES        : Part of the Bosak XQuery 3.1 implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 22-07-2026     | Creation — minimal static context for prolog-less queries                                |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 25-07-2026     | Store option declarations in the static context                                          |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.3   | 26-07-2026     | UserFunctionDeclaration/UserVariableDeclaration records with storage, cloning, predeclared 'local' prefix |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.4   | 27-07-2026     | ModuleImport record, ImportedModules/ModuleNamespaceUri state, IsPrivate declaration flags |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.5   | 27-07-2026     | DefaultEmptyOrderLeast static-context property |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.6   | 29-07-2026     | UndeclaredPrefixes tracking for namespace undeclarations (declare namespace p = "") |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.7   | 01-08-2026     | ContextItemTypeName records the library-module context item type declaration         |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.8   | 01-08-2026     | DecimalFormats/DeclaredDefaultDecimalFormat/BoundarySpaceStrip prolog state          |
//                      | Charles Korthout | 0.9   | 21-09-2026     | API freeze stage A: reduced accessibility (internalized Parser/Compiler types)         |
//                      | Charles Korthout | 0.10  | 21-09-2026     | API freeze stage C: internalized type                                                   |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.11  | 28-10-2026     | Represent main-module context item declarations and preserve them in clones (1.30.0).    |
//                      | Charles Korthout | 0.12  | 28-10-2026     | Carry immutable copy-namespaces modes through static-context cloning (1.31.0). |
//                      | Charles Korthout | 0.13  | 28-10-2026     | Retain immutable construction declarations across context cloning (1.32.0). |
// ===========================================================================================================================================================

using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Parser.Ast;
using Bosak.XPath.Runtime.Vm;

namespace Bosak.XQuery.Compiler;

/// <summary>A user function declared in the prolog (<c>declare function p:name($p as T, ...) as R { body }</c>).</summary>
internal sealed record UserFunctionDeclaration(
    string LocalName,
    string NamespaceUri,
    IReadOnlyList<UserFunctionParameter> Parameters,
    string? ReturnType,
    XPathAstNode Body,
    int Position,
    bool IsPrivate = false);

/// <summary>One parameter of a user function declaration: a name and an optional sequence type.</summary>
public sealed record UserFunctionParameter(string Name, string? TypeName);

/// <summary>A user variable declared in the prolog (<c>declare variable $p:name (as T)? := expr;</c> or <c>external</c>).</summary>
internal sealed record UserVariableDeclaration(
    string LocalName,
    string NamespaceUri,
    string? TypeName,
    XPathAstNode? Body,
    bool IsExternal,
    int Position,
    bool IsPrivate = false);

/// <summary>A main-module initial context item declaration.</summary>
/// <param name="TypeName">The declared ItemType, defaulting to item().</param>
/// <param name="Initializer">The initial or external-default expression, when present.</param>
/// <param name="IsExternal">Whether the host may supply the initial item.</param>
internal sealed record ContextItemDeclaration(string TypeName, XPathAstNode? Initializer, bool IsExternal);

/// <summary>A module import declaration (<c>import module namespace p = "uri" at "loc", ...;</c>).</summary>
public sealed record ModuleImport(
    string? Prefix,
    string NamespaceUri,
    IReadOnlyList<string> LocationHints,
    int Position);

/// <summary>A schema import declaration (<c>import schema namespace p = "uri" at "loc", ...;</c>).</summary>
public sealed record SchemaImport(
    string? Prefix,
    string? NamespaceUri,
    IReadOnlyList<string> LocationHints,
    int Position);

/// <summary>
/// The static context derived from an XQuery prolog. It is immutable after construction
/// and is used during compilation to resolve QNames and during execution to configure the
/// <see cref="Bosak.XPath.Runtime.Vm.EvaluationContext"/>.
/// </summary>
internal sealed class XQueryStaticContext
{
    private readonly Dictionary<string, string> _namespaces;
    private readonly Dictionary<(string LocalName, string NamespaceUri), XdmValue> _variables;
    private readonly HashSet<(string LocalName, string NamespaceUri, int Arity)> _functionSignatures;
    private readonly List<(string LocalName, string NamespaceUri, string Value)> _options;
    private readonly List<UserFunctionDeclaration> _userFunctions;
    private readonly List<UserVariableDeclaration> _userVariables;
    private readonly List<ModuleImport> _importedModules;
    private readonly List<SchemaImport> _importedSchemas;
    private readonly HashSet<string> _undeclaredPrefixes;
    private readonly Dictionary<(string LocalName, string NamespaceUri), DecimalFormat> _decimalFormats;

    /// <summary>
    /// Creates a static context with the standard XQuery namespace prefixes pre-bound.
    /// </summary>
    public XQueryStaticContext()
    {
        _namespaces = new Dictionary<string, string>
        {
            ["xml"] = "http://www.w3.org/XML/1998/namespace",
            ["xs"] = "http://www.w3.org/2001/XMLSchema",
            ["xsi"] = "http://www.w3.org/2001/XMLSchema-instance",
            ["fn"] = "http://www.w3.org/2005/xpath-functions",
            ["math"] = "http://www.w3.org/2005/xpath-functions/math",
            ["map"] = "http://www.w3.org/2005/xpath-functions/map",
            ["array"] = "http://www.w3.org/2005/xpath-functions/array",
            ["local"] = "http://www.w3.org/2005/xquery-local-functions",
            ["err"] = "http://www.w3.org/2005/xqt-errors"
        };
        _variables = new Dictionary<(string, string), XdmValue>();
        _functionSignatures = new HashSet<(string, string, int)>();
        _options = new List<(string, string, string)>();
        _userFunctions = new List<UserFunctionDeclaration>();
        _userVariables = new List<UserVariableDeclaration>();
        _importedModules = new List<ModuleImport>();
        _importedSchemas = new List<SchemaImport>();
        _undeclaredPrefixes = new HashSet<string>(StringComparer.Ordinal);
        _decimalFormats = new Dictionary<(string, string), DecimalFormat>();
    }

    private XQueryStaticContext(
        Dictionary<string, string> namespaces,
        Dictionary<(string LocalName, string NamespaceUri), XdmValue> variables,
        HashSet<(string LocalName, string NamespaceUri, int Arity)> functionSignatures,
        List<(string LocalName, string NamespaceUri, string Value)> options,
        List<UserFunctionDeclaration> userFunctions,
        List<UserVariableDeclaration> userVariables,
        List<ModuleImport> importedModules,
        List<SchemaImport> importedSchemas,
        HashSet<string> undeclaredPrefixes,
        string? defaultElementNamespace,
        string? defaultFunctionNamespace,
        string? defaultCollation,
        string? baseUri,
        string? moduleNamespaceUri,
        bool? defaultEmptyOrderLeast,
        string? contextItemTypeName,
        Dictionary<(string LocalName, string NamespaceUri), DecimalFormat> decimalFormats,
        DecimalFormat? declaredDefaultDecimalFormat,
        bool? boundarySpaceStrip,
        ContextItemDeclaration? contextDeclaration,
        bool? preserveNamespaces, bool? inheritNamespaces, XdmConstructionMode? constructionMode)
    {
        _namespaces = namespaces;
        _variables = variables;
        _functionSignatures = functionSignatures;
        _options = options;
        _userFunctions = userFunctions;
        _userVariables = userVariables;
        _importedModules = importedModules;
        _importedSchemas = importedSchemas;
        _undeclaredPrefixes = undeclaredPrefixes;
        _decimalFormats = decimalFormats;
        DefaultElementNamespace = defaultElementNamespace;
        DefaultFunctionNamespace = defaultFunctionNamespace;
        DefaultCollation = defaultCollation;
        BaseUri = baseUri;
        ModuleNamespaceUri = moduleNamespaceUri;
        DefaultEmptyOrderLeast = defaultEmptyOrderLeast;
        ContextItemTypeName = contextItemTypeName;
        DeclaredDefaultDecimalFormat = declaredDefaultDecimalFormat;
        BoundarySpaceStrip = boundarySpaceStrip;
        ContextDeclaration = contextDeclaration;
        PreserveNamespaces = preserveNamespaces;
        InheritNamespaces = inheritNamespaces;
        ConstructionMode = constructionMode;
    }

    /// <summary>
    /// The default namespace URI for unprefixed element and type names.
    /// </summary>
    public string? DefaultElementNamespace { get; private init; }

    /// <summary>
    /// The default namespace URI for unprefixed function names.
    /// Defaults to the fn namespace when not explicitly declared.
    /// </summary>
    public string? DefaultFunctionNamespace { get; private init; } = "http://www.w3.org/2005/xpath-functions";

    /// <summary>
    /// The default collation URI used by string comparison functions.
    /// </summary>
    public string? DefaultCollation { get; private init; }

    /// <summary>
    /// The static base URI for resolving relative URIs in the query.
    /// </summary>
    public string? BaseUri { get; private init; }

    /// <summary>
    /// The prolog's default order for empty sequences in order-by clauses
    /// (<c>declare default order empty least|greatest</c>); null means "least".
    /// </summary>
    public bool? DefaultEmptyOrderLeast { get; private init; }

    /// <summary>
    /// The target namespace of a library module (<c>module namespace p = "uri";</c>);
    /// null for the main module.
    /// </summary>
    public string? ModuleNamespaceUri { get; private init; }

    /// <summary>
    /// The declared context item type of a library module
    /// (<c>declare context item as T external;</c>); null when the module does not
    /// declare one. Used by fn:load-xquery-module to validate the supplied context item.
    /// </summary>
    public string? ContextItemTypeName { get; private init; }

    /// <summary>The main-module initial context item declaration, if explicitly present.</summary>
    internal ContextItemDeclaration? ContextDeclaration { get; private init; }

    /// <summary>Creates a context carrying a main-module context declaration.</summary>
    /// <param name="declaration">The parsed declaration.</param>
    /// <returns>The updated immutable static context.</returns>
    internal XQueryStaticContext WithContextDeclaration(ContextItemDeclaration declaration)
        => CloneWith(contextDeclaration: declaration);

    /// <summary>Creates a new context with the declared context item type set.</summary>
    public XQueryStaticContext WithContextItemType(string? typeName)
        => CloneWith(contextItemTypeName: typeName);

    /// <summary>
    /// The named decimal formats declared in the prolog
    /// (<c>declare decimal-format p:name …</c>), keyed by expanded name.
    /// </summary>
    public IReadOnlyDictionary<(string LocalName, string NamespaceUri), DecimalFormat> DecimalFormats => _decimalFormats;

    /// <summary>
    /// The default decimal format declared in the prolog
    /// (<c>declare default decimal-format …</c>); null when not declared.
    /// </summary>
    public DecimalFormat? DeclaredDefaultDecimalFormat { get; private init; }

    /// <summary>
    /// The boundary-space policy for direct element constructors
    /// (<c>declare boundary-space strip|preserve</c>): true = strip, false = preserve,
    /// null = not declared (spec default is strip).
    /// </summary>
    public bool? BoundarySpaceStrip { get; private init; }

    /// <summary>The declared construction mode; null selects the documented preserve default.</summary>
    public XdmConstructionMode? ConstructionMode { get; private init; }

    /// <summary>Creates a static context with the construction policy set.</summary>
    /// <param name="mode">The declared schema annotation policy.</param>
    /// <returns>The new immutable context.</returns>
    public XQueryStaticContext WithConstructionMode(XdmConstructionMode mode)
        => CloneWith(constructionMode: mode);

    /// <summary>The declared preserve/no-preserve mode; null means the default preserve.</summary>
    public bool? PreserveNamespaces { get; private init; }

    /// <summary>The declared inherit/no-inherit mode; null means the default inherit.</summary>
    public bool? InheritNamespaces { get; private init; }

    /// <summary>Creates a context with the copy-namespaces declaration set.</summary>
    /// <param name="preserve">Whether copied elements retain unused source namespace bindings.</param>
    /// <param name="inherit">Whether copied elements inherit constructor namespace bindings.</param>
    /// <returns>The new immutable static context.</returns>
    public XQueryStaticContext WithCopyNamespaces(bool preserve, bool inherit)
        => CloneWith(preserveNamespaces: preserve, inheritNamespaces: inherit);

    /// <summary>Creates a new context with a named decimal format declaration added.</summary>
    public XQueryStaticContext WithDecimalFormat(string localName, string namespaceUri, DecimalFormat format)
    {
        var copy = new Dictionary<(string, string), DecimalFormat>(_decimalFormats) { [(localName, namespaceUri)] = format };
        return CloneWith(decimalFormats: copy);
    }

    /// <summary>Creates a new context with the default decimal format declaration set.</summary>
    public XQueryStaticContext WithDeclaredDefaultDecimalFormat(DecimalFormat format)
        => CloneWith(declaredDefaultDecimalFormat: format);

    /// <summary>Creates a new context with the boundary-space policy set.</summary>
    public XQueryStaticContext WithBoundarySpace(bool strip)
        => CloneWith(boundarySpaceStrip: strip);

    /// <summary>
    /// Returns a read-only view of the namespace bindings (prefix → URI).
    /// </summary>
    public IReadOnlyDictionary<string, string> Namespaces => _namespaces;

    /// <summary>
    /// Returns a read-only view of the statically declared variables and their values.
    /// </summary>
    public IReadOnlyDictionary<(string LocalName, string NamespaceUri), XdmValue> Variables => _variables;

    /// <summary>
    /// Returns a read-only view of the declared function signatures.
    /// </summary>
    public IReadOnlyCollection<(string LocalName, string NamespaceUri, int Arity)> FunctionSignatures => _functionSignatures;

    /// <summary>
    /// Returns a read-only view of the option declarations
    /// (<c>declare option output:* "..."</c>) in prolog order.
    /// </summary>
    public IReadOnlyList<(string LocalName, string NamespaceUri, string Value)> Options => _options;

    /// <summary>Returns a read-only view of the user function declarations.</summary>
    internal IReadOnlyList<UserFunctionDeclaration> UserFunctions => _userFunctions;

    /// <summary>Returns a read-only view of the user variable declarations.</summary>
    internal IReadOnlyList<UserVariableDeclaration> UserVariables => _userVariables;

    /// <summary>Returns a read-only view of the module import declarations in prolog order.</summary>
    public IReadOnlyList<ModuleImport> ImportedModules => _importedModules;

    /// <summary>Returns a read-only view of the schema import declarations in prolog order.</summary>
    public IReadOnlyList<SchemaImport> ImportedSchemas => _importedSchemas;

    /// <summary>
    /// Prefixes explicitly undeclared in the prolog (<c>declare namespace p = "";</c>) and not
    /// later redeclared. The runtime context must unbind these (K2-NamespaceProlog-4/9).
    /// </summary>
    public IReadOnlyCollection<string> UndeclaredPrefixes => _undeclaredPrefixes;

    /// <summary>
    /// Creates a new context with an option declaration appended.
    /// </summary>
    public XQueryStaticContext WithOption(string localName, string namespaceUri, string value)
    {
        var copy = new List<(string, string, string)>(_options) { (localName, namespaceUri, value) };
        return CloneWith(options: copy);
    }

    /// <summary>Creates a new context with a user function declaration appended.</summary>
    internal XQueryStaticContext WithUserFunction(UserFunctionDeclaration declaration)
    {
        var copy = new List<UserFunctionDeclaration>(_userFunctions) { declaration };
        return CloneWith(userFunctions: copy);
    }

    /// <summary>Creates a new context with a user variable declaration appended.</summary>
    internal XQueryStaticContext WithUserVariable(UserVariableDeclaration declaration)
    {
        var copy = new List<UserVariableDeclaration>(_userVariables) { declaration };
        return CloneWith(userVariables: copy);
    }

    /// <summary>Creates a new context with a module import declaration appended.</summary>
    public XQueryStaticContext WithImportedModule(ModuleImport import)
    {
        var copy = new List<ModuleImport>(_importedModules) { import };
        return CloneWith(importedModules: copy);
    }

    /// <summary>Creates a new context with a schema import declaration appended.</summary>
    public XQueryStaticContext WithImportedSchema(SchemaImport import)
    {
        var copy = new List<SchemaImport>(_importedSchemas) { import };
        return CloneWith(importedSchemas: copy);
    }

    /// <summary>Creates a new context with the library module target namespace set.</summary>
    public XQueryStaticContext WithModuleNamespace(string? namespaceUri)
        => CloneWith(moduleNamespaceUri: namespaceUri);

    /// <summary>
    /// Creates a new context with the specified namespace binding added or replaced.
    /// A zero-length URI undeclares the prefix (XQuery namespace undeclaration, K2-ExternalVariablesWithout-3).
    /// </summary>
    public XQueryStaticContext WithNamespace(string prefix, string namespaceUri)
    {
        var copy = new Dictionary<string, string>(_namespaces);
        var undeclared = new HashSet<string>(_undeclaredPrefixes, StringComparer.Ordinal);
        if (namespaceUri.Length == 0 && prefix.Length > 0)
        {
            copy.Remove(prefix);
            undeclared.Add(prefix);
        }
        else
        {
            copy[prefix] = namespaceUri;
            undeclared.Remove(prefix);
        }
        return CloneWith(namespaces: copy, undeclaredPrefixes: undeclared);
    }

    /// <summary>
    /// Creates a new context with the specified default element namespace.
    /// </summary>
    public XQueryStaticContext WithDefaultElementNamespace(string? namespaceUri)
        => CloneWith(defaultElementNamespace: namespaceUri);

    /// <summary>
    /// Creates a new context with the specified default function namespace.
    /// </summary>
    public XQueryStaticContext WithDefaultFunctionNamespace(string? namespaceUri)
        => CloneWith(defaultFunctionNamespace: namespaceUri);

    /// <summary>
    /// Creates a new context with the specified default collation.
    /// </summary>
    public XQueryStaticContext WithDefaultCollation(string? collation)
        => CloneWith(defaultCollation: collation);

    /// <summary>
    /// Creates a new context with the specified static base URI.
    /// </summary>
    public XQueryStaticContext WithBaseUri(string? baseUri)
        => CloneWith(baseUri: baseUri);

    /// <summary>
    /// Creates a new context with the specified default order for empty sequences.
    /// </summary>
    public XQueryStaticContext WithDefaultEmptyOrderLeast(bool? least)
        => CloneWith(defaultEmptyOrderLeast: least);

    /// <summary>
    /// Creates a new context with a declared variable.
    /// </summary>
    public XQueryStaticContext WithVariable(string localName, string namespaceUri, XdmValue value)
    {
        var copy = new Dictionary<(string, string), XdmValue>(_variables) { [(localName, namespaceUri)] = value };
        return CloneWith(variables: copy);
    }

    /// <summary>
    /// Creates a new context with a declared function signature.
    /// </summary>
    public XQueryStaticContext WithFunctionSignature(string localName, string namespaceUri, int arity)
    {
        var copy = new HashSet<(string, string, int)>(_functionSignatures) { (localName, namespaceUri, arity) };
        return CloneWith(functionSignatures: copy);
    }

    private XQueryStaticContext CloneWith(
        Dictionary<string, string>? namespaces = null,
        Dictionary<(string LocalName, string NamespaceUri), XdmValue>? variables = null,
        HashSet<(string LocalName, string NamespaceUri, int Arity)>? functionSignatures = null,
        List<(string LocalName, string NamespaceUri, string Value)>? options = null,
        List<UserFunctionDeclaration>? userFunctions = null,
        List<UserVariableDeclaration>? userVariables = null,
        List<ModuleImport>? importedModules = null,
        List<SchemaImport>? importedSchemas = null,
        HashSet<string>? undeclaredPrefixes = null,
        string? defaultElementNamespace = null,
        string? defaultFunctionNamespace = null,
        string? defaultCollation = null,
        string? baseUri = null,
        string? moduleNamespaceUri = null,
        bool? defaultEmptyOrderLeast = null,
        string? contextItemTypeName = null,
        Dictionary<(string LocalName, string NamespaceUri), DecimalFormat>? decimalFormats = null,
        DecimalFormat? declaredDefaultDecimalFormat = null,
        bool? boundarySpaceStrip = null,
        ContextItemDeclaration? contextDeclaration = null,
        bool? preserveNamespaces = null, bool? inheritNamespaces = null, XdmConstructionMode? constructionMode = null)
    {
        return new XQueryStaticContext(
            namespaces ?? _namespaces,
            variables ?? _variables,
            functionSignatures ?? _functionSignatures,
            options ?? _options,
            userFunctions ?? _userFunctions,
            userVariables ?? _userVariables,
            importedModules ?? _importedModules,
            importedSchemas ?? _importedSchemas,
            undeclaredPrefixes ?? _undeclaredPrefixes,
            defaultElementNamespace ?? DefaultElementNamespace,
            defaultFunctionNamespace ?? DefaultFunctionNamespace,
            defaultCollation ?? DefaultCollation,
            baseUri ?? BaseUri,
            moduleNamespaceUri ?? ModuleNamespaceUri,
            defaultEmptyOrderLeast ?? DefaultEmptyOrderLeast,
            contextItemTypeName ?? ContextItemTypeName,
            decimalFormats ?? _decimalFormats,
            declaredDefaultDecimalFormat ?? DeclaredDefaultDecimalFormat,
            boundarySpaceStrip ?? BoundarySpaceStrip,
            contextDeclaration ?? ContextDeclaration,
            preserveNamespaces ?? PreserveNamespaces, inheritNamespaces ?? InheritNamespaces, constructionMode ?? ConstructionMode);
    }
}
