// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 22 mei 2026
// PURPOSE              : Formats integers according to XPath 3.1 fn:format-integer picture strings.
// SPECIAL NOTES        : Part of the standard XPath / XQuery function library.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 22-05-2026     | Creation                                                                                 |
//                      | Charles Korthout | 0.2   | 24-05-2026     | Made public for reuse by xsl:number formatting                                          |
//                      | Charles Korthout | 0.3   | 01-06-2026     | Greek alphabetic: include final sigma (U+03C2); base 25 for lowercase                  |
//                      | Charles Korthout | 0.4   | 01-06-2026     | Added circled digit zero (U+24EA); contiguous Unicode digit blocks for format-integer |
//                      | Charles Korthout | 0.5   | 01-06-2026     | Fixed contiguous block startValue; added multi-range sequences (circled 21-50, dingbat etc); extended block counts to 10 |
//                      | Charles Korthout | 0.6   | 01-06-2026     | Special zero for full-stop block U+2488; XdmValueToLongArray returns long[] to prevent overflow |
//                      | Charles Korthout | 0.7   | 03-06-2026     | Added BigInteger overload for formatting values > long.MaxValue (fixes number-0807)       |
//                      | Charles Korthout | 0.8   | 26-06-2026     | German word/ordinal support for xsl:number and fn:format-integer                         |
//                      | Charles Korthout | 0.9   | 15-07-2026     | Tier-2l: CJK kanji, French ordinal, Italian gender, o(-lang) suffix                     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.10  | 09-09-2026     | XML doc coverage on public API (Beta review)                                             |
//                      | Charles Korthout | 0.11  | 21-09-2026     | API freeze stage C: internalized type                                                   |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.12  | 27-10-2026     | Correct cardinal variation parsing and bounded German named ordinal endings (1.26.12). |
//                      | Charles Korthout | 0.13  | 27-10-2026     | Add bounded XPath4 radix pictures and original-value ordinals (candidate 1.27.0).       |
// ===========================================================================================================================================================

using System.Globalization;
using System.Numerics;
using System.Text;
using Bosak.XPath.Runtime.Vm;

namespace Bosak.XPath.Standard.Functions;

/// <summary>
/// Implements fn:format-integer per XPath and XQuery Functions and Operators 3.1 §4.6.
/// </summary>
internal static class FormatIntegerEngine
{
    /// <summary>
    /// Formats an integer according to an <c>fn:format-integer</c> picture string.
    /// </summary>
    /// <param name="ctx">The evaluation context.</param>
    /// <param name="value">The integer to format.</param>
    /// <param name="picture">The format picture with optional cardinal or ordinal variation and numbering modifiers.</param>
    /// <param name="language">An optional language tag (e.g. <c>de</c>, <c>fr</c>) used for word and ordinal output.</param>
    /// <returns>The formatted integer string.</returns>
    /// <exception cref="InvalidOperationException">The picture is invalid (FODF1310).</exception>
    public static string Format(EvaluationContext ctx, long value, string picture, string? language)
        => Format(ctx, new BigInteger(value), picture, language);

    /// <summary>
    /// Formats an arbitrarily large integer according to an <c>fn:format-integer</c> picture string.
    /// </summary>
    /// <param name="ctx">The evaluation context.</param>
    /// <param name="value">The integer to format.</param>
    /// <param name="picture">The format picture with optional cardinal or ordinal variation and numbering modifiers.</param>
    /// <param name="language">An optional language tag (e.g. <c>de</c>, <c>fr</c>) used for word and ordinal output.</param>
    /// <returns>The formatted integer string.</returns>
    /// <exception cref="InvalidOperationException">The picture is invalid (FODF1310).</exception>
    public static string Format(EvaluationContext ctx, BigInteger value, string picture, string? language)
    {
        // 1. Split picture into primary format token and format modifier
        ParsePicture(picture, out string primaryToken, out string modifier);

        // Empty primary token is always an error
        if (string.IsNullOrEmpty(primaryToken))
            throw new InvalidOperationException("FODF1310");

        // 2. Parse format modifier
        ParseModifier(modifier, out bool ordinal, out string? ordinalSuffix, out bool titleCase);

        // A known German word-numbering scheme may select ordinal output even under c(...).
        // Other schemes/languages retain the existing cardinal or ordinal fallback.
        if (NormalizeLanguage(language) == "de"
            && (primaryToken is "w" or "W" or "Ww")
            && GermanOrdinalEnding(ordinalSuffix) is not null)
            ordinal = true;

        // 3. Format based on primary token
        BigInteger absValue = BigInteger.Abs(value);
        string result;
        int radix = 0;
        string radixPattern = string.Empty;
        bool isRadix = ctx.IsXPath40 && TryParseRadix(primaryToken, out radix, out radixPattern);
        if (isRadix)
        {
            result = FormatRadixPattern(absValue, radixPattern, radix);
        }
        else if (TryFormatNamedToken(absValue, primaryToken, language, out result))
        {
            // Named token handled
        }
        else if (TryFormatCustomSequence(absValue, primaryToken, out result))
        {
            // Custom numbering sequence handled
        }
        else if (HasMandatoryDigits(primaryToken))
        {
            // Token contains at least one mandatory digit.
            // It must be a valid decimal-digit-pattern; any syntax error is FODF1310.
            result = FormatDecimalPattern(absValue, primaryToken);
        }
        else
        {
            // No mandatory digits: check for missing semicolon before modifier
            if (!picture.Contains(';') && TryDetectMissingSemicolon(primaryToken))
                throw new InvalidOperationException("FODF1310");

            // Unsupported numbering sequence: fallback to format token "1"
            result = FormatDecimalPattern(absValue, "1");
        }

        // 4. Apply ordinal transformation
        if (ordinal)
        {
            if (isRadix)
            {
                // Radix digits (including letters) are numeric; suffixes use the original value.
                result += !string.IsNullOrEmpty(ordinalSuffix)
                    && !ordinalSuffix.StartsWith('%') && !ordinalSuffix.StartsWith('-')
                    ? ordinalSuffix
                    : GetEnglishOrdinalSuffix((long)(absValue % 100));
            }
            else
                result = ToOrdinal(result, absValue, ordinalSuffix, language);
        }

        // 5. Apply title case
        if (titleCase && !isRadix)
        {
            result = ToTitleCase(result);
        }

        // 6. Handle negative sign
        if (value < 0)
        {
            result = "-" + result;
        }

        return result;
    }

    private static bool TryParseRadix(string token, out int radix, out string pattern)
    {
        radix = 0;
        pattern = string.Empty;
        int caret = token.IndexOf('^');
        if (caret is < 1 or > 2 || token[0] == '0')
            return false;
        for (int i = 0; i < caret; i++)
            if (token[i] is < '0' or > '9')
                return false;
        if (!int.TryParse(token.AsSpan(0, caret), NumberStyles.None, CultureInfo.InvariantCulture, out radix)
            || radix is < 2 or > 36)
            return false;
        var tail = token.AsSpan(caret + 1);
        if (tail.IndexOfAny('x', 'X') < 0)
            return false; // Without x/X, caret retains its decimal-grouping interpretation.
        pattern = token.Substring(caret + 1);
        return true;
    }

    private static string FormatRadixPattern(BigInteger magnitude, string pattern, int radix)
    {
        var codepoints = GetCodepoints(pattern).ToList();
        var separators = new List<(int Position, int Codepoint)>();
        int totalDigits = 0;
        int mandatoryDigits = 0;
        bool sawOptional = false;
        int mandatorySign = 0;
        for (int i = codepoints.Count - 1; i >= 0; i--)
        {
            int cp = codepoints[i];
            if (cp == '#')
            {
                sawOptional = true;
                totalDigits++;
            }
            else if (cp is 'x' or 'X')
            {
                if (sawOptional || (mandatorySign != 0 && mandatorySign != cp))
                    throw new InvalidOperationException("FODF1310");
                mandatorySign = cp;
                mandatoryDigits++;
                totalDigits++;
            }
            else if (IsGroupingSeparator(cp))
            {
                if (i == 0 || i == codepoints.Count - 1
                    || (codepoints[i - 1] != '#' && IsGroupingSeparator(codepoints[i - 1])))
                    throw new InvalidOperationException("FODF1310");
                separators.Add((totalDigits, cp));
            }
            else
                throw new InvalidOperationException("FODF1310");
        }
        if (mandatoryDigits == 0)
            throw new InvalidOperationException("FODF1310");

        string alphabet = mandatorySign == 'X'
            ? "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
            : "0123456789abcdefghijklmnopqrstuvwxyz";
        var reversed = new StringBuilder();
        do
        {
            magnitude = BigInteger.DivRem(magnitude, radix, out var remainder);
            reversed.Append(alphabet[(int)remainder]);
        } while (magnitude > 0);
        char[] digits = reversed.ToString().ToCharArray();
        Array.Reverse(digits);
        string padded = new string(digits).PadLeft(mandatoryDigits, '0');
        return InsertGroupingSeparators(padded, BuildGroupingTemplate(separators, totalDigits));
    }

    private static bool HasMandatoryDigits(string token)
    {
        foreach (int cp in GetCodepoints(token))
        {
            if (IsDecimalDigit(cp, out _, out _))
                return true;
        }
        return false;
    }

    private static bool TryDetectMissingSemicolon(string primaryToken)
    {
        // If token ends with o/t/c and the prefix is a valid token, it's a missing semicolon
        if (primaryToken.Length < 2) return false;
        char last = primaryToken[primaryToken.Length - 1];
        if (last == 'o' || last == 't' || last == 'c')
        {
            string prefix = primaryToken.Substring(0, primaryToken.Length - 1);
            return TryFormatNamedToken(1, prefix, out _)
                || HasMandatoryDigits(prefix);
        }
        // If token contains "o(" and the prefix is valid
        int idx = primaryToken.IndexOf("o(");
        if (idx > 0)
        {
            string prefix = primaryToken.Substring(0, idx);
            return TryFormatNamedToken(1, prefix, out _)
                || HasMandatoryDigits(prefix);
        }
        return false;
    }

    private static void ParsePicture(string picture, out string primaryToken, out string modifier)
    {
        int lastSemi = picture.LastIndexOf(';');
        if (lastSemi >= 0)
        {
            primaryToken = picture.Substring(0, lastSemi);
            modifier = picture.Substring(lastSemi + 1);
        }
        else
        {
            primaryToken = picture;
            modifier = string.Empty;
        }
    }

    private static void ParseModifier(string modifier, out bool ordinal, out string? ordinalSuffix, out bool titleCase)
    {
        ordinal = false;
        ordinalSuffix = null;
        titleCase = false;

        if (string.IsNullOrEmpty(modifier))
            return;

        string remaining = modifier;

        // Check for title case flag ('t' outside any parenthesized suffix).
        // This must run before ordinal detection so that ordinal scheme names
        // such as "%spellout-ordinal" do not accidentally enable title case.
        if (HasTitleCaseFlag(remaining))
        {
            titleCase = true;
            remaining = RemoveTitleCaseFlag(remaining);
        }

        // Check for cardinal
        if (remaining == "c" || string.IsNullOrEmpty(remaining))
        {
            return;
        }

        // Check for ordinal
        if (remaining == "o")
        {
            ordinal = true;
            return;
        }

        // Both cardinal and ordinal modifiers may carry a nonempty variation name.
        if (remaining.Length > 3
            && (remaining[0] is 'c' or 'o')
            && remaining[1] == '(' && remaining[^1] == ')')
        {
            // Preserve the existing balanced-parenthesis convention.
            if (remaining.Count(c => c == '(') != remaining.Count(c => c == ')'))
                throw new InvalidOperationException("FODF1310");

            ordinal = remaining[0] == 'o';
            ordinalSuffix = remaining.Substring(2, remaining.Length - 3);
            return;
        }

        // Invalid modifier
        throw new InvalidOperationException("FODF1310");
    }

    private static bool HasTitleCaseFlag(string s)
    {
        int depth = 0;
        foreach (char c in s)
        {
            if (c == '(') depth++;
            else if (c == ')') depth--;
            else if (c == 't' && depth == 0) return true;
        }
        return false;
    }

    private static string RemoveTitleCaseFlag(string s)
    {
        var sb = new StringBuilder();
        int depth = 0;
        foreach (char c in s)
        {
            if (c == '(')
            {
                depth++;
                sb.Append(c);
            }
            else if (c == ')')
            {
                depth--;
                sb.Append(c);
            }
            else if (c == 't' && depth == 0)
            {
                // skip title-case flag
            }
            else
            {
                sb.Append(c);
            }
        }
        return sb.ToString();
    }

    private static bool TryFormatNamedToken(BigInteger value, string primaryToken, out string result)
        => TryFormatNamedToken(value, primaryToken, null, out result);

    private static bool TryFormatNamedToken(BigInteger value, string primaryToken, string? language, out string result)
    {
        if (value > long.MaxValue || value < 0)
        {
            result = null!;
            return false;
        }
        long v = (long)value;
        result = primaryToken switch
        {
            "a" => ToAlphabetic(v, false),
            "A" => ToAlphabetic(v, true),
            "i" => ToRoman(v, false),
            "I" => ToRoman(v, true),
            "w" => ToWords(v, false, language),
            "W" => ToWords(v, true, language),
            "Ww" => ToWordsTitle(v, language),
            _ => null!
        };
        return result is not null;
    }

    private static bool TryFormatCustomSequence(BigInteger value, string primaryToken, out string result)
    {
        result = string.Empty;
        if (string.IsNullOrEmpty(primaryToken))
            return false;
        if (value > long.MaxValue || value < 0)
            return false;
        long v = (long)value;

        var codepoints = GetCodepoints(primaryToken).ToList();
        if (codepoints.Count != 1)
            return false;

        int cp = codepoints[0];

        // CJK kanji numbering sequence (primary token U+4E00)
        if (cp == 0x4E00)
        {
            result = FormatCjkKanji(v);
            return true;
        }

        // Circled digits: U+24EA (0), U+2460-U+2473 (1-20), U+3251-U+325F (21-35), U+32B1-U+32BF (36-50)
        if (cp >= 0x2460 && cp <= 0x2473)
        {
            if (v == 0)
            {
                result = "\u24EA";
                return true;
            }
            if (v <= 20) { result = char.ConvertFromUtf32((int)(0x2460 + v - 1)); return true; }
            if (v <= 35) { result = char.ConvertFromUtf32((int)(0x3251 + v - 21)); return true; }
            if (v <= 50) { result = char.ConvertFromUtf32((int)(0x32B1 + v - 36)); return true; }
            return false;
        }

        // Digits with full stop: special zero U+1F100, primary U+2488-U+249B (1-20)
        if (cp == 0x1F100)
        {
            if (v == 0) { result = "\ud83c\udd00"; return true; }
            if (v > 20) return false;
            result = char.ConvertFromUtf32((int)(0x2488 + v - 1));
            return true;
        }
        if (cp >= 0x2488 && cp <= 0x249B)
        {
            if (v == 0) { result = "\ud83c\udd00"; return true; }
            if (v > 20) return false;
            result = char.ConvertFromUtf32((int)(0x2488 + v - 1));
            return true;
        }

        // Dingbat negative circled: special zero U+24FF, primary U+2776-U+277F (1-10), secondary U+24EB-U+24F3 (11-20)
        if (cp == 0x2776)
        {
            if (v == 0) { result = "\u24FF"; return true; }
            if (v <= 10) { result = char.ConvertFromUtf32((int)(0x2776 + v - 1)); return true; }
            if (v <= 20) { result = char.ConvertFromUtf32((int)(0x24EB + v - 11)); return true; }
            return false;
        }

        // Dingbat circled sans-serif: special zero U+1F10B, primary U+2780-U+2789 (1-10)
        if (cp == 0x2780)
        {
            if (v == 0) { result = "\ud83c\udd0b"; return true; }
            if (v > 10) return false;
            result = char.ConvertFromUtf32((int)(0x2780 + v - 1));
            return true;
        }

        // Dingbat negative circled sans-serif: special zero U+1F10C, primary U+278A-U+2793 (1-10)
        if (cp == 0x278A)
        {
            if (v == 0) { result = "\ud83c\udd0c"; return true; }
            if (v > 10) return false;
            result = char.ConvertFromUtf32((int)(0x278A + v - 1));
            return true;
        }

        // Greek uppercase letters: U+0391-U+03A1 (24 letters, excluding U+03A2)
        if (cp == 0x0391)
        {
            result = ToGreekAlphabetic(v, true);
            return true;
        }

        // Greek lowercase letters: U+03B1-U+03C9 (24 letters, excluding U+03C2)
        if (cp == 0x03B1)
        {
            result = ToGreekAlphabetic(v, false);
            return true;
        }

        // Generic contiguous digit blocks (also handles parenthesized, full-stop, etc.)
        if (TryFormatContiguousBlock(v, cp, out result))
            return true;

        return false;
    }

    private static string FormatCjkKanji(long n)
    {
        if (n <= 0)
            return "\u96F6"; // zero
        string[] digits = { "", "\u4E00", "\u4E8C", "\u4E09", "\u56DB", "\u4E94", "\u516D", "\u4E03", "\u516B", "\u4E5D" };
        string[] units = { "", "\u5341", "\u767E", "\u5343" };

        int thousands = (int)(n / 1000);
        int hundreds = (int)((n % 1000) / 100);
        int tens = (int)((n % 100) / 10);
        int ones = (int)(n % 10);

        var sb = new StringBuilder();
        if (thousands > 0)
        {
            if (thousands != 1) sb.Append(digits[thousands]);
            sb.Append(units[3]);
        }
        if (hundreds > 0)
        {
            if (hundreds != 1) sb.Append(digits[hundreds]);
            sb.Append(units[2]);
        }
        if (tens > 0)
        {
            if (tens != 1) sb.Append(digits[tens]);
            sb.Append(units[1]);
        }
        if (ones > 0)
            sb.Append(digits[ones]);
        return sb.ToString();
    }

    /// <summary>
    /// Known contiguous Unicode digit/number blocks used by <c>fn:format-integer</c>.
    /// Each tuple is (startCodepoint, count, startValue).
    /// </summary>
    private static readonly (int Start, int Count, int StartValue)[] ContiguousDigitBlocks = new[]
    {
        // Parenthesized digits: U+2474-U+2487 (1-20)
        (0x2474, 20, 1),
        // Digits with full stop: U+2488-U+249B (1-20)
        (0x2488, 20, 1),
        // Double circled: U+24F5-U+24FE (1-10)
        (0x24F5, 10, 1),
        // Dingbat negative circled: U+2776-U+277F (1-10) — handled by TryFormatCustomSequence for multi-range
        (0x2776, 10, 1),
        // Dingbat circled sans-serif: U+2780-U+2789 (1-10) — handled by TryFormatCustomSequence for special zero
        (0x2780, 10, 1),
        // Dingbat negative circled sans-serif: U+278A-U+2793 (1-10) — handled by TryFormatCustomSequence for special zero
        (0x278A, 10, 1),
        // Circled ideograph: U+3280-U+3289 (1-10)
        (0x3280, 10, 1),
        // Parenthesized ideograph: U+3220-U+3229 (1-10)
        (0x3220, 10, 1),
        // Aegean number: U+10107-U+10110 (1-10)
        (0x10107, 10, 1),
        // Rumi digit: U+10E60-U+10E69 (1-10)
        (0x10E60, 10, 1),
        // Brahmi number: U+11052-U+1105B (1-10)
        (0x11052, 10, 1),
        // Sinhala archaic digit: U+111E1-U+111EA (1-10)
        (0x111E1, 10, 1),
        // Coptic epact digit: U+102E1-U+102EA (1-10)
        (0x102E1, 10, 1),
        // Mende Kikakui digit: U+1E8C7-U+1E8CF (1-9)
        (0x1E8C7, 9, 1),
        // Counting rod / Tai Xuan Jing: U+1D360-U+1D368 (1-9)
        (0x1D360, 9, 1),
        // Adlam digit: U+1E947-U+1E94F (1-9)
        (0x1E947, 9, 1),
        // Digit with comma: U+1F101-U+1F10A (0-9)
        (0x1F101, 10, 0),
    };

    /// <summary>
    /// Tries to format <paramref name="value"/> using a known contiguous Unicode digit block.
    /// Any codepoint within the block identifies the sequence (not just the first codepoint).
    /// </summary>
    private static bool TryFormatContiguousBlock(BigInteger value, int tokenCp, out string result)
    {
        result = string.Empty;
        if (value > int.MaxValue || value < 0)
            return false;
        int v = (int)value;
        foreach (var (blockStart, count, startValue) in ContiguousDigitBlocks)
        {
            if (tokenCp >= blockStart && tokenCp < blockStart + count)
            {
                if (v < startValue || v >= startValue + count) return false;
                result = char.ConvertFromUtf32(blockStart + v - startValue);
                return true;
            }
        }
        return false;
    }

    private static string ToGreekAlphabetic(long n, bool upper)
    {
        if (n <= 0) return n.ToString(CultureInfo.InvariantCulture);
        // Uppercase Greek: U+0391-U+03A1 (17 letters), skip U+03A2, then U+03A3-U+03A9 (7 letters) = 24 total.
        int[] upperCodes = { 0x0391, 0x0392, 0x0393, 0x0394, 0x0395, 0x0396, 0x0397, 0x0398, 0x0399, 0x039A, 0x039B, 0x039C, 0x039D, 0x039E, 0x039F, 0x03A0, 0x03A1, 0x03A3, 0x03A4, 0x03A5, 0x03A6, 0x03A7, 0x03A8, 0x03A9 };
        // Lowercase Greek: U+03B1-U+03C9 inclusive = 25 letters (includes both final sigma U+03C2 and regular sigma U+03C3).
        int[] lowerCodes = { 0x03B1, 0x03B2, 0x03B3, 0x03B4, 0x03B5, 0x03B6, 0x03B7, 0x03B8, 0x03B9, 0x03BA, 0x03BB, 0x03BC, 0x03BD, 0x03BE, 0x03BF, 0x03C0, 0x03C1, 0x03C2, 0x03C3, 0x03C4, 0x03C5, 0x03C6, 0x03C7, 0x03C8, 0x03C9 };
        var codes = upper ? upperCodes : lowerCodes;
        int @base = upper ? 24 : 25;
        var sb = new StringBuilder();
        while (n > 0)
        {
            n--;
            sb.Insert(0, char.ConvertFromUtf32(codes[n % @base]));
            n /= @base;
        }
        return sb.ToString();
    }

    private static bool TryFormatDecimalPattern(BigInteger value, string primaryToken, out string result)
    {
        result = string.Empty;
        try
        {
            result = FormatDecimalPattern(value, primaryToken);
            return true;
        }
        catch
        {
            return false;
        }
    }

    private static string FormatDecimalPattern(BigInteger value, string primaryToken)
    {
        if (string.IsNullOrEmpty(primaryToken))
            throw new InvalidOperationException("FODF1310");

        // Check for decimal separator (for default decimal format, it's '.')
        // TODO: Use actual decimal format from context
        if (primaryToken.Contains('.'))
            throw new InvalidOperationException("FODF1310");

        // Parse the token using codepoints to handle astral plane characters
        var separators = new List<(int Position, int Codepoint)>();
        bool sawHash = false;
        bool hasMandatory = false;
        int? zeroDigitCodepoint = null;
        int totalDigits = 0;

        var codepoints = GetCodepoints(primaryToken).ToList();

        for (int i = codepoints.Count - 1; i >= 0; i--)
        {
            int cp = codepoints[i];
            if (cp == '#')
            {
                sawHash = true;
                totalDigits++;
            }
            else if (IsDecimalDigit(cp, out int digitValue, out int zeroCp))
            {
                if (sawHash)
                    throw new InvalidOperationException("FODF1310"); // mandatory digit after optional digit (from right)
                hasMandatory = true;
                if (zeroDigitCodepoint.HasValue)
                {
                    if (zeroCp != zeroDigitCodepoint.Value)
                        throw new InvalidOperationException("FODF1310"); // mixed families
                }
                else
                {
                    zeroDigitCodepoint = zeroCp;
                }
                totalDigits++;
            }
            else if (IsGroupingSeparator(cp))
            {
                if (i == 0 || i == codepoints.Count - 1)
                    throw new InvalidOperationException("FODF1310"); // at start or end
                // Check adjacent grouping separators (optional-digit-sign # is not a grouping separator)
                if (i > 0 && codepoints[i - 1] != '#' && IsGroupingSeparator(codepoints[i - 1]))
                    throw new InvalidOperationException("FODF1310");
                separators.Add((totalDigits, cp)); // position is number of digits to the right
            }
            else
            {
                throw new InvalidOperationException("FODF1310"); // invalid character
            }
        }

        if (!hasMandatory)
            throw new InvalidOperationException("FODF1310"); // no mandatory digit

        // Build grouping separator template
        var template = BuildGroupingTemplate(separators, totalDigits);

        // Format the number
        BigInteger absValue = BigInteger.Abs(value);
        string s1 = absValue.ToString(CultureInfo.InvariantCulture);
        int minWidth = codepoints.Count(cp => IsDecimalDigit(cp, out _, out _));
        
        // Pad with zeroes
        string s2 = s1.PadLeft(minWidth, '0');

        // Map digits to selected family
        string s3 = zeroDigitCodepoint.HasValue && zeroDigitCodepoint.Value != '0'
            ? MapDigits(s2, zeroDigitCodepoint.Value)
            : s2;

        // Insert grouping separators
        string s4 = InsertGroupingSeparators(s3, template);

        return s4;
    }

    private static IEnumerable<int> GetCodepoints(string s)
    {
        for (int i = 0; i < s.Length;)
        {
            int cp = char.ConvertToUtf32(s, i);
            yield return cp;
            i += char.IsHighSurrogate(s[i]) ? 2 : 1;
        }
    }

    private static bool IsDecimalDigit(int codepoint, out int digitValue, out int zeroCodepoint)
    {
        // Check for ASCII digits
        if (codepoint >= '0' && codepoint <= '9')
        {
            digitValue = codepoint - '0';
            zeroCodepoint = '0';
            return true;
        }

        // Check for other Unicode decimal digits (Nd category)
        string s = char.ConvertFromUtf32(codepoint);
        var cat = CharUnicodeInfo.GetUnicodeCategory(s, 0);
        if (cat == UnicodeCategory.DecimalDigitNumber)
        {
            digitValue = (int)CharUnicodeInfo.GetDigitValue(s, 0);
            // Find zero digit of this family
            zeroCodepoint = codepoint - digitValue;
            return true;
        }

        digitValue = -1;
        zeroCodepoint = 0;
        return false;
    }

    private static bool IsGroupingSeparator(int codepoint)
    {
        string s = char.ConvertFromUtf32(codepoint);
        var cat = CharUnicodeInfo.GetUnicodeCategory(s, 0);
        // Non-alphanumeric: not Nd, Nl, No, Lu, Ll, Lt, Lm, Lo
        return cat != UnicodeCategory.DecimalDigitNumber
            && cat != UnicodeCategory.LetterNumber
            && cat != UnicodeCategory.OtherNumber
            && cat != UnicodeCategory.UppercaseLetter
            && cat != UnicodeCategory.LowercaseLetter
            && cat != UnicodeCategory.TitlecaseLetter
            && cat != UnicodeCategory.ModifierLetter
            && cat != UnicodeCategory.OtherLetter;
    }

    private static List<(int Position, int Codepoint)> BuildGroupingTemplate(List<(int Position, int Codepoint)> separators, int totalDigits)
    {
        if (separators.Count == 0)
            return new List<(int, int)>();

        // Check if regular
        bool sameChar = separators.All(s => s.Codepoint == separators[0].Codepoint);
        if (sameChar)
        {
            var positions = separators.Select(s => s.Position).OrderBy(p => p).ToList();
            // Find G: the smallest position
            int g = positions[0];
            // Check if all positions are multiples of g
            bool allMultiples = positions.All(p => p % g == 0);
            // Check if every multiple of g less than totalDigits is present
            bool allPresent = true;
            for (int m = g; m < totalDigits; m += g)
            {
                if (!positions.Contains(m))
                {
                    allPresent = false;
                    break;
                }
            }

            if (allMultiples && allPresent)
            {
                // Regular grouping - infinite template
                var template = new List<(int, int)>();
                int cp = separators[0].Codepoint;
                for (int n = 1; n * g < 1000; n++) // practical limit
                {
                    template.Add((n * g, cp));
                }
                return template;
            }
        }

        // Non-regular - return explicit separators
        return separators.OrderBy(s => s.Position).ToList();
    }

    private static string MapDigits(string digits, int zeroCodepoint)
    {
        var sb = new StringBuilder(digits.Length * 2);
        foreach (char c in digits)
        {
            if (c >= '0' && c <= '9')
            {
                int digitValue = c - '0';
                int targetCp = zeroCodepoint + digitValue;
                sb.Append(char.ConvertFromUtf32(targetCp));
            }
            else
            {
                sb.Append(c);
            }
        }
        return sb.ToString();
    }

    private static string InsertGroupingSeparators(string digits, List<(int Position, int Codepoint)> template)
    {
        if (template.Count == 0)
            return digits;

        // Count actual digit characters (not surrogate pairs)
        int digitCount = CountCodepoints(digits);

        // Build a list of insertion points
        var insertions = new List<(int FromRight, int Codepoint)>();
        foreach (var (pos, cp) in template)
        {
            if (pos < digitCount)
            {
                insertions.Add((pos, cp));
            }
        }

        // Sort by position from right, descending
        insertions = insertions.OrderByDescending(i => i.FromRight).ToList();

        var sb = new StringBuilder(digits.Length + insertions.Count * 2);
        int currentDigitFromRight = 0;
        
        // Iterate through digits from right to left
        for (int i = digits.Length - 1; i >= 0;)
        {
            // Get the current codepoint
            int cp;
            if (i > 0 && char.IsLowSurrogate(digits[i]) && char.IsHighSurrogate(digits[i - 1]))
            {
                cp = char.ConvertToUtf32(digits[i - 1], digits[i]);
                sb.Insert(0, char.ConvertFromUtf32(cp));
                i -= 2;
            }
            else
            {
                cp = digits[i];
                sb.Insert(0, (char)cp);
                i--;
            }
            
            currentDigitFromRight++;
            
            // Check if we need to insert a separator after this digit
            foreach (var (pos, sepCp) in insertions)
            {
                if (pos == currentDigitFromRight)
                {
                    sb.Insert(0, char.ConvertFromUtf32(sepCp));
                    break;
                }
            }
        }

        return sb.ToString();
    }

    private static int CountCodepoints(string s)
    {
        int count = 0;
        for (int i = 0; i < s.Length;)
        {
            count++;
            i += char.IsHighSurrogate(s[i]) ? 2 : 1;
        }
        return count;
    }

    private static string ToOrdinal(string result, BigInteger value, string? suffix, string? language)
    {
        // Simple heuristic: if result contains only digits (and separators), treat as digits
        bool isDigits = result.All(c => char.IsDigit(c) || IsGroupingSeparatorChar(c));
        
        if (isDigits)
        {
            // A parenthesized suffix starting with '-' is a language/variant hint, not a literal suffix.
            if (!string.IsNullOrEmpty(suffix) && !suffix.StartsWith('%') && !suffix.StartsWith('-'))
                return result + suffix;

            // Remove grouping separators for suffix determination
            string clean = new string(result.Where(char.IsDigit).ToArray());
            if (!string.IsNullOrEmpty(clean) && long.TryParse(clean, out long num))
            {
                return result + GetEnglishOrdinalSuffix(num);
            }
            return result + "th";
        }
        else
        {
            // For words, convert to ordinal word
            if (value > long.MaxValue || value < 0)
                return result + (suffix ?? "th");
            var lang = NormalizeLanguage(language);
            if (lang == "de")
                return GermanToOrdinalWords(result, suffix);
            if (lang == "it")
                return ItalianToOrdinal(value, suffix, result);
            if (lang == "fr")
                return FrenchToOrdinalWords(result, (long)value, suffix);
            return ToOrdinalWords(result, (long)value, language);
        }
    }

    private static bool IsGroupingSeparatorChar(char c)
    {
        var cat = CharUnicodeInfo.GetUnicodeCategory(c);
        return cat != UnicodeCategory.DecimalDigitNumber
            && cat != UnicodeCategory.LetterNumber
            && cat != UnicodeCategory.OtherNumber
            && cat != UnicodeCategory.UppercaseLetter
            && cat != UnicodeCategory.LowercaseLetter
            && cat != UnicodeCategory.TitlecaseLetter
            && cat != UnicodeCategory.ModifierLetter
            && cat != UnicodeCategory.OtherLetter;
    }

    private static string GetEnglishOrdinalSuffix(long n)
    {
        long lastTwo = Math.Abs(n) % 100;
        if (lastTwo >= 11 && lastTwo <= 13)
            return "th";
        
        long lastDigit = lastTwo % 10;
        return lastDigit switch
        {
            1 => "st",
            2 => "nd",
            3 => "rd",
            _ => "th"
        };
    }

    private static string ToOrdinalWords(string cardinalWord, long value, string? language)
    {
        string lower = cardinalWord.ToLowerInvariant();
        
        // Special cases for simple numbers
        string? ordinal = lower switch
        {
            "one" => "first",
            "two" => "second",
            "three" => "third",
            "five" => "fifth",
            "eight" => "eighth",
            "nine" => "ninth",
            "eleven" => "eleventh",
            "twelve" => "twelfth",
            "thirteen" => "thirteenth",
            "fourteen" => "fourteenth",
            "fifteen" => "fifteenth",
            "sixteen" => "sixteenth",
            "seventeen" => "seventeenth",
            "eighteen" => "eighteenth",
            "nineteen" => "nineteenth",
            "twenty" => "twentieth",
            "thirty" => "thirtieth",
            "forty" => "fortieth",
            "fifty" => "fiftieth",
            "sixty" => "sixtieth",
            "seventy" => "seventieth",
            "eighty" => "eightieth",
            "ninety" => "ninetieth",
            "hundred" => "hundredth",
            "thousand" => "thousandth",
            "million" => "millionth",
            "billion" => "billionth",
            "zero" => "zeroth",
            _ => null
        };

        if (ordinal is not null)
        {
            return MatchCase(cardinalWord, ordinal);
        }

        // If it ends with "y", replace with "ieth"
        if (lower.EndsWith("y"))
            return cardinalWord.Substring(0, cardinalWord.Length - 1) + "ieth";

        // If it contains compound number words with spaces/hyphens, replace only the last word
        if (lower.Contains(' ') || lower.Contains('-'))
        {
            return ReplaceLastWordWithOrdinal(cardinalWord, value, language);
        }

        // Default: append "th" (preserving case of the original)
        return MatchCase(cardinalWord, cardinalWord.ToLowerInvariant() + "th");
    }

    private static string MatchCase(string original, string replacement)
    {
        // Preserve case of the original word
        if (original.All(char.IsUpper))
            return replacement.ToUpperInvariant();
        if (char.IsUpper(original[0]))
            return char.ToUpperInvariant(replacement[0]) + replacement.Substring(1);
        return replacement;
    }

    private static string ReplaceLastWordWithOrdinal(string original, long value, string? language)
    {
        int lastSpace = original.LastIndexOf(' ');
        int lastHyphen = original.LastIndexOf('-');
        int splitAt = Math.Max(lastSpace, lastHyphen);
        
        if (splitAt < 0)
        {
            return original + "th";
        }
        
        string prefix = original.Substring(0, splitAt + 1);
        string lastWord = original.Substring(splitAt + 1);
        string ordinalLast = ToOrdinalWords(lastWord, value, language);
        return prefix + ordinalLast;
    }

    private static string ToTitleCase(string s)
    {
        return CultureInfo.InvariantCulture.TextInfo.ToTitleCase(s.ToLowerInvariant());
    }

    private static string ToAlphabetic(long n, bool upper)
    {
        if (n <= 0) return n.ToString(CultureInfo.InvariantCulture);
        StringBuilder sb = new();
        while (n > 0)
        {
            n--;
            char c = (char)(n % 26 + (upper ? 'A' : 'a'));
            sb.Insert(0, c);
            n /= 26;
        }
        return sb.ToString();
    }

    private static string ToRoman(long n, bool upper)
    {
        if (n <= 0 || n > 3999) return n.ToString(CultureInfo.InvariantCulture);
        var values = new[] { 1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1 };
        var symbols = new[] { "M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I" };
        StringBuilder sb = new();
        for (int i = 0; i < values.Length; i++)
        {
            while (n >= values[i])
            {
                sb.Append(symbols[i]);
                n -= values[i];
            }
        }
        return upper ? sb.ToString() : sb.ToString().ToLowerInvariant();
    }

    private static string ToWords(long n, bool upper, string? language)
    {
        string s = NumberToWords(n, language);
        if (!upper)
            return s.ToLowerInvariant();
        // Invariant uppercasing leaves German ß (U+00DF) unchanged; normalize to SS.
        return s.ToUpperInvariant().Replace("ß", "SS");
    }

    private static string ToWordsTitle(long n, string? language)
    {
        string s = NumberToWords(n, language);
        return CultureInfo.InvariantCulture.TextInfo.ToTitleCase(s.ToLowerInvariant());
    }

    private static string NumberToWords(long n, string? language)
    {
        var lang = NormalizeLanguage(language);
        if (lang == "de")
            return GermanNumberToWords(n);
        if (lang == "fr")
            return FrenchNumberToWords(n);
        return EnglishNumberToWords(n);
    }

    private static string EnglishNumberToWords(long n)
    {
        if (n == 0) return "zero";
        if (n < 0) return "minus " + EnglishNumberToWords(-n);
        if (n <= 19) return new[] { "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen" }[n - 1];
        if (n < 100)
        {
            var tens = new[] { "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety" };
            string r = tens[n / 10 - 2];
            if (n % 10 > 0) r += "-" + EnglishNumberToWords(n % 10);
            return r;
        }
        if (n < 1000)
        {
            string r = EnglishNumberToWords(n / 100) + " hundred";
            if (n % 100 > 0) r += " and " + EnglishNumberToWords(n % 100);
            return r;
        }
        if (n < 1000000)
        {
            string r = EnglishNumberToWords(n / 1000) + " thousand";
            if (n % 1000 > 0) r += " " + EnglishNumberToWords(n % 1000);
            return r;
        }
        if (n < 1000000000)
        {
            string r = EnglishNumberToWords(n / 1000000) + " million";
            if (n % 1000000 > 0) r += " " + EnglishNumberToWords(n % 1000000);
            return r;
        }
        string rr = EnglishNumberToWords(n / 1000000000) + " billion";
        if (n % 1000000000 > 0) rr += " " + EnglishNumberToWords(n % 1000000000);
        return rr;
    }

    private static string NormalizeLanguage(string? language)
    {
        if (string.IsNullOrWhiteSpace(language))
            return "en";
        var trimmed = language.Trim();
        if (trimmed.Length >= 2)
            return trimmed.Substring(0, 2).ToLowerInvariant();
        return trimmed.ToLowerInvariant();
    }

    private static string GermanNumberToWords(long n)
    {
        if (n == 0) return "null";
        if (n < 0) return "minus " + GermanNumberToWords(-n);
        if (n <= 19) return new[] { "eins", "zwei", "drei", "vier", "fünf", "sechs", "sieben", "acht", "neun", "zehn", "elf", "zwölf", "dreizehn", "vierzehn", "fünfzehn", "sechzehn", "siebzehn", "achtzehn", "neunzehn" }[n - 1];
        if (n < 100)
        {
            var tens = new[] { "zwanzig", "dreißig", "vierzig", "fünfzig", "sechzig", "siebzig", "achtzig", "neunzig" };
            long t = n / 10;
            long u = n % 10;
            if (u == 0) return tens[t - 2];
            string unit = u == 1 ? "ein" : GermanNumberToWords(u);
            return unit + "und" + tens[t - 2];
        }
        if (n < 1000)
        {
            long h = n / 100;
            long r = n % 100;
            string hw = h == 1 ? "einhundert" : GermanNumberToWords(h) + "hundert";
            if (r == 0) return hw;
            return hw + GermanNumberToWords(r);
        }
        if (n < 1_000_000)
        {
            long t = n / 1000;
            long r = n % 1000;
            string tw = t == 1 ? "eintausend" : GermanNumberToWords(t) + "tausend";
            if (r == 0) return tw;
            return tw + GermanNumberToWords(r);
        }
        if (n < 1_000_000_000)
        {
            long m = n / 1_000_000;
            long r = n % 1_000_000;
            string mw = m == 1 ? "eine Million" : GermanNumberToWords(m) + " Millionen";
            if (r == 0) return mw;
            return mw + " " + GermanNumberToWords(r);
        }
        return n.ToString(CultureInfo.InvariantCulture);
    }

    // Bounded aliases from the pinned German CLDR rules; feminine is the legacy e alias.
    private static string? GermanOrdinalEnding(string? variation) => variation switch
    {
        "%spellout-ordinal" or "%spellout-ordinal-feminine" => "e",
        "%spellout-ordinal-s" => "es",
        "%spellout-ordinal-r" => "er",
        "%spellout-ordinal-n" => "en",
        _ => null,
    };

    private static string GermanToOrdinalWords(string cardinalWord, string? suffix)
    {
        string ending = GermanOrdinalEnding(suffix)
            ?? (string.IsNullOrEmpty(suffix) || suffix.StartsWith("%") ? "e" : suffix.TrimStart('-'));
        int lastSpace = cardinalWord.LastIndexOf(' ');
        if (lastSpace < 0)
            return MatchCase(cardinalWord, GermanMakeOrdinalLastWord(cardinalWord.ToLowerInvariant(), ending));

        string prefix = cardinalWord.Substring(0, lastSpace + 1);
        string last = cardinalWord.Substring(lastSpace + 1);
        return prefix + MatchCase(last, GermanMakeOrdinalLastWord(last.ToLowerInvariant(), ending));
    }

    private static string GermanMakeOrdinalLastWord(string lowerLast, string ending)
    {
        // Units (including when they terminate a compound word)
        if (lowerLast.EndsWith("eins")) return lowerLast.Substring(0, lowerLast.Length - 4) + "erst" + ending;
        if (lowerLast.EndsWith("zwei")) return lowerLast.Substring(0, lowerLast.Length - 4) + "zweit" + ending;
        if (lowerLast.EndsWith("drei")) return lowerLast.Substring(0, lowerLast.Length - 4) + "dritt" + ending;
        if (lowerLast.EndsWith("vier")) return lowerLast.Substring(0, lowerLast.Length - 4) + "viert" + ending;
        if (lowerLast.EndsWith("fünf")) return lowerLast.Substring(0, lowerLast.Length - 4) + "fünft" + ending;
        if (lowerLast.EndsWith("sechs")) return lowerLast.Substring(0, lowerLast.Length - 5) + "sechst" + ending;
        if (lowerLast.EndsWith("sieben")) return lowerLast.Substring(0, lowerLast.Length - 6) + "siebt" + ending;
        if (lowerLast.EndsWith("acht")) return lowerLast.Substring(0, lowerLast.Length - 4) + "acht" + ending;
        if (lowerLast.EndsWith("neun")) return lowerLast.Substring(0, lowerLast.Length - 4) + "neunt" + ending;
        if (lowerLast.EndsWith("zehn")) return lowerLast.Substring(0, lowerLast.Length - 4) + "zehnt" + ending;
        if (lowerLast.EndsWith("elf")) return lowerLast.Substring(0, lowerLast.Length - 3) + "elft" + ending;
        if (lowerLast.EndsWith("zwölf")) return lowerLast.Substring(0, lowerLast.Length - 5) + "zwölft" + ending;
        if (lowerLast.EndsWith("hundert")) return lowerLast.Substring(0, lowerLast.Length - 7) + "hundertst" + ending;
        if (lowerLast.EndsWith("tausend")) return lowerLast.Substring(0, lowerLast.Length - 7) + "tausendst" + ending;
        if (lowerLast.EndsWith("ig")) return lowerLast.Substring(0, lowerLast.Length - 2) + "igst" + ending;
        return lowerLast + "t" + ending;
    }

    private static string ItalianToOrdinal(BigInteger value, string? suffix, string originalResult)
    {
        if (value > long.MaxValue || value < 0)
            return originalResult + (suffix ?? "th");
        long v = (long)value;
        bool feminine = suffix is not null &&
            (suffix == "-a" || suffix.IndexOf("feminine", StringComparison.OrdinalIgnoreCase) >= 0);
        string ordinal = v switch
        {
            1 => feminine ? "prima" : "primo",
            2 => feminine ? "seconda" : "secondo",
            3 => feminine ? "terza" : "terzo",
            4 => feminine ? "quarta" : "quarto",
            5 => feminine ? "quinta" : "quinto",
            6 => feminine ? "sesta" : "sesto",
            7 => feminine ? "settima" : "settimo",
            8 => feminine ? "ottava" : "ottavo",
            9 => feminine ? "nona" : "nono",
            10 => feminine ? "decima" : "decimo",
            _ => originalResult.ToLowerInvariant() + (feminine ? "a" : "o")
        };
        return MatchCase(originalResult, ordinal);
    }

    private static string FrenchNumberToWords(long n)
    {
        if (n == 0) return "zéro";
        if (n < 0) return "moins " + FrenchNumberToWords(-n);
        if (n <= 19) return new[] { "un", "deux", "trois", "quatre", "cinq", "six", "sept", "huit", "neuf", "dix", "onze", "douze", "treize", "quatorze", "quinze", "seize", "dix-sept", "dix-huit", "dix-neuf" }[n - 1];
        if (n < 100)
        {
            var tens = new[] { "vingt", "trente", "quarante", "cinquante", "soixante", "soixante-dix", "quatre-vingts", "quatre-vingt-dix" };
            long t = n / 10;
            long u = n % 10;
            if (u == 0) return tens[t - 2];
            if (t == 7 || t == 9) // soixante-dix / quatre-vingt-dix use 1..19 for units
                return tens[t - 2] + "-" + FrenchNumberToWords((t == 7 ? 60 : 80) + u);
            if (t == 8 && u == 1) return "quatre-vingt-un";
            return tens[t - 2].TrimEnd('s') + "-" + FrenchNumberToWords(u);
        }
        if (n < 1000)
        {
            long h = n / 100;
            long r = n % 100;
            string hw = h == 1 ? "cent" : FrenchNumberToWords(h) + " cents";
            if (r == 0)
            {
                if (h == 1) return hw;
                return hw.TrimEnd('s');
            }
            return hw.TrimEnd('s') + " " + FrenchNumberToWords(r);
        }
        if (n < 1_000_000)
        {
            long t = n / 1000;
            long r = n % 1000;
            string tw = t == 1 ? "mille" : FrenchNumberToWords(t) + " mille";
            if (r == 0) return tw;
            return tw + " " + FrenchNumberToWords(r);
        }
        return n.ToString(CultureInfo.InvariantCulture);
    }

    private static string FrenchToOrdinalWords(string cardinalWord, long value, string? suffix)
    {
        if (value == 1)
            return MatchCase(cardinalWord, "premier");

        int lastSpace = cardinalWord.LastIndexOf(' ');
        int lastHyphen = cardinalWord.LastIndexOf('-');
        int splitAt = Math.Max(lastSpace, lastHyphen);

        string prefix;
        string originalLast;
        if (splitAt < 0)
        {
            prefix = "";
            originalLast = cardinalWord;
        }
        else
        {
            prefix = cardinalWord.Substring(0, splitAt + 1);
            originalLast = cardinalWord.Substring(splitAt + 1);
        }

        string last = originalLast.ToLowerInvariant();
        string ordinalLast = last switch
        {
            "un" => "unième",
            "cinq" => "cinquième",
            "neuf" => "neuvième",
            _ => last.TrimEnd('e') + "ième"
        };
        return prefix + MatchCase(originalLast, ordinalLast);
    }
}
