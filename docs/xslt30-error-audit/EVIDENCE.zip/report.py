"""Reconcile observed outcomes and all retained exclusions without gate admission."""
import collections,csv,hashlib,importlib.util,json,re,xml.etree.ElementTree as ET,zipfile
from pathlib import Path
packet=Path(__file__).resolve().parent
root=Path('D:/Development/Bosak/.worktrees/Bosak.XsltStaticErrors')
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
gate=module('gate',root/'tools/xslt30_gate.py')
reference=module('reference',root/'docs/xslt30-qualification/report.py')
plan=json.loads((packet/'PLAN.json').read_text());run=json.loads((packet/'RUN.json').read_text());audit_input=json.loads((packet/'AUDIT-INPUT.json').read_text())
assert not (packet/'REPORT.json').exists()
assert run['status']=='Completed' and run['completeCatalogCounts']
rows=reference.parse(plan,(packet/'stdout.log').read_text(encoding='utf-8-sig'),True)
assert len(rows)==579 and {(r['test_set'],r['test']) for r in rows}=={('error',n) for n in plan['sets'][0]['cases']}
source=(root/'tests/Bosak.Xslt.Conformance/Program.cs').read_text(encoding='utf-8')
body=source.split('HashSet<string> SkipFeatures',1)[1].split('{',1)[1].split('}',1)[0]
unsupported={s.casefold() for s in re.findall(r'"([^"\n]+)"','\n'.join(line.split('//',1)[0] for line in body.splitlines()))}
notes=reference.named_skip_notes(source)
item=plan['sets'][0];definition=packet/'corpus'/item['file']
assert gate.digest(definition)==item['sha256']
cases={c.get('name'):c for c in ET.parse(definition).getroot().findall('t:test-case',reference.NS)}
original={r['test']:r for r in csv.DictReader((packet/'ORIGINAL-GATE-EXCLUSIONS.csv').open(encoding='utf-8',newline=''))}
for row in rows:
 row['recorded_reason']=row['reason']
 if row['status']=='Skipped' and row['reason_source']=='DerivedFromControlFlow':
  row['reason']=reference.explain_silent(cases[row['test']],unsupported,row['catalog_file'])
  row['reason_source']='DerivedFromPinnedPolicyAndCatalog'
 elif row['status']=='Skipped' and row['reason']=='Known harness skip':
  assert notes.get(row['test'])
  row['reason']='Retained named skip; historical policy note (not revalidated): '+notes[row['test']]
  row['reason_source']='DerivedFromPinnedNamedSkipComment'
 elif row['status']=='Skipped' and row['test']=='error-1160a':
  row['reason']='Retained remote-resource skip; printed historical condition was not re-probed: '+row['reason']
 row['expected_error_codes']=' '.join(e.get('code','') for e in cases[row['test']].findall('.//t:result//t:error',reference.NS))
 row['original_gate_status']='Skipped'
 row['original_gate_reason']=original[row['test']]['reason']
fields=['test_set','test','status','reason','recorded_reason','reason_source','evidence_line','catalog_file','expected_error_codes','original_gate_status','original_gate_reason']
for filename,subset in [('outcomes.csv',rows),('skips.csv',[r for r in rows if r['status']=='Skipped']),('failures.csv',[r for r in rows if r['status']=='Failed'])]:
 with (packet/filename).open('w',encoding='utf-8',newline='') as stream:
  writer=csv.DictWriter(stream,fieldnames=fields,lineterminator='\n');writer.writeheader();writer.writerows(subset)
before=json.loads((packet/'CORPUS-BEFORE.json').read_text());after=gate.inventory(packet/'corpus')
gate.write_json(packet/'CORPUS-AFTER.json',after)
changes=dict(added=sorted(after.keys()-before.keys()),removed=sorted(before.keys()-after.keys()),changed=sorted(n for n in before.keys()&after.keys() if before[n]!=after[n]))
with zipfile.ZipFile(packet/'GENERATED-OUTPUTS.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
 for name in changes['added']+changes['changed']:archive.write(packet/'corpus'/name,name)
counts={k:sum(r['status']==k for r in rows) for k in ['Passed','Failed','Skipped']}
assert counts=={k:run['counts'][k] for k in counts}
audit=dict(corpusDifferences=changes,sourceCorpusUnchanged=gate.inventory(Path(audit_input['sourceCorpus']))==before,
 runtimeUnchanged=gate.runtime_hashes(packet/'runtime')==json.loads((packet/'RUNTIME-HASHES.json').read_text()),
 gatePolicyUnchanged=gate.digest(root/'docs/xslt30-gate/BASELINE.json')==audit_input['gatePolicyFileSha256'])
assert not any(changes.values()) and all(audit[k] for k in ['sourceCorpusUnchanged','runtimeUnchanged','gatePolicyUnchanged'])
gate.write_json(packet/'AUDIT.json',audit)
raw=(root/'docs/xslt30-qualification/run.py').read_bytes();normalized=raw.decode('utf-8').replace('\r\n','\n')
assert hashlib.sha256(normalized.encode()).hexdigest()==audit_input['controllerSourceSha256']
gate.write_json(packet/'CONTROLLER-SOURCE.json',dict(sourceCommit=plan['sourceCommit'],path='docs/xslt30-qualification/run.py',rawSha256=hashlib.sha256(raw).hexdigest(),
 normalizedLfSha256=audit_input['controllerSourceSha256'],adaptation='Only append the unique error set filter to the unchanged qualified controller argument list'))
(packet/'QUALIFIED-CONTROLLER.py').write_bytes(raw)
gate.write_json(packet/'PREPARATION-NOTE.json',dict(earlyStartAttempt='Python refused because run-selected.py did not yet exist while corpus preparation was still copying; no .NET process or test ran',
 preparationCompletedBeforeActualRun=True,actualAttempt='RUN.json'))
result=dict(sourceCommit=plan['sourceCommit'],corpusCommit=plan['corpusCommit'],selectedSet='error',totalCases=579,counts=counts,
 completeIdentityReconciliation=True,measurementComplete=True,elapsedSeconds=run['elapsedSeconds'],integrity=audit,
 skipReasonGroups=[dict(reason=reason,count=count) for reason,count in collections.Counter(r['reason'] for r in rows if r['status']=='Skipped').most_common()],
 adoptedGateCounts=audit_input['adoptedGatePolicy']['counts'],adoptedGateUnchanged=True,
 scope='Existing Legacy assertions accepted 513 cases; no independent compile-time/error-stage proof, skip admission, engine change or complete conformance claim')
gate.write_json(packet/'REPORT.json',result)
print(json.dumps(result,indent=2))
