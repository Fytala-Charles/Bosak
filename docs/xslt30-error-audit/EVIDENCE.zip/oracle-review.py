from pathlib import Path
import csv,hashlib,json,re
packet=Path(__file__).resolve().parent
root=Path('D:/Development/Bosak/.worktrees/Bosak.XsltStaticErrors')
path=root/'tests/Bosak.Xslt.Conformance/Program.cs'
raw=path.read_bytes();source=raw.decode('utf-8')
labels_body=source.split('private static readonly (string Expected, string MessageLabel)[] ErrorMessageLabels =',1)[1].split('};',1)[0]
alias_body=source.split('private static bool ErrorCodeAliasMatches',1)[1].split('static bool IsBackwardsCompatibleSpec',1)[0]
labels=re.findall(r'\("([A-Z]{4,5}\d{4})", "([^"\n]+)"\)',labels_body)
pairs=re.findall(r'\("([A-Z]{4,5}\d{4})", "([A-Z]{4,5}\d{4})"\)',alias_body)
assert len(labels)==7 and len(pairs)==22
possible={expected for expected,_ in labels+pairs}|{'XTSE0800','XTRE0270'}
rows=list(csv.DictReader((packet/'outcomes.csv').open(encoding='utf-8',newline='')))
candidates=[dict(test=r['test'],expectedErrorCodes=r['expected_error_codes']) for r in rows
 if r['status']=='Passed' and set(r['expected_error_codes'].split())&possible]
record=dict(sourceCommit='df16de7f39a556c6f9afea3eee9f61ef9bbc602e',sourcePath='tests/Bosak.Xslt.Conformance/Program.cs',sourceSha256=hashlib.sha256(raw).hexdigest(),
 messageLabelPairs=[dict(expected=a,messageLabel=b) for a,b in labels],codeAliasPairs=[dict(expected=a,acceptedActual=b) for a,b in pairs],
 otherLegacyAliases=[dict(expected='XTSE0800',acceptedActual='XTSE0085'),dict(expected='XTRE0270',acceptedActual='XTSE0270')],
 reviewCandidates=candidates,reviewCandidateCount=len(candidates),
 limitation='Candidates share expected codes with the alias tables; PASS lines do not identify the actual exception or matching branch. These are not confirmed alias-dependent passes. No per-case code fidelity or compile-time/error-stage proof is claimed.',
 recommendation='Keep the adopted gate unchanged. Next audit exact error identity and static/dynamic phase independently under the same catalog and engine profile; do not infer eligibility from the 513 legacy passes.')
(packet/'ORACLE-REVIEW.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
(packet/'RUNNER-SOURCE.cs').write_bytes(raw)
print('Recorded 22 code-alias pairs, 7 message-label pairs and',len(candidates),'possible review candidates; actual alias use remains unobserved.')
