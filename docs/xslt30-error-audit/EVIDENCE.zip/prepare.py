"""Seal a read-only targeted audit of the original 579-case error set."""
import csv,difflib,hashlib,importlib.util,json,shutil,subprocess,zipfile
from pathlib import Path
packet=Path(__file__).resolve().parent
root=Path('D:/Development/Bosak/.worktrees/Bosak.XsltStaticErrors')
source=Path('D:/Development/Bosak/.guard-tmp/xslt30-final-retry-20261112/corpus')
assert not (packet/'PLAN.json').exists() and not (packet/'RUN.json').exists()
spec=importlib.util.spec_from_file_location('gate',root/'tools/xslt30_gate.py')
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
policy,plan,inputs,skips=gate.baseline()
selected=[s for s in plan['sets'] if 'error' in s['name'].lower()]
assert len(selected)==1 and selected[0]['name']=='error' and len(selected[0]['cases'])==579
assert gate.inventory(source)==inputs
assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==policy['corpusCommit']
assert not subprocess.check_output(['git','-C',str(root),'status','--porcelain'],text=True).strip()
commit=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
with (packet/'BUILD.log').open('xb') as stream:
 result=subprocess.run(['dotnet','build','tests/Bosak.Xslt.Conformance','-c','Release'],cwd=root,stdout=stream,stderr=subprocess.STDOUT)
assert result.returncode==0
(packet/'DOTNET-INFO.txt').write_bytes(subprocess.check_output(['dotnet','--info'],cwd=root))
shutil.copytree(source,packet/'corpus')
shutil.copytree(root/'tests/Bosak.Xslt.Conformance/bin/Release/net10.0',packet/'runtime')
assert gate.inventory(packet/'corpus')==inputs
plan.update(sourceCommit=commit,sourceBaseCommit=commit,sourceIdentity='Clean committed current-main source; fresh Release runtime',
    sets=selected,totalCases=579,selection='Only original error set; unique substring filter error; no case filter, resume, retry or fixture edit',
    wallTimeoutSeconds=1200,memoryLimitBytes=8589934592,
    standardsPolicy='Observation only; immutable corpus and existing XSLT adoption retained; no new semantic interpretation or gate admission')
original=(root/'docs/xslt30-qualification/run.py').read_text(encoding='utf-8')
before="'--processor-profile', 'legacy', str(packet / 'corpus/catalog.xml')]"
after="'--processor-profile', 'legacy', str(packet / 'corpus/catalog.xml'), 'error']"
assert original.count(before)==1
controller=original.replace(before,after)
(packet/'run-selected.py').write_text(controller,encoding='utf-8')
(packet/'CONTROLLER-ADAPTATION.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),controller.splitlines(True),fromfile='qualified-run.py',tofile='run-selected.py')),encoding='utf-8')
for name,value in [('PLAN.json',plan),('CORPUS-BEFORE.json',inputs),('RUNTIME-HASHES.json',gate.runtime_hashes(packet/'runtime')),
 ('AUDIT-INPUT.json',dict(sourceCommit=commit,sourceCorpus=str(source),sourceCorpusInventory=inputs,adoptedGatePolicy=policy,
    gatePolicyFileSha256=gate.digest(root/'docs/xslt30-gate/BASELINE.json'),controllerSourceSha256=hashlib.sha256(original.encode()).hexdigest(),
    controllerAdaptationSha256=gate.digest(packet/'run-selected.py'),engineOrRunnerSourceChanges=False,
    caveat='Existing Legacy assertion acceptance; does not independently prove compile-time rejection, error-stage correctness or complete static validation'))]:
 gate.write_json(packet/name,value)
selected_skips=[row for row in skips if row['test_set']=='error']
assert len(selected_skips)==579 and {r['test'] for r in selected_skips}==set(selected[0]['cases'])
with (packet/'ORIGINAL-GATE-EXCLUSIONS.csv').open('w',encoding='utf-8',newline='') as stream:
 writer=csv.DictWriter(stream,fieldnames=list(selected_skips[0]),lineterminator='\n');writer.writeheader();writer.writerows(selected_skips)
print('Prepared exact 579-case audit at',commit,'with',len(gate.runtime_hashes(packet/'runtime')),'runtime inputs; gate unchanged.')
