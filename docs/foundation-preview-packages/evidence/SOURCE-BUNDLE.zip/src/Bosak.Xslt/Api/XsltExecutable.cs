// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 25 mei 2026
// PURPOSE              : An executable, thread-safe XSLT stylesheet that can transform source documents.
// SPECIAL NOTES        : Part of the Bosak XPath 3.1 implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 25-05-2026     | Creation                                                                                 |
//                      | Charles Korthout | 0.2   | 31-05-2026     | Added IXsltMessageListener pass-through to TransformEngine                              |
//                      | Charles Korthout | 0.3   | 08-06-2026     | Added initialMode parameter to Transform/TransformToString                             |
//                      | Charles Korthout | 0.4   | 24-06-2026     | Added TransformFunction/TransformFunctionToString for xsl:function entry points        |
//                      | Charles Korthout | 0.5   | 25-06-2026     | Added rawResult parameter to Transform for initial-template raw XDM output             |
//                      | Charles Korthout | 0.7   | 26-06-2026     | Added baseOutputUri parameter to Transform/TransformToString                            |
//                      | Charles Korthout | 0.6   | 26-06-2026     | Propagate TreatRecoverableAmbiguousMatchAsError to TransformEngine                      |
//                      | Charles Korthout | 0.8   | 06-07-2026     | Use xsl:result-document output properties in TransformToString                          |
//                      | Charles Korthout | 0.9   | 11-07-2026     | Read xsl:result-document output properties from fragment wrapper elements too.          |
//                      | Charles Korthout | 1.0   | 11-07-2026     | Resolve named character maps for principal and function output before serialization.    |
//                      | Charles Korthout | 1.1   | 11-07-2026     | Merge parameter-document character maps with named character-map resolutions.          |
//                      | Charles Korthout | 1.2   | 12-07-2026     | Use principal xsl:result-document output properties (including JSON) in TransformToString. |
//                      | Charles Korthout | 1.3   | 12-07-2026     | Resolve stylesheet-level character maps in OutputProperties; pre-resolved maps win.     |
//                      | Charles Korthout | 1.4   | 13-07-2026     | Stamp EffectiveVersion and ImplicitResultTree for default output-method inference.      |
//                      | Charles Korthout | 1.5   | 13-07-2026     | Raised transform stack to 16MB for deep continuation-style recursion (HOF-068).         |
//                      | Charles Korthout | 1.6    | 14-07-2026     | TransformCaptured: fn:transform entry point with result-document capture and formats.  |
//                      | Charles Korthout | 1.7   | 15-07-2026     | Added serialization-params merge and TransformFunctionCaptured for fn:transform.        |
//                      | Charles Korthout | 1.8   | 15-07-2026     | TransformCaptured/TransformFunctionCaptured accept explicit global context item           |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.9   | 28-08-2026     | Added optional serializationParams to TransformToString/TransformFunctionToString.        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.10  | 09-09-2026     | XML doc coverage on public API (Beta review)                                           |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.11  | 16-09-2026     | Added TransformStreaming (burst-mode streaming input via XmlStreamingProvider)         |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.12  | 16-09-2026     | Phase B: accumulators supported over streamed sources (guard removed); whitespace      |
//                      |                  |       |                | stripping is engine-owned for all streamed sources                                     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.13  | 21-09-2026     | Added TransformStreamingToString (streaming input with serialized string output)        |
//                      | Charles Korthout | 1.14  | 21-09-2026     | API freeze stage B: internalized                                                       |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.15  | 23-09-2026     | REQ-103: RunWithStack rethrows via ExceptionDispatchInfo (original stack preserved;   |
//                      |                  |       |                | `throw exception` reset it, hiding engine stacks from conformance diagnostics)        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.16  | 10-10-2026     | REQ-125 Slice C: CaptureTransform — IO-free captured output contract over the         |
//                      |                  |       |                | result-document capture machinery (identities, bytes, bounds, classified failures)    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.17  | 10-10-2026     | REQ-125 Slice D: CaptureTransform builds/stamps the ExecutionGate (token, TimeLimit,  |
//                      |                  |       |                | MaxEngineOperations), pre-run cancellation check, gate cleared in finally             |
//                      | Charles Korthout | 1.18  | 11-10-2026     | C-F1/D-F1: document bounded profiles and unconditional terminal observations.            |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.19  | 01-11-2026     | Add internal bounded explicit-context transform entry point. |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.20  | 01-11-2026     | Expose effective static values internally for bounded capture. |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.21 | 06-11-2026     | Run explicit source-role capture with local serialization diagnostics (1.76.0). |
// ===========================================================================================================================================================

using System.Xml.Linq;
using System.Threading;
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Providers.Streaming;
using Bosak.XPath.Providers.Xml;
using Bosak.XPath.Runtime;
using Bosak.XPath.Runtime.Vm;
using Bosak.Xslt.Capture;

namespace Bosak.Xslt.Api;

/// <summary>
/// Represents a compiled XSLT stylesheet ready for execution.
/// </summary>
public sealed class XsltExecutable
{
    private readonly Stylesheet.Stylesheet _stylesheet;
    private readonly IXsltMessageListener? _messageListener;
    private readonly bool _treatRecoverableAmbiguousMatchAsError;

    internal XsltExecutable(Stylesheet.Stylesheet stylesheet, IXsltMessageListener? messageListener = null, bool treatRecoverableAmbiguousMatchAsError = false)
    {
        _stylesheet = stylesheet;
        _messageListener = messageListener;
        _treatRecoverableAmbiguousMatchAsError = treatRecoverableAmbiguousMatchAsError;
    }

    /// <summary>
    /// Gets the effective stylesheet-level output properties, with named character maps
    /// resolved to a concrete character-to-string table.
    /// </summary>
    public Stylesheet.OutputProperties OutputProperties
    {
        get
        {
            var props = _stylesheet.EffectiveOutputProperties ?? new Stylesheet.OutputProperties();
            if (props.UseCharacterMaps.Count > 0 && props.CharacterMap == null)
            {
                props = props.Clone();
                props.CharacterMap = _stylesheet.ResolveCharacterMap(
                    props.UseCharacterMaps.Select(Stylesheet.Stylesheet.ExpandQName));
            }
            // If the runtime already resolved the maps inside a package scope, keep them.
            return props;
        }
    }

    /// <summary>
    /// Gets the output properties of the principal <c>xsl:result-document</c> produced
    /// during the last transformation, if any.
    /// </summary>
    internal Stylesheet.OutputProperties? LastResultDocumentProperties { get; private set; }

    /// <summary>Copies effective static values after the selected compilation profile has resolved them.</summary>
    internal IReadOnlyDictionary<(string LocalName, string NamespaceUri), XdmValue> CaptureSchemaStaticValues()
        => _stylesheet.StaticVariables;

    /// <summary>Returns the raw principal result with independent document-match and node-global inputs.</summary>
    /// <param name="matchInput">Document-root initial match input, or null for named-template work.</param>
    /// <param name="globalInput">Explicit global context node; null means absent without source fallback.</param>
    /// <param name="initialTemplate">Optional initial named template.</param>
    /// <param name="context">Borrowed dynamic context, subject to transform context mutation.</param>
    /// <returns>The raw principal result; secondary results are captured without external delivery.</returns>
    /// <exception cref="NotSupportedException">The match input is not a document node.</exception>
    internal XdmValue TransformWithExplicitContext(IXdmNode? matchInput, IXdmNode? globalInput, string? initialTemplate, EvaluationContext? context)
    {
        if (matchInput != null && matchInput.NodeKind != XdmNodeKind.Document)
            throw new NotSupportedException("Explicit-context transforms admit only document-root initial match inputs.");
        return RunWithStack(() => new Runtime.TransformEngine(_stylesheet, context, _messageListener, _treatRecoverableAmbiguousMatchAsError)
            .TransformCore(matchInput, initialTemplate, null, true, null, null, true, true, globalInput, false), DefaultTransformStackSize);
    }


    internal XdmValue TransformCapturedContext(IXdmNode? match,IXdmNode? global,string? template,string? mode,
        bool raw,string? outputUri,EvaluationContext context)
        =>RunWithStack(()=>new Runtime.TransformEngine(_stylesheet,context,null,_treatRecoverableAmbiguousMatchAsError)
            .TransformCore(match,template,mode,raw,outputUri,null,true,false,global,false),DefaultTransformStackSize);

    internal XsltCaptureResult CaptureExplicitContext(IXdmNode? match,IXdmNode? global,XsltCaptureOptions options,
        EvaluationContext context,Action<Exception> observeError,Action<long>? observeProduction=null)
    {
        var session=new XsltCaptureSession(options,null,context.ExecutionGate,observeProduction,observeError);
        Exception? failure=null;
        try
        {
            context.ExecutionGate?.Checkpoint();
            RunWithStack<object?>(()=>
            {
                var engine=new Runtime.TransformEngine(_stylesheet,context,session.MessageListener,_treatRecoverableAmbiguousMatchAsError);
                engine.ResultDocumentCaptureObserver=session.ObserveResultDocument;
                var result=engine.TransformCore(match,options.InitialTemplate,options.InitialMode,false,options.BaseOutputUri,null,true,false,global,false);
                var props=(engine.PrincipalResultDocumentProperties??OutputProperties).Clone();
                props.EffectiveVersion??=_stylesheet.Version;
                props.ImplicitResultTree=engine.PrincipalResultDocumentProperties is null;
                session.CapturePrincipal(result,props);
                return null;
            },DefaultTransformStackSize);
        }
        catch(Exception error){failure=error;}
        return session.BuildResult(failure);
    }

    /// <summary>
    /// Default stack size (bytes) allocated for the transformation thread.  A larger
    /// stack is required for stylesheets that rely on deep xsl:call-template recursion
    /// (for example the DocBook XSLT 1.0 stylesheets).
    /// </summary>
    private const int DefaultTransformStackSize = 16 * 1024 * 1024;

    /// <summary>
    /// Transforms the supplied source document using this stylesheet.
    /// </summary>
    /// <param name="source">The source document or node to transform. May be null for named-template entry points with no initial context item.</param>
    /// <param name="context">Optional evaluation context (variables, parameters, etc.).</param>
    /// <param name="initialTemplate">Optional name of the initial template to execute.</param>
    /// <param name="initialMode">Optional name of the initial mode to use.</param>
    /// <param name="rawResult">When true and an initial template is used, returns the raw template result instead of wrapping it in a result document.</param>
    /// <param name="baseOutputUri">The base output URI for the transformation; used by fn:current-output-uri().</param>
    /// <returns>The result of the transformation as an XDM value.</returns>
    public XdmValue Transform(IXdmNode? source, EvaluationContext? context = null, string? initialTemplate = null, string? initialMode = null, bool rawResult = false, string? baseOutputUri = null)
    {
        return RunWithStack(() =>
        {
            var engine = new Runtime.TransformEngine(_stylesheet, context, _messageListener, _treatRecoverableAmbiguousMatchAsError);
            var result = engine.Transform(source, initialTemplate, initialMode, rawResult, baseOutputUri);
            LastResultDocumentProperties = engine.PrincipalResultDocumentProperties;
            return result;
        }, DefaultTransformStackSize);
    }

    /// <summary>
    /// Transforms a streamed source document using this stylesheet (burst-mode streaming
    /// input). The source is pulled from <paramref name="source"/> lazily: the root's
    /// top-level elements (records) are materialized one at a time as the stylesheet
    /// consumes them, so record-at-a-time processing (<c>xsl:for-each</c> or
    /// <c>xsl:apply-templates</c> over the root's children with record-local bodies) runs
    /// in bounded memory. The streamed children of the root are forward-only: they can be
    /// read once, in one pass. Operations that inherently need the whole input
    /// (<c>xsl:sort</c>, grouping, <c>fn:last()</c>) either buffer it or raise an error.
    /// <c>xsl:strip-space</c>/<c>xsl:preserve-space</c> rules and <c>xsl:accumulator</c>
    /// declarations are honored per record as it is materialized.
    /// </summary>
    /// <param name="source">The stream containing the source XML document.</param>
    /// <param name="options">Optional streaming options (base URI, reader settings).</param>
    /// <param name="context">Optional evaluation context (variables, parameters, etc.).</param>
    /// <param name="initialTemplate">Optional name of the initial template to execute.</param>
    /// <param name="initialMode">Optional name of the initial mode to use.</param>
    /// <param name="baseOutputUri">The base output URI for the transformation; used by fn:current-output-uri().</param>
    /// <returns>The result of the transformation as an XDM value.</returns>
    public XdmValue TransformStreaming(System.IO.Stream source, StreamingTransformOptions? options = null, EvaluationContext? context = null, string? initialTemplate = null, string? initialMode = null, string? baseOutputUri = null)
    {
        options ??= new StreamingTransformOptions();
        var loadOptions = new StreamingLoadOptions
        {
            BaseUri = options.BaseUri,
            DocumentUri = options.BaseUri,
            ReaderSettings = options.ReaderSettings,
        };

        var sourceNode = XmlStreamingProvider.Load(source, loadOptions);
        return Transform(sourceNode, context, initialTemplate, initialMode, baseOutputUri: baseOutputUri);
    }

    /// <summary>
    /// Transforms a streamed source document using this stylesheet (burst-mode streaming
    /// input) and serializes the result to a string. The source is pulled from
    /// <paramref name="source"/> lazily: the root's top-level elements (records) are
    /// materialized one at a time as the stylesheet consumes them, so record-at-a-time
    /// processing runs in bounded memory (see <see cref="TransformStreaming"/> for the
    /// full streaming contract). Output properties (including a principal
    /// <c>xsl:result-document</c> and named character maps) are applied exactly as for
    /// <see cref="TransformToString(IXdmNode?, EvaluationContext?, string?, string?, string?, Stylesheet.OutputProperties?)"/>.
    /// </summary>
    /// <param name="source">The stream containing the source XML document.</param>
    /// <param name="options">Optional streaming options (base URI, reader settings).</param>
    /// <param name="context">Optional evaluation context (variables, parameters, etc.).</param>
    /// <param name="initialTemplate">Optional name of the initial template to execute.</param>
    /// <param name="initialMode">Optional name of the initial mode to use.</param>
    /// <param name="baseOutputUri">The base output URI for the transformation; used by fn:current-output-uri().</param>
    /// <returns>The serialized result of the transformation.</returns>
    public string TransformStreamingToString(System.IO.Stream source, StreamingTransformOptions? options = null, EvaluationContext? context = null, string? initialTemplate = null, string? initialMode = null, string? baseOutputUri = null)
    {
        options ??= new StreamingTransformOptions();
        var loadOptions = new StreamingLoadOptions
        {
            BaseUri = options.BaseUri,
            DocumentUri = options.BaseUri,
            ReaderSettings = options.ReaderSettings,
        };

        var sourceNode = XmlStreamingProvider.Load(source, loadOptions);
        return TransformToString(sourceNode, context, initialTemplate, initialMode, baseOutputUri);
    }

    /// <summary>
    /// Runs a transformation with an explicit initial match selection, which is applied
    /// to the initial mode when no source node is supplied.
    /// </summary>
    /// <param name="source">The source document or node to transform. May be null when an initial match selection is supplied.</param>
    /// <param name="initialMatchSelection">The initial match selection applied to the initial mode (fn:transform).</param>
    /// <param name="context">Optional evaluation context (variables, parameters, etc.).</param>
    /// <param name="initialTemplate">Optional name of the initial template to execute.</param>
    /// <param name="initialMode">Optional name of the initial mode to use.</param>
    /// <param name="rawResult">When true and an initial template is used, returns the raw template result instead of wrapping it in a result document.</param>
    /// <param name="baseOutputUri">The base output URI for the transformation; used by fn:current-output-uri().</param>
    /// <returns>The result of the transformation as an XDM value.</returns>
    public XdmValue Transform(IXdmNode? source, XdmValue? initialMatchSelection, EvaluationContext? context = null, string? initialTemplate = null, string? initialMode = null, bool rawResult = false, string? baseOutputUri = null)
    {
        return RunWithStack(() =>
        {
            var engine = new Runtime.TransformEngine(_stylesheet, context, _messageListener, _treatRecoverableAmbiguousMatchAsError);
            var result = engine.Transform(source, initialTemplate, initialMode, rawResult, baseOutputUri, initialMatchSelection: initialMatchSelection);
            LastResultDocumentProperties = engine.PrincipalResultDocumentProperties;
            return result;
        }, DefaultTransformStackSize);
    }

    /// <summary>
    /// Runs a transformation with output capture (REQ-125 Slice C): the principal output and every
    /// secondary <c>xsl:result-document</c> output are serialized to bytes in memory — with their
    /// resolved identities and effective output properties — and returned as a classified, immutable
    /// result. No output definition is written to the file system or the network.
    /// </summary>
    /// <param name="source">The source document or node to transform. May be null for named-template entry points with no initial context item.</param>
    /// <param name="options">Optional capture controls (base output URI, entry point, bounds, cancellation and execution limits). <see langword="null"/> captures every output with no bounds.</param>
    /// <returns>
    /// The immutable capture result; never <see langword="null"/>. Expected error conditions —
    /// engine/spec errors raised by the stylesheet, duplicate output URIs (XTDE1490), configured
    /// bound breaches, message overflow, cancellation and execution-limit exhaustion — are classified
    /// on the result (see <see cref="XsltCaptureResult.Outcome"/> and
    /// <see cref="XsltCaptureResult.Failures"/>), never thrown.
    /// </returns>
    /// <remarks>
    /// <para>
    /// Identity: the principal output's resolved identity is the base output URI (from
    /// <see cref="XsltCaptureOptions.BaseOutputUri"/>), even when the stylesheet never names it; when
    /// no base output URI is supplied the identity is the empty string. Secondary identities are the
    /// <c>xsl:result-document</c> hrefs resolved against that base.
    /// </para>
    /// <para>
    /// Byte fidelity: each output's bytes are produced by the engine's serializer under its effective
    /// output properties (method, encoding, byte-order mark and all other overrides, including
    /// <c>xsl:result-document</c> attributes and named output definitions), matching the
    /// <c>fn:transform</c> serialized-delivery contract. Bounds are enforced during production: a
    /// secondary output is serialized as soon as its instruction completes, and the transformation is
    /// terminated at the first output that breaches a configured bound; outputs completed earlier are
    /// retained and the breach is a classified failure.
    /// </para>
    /// <para>
    /// Cancellation and limits (REQ-125 Slice D): the run and its nested <c>fn:transform</c> calls
    /// share one execution gate built from <see cref="XsltCaptureOptions.CancellationToken"/>,
    /// <see cref="XsltCaptureOptions.TimeLimit"/> and
    /// <see cref="XsltCaptureOptions.MaxEngineOperations"/>. Checkpoints fire at every XSLT
    /// instruction dispatch, template invocation, secondary result-document production,
    /// <c>xsl:message</c> emission and output serialization. Cancellation classifies as
    /// <see cref="XsltCaptureOutcome.Cancelled"/>; the two limits classify as <c>XV0011</c>/<c>XV0012</c>
    /// failures on a partial/failed outcome. Cancellation/deadlines are observed unconditionally
    /// before and after serialization and before result publication; bounded serialization also
    /// observes controls between encoding chunks. These observations do not consume engine
    /// operations or alter the 64-checkpoint hot-loop batch. The gate is stamped on the run's evaluation context for
    /// the duration of the run and cleared afterwards, and nested transforms inherit the same gate
    /// instance — so the remaining budget and deadline are shared across nesting, and sequential or
    /// concurrent runs never observe another run's controls (a gate is only ever used from its own
    /// transformation thread). A stylesheet <c>xsl:try</c>/<c>xsl:catch</c> can swallow the internal
    /// termination signal; the recorded cancellation/limit failure still downgrades the outcome.
    /// </para>
    /// <para>
    /// Coverage and exclusions: capture covers the principal output and all secondary outputs,
    /// including raw outputs when byte limits are absent. With byte limits, JSON/adaptive,
    /// text Unicode normalization, non-text character maps and non-XDocument markup provider
    /// fallbacks are refused as UnsupportedSerializationProfile/XV0014 before serialization.
    /// Text (including character maps) and supported XML/HTML/XHTML profiles use incremental
    /// encoding sinks; encoding/BOM bytes count against both budgets. The sink retains no more
    /// than the permitted output bytes, with fixed-size encoding/markup lookahead. Result-tree
    /// construction, normalization and XPath working memory are separate from serialization
    /// budgets; capture is not an OS memory sandbox. There is no initial-match-selection or raw-result delivery variant on this entry
    /// point; <c>xsl:message</c> texts travel the separate bounded channel
    /// <see cref="XsltCaptureResult.Messages"/>. A single XPath expression between checkpoints (for
    /// example a long loop inside one <c>select</c> attribute) is not interrupted mid-evaluation;
    /// the wall-clock and operation limits are cooperative, deterministic bounds — Braid's process
    /// termination remains the hard wall-clock control. When this method is not used, the existing
    /// <c>Transform</c>/<c>TransformToString</c> family is unchanged — including its current disk
    /// behavior for secondary result documents.
    /// </para>
    /// </remarks>
    public XsltCaptureResult CaptureTransform(IXdmNode? source, XsltCaptureOptions? options = null)
    {
        options ??= new XsltCaptureOptions();
        var context = options.Context ?? new EvaluationContext();

        // REQ-125 Slice D: one execution gate per controlled run. A gate already on the context
        // (a nested controlled run) is inherited — its remaining budget and deadline are shared —
        // and the options' controls apply only when no gate is present yet.
        var gate = context.ExecutionGate;
        var stamped = false;
        if (gate is null &&
            (options.CancellationToken.HasValue || options.TimeLimit.HasValue || options.MaxEngineOperations.HasValue))
        {
            gate = ExecutionGate.Create(
                options.CancellationToken ?? default,
                options.TimeLimit,
                options.MaxEngineOperations);
            context.ExecutionGate = gate;
            stamped = true;
        }

        var session = new XsltCaptureSession(options, _messageListener, gate);
        Exception? failure = null;
        try
        {
            // A token triggered before the run starts cancels immediately, before any output is
            // produced and before the transformation thread starts.
            gate?.Checkpoint();

            RunWithStack<object?>(() =>
            {
                var engine = new Runtime.TransformEngine(_stylesheet, context, session.MessageListener, _treatRecoverableAmbiguousMatchAsError);
                engine.ResultDocumentCaptureObserver = session.ObserveResultDocument;
                var result = engine.Transform(source, options.InitialTemplate, options.InitialMode,
                    rawResult: false, baseOutputUri: options.BaseOutputUri, captureResultDocuments: true);
                LastResultDocumentProperties = engine.PrincipalResultDocumentProperties;

                // A principal xsl:result-document (no href) supplies the effective output properties,
                // overriding the stylesheet-level xsl:output defaults. Clone before stamping
                // run-specific inference state so concurrent captures never share mutable state.
                var principalProps = (engine.PrincipalResultDocumentProperties ?? OutputProperties).Clone();
                principalProps.EffectiveVersion ??= _stylesheet.Version;
                principalProps.ImplicitResultTree = engine.PrincipalResultDocumentProperties == null;
                session.CapturePrincipal(result, principalProps);
                return null;
            }, DefaultTransformStackSize);
        }
        catch (Exception ex)
        {
            failure = ex;
        }
        finally
        {
            if (stamped)
                context.ExecutionGate = null;
        }

        return session.BuildResult(failure);
    }

    /// <summary>
    /// Runs a transformation on behalf of <c>fn:transform</c>: secondary result
    /// documents are captured rather than written to disk, and both the principal
    /// and the secondary results are post-processed according to the requested
    /// delivery format (document, raw, or serialized).
    /// </summary>
    /// <param name="source">The source node, or null when no source-node is supplied.</param>
    /// <param name="initialMatchSelection">Optional initial match selection applied in the initial mode.</param>
    /// <param name="context">Optional evaluation context (stylesheet parameters).</param>
    /// <param name="initialTemplate">Optional initial named template (lexical or Clark form).</param>
    /// <param name="initialMode">Optional initial mode.</param>
    /// <param name="deliveryFormat">One of <c>document</c>, <c>raw</c>, or <c>serialized</c>.</param>
    /// <param name="baseOutputUri">Optional base output URI for resolving result-document hrefs.</param>
    /// <param name="secondaryResults">The captured secondary result documents, keyed by resolved URI.</param>
    /// <returns>The principal result in the requested delivery format.</returns>
    internal XdmValue TransformCaptured(
        IXdmNode? source,
        XdmValue? initialMatchSelection,
        EvaluationContext? context,
        string? initialTemplate,
        string? initialMode,
        string deliveryFormat,
        string? baseOutputUri,
        out IReadOnlyDictionary<string, XdmValue> secondaryResults)
    {
        return TransformCaptured(source, initialMatchSelection, context, initialTemplate, initialMode,
            deliveryFormat, baseOutputUri, serializationParams: null, out secondaryResults);
    }

    /// <summary>
    /// Runs a transformation on behalf of <c>fn:transform</c>, merging the supplied
    /// serialization parameters into the effective output properties.
    /// </summary>
    /// <param name="source">The source node, or null when no source-node is supplied.</param>
    /// <param name="initialMatchSelection">Optional initial match selection applied in the initial mode.</param>
    /// <param name="context">Optional evaluation context (stylesheet parameters).</param>
    /// <param name="initialTemplate">Optional initial named template (lexical or Clark form).</param>
    /// <param name="initialMode">Optional initial mode.</param>
    /// <param name="deliveryFormat">One of <c>document</c>, <c>raw</c>, or <c>serialized</c>.</param>
    /// <param name="baseOutputUri">Optional base output URI for resolving result-document hrefs.</param>
    /// <param name="serializationParams">Optional user-supplied serialization parameters.</param>
    /// <param name="secondaryResults">The captured secondary result documents, keyed by resolved URI.</param>
    /// <returns>The principal result in the requested delivery format.</returns>
    internal XdmValue TransformCaptured(
        IXdmNode? source,
        XdmValue? initialMatchSelection,
        EvaluationContext? context,
        string? initialTemplate,
        string? initialMode,
        string deliveryFormat,
        string? baseOutputUri,
        Stylesheet.OutputProperties? serializationParams,
        out IReadOnlyDictionary<string, XdmValue> secondaryResults)
        => TransformCaptured(source, initialMatchSelection, context, initialTemplate, initialMode,
            deliveryFormat, baseOutputUri, serializationParams, globalContextItem: null, out secondaryResults);

    /// <summary>
    /// Runs a transformation on behalf of <c>fn:transform</c> with an explicit global
    /// context item: secondary result documents are captured rather than written to disk,
    /// and the principal result is post-processed according to the requested delivery format.
    /// </summary>
    /// <param name="source">The source node, or null when no source-node is supplied.</param>
    /// <param name="initialMatchSelection">Optional initial match selection applied in the initial mode.</param>
    /// <param name="context">Optional evaluation context (stylesheet parameters).</param>
    /// <param name="initialTemplate">Optional initial named template (lexical or Clark form).</param>
    /// <param name="initialMode">Optional initial mode.</param>
    /// <param name="deliveryFormat">One of <c>document</c>, <c>raw</c>, or <c>serialized</c>.</param>
    /// <param name="baseOutputUri">Optional base output URI for resolving result-document hrefs.</param>
    /// <param name="serializationParams">Optional user-supplied serialization parameters.</param>
    /// <param name="globalContextItem">Optional explicit global context item for the transformation.</param>
    /// <param name="secondaryResults">The captured secondary result documents, keyed by resolved URI.</param>
    /// <returns>The principal result in the requested delivery format.</returns>
    internal XdmValue TransformCaptured(
        IXdmNode? source,
        XdmValue? initialMatchSelection,
        EvaluationContext? context,
        string? initialTemplate,
        string? initialMode,
        string deliveryFormat,
        string? baseOutputUri,
        Stylesheet.OutputProperties? serializationParams,
        IXdmNode? globalContextItem,
        out IReadOnlyDictionary<string, XdmValue> secondaryResults)
    {
        IReadOnlyDictionary<string, XdmValue> capturedResults = new Dictionary<string, XdmValue>();
        var principalResult = RunWithStack(() =>
        {
            bool raw = deliveryFormat == "raw";
            bool serialized = deliveryFormat == "serialized";
            var engine = new Runtime.TransformEngine(_stylesheet, context, _messageListener, _treatRecoverableAmbiguousMatchAsError);
            var result = engine.Transform(source, initialTemplate, initialMode,
                rawResult: raw, baseOutputUri: baseOutputUri,
                initialMatchSelection: initialMatchSelection,
                captureResultDocuments: true, rawTransformResult: raw,
                globalContextItem: globalContextItem);
            LastResultDocumentProperties = engine.PrincipalResultDocumentProperties;

            var captured = new Dictionary<string, XdmValue>();
            foreach (var (uri, entry) in engine.CapturedResultDocuments)
            {
                var props = entry.Props;
                if (serialized && serializationParams != null)
                {
                    props = props.Clone();
                    Stylesheet.OutputProperties.Merge(props, serializationParams);
                }
                captured[uri] = serialized
                    ? XdmValue.FromString(Runtime.ResultTreeSerializer.Serialize(entry.Value, props))
                    : entry.Value;
            }
            capturedResults = captured;

            if (serialized)
            {
                var outputProperties = engine.PrincipalResultDocumentProperties
                    ?? OutputProperties;
                outputProperties.EffectiveVersion ??= _stylesheet.Version;
                outputProperties.ImplicitResultTree = engine.PrincipalResultDocumentProperties == null;
                if (serializationParams != null)
                {
                    outputProperties = outputProperties.Clone();
                    Stylesheet.OutputProperties.Merge(outputProperties, serializationParams);
                }
                return XdmValue.FromString(Runtime.ResultTreeSerializer.Serialize(result, outputProperties));
            }

            return result;
        }, DefaultTransformStackSize);
        secondaryResults = capturedResults;
        return principalResult;
    }

    /// <summary>
    /// Transforms the supplied source document and serializes the result to a string.
    /// </summary>
    /// <param name="source">The source document or node to transform. May be null for named-template entry points with no initial context item.</param>
    /// <param name="context">Optional evaluation context.</param>
    /// <param name="initialTemplate">Optional name of the initial template to execute.</param>
    /// <param name="initialMode">Optional name of the initial mode to use.</param>
    /// <param name="baseOutputUri">The base output URI for the transformation; used by fn:current-output-uri().</param>
    /// <param name="serializationParams">Optional serialization parameters merged with the effective output properties.</param>
    /// <returns>The serialized result of the transformation.</returns>
    public string TransformToString(IXdmNode? source, EvaluationContext? context = null, string? initialTemplate = null, string? initialMode = null, string? baseOutputUri = null, Stylesheet.OutputProperties? serializationParams = null)
    {
        return RunWithStack(() =>
        {
            var engine = new Runtime.TransformEngine(_stylesheet, context, _messageListener, _treatRecoverableAmbiguousMatchAsError);
            var result = engine.Transform(source, initialTemplate, initialMode, false, baseOutputUri);
            LastResultDocumentProperties = engine.PrincipalResultDocumentProperties;

            // A principal xsl:result-document (no href) supplies the effective output
            // properties, overriding the stylesheet-level xsl:output defaults.
            var outputProperties = engine.PrincipalResultDocumentProperties
                ?? _stylesheet.EffectiveOutputProperties
                ?? new Stylesheet.OutputProperties();

            // Fall back to annotation-based output properties for backward compatibility
            // when the result tree is a wrapper element produced by the legacy path.
            bool implicitResultTree = engine.PrincipalResultDocumentProperties == null;
            if (engine.PrincipalResultDocumentProperties == null && result.IsNode && result.NodeValue is XDocumentNode xdn)
            {
                Stylesheet.OutputProperties? rdProps = null;
                if (xdn.UnderlyingObject is XDocument doc)
                    rdProps = doc.Annotation<Stylesheet.OutputProperties>();
                else if (xdn.UnderlyingObject is XElement elem)
                    rdProps = elem.Annotation<Stylesheet.OutputProperties>();
                if (rdProps != null)
                {
                    outputProperties = rdProps;
                    implicitResultTree = false;
                }
            }

            // Default output-method inference needs the effective stylesheet version
            // and whether the result tree was generated implicitly (XSLT 3.0 §26).
            outputProperties.EffectiveVersion = _stylesheet.Version;
            outputProperties.ImplicitResultTree = implicitResultTree;

            // Resolve named character maps for the principal output if not already done.
            if (outputProperties.UseCharacterMaps.Count > 0 && outputProperties.CharacterMap == null)
            {
                outputProperties = outputProperties.Clone();
                outputProperties.CharacterMap = _stylesheet.ResolveCharacterMap(
                    outputProperties.UseCharacterMaps.Select(Stylesheet.Stylesheet.ExpandQName));
            }

            if (serializationParams != null)
            {
                outputProperties = outputProperties.Clone();
                Stylesheet.OutputProperties.Merge(outputProperties, serializationParams);
            }

            return Runtime.ResultTreeSerializer.Serialize(result, outputProperties);
        }, DefaultTransformStackSize);
    }

    /// <summary>
    /// Transforms the supplied source document (or initial match selection) and serializes
    /// the result to a string.
    /// </summary>
    /// <param name="source">The source document or node to transform. May be null when an initial match selection is supplied.</param>
    /// <param name="initialMatchSelection">The initial match selection applied to the initial mode (fn:transform).</param>
    /// <param name="context">Optional evaluation context.</param>
    /// <param name="initialTemplate">Optional name of the initial template to execute.</param>
    /// <param name="initialMode">Optional name of the initial mode to use.</param>
    /// <param name="baseOutputUri">The base output URI for the transformation; used by fn:current-output-uri().</param>
    /// <param name="serializationParams">Optional serialization parameters merged with the effective output properties.</param>
    /// <returns>The serialized result of the transformation.</returns>
    public string TransformToString(IXdmNode? source, XdmValue? initialMatchSelection, EvaluationContext? context = null, string? initialTemplate = null, string? initialMode = null, string? baseOutputUri = null, Stylesheet.OutputProperties? serializationParams = null)
    {
        return RunWithStack(() =>
        {
            var engine = new Runtime.TransformEngine(_stylesheet, context, _messageListener, _treatRecoverableAmbiguousMatchAsError);
            var result = engine.Transform(source, initialTemplate, initialMode, false, baseOutputUri, initialMatchSelection: initialMatchSelection);
            LastResultDocumentProperties = engine.PrincipalResultDocumentProperties;

            var outputProperties = engine.PrincipalResultDocumentProperties
                ?? _stylesheet.EffectiveOutputProperties
                ?? new Stylesheet.OutputProperties();
            outputProperties.EffectiveVersion = _stylesheet.Version;

            if (serializationParams != null)
            {
                outputProperties = outputProperties.Clone();
                Stylesheet.OutputProperties.Merge(outputProperties, serializationParams);
            }

            return Runtime.ResultTreeSerializer.Serialize(result, outputProperties);
        }, DefaultTransformStackSize);
    }

    /// <summary>
    /// Invokes an <c>xsl:function</c> as the transformation entry point and returns its raw XDM value.
    /// </summary>
    /// <param name="name">The expanded function name (EQName form <c>Q{{uri}}local</c>).</param>
    /// <param name="args">Arguments to pass to the function.</param>
    /// <param name="context">Optional evaluation context.</param>
    /// <returns>The value returned by the function.</returns>
    public XdmValue TransformFunction(string name, XdmValue[] args, EvaluationContext? context = null)
    {
        return RunWithStack(() =>
        {
            var engine = new Runtime.TransformEngine(_stylesheet, context, _messageListener, _treatRecoverableAmbiguousMatchAsError);
            return engine.TransformFunction(name, args);
        }, DefaultTransformStackSize);
    }

    /// <summary>
    /// Invokes an <c>xsl:function</c> as the transformation entry point and serializes the result to a string.
    /// </summary>
    /// <param name="name">The expanded function name (EQName form <c>Q{{uri}}local</c>).</param>
    /// <param name="args">Arguments to pass to the function.</param>
    /// <param name="context">Optional evaluation context.</param>
    /// <param name="serializationParams">Optional serialization parameters merged with the effective output properties.</param>
    /// <returns>The serialized result of the function call.</returns>
    public string TransformFunctionToString(string name, XdmValue[] args, EvaluationContext? context = null, Stylesheet.OutputProperties? serializationParams = null)
    {
        var result = TransformFunction(name, args, context);
        var outputProperties = _stylesheet.EffectiveOutputProperties ?? new Stylesheet.OutputProperties();
        outputProperties.EffectiveVersion = _stylesheet.Version;
        outputProperties.ImplicitResultTree = true;
        if (outputProperties.UseCharacterMaps.Count > 0 && outputProperties.CharacterMap == null)
        {
            outputProperties = outputProperties.Clone();
            outputProperties.CharacterMap = _stylesheet.ResolveCharacterMap(
                outputProperties.UseCharacterMaps.Select(Stylesheet.Stylesheet.ExpandQName));
        }
        if (serializationParams != null)
        {
            outputProperties = outputProperties.Clone();
            Stylesheet.OutputProperties.Merge(outputProperties, serializationParams);
        }
        return Runtime.ResultTreeSerializer.Serialize(result, outputProperties);
    }

    /// <summary>
    /// Invokes an <c>xsl:function</c> as the transformation entry point on behalf of
    /// <c>fn:transform</c>, honoring delivery format, base output URI, serialization
    /// parameters, and captured secondary result documents.
    /// </summary>
    /// <param name="name">The expanded function name (EQName form <c>Q{{uri}}local</c>).</param>
    /// <param name="args">Arguments to pass to the function.</param>
    /// <param name="context">Optional evaluation context.</param>
    /// <param name="deliveryFormat">One of <c>document</c>, <c>raw</c>, or <c>serialized</c>.</param>
    /// <param name="baseOutputUri">Optional base output URI for secondary result documents.</param>
    /// <param name="serializationParams">Optional user-supplied serialization parameters.</param>
    /// <param name="secondaryResults">The captured secondary result documents.</param>
    /// <returns>The principal result in the requested delivery format.</returns>
    internal XdmValue TransformFunctionCaptured(
        string name,
        XdmValue[] args,
        EvaluationContext? context,
        string deliveryFormat,
        string? baseOutputUri,
        Stylesheet.OutputProperties? serializationParams,
        out IReadOnlyDictionary<string, XdmValue> secondaryResults)
        => TransformFunctionCaptured(name, args, context, deliveryFormat, baseOutputUri, serializationParams, source: null, out secondaryResults);

    /// <summary>
    /// Invokes an <c>xsl:function</c> as the transformation entry point on behalf of
    /// <c>fn:transform</c>, with an optional source node used as the global context
    /// item fallback.
    /// </summary>
    /// <param name="name">The expanded function name (EQName form <c>Q{{uri}}local</c>).</param>
    /// <param name="args">Arguments to pass to the function.</param>
    /// <param name="context">Optional evaluation context.</param>
    /// <param name="deliveryFormat">One of <c>document</c>, <c>raw</c>, or <c>serialized</c>.</param>
    /// <param name="baseOutputUri">Optional base output URI for secondary result documents.</param>
    /// <param name="serializationParams">Optional user-supplied serialization parameters.</param>
    /// <param name="source">Optional source node used as the global context item fallback.</param>
    /// <param name="secondaryResults">The captured secondary result documents.</param>
    /// <returns>The principal result in the requested delivery format.</returns>
    internal XdmValue TransformFunctionCaptured(
        string name,
        XdmValue[] args,
        EvaluationContext? context,
        string deliveryFormat,
        string? baseOutputUri,
        Stylesheet.OutputProperties? serializationParams,
        IXdmNode? source,
        out IReadOnlyDictionary<string, XdmValue> secondaryResults)
        => TransformFunctionCaptured(name, args, context, deliveryFormat, baseOutputUri, serializationParams, source, globalContextItem: null, out secondaryResults);

    /// <summary>
    /// Invokes an <c>xsl:function</c> as the transformation entry point on behalf of
    /// <c>fn:transform</c>, with an explicit source node and global context item.
    /// </summary>
    /// <param name="name">The expanded function name (EQName form <c>Q{{uri}}local</c>).</param>
    /// <param name="args">Arguments to pass to the function.</param>
    /// <param name="context">Optional evaluation context.</param>
    /// <param name="deliveryFormat">One of <c>document</c>, <c>raw</c>, or <c>serialized</c>.</param>
    /// <param name="baseOutputUri">Optional base output URI for secondary result documents.</param>
    /// <param name="serializationParams">Optional user-supplied serialization parameters.</param>
    /// <param name="source">Optional source node used as the global context item fallback.</param>
    /// <param name="globalContextItem">Optional explicit global context item for the transformation.</param>
    /// <param name="secondaryResults">The captured secondary result documents.</param>
    /// <returns>The principal result in the requested delivery format.</returns>
    internal XdmValue TransformFunctionCaptured(
        string name,
        XdmValue[] args,
        EvaluationContext? context,
        string deliveryFormat,
        string? baseOutputUri,
        Stylesheet.OutputProperties? serializationParams,
        IXdmNode? source,
        IXdmNode? globalContextItem,
        out IReadOnlyDictionary<string, XdmValue> secondaryResults)
    {
        IReadOnlyDictionary<string, XdmValue> capturedResults = new Dictionary<string, XdmValue>();
        var principalResult = RunWithStack(() =>
        {
            bool serialized = deliveryFormat == "serialized";
            var engine = new Runtime.TransformEngine(_stylesheet, context, _messageListener, _treatRecoverableAmbiguousMatchAsError);
            var result = engine.TransformFunction(name, args, captureResultDocuments: true, baseOutputUri: baseOutputUri, source: source, globalContextItem: globalContextItem);
            LastResultDocumentProperties = engine.PrincipalResultDocumentProperties;

            var captured = new Dictionary<string, XdmValue>();
            foreach (var (uri, entry) in engine.CapturedResultDocuments)
            {
                var props = entry.Props;
                if (serialized && serializationParams != null)
                {
                    props = props.Clone();
                    Stylesheet.OutputProperties.Merge(props, serializationParams);
                }
                captured[uri] = serialized
                    ? XdmValue.FromString(Runtime.ResultTreeSerializer.Serialize(entry.Value, props))
                    : entry.Value;
            }
            capturedResults = captured;

            if (deliveryFormat == "serialized")
            {
                var outputProperties = _stylesheet.EffectiveOutputProperties ?? new Stylesheet.OutputProperties();
                outputProperties.EffectiveVersion = _stylesheet.Version;
                outputProperties.ImplicitResultTree = true;
                if (serializationParams != null)
                {
                    outputProperties = outputProperties.Clone();
                    Stylesheet.OutputProperties.Merge(outputProperties, serializationParams);
                }
                ResolveCharacterMapsFor(outputProperties);
                return XdmValue.FromString(Runtime.ResultTreeSerializer.Serialize(result, outputProperties));
            }

            if (deliveryFormat == "document" && !result.IsUndefined)
            {
                if (!result.IsNode || result.NodeValue?.NodeKind != XdmNodeKind.Document)
                {
                    // Wrap a non-document result in a new document node.
                    XDocument wrapper;
                    if (result.IsNode && result.NodeValue != null)
                    {
                        var xdn = (Bosak.XPath.Providers.Xml.XDocumentNode)result.NodeValue;
                        if (xdn.UnderlyingObject is System.Xml.Linq.XElement elem)
                        {
                            wrapper = new System.Xml.Linq.XDocument(elem);
                        }
                        else if (xdn.UnderlyingObject is System.Xml.Linq.XDocument doc)
                        {
                            wrapper = doc;
                        }
                        else
                        {
                            wrapper = new System.Xml.Linq.XDocument();
                            wrapper.Add(new System.Xml.Linq.XText(result.ToString()));
                        }
                    }
                    else
                    {
                        wrapper = new System.Xml.Linq.XDocument();
                        wrapper.Add(new System.Xml.Linq.XText(result.ToString()));
                    }
                    result = XdmValue.FromNode(new Bosak.XPath.Providers.Xml.XDocumentNode(wrapper));
                }
            }

            return result;
        }, DefaultTransformStackSize);
        secondaryResults = capturedResults;
        return principalResult;
    }

    private void ResolveCharacterMapsFor(Stylesheet.OutputProperties outputProperties)
    {
        if (outputProperties.UseCharacterMaps.Count > 0)
        {
            // If the runtime already resolved the maps inside the declaring package scope,
            // use that concrete map instead of re-resolving against the principal stylesheet.
            if (outputProperties.CharacterMap != null && outputProperties.CharacterMap.Count > 0)
            {
                return;
            }

            var resolved = _stylesheet.ResolveCharacterMap(
                outputProperties.UseCharacterMaps.Select(Stylesheet.Stylesheet.ExpandQName));
            if (outputProperties.CharacterMap != null)
            {
                foreach (var kvp in outputProperties.CharacterMap)
                    resolved[kvp.Key] = kvp.Value;
            }
            outputProperties.CharacterMap = resolved;
        }
    }

    /// <summary>
    /// Runs the supplied transformation action on a dedicated thread with an enlarged
    /// stack.  This gives deep call-template recursion (such as the DocBook lookup.key
    /// template) enough stack space without requiring tail-call optimisations.
    /// </summary>
    private static T RunWithStack<T>(Func<T> action, int stackSize)
    {
        T? result = default;
        Exception? exception = null;
        var thread = new Thread(() =>
        {
            try
            {
                result = action();
            }
            catch (Exception ex)
            {
                exception = ex;
            }
        }, stackSize);
        thread.Start();
        thread.Join();
        if (exception != null)
            System.Runtime.ExceptionServices.ExceptionDispatchInfo.Throw(exception);
        return result!;
    }
}
