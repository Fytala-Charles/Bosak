from pathlib import Path
import importlib.util,json,copy,unittest,zipfile
from unittest.mock import patch
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('measurement',P/'measure.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class Guards(unittest.TestCase):
 def setUp(self):
  self.review=json.loads((P/'REVIEW.json').read_text())
  with zipfile.ZipFile(m.R/'docs/streaming-wrapper-cache/EVIDENCE.zip') as z:self.gate=json.loads(z.read('standalone/GATE.json'))
 def test_review_and_qualification_accept_exact_pins(self):
  m.validate_review(self.review);m.validate_qualification(self.review,self.gate,self.review['qualifiedRuntimeHashes'])
 def test_changed_review_refuses_before_launch(self):
  cases=[('provider','gc-verbose'),('main','0'*40),('qualifiedEngineCheckpoint','0'*40),('wallTimeoutSeconds',181),('memoryLimitBytes',8589934593),('traceLimitBytes',268435457),('readerTimeoutSeconds',121)]
  with patch.object(m.subprocess,'Popen') as launch:
   for field,value in cases:
    with self.subTest(field=field):
     bad=copy.deepcopy(self.review);bad[field]=value
     with self.assertRaises(ValueError):m.validate_review(bad)
   launch.assert_not_called()
 def test_failed_source_or_incomplete_qualification_refuses(self):
  with patch.object(m.subprocess,'Popen') as launch:
   for field,value in [('success',False),('sourceCommit','0'*40),('counts',{'Passed':10220,'Failed':1,'Skipped':4380})]:
    with self.subTest(field=field):
     bad=copy.deepcopy(self.gate);bad[field]=value
     with self.assertRaises(ValueError):m.validate_qualification(self.review,bad,self.review['qualifiedRuntimeHashes'])
   launch.assert_not_called()
 def test_changed_payload_or_missing_engine_refuses(self):
  hashes=copy.deepcopy(self.review['qualifiedRuntimeHashes']);hashes['Bosak.XPath.Providers.dll']='0'*64
  with patch.object(m.subprocess,'Popen') as launch:
   with self.assertRaises(ValueError):m.validate_qualification(self.review,self.gate,hashes)
   bad=copy.deepcopy(self.review);bad['engineHashes'].pop('Bosak.XPath.Providers.dll')
   with self.assertRaises(ValueError):m.validate_qualification(bad,self.gate,self.review['qualifiedRuntimeHashes'])
   launch.assert_not_called()

if __name__=='__main__':unittest.main()
