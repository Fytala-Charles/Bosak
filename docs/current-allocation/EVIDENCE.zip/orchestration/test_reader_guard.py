from pathlib import Path
import importlib.util,unittest,json,copy,hashlib
from unittest.mock import patch
P=Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('reader',P/'read-current.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class ReaderGuards(unittest.TestCase):
 def setUp(self):
  O=P/'measurement';self.run=json.loads((O/'COLLECT.json').read_text());self.result=json.loads((O/'RESULTS.json').read_text());self.pre=json.loads((O/'PRELAUNCH.json').read_text());self.review=(P/'REVIEW.json').read_bytes();self.sha=self.result['traceSha256']
 def test_complete_exact_producer_accepted(self):m.validate_producer(self.run,self.result,self.pre,self.review,self.sha)
 def test_partial_producer_and_unknown_trace_refuse_without_launch(self):
  with patch.object(m.subprocess,'Popen') as launch:
   for field,value in [('success',False),('status','TimedOut'),('timeoutSeconds',181),('memoryLimitBytes',1)]:
    bad=copy.deepcopy(self.run);bad[field]=value
    with self.assertRaises(ValueError):m.validate_producer(bad,self.result,self.pre,self.review,self.sha)
   with self.assertRaises(ValueError):m.validate_producer(self.run,self.result,self.pre,self.review,'0'*64)
   launch.assert_not_called()
 def test_changed_outcomes_and_review_refuse_without_launch(self):
  with patch.object(m.subprocess,'Popen') as launch:
   for field,value in [('selectedCases',53),('passed',51),('skipped',3),('unselected',14548),('completeProducerReceipt',False)]:
    bad=copy.deepcopy(self.result);bad[field]=value
    with self.assertRaises(ValueError):m.validate_producer(self.run,bad,self.pre,self.review,self.sha)
   with self.assertRaises(ValueError):m.validate_producer(self.run,self.result,self.pre,b'changed review',self.sha)
   launch.assert_not_called()

if __name__=='__main__':unittest.main()
