from pathlib import Path
import json,hashlib,shutil,subprocess,xml.etree.ElementTree as ET,importlib.util
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('current_measurement',P/'measure.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def validate_producer(run,result,prelaunch,review,rawHash):
 m.check(run.get('success') is True and run.get('status')=='Completed','Incomplete producer')
 m.check(run['timeoutSeconds']==180 and run['memoryLimitBytes']==8589934592,'Producer bounds changed')
 m.check(result.get('completeProducerReceipt') and result['selectedCases']==54 and result['passed']==52 and result['skipped']==2 and result['unselected']==14547,'Selected producer outcomes changed')
 m.check(result['traceSha256']==rawHash,'Unknown or changed produced trace')
 m.check(prelaunch['reviewSha256']==hashlib.sha256(review).hexdigest() and prelaunch['explicitQualificationValidated'] and prelaunch['nineEngineHashesValidated'],'Producer review chain changed')

def main():
 O=m.O;A=O/'analysis';m.check(not A.exists(),'Existing analysis attempt; preserve receipts')
 run=json.loads((O/'COLLECT.json').read_text());result=json.loads((O/'RESULTS.json').read_text());pre=json.loads((O/'PRELAUNCH.json').read_text())
 rawHash=m.sha(O/'raw.nettrace');validate_producer(run,result,pre,(P/'REVIEW.json').read_bytes(),rawHash)
 m.check(pre['sourceSha256']==m.sha(P/'measure.py'),'Producer source changed after capture')
 support=m.module('current_reader_support',m.R/'tools/xslt30_stack_profile.py');m.validate_current(support)
 expected=support.profiler_files(m.PROFILER)
 A.mkdir();build=A/'reader';build.mkdir();shutil.copyfile(m.R/'tools/xslt30-gc/GcEvents.cs.in',build/'GcEvents.cs')
 project=ET.Element('Project',Sdk='Microsoft.NET.Sdk');props=ET.SubElement(project,'PropertyGroup')
 for key,value in [('OutputType','Exe'),('TargetFramework','net8.0'),('ImplicitUsings','enable'),('Nullable','enable'),('GenerateDocumentationFile','true')]:ET.SubElement(props,key).text=value
 refs=ET.SubElement(project,'ItemGroup')
 for library in m.PROFILER.parent.glob('*.dll'):
  if library.name=='dotnet-trace.dll':continue
  ref=ET.SubElement(refs,'Reference',Include=library.stem);ET.SubElement(ref,'HintPath').text=str(library)
 ET.indent(project);ET.ElementTree(project).write(build/'GcEvents.csproj',encoding='unicode')
 with (A/'BUILD.log').open('xb') as log:subprocess.run(['dotnet','build',str(build/'GcEvents.csproj'),'-c','Release'],stdout=log,stderr=subprocess.STDOUT,check=True)
 pin=json.loads((O/'CASE-COST-PIN.json').read_text());command=[pin['nativeFiles']['dotnet.exe']['path'],'exec','--fx-version','8.0.28','--roll-forward','Disable',str(build/'bin/Release/net8.0/GcEvents.dll'),str(O/'raw.nettrace'),str(A/'gc-events.jsonl'),str(A/'gc-meta.json')]
 m.write(A/'READ-REVIEW.json',dict(completeProducerValidated=True,onlyAllowedTrace=rawHash,producerSourceSha256=pre['sourceSha256'],readerSourceSha256=m.sha(build/'GcEvents.cs'),readerBinarySha256=m.sha(build/'bin/Release/net8.0/GcEvents.dll'),workloadExecutions=0,timeoutSeconds=120,memoryLimitBytes=8589934592,historicalWhitelistUnchanged=True))
 receipt=support.bounded(command,A,A/'READER',120)
 m.check(receipt['success'],'Read-only reader failed; preserve without automatic retry')
 m.check(m.sha(O/'raw.nettrace')==rawHash,'Input trace changed')
 support.profiler_files(m.PROFILER);m.validate_current(support)
 analysis=m.module('current_gc_analysis',m.R/'tools/xslt30_gc_analysis.py')
 report=analysis.analyze([json.loads(line) for line in (A/'gc-events.jsonl').read_text().splitlines()])
 m.write(A/'REPORT.json',report)
 m.write(A/'IDENTITY.json',dict(traceSha256=rawHash,readerSourceSha256=m.sha(build/'GcEvents.cs'),readerBinarySha256=m.sha(build/'bin/Release/net8.0/GcEvents.dll'),readerRuntimeFiles=support.inventory(build/'bin/Release/net8.0'),analysisSourceSha256=m.sha(m.R/'tools/xslt30_gc_analysis.py'),workloadExecutions=0))
 print(json.dumps({k:report.get(k) for k in ['gcCount','gcFullySuspendedPhaseUnionMs','allocationTicks','reportedAllocationIntervalBytes','thresholdCrossingTypes','sampledAllocationEngineContexts']},indent=2))

if __name__=='__main__':main()
