from pathlib import Path
import json,collections,hashlib,re
p=Path(__file__).resolve().parent;r=Path('D:/Development/Bosak/.worktrees/Bosak.CurrentAllocation');o=p/'measurement';d=r/'docs/current-allocation'
report=json.loads((o/'analysis/REPORT.json').read_text());old=json.loads((r/'docs/xslt30-gc-correlation/ALLOCATION-REPORT.json').read_text())
policy=json.loads((r/'docs/xslt30-stack-profile/BASELINE.json').read_text());rows=[json.loads(x) for x in (o/'work/case-costs.jsonl').read_text().splitlines()]
assert {x['test']:x['result'] for x in rows}==policy['expectedResults'] and policy['fullCatalogCases']==14601
selectedSkips=json.loads((r/'docs/xslt30-stack-profile/SELECTED-SKIPS.json').read_text());assert {x['test'] for x in selectedSkips}=={x['test'] for x in rows if x['result']=='Skip'}
stdout=(o/'COLLECT.stdout.log').read_text(encoding='utf-8-sig')
for pattern in [r'^Total:\s+54\s*$',r'^Passed:\s+52\s*$',r'^Failed:\s+0\s*$',r'^Skipped:\s+2\s*$',r'^Unselected:\s+0\s*$',r'^Missing test sets:\s+0\s*$']:assert re.search(pattern,stdout,re.M),pattern
scope=dict(filteredRunnerCounts=dict(total=54,passed=52,failed=0,skipped=2,unselected=0),fullPinnedCatalogCases=14601,selectedSetCases=54,otherOriginalCasesOutsideSelectedSet=14601-54,outsideCountSource='Derived from full pinned catalog minus selected set; not the filtered runner console Unselected field',producerResultUnselectedField='Derived outside-set scope, not a producer console count',skipReasons=selectedSkips,skipReasonSource='Original pinned catalog/policy; runner does not print individual case skip explanations')
(d/'SCOPE.json').write_bytes((json.dumps(scope,indent=2)+'\n').encode())
def typeCounts(path):return collections.Counter(x['payload'].get('TypeName','') for x in map(json.loads,path.read_text().splitlines()) if x['name']=='GC/AllocationTick')
newTypes=typeCounts(o/'analysis/gc-events.jsonl');oldTypes=typeCounts(p.parent/'xslt30-gc-correlation-20261113/allocation/gc-events.jsonl')
comparison=dict(historicalVersion='1.81.8',currentImplementationVersion='1.81.9',sameRequestedProvider=True,sameSelectedCaseIdentitiesAndExpectedResults=True,controlledBenchmark=False,causalDeltaClaimed=False,rows=[])
for key in ['collections','gcFullySuspendedPhaseUnionMs','allocationTicks','reportedAllocationIntervalBytes']:
 comparison['rows'].append(dict(metric=key,historical=old[key],current=report[key]))
comparison['thresholdNameSamples']={token:dict(historical=sum(v for k,v in oldTypes.items() if token in k),current=sum(v for k,v in newTypes.items() if token in k)) for token in ['CreateValueCallback','DisplayClass50_0']}
comparison['limitations']=['Independent fresh-process captures have different caller reference metadata and heap/cache/timing histories.','Allocation interval bytes are approximate. Threshold names and ticks are not exact object counts or per-type byte ownership.','Generated display-class names can change; use the exact warmed-hit allocation regression as direct proof of the factory change.']
(d/'COMPARISON.json').write_bytes((json.dumps(comparison,indent=2)+'\n').encode())
summary=dict(diagnosticOnly=True,qualification=False,version='1.81.9',qualifiedEngineCheckpoint='af52e427ea122cdeef70ad125a90492ed585cc9e',engineCodeMatchesMain='375f2a0158b3c2a0059f52a4ee0adcd5306a6c00',selectedPassed=52,selectedExcluded=2,outsideSelectedSetDerived=14547,collections=report['collections'],allocationTicks=report['allocationTicks'],approxReportedAllocationIntervalBytes=report['reportedAllocationIntervalBytes'],fullySuspendedPhaseUnionMs=report['gcFullySuspendedPhaseUnionMs'],traceBytes=(o/'raw.nettrace').stat().st_size,traceSha256=hashlib.sha256((o/'raw.nettrace').read_bytes()).hexdigest(),unmatched=report['unmatched'],controls=7,nextLead='Investigate primitive-scalar materialization at comparison/conversion call sites with a bounded allocation reproduction before proposing a fast path; preserve typed-node/list atomization, lazy/error order and sequence lifetime.',engineChanged=False,published=False)
(d/'RESULTS.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode());(d/'REPORT.json').write_bytes((o/'analysis/REPORT.json').read_bytes())
print(json.dumps(summary,indent=2))
