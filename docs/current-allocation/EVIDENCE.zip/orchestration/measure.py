"""One reviewed1.81.9 diagnostic; historical tool defaults and whitelists are untouched."""
from pathlib import Path
import subprocess,json,hashlib,zipfile,shutil,importlib.util,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parent
R=Path('D:/Development/Bosak/.worktrees/Bosak.CurrentAllocation')
O=P/'measurement'
PROFILER=P.parent/'xslt30-cpu-profile-20261113/profiler/.store/dotnet-trace/10.0.745401/dotnet-trace/10.0.745401/tools/net8.0/any/dotnet-trace.dll'
CORPUS=P.parent/'xslt30-final-retry-20261112/corpus'

def check(condition,message):
 if not condition:raise ValueError(message)

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):path.write_bytes((json.dumps(value,indent=2)+'\n').encode())
def module(name,path):
 expected=subprocess.check_output(['git','show','375f2a0158b3c2a0059f52a4ee0adcd5306a6c00:'+path.relative_to(R).as_posix()],cwd=R)
 check(path.read_bytes().replace(b'\r\n',b'\n')==expected.replace(b'\r\n',b'\n'),'Committed support source changed')
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def validate_qualification(review,gate,hashes):
 check(gate.get('success') is True,'Qualification is not successful')
 check(gate.get('sourceCommit')==review['qualifiedEngineCheckpoint'],'Unreviewed qualified source')
 check(gate.get('counts')=={'Passed':10221,'Failed':0,'Skipped':4380},'Qualified outcome profile changed')
 check(hashes==review['qualifiedRuntimeHashes'],'Qualified runtime payload changed')
 check(len(review['engineHashes'])==9,'Need exact nine engine hashes')

def validate_review(review):
 check(review['main']=='375f2a0158b3c2a0059f52a4ee0adcd5306a6c00' and review['qualifiedEngineCheckpoint']=='af52e427ea122cdeef70ad125a90492ed585cc9e','Unreviewed source identity')
 check(review['provider']=='Microsoft-Windows-DotNETRuntime:0x1:5','Unreviewed provider')
 check((review['wallTimeoutSeconds'],review['memoryLimitBytes'],review['traceLimitBytes'],review['readerTimeoutSeconds'])==(180,8589934592,268435456,120),'Diagnostic bounds changed')

def preflight():
 review=json.loads((P/'REVIEW.json').read_text())
 validate_review(review)
 check(review['recordedBeforeImplementation'] and review['recordedBeforeCapture'],'Missing prior review')
 check(not O.exists(),'Existing attempt output; preserve receipts')
 check(not subprocess.check_output(['git','diff',review['qualifiedEngineCheckpoint'],review['main'],'--','src','tests/Bosak.Xslt.Conformance','Bosak.sln','Directory.Build.props','global.json'],cwd=R),'Engine/runner source parity changed')
 d=R/'docs/streaming-wrapper-cache'
 committed=subprocess.check_output(['git','show',review['main']+':docs/streaming-wrapper-cache/MANIFEST.json'],cwd=R)
 check(hashlib.sha256(committed).hexdigest()==review['qualifiedDossierManifestSha256'] and (d/'MANIFEST.json').read_bytes()==committed,'Trusted qualification manifest changed')
 for n,e in json.loads(committed)['files'].items():check(sha(d/n)==e['sha256'],'Sealed qualification evidence changed: '+n)
 with zipfile.ZipFile(d/'EVIDENCE.zip') as z:validate_qualification(review,json.loads(z.read('standalone/GATE.json')),json.loads(z.read('standalone/RUNTIME-HASHES.json')))
 support=module('current_stack_support',R/'tools/xslt30_stack_profile.py');cost=module('current_cost_support',R/'tools/xslt30_case_cost.py');gate=module('current_gate',R/'tools/xslt30_gate.py')
 policy=support.baseline();tool=support.profiler_files(PROFILER)
 with zipfile.ZipFile(R/'docs/xslt30-stack-profile/REFERENCE.zip') as z:pin=json.loads(z.read('diagnostic/CASE-COST-PIN.json'))
 support.native_files(pin)
 originalCollector=json.loads((P.parent/'xslt30-gc-alloc-run-20261113/COLLECTOR-FRAMEWORK.json').read_text())
 check(support.inventory(Path(originalCollector['path']))==originalCollector['files'],'Original collector framework changed')
 _,_,inputs,_=gate.baseline();check(gate.inventory(CORPUS)==inputs,'Corpus differs from immutable inventory')
 return review,support,cost,gate,policy,tool,pin,originalCollector,inputs

def prepare():
 review,support,cost,gate,policy,tool,pin,collector,inputs=preflight()
 O.mkdir();runtime=O/'qualified-runtime';runtime.mkdir()
 with zipfile.ZipFile(R/'docs/streaming-wrapper-cache/REFERENCE.zip') as z:
  for name,digest in review['qualifiedRuntimeHashes'].items():
   data=z.read('candidate/'+name);check(hashlib.sha256(data).hexdigest()==digest,'Qualified reference bytes changed');(runtime/name).write_bytes(data)
 build=O/'diagnostic';build.mkdir();program=R/'tests/Bosak.Xslt.Conformance/Program.cs'
 committed=subprocess.check_output(['git','show',review['qualifiedEngineCheckpoint']+':tests/Bosak.Xslt.Conformance/Program.cs'],cwd=R)
 check(program.read_bytes().replace(b'\r\n',b'\n')==committed.replace(b'\r\n',b'\n'),'Caller source changed')
 (build/'Program.cs').write_bytes(cost.instrument(program.read_bytes()));shutil.copyfile(R/'tools/xslt30-case-cost/CaseCosts.cs.in',build/'CaseCosts.cs')
 project=ET.Element('Project',Sdk='Microsoft.NET.Sdk');props=ET.SubElement(project,'PropertyGroup')
 for key,value in [('OutputType','Exe'),('TargetFramework','net10.0'),('AssemblyName','Bosak.Xslt.Conformance'),('ImplicitUsings','enable'),('Nullable','enable'),('GenerateDocumentationFile','true')]:ET.SubElement(props,key).text=value
 refs=ET.SubElement(project,'ItemGroup')
 for name in review['engineHashes']:
  ref=ET.SubElement(refs,'Reference',Include=Path(name).stem);ET.SubElement(ref,'HintPath').text=str(runtime/name)
 ET.indent(project);ET.ElementTree(project).write(build/'Diagnostic.csproj',encoding='unicode')
 with (O/'BUILD.log').open('xb') as log:subprocess.run(['dotnet','build',str(build/'Diagnostic.csproj'),'-c','Release'],stdout=log,stderr=subprocess.STDOUT,check=True)
 produced=build/'bin/Release/net10.0'
 for name,digest in review['engineHashes'].items():check(sha(produced/name)==digest,'Copied caller changed engine input')
 shutil.copytree(runtime,O/'runtime')
 for suffix in ['dll','pdb','deps.json','runtimeconfig.json']:shutil.copyfile(produced/('Bosak.Xslt.Conformance.'+suffix),O/'runtime'/('Bosak.Xslt.Conformance.'+suffix))
 config=O/'runtime/Bosak.Xslt.Conformance.runtimeconfig.json';data=json.loads(config.read_text());data['runtimeOptions']['framework']['version']='10.0.11';data['runtimeOptions']['rollForward']='Disable';write(config,data)
 shutil.copytree(CORPUS,O/'corpus')
 for name,data in [('CASE-COST-PIN.json',pin),('CORPUS-BEFORE.json',inputs),('RUNTIME-BEFORE.json',support.inventory(O/'runtime')),('COLLECTOR-FRAMEWORK.json',collector)]:write(O/name,data)
 plan=dict(policy=policy,profiler=str(PROFILER),profilerFiles=tool,engineHashes=review['engineHashes'],sourceCommit=None,qualifiedEngineCheckpoint=review['qualifiedEngineCheckpoint'],main=review['main'],diagnosticOnly=True,qualification=False,toolSourceSha256=sha(R/'tools/xslt30_stack_profile.py'),experimentSourceSha256=sha(Path(__file__)),provider=review['provider'])
 write(O/'PLAN.json',plan)
 write(O/'SOURCE-IDENTITY.json',dict(originalRunnerSourceSha256=sha(program),diagnosticSources={f.name:sha(f) for f in [build/'Program.cs',build/'CaseCosts.cs']},engineHashes=review['engineHashes'],engineAndRunnerSourceParity=True,qualifiedDossierManifestSha256=review['qualifiedDossierManifestSha256']))
 return support,gate

def validate_current(support):
 plan,pin=support.validate(O);review=json.loads((P/'REVIEW.json').read_text())
 check(plan['engineHashes']==review['engineHashes'] and plan['provider']==review['provider'],'Explicit current-engine scope changed')
 for name,digest in review['engineHashes'].items():check(sha(O/'runtime'/name)==digest,'Current engine hash changed')
 return plan,pin

def collect():
 support,gate=prepare();plan,pin=validate_current(support);_,command=support.commands(O,plan,pin)
 i=command.index('--profile');check(command[i+1]=='dotnet-common,dotnet-sampled-thread-time','Unexpected default collector scope');command[i]='--providers';command[i+1]=plan['provider']
 write(O/'PRELAUNCH.json',dict(explicitQualificationValidated=True,nineEngineHashesValidated=True,reviewSha256=sha(P/'REVIEW.json'),sourceSha256=sha(Path(__file__)),command=command,diagnosticOnly=True,qualification=False))
 work=O/'work';work.mkdir();result=support.bounded(command,work,O/'COLLECT',180,O/'raw.nettrace')
 check(result['success'],'Original failed capture retained; do not retry automatically')
 rows=[json.loads(s) for s in (work/'case-costs.jsonl').read_text().splitlines()];support.validate_cases(rows,plan['policy']['expectedResults'])
 end=json.loads((work/'case-cost-end.json').read_text());check(end['rows']==54 and not end['errors'],'Incomplete case ledger')
 native=json.loads((work/'case-cost-runtime.json').read_text());check(native['frameworkVersion']=='10.0.11','Target framework changed')
 for name,value in pin['nativeFiles'].items():check(native['modules'][name]['sha256']==value['sha256'],'Loaded native pin changed')
 validate_current(support);after=gate.inventory(O/'corpus');check(after==json.loads((O/'CORPUS-BEFORE.json').read_text()),'Corpus changed')
 write(O/'CORPUS-AFTER.json',after);write(O/'RUNTIME-AFTER.json',support.inventory(O/'runtime'))
 write(O/'TARGET-FRAMEWORK-AFTER.json',support.inventory(Path(pin['frameworkDirectory'])))
 collector=json.loads((O/'COLLECTOR-FRAMEWORK.json').read_text());write(O/'COLLECTOR-FRAMEWORK-AFTER.json',support.inventory(Path(collector['path'])))
 write(O/'PROFILER-AFTER.json',{name:sha(PROFILER.parent/name) for name in plan['profilerFiles']})
 write(O/'RESULTS.json',dict(diagnosticOnly=True,qualification=False,selectedCases=len(rows),passed=sum(x['result']=='Pass' for x in rows),skipped=sum(x['result']=='Skip' for x in rows),unselected=14547,caseWallSeconds=sum(x['wallSeconds'] for x in rows),caseCpuSeconds=sum(x['cpuSeconds'] for x in rows),traceSha256=sha(O/'raw.nettrace'),completeProducerReceipt=True,noStackSampler=True,inventoryUnchanged=True))
 print((O/'RESULTS.json').read_text())

if __name__=='__main__':collect()
