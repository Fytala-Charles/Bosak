// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 19 mei 2026
// PURPOSE              : Specifies the XPath language version compatibility for compilation
// SPECIAL NOTES        : Part of the Bosak XPath 3.1 implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 19-05-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 08-10-2026     | REQ-118: added XPath40 (4.0-S0 version gate)                                             |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.3   | 09-10-2026     | REQ-123: added XPath40Experimental (1.1.0 track — 4.0-Exp S1 level plumbing)             |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.4   | 24-10-2026     | Document Experimental opt-in to the newer absent-substring contract.                     |
//                      | Charles Korthout | 0.5   | 24-10-2026     | Document Experimental signed Unix epochs with frozen domain preserved.                    |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
namespace Bosak.XPath.Api;

/// <summary>
/// Specifies the XPath language version compatibility for compilation.
/// The default (<see cref="XPath31"/>) is unchanged from previous releases;
/// <see cref="XPath40"/> opts in to XPath 4.0 features (REQ-118 version gate,
/// dossier docs/REQ-118-xpath-xslt-40.md); <see cref="XPath40Experimental"/>
/// additionally opts in to not-yet-stabilized 4.0 draft additions and explicitly
/// documented newer function contracts (REQ-123).
/// </summary>
public enum XPathCompatibility
{
    /// <summary>
    /// XPath 4.0, experimental tier (opt-in, 1.1.0). Everything in
    /// <see cref="XPath40"/> plus 4.0 draft additions that are NOT yet
    /// stabilized — post-June-2026 spec sections carrying churn risk
    /// (REQ-123). Experimental-only functions raise XPST0017 at both
    /// <see cref="XPath31"/> and <see cref="XPath40"/>; semantics may
    /// change as the draft moves. This profile also opts into documented newer
    /// contracts for existing functions: <c>index-of-substring</c> interprets an
    /// absent substring as an empty string; frozen <see cref="XPath40"/> retains
    /// the XPTY0004 refusal for that argument. <c>unix-dateTime</c> accepts signed
    /// epochs within the supported calendar; frozen <see cref="XPath40"/> retains
    /// the nonnegative epoch domain.
    /// </summary>
    XPath40Experimental = 50,

    /// <summary>
    /// XPath 4.0 (opt-in). Allows the constructs of XPath 3.1 plus the XPath 4.0
    /// surfaces as they land: 4.0-only F&amp;O functions (slice 4.0-S1: fn:replicate,
    /// fn:slice, fn:items-at, fn:foot, fn:trunk, fn:insert-separator, fn:char,
    /// fn:characters); grammar features land in later slices.
    /// </summary>
    XPath40 = 40,

    /// <summary>
    /// XPath 3.1 (default). Allows all XPath 3.1 constructs including
    /// maps, arrays, higher-order functions, the simple map operator (!),
    /// arrow operator (=>), and string concatenation (||). XPath 4.0-only
    /// functions raise XPST0017 during compilation.
    /// </summary>
    XPath31 = 31,

    /// <summary>
    /// XPath 3.0. Rejects XPath 3.1-specific constructs (maps, arrays,
    /// namespace-node() kind test) but allows higher-order functions.
    /// </summary>
    XPath30 = 30,

    /// <summary>
    /// XPath 2.0 compatibility mode. Rejects all XPath 3.0+ constructs
    /// including higher-order functions, the simple map operator, arrow
    /// operator, and string concatenation.
    /// </summary>
    XPath20 = 20,
}
