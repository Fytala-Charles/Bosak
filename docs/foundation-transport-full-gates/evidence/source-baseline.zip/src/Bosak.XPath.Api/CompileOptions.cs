// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 19 mei 2026
// PURPOSE              : Options that control how an XPath expression is compiled
// SPECIAL NOTES        : Part of the Bosak XPath 3.1 implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 19-05-2026     | Creation                                                                                 |
//                      | Charles Korthout | 0.2   | 24-06-2026     | Added DefiningElementDefaultNamespace for element-available default namespace            |
//                      | Charles Korthout | 0.3   | 26-06-2026     | Added BackwardsCompatible for XSLT 1.0 static constant folding                         |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.4   | 25-07-2026     | Added Xml11LineEndings for XML 1.1 line-ending normalization in string literals        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.5   | 21-09-2026     | API freeze stage D: Default now returns a fresh instance per access; clarified          |
//                      |                  |       |                | DefiningElementDefaultNamespace summary                                                  |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.6   | 24-09-2026     | REQ-104: added SchemaSet — compiled schema set enabling schema-aware kind tests        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.7   | 12-10-2026     | Expose enumeration alias static context for XPath 4.0 type tests
//                      | Charles Korthout | 0.8   | 13-10-2026     | Document inline namespaces and XPath 4.0 default namespace wildcard
//                      | Charles Korthout | 0.9 | 13-10-2026     | Carry expanded XSLT item-type aliases through the internal host static context
//                      | Charles Korthout | 0.10 | 13-10-2026     | Carry known nominative record names for host static type validation
//                      | Charles Korthout | 0.11  | 13-10-2026     | Carry internal host keyword parameter identities for exact-arity functions.
//                      | Charles Korthout | 0.3   | 14-10-2026     | Capture host required-prefix lengths without public API changes.                         |
//                      | Charles Korthout | 0.12  | 18-10-2026     | Correct build-warning documentation and nullable-flow diagnostics.                     |
//                      |==================|=======|================|=========================================================================================

// ===========================================================================================================================================================

using System.Xml.Schema;

namespace Bosak.XPath.Api;

/// <summary>
/// Options that control how an XPath expression is compiled.
/// </summary>
public sealed class CompileOptions
{
    /// <summary>
    /// Default options: XPath 3.1 compatibility, no static context.
    /// Returns a new instance on every access.
    /// </summary>
    public static CompileOptions Default => new();

    /// <summary>
    /// The XPath language version to target. Defaults to <see cref="XPathCompatibility.XPath31"/>.
    /// </summary>
    public XPathCompatibility Compatibility { get; init; } = XPathCompatibility.XPath31;

    /// <summary>
    /// Namespace bindings available during static analysis.
    /// Key = prefix, Value = namespace URI.
    /// </summary>
    public IReadOnlyDictionary<string, string>? Namespaces { get; init; }

    /// <summary>
    /// XPath 4.0 enumeration aliases for type tests, treat and casting expressions.
    /// Keys are expanded names in Q{uri}local form; values are enum(...) item types.
    /// Other named item types and declaration conversion are not supported by this option.
    /// </summary>
    public IReadOnlyDictionary<string, string>? EnumerationItemTypes { get; init; }

    // Expanded package-local definitions supplied by the XSLT host, independent of
    // the public enumeration-only option. Definitions contain no unresolved aliases.
    internal IReadOnlyDictionary<string, string>? ItemTypeAliases { get; init; }

    // The XSLT host supplies expanded parameter EQNames for the declaration selected
    // by supplied arity. Null retains the standard-library keyword signature lookup.
    internal Func<string, string, int, IReadOnlyList<string>?>? FunctionParameterNames { get; init; }

    // Required prefix length for a host signature; defaults remain evaluated by the host.
    internal Func<string, string, int, int?>? FunctionMinimumArity { get; init; }

    // Non-null enables host named-type validation, even when no records are declared.
    internal IReadOnlySet<string>? NamedRecordTypeNames { get; init; }

    /// <summary>
    /// The default element namespace URI for unprefixed element and type names
    /// in XPath expressions. When null or empty, unprefixed names match no namespace.
    /// In XPath 4.0, <c>##any</c> matches unprefixed element axis name tests in any namespace;
    /// unprefixed item type names use the XML Schema namespace, while kind-test names use no namespace.
    /// Inline XPath 4.0 namespace declarations override these supplied bindings for that expression.
    /// </summary>
    public string? DefaultElementNamespace { get; init; }

    /// <summary>
    /// Enables XML 1.1 line-ending normalization in string literals (#xD#xA, #xD#x85,
    /// lone #xD, #x85, and #x2028 all normalize to #xA). Disabled: character references
    /// produce their exact characters (the XML 1.0 behavior expected by most QT3 tests).
    /// </summary>
    public bool Xml11LineEndings { get; init; }

    /// <summary>
    /// The default namespace of the <em>defining</em> element — the XSLT stylesheet or
    /// XQuery module element in which the expression appears — used when resolving
    /// unprefixed element names in that module's host markup. Used by XSLT's
    /// <c>fn:element-available</c> to expand unprefixed lexical QNames per the XSLT
    /// specification. Distinct from <see cref="DefaultElementNamespace"/>, which applies
    /// to unprefixed element names inside the XPath expression itself.
    /// </summary>
    public string? DefiningElementDefaultNamespace { get; init; }

    /// <summary>
    /// Statically-known variable types for optimization and early error detection.
    /// Key = variable QName (e.g., "xs:QName"), Value = XDM type.
    /// </summary>
    public IReadOnlyDictionary<string, string>? StaticVariableTypes { get; init; }

    /// <summary>
    /// If true, the compiler performs additional validations and may
    /// reject expressions that rely on dynamic context information.
    /// </summary>
    public bool StrictStaticTyping { get; init; }

    /// <summary>
    /// The static base URI for resolving relative URIs in expressions
    /// (e.g. <c>resolve-uri('file.xml')</c>). When null, the runtime
    /// context's <see cref="Bosak.XPath.Runtime.Vm.EvaluationContext.BaseUri"/> is used.
    /// </summary>
    public string? BaseUri { get; init; }

    /// <summary>
    /// If true, enables IL JIT compilation for hot expressions after
    /// a threshold of executions. Defaults to false (register VM only).
    /// </summary>
    public bool EnableJit { get; init; }

    /// <summary>
    /// If true, the expression is compiled in XPath 1.0 backwards-compatible
    /// mode. This affects static type folding (e.g. integer arithmetic is
    /// promoted to <c>xs:double</c>) and may influence parser diagnostics.
    /// </summary>
    public bool BackwardsCompatible { get; init; }

    /// <summary>
    /// The compiled schema set in scope for a schema-aware compilation. When non-null,
    /// <c>schema-element()</c>/<c>schema-attribute()</c> kind tests are permitted and their
    /// name arguments are validated against the set's global declarations (XPST0008 when no
    /// matching declaration exists). When null (the default), schema-aware kind tests raise
    /// XPST0008 (no schema awareness). Mirrors <see cref="Bosak.XPath.Runtime.Vm.EvaluationContext.SchemaSet"/>,
    /// which carries the set at evaluation time.
    /// </summary>
    public XmlSchemaSet? SchemaSet { get; init; }
}
