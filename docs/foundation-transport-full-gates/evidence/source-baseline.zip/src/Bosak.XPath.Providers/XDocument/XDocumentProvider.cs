// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 19 mei 2026
// PURPOSE              : Extension methods to convert LINQ to XML objects into IXdmNode adapters
// SPECIAL NOTES        : Part of the XDocument node provider layer.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 19-05-2026     | Creation                                                                                 |
//                      | Charles Korthout | 0.2   | 05-06-2026     | Preserve whitespace in elements; strip document-level whitespace-only text nodes        |
//                      | Charles Korthout | 0.3   | 25-06-2026     | LoadXml sets DocumentUri on returned document node                                      |
//                      | Charles Korthout | 0.4   | 15-07-2026     | LoadXml absolutizes relative paths before building the document URI (UriFormatException)|
//                      | Charles Korthout | 0.5   | 15-07-2026     | Added LoadXml overload with explicit baseUri for published resource URIs                |
//                      | Charles Korthout | 0.6   | 19-07-2026     | Added LoadXml overload with optional XML Schema validation and PSVI annotations         |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.7   | 25-07-2026     | Added ConstructElement for XQuery element constructors (ElementConstructorHook)        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.8   | 25-07-2026     | Added ConstructContentNode; xmlns:xml redundancy and xmlns:xmlns rejection             |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.9   | 25-07-2026     | Namespace fixup; in-scope namespace copying on clones; base-URI annotation             |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.10  | 25-07-2026     | ConstructAttribute/ConstructDocument for computed constructors; namespace declarations and text content nodes |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.11  | 25-07-2026     | Preserve XML 1.1 undeclaration annotations across the base-URI reparse                                        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.9   | 28-07-2026     | Non-propagating namespace-binding markers for attribute-name bindings; no content fixup; clone annotations |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.10  | 29-07-2026     | Content ns declarations win over name prefixes (generated prefixes); xmlns:xml omitted; parentless ns nodes |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.12  | 07-08-2026     | Strict validation strips whitespace-only text nodes in element-only schema content (ForExprType009) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.13  | 17-08-2026     | ConstructElement handles clashing attribute prefixes via generated prefixes and attribute annotations (cbcl-ns-fixup-1) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.14  | 18-08-2026     | XQST0070/XQST0085/XQDY0096 reserved-namespace checks in element constructors            |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.15  | 18-08-2026     | XQDY0138 for document nodes used as element content                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.16  | 18-08-2026     | XQDY0092 for invalid xml:space in computed attributes (K2-ComputeConAttr-60)            |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.17  | 21-08-2026     | Encode XML 1.1-only name characters in constructed element/attribute names              |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.18  | 21-08-2026     | Expose ValidateXDocument for in-memory schema validation (fn:json-to-xml validate)      |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.19  | 23-08-2026     | Annotate constructed elements so they report xs:anyType instead of xs:untyped |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.20  | 09-09-2026     | XML doc coverage on public API (Beta review)                                             |
//                      | Charles Korthout | 0.21  | 09-09-2026     | Perf: construct via the shared XDocumentNode wrapper cache                               |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.22  | 21-09-2026     | API freeze stage D: LoadXml(filePath) overloads renamed to LoadFile                      |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.23  | 24-09-2026     | REQ-105 (PA-3): validated documents get schema-normalized simple-typed values          |
//                      |                  |       |                | (whiteSpace facet, XDM 3.3.2; match-136..141)                                            |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.24  | 10-10-2026     | REQ-125 Slice B: LoadControlled parses host-approved bytes with DTD/entities prohibited  |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.25  | 18-10-2026     | Correct build-warning documentation and nullable-flow diagnostics.                     |
//                      | Charles Korthout | 0.26 | 27-10-2026     | Normalize copied trees into reversible encoded-name storage. (1.26.11). |
//                      |==================|=======|================|=========================================================================================

//                      | Charles Korthout | 0.27  | 28-10-2026     | Clone node content with lexical namespace preservation/inheritance modes (1.31.0). |
//                      | Charles Korthout | 0.28  | 28-10-2026     | Apply explicit/default construction copying with destination-private annotations (1.32.0). |
// ===========================================================================================================================================================

using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using Bosak.XPath.Core.Xdm;

namespace Bosak.XPath.Providers.Xml;


/// <summary>
/// Provides extension methods to adapt LINQ to XML types to the XDM <see cref="IXdmNode"/> interface.
/// </summary>
public static class XDocumentProvider
{
    /// <summary>
    /// Adapts an <see cref="XDocument"/> to <see cref="IXdmNode"/>.
    /// </summary>
    /// <param name="document">The document to adapt.</param>
    /// <returns>The document node adapter.</returns>
    public static IXdmNode ToXdmNode(this System.Xml.Linq.XDocument document)
    {
        ArgumentNullException.ThrowIfNull(document);
        var map = ComputeDocumentOrder(document);
        XDocumentNode.RegisterOrderMap(document, map);
        return XDocumentNode.Wrap(document);
    }

    /// <summary>
    /// Adapts an <see cref="XElement"/> to <see cref="IXdmNode"/>.
    /// </summary>
    /// <param name="element">The element to adapt.</param>
    /// <returns>The element node adapter.</returns>
    public static IXdmNode ToXdmNode(this XElement element)
    {
        ArgumentNullException.ThrowIfNull(element);
        var doc = element.Document;
        if (doc is not null)
        {
            var map = ComputeDocumentOrder(doc);
            XDocumentNode.RegisterOrderMap(doc, map);
        }
        return XDocumentNode.Wrap(element);
    }

    /// <summary>
    /// Builds an XDocument-backed element node from provider-neutral construction data
    /// (the <c>Bosak.XPath.Runtime.Vm.EvaluationContext.ElementConstructorHook</c>).
    /// Prefixes used by the tag and attributes are declared on the element so that
    /// serialization honors them; existing nodes are deep-copied into the new tree.
    /// </summary>
    /// <param name="spec">The provider-neutral element construction data.</param>
    /// <returns>The constructed element node.</returns>
    public static IXdmNode ConstructElement(XdmElementSpec spec)
    {
        ArgumentNullException.ThrowIfNull(spec);

        // XQDY0096: a constructed element must not be in the XMLNS namespace, and a non-'xml'
        // prefix must not be bound to the XML namespace URI (comp-elem-bad-name-2/3).
        if (spec.NamespaceUri == "http://www.w3.org/2000/xmlns/")
            throw new InvalidOperationException("XQDY0096: A computed element name must not use the XMLNS namespace URI.");
        if (spec.NamespaceUri == "http://www.w3.org/XML/1998/namespace" && spec.Prefix is not (null or "xml"))
            throw new InvalidOperationException("XQDY0096: A computed element name must not bind a non-'xml' prefix to the XML namespace URI.");

        XNamespace ns = spec.NamespaceUri is null ? XNamespace.None : XNamespace.Get(spec.NamespaceUri);
        // XML 1.1 allows name characters that .NET's XML 1.0 name checker rejects.
        // Encode them so the element can be stored in an XName; XDocumentNode decodes
        // them back when reporting LocalName/Prefix and when serializing.
        string encodedLocalName = Xml11NameCodec.EncodeName(spec.LocalName);
        var element = new XElement(ns + encodedLocalName);

        // The constructed element's base URI is the static base URI of the query
        // (honored by XDocumentNode.ResolveXmlBase through the string annotation).
        if (!string.IsNullOrEmpty(spec.BaseUri))
            element.AddAnnotation(spec.BaseUri);

        // Mark encoded-name storage independently of XML-version feature validation.
        element.AddAnnotation(Xml11Annotation.Instance);

        // XDM: elements created by an element constructor have type annotation xs:anyType,
        // while elements parsed from an unvalidated document have type annotation xs:untyped.
        if (spec.ConstructionMode == XdmConstructionMode.Strip)
            XQueryConstructionMetadata.Strip(element);
        else
        {
            element.AddAnnotation(ConstructedElementAnnotation.Instance);
            if (spec.ConstructionMode == XdmConstructionMode.Preserve)
                element.AddAnnotation(new XmlSchemaInfo
                {
                    SchemaType = XmlSchemaType.GetBuiltInComplexType(new System.Xml.XmlQualifiedName("anyType", "http://www.w3.org/2001/XMLSchema"))
                });
        }

        // Declare prefixes so serialization uses the source prefixes rather than generated ones.
        // Explicit xmlns declarations in the constructor always win over generated ones.
        var declared = new HashSet<string>(StringComparer.Ordinal);          // reserved prefixes
        var declaredUris = new Dictionary<string, string>(StringComparer.Ordinal); // prefix -> URI bindings on the element
        foreach (var attr in spec.Attributes)
        {
            if (attr.Prefix == "xmlns")
                declared.Add(attr.LocalName);
            else if (attr.LocalName == "xmlns" && attr.Prefix is null)
                declared.Add("");
        }

        // Computed namespace declarations in content take precedence over name-implied
        // bindings: a tag or attribute name whose prefix they redeclare with a different
        // URI gets a generated prefix instead (nscons-010/011).
        var contentNsDecls = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (var item in spec.Content)
        {
            if (item.Kind == XdmContentKind.Namespace)
            {
                var declPrefix = item.Target ?? string.Empty;
                if (!contentNsDecls.ContainsKey(declPrefix))
                    contentNsDecls[declPrefix] = item.Text ?? string.Empty;
            }
        }
        string GeneratePrefix()
        {
            // Only probe membership: Declare() performs the declared.Add itself
            // (adding here would suppress the declaration entirely).
            for (int i = 1; ; i++)
            {
                var candidate = $"ns{i}";
                if (!declared.Contains(candidate) && !declaredUris.ContainsKey(candidate))
                    return candidate;
            }
        }

        // Adds a namespace declaration for the supplied prefix/URI if one is needed and
        // returns the actual prefix used. If the requested prefix is already bound to a
        // different URI, a generated prefix is allocated for this URI instead.
        string? Declare(string? prefix, string? nsUri, bool impliedByAttributeName = false)
        {
            if (string.IsNullOrEmpty(nsUri))
                return null;

            if (prefix is null)
            {
                if (declared.Contains(""))
                {
                    // Default namespace will be supplied by the explicit xmlns attribute;
                    // keep the tag unprefixed.
                    return "";
                }
                if (declaredUris.TryGetValue("", out var existingDefaultUri))
                {
                    return existingDefaultUri == nsUri ? "" : null;
                }
                if (declaredUris.TryAdd("", nsUri))
                {
                    element.Add(new XAttribute("xmlns", nsUri));
                    declared.Add("");
                    return "";
                }
            }

            if (prefix is ("xml" or "xmlns"))
                return null;

            string p = prefix!;

            // An explicit xmlns:prefix attribute in the constructor reserves that prefix.
            // The URI is assumed to match; if it does not, the query is in error and the
            // explicit declaration wins.
            if (declared.Contains(p) && !declaredUris.ContainsKey(p))
                return p;

            if (declaredUris.TryAdd(p, nsUri))
            {
                var declAttr = new XAttribute(XNamespace.Xmlns + Xml11NameCodec.EncodeName(p), nsUri);
                // Bindings implied by an attribute's name are part of this element's
                // in-scope namespaces but do not propagate to nested constructors.
                if (impliedByAttributeName)
                    declAttr.AddAnnotation(new NonPropagatingNamespaceBinding());
                element.Add(declAttr);
                declared.Add(p);
                return p;
            }

            if (declaredUris[p] == nsUri)
                return p;

            // Prefix is bound to a different URI; reuse an existing prefix for this URI
            // or generate a new one.
            foreach (var (existingPrefix, existingUri) in declaredUris)
            {
                if (existingUri == nsUri)
                    return existingPrefix;
            }

            string newPrefix = GeneratePrefix();
            var newDeclAttr = new XAttribute(XNamespace.Xmlns + Xml11NameCodec.EncodeName(newPrefix), nsUri);
            if (impliedByAttributeName)
                newDeclAttr.AddAnnotation(new NonPropagatingNamespaceBinding());
            element.Add(newDeclAttr);
            declaredUris[newPrefix] = nsUri;
            declared.Add(newPrefix);
            return newPrefix;
        }

        // Tag: a conflicting name-implied prefix is replaced by a generated one.
        if (spec.Prefix is not null && contentNsDecls.TryGetValue(spec.Prefix, out var tagDeclUri)
            && tagDeclUri != (spec.NamespaceUri ?? string.Empty))
            Declare(GeneratePrefix(), spec.NamespaceUri);
        else
            Declare(spec.Prefix, spec.NamespaceUri);

        foreach (var attr in spec.Attributes)
        {
            if (attr.Prefix == "xmlns")
            {
                // xmlns:xml is redundant (the xml prefix is implicitly bound);
                // xmlns:xmlns is a reserved-namespace error (XQDY0074).
                if (attr.LocalName == "xmlns")
                    throw new InvalidOperationException("XQDY0074: The 'xmlns' prefix must not be declared.");
                if (attr.LocalName == "xml")
                    continue;
                // XQST0085: in XML 1.0 a prefixed namespace declaration must not bind to
                // the empty namespace URI (Constr-namespace-13/16). In XML 1.1 mode this is
                // a prefixed namespace undeclaration (XQST0085b): record it as an annotation
                // so the namespace axis and serialization hide the prefix in this subtree.
                if (attr.Value.Length == 0)
                {
                    if (!spec.Xml11Mode)
                        throw new InvalidOperationException($"XQST0085: The prefix '{attr.LocalName}' cannot be bound to the empty namespace name.");
                    var undecl = element.Annotation<PrefixedNamespaceUndeclarations>() ?? new PrefixedNamespaceUndeclarations();
                    if (!undecl.Prefixes.Contains(attr.LocalName))
                        undecl.Prefixes.Add(attr.LocalName);
                    if (!element.Annotations<PrefixedNamespaceUndeclarations>().Any())
                        element.AddAnnotation(undecl);
                    continue;
                }
                // XQST0070: no prefix may be bound to the XMLNS namespace URI.
                if (attr.Value == "http://www.w3.org/2000/xmlns/")
                    throw new InvalidOperationException($"XQST0070: The prefix '{attr.LocalName}' cannot be bound to the XMLNS namespace URI.");
                element.Add(new XAttribute(XNamespace.Xmlns + Xml11NameCodec.EncodeName(attr.LocalName), attr.Value));
            }
            else if (attr.LocalName == "xmlns" && attr.Prefix is null)
            {
                // XQST0070: the default namespace must not be the XML or XMLNS namespace
                // (K2-DirectConElem-36, defaultnamespacedeclerr-3/5/7).
                if (attr.Value is "http://www.w3.org/XML/1998/namespace" or "http://www.w3.org/2000/xmlns/")
                    throw new InvalidOperationException($"XQST0070: The default namespace must not be the reserved namespace '{attr.Value}'.");
                element.Add(new XAttribute("xmlns", attr.Value));
            }
            else
            {
                // Attribute name: a prefix redeclared by a content namespace declaration
                // with a different URI is replaced by a generated prefix (nscons-010).
                string? actualPrefix;
                if (attr.Prefix is not null && contentNsDecls.TryGetValue(attr.Prefix, out var attrDeclUri)
                    && attrDeclUri != (attr.NamespaceUri ?? string.Empty))
                    actualPrefix = Declare(GeneratePrefix(), attr.NamespaceUri, impliedByAttributeName: true);
                else
                    actualPrefix = Declare(attr.Prefix, attr.NamespaceUri, impliedByAttributeName: true);
                XNamespace ans = attr.NamespaceUri is null ? XNamespace.None : XNamespace.Get(attr.NamespaceUri);
                string encodedAttrLocalName = Xml11NameCodec.EncodeName(attr.LocalName);
                var newAttr = new XAttribute(ans + encodedAttrLocalName, attr.Value);
                if (!string.IsNullOrEmpty(actualPrefix))
                    newAttr.AddAnnotation(new AttributePrefixAnnotation(Xml11NameCodec.EncodeName(actualPrefix)));
                if (spec.ConstructionMode is { } mode)
                    XQueryConstructionMetadata.Attribute(attr.SourceNode, newAttr, mode);
                element.Add(newAttr);
            }
        }

        string? pendingText = null;
        void FlushText()
        {
            if (pendingText is not null)
            {
                element.Add(pendingText);
                pendingText = null;
            }
        }

        foreach (var item in spec.Content)
        {
            switch (item.Kind)
            {
                case XdmContentKind.Text:
                    pendingText = pendingText is null ? item.Text : pendingText + item.Text;
                    break;
                case XdmContentKind.Comment:
                    FlushText();
                    element.Add(new XComment(item.Text ?? string.Empty));
                    break;
                case XdmContentKind.ProcessingInstruction:
                    FlushText();
                    element.Add(new XProcessingInstruction(item.Target ?? string.Empty, item.Text ?? string.Empty));
                    break;
                case XdmContentKind.Namespace:
                    FlushText();
                    var nsDeclPrefix = item.Target ?? string.Empty;
                    var nsDeclUri = item.Text ?? string.Empty;
                    // xmlns:xml is redundant: the xml prefix is implicitly bound (nscons-004).
                    if (nsDeclPrefix == "xml")
                        break;
                    // Duplicate declarations with the same URI merge silently (nscons-005/006);
                    // different-URI redeclarations were already rejected by the runtime (XQDY0102).
                    if (nsDeclPrefix.Length == 0)
                    {
                        if (!declared.Contains("") && declaredUris.TryAdd("", nsDeclUri))
                        {
                            element.Add(new XAttribute("xmlns", nsDeclUri));
                            declared.Add("");
                        }
                    }
                    else if (!declared.Contains(nsDeclPrefix) && declaredUris.TryAdd(nsDeclPrefix, nsDeclUri))
                    {
                        element.Add(new XAttribute(XNamespace.Xmlns + Xml11NameCodec.EncodeName(nsDeclPrefix), nsDeclUri));
                        declared.Add(nsDeclPrefix);
                    }
                    break;
                default:
                    FlushText();
                    var childNode = CloneNode(item.Node!.Value, item.PreserveNamespaces, item.InheritNamespaces, item.ConstructionMode);
                    if (item.IsLiteralElement && childNode is XElement literalChild)
                        literalChild.AddAnnotation(new XQueryNamespaceCopyBoundary());
                    // XQuery strips document nodes used as element content and inserts their
                    // children instead (Constr-compelem-doc-1, K2-DirectConElem-42/43).
                    // The engine represents non-element-root document nodes with a synthetic
                    // __xdm_doc__ wrapper; unwrap it so only the real content is inserted.
                    // Text children are merged with the surrounding pending text so adjacent
                    // text nodes collapse (Constr-cont-document-1/2).
                    if (childNode is System.Xml.Linq.XDocument childDoc)
                    {
                        var docContent = (childDoc.Root?.Name.LocalName == "__xdm_doc__" && childDoc.Root.Name.NamespaceName == "")
                            ? childDoc.Root.Nodes()
                            : childDoc.Nodes();
                        foreach (var docChild in docContent.ToList())
                        {
                            switch (docChild)
                            {
                                case XText text:
                                    pendingText = pendingText is null ? text.Value : pendingText + text.Value;
                                    break;
                                case XElement childElement:
                                    FlushText();
                                    childElement.Remove();
                                    element.Add(childElement);
                                    break;
                                case XComment comment:
                                    FlushText();
                                    element.Add(comment);
                                    break;
                                case XProcessingInstruction pi:
                                    FlushText();
                                    element.Add(pi);
                                    break;
                            }
                        }
                        break;
                    }
                    // XQuery: a constructed child element keeps its own computed in-scope
                    // namespace bindings — they are not "redundant" with the parent's
                    // (K2-NameTest-30/31), so no namespace fixup is applied here.
                    element.Add(childNode);
                    break;
            }
        }
        FlushText();

        return XDocumentNode.Wrap(element);
    }

    private static XElement ParentlessOwner()
    {
        var owner = new XElement("__ns_owner__");
        owner.AddAnnotation(new ParentlessNamespaceNode());
        return owner;
    }

    /// <summary>
    /// Builds an XDocument-backed comment or processing-instruction node
    /// (the <c>Bosak.XPath.Runtime.Vm.EvaluationContext.ContentNodeConstructorHook</c>).
    /// </summary>
    /// <param name="item">The content item to construct.</param>
    /// <returns>The constructed node.</returns>
    public static IXdmNode ConstructContentNode(XdmContentItem item)
    {
        ArgumentNullException.ThrowIfNull(item);
        return item.Kind switch
        {
            XdmContentKind.Text => XDocumentNode.Wrap(new XText(item.Text ?? string.Empty)),
            XdmContentKind.Comment => XDocumentNode.Wrap(new XComment(item.Text ?? string.Empty)),
            XdmContentKind.ProcessingInstruction => XDocumentNode.Wrap(new XProcessingInstruction(item.Target ?? string.Empty, item.Text ?? string.Empty)),
            XdmContentKind.Namespace => XDocumentNode.CreateNamespaceNode(
                string.IsNullOrEmpty(item.Target)
                    ? new XAttribute("xmlns", item.Text ?? string.Empty)
                    : new XAttribute(XNamespace.Xmlns + item.Target, item.Text ?? string.Empty),
                // Computed namespace constructors create parentless nodes (nscons-012).
                ParentlessOwner()),
            _ => throw new ArgumentException($"ConstructContentNode does not handle kind '{item.Kind}'.", nameof(item))
        };
    }

    /// <summary>
    /// Removes namespace declarations from a child element that are identical to bindings
    /// already in scope at the parent (XML namespace fixup: redundant re-declarations are
    /// omitted from the output).
    /// </summary>
    private static void ApplyNamespaceFixup(XElement parent, XElement child)
    {
        var inScope = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (var ancestor in parent.AncestorsAndSelf())
        {
            foreach (var attr in ancestor.Attributes())
            {
                if (!attr.IsNamespaceDeclaration)
                    continue;
                string prefix = attr.Name.LocalName == "xmlns" ? string.Empty : attr.Name.LocalName;
                inScope.TryAdd(prefix, attr.Value);
            }
        }

        var redundant = child.Attributes()
            .Where(a => a.IsNamespaceDeclaration)
            .Where(a =>
            {
                string prefix = a.Name.LocalName == "xmlns" ? string.Empty : a.Name.LocalName;
                return inScope.TryGetValue(prefix, out var uri) && uri == a.Value;
            })
            .ToList();
        foreach (var attr in redundant)
            attr.Remove();
    }

    /// <summary>
    /// Builds an XDocument-backed free-standing attribute node for a computed attribute
    /// constructor (the <c>Bosak.XPath.Runtime.Vm.EvaluationContext.AttributeConstructorHook</c>).
    /// </summary>
    /// <param name="attribute">The computed attribute (name and value).</param>
    /// <returns>The constructed attribute node.</returns>
    public static IXdmNode ConstructAttribute(XdmAttributeValue attribute)
    {
        ArgumentNullException.ThrowIfNull(attribute);
        // XQDY0092: xml:space must be "default" or "preserve" (XQ 3.1 §3.9.2). Validate
        // here so the error is raised at construction time instead of surfacing as a
        // LINQ ArgumentException during serialization (K2-ComputeConAttr-60).
        if (attribute.NamespaceUri == "http://www.w3.org/XML/1998/namespace" && attribute.LocalName == "space" &&
            attribute.Value != "default" && attribute.Value != "preserve")
            throw new InvalidOperationException("XQDY0092: The value of xml:space must be 'default' or 'preserve'.");
        XNamespace ns = attribute.NamespaceUri is null ? XNamespace.None : XNamespace.Get(attribute.NamespaceUri);
        string encodedAttrLocalName = Xml11NameCodec.EncodeName(attribute.LocalName);
        var xattr = new XAttribute(ns + encodedAttrLocalName, attribute.Value);
        xattr.AddAnnotation(Xml11Annotation.Instance);
        // LINQ attributes cannot carry a prefix; record it as an annotation so the
        // free-standing attribute still reports its constructed prefix.
        if (!string.IsNullOrEmpty(attribute.Prefix))
            xattr.AddAnnotation(new AttributePrefixAnnotation(Xml11NameCodec.EncodeName(attribute.Prefix)));
        if (attribute.ConstructionMode is { } mode) XQueryConstructionMetadata.Attribute(attribute.SourceNode, xattr, mode);
        return XDocumentNode.Wrap(xattr);
    }

    /// <summary>
    /// Builds an XDocument-backed document node for a computed document constructor
    /// (the <c>Bosak.XPath.Runtime.Vm.EvaluationContext.DocumentConstructorHook</c>).
    /// </summary>
    /// <param name="content">The document content items.</param>
    /// <returns>The constructed document node.</returns>
    public static IXdmNode ConstructDocument(IReadOnlyList<XdmContentItem> content)
    {
        ArgumentNullException.ThrowIfNull(content);

        // LINQ documents allow a single root element; XDM document nodes allow any content.
        // Use the engine's synthetic document-root wrapper for anything else.
        bool singleElementRoot = content.Count == 1 && content[0].Kind == XdmContentKind.Node &&
            content[0].Node!.Value.NodeValue.NodeKind == XdmNodeKind.Element;
        var document = new System.Xml.Linq.XDocument();
        document.AddAnnotation(Xml11Annotation.Instance);
        XContainer container = document;
        if (!singleElementRoot)
        {
            var wrapper = new XElement("__xdm_doc__");
            document.Add(wrapper);
            container = wrapper;
        }

        string? pendingText = null;
        void FlushText()
        {
            if (pendingText is not null)
            {
                container.Add(pendingText);
                pendingText = null;
            }
        }

        foreach (var item in content)
        {
            switch (item.Kind)
            {
                case XdmContentKind.Text:
                    pendingText = pendingText is null ? item.Text : pendingText + item.Text;
                    break;
                case XdmContentKind.Comment:
                    FlushText();
                    container.Add(new XComment(item.Text ?? string.Empty));
                    break;
                case XdmContentKind.ProcessingInstruction:
                    FlushText();
                    container.Add(new XProcessingInstruction(item.Target ?? string.Empty, item.Text ?? string.Empty));
                    break;
                default:
                    FlushText();
                    var docChildNode = CloneNode(item.Node!.Value, item.PreserveNamespaces, item.InheritNamespaces, item.ConstructionMode);
                    // XQuery strips document nodes used as document content and inserts their
                    // children instead (prod-CompDocConstructor document-node tests).
                    if (docChildNode is System.Xml.Linq.XDocument childDoc)
                    {
                        var docChildren = (childDoc.Root?.Name.LocalName == "__xdm_doc__" && childDoc.Root.Name.NamespaceName == "")
                            ? childDoc.Root.Nodes()
                            : childDoc.Nodes();
                        foreach (var docChild in docChildren.ToList())
                        {
                            switch (docChild)
                            {
                                case XText text:
                                    pendingText = pendingText is null ? text.Value : pendingText + text.Value;
                                    break;
                                case XElement childElement:
                                    FlushText();
                                    childElement.Remove();
                                    container.Add(childElement);
                                    break;
                                case XComment comment:
                                    FlushText();
                                    container.Add(comment);
                                    break;
                                case XProcessingInstruction pi:
                                    FlushText();
                                    container.Add(pi);
                                    break;
                            }
                        }
                        break;
                    }
                    container.Add(docChildNode);
                    break;
            }
        }
        FlushText();
        return XDocumentNode.Wrap(document);
    }

    private static XNode CloneNode(XdmValue nodeValue, bool preserveNamespaces, bool inheritNamespaces, XdmConstructionMode? constructionMode)
    {
        var node = nodeValue.NodeValue;
        XNode clone;
        if (node is XDocumentNode xDocumentNode)
        {
            clone = xDocumentNode.UnderlyingObject switch
            {
                XElement element => CloneEncodedElement(element),
                System.Xml.Linq.XDocument document => CloneEncodedDocument(document),
                XText text => new XText(text.Value),
                XComment comment => new XComment(comment.Value),
                XProcessingInstruction pi => new XProcessingInstruction(pi.Target, pi.Data),
                XAttribute => throw new InvalidOperationException("FOTY0013: Cannot copy a free-standing attribute node."),
                _ => XElement.Parse(node.StringValue)
            };
        }
        else
        {
            // Non-XDocument providers: round-trip through the serialized form.
            clone = XElement.Parse(node.StringValue);
        }

        // A copied element carries the in-scope namespace declarations it needs
        // (prefixes used by its name, attribute names, and subtree).
        if (clone is XElement cloneElement && node is XDocumentNode sourceNode &&
            sourceNode.UnderlyingObject is XElement sourceElement)
        {
            CopyInScopeNamespaces(sourceElement, cloneElement);
            bool defaultAbsent = true;
            foreach (var ns in XDocumentNode.Wrap(sourceElement).Axis(XdmAxis.Namespace))
                if (ns.NodeValue.LocalName.Length == 0) { defaultAbsent = false; break; }
            if (preserveNamespaces && defaultAbsent)
            {
                cloneElement.Attribute("xmlns")?.Remove();
                cloneElement.AddAnnotation(new XQueryDefaultNamespaceAbsence());
            }
            // Preserve annotation-based semantics: the namespace inheritance barrier,
            // prefixed namespace undeclarations, and the base-URI annotation.
            foreach (var annotation in sourceElement.Annotations<object>())
                if (annotation is not Xml11Annotation && annotation is not OriginalPrefixAnnotation)
                    cloneElement.AddAnnotation(annotation);
        }
        if (clone is XElement copied && node is XDocumentNode original && original.UnderlyingObject is XElement source)
        {
            copied.RemoveAnnotations<XQueryNamespaceCopyBoundary>();
            if (!preserveNamespaces || !inheritNamespaces)
                ApplyNamespaceCopyMode(source, copied, preserveNamespaces, inheritNamespaces);
        }
        else if (clone is XDocument copiedDocument && node is XDocumentNode originalDocument &&
                 originalDocument.UnderlyingObject is XDocument sourceDocument && sourceDocument.Root is { } sourceRoot && copiedDocument.Root is { } copiedRoot &&
                 (!preserveNamespaces || !inheritNamespaces))
            ApplyNamespaceCopyMode(sourceRoot, copiedRoot, preserveNamespaces, inheritNamespaces);
        if (constructionMode is { } mode)
            XQueryConstructionMetadata.ApplyTree((node as XDocumentNode)?.UnderlyingObject as XObject, clone, mode, preserveNamespaces);
        return clone;
    }

    private static void ApplyNamespaceCopyMode(XElement source, XElement copy, bool preserve, bool inherit)
    {
        foreach (var pair in source.DescendantsAndSelf().Zip(copy.DescendantsAndSelf()))
        {
            var bindings = new Dictionary<string, string>(StringComparer.Ordinal);
            if (preserve)
            {
                foreach (var value in XDocumentNode.Wrap(pair.First).Axis(XdmAxis.Namespace))
                    bindings[value.NodeValue.LocalName] = value.NodeValue.StringValue;
                // Absence of a default namespace is itself a namespace binding.
                bindings.TryAdd(string.Empty, string.Empty);
            }
            else
            {
                var element = XDocumentNode.Wrap(pair.First);
                bindings[element.Prefix ?? string.Empty] = element.NamespaceUri;
                foreach (var attribute in pair.First.Attributes().Where(a => !a.IsNamespaceDeclaration && a.Name.NamespaceName.Length != 0))
                {
                    var node = XDocumentNode.Wrap(attribute);
                    string prefix = node.Prefix ?? string.Empty;
                    if (prefix.Length == 0) prefix = "ns" + bindings.Count;
                    bindings[prefix] = node.NamespaceUri;
                }
                pair.Second.Attributes().Where(a => a.IsNamespaceDeclaration).Remove();
            }
            pair.Second.RemoveAnnotations<XQueryDefaultNamespaceAbsence>();
            foreach (var (prefix, uri) in bindings)
            {
                if (prefix is "xml" or "xmlns") continue;
                if (prefix.Length == 0 && uri.Length == 0)
                {
                    pair.Second.Attribute("xmlns")?.Remove();
                    pair.Second.AddAnnotation(new XQueryDefaultNamespaceAbsence());
                    continue;
                }
                XName name = prefix.Length == 0 ? XName.Get("xmlns") : XNamespace.Xmlns + Xml11NameCodec.EncodeName(prefix);
                pair.Second.SetAttributeValue(name, uri);
            }
            pair.Second.RemoveAnnotations<XQueryNamespaceCopyBoundary>();
            if (!inherit) pair.Second.AddAnnotation(new XQueryNamespaceCopyBoundary());
        }
    }

    /// <summary>Copies a tree into the provider's reversible encoded-name representation.</summary>
    internal static XElement CloneEncodedElement(XElement source)
    {
        var clone = new XElement(source);
        foreach (var pair in source.DescendantsAndSelf().Zip(clone.DescendantsAndSelf()))
        {
            bool encoded = XDocumentNode.Wrap(pair.First).UsesEncodedNames;
            if (pair.First.Annotation<XQueryNamespaceCopyBoundary>() is not null)
                pair.Second.AddAnnotation(new XQueryNamespaceCopyBoundary());
            if (pair.First.Annotation<XQueryDefaultNamespaceAbsence>() is not null)
                pair.Second.AddAnnotation(new XQueryDefaultNamespaceAbsence());
            if (!encoded)
                pair.Second.Name = XName.Get(Xml11NameCodec.EncodeName(pair.First.Name.LocalName), pair.First.Name.NamespaceName);
            if (pair.First.Annotation<OriginalPrefixAnnotation>() is { } original)
                pair.Second.AddAnnotation(new OriginalPrefixAnnotation { Prefix = encoded ? original.Prefix : Xml11NameCodec.EncodeName(original.Prefix) });
            pair.Second.RemoveAttributes();
            foreach (var attribute in pair.First.Attributes())
            {
                string local = encoded ? attribute.Name.LocalName : Xml11NameCodec.EncodeName(attribute.Name.LocalName);
                var target = new XAttribute(XName.Get(local, attribute.Name.NamespaceName), attribute.Value);
                pair.Second.Add(target);
                if (attribute.Annotation<NonPropagatingNamespaceBinding>() is not null)
                    target.AddAnnotation(new NonPropagatingNamespaceBinding());
                if (attribute.Annotation<AttributePrefixAnnotation>() is { } prefix)
                    target.AddAnnotation(new AttributePrefixAnnotation(encoded ? prefix.Prefix : Xml11NameCodec.EncodeName(prefix.Prefix)));
            }
        }
        clone.AddAnnotation(Xml11Annotation.Instance);
        return clone;
    }

    private static XDocument CloneEncodedDocument(XDocument source)
    {
        var clone = new XDocument(source);
        if (source.Root is { } root)
            clone.Root!.ReplaceWith(CloneEncodedElement(root));
        clone.AddAnnotation(Xml11Annotation.Instance);
        return clone;
    }

    private static void CopyInScopeNamespaces(XElement source, XElement clone)
    {
        // Declarations in scope at the source element (own + inherited) are part of the copy.
        var declared = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (var ancestor in source.AncestorsAndSelf())
        {
            foreach (var attr in ancestor.Attributes())
            {
                if (!attr.IsNamespaceDeclaration)
                    continue;
                string prefix = attr.Name.LocalName == "xmlns" ? string.Empty : attr.Name.LocalName;
                declared.TryAdd(XDocumentNode.Wrap(ancestor).UsesEncodedNames ? prefix : Xml11NameCodec.EncodeName(prefix), attr.Value);
            }
            if (ancestor.Annotation<XQueryNamespaceCopyBoundary>() is not null) break;
        }

        var declaredOnClone = new HashSet<string>(
            clone.Attributes().Where(a => a.IsNamespaceDeclaration)
                .Select(a => a.Name.LocalName == "xmlns" ? string.Empty : a.Name.LocalName),
            StringComparer.Ordinal);
        foreach (var (prefix, uri) in declared)
        {
            if (declaredOnClone.Contains(prefix))
                continue;
            if (prefix.Length == 0)
                clone.Add(new XAttribute("xmlns", uri));
            else if (prefix is not ("xml" or "xmlns"))
                clone.Add(new XAttribute(XNamespace.Xmlns + prefix, uri));
        }
    }

    /// <summary>
    /// Parses an XML string and returns the root as an <see cref="IXdmNode"/>.
    /// XML 1.1 declarations are accepted by encoding name characters that .NET rejects.
    /// </summary>
    /// <param name="xml">The XML text to parse.</param>
    /// <returns>The parsed document node.</returns>
    public static IXdmNode ParseXml(string xml)
    {
        var document = Xml11Loader.Parse(xml, LoadOptions.PreserveWhitespace);
        var map = ComputeDocumentOrder(document);
        XDocumentNode.RegisterOrderMap(document, map);
        return XDocumentNode.Wrap(document);
    }

    /// <summary>
    /// Parses an XML string that is known to be XML 1.1 and returns the root as an <see cref="IXdmNode"/>.
    /// </summary>
    /// <param name="xml">The XML 1.1 text to parse.</param>
    /// <param name="baseUri">An optional base URI recorded on the parsed nodes.</param>
    /// <returns>The parsed document node.</returns>
    public static IXdmNode ParseXml11(string xml, string? baseUri = null)
    {
        var document = Xml11Loader.ParseXml11(xml, LoadOptions.PreserveWhitespace, baseUri);
        var map = ComputeDocumentOrder(document);
        XDocumentNode.RegisterOrderMap(document, map);
        return XDocumentNode.Wrap(document);
    }

    /// <summary>
    /// Loads an XML file and returns the root as an <see cref="IXdmNode"/>.
    /// The file path is preserved as the document's base URI.
    /// XML 1.1 declarations are accepted by encoding name characters that .NET rejects.
    /// </summary>
    /// <param name="filePath">The path or file URI of the document to load.</param>
    /// <returns>The loaded document node.</returns>
    public static IXdmNode LoadFile(string filePath)
        => LoadFile(filePath, baseUri: null);

    /// <summary>
    /// Loads an XML file and returns the root as an <see cref="IXdmNode"/>.
    /// When <paramref name="baseUri"/> is supplied, it is used as the document's base URI
    /// instead of the file path. This is used by test harnesses that publish a source
    /// document under a different URI than its local file location.
    /// XML 1.1 declarations are accepted by encoding name characters that .NET rejects.
    /// </summary>
    /// <param name="filePath">The path or file URI of the document to load.</param>
    /// <param name="baseUri">An optional published URI to use as the document's base URI.</param>
    /// <returns>The loaded document node.</returns>
    public static IXdmNode LoadFile(string filePath, string? baseUri)
    {
        var document = Xml11Loader.Load(filePath, LoadOptions.SetBaseUri | LoadOptions.PreserveWhitespace);
        StripDocumentLevelWhitespace(document);
        if (!string.IsNullOrEmpty(baseUri))
        {
            // Reparse with the published URI so element BaseUri values reflect it;
            // XML 1.1 namespace-undeclaration annotations do not survive ToString(),
            // so they are transferred explicitly.
            var originals = document.Descendants().ToList();
            document = Xml11Loader.Parse(document.ToString(),
                LoadOptions.SetBaseUri | LoadOptions.PreserveWhitespace, baseUri);
            StripDocumentLevelWhitespace(document);
            var reparsed = document.Descendants().ToList();
            for (int i = 0; i < originals.Count; i++)
            {
                if (originals[i].Annotation<PrefixedNamespaceUndeclarations>() is { } undeclarations)
                    reparsed[i].AddAnnotation(undeclarations);
            }
        }
        var map = ComputeDocumentOrder(document);
        XDocumentNode.RegisterOrderMap(document, map);
        var node = XDocumentNode.Wrap(document);
        // Relative paths must be absolutized first: new Uri(relativePath) throws UriFormatException.
        var absolutePath = Uri.IsWellFormedUriString(filePath, UriKind.Absolute)
            ? filePath
            : Path.GetFullPath(filePath);
        node.SetDocumentUri(new Uri(absolutePath).AbsoluteUri);
        return node;
    }

    /// <summary>
    /// Loads XML from host-approved bytes under the controlled resource profile (REQ-125 Slice B).
    /// DTD processing is prohibited and no external resolver is consulted, so the DTD/entity
    /// policy applies to the approved content exactly as it does to a controlled disk load;
    /// the approved bytes are authoritative and are never re-resolved against their URI.
    /// Whitespace handling, document-order registration and the document URI follow
    /// <see cref="LoadFile(string, string?)"/>.
    /// </summary>
    /// <param name="bytes">The approved XML bytes.</param>
    /// <param name="baseUri">The effective URI the bytes correspond to (used as base and document URI).</param>
    /// <returns>The loaded document node.</returns>
    public static IXdmNode LoadControlled(byte[] bytes, string? baseUri)
    {
        var settings = new XmlReaderSettings
        {
            DtdProcessing = DtdProcessing.Prohibit,
            XmlResolver = null,
            IgnoreWhitespace = false,
        };
        XDocument document;
        using (var stream = new MemoryStream(bytes, writable: false))
        using (var reader = XmlReader.Create(stream, settings, baseUri ?? string.Empty))
        {
            document = XDocument.Load(reader, LoadOptions.SetBaseUri | LoadOptions.PreserveWhitespace);
        }
        StripDocumentLevelWhitespace(document);
        var map = ComputeDocumentOrder(document);
        XDocumentNode.RegisterOrderMap(document, map);
        var node = XDocumentNode.Wrap(document);
        if (!string.IsNullOrEmpty(baseUri))
            node.SetDocumentUri(baseUri);
        return node;
    }

    /// <summary>
    /// Loads an XML file, optionally validates it against the supplied XML Schema set,
    /// and returns the root as an <see cref="IXdmNode"/>.
    /// When <paramref name="baseUri"/> is supplied, it is used as the document's base URI
    /// instead of the file path. PSVI annotations are added to the tree so that
    /// <see cref="XDocumentNode.IsId"/> reflects the schema types.
    /// </summary>
    /// <param name="filePath">The path or file URI of the document to load.</param>
    /// <param name="baseUri">An optional published URI to use as the document's base URI.</param>
    /// <param name="schemaSet">An optional compiled schema set to validate against.</param>
    /// <returns>The loaded (and optionally validated) document node.</returns>
    /// <exception cref="XmlSchemaValidationException">Validation against <paramref name="schemaSet"/> produces errors.</exception>
    public static IXdmNode LoadFile(string filePath, string? baseUri, XmlSchemaSet? schemaSet)
    {
        var document = Xml11Loader.Load(filePath, LoadOptions.SetBaseUri | LoadOptions.PreserveWhitespace);
        StripDocumentLevelWhitespace(document);
        if (!string.IsNullOrEmpty(baseUri))
        {
            // See LoadFile(filePath, baseUri): preserve XML 1.1 undeclaration annotations
            // across the reparse for the published base URI.
            var originals = document.Descendants().ToList();
            document = Xml11Loader.Parse(document.ToString(),
                LoadOptions.SetBaseUri | LoadOptions.PreserveWhitespace, baseUri);
            StripDocumentLevelWhitespace(document);
            var reparsed = document.Descendants().ToList();
            for (int i = 0; i < originals.Count; i++)
            {
                if (originals[i].Annotation<PrefixedNamespaceUndeclarations>() is { } undeclarations)
                    reparsed[i].AddAnnotation(undeclarations);
            }
        }
        if (schemaSet is not null)
        {
            ValidateDocument(document, schemaSet);
        }
        var map = ComputeDocumentOrder(document);
        XDocumentNode.RegisterOrderMap(document, map);
        var node = XDocumentNode.Wrap(document);
        var absolutePath = Uri.IsWellFormedUriString(filePath, UriKind.Absolute)
            ? filePath
            : Path.GetFullPath(filePath);
        node.SetDocumentUri(new Uri(absolutePath).AbsoluteUri);
        return node;
    }

    private static void ValidateDocument(XDocument document, XmlSchemaSet schemaSet)
    {
        var errors = new List<string>();
        document.Validate(schemaSet, (sender, e) =>
        {
            if (e.Severity == XmlSeverityType.Error)
                errors.Add(e.Message);
        }, addSchemaInfo: true);
        if (errors.Count > 0)
        {
            throw new XmlSchemaValidationException(
                $"Document validation failed against the supplied schema(s):\n{string.Join("\n", errors)}");
        }
        StripElementOnlyContentWhitespace(document);
        // Validating XDM construction records the schema-normalized value for simple-typed
        // content (XDM §3.3.2); apply the governing type's whiteSpace facet.
        if (document.Root is not null)
            XdmSchemaAnnotator.ApplySchemaNormalizedValues(document.Root);
    }

    /// <summary>
    /// Validates an in-memory <see cref="XDocument"/> against the supplied XML Schema set
    /// and attaches PSVI annotations (<see cref="System.Xml.Schema.Extensions.GetSchemaInfo(XElement)"/>) to every
    /// node. On success, whitespace-only text nodes inside element-only schema content are
    /// stripped to match XDM validating construction rules. On failure, a
    /// <see cref="XmlSchemaValidationException"/> is thrown.
    /// </summary>
    /// <param name="document">The document to validate. It is modified in place.</param>
    /// <param name="schemaSet">The compiled schema set to validate against.</param>
    /// <exception cref="ArgumentNullException">If <paramref name="document"/> or <paramref name="schemaSet"/> is null.</exception>
    /// <exception cref="XmlSchemaValidationException">If validation produces any errors.</exception>
    public static void ValidateXDocument(XDocument document, XmlSchemaSet schemaSet)
    {
        if (document is null) throw new ArgumentNullException(nameof(document));
        if (schemaSet is null) throw new ArgumentNullException(nameof(schemaSet));
        ValidateDocument(document, schemaSet);
    }

    /// <summary>
    /// Removes whitespace-only text nodes from elements whose validated schema type has
    /// element-only content. A validating XDM construction discards such whitespace
    /// (XDM §3.3.1.1), so strictly validated source documents match the whitespace-free
    /// trees the QT3 expectations assume (ForExprType009, orderData.xml).
    /// </summary>
    private static void StripElementOnlyContentWhitespace(XDocument document)
    {
        foreach (var element in document.Descendants())
        {
            if (element.GetSchemaInfo()?.SchemaElement?.ElementSchemaType is not XmlSchemaComplexType complexType
                || complexType.ContentType != XmlSchemaContentType.ElementOnly)
                continue;
            foreach (var text in element.Nodes().OfType<XText>()
                         .Where(t => string.IsNullOrWhiteSpace(t.Value))
                         .ToList())
            {
                text.Remove();
            }
        }
    }

    /// <summary>
    /// Removes whitespace-only text nodes that are direct children of the document node.
    /// XPath/XQuery processors typically preserve whitespace inside elements but strip
    /// insignificant whitespace before/after the root element.
    /// </summary>
    /// <param name="doc">The document to strip; it is modified in place.</param>
    public static void StripDocumentLevelWhitespace(System.Xml.Linq.XDocument doc)
    {
        var toRemove = doc.Nodes()
            .OfType<System.Xml.Linq.XText>()
            .Where(t => string.IsNullOrWhiteSpace(t.Value))
            .ToList();
        foreach (var node in toRemove)
            node.Remove();
    }

    // ------------------------------------------------------------------
    // Document order indexing
    // ------------------------------------------------------------------

    private static Dictionary<XObject, long> ComputeDocumentOrder(System.Xml.Linq.XDocument doc)
    {
        var map = new Dictionary<XObject, long>();
        long index = 0;

        map[doc] = index++;
        Traverse(doc, ref index, map);

        return map;
    }

    private static void Traverse(XContainer container, ref long index, Dictionary<XObject, long> map)
    {
        foreach (var node in container.Nodes())
        {
            map[node] = index++;

            if (node is XElement el)
            {
                foreach (var attr in el.Attributes())
                    map[attr] = index++;

                Traverse(el, ref index, map);
            }
        }
    }
}

/// <summary>Stops namespace-axis inheritance above a copied XQuery element.</summary>
internal sealed class XQueryNamespaceCopyBoundary { }

/// <summary>Preserves an absent default namespace without adding redundant serialized declarations.</summary>
internal sealed class XQueryDefaultNamespaceAbsence { }
