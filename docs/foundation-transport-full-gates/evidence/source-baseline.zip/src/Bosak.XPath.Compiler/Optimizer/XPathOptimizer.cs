// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 19 mei 2026
// PURPOSE              : Performs bottom-up optimizations on the XPath AST before lowering to IR
// SPECIAL NOTES        : Part of the AST-to-IR compilation pipeline.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 19-05-2026     | Creation                                                                                 |
//                      | Charles Korthout | 0.2   | 19-05-2026     | Added OptimizeLookupWildcard                                                           |
//                      | Charles Korthout | 0.3   | 21-05-2026     | Integer div constant fold produces DecimalLiteralNode (XPath div semantics)            |
//                      | Charles Korthout | 0.4   | 26-06-2026     | Backwards-compatible mode promotes integer arithmetic folding to xs:double            |
//                      | Charles Korthout | 0.5   | 07-07-2026     | Preserve negative-zero unary minus in BC mode; fixes xpath-compat-0101               |
//                      | Charles Korthout | 0.6   | 15-07-2026     | Preserve PositionalVariableName when rebuilding QuantifiedBinding (FLWOR 'at $pos')     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.7   | 15-07-2026     | Preserve VariablePrefix/VariableNamespaceUri when rebuilding QuantifiedBinding          |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.8   | 19-07-2026     | Only fold unary plus for numeric literals; non-literals need runtime type check         |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.9   | 21-07-2026     | Skip decimal constant folding on OverflowException; let runtime raise FOAR0002        |
//                      | Charles Korthout | 1.0   | 22-07-2026     | Optimize FlworExpressionNode and all clause types (XQuery order by)                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.1   | 23-07-2026     | Optimize CountClauseNode (XQuery count)                                                 |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.2   | 25-07-2026     | Optimize GroupByClauseNode (XQuery group by)                                            |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.3   | 25-07-2026     | Optimize WindowClauseNode (XQuery window)                                               |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.4   | 25-07-2026     | Optional window end condition                                                           |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.5   | 25-07-2026     | Optimize DirectElementConstructorNode                                                   |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.6   | 25-07-2026     | Optimize computed constructor nodes                                                     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.7   | 25-07-2026     | Optimize switch/typeswitch nodes (reference-transparent rebuilds)                       |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.8   | 27-07-2026     | Reference-transparent traversal for StringConstructorNode |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.9   | 22-08-2026     | Optimize ValidateExpressionNode |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.10  | 09-09-2026     | XML doc coverage on public API (Beta review)                                             |
//                      | Charles Korthout | 1.11  | 21-09-2026     | API freeze stage A: internalized (IVT for in-repo consumers)                           |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.12  | 08-10-2026     | REQ-118 4.0-S3b: reference-transparent traversal for StringTemplateNode                |
//                      |==================|=======|================|=========================================================================================
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.13  | 08-10-2026     | REQ-118 4.0-S4: OptimizePipeline for PipelineExprNode ('->')
//                      | Charles Korthout | 1.14  | 24-10-2026     | Check integer folding overflow and retain decimal-backed integer literal type.            |
//                      | Charles Korthout | 1.15  | 25-10-2026     | Avoid unary minimum-value wraparound and retain wide integer literal identity.             |
//                      | Charles Korthout | 1.16  | 25-10-2026     | Preserve atomization, conversion and errors across repeated unary negation.                 |
//                      | Charles Korthout | 1.17  | 28-10-2026     | Implement statically validated ignored-pragma fallback and raw scanning (1.33.0). |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using Bosak.XPath.Parser.Ast;
using Bosak.XPath.Core.Xdm;

namespace Bosak.XPath.Compiler.Optimizer;

/// <summary>
/// Performs bottom-up optimizations on the XPath AST before lowering to IR.
/// </summary>
internal sealed class XPathOptimizer
{
    private bool _backwardsCompatible;

    /// <summary>
    /// Optimizes an AST node. Runs multiple passes until no further changes are made.
    /// </summary>
    /// <param name="node">The root of the AST to optimize.</param>
    /// <returns>The optimized AST; the original node when no optimization applies.</returns>
    public XPathAstNode Optimize(XPathAstNode node)
        => Optimize(node, backwardsCompatible: false);

    /// <summary>
    /// Optimizes an AST node, optionally applying XPath 1.0 backwards-compatible
    /// constant-folding rules.
    /// </summary>
    /// <param name="node">The root of the AST to optimize.</param>
    /// <param name="backwardsCompatible">When true, constant folding follows XPath 1.0
    /// backwards-compatible rules (integer arithmetic folds to xs:double).</param>
    /// <returns>The optimized AST; the original node when no optimization applies.</returns>
    public XPathAstNode Optimize(XPathAstNode node, bool backwardsCompatible)
    {
        _backwardsCompatible = backwardsCompatible;
        bool changed;
        do
        {
            changed = false;
            node = OptimizeNode(node, ref changed);
        } while (changed);
        return node;
    }

    private XPathAstNode OptimizeNode(XPathAstNode node, ref bool changed)
    {
        return node switch
        {
            BinaryExpressionNode bin => OptimizeBinary(bin, ref changed),
            UnaryExpressionNode unary => OptimizeUnary(unary, ref changed),
            IfExpressionNode ifExpr => OptimizeIf(ifExpr, ref changed),
            SequenceExpressionNode seq => OptimizeSequence(seq, ref changed),
            RangeExpressionNode range => OptimizeRange(range, ref changed),
            PathExprNode path => OptimizePath(path, ref changed),
            StepNode step => OptimizeStep(step, ref changed),
            PostfixPredicateNode postfix => OptimizePostfix(postfix, ref changed),
            ParenthesizedExprNode paren => OptimizeParen(paren, ref changed),
            ForExpressionNode forExpr => OptimizeFor(forExpr, ref changed),
            QuantifiedExpressionNode quant => OptimizeQuantified(quant, ref changed),
            ArrowExprNode arrow => OptimizeArrow(arrow, ref changed),
            PipelineExprNode pipeline => OptimizePipeline(pipeline, ref changed),
            LookupNode lookup => OptimizeLookup(lookup, ref changed),
            LookupWildcardNode lookup => OptimizeLookupWildcard(lookup, ref changed),
            CastNode cast => OptimizeCast(cast, ref changed),
            CastableNode castable => OptimizeCastable(castable, ref changed),
            InstanceOfNode inst => OptimizeInstanceOf(inst, ref changed),
            TreatNode treat => OptimizeTreat(treat, ref changed),
            MapConstructorNode map => OptimizeMap(map, ref changed),
            ArrayConstructorNode arr => OptimizeArray(arr, ref changed),
            InlineFunctionNode inline => OptimizeInline(inline, ref changed),
            DirectElementConstructorNode element => OptimizeDirectElementConstructor(element, ref changed),
            ComputedElementConstructorNode n => OptimizeComputedConstructor(n, ref changed),
            ComputedAttributeConstructorNode n => OptimizeComputedConstructor(n, ref changed),
            ComputedDocumentConstructorNode n => OptimizeComputedConstructor(n, ref changed),
            ComputedTextConstructorNode n => OptimizeComputedConstructor(n, ref changed),
            ComputedCommentConstructorNode n => OptimizeComputedConstructor(n, ref changed),
            ComputedPIConstructorNode n => OptimizeComputedConstructor(n, ref changed),
            ComputedNamespaceConstructorNode n => OptimizeComputedConstructor(n, ref changed),
            SwitchExpressionNode n => OptimizeSwitch(n, ref changed),
            TypeswitchExpressionNode n => OptimizeTypeswitch(n, ref changed),
            FunctionCallNode call => OptimizeFunctionCall(call, ref changed),
            LetExpressionNode let => OptimizeLet(let, ref changed),
            DynamicFunctionCallNode dyn => OptimizeDynamicFunctionCall(dyn, ref changed),
            FlworExpressionNode flwor => OptimizeFlwor(flwor, ref changed),
            StringConstructorNode n => OptimizeStringConstructor(n, ref changed),
            StringTemplateNode n => OptimizeStringTemplate(n, ref changed),
            ValidateExpressionNode n => OptimizeValidate(n, ref changed),
            ExtensionExpressionNode n => OptimizeIgnoredExtension(n, ref changed),
            _ => node
        };
    }

    private XPathAstNode OptimizeStringConstructor(StringConstructorNode node, ref bool changed)
    {
        var parts = OptimizeParts(node.Parts, ref changed);
        return parts is null ? node : node with { Parts = parts };
    }

    private XPathAstNode OptimizeStringTemplate(StringTemplateNode node, ref bool changed)
    {
        var parts = OptimizeParts(node.Parts, ref changed);
        return parts is null ? node : node with { Parts = parts };
    }

    // Optimizes literal/interpolation parts shared by string constructors and string
    // templates. Returns the new part list, or null when nothing changed.
    private List<XPathAstNode>? OptimizeParts(IReadOnlyList<XPathAstNode> nodeParts, ref bool changed)
    {
        var parts = new List<XPathAstNode>(nodeParts.Count);
        bool anyChanged = false;
        foreach (var part in nodeParts)
        {
            var optPart = OptimizeNode(part, ref changed);
            parts.Add(optPart);
            if (optPart != part) anyChanged = true;
        }
        return anyChanged ? parts : null;
    }

    private XPathAstNode OptimizeIgnoredExtension(ExtensionExpressionNode node, ref bool changed)
    {
        // No pragma namespaces are recognized. Static validation precedes optimization.
        changed = true;
        return OptimizeNode(node.Expression, ref changed);
    }

    private XPathAstNode OptimizeValidate(ValidateExpressionNode node, ref bool changed)
    {
        var optExpr = OptimizeNode(node.Expression, ref changed);
        if (optExpr == node.Expression)
            return node;
        changed = true;
        return node with { Expression = optExpr };
    }

    private XPathAstNode OptimizeComputedConstructor(XPathAstNode node, ref bool changed)
    {
        return node switch
        {
            ComputedElementConstructorNode n => n with
            {
                NameExpression = n.NameExpression is null ? null : OptimizeNode(n.NameExpression, ref changed),
                ContentExpression = OptimizeNode(n.ContentExpression, ref changed)
            },
            ComputedAttributeConstructorNode n => n with
            {
                NameExpression = n.NameExpression is null ? null : OptimizeNode(n.NameExpression, ref changed),
                ValueExpression = OptimizeNode(n.ValueExpression, ref changed)
            },
            ComputedDocumentConstructorNode n => n with { ContentExpression = OptimizeNode(n.ContentExpression, ref changed) },
            ComputedTextConstructorNode n => n with { ValueExpression = OptimizeNode(n.ValueExpression, ref changed) },
            ComputedCommentConstructorNode n => n with { ValueExpression = OptimizeNode(n.ValueExpression, ref changed) },
            ComputedPIConstructorNode n => n with
            {
                TargetExpression = n.TargetExpression is null ? null : OptimizeNode(n.TargetExpression, ref changed),
                ValueExpression = OptimizeNode(n.ValueExpression, ref changed)
            },
            ComputedNamespaceConstructorNode n => n with
            {
                PrefixExpression = n.PrefixExpression is null ? null : OptimizeNode(n.PrefixExpression, ref changed),
                UriExpression = OptimizeNode(n.UriExpression, ref changed)
            },
            _ => node
        };
    }

    private SwitchExpressionNode OptimizeSwitch(SwitchExpressionNode node, ref bool changed)
    {
        var operand = OptimizeNode(node.Operand, ref changed);
        bool anyChanged = operand != node.Operand;
        var cases = new List<SwitchCaseClause>(node.Cases.Count);
        foreach (var clause in node.Cases)
        {
            var values = new List<XPathAstNode>(clause.Values.Count);
            bool valuesChanged = false;
            foreach (var value in clause.Values)
            {
                var optValue = OptimizeNode(value, ref changed);
                values.Add(optValue);
                if (optValue != value) valuesChanged = true;
            }
            var optReturn = OptimizeNode(clause.Return, ref changed);
            if (valuesChanged || optReturn != clause.Return)
            {
                anyChanged = true;
                cases.Add(clause with { Values = values, Return = optReturn });
            }
            else
            {
                cases.Add(clause);
            }
        }
        var optDefault = OptimizeNode(node.Default, ref changed);
        if (!anyChanged && optDefault == node.Default)
            return node;
        changed = true;
        return node with { Operand = operand, Cases = cases, Default = optDefault };
    }

    private TypeswitchExpressionNode OptimizeTypeswitch(TypeswitchExpressionNode node, ref bool changed)
    {
        var operand = OptimizeNode(node.Operand, ref changed);
        bool anyChanged = operand != node.Operand;
        var cases = new List<TypeswitchCaseClause>(node.Cases.Count);
        foreach (var clause in node.Cases)
        {
            var optReturn = OptimizeNode(clause.Return, ref changed);
            if (optReturn != clause.Return)
            {
                anyChanged = true;
                cases.Add(clause with { Return = optReturn });
            }
            else
            {
                cases.Add(clause);
            }
        }
        var optDefault = OptimizeNode(node.Default, ref changed);
        if (!anyChanged && optDefault == node.Default)
            return node;
        changed = true;
        return node with { Operand = operand, Cases = cases, Default = optDefault };
    }

    private DirectElementConstructorNode OptimizeDirectElementConstructor(DirectElementConstructorNode node, ref bool changed)
    {
        var attributes = new List<DirectAttributeNode>(node.Attributes.Count);
        bool attrsChanged = false;
        foreach (var attr in node.Attributes)
        {
            var parts = new List<XPathAstNode>(attr.ValueParts.Count);
            foreach (var part in attr.ValueParts)
            {
                var optimized = OptimizeNode(part, ref changed);
                parts.Add(optimized);
                if (optimized != part) attrsChanged = true;
            }
            attributes.Add(attrsChanged ? attr with { ValueParts = parts } : attr);
        }
        var content = new List<XPathAstNode>(node.Content.Count);
        bool contentChanged = false;
        foreach (var part in node.Content)
        {
            var optimized = OptimizeNode(part, ref changed);
            content.Add(optimized);
            if (optimized != part) contentChanged = true;
        }
        if (!attrsChanged && !contentChanged)
            return node;
        return node with { Attributes = attributes, Content = content };
    }

    // ------------------------------------------------------------------
    // Binary expressions
    // ------------------------------------------------------------------

    private XPathAstNode OptimizeBinary(BinaryExpressionNode node, ref bool changed)
    {
        var left = OptimizeNode(node.Left, ref changed);
        var right = OptimizeNode(node.Right, ref changed);

        if (left != node.Left || right != node.Right)
        {
            changed = true;
            node = node with { Left = left, Right = right };
        }

        // Constant folding (arithmetic operations may throw at compile time,
        // e.g. division by zero; skip folding in that case and let runtime handle it)
        if (left is IntegerLiteralNode li && right is IntegerLiteralNode ri)
        {
            try
            {
                XPathAstNode? result = node.Operator switch
                {
                    BinaryOperator.Plus => _backwardsCompatible
                        ? new DoubleLiteralNode((double)li.Value + (double)ri.Value)
                        : new IntegerLiteralNode(checked(li.Value + ri.Value)),
                    BinaryOperator.Minus => _backwardsCompatible
                        ? new DoubleLiteralNode((double)li.Value - (double)ri.Value)
                        : new IntegerLiteralNode(checked(li.Value - ri.Value)),
                    BinaryOperator.Multiply => _backwardsCompatible
                        ? new DoubleLiteralNode((double)li.Value * (double)ri.Value)
                        : new IntegerLiteralNode(checked(li.Value * ri.Value)),
                    BinaryOperator.Divide => _backwardsCompatible
                        ? new DoubleLiteralNode((double)li.Value / (double)ri.Value)
                        : new DecimalLiteralNode((decimal)li.Value / (decimal)ri.Value),
                    BinaryOperator.Idiv => _backwardsCompatible
                        ? new DoubleLiteralNode((double)(li.Value / ri.Value))
                        : new IntegerLiteralNode(li.Value / ri.Value),
                    BinaryOperator.Mod => _backwardsCompatible
                        ? new DoubleLiteralNode((double)li.Value % (double)ri.Value)
                        : new IntegerLiteralNode(li.Value % ri.Value),
                    BinaryOperator.Eq => new BooleanLiteralNode(li.Value == ri.Value),
                    BinaryOperator.Ne => new BooleanLiteralNode(li.Value != ri.Value),
                    BinaryOperator.Lt => new BooleanLiteralNode(li.Value < ri.Value),
                    BinaryOperator.Le => new BooleanLiteralNode(li.Value <= ri.Value),
                    BinaryOperator.Gt => new BooleanLiteralNode(li.Value > ri.Value),
                    BinaryOperator.Ge => new BooleanLiteralNode(li.Value >= ri.Value),
                    BinaryOperator.Equal => new BooleanLiteralNode(li.Value == ri.Value),
                    BinaryOperator.NotEqual => new BooleanLiteralNode(li.Value != ri.Value),
                    BinaryOperator.LessThan => new BooleanLiteralNode(li.Value < ri.Value),
                    BinaryOperator.LessThanOrEqual => new BooleanLiteralNode(li.Value <= ri.Value),
                    BinaryOperator.GreaterThan => new BooleanLiteralNode(li.Value > ri.Value),
                    BinaryOperator.GreaterThanOrEqual => new BooleanLiteralNode(li.Value >= ri.Value),
                    _ => null
                };
                if (result is not null) { changed = true; return result; }
            }
            catch (DivideByZeroException)
            {
                // Skip constant folding; let runtime evaluate and produce the proper XPath error/INF
            }
            catch (OverflowException)
            {
                // Keep the operation for runtime checked arithmetic and decimal-backed integer promotion.
            }
        }

        if (left is DoubleLiteralNode ld && right is DoubleLiteralNode rd)
        {
            try
            {
                var result = node.Operator switch
                {
                    BinaryOperator.Plus => new DoubleLiteralNode(ld.Value + rd.Value),
                    BinaryOperator.Minus => new DoubleLiteralNode(ld.Value - rd.Value),
                    BinaryOperator.Multiply => new DoubleLiteralNode(ld.Value * rd.Value),
                    BinaryOperator.Divide => new DoubleLiteralNode(ld.Value / rd.Value),
                    _ => null
                };
                if (result is not null) { changed = true; return result; }
            }
            catch (DivideByZeroException)
            {
                // Double division by zero produces Infinity/NaN, not an exception,
                // so this catch is defensive only.
            }
        }

        if (left is DecimalLiteralNode lc && right is DecimalLiteralNode rc)
        {
            try
            {
                var result = node.Operator switch
                {
                    BinaryOperator.Plus => new DecimalLiteralNode(lc.Value + rc.Value, IsIntegerLiteral: lc.IsIntegerLiteral && rc.IsIntegerLiteral),
                    BinaryOperator.Minus => new DecimalLiteralNode(lc.Value - rc.Value, IsIntegerLiteral: lc.IsIntegerLiteral && rc.IsIntegerLiteral),
                    BinaryOperator.Multiply => new DecimalLiteralNode(lc.Value * rc.Value, IsIntegerLiteral: lc.IsIntegerLiteral && rc.IsIntegerLiteral),
                    BinaryOperator.Divide => new DecimalLiteralNode(lc.Value / rc.Value),
                    _ => null
                };
                if (result is not null) { changed = true; return result; }
            }
            catch (DivideByZeroException)
            {
                // Skip constant folding; let runtime evaluate and produce the proper XPath error
            }
            catch (OverflowException)
            {
                // Skip constant folding; let runtime surface the overflow as FOAR0002
            }
        }

        if (left is StringLiteralNode ls && right is StringLiteralNode rs && node.Operator == BinaryOperator.StringConcat)
        {
            changed = true;
            return new StringLiteralNode(ls.Value + rs.Value);
        }

        // Boolean simplification
        if (node.Operator is BinaryOperator.And or BinaryOperator.Or)
        {
            var simplified = SimplifyBoolean(node.Operator, left, right);
            if (simplified is not null) { changed = true; return simplified; }
        }

        return node;
    }

    private static XPathAstNode? SimplifyBoolean(BinaryOperator op, XPathAstNode left, XPathAstNode right)
    {
        bool? leftBool = AsBoolean(left);
        bool? rightBool = AsBoolean(right);

        if (op == BinaryOperator.And)
        {
            if (leftBool == false || rightBool == false) return FalseLiteral();
            // and/or always return a boolean; only propagate an operand if it is
            // already a boolean literal (otherwise we'd change the result type).
            if (leftBool == true && right is BooleanLiteralNode) return right;
            if (rightBool == true && left is BooleanLiteralNode) return left;
        }
        else if (op == BinaryOperator.Or)
        {
            if (leftBool == true || rightBool == true) return TrueLiteral();
            if (leftBool == false && right is BooleanLiteralNode) return right;
            if (rightBool == false && left is BooleanLiteralNode) return left;
        }

        return null;
    }

    // ------------------------------------------------------------------
    // Unary expressions
    // ------------------------------------------------------------------

    private XPathAstNode OptimizeUnary(UnaryExpressionNode node, ref bool changed)
    {
        var operand = OptimizeNode(node.Operand, ref changed);
        if (operand != node.Operand)
        {
            changed = true;
            node = node with { Operand = operand };
        }

        // Do not cancel -(-x): the inner operation may atomize x, convert an
        // untyped value, normalize a numeric subtype or raise an error. The
        // runtime must retain those semantics even when the two signs cancel.

        // -(IntegerLiteral) => negated literal. In XPath 1.0 BC mode, -0 must produce
        // a negative zero double, so do not fold the unary minus on integer zero.
        if (node.Operator == UnaryOperator.Minus && operand is IntegerLiteralNode i)
        {
            if (_backwardsCompatible && i.Value == 0)
                return node;
            // Let runtime promote the negation of Int64.MinValue instead of wrapping.
            if (i.Value == long.MinValue)
                return node;
            changed = true;
            return new IntegerLiteralNode(-i.Value);
        }

        // -(DoubleLiteral) => negated literal
        if (node.Operator == UnaryOperator.Minus && operand is DoubleLiteralNode d)
        {
            changed = true;
            return new DoubleLiteralNode(-d.Value);
        }

        // -(DecimalLiteral) => negated literal
        if (node.Operator == UnaryOperator.Minus && operand is DecimalLiteralNode dec)
        {
            changed = true;
            return new DecimalLiteralNode(-dec.Value, IsIntegerLiteral: dec.IsIntegerLiteral);
        }

        // +x => x only for numeric literals; non-numeric operands must be checked at runtime
        if (node.Operator == UnaryOperator.Plus && operand is IntegerLiteralNode or DecimalLiteralNode or DoubleLiteralNode)
        {
            changed = true;
            return operand;
        }

        return node;
    }

    // ------------------------------------------------------------------
    // If expressions
    // ------------------------------------------------------------------

    private XPathAstNode OptimizeIf(IfExpressionNode node, ref bool changed)
    {
        var cond = OptimizeNode(node.Condition, ref changed);
        var thenBranch = OptimizeNode(node.ThenBranch, ref changed);
        var elseBranch = OptimizeNode(node.ElseBranch, ref changed);

        if (cond != node.Condition || thenBranch != node.ThenBranch || elseBranch != node.ElseBranch)
        {
            changed = true;
            node = node with { Condition = cond, ThenBranch = thenBranch, ElseBranch = elseBranch };
        }

        // Dead code elimination
        if (AsBoolean(cond) == true) { changed = true; return thenBranch; }
        if (AsBoolean(cond) == false) { changed = true; return elseBranch; }

        return node;
    }

    // ------------------------------------------------------------------
    // Sequence expressions
    // ------------------------------------------------------------------

    private XPathAstNode OptimizeSequence(SequenceExpressionNode node, ref bool changed)
    {
        var optimized = new List<XPathAstNode>();
        foreach (var expr in node.Expressions)
        {
            var opt = OptimizeNode(expr, ref changed);
            optimized.Add(opt);
        }

        if (optimized.Count != node.Expressions.Count || !optimized.SequenceEqual(node.Expressions))
        {
            changed = true;
            return optimized.Count == 1 ? optimized[0] : node with { Expressions = optimized };
        }

        return node;
    }

    // ------------------------------------------------------------------
    // Range expressions
    // ------------------------------------------------------------------

    private XPathAstNode OptimizeRange(RangeExpressionNode node, ref bool changed)
    {
        var from = OptimizeNode(node.From, ref changed);
        var to = OptimizeNode(node.To, ref changed);

        if (from != node.From || to != node.To)
        {
            changed = true;
            node = node with { From = from, To = to };
        }

        // Constant range expansion (only for small ranges to avoid blow-up)
        if (from is IntegerLiteralNode fi && to is IntegerLiteralNode ti)
        {
            long count = ti.Value - fi.Value + 1;
            if (count >= 0 && count <= 16)
            {
                changed = true;
                var items = new List<XPathAstNode>();
                for (long v = fi.Value; v <= ti.Value; v++)
                    items.Add(new IntegerLiteralNode(v));
                return new SequenceExpressionNode(items);
            }
        }

        return node;
    }

    // ------------------------------------------------------------------
    // Path expressions
    // ------------------------------------------------------------------

    private XPathAstNode OptimizePath(PathExprNode node, ref bool changed)
    {
        var optimized = new List<XPathAstNode>();
        foreach (var step in node.Steps)
        {
            optimized.Add(OptimizeNode(step, ref changed));
        }

        if (!optimized.SequenceEqual(node.Steps))
        {
            changed = true;
            return node with { Steps = optimized };
        }

        return node;
    }

    private XPathAstNode OptimizeStep(StepNode node, ref bool changed)
    {
        var preds = new List<XPathAstNode>();
        foreach (var p in node.Predicates)
        {
            preds.Add(OptimizeNode(p, ref changed));
        }

        if (!preds.SequenceEqual(node.Predicates))
        {
            changed = true;
            return node with { Predicates = preds };
        }

        return node;
    }

    private XPathAstNode OptimizePostfix(PostfixPredicateNode node, ref bool changed)
    {
        var expr = OptimizeNode(node.Expression, ref changed);
        var pred = OptimizeNode(node.Predicate, ref changed);

        if (expr != node.Expression || pred != node.Predicate)
        {
            changed = true;
            return node with { Expression = expr, Predicate = pred };
        }

        return node;
    }

    private XPathAstNode OptimizeParen(ParenthesizedExprNode node, ref bool changed)
    {
        var inner = OptimizeNode(node.Expression, ref changed);
        changed = true;
        // Unwrap single-expression parentheses
        return inner;
    }

    // ------------------------------------------------------------------
    // FLWOR
    // ------------------------------------------------------------------

    private XPathAstNode OptimizeFor(ForExpressionNode node, ref bool changed)
    {
        var bindings = new List<QuantifiedBinding>();
        foreach (var b in node.Bindings)
        {
            var expr = OptimizeNode(b.Expression, ref changed);
            bindings.Add(expr == b.Expression ? b : b with { Expression = expr });
        }

        var body = OptimizeNode(node.ReturnExpression, ref changed);

        if (!bindings.SequenceEqual(node.Bindings) || body != node.ReturnExpression)
        {
            changed = true;
            return node with { Bindings = bindings, ReturnExpression = body };
        }

        return node;
    }

    private XPathAstNode OptimizeQuantified(QuantifiedExpressionNode node, ref bool changed)
    {
        var bindings = new List<QuantifiedBinding>();
        foreach (var b in node.Bindings)
        {
            var expr = OptimizeNode(b.Expression, ref changed);
            bindings.Add(expr == b.Expression ? b : b with { Expression = expr });
        }

        var body = OptimizeNode(node.SatisfiesExpression, ref changed);

        if (!bindings.SequenceEqual(node.Bindings) || body != node.SatisfiesExpression)
        {
            changed = true;
            return node with { Bindings = bindings, SatisfiesExpression = body };
        }

        return node;
    }

    // ------------------------------------------------------------------
    // Arrow / Lookup
    // ------------------------------------------------------------------

    private XPathAstNode OptimizeArrow(ArrowExprNode node, ref bool changed)
    {
        var source = OptimizeNode(node.Source, ref changed);
        var target = OptimizeNode(node.Target, ref changed);

        if (source != node.Source || target != node.Target)
        {
            changed = true;
            return node with { Source = source, Target = target };
        }

        return node;
    }

    private XPathAstNode OptimizePipeline(PipelineExprNode node, ref bool changed)
    {
        var source = OptimizeNode(node.Source, ref changed);
        var target = OptimizeNode(node.Target, ref changed);

        if (source != node.Source || target != node.Target)
        {
            changed = true;
            return node with { Source = source, Target = target };
        }

        return node;
    }

    private XPathAstNode OptimizeLookup(LookupNode node, ref bool changed)
    {
        var expr = OptimizeNode(node.Expression, ref changed);
        var key = OptimizeNode(node.Key, ref changed);

        if (expr != node.Expression || key != node.Key)
        {
            changed = true;
            return node with { Expression = expr, Key = key };
        }

        return node;
    }

    private XPathAstNode OptimizeLookupWildcard(LookupWildcardNode node, ref bool changed)
    {
        var expr = OptimizeNode(node.Expression, ref changed);

        if (expr != node.Expression)
        {
            changed = true;
            return node with { Expression = expr };
        }

        return node;
    }

    // ------------------------------------------------------------------
    // Type expressions
    // ------------------------------------------------------------------

    private XPathAstNode OptimizeCast(CastNode node, ref bool changed)
    {
        var expr = OptimizeNode(node.Expression, ref changed);
        if (expr != node.Expression)
        {
            changed = true;
            node = node with { Expression = expr };
        }

        // Fold string-to-integer cast
        if (expr is StringLiteralNode s && node.TypeName is "integer" or "int" && node.Prefix == "xs")
        {
            if (int.TryParse(s.Value, out var val))
            {
                changed = true;
                return new IntegerLiteralNode(val);
            }
        }

        return node;
    }

    private XPathAstNode OptimizeCastable(CastableNode node, ref bool changed)
    {
        var expr = OptimizeNode(node.Expression, ref changed);
        if (expr != node.Expression) { changed = true; return node with { Expression = expr }; }
        return node;
    }

    private XPathAstNode OptimizeInstanceOf(InstanceOfNode node, ref bool changed)
    {
        var expr = OptimizeNode(node.Expression, ref changed);
        if (expr != node.Expression) { changed = true; return node with { Expression = expr }; }
        return node;
    }

    private XPathAstNode OptimizeTreat(TreatNode node, ref bool changed)
    {
        var expr = OptimizeNode(node.Expression, ref changed);
        if (expr != node.Expression) { changed = true; return node with { Expression = expr }; }
        return node;
    }

    // ------------------------------------------------------------------
    // Constructors
    // ------------------------------------------------------------------

    private XPathAstNode OptimizeMap(MapConstructorNode node, ref bool changed)
    {
        var entries = new List<MapEntryNode>();
        foreach (var e in node.Entries)
        {
            var key = OptimizeNode(e.Key, ref changed);
            var value = OptimizeNode(e.Value, ref changed);
            entries.Add(key == e.Key && value == e.Value ? e : new MapEntryNode(key, value));
        }

        if (!entries.SequenceEqual(node.Entries))
        {
            changed = true;
            return node with { Entries = entries };
        }

        return node;
    }

    private XPathAstNode OptimizeArray(ArrayConstructorNode node, ref bool changed)
    {
        var items = new List<XPathAstNode>();
        foreach (var item in node.Items)
        {
            items.Add(OptimizeNode(item, ref changed));
        }

        if (!items.SequenceEqual(node.Items))
        {
            changed = true;
            return node with { Items = items };
        }

        return node;
    }

    private XPathAstNode OptimizeInline(InlineFunctionNode node, ref bool changed)
    {
        var body = OptimizeNode(node.Body, ref changed);
        if (body != node.Body)
        {
            changed = true;
            return node with { Body = body };
        }
        return node;
    }

    private XPathAstNode OptimizeLet(LetExpressionNode node, ref bool changed)
    {
        bool bindingsChanged = false;
        var newBindings = new List<QuantifiedBinding>(node.Bindings.Count);
        foreach (var binding in node.Bindings)
        {
            var optExpr = OptimizeNode(binding.Expression, ref changed);
            newBindings.Add(binding with { Expression = optExpr });
            if (optExpr != binding.Expression) bindingsChanged = true;
        }
        var body = OptimizeNode(node.Body, ref changed);
        if (bindingsChanged || body != node.Body)
        {
            changed = true;
            return node with { Bindings = newBindings, Body = body };
        }
        return node;
    }

    // ------------------------------------------------------------------
    // Full FLWOR (XQuery order by, etc.)
    // ------------------------------------------------------------------

    private XPathAstNode OptimizeFlwor(FlworExpressionNode node, ref bool changed)
    {
        var clauses = new List<FlworClauseNode>(node.Clauses.Count);
        bool anyClauseChanged = false;
        foreach (var clause in node.Clauses)
        {
            var newClause = OptimizeFlworClause(clause, ref changed);
            clauses.Add(newClause);
            if (newClause != clause) anyClauseChanged = true;
        }
        var body = OptimizeNode(node.ReturnExpression, ref changed);
        if (anyClauseChanged || body != node.ReturnExpression)
        {
            changed = true;
            return node with { Clauses = clauses, ReturnExpression = body };
        }
        return node;
    }

    private FlworClauseNode OptimizeFlworClause(FlworClauseNode clause, ref bool changed)
    {
        return clause switch
        {
            ForClauseNode forClause => OptimizeForClause(forClause, ref changed),
            LetClauseNode letClause => OptimizeLetClause(letClause, ref changed),
            WhereClauseNode whereClause => OptimizeWhereClause(whereClause, ref changed),
            CountClauseNode countClause => OptimizeCountClause(countClause, ref changed),
            OrderByClauseNode orderClause => OptimizeOrderByClause(orderClause, ref changed),
            GroupByClauseNode groupClause => OptimizeGroupByClause(groupClause, ref changed),
            WindowClauseNode windowClause => OptimizeWindowClause(windowClause, ref changed),
            _ => clause
        };
    }

    private WindowClauseNode OptimizeWindowClause(WindowClauseNode node, ref bool changed)
    {
        var inExpr = OptimizeNode(node.InExpression, ref changed);
        var startWhen = OptimizeNode(node.StartCondition.WhenExpression, ref changed);
        var endWhen = node.EndCondition is null ? null : OptimizeNode(node.EndCondition.WhenExpression, ref changed);
        if (inExpr == node.InExpression && startWhen == node.StartCondition.WhenExpression && endWhen == node.EndCondition?.WhenExpression)
            return node;
        return node with
        {
            InExpression = inExpr,
            StartCondition = node.StartCondition with { WhenExpression = startWhen },
            EndCondition = node.EndCondition is null ? null : node.EndCondition with { WhenExpression = endWhen! }
        };
    }

    private GroupByClauseNode OptimizeGroupByClause(GroupByClauseNode node, ref bool changed)
    {
        var specs = new List<GroupingSpec>(node.Specs.Count);
        foreach (var spec in node.Specs)
        {
            if (spec.KeyExpression is null)
            {
                specs.Add(spec);
                continue;
            }
            var key = OptimizeNode(spec.KeyExpression, ref changed);
            specs.Add(key == spec.KeyExpression ? spec : spec with { KeyExpression = key });
        }
        return specs.SequenceEqual(node.Specs) ? node : node with { Specs = specs };
    }

    private ForClauseNode OptimizeForClause(ForClauseNode node, ref bool changed)
    {
        var bindings = new List<QuantifiedBinding>(node.Bindings.Count);
        foreach (var b in node.Bindings)
        {
            var expr = OptimizeNode(b.Expression, ref changed);
            bindings.Add(expr == b.Expression
                ? b
                : b with { Expression = expr });
        }
        return bindings.SequenceEqual(node.Bindings) ? node : node with { Bindings = bindings };
    }

    private LetClauseNode OptimizeLetClause(LetClauseNode node, ref bool changed)
    {
        var bindings = new List<QuantifiedBinding>(node.Bindings.Count);
        foreach (var b in node.Bindings)
        {
            var expr = OptimizeNode(b.Expression, ref changed);
            bindings.Add(expr == b.Expression
                ? b
                : b with { Expression = expr });
        }
        return bindings.SequenceEqual(node.Bindings) ? node : node with { Bindings = bindings };
    }

    private WhereClauseNode OptimizeWhereClause(WhereClauseNode node, ref bool changed)
    {
        var condition = OptimizeNode(node.Condition, ref changed);
        return condition == node.Condition ? node : node with { Condition = condition };
    }

    private CountClauseNode OptimizeCountClause(CountClauseNode node, ref bool changed)
    {
        // Count clauses have no child expressions; nothing to optimize.
        return node;
    }

    private OrderByClauseNode OptimizeOrderByClause(OrderByClauseNode node, ref bool changed)
    {
        var specs = new List<OrderSpec>(node.Specs.Count);
        foreach (var spec in node.Specs)
        {
            var key = OptimizeNode(spec.KeyExpression, ref changed);
            specs.Add(key == spec.KeyExpression ? spec : spec with { KeyExpression = key });
        }
        return specs.SequenceEqual(node.Specs) ? node : node with { Specs = specs };
    }

    private XPathAstNode OptimizeDynamicFunctionCall(DynamicFunctionCallNode node, ref bool changed)
    {
        var func = OptimizeNode(node.Function, ref changed);
        bool argsChanged = false;
        var newArgs = new List<XPathAstNode>(node.Arguments.Count);
        foreach (var arg in node.Arguments)
        {
            var optimized = OptimizeNode(arg, ref changed);
            newArgs.Add(optimized);
            if (optimized != arg) argsChanged = true;
        }
        if (func != node.Function || argsChanged)
        {
            changed = true;
            return node with { Function = func, Arguments = newArgs };
        }
        return node;
    }

    private XPathAstNode OptimizeFunctionCall(FunctionCallNode node, ref bool changed)
    {
        // Optimize arguments
        var args = node.Arguments;
        bool argsChanged = false;
        var newArgs = new List<XPathAstNode>(args.Count);
        foreach (var arg in args)
        {
            var optimized = OptimizeNode(arg, ref changed);
            newArgs.Add(optimized);
            if (optimized != arg) argsChanged = true;
        }

        if (argsChanged)
        {
            changed = true;
            node = node with { Arguments = newArgs };
        }

        // Fold common functions
        if (string.IsNullOrEmpty(node.Prefix) && node.LocalName == "true" && args.Count == 0)
        {
            changed = true;
            return new BooleanLiteralNode(true) { Span = node.Span };
        }

        if (string.IsNullOrEmpty(node.Prefix) && node.LocalName == "false" && args.Count == 0)
        {
            changed = true;
            return new BooleanLiteralNode(false) { Span = node.Span };
        }

        if (string.IsNullOrEmpty(node.Prefix) && node.LocalName == "not" && args.Count == 1 && args[0] is BooleanLiteralNode b)
        {
            changed = true;
            return new BooleanLiteralNode(!b.Value) { Span = node.Span };
        }

        return node;
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private static bool? AsBoolean(XPathAstNode node)
    {
        return node switch
        {
            BooleanLiteralNode b => b.Value,
            IntegerLiteralNode i => i.Value != 0,
            DoubleLiteralNode d => d.Value != 0.0 && !double.IsNaN(d.Value),
            DecimalLiteralNode dec => dec.Value != 0m,
            StringLiteralNode s => !string.IsNullOrEmpty(s.Value),
            _ => null
        };
    }

    private static XPathAstNode TrueLiteral() => new BooleanLiteralNode(true);
    private static XPathAstNode FalseLiteral() => new BooleanLiteralNode(false);
}
