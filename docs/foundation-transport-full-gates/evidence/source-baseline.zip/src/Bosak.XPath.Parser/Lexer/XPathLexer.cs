// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 19 mei 2026
// PURPOSE              : A zero-allocation XPath 3.1 lexer operating over <see cref="ReadOnlySpan{char}"/>
// SPECIAL NOTES        : Part of the hand-written recursive-descent parser pipeline.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 19-05-2026     | Creation                                                                                 |
//                      | Charles Korthout | 0.2   | 13-06-2026     | Trailing dot in number is DecimalLiteral (fixes select-3501/3502)                        |
//                      | Charles Korthout | 0.3   | 26-06-2026     | Lex Q{uri}* URI-qualified wildcards                                                      |
//                      | Charles Korthout | 0.4   | 19-07-2026     | NumericLiteral followed by NameStartChar is Invalid (10idiv → XPST0003)                 |
//                      | Charles Korthout | 0.5   | 20-07-2026     | Unterminated XPath comments now raise XPST0003                                         |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.6   | 25-07-2026     | Constructor mode: direct element/comment/PI constructors as single tokens               |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.7   | 27-07-2026     | Whole-span token scan for XQuery string constructors (interpolation/nesting aware) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.8   | 29-07-2026     | Lex '%' as Percent token for XQuery annotations |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.9   | 29-07-2026     | QNames carry at most one colon (map constructor entry disambiguation) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.0   | 29-07-2026     | ScanDirectConstructorLength for prolog-level constructor skipping |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.1   | 22-08-2026     | Recognize 'validate' as KeywordValidate |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.2   | 22-08-2026     | Treat 'validate' as a contextual XQuery keyword (Name token) to keep it valid in XPath |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.3   | 27-08-2026     | Reject invalid XML 1.0 name characters (e.g. U+00B5) as XPST0003                       |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.4   | 07-09-2026     | Unterminated braced URI literal Q{ raises XPST0003 (eqname-907)                          |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.5   | 09-09-2026     | XML doc coverage on public API (Beta review)                                             |
//                      | Charles Korthout | 1.6   | 21-09-2026     | API freeze stage A: internalized (IVT for in-repo consumers)                           |
//                      | Charles Korthout | 1.7   | 21-09-2026     | API freeze stage A: ParseException renamed to XPathParseException                      |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.8   | 08-10-2026     | REQ-118 4.0-S3a: '??' Otherwise token; 4.0 hex/binary literals + digit underscores     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.9   | 08-10-2026     | REQ-118 4.0-S3b: StringTemplate token scanning ({{ }} `` escapes, nested templates)   |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.10  | 08-10-2026     | REQ-118 4.0-S4: '->' pipeline and '=!>' mapping arrow token scanning                   |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.11  | 18-10-2026     | Correct build-warning documentation and nullable-flow diagnostics.                     |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.12  | 23-10-2026     | Reject leading/trailing separators in fractional and exponent digit groups.              |
//                      | Charles Korthout | 1.13  | 28-10-2026     | Implement statically validated ignored-pragma fallback and raw scanning (1.33.0). |
// ===========================================================================================================================================================
using System.Runtime.CompilerServices;
using Bosak.XPath.Parser;

namespace Bosak.XPath.Parser.Lexer;

/// <summary>
/// A zero-allocation XPath 3.1 lexer operating over <see cref="ReadOnlySpan{T}"/>.
/// </summary>
internal ref struct XPathLexer
{
    private readonly ReadOnlySpan<char> _source;
    private readonly bool _allowConstructors;
    private readonly bool _xpath40;
    private int _position;

    /// <summary>
    /// Initializes a lexer over the given source text.
    /// </summary>
    /// <param name="source">The XPath or XQuery source text to tokenize.</param>
    /// <param name="allowConstructors">When true, XQuery direct element/comment/PI and string
    /// constructors are scanned as single <see cref="TokenKind.Constructor"/> tokens,
    /// and raw extension pragmas as <see cref="TokenKind.Pragma"/> tokens.</param>
    /// <param name="xpath40">When true, XPath 4.0 lexical extensions are enabled: hexadecimal
    /// (<c>0x...</c>) and binary (<c>0b...</c>) integer literals and underscore digit separators.</param>
    public XPathLexer(ReadOnlySpan<char> source, bool allowConstructors = false, bool xpath40 = false)
    {
        _source = source;
        _allowConstructors = allowConstructors;
        _xpath40 = xpath40;
        _position = 0;
    }

    /// <summary>The source text being tokenized.</summary>
    public ReadOnlySpan<char> Source => _source;
    /// <summary>The zero-based character offset of the next character to scan.</summary>
    public int Position => _position;
    /// <summary>True when the end of the source text has been reached.</summary>
    public bool IsAtEnd => _position >= _source.Length;

    /// <summary>
    /// Attempts to scan a direct element constructor at the start of <paramref name="source"/>.
    /// Returns the constructor's length in characters, or 0 when the text does not form a
    /// structurally valid constructor (the caller then treats '&lt;' as an operator).
    /// Prolog-level scanners use this to skip constructor text with quote fidelity
    /// (K2-Axes-1/2: apostrophes in element content are not string delimiters).
    /// </summary>
    /// <param name="source">The source text positioned at '&lt;'.</param>
    /// <returns>The length of the constructor in characters, or 0 when the text is not a
    /// structurally valid constructor.</returns>
    public static int ScanDirectConstructorLength(ReadOnlySpan<char> source)
    {
        if (source.Length < 2 || source[0] != '<' || !IsNameStartChar(source[1]))
            return 0;
        var lexer = new XPathLexer(source, allowConstructors: true);
        var token = lexer.TryScanConstructor(0);
        return token.Kind == TokenKind.Constructor ? token.Length : 0;
    }

    /// <summary>
    /// Returns the next token and advances the lexer.
    /// </summary>
    /// <returns>The next token, or <see cref="Token.Eof"/> when the end of the source is reached.</returns>
    /// <exception cref="XPathParseException">An XPath comment or braced URI literal is unterminated.</exception>
    public Token NextToken()
    {
        SkipWhitespaceAndComments();

        if (_position >= _source.Length)
            return Token.Eof;

        int start = _position;
        char c = _source[_position];

        if (_allowConstructors && c == '(' && _position + 1 < _source.Length && _source[_position + 1] == '#')
        {
            int length = ScanPragmaLength(_source[start..]);
            _position += length;
            return new Token(TokenKind.Pragma, start, length);
        }

        // ---- XQuery direct element constructors -----------------------
        // '<' followed by a name-start char begins a constructor; the whole span
        // (attributes, text, nested elements, enclosed expressions) is one token.
        // Anything that does not match the structure falls back to the '<' operator.
        if (_allowConstructors && c == '<' && _position + 1 < _source.Length && IsNameStartChar(_source[_position + 1]))
        {
            var ctor = TryScanConstructor(start);
            if (ctor.Kind != TokenKind.Invalid)
            {
                _position = start + ctor.Length;
                return ctor;
            }
            _position = start;
        }

        // Direct comment / processing-instruction constructors (standalone expressions).
        if (_allowConstructors && c == '<' && _position + 1 < _source.Length && _source[_position + 1] == '?')
        {
            int close = IndexOf(_position + 2, "?>");
            if (close >= 0)
            {
                _position = close + 2;
                return new Token(TokenKind.Constructor, start, _position - start);
            }
        }
        if (_allowConstructors && c == '<' && _position + 1 < _source.Length && _source[_position + 1] == '!' &&
            _position + 3 < _source.Length && _source[_position + 2] == '-' && _source[_position + 3] == '-')
        {
            int close = IndexOf(_position + 4, "-->");
            if (close >= 0)
            {
                _position = close + 3;
                return new Token(TokenKind.Constructor, start, _position - start);
            }
        }

        // ---- XQuery string constructors --------------------------------------
        // "``[" begins a string constructor; the whole span (literal text and
        // `{`...`}` interpolations, including nested constructors) is one token.
        if (_allowConstructors && c == '`' && _position + 2 < _source.Length
            && _source[_position + 1] == '`' && _source[_position + 2] == '[')
        {
            int end = ScanStringConstructorEnd(start + 3);
            if (end >= 0)
            {
                _position = end;
                return new Token(TokenKind.Constructor, start, end - start);
            }
            _position = start;
        }

        // ---- XPath 4.0 string templates --------------------------------------
        // A lone backtick opens a string template; the whole span (fixed parts with
        // {{ }} `` escapes and {...} interpolations, including nested templates) is
        // one raw token for the parser to re-scan. In XPath 3.1 mode a backtick
        // remains an invalid token (XPST0003), as before.
        if (_xpath40 && c == '`')
        {
            int end = ScanStringTemplateEnd(start + 1);
            if (end >= 0)
            {
                _position = end;
                return new Token(TokenKind.StringTemplate, start, end - start);
            }
        }

        // ---- Literals ------------------------------------------------
        if (c == '"' || c == '\'')
            return ReadStringLiteral(start, c);

        // ---- Numbers -------------------------------------------------
        if (char.IsDigit(c))
            return ReadNumber(start);

        if (c == '.')
        {
            if (_position + 1 < _source.Length && char.IsDigit(_source[_position + 1]))
                return ReadNumber(start); // .5
            if (_position + 1 < _source.Length && _source[_position + 1] == '.')
            {
                _position += 2;
                return new Token(TokenKind.DotDot, start, 2);
            }
            _position++;
            return new Token(TokenKind.Dot, start, 1);
        }

        // ---- Names / Keywords ----------------------------------------
        // Exclude ':' here — it is handled by ReadOperator as Colon or DoubleColon.
        // ReadNameOrKeyword still handles QNames (prefix:local) internally.
        if (IsNameStartChar(c) && c != ':')
            return ReadNameOrKeyword(start);

        // ---- Multi-char operators (check longest first) --------------
        return ReadOperator(start, c);
    }

    // ------------------------------------------------------------------
    // Whitespace & Comments
    // ------------------------------------------------------------------

    /// <summary>Scans a raw pragma span without interpreting strings, comments or braces.</summary>
    /// <param name="source">Source positioned at a possible pragma opener.</param>
    /// <returns>The complete pragma length, or zero when no opener is present.</returns>
    /// <exception cref="XPathParseException">The pragma has no closing delimiter.</exception>
    public static int ScanPragmaLength(ReadOnlySpan<char> source)
    {
        if (!source.StartsWith("(#")) return 0;
        int end = source[2..].IndexOf("#)".AsSpan(), StringComparison.Ordinal);
        if (end < 0) throw new XPathParseException("XPST0003: Unterminated pragma.", 0);
        return end + 4;
    }

    private void SkipWhitespaceAndComments()
    {
        while (_position < _source.Length)
        {
            char c = _source[_position];

            if (char.IsWhiteSpace(c))
            {
                _position++;
                continue;
            }

            if (c == '(' && _position + 1 < _source.Length && _source[_position + 1] == ':')
            {
                SkipComment();
                continue;
            }

            break;
        }
    }

    /// <summary>
    /// Skips a nested XPath comment <c>(: ... :)</c>.
    /// </summary>
    private void SkipComment()
    {
        // Skip opening '(:'
        int start = _position;
        _position += 2;
        int depth = 1;

        while (_position < _source.Length && depth > 0)
        {
            char c = _source[_position];

            if (c == ':' && _position + 1 < _source.Length && _source[_position + 1] == ')')
            {
                depth--;
                _position += 2;
            }
            else if (c == '(' && _position + 1 < _source.Length && _source[_position + 1] == ':')
            {
                depth++;
                _position += 2;
            }
            else
            {
                _position++;
            }
        }

        if (depth > 0)
        {
            throw new XPathParseException("Unterminated comment", start);
        }
    }

    // ------------------------------------------------------------------
    // String literals
    // ------------------------------------------------------------------

    private Token ReadStringLiteral(int start, char quote)
    {
        _position++; // skip opening quote

        while (_position < _source.Length)
        {
            char c = _source[_position];

            if (c == quote)
            {
                // Check for doubled quote (escape sequence)
                if (_position + 1 < _source.Length && _source[_position + 1] == quote)
                {
                    _position += 2; // skip both quotes
                    continue;
                }

                _position++; // skip closing quote
                return new Token(TokenKind.StringLiteral, start, _position - start);
            }

            _position++;
        }

        // Unterminated string
        return new Token(TokenKind.Invalid, start, _position - start);
    }

    // ------------------------------------------------------------------
    // Numbers
    // ------------------------------------------------------------------

    private Token ReadNumber(int start)
    {
        bool hasDot = false;
        bool hasExponent = false;

        // XPath 4.0: hexadecimal (0x...) and binary (0b...) integer literals.
        if (_xpath40 && _source[_position] == '0' && _position + 1 < _source.Length &&
            (_source[_position + 1] == 'x' || _source[_position + 1] == 'b'))
        {
            bool hex = _source[_position + 1] == 'x';
            _position += 2;
            int digits = 0;
            while (_position < _source.Length)
            {
                char d = _source[_position];
                bool ok = hex ? (d is >= '0' and <= '9' or >= 'a' and <= 'f' or >= 'A' and <= 'F')
                              : (d is '0' or '1');
                if (ok || (d == '_' && digits > 0))
                {
                    if (ok) digits++;
                    _position++;
                    continue;
                }
                break;
            }
            // A trailing underscore (or missing digits) is not part of the literal;
            // backing off leaves a name-start character which the caller reports
            // as an invalid token (XPST0003), matching the Digits grammar.
            while (_position > start + 2 && _source[_position - 1] == '_')
                _position--;
            if (digits == 0)
                return new Token(TokenKind.Invalid, start, _position - start);
            return new Token(TokenKind.IntegerLiteral, start, _position - start);
        }

        // Integer part (underscore separators allowed in XPath 4.0)
        while (_position < _source.Length && (char.IsDigit(_source[_position]) || (_xpath40 && _source[_position] == '_')))
        {
            _position++;
        }
        // A trailing underscore is not part of the literal (Digits grammar);
        // the name-follow check below reports it as an invalid token (XPST0003).
        while (_position > start + 1 && _source[_position - 1] == '_')
            _position--;

        // Decimal point
        if (_position < _source.Length && _source[_position] == '.')
        {
            _position++;
            int fractionStart = _position;

            while (_position < _source.Length && (char.IsDigit(_source[_position]) || (_xpath40 && _source[_position] == '_')))
            {
                _position++;
            }

            // A nonempty 4.0 Digits group must begin and end with a digit.
            // Repeated separators between digits remain valid.
            if (_xpath40 && _position > fractionStart &&
                (_source[fractionStart] == '_' || _source[_position - 1] == '_'))
                return new Token(TokenKind.Invalid, start, _position - start);

            // A trailing dot is part of a decimal literal per XPath 3.1:
            // DecimalLiteral ::= Digits '.' Digits?
            // This makes "5.*." parse as (5.0 * .) and "5.+*" as (5.0 + *).
            hasDot = true;
        }

        // Exponent
        if (_position < _source.Length && (_source[_position] == 'e' || _source[_position] == 'E'))
        {
            int expPos = _position;
            _position++;

            if (_position < _source.Length && (_source[_position] == '+' || _source[_position] == '-'))
                _position++;

            int exponentStart = _position;
            bool hasExpDigits = false;
            while (_position < _source.Length && (char.IsDigit(_source[_position]) || (_xpath40 && _source[_position] == '_')))
            {
                hasExpDigits = true;
                _position++;
            }

            if (_xpath40 && _position > exponentStart &&
                (_source[exponentStart] == '_' || _source[_position - 1] == '_'))
                return new Token(TokenKind.Invalid, start, _position - start);

            if (hasExpDigits)
            {
                hasExponent = true;
            }
            else
            {
                // Rollback exponent — it's not a double
                _position = expPos;
            }
        }

        int length = _position - start;

        if (hasExponent)
            return new Token(TokenKind.DoubleLiteral, start, length);

        if (hasDot)
            return new Token(TokenKind.DecimalLiteral, start, length);

        // NumericLiteral must be followed by a terminal or whitespace; a
        // name-start character immediately after the number is a lexical error
        // (e.g. "10idiv 3" must raise XPST0003, not parse as "10 idiv 3").
        if (_position < _source.Length && IsNameStartChar(_source[_position]) && _source[_position] != ':')
        {
            while (_position < _source.Length && IsNameChar(_source[_position]))
                _position++;
            return new Token(TokenKind.Invalid, start, _position - start);
        }

        return new Token(TokenKind.IntegerLiteral, start, length);
    }

    // ------------------------------------------------------------------
    // Names & Keywords
    // ------------------------------------------------------------------

    private Token ReadNameOrKeyword(int start)
    {
        // Consume name chars, but stop at ':' so we can handle QNames,
        // axis separators (::), and wildcard patterns (prefix:*, *:local).
        while (_position < _source.Length && IsNameChar(_source[_position]) && _source[_position] != ':')
            _position++;

        // Braced URI literal: Q{uri}localname
        if (_position - start == 1 && _source[start] == 'Q' &&
            _position < _source.Length && _source[_position] == '{')
        {
            _position++; // consume '{'
            while (_position < _source.Length && _source[_position] != '}')
                _position++;
            if (_position >= _source.Length)
                throw new XPathParseException("XPST0003: Unterminated braced URI literal (missing '}').", start);
            _position++; // consume '}'

            // URI-qualified wildcard: Q{uri}*
            if (_position < _source.Length && _source[_position] == '*')
            {
                _position++; // consume '*'
                return new Token(TokenKind.Name, start, _position - start);
            }

            // Read local name or prefix:local — a QName carries at most one colon;
            // a further colon starts a new token (map constructor entries).
            if (_position < _source.Length && IsNameStartChar(_source[_position]))
            {
                while (_position < _source.Length && IsNameChar(_source[_position]) && _source[_position] != ':')
                    _position++;

                // Handle prefix:local
                if (_position < _source.Length && _source[_position] == ':')
                {
                    int colonPos = _position;
                    _position++;
                    if (_position < _source.Length && IsNameStartChar(_source[_position]))
                    {
                        while (_position < _source.Length && IsNameChar(_source[_position]) && _source[_position] != ':')
                            _position++;
                        return new Token(TokenKind.Name, start, _position - start);
                    }
                    _position = colonPos; // rollback
                }
            }
            return new Token(TokenKind.Name, start, _position - start);
        }

        // Check for colon (QName)
        if (_position < _source.Length && _source[_position] == ':')
        {
            int colonPos = _position;
            _position++;

            // "::" is axis separator, not part of a QName
            if (_position < _source.Length && _source[_position] == ':')
            {
                // Rollback — this is a prefix followed by ::
                _position = colonPos;
                return new Token(TokenKind.Name, start, colonPos - start);
            }

            // prefix:* is a Name, Colon, Star sequence — don't consume the star
            if (_position < _source.Length && _source[_position] == '*')
            {
                _position = colonPos;
                return new Token(TokenKind.Name, start, colonPos - start);
            }

            // prefix:localname — a QName carries at most one colon; a further colon
            // starts a new token (map constructor entries, map{z:b:z:b}).
            if (_position < _source.Length && IsNameStartChar(_source[_position]))
            {
                while (_position < _source.Length && IsNameChar(_source[_position]) && _source[_position] != ':')
                    _position++;

                return new Token(TokenKind.Name, start, _position - start);
            }

            // Trailing colon with no valid local name — treat as name + colon
            _position = colonPos;
            return new Token(TokenKind.Name, start, colonPos - start);
        }

        ReadOnlySpan<char> text = _source.Slice(start, _position - start);
        TokenKind kind = text.Length switch
        {
            2 => ResolveKeyword2(text),
            3 => ResolveKeyword3(text),
            4 => ResolveKeyword4(text),
            5 => ResolveKeyword5(text),
            6 => ResolveKeyword6(text),
            7 => ResolveKeyword7(text),
            8 => ResolveKeyword8(text),
            9 => ResolveKeyword9(text),
            _ => TokenKind.Name
        };

        return new Token(kind, start, _position - start);
    }

    // ------------------------------------------------------------------
    // Operators
    // ------------------------------------------------------------------

    private Token ReadOperator(int start, char c)
    {
        _position++;

        switch (c)
        {
            case '(':
                return new Token(TokenKind.LParen, start, 1);
            case ')':
                return new Token(TokenKind.RParen, start, 1);
            case '[':
                return new Token(TokenKind.LBracket, start, 1);
            case ']':
                return new Token(TokenKind.RBracket, start, 1);
            case '{':
                return new Token(TokenKind.LBrace, start, 1);
            case '}':
                return new Token(TokenKind.RBrace, start, 1);
            case ',':
                return new Token(TokenKind.Comma, start, 1);
            case '+':
                return new Token(TokenKind.Plus, start, 1);
            case '-':
                if (_position < _source.Length && _source[_position] == '>')
                {
                    // Longest-token rule: '->' is the XPath 4.0 pipeline operator.
                    // The parser rejects it with XPST0003 in 3.1 mode.
                    _position++;
                    return new Token(TokenKind.PipelineArrow, start, 2);
                }
                return new Token(TokenKind.Minus, start, 1);
            case '*':
                return new Token(TokenKind.Star, start, 1);
            case '$':
                return new Token(TokenKind.Dollar, start, 1);
            case '@':
                return new Token(TokenKind.At, start, 1);
            case '?':
                if (_position < _source.Length && _source[_position] == '?')
                {
                    // Longest-token rule: '??' is the XPath 4.0 otherwise operator.
                    // The parser rejects it with XPST0003 in 3.1 mode.
                    _position++;
                    return new Token(TokenKind.Otherwise, start, 2);
                }
                return new Token(TokenKind.Question, start, 1);
            case '#':
                return new Token(TokenKind.Hash, start, 1);
            case '%':
                return new Token(TokenKind.Percent, start, 1);
            case ';':
                return new Token(TokenKind.Semicolon, start, 1);

            case '/':
                if (_position < _source.Length && _source[_position] == '/')
                {
                    _position++;
                    return new Token(TokenKind.SlashSlash, start, 2);
                }
                return new Token(TokenKind.Slash, start, 1);

            case '|':
                if (_position < _source.Length && _source[_position] == '|')
                {
                    _position++;
                    return new Token(TokenKind.StringConcat, start, 2);
                }
                return new Token(TokenKind.VBar, start, 1);

            case ':':
                if (_position < _source.Length && _source[_position] == ':')
                {
                    _position++;
                    return new Token(TokenKind.DoubleColon, start, 2);
                }
                if (_position < _source.Length && _source[_position] == '=')
                {
                    _position++;
                    return new Token(TokenKind.Assign, start, 2);
                }
                return new Token(TokenKind.Colon, start, 1);

            case '=':
                if (_position < _source.Length && _source[_position] == '>')
                {
                    _position++;
                    return new Token(TokenKind.Arrow, start, 2);
                }
                if (_position + 1 < _source.Length && _source[_position] == '!' && _source[_position + 1] == '>')
                {
                    // Longest-token rule: '=!>' is the XPath 4.0 mapping arrow.
                    // The parser rejects it with XPST0003 in 3.1 mode.
                    _position += 2;
                    return new Token(TokenKind.MappingArrow, start, 3);
                }
                return new Token(TokenKind.Equal, start, 1);

            case '!':
                if (_position < _source.Length && _source[_position] == '=')
                {
                    _position++;
                    return new Token(TokenKind.NotEqual, start, 2);
                }
                return new Token(TokenKind.Bang, start, 1);

            case '<':
                if (_position < _source.Length)
                {
                    if (_source[_position] == '=')
                    {
                        _position++;
                        return new Token(TokenKind.LessThanOrEqual, start, 2);
                    }
                    if (_source[_position] == '<')
                    {
                        _position++;
                        return new Token(TokenKind.NodeBefore, start, 2);
                    }
                }
                return new Token(TokenKind.LessThan, start, 1);

            case '>':
                if (_position < _source.Length)
                {
                    if (_source[_position] == '=')
                    {
                        _position++;
                        return new Token(TokenKind.GreaterThanOrEqual, start, 2);
                    }
                    if (_source[_position] == '>')
                    {
                        _position++;
                        return new Token(TokenKind.NodeAfter, start, 2);
                    }
                }
                return new Token(TokenKind.GreaterThan, start, 1);

            default:
                return new Token(TokenKind.Invalid, start, 1);
        }
    }

    // ------------------------------------------------------------------
    // Keyword resolution
    // ------------------------------------------------------------------

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private static bool SeqEqual(ReadOnlySpan<char> a, string b)
        => a.Length == b.Length && a.SequenceEqual(b.AsSpan());

    private static TokenKind ResolveKeyword2(ReadOnlySpan<char> text)
    {
        if (SeqEqual(text, "as")) return TokenKind.KeywordAs;
        if (SeqEqual(text, "eq")) return TokenKind.ValueEq;
        if (SeqEqual(text, "ge")) return TokenKind.ValueGe;
        if (SeqEqual(text, "gt")) return TokenKind.ValueGt;
        if (SeqEqual(text, "if")) return TokenKind.KeywordIf;
        if (SeqEqual(text, "in")) return TokenKind.KeywordIn;
        if (SeqEqual(text, "is")) return TokenKind.ValueIs;
        if (SeqEqual(text, "le")) return TokenKind.ValueLe;
        if (SeqEqual(text, "lt")) return TokenKind.ValueLt;
        if (SeqEqual(text, "ne")) return TokenKind.ValueNe;
        if (SeqEqual(text, "of")) return TokenKind.KeywordOf;
        if (SeqEqual(text, "or")) return TokenKind.KeywordOr;
        if (SeqEqual(text, "to")) return TokenKind.KeywordTo;
        return TokenKind.Name;
    }

    private static TokenKind ResolveKeyword3(ReadOnlySpan<char> text)
    {
        if (SeqEqual(text, "and")) return TokenKind.KeywordAnd;
        if (SeqEqual(text, "div")) return TokenKind.KeywordDiv;
        if (SeqEqual(text, "for")) return TokenKind.KeywordFor;
        if (SeqEqual(text, "let")) return TokenKind.KeywordLet;
        if (SeqEqual(text, "map")) return TokenKind.KeywordMap;
        if (SeqEqual(text, "mod")) return TokenKind.KeywordMod;
        if (SeqEqual(text, "not")) return TokenKind.Name; // not is a function, not a keyword
        if (SeqEqual(text, "try")) return TokenKind.KeywordTry;
        return TokenKind.Name;
    }

    private static TokenKind ResolveKeyword4(ReadOnlySpan<char> text)
    {
        if (SeqEqual(text, "cast")) return TokenKind.KeywordCast;
        if (SeqEqual(text, "else")) return TokenKind.KeywordElse;
        if (SeqEqual(text, "idiv")) return TokenKind.KeywordIdiv;
        if (SeqEqual(text, "then")) return TokenKind.KeywordThen;
        if (SeqEqual(text, "some")) return TokenKind.KeywordSome;
        return TokenKind.Name;
    }

    private static TokenKind ResolveKeyword5(ReadOnlySpan<char> text)
    {
        if (SeqEqual(text, "array")) return TokenKind.KeywordArray;
        if (SeqEqual(text, "catch")) return TokenKind.KeywordCatch;
        if (SeqEqual(text, "every")) return TokenKind.KeywordEvery;
        if (SeqEqual(text, "idiv")) return TokenKind.KeywordIdiv;
        if (SeqEqual(text, "treat")) return TokenKind.KeywordTreat;
        if (SeqEqual(text, "union")) return TokenKind.KeywordUnion;
        return TokenKind.Name;
    }

    private static TokenKind ResolveKeyword6(ReadOnlySpan<char> text)
    {
        if (SeqEqual(text, "except")) return TokenKind.KeywordExcept;
        if (SeqEqual(text, "return")) return TokenKind.KeywordReturn;
        return TokenKind.Name;
    }

    private static TokenKind ResolveKeyword7(ReadOnlySpan<char> text)
    {
        if (SeqEqual(text, "castable")) return TokenKind.KeywordCastable;
        if (SeqEqual(text, "default")) return TokenKind.Name;
        if (SeqEqual(text, "element")) return TokenKind.Name; // kind test, parsed as name
        if (SeqEqual(text, "foreach")) return TokenKind.Name; // function name
        if (SeqEqual(text, "item")) return TokenKind.Name;
        if (SeqEqual(text, "satisfies")) return TokenKind.KeywordSatisfies;
        if (SeqEqual(text, "switch")) return TokenKind.Name; // XQuery
        if (SeqEqual(text, "version")) return TokenKind.Name; // XQuery
        return TokenKind.Name;
    }

    private static TokenKind ResolveKeyword8(ReadOnlySpan<char> text)
    {
        if (SeqEqual(text, "ancestor")) return TokenKind.Name;
        if (SeqEqual(text, "attribute")) return TokenKind.Name;
        if (SeqEqual(text, "castable")) return TokenKind.KeywordCastable;
        if (SeqEqual(text, "children")) return TokenKind.Name;
        if (SeqEqual(text, "function")) return TokenKind.KeywordFunction;
        if (SeqEqual(text, "instance")) return TokenKind.KeywordInstance;
        if (SeqEqual(text, "validate")) return TokenKind.Name; // XQuery
        if (SeqEqual(text, "variable")) return TokenKind.Name; // XQuery
        return TokenKind.Name;
    }

    private static TokenKind ResolveKeyword9(ReadOnlySpan<char> text)
    {
        if (SeqEqual(text, "descendant")) return TokenKind.Name;
        if (SeqEqual(text, "following")) return TokenKind.Name;
        if (SeqEqual(text, "intersect")) return TokenKind.KeywordIntersect;
        if (SeqEqual(text, "namespace")) return TokenKind.Name;
        if (SeqEqual(text, "preceding")) return TokenKind.Name;
        if (SeqEqual(text, "satisfies")) return TokenKind.KeywordSatisfies;
        if (SeqEqual(text, "transform")) return TokenKind.Name;
        if (SeqEqual(text, "typeswitch")) return TokenKind.Name; // XQuery
        return TokenKind.Name;
    }

    // ------------------------------------------------------------------
    // XQuery direct element constructors
    // ------------------------------------------------------------------

    /// <summary>
    /// Attempts to scan a whole direct element constructor starting at '&lt;'. Returns an
    /// Invalid token when the structure does not hold (the caller then re-lexes '&lt;' as
    /// the comparison operator). Structure validation is shallow: name matching and
    /// expression parsing are left to the parser.
    /// </summary>
    private Token TryScanConstructor(int start)
    {
        int pos = start + 1;
        if (!ScanNcName(ref pos))
            return default;

        // Attributes / open tag.
        while (true)
        {
            ScanWhitespace(ref pos);
            if (pos >= _source.Length)
                return default;
            char c = _source[pos];
            if (c == '>')
            {
                pos++;
                break;
            }
            if (c == '/' && pos + 1 < _source.Length && _source[pos + 1] == '>')
                return new Token(TokenKind.Constructor, start, pos + 2 - start);
            if (!ScanNcName(ref pos))
                return default;
            ScanWhitespace(ref pos);
            if (pos >= _source.Length || _source[pos] != '=')
                return default;
            pos++;
            ScanWhitespace(ref pos);
            if (pos >= _source.Length || (_source[pos] != '"' && _source[pos] != '\''))
                return default;
            char quote = _source[pos++];
            if (!ScanConstructorAttributeValue(ref pos, quote))
                return default;
        }

        // Content until the matching end tag (depth tracks nested open elements).
        int depth = 1;
        while (pos < _source.Length)
        {
            char c = _source[pos];
            if (c == '<')
            {
                if (MatchesAt(pos, "<!--"))
                {
                    int close = IndexOf(pos + 4, "-->");
                    if (close < 0) return default;
                    pos = close + 3;
                    continue;
                }
                if (MatchesAt(pos, "<![CDATA["))
                {
                    int close = IndexOf(pos + 9, "]]>");
                    if (close < 0) return default;
                    pos = close + 3;
                    continue;
                }
                if (pos + 1 < _source.Length && _source[pos + 1] == '?')
                {
                    int close = IndexOf(pos + 2, "?>");
                    if (close < 0) return default;
                    pos = close + 2;
                    continue;
                }
                if (pos + 1 < _source.Length && _source[pos + 1] == '/')
                {
                    pos += 2;
                    ScanWhitespace(ref pos);
                    if (!ScanNcName(ref pos))
                        return default;
                    ScanWhitespace(ref pos);
                    if (pos >= _source.Length || _source[pos] != '>')
                        return default;
                    pos++;
                    depth--;
                    if (depth == 0)
                        return new Token(TokenKind.Constructor, start, pos - start);
                    continue;
                }
                if (pos + 1 < _source.Length && IsNameStartChar(_source[pos + 1]))
                {
                    pos++;
                    if (!ScanNcName(ref pos))
                        return default;
                    bool selfClosed = false;
                    while (true)
                    {
                        ScanWhitespace(ref pos);
                        if (pos >= _source.Length)
                            return default;
                        char c2 = _source[pos];
                        if (c2 == '>')
                        {
                            pos++;
                            break;
                        }
                        if (c2 == '/' && pos + 1 < _source.Length && _source[pos + 1] == '>')
                        {
                            pos += 2;
                            selfClosed = true;
                            break;
                        }
                        if (!ScanNcName(ref pos))
                            return default;
                        ScanWhitespace(ref pos);
                        if (pos >= _source.Length || _source[pos] != '=')
                            return default;
                        pos++;
                        ScanWhitespace(ref pos);
                        if (pos >= _source.Length || (_source[pos] != '"' && _source[pos] != '\''))
                            return default;
                        char quote2 = _source[pos++];
                        if (!ScanConstructorAttributeValue(ref pos, quote2))
                            return default;
                    }
                    if (!selfClosed)
                        depth++;
                    continue;
                }
                return default;
            }
            if (c == '{')
            {
                if (pos + 1 < _source.Length && _source[pos + 1] == '{')
                {
                    pos += 2;
                    continue;
                }
                if (!ScanBalancedBraces(ref pos))
                    return default;
                continue;
            }
            if (c == '}' && pos + 1 < _source.Length && _source[pos + 1] == '}')
            {
                pos += 2;
                continue;
            }
            pos++;
        }
        return default;
    }

    private bool ScanNcName(ref int pos)
    {
        if (pos >= _source.Length || !IsNameStartChar(_source[pos]) || _source[pos] == ':')
            return false;
        pos++;
        while (pos < _source.Length && IsNameChar(_source[pos]) && _source[pos] != ':')
            pos++;
        // Optional prefix:local part.
        if (pos < _source.Length && _source[pos] == ':')
        {
            pos++;
            if (pos >= _source.Length || !IsNameStartChar(_source[pos]) || _source[pos] == ':')
                return false;
            pos++;
            while (pos < _source.Length && IsNameChar(_source[pos]))
                pos++;
        }
        return true;
    }

    private void ScanWhitespace(ref int pos)
    {
        while (pos < _source.Length && char.IsWhiteSpace(_source[pos]))
            pos++;
    }

    private bool MatchesAt(int pos, string text)
        => _source.Length - pos >= text.Length && _source.Slice(pos, text.Length).SequenceEqual(text.AsSpan());

    private int IndexOf(int from, string text)
    {
        int idx = _source.Slice(from).IndexOf(text.AsSpan(), StringComparison.Ordinal);
        return idx < 0 ? -1 : from + idx;
    }

    private bool ScanConstructorAttributeValue(ref int pos, char quote)
    {
        while (pos < _source.Length)
        {
            char c = _source[pos];
            if (c == quote)
            {
                // A doubled quote is an escaped literal quote, not the delimiter.
                if (pos + 1 < _source.Length && _source[pos + 1] == quote)
                {
                    pos += 2;
                    continue;
                }
                pos++;
                return true;
            }
            if (c == '{')
            {
                if (pos + 1 < _source.Length && _source[pos + 1] == '{')
                {
                    pos += 2;
                    continue;
                }
                if (!ScanBalancedBraces(ref pos))
                    return false;
                continue;
            }
            if (c == '}' && pos + 1 < _source.Length && _source[pos + 1] == '}')
            {
                pos += 2;
                continue;
            }
            pos++;
        }
        return false;
    }

    private bool ScanBalancedBraces(ref int pos)
    {
        int depth = 1;
        pos++;
        while (pos < _source.Length)
        {
            char c = _source[pos];
            if (_allowConstructors && c == '(' && pos + 1 < _source.Length && _source[pos + 1] == '#')
            {
                pos += ScanPragmaLength(_source[pos..]);
                continue;
            }

            if (c == '{')
            {
                depth++;
            }
            else if (c == '}')
            {
                depth--;
                if (depth == 0)
                {
                    pos++;
                    return true;
                }
            }
            else if (c == '\'' || c == '"')
            {
                char q = c;
                pos++;
                while (pos < _source.Length)
                {
                    if (_source[pos] == q)
                    {
                        if (pos + 1 < _source.Length && _source[pos + 1] == q)
                        {
                            pos += 2;
                            continue;
                        }
                        break;
                    }
                    pos++;
                }
            }
            else if (c == '(' && pos + 1 < _source.Length && _source[pos + 1] == ':')
            {
                int commentDepth = 1;
                pos += 2;
                while (pos < _source.Length && commentDepth > 0)
                {
                    if (_source[pos] == '(' && pos + 1 < _source.Length && _source[pos + 1] == ':')
                    {
                        commentDepth++;
                        pos += 2;
                    }
                    else if (_source[pos] == ':' && pos + 1 < _source.Length && _source[pos + 1] == ')')
                    {
                        commentDepth--;
                        pos += 2;
                    }
                    else
                    {
                        pos++;
                    }
                }
                continue;
            }
            pos++;
        }
        return false;
    }

    // ------------------------------------------------------------------
    // Character classification
    // ------------------------------------------------------------------

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private static bool IsNameStartChar(char c)
    {
        // XML 1.0 NameStartChar production (excluding supplementary characters,
        // which are not representable in a single C# char).
        return c == ':'
            || c == '_'
            || (c >= 'A' && c <= 'Z')
            || (c >= 'a' && c <= 'z')
            || (c >= '\u00C0' && c <= '\u00D6')
            || (c >= '\u00D8' && c <= '\u00F6')
            || (c >= '\u00F8' && c <= '\u02FF')
            || (c >= '\u0370' && c <= '\u037D')
            || (c >= '\u037F' && c <= '\u1FFF')
            || (c >= '\u200C' && c <= '\u200D')
            || (c >= '\u2070' && c <= '\u218F')
            || (c >= '\u2C00' && c <= '\u2FEF')
            || (c >= '\u3001' && c <= '\uD7FF')
            || (c >= '\uF900' && c <= '\uFDCF')
            || (c >= '\uFDF0' && c <= '\uFFFD');
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private static bool IsNameChar(char c)
    {
        return IsNameStartChar(c)
            || c == '-'
            || c == '.'
            || (c >= '0' && c <= '9')
            || c == '\u00B7'
            || (c >= '\u0300' && c <= '\u036F')
            || (c >= '\u203F' && c <= '\u2040');
    }

    // ------------------------------------------------------------------
    // XQuery string constructors
    // ------------------------------------------------------------------

    // Scans the body of a string constructor starting just past the opening "``[".
    // Returns the position just past the closing "]``" or -1 when unterminated.
    // Interpolations are skipped with full expression awareness: string literals,
    // nested comments, brace depth, and nested string constructors.
    private int ScanStringConstructorEnd(int pos)
    {
        while (pos < _source.Length)
        {
            char c = _source[pos];
            if (c == ']' && pos + 2 < _source.Length && _source[pos + 1] == '`' && _source[pos + 2] == '`')
                return pos + 3;
            if (c == '`' && pos + 1 < _source.Length && _source[pos + 1] == '{')
            {
                pos = ScanStringInterpolationEnd(pos + 2);
                if (pos < 0)
                    return -1;
                continue;
            }
            pos++;
        }
        return -1;
    }

    // Scans one string-constructor interpolation body starting just past "`{".
    // Returns the position just past the closing "}`" or -1 when unterminated.
    private int ScanStringInterpolationEnd(int pos)
    {
        int depth = 1;
        while (pos < _source.Length)
        {
            char c = _source[pos];
            if (_allowConstructors && c == '(' && pos + 1 < _source.Length && _source[pos + 1] == '#')
            {
                pos += ScanPragmaLength(_source[pos..]);
                continue;
            }

            if (c == '\'' || c == '"')
            {
                char q = c;
                pos++;
                while (pos < _source.Length)
                {
                    if (_source[pos] == q)
                    {
                        if (pos + 1 < _source.Length && _source[pos + 1] == q)
                        {
                            pos += 2;
                            continue;
                        }
                        pos++;
                        break;
                    }
                    pos++;
                }
                continue;
            }
            if (c == '(' && pos + 1 < _source.Length && _source[pos + 1] == ':')
            {
                int commentDepth = 1;
                pos += 2;
                while (pos < _source.Length && commentDepth > 0)
                {
                    if (_source[pos] == '(' && pos + 1 < _source.Length && _source[pos + 1] == ':') { commentDepth++; pos += 2; }
                    else if (_source[pos] == ':' && pos + 1 < _source.Length && _source[pos + 1] == ')') { commentDepth--; pos += 2; }
                    else pos++;
                }
                continue;
            }
            if (c == '`' && pos + 2 < _source.Length && _source[pos + 1] == '`' && _source[pos + 2] == '[')
            {
                // A nested string constructor inside the interpolation expression.
                pos = ScanStringConstructorEnd(pos + 3);
                if (pos < 0)
                    return -1;
                continue;
            }
            if (c == '{')
            {
                depth++;
                pos++;
                continue;
            }
            if (c == '}')
            {
                depth--;
                if (depth == 0)
                {
                    // The interpolation must close with '}`'.
                    if (pos + 1 < _source.Length && _source[pos + 1] == '`')
                        return pos + 2;
                    return -1;
                }
                pos++;
                continue;
            }
            pos++;
        }
        return -1;
    }

    // Scans the body of an XPath 4.0 string template starting just past the opening
    // backtick. Fixed parts may contain '{{', '}}' and '``' escapes; a lone '{'
    // opens an interpolation (closed by the matching '}'), a lone backtick ends the
    // template. Returns the position just past the closing backtick or -1 when
    // unterminated (including an unterminated interpolation).
    private int ScanStringTemplateEnd(int pos)
    {
        while (pos < _source.Length)
        {
            char c = _source[pos];
            if (c == '`')
            {
                // Longest token wins: '``' is an escaped backtick, a lone backtick ends
                // the template.
                if (pos + 1 < _source.Length && _source[pos + 1] == '`')
                {
                    pos += 2;
                    continue;
                }
                return pos + 1;
            }
            if (c == '{')
            {
                if (pos + 1 < _source.Length && _source[pos + 1] == '{')
                {
                    pos += 2; // escaped '{'
                    continue;
                }
                pos = ScanTemplateInterpolationEnd(pos + 1);
                if (pos < 0)
                    return -1;
                continue;
            }
            if (c == '}' && pos + 1 < _source.Length && _source[pos + 1] == '}')
            {
                pos += 2; // escaped '}'
                continue;
            }
            pos++;
        }
        return -1;
    }

    // Scans one string-template interpolation body starting just past the opening '{'.
    // Strings, comments, and nested string templates are skipped; the interpolation
    // ends at the '}' that closes brace depth zero. Returns the position just past
    // that '}' or -1 when unterminated.
    private int ScanTemplateInterpolationEnd(int pos)
    {
        int depth = 1;
        while (pos < _source.Length)
        {
            char c = _source[pos];
            if (c == '\'' || c == '"')
            {
                char q = c;
                pos++;
                while (pos < _source.Length)
                {
                    if (_source[pos] == q)
                    {
                        if (pos + 1 < _source.Length && _source[pos + 1] == q)
                        {
                            pos += 2;
                            continue;
                        }
                        pos++;
                        break;
                    }
                    pos++;
                }
                continue;
            }
            if (c == '(' && pos + 1 < _source.Length && _source[pos + 1] == ':')
            {
                int commentDepth = 1;
                pos += 2;
                while (pos < _source.Length && commentDepth > 0)
                {
                    if (_source[pos] == '(' && pos + 1 < _source.Length && _source[pos + 1] == ':') { commentDepth++; pos += 2; }
                    else if (_source[pos] == ':' && pos + 1 < _source.Length && _source[pos + 1] == ')') { commentDepth--; pos += 2; }
                    else pos++;
                }
                continue;
            }
            if (c == '`')
            {
                // A nested string template inside the interpolation expression. The
                // '``' escape cannot appear here (an interpolation is an Expr, where
                // '``' is not a lexical unit), so a backtick always opens a template.
                pos = ScanStringTemplateEnd(pos + 1);
                if (pos < 0)
                    return -1;
                continue;
            }
            if (c == '{')
            {
                depth++;
                pos++;
                continue;
            }
            if (c == '}')
            {
                depth--;
                if (depth == 0)
                    return pos + 1;
                pos++;
                continue;
            }
            pos++;
        }
        return -1;
    }
}
