// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 19 mei 2026
// PURPOSE              : Recursive-descent parser for XPath 3.1. Consumes tokens from <see cref="XPathLexer"/> and produce...
// SPECIAL NOTES        : Part of the Bosak XPath 3.1 implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
//                      |                  |       |                | allowPrefixedBracedLocal for Q{uri}prefix:local                                        |
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 19-05-2026     | Creation                                                                                 |
//                      | Charles Korthout | 0.2   | 19-05-2026     | Added SimpleMap (!) expression parsing                                                 |
//                      | Charles Korthout | 0.3   | 19-05-2026     | Added string literal lookup keys and LookupWildcardNode                                |
//                      | Charles Korthout | 0.4   | 19-05-2026     | Parse sequence type occurrence indicators (*, +, ?)                                    |
//                      | Charles Korthout | 0.5   | 19-05-2026     | Support inline functions as arrow expression targets                                   |
//                      | Charles Korthout | 0.6   | 21-05-2026     | Fixed SkipSequenceType RParen consumption; ParseSequenceType handles item()/function(*)/empty-sequence() |
//                      | Charles Korthout | 0.7   | 26-05-2026     | Added ExpectName() to allow XPath keywords as variable names ($mod, $div, etc.)                       |
//                      | Charles Korthout | 0.8   | 31-05-2026     | decimal.TryParse fallback to double for oversized decimal literals                       |
//                      | Charles Korthout | 0.9   | 10-06-2026     | Kind-test parsing no longer treats prefixed names (e.g. my:node()) as kind tests         |
//                      | Charles Korthout | 0.9   | 01-06-2026     | Prevent map/array/function keywords from being parsed as name tests in step expr       |
//                      | Charles Korthout | 1.0   | 01-06-2026     | ParseAxisStep defaults to attribute/namespace axis for attribute()/namespace-node()    |
//                      | Charles Korthout | 1.1   | 05-06-2026     | Fixed SkipSequenceType to use token char spans; ParseTypeNameAndParens consumes function return type |
//                      | Charles Korthout | 1.2   | 05-06-2026     | Added XQST0039 duplicate parameter name check in ParseInlineFunction                     |
//                      | Charles Korthout | 1.3   | 11-06-2026     | xml prefix falls back to PrefixedName; other prefixes use QName for NamespaceTest       |
//                      | Charles Korthout | 1.4   | 13-06-2026     | Empty-URI EQName support in SplitQName (Q{}local)                                       |
//                      | Charles Korthout | 1.5   | 13-06-2026     | Resolve xml prefix in node tests to the XML namespace                                    |
//                      | Charles Korthout | 1.6   | 13-06-2026     | Fixed Unquote to preserve doubled quotes that do not match the enclosing delimiter      |
//                      | Charles Korthout | 1.7   | 26-06-2026     | Static errors for removed map functions and obsolete map namespace; XPST0003 for :=    |
//                      | Charles Korthout | 1.8   | 15-07-2026     | UnaryLookup (?KS ≡ .?KS); empty-paren lookup key .?(); keyword NCName lookup keys; qualified-name keys are XPST0003; argument-placeholder vs lookup disambiguation |
//                      | Charles Korthout | 1.8   | 26-06-2026     | Parse Q{uri}* URI-qualified wildcards                                                    |
//                      | Charles Korthout | 1.9   | 15-07-2026     | Keep ' as ' separated in nested function tests inside map/array type parens (ArrayTest-063) |
//                      | Charles Korthout | 1.10  | 15-07-2026     | FLWOR completion: 'at $pos' positional var, 'where' clause, mixed for/let chains          |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.11  | 15-07-2026     | EQName URI whitespace normalized in SplitQName; for/let bindings capture prefix/namespace |
//                      | Charles Korthout | 1.12  | 19-07-2026     | Reserved function names in function calls and named function references raise XPST0003    |
//                      | Charles Korthout | 1.13  | 19-07-2026     | Reserved function name check applies only to named function references, not function calls |
//                      | Charles Korthout | 1.14  | 20-07-2026     | Allow 'is' as a non-reserved function name in function calls (K-NodeSame-6)              |
//                      | Charles Korthout | 1.15  | 20-07-2026     | Only treat 'for'/'let' as FLWOR keywords when followed by '$' (K2-NameTest-78/79)        |
//                      | Charles Korthout | 1.16  | 20-07-2026     | Disallow consecutive for/let clauses in FLWOR (XPath-only; LetExpr020a)                   |
//                      | Charles Korthout | 1.17  | 20-07-2026     | Require closing parenthesis in sequence type tests (K-SeqExprTreat-16)                    |
//                      | Charles Korthout | 1.18  | 22-07-2026     | Parse full XQuery FLWOR with order by, empty order, and collation                       |
//                      | Charles Korthout | 1.19  | 22-07-2026     | Added allowFullFlwor flag to Parse; XPath-only mode rejects multi-clause FLWOR/order by |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.20  | 23-07-2026     | Parse XQuery FLWOR count clause                                                           |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.21  | 25-07-2026     | Parse XQuery FLWOR group by clause                                                        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.22  | 25-07-2026     | Parse XQuery FLWOR window clause (tumbling/sliding)                                       |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.23  | 25-07-2026     | Optional window end condition; XQST0103; stable order by; 'as' type declarations        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.24  | 25-07-2026     | Direct element/comment/PI constructors; allowing empty; XQST0118 tag mismatch           |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.25  | 25-07-2026     | Constructor validations: XQST0022/0046/0070/0071/0090; CDATA/ref text; empty-expr rules |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.26  | 25-07-2026     | Parse XQuery computed constructors; EQName char/entity reference expansion; boundary-whitespace CDATA fix |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.27  | 25-07-2026     | Parse XQuery switch and typeswitch expressions incl. sequence-type unions in case clauses |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.28  | 25-07-2026     | xml:space is an ordinary constructor attribute; boundary whitespace stripped at flush time |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.29  | 26-07-2026     | SkipSequenceType stops at expression boundaries (:=/in/return/then/else/|) after function-type 'as' |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.30  | 27-07-2026     | Full try/catch parsing: named code patterns, multiple clauses, empty bodies |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.31  | 27-07-2026     | String constructor scanning; XPath-mode string literals no longer expand references |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.32  | 27-07-2026     | ordered/unordered expressions (identity); empty bodies; explicit empty least/greatest tracked |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.33  | 28-07-2026     | PI kind test: trimmed NCName argument with XPTY0004/XPST0003; kind-test schema type names captured |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.34  | 29-07-2026     | ParseExprSingle entry point: single ExprSingle, trailing tokens raise XPST0003 |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.35  | 29-07-2026     | XQuery annotations: inline-function annotations, function-test assertions (XQuery-only, literals only) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.36  | 29-07-2026     | Char-reference validation: XQST0090 for invalid/overflow values, XPST0003 for malformed refs |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.37  | 29-07-2026     | XQST0089 positional-variable duplicate; XQST0125 for %public/%private inline annotations |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.38  | 29-07-2026     | Map-constructor key disambiguation: gated wildcard name tests, '*:b:b' token split |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.39  | 29-07-2026     | For-binding grammar order: 'allowing empty' precedes the positional variable |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.40  | 29-07-2026     | Parenthesized sequence types in 'as' declarations |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.41  | 29-07-2026     | Constructor steps after /; '<' after slash is XPST0003; schema-attribute and namespace-node() kind-test errors |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.42  | 01-08-2026     | Boundary-space policy flag (strip default; preserve keeps whitespace-only runs)      |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.43  | 07-08-2026     | EQName ':'-after-brace XPST0003 and xmlns-URI XQST0070; namespace-decl URI whitespace accepted; PI target NCName check; inline-function duplicate params compare expanded names; group-by 'as' requires ':='; reserved function names rejected in calls |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.44  | 18-08-2026     | Treat 'if' as conditional only when followed by '('; otherwise name test (K2-NameTest-5) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.44  | 07-08-2026     | Q{uri}:* name test is malformed — XPST0003 (nametest-23)                            |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.45  | 07-08-2026     | Empty enclosed expressions allowed (XQ31); whitespace required between constructor attributes (XPST0003); XML 1.0 line-ending normalization for literal characters in XQuery string literals |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.46  | 18-08-2026     | Named-function-ref arity > Int32 clamps to int.MaxValue so resolution fails with FOAR0002 (fn-function-arity-017/fn-function-name-018) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.47  | 18-08-2026     | Normalize line endings before XML attribute-value whitespace normalization (K2-DirectConElemAttr-75) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.48  | 21-08-2026     | Preserve Q{uri}local EQName form for user-defined sequence types in ParseTypeNameAndParens |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.49  | 22-08-2026     | ParseSingleType treats * and + after a cast target as operators when an operand follows |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.50  | 22-08-2026     | Parse XQuery validate expressions (strict/lax/no mode) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.51  | 22-08-2026     | Treat 'validate' as a contextual XQuery keyword (Name token) |
//                      | Charles Korthout | 1.52  | 23-08-2026     | Parse XQuery validate type QName { Expr } syntax |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.53  | 23-08-2026     | Allow keywords as unprefixed function names when followed by '(' or '#' (xquery30keywords5) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.54  | 07-09-2026     | Static errors: wildcard-QName trivia gaps, kind-test arguments, document-node content... |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.55  | 09-09-2026     | Operator/invalid tokens rejected as function names (K-NodeAfter/Before-5/7, K-FunctionCallExpr-9); empty-sequence() occurrence indicator is XPST0003 (K-QuantExprWith-7/8); typed function test requires 'as' return type (hof-910) |
//                      | Charles Korthout | 1.56  | 09-09-2026     | Integer literals beyond long range tagged IsIntegerLiteral (stay xs:integer)             |
//                      | Charles Korthout | 1.57  | 09-09-2026     | XML doc coverage on public API (Beta review)                                             |
//                      | Charles Korthout | 1.58  | 21-09-2026     | Braced-URI names (Q{uri}local) in step position are function calls, never kind tests   |
//                      | Charles Korthout | 1.59  | 21-09-2026     | API freeze stage A: internalized (IVT for in-repo consumers)                           |
//                      | Charles Korthout | 1.60  | 21-09-2026     | API freeze stage A: ParseException renamed to XPathParseException                      |
//                      |                  |       |                | (A ! Q{ns}text(...) misparsed as text() step; sx-treat-107/108/109, sx-instance-of-107/108) |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.61  | 24-09-2026     | REQ-104: schemaAware parse option — schema-element()/schema-attribute() unprefixed     |
//                      |                  |       |                | names no longer raise XPST0008 when schema awareness is enabled                        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.62  | 30-09-2026     | REQ-114/PB-3 C9: ParseDocumentNodeContent surfaces the inner element() type name so   |
//                      |                  |       |                | document-node(element(E,T)) keeps T in the NodeTest (validation-1401)                  |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.63  | 08-10-2026     | REQ-118 4.0-S3a: xpath40 parse option — '??' otherwise operator (OtherwiseExpr between  |
//                      |                  |       |                | ComparisonExpr and StringConcatExpr) and 0x/0b/underscore numeric literals              |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.64  | 08-10-2026     | REQ-118 4.0-S3b: keyword arguments in ParseArgumentList (4.0-only, XPST0003 in 3.1,   |
//                      |                  |       |                | positional-after-keyword XPST0003, dynamic-call rejection XPST0017) and XPath 4.0      |
//                      |                  |       |                | string templates (ParseStringTemplate + interpolation scanning)                         |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.65  | 08-10-2026     | REQ-118 4.0-S4: '->' pipeline (PipelineExpr), '=!>' mapping arrow desugar, 'fn' focus  |
//                      |                  |       |                | functions, 'for member'/'for key value' bindings (XPath 4.0, XPST0003 in 3.1)           |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.66  | 08-10-2026     | REQ-118 4.0-S6a: enum types + choice item types in ItemType positions (XPST0003 in 3.1)|
//                      | Charles Korthout | 1.67  | 08-10-2026     | REQ-118 4.0-S6b: record types in ItemType positions + 'but with' operator (XPST0003 in 3.1)|
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.68  | 09-10-2026     | REQ-123 parse-csv: bare {…} map constructor (XPath 4.0 "map"? "{" … "}", PR2778;          |
//                      |                  |       |                | XPST0003 in 3.1) as a PrimaryExpr sibling of the 'map {' keyword form                    |
//                      |------------------|-------|----------------|------------------------------------------------------------------------------------------|
//                      | Charles Korthout | 1.69  | 09-10-2026     | REQ-123 element-to-map slice: PR2688 string-literal lookup step E/"key" (unquoted key,   |
//                      |                  |       |                | LookupKey NodeTest) only in NON-first step position — a first-position string literal    |
//                      |                  |       |                | remains a primary expression so function arguments like parse-xml('<a/>') keep working   |
//                      |------------------|-------|----------------|------------------------------------------------------------------------------------------|
//                      | Charles Korthout | 1.70  | 10-10-2026     | REQ-123 fn:atomic-equal slice (4.0 parser companions): '=>' arrow targets accept the      |
//                      |                  |       |                | quantifier keywords as function names ($s => every()); if expressions accept EnclosedExpr |
//                      |                  |       |                | ("{" Expr "}") branches in place of then/else, with 'else' omittable for a braced then   |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.71  | 10-10-2026     | REQ-123 sort-with slice: '?' lookup accepts a variable reference as key ($map?$key,       |
//                      |                  |       |                | spec PR2962) alongside literals, NCNames, and parenthesized keys                           |
//                      | Charles Korthout | 1.72  | 10-10-2026     | REQ-123 compare-tail slice: # QName literals (PR1976/PR2227, XPST0154); SplitQName     |
//                      |                  |       |                | allowPrefixedBracedLocal for Q{uri}prefix:local                                        |
//                      |==================|=======|================|=========================================================================================
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.73   | 10-10-2026     | REQ-123 JNode cluster: integer-literal lookup step (E/2) and braced key selector
//                      | Charles Korthout |        |                | child::{K} (PR2667) in step position
//                      |------------------|-------|----------------|------------------------------------------------------------------------------------------
//                      | Charles Korthout | 1.74  | 10-10-2026     | REQ-123 destructuring let (PR1131): let $(...)/$[...]/${...} bindings with per-variable |
//                      |                  |       |                | and whole-pattern type declarations (XPST0003 in 3.1); 'as' allowed in simple let      |
//                      |                  |       |                | bindings at XPath 4.0                                                                  |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 1.75  | 13-10-2026     | Parse XPath 4.0 inline namespace declarations
//                      | Charles Korthout | 1.76  | 13-10-2026     | Validate targeted processing-instruction sequence types with shared target parsing
//                      | Charles Korthout | 1.77 | 13-10-2026     | Parse XPath 4.0 fn function types and documentary parameters
//                      | Charles Korthout | 1.78 | 22-10-2026     | Gate record types while retaining inline-function signature text in older profiles.
//                      | Charles Korthout | 1.79  | 28-10-2026     | Distinguish literal child elements from enclosed-expression node copies (1.31.0). |
//                      | Charles Korthout | 1.80  | 28-10-2026     | Parse ValidateExpr at ValueExpr precedence; require parentheses for path/postfix use (1.32.0). |
//                      | Charles Korthout | 1.81  | 28-10-2026     | Implement statically validated ignored-pragma fallback and raw scanning (1.33.0). |
// ===========================================================================================================================================================
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text;
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Parser.Lexer;

namespace Bosak.XPath.Parser.Ast;

/// <summary>
/// Recursive-descent parser for XPath 3.1.
/// Consumes tokens from <see cref="XPathLexer"/> and produces an immutable AST.
/// </summary>
internal sealed class XPathParser
{
    private Token[] _tokens;
    private readonly string _source;
    private readonly bool _allowFullFlwor;
    private bool _xml11LineEndings;
    // Boundary-space policy for direct element constructors: true = strip (the spec
    // default), false = preserve whitespace-only text runs at content boundaries.
    private bool _boundarySpaceStrip = true;
    // Schema awareness (REQ-104): when true, schema-element()/schema-attribute() kind
    // tests parse without the no-schema-awareness XPST0008; declaration existence is
    // validated against the compiled schema set at compile time (XPST0008 when absent).
    private bool _schemaAware;
    // XPath 4.0 grammar features (REQ-118): the '??' otherwise operator and
    // hexadecimal/binary/underscore numeric literals. False = XPath 3.1 (default):
    // an Otherwise token is rejected with XPST0003.
    private bool _xpath40;
    private int _position;
    // > 0 while parsing a map-constructor key: '*:local' name tests are no longer
    // greedy — the entry ':' must follow the local name (map{* :b}, MapConstructor-020).
    private int _mapKeyDepth;

    /// <summary>
    /// Initializes a parser over a pre-lexed token stream.
    /// </summary>
    /// <param name="tokens">The tokens produced by <see cref="XPathLexer"/>, excluding the final Eof token.</param>
    /// <param name="source">The original source text the tokens were scanned from (used for token text and spans).</param>
    /// <param name="allowFullFlwor">When true, allows full XQuery FLWOR syntax (multiple for/let/where/order-by clauses).</param>
    public XPathParser(Token[] tokens, string source, bool allowFullFlwor = false)
    {
        _tokens = tokens;
        _source = source;
        _allowFullFlwor = allowFullFlwor;
        _position = 0;
    }

    // Functions removed from the XPath / XSLT 3.0 specifications. Calls to these
    // are reported as static errors (XPST0017) at parse time.
    private static readonly HashSet<(string NamespaceUri, string LocalName)> RemovedFunctions = new()
    {
        ("http://www.w3.org/2005/xpath-functions/map", "new"),
        ("http://www.w3.org/2005/xpath-functions/map", "for-each-entry"),
        ("http://www.w3.org/2005/xpath-functions/map", "collation"),
        ("http://www.w3.org/2005/xpath-functions", "deep-equal2"),
    };

    private const string OldMapNamespace = "http://www.w3.org/2011/xpath-functions/map";

    /// <summary>
    /// XPath reserved function names. These cannot be used as function names in
    /// function calls or named function references when the name has no prefix
    /// (i.e., is in the default function namespace).
    /// </summary>
    private static readonly HashSet<string> ReservedFunctionNames = new(StringComparer.Ordinal)
    {
        "attribute", "comment", "document-node", "element", "empty-sequence",
        "function", "if", "item", "namespace-node", "node", "processing-instruction",
        "schema-attribute", "schema-element", "switch", "text", "typeswitch",
        "array", "map"
    };

    /// <summary>
    /// Convenience method: lexes and parses an XPath expression string.
    /// </summary>
    /// <param name="xpath">The XPath expression to parse.</param>
    /// <param name="allowFullFlwor">When true, allows full XQuery FLWOR syntax (multiple for/let/where/order-by clauses). Default is false (XPath-only FLWOR).</param>
    /// <param name="xml11LineEndings">When true, string literals get XML 1.1 line-ending
    /// normalization; when false (default), references produce their exact characters.</param>
    /// <param name="boundarySpaceStrip">When true (the default), whitespace-only text at the
    /// boundaries of direct element constructor content is stripped; false preserves it.</param>
    /// <param name="schemaAware">When true, schema-aware kind tests
    /// (<c>schema-element()</c>/<c>schema-attribute()</c>) are permitted; when false (the
    /// default) an unprefixed name argument raises XPST0008 (no schema awareness).</param>
    /// <param name="xpath40">When true, enables XPath 4.0 grammar extensions: the <c>??</c>
    /// otherwise operator and hexadecimal/binary integer literals with underscore separators.</param>
    /// <returns>The root of the parsed AST.</returns>
    /// <exception cref="XPathParseException">The expression is not syntactically valid.</exception>
    public static XPathAstNode Parse(string xpath, bool allowFullFlwor = false, bool xml11LineEndings = false, bool boundarySpaceStrip = true, bool schemaAware = false, bool xpath40 = false)
    {
        if (xpath40 && !allowFullFlwor)
            xpath = ExtractNamespaceDeclarations(xpath, xpath40: true).Expression;
        var lexer = new XPathLexer(xpath.AsSpan(), allowConstructors: allowFullFlwor, xpath40: xpath40);
        var tokens = new List<Token>();
        Token tok;
        while ((tok = lexer.NextToken()).Kind != TokenKind.Eof)
            tokens.Add(tok);

        var parser = new XPathParser(tokens.ToArray(), xpath, allowFullFlwor) { _xml11LineEndings = xml11LineEndings, _boundarySpaceStrip = boundarySpaceStrip, _schemaAware = schemaAware, _xpath40 = xpath40 };
        return parser.ParseExpression();
    }

    /// <summary>
    /// Convenience method: lexes and parses a single XPath ExprSingle, requiring the whole
    /// input to be consumed. XQuery variable initializers and context-item initial values
    /// are ExprSingle, not Expr (a top-level comma is XPST0003, K2-ExternalVariablesWith-11).
    /// </summary>
    /// <param name="xpath">The XPath expression to parse.</param>
    /// <param name="allowFullFlwor">When true, allows full XQuery FLWOR syntax. Default is false.</param>
    /// <param name="xml11LineEndings">When true, string literals get XML 1.1 line-ending normalization.</param>
    /// <param name="boundarySpaceStrip">When true (the default), whitespace-only text at the
    /// boundaries of direct element constructor content is stripped; false preserves it.</param>
    /// <param name="xpath40">When true, enables XPath 4.0 grammar extensions (see <see cref="Parse"/>).</param>
    /// <returns>The root of the parsed AST.</returns>
    /// <exception cref="XPathParseException">The expression is not syntactically valid, or input remains after the ExprSingle.</exception>
    public static XPathAstNode ParseExprSingle(string xpath, bool allowFullFlwor = false, bool xml11LineEndings = false, bool boundarySpaceStrip = true, bool xpath40 = false)
    {
        var lexer = new XPathLexer(xpath.AsSpan(), allowConstructors: allowFullFlwor, xpath40: xpath40);
        var tokens = new List<Token>();
        Token tok;
        while ((tok = lexer.NextToken()).Kind != TokenKind.Eof)
            tokens.Add(tok);

        var parser = new XPathParser(tokens.ToArray(), xpath, allowFullFlwor) { _xml11LineEndings = xml11LineEndings, _boundarySpaceStrip = boundarySpaceStrip, _xpath40 = xpath40 };
        var result = parser.ParseExprSingle();
        if (!parser.IsAtEnd)
            throw new XPathParseException($"XPST0003: Unexpected token {parser.Current.Kind} after the expression.", parser.Current.Start);
        return result;
    }

    /// <summary>Reads XPath 4.0 namespace declarations without changing expression offsets.</summary>
    internal static (string Expression, Dictionary<string, string> Namespaces, string? DefaultNamespace) ExtractNamespaceDeclarations(string source, bool xpath40)
    {
        var namespaces = new Dictionary<string, string>(StringComparer.Ordinal);
        if (!xpath40)
            return (source, namespaces, null);
        var lexer = new XPathLexer(source.AsSpan(), xpath40: true);
        var tokens = new List<Token>();
        Token token;
        while ((token = lexer.NextToken()).Kind != TokenKind.Eof)
            tokens.Add(token);
        var parser = new XPathParser(tokens.ToArray(), source) { _xpath40 = true };
        bool Is(string word, int offset = 0) => parser.Peek(offset).Kind != TokenKind.Eof && parser.GetString(parser.Peek(offset)) == word;
        void Require(string word)
        {
            if (!Is(word))
                throw new XPathParseException($"XPST0003: Expected '{word}' in namespace declaration.", parser.Current.Start);
            parser.Advance();
        }
        string? defaultNamespace = null;
        while (!parser.IsAtEnd && Is("declare") && (Is("namespace", 1) || Is("default", 1)))
        {
            parser.Advance();
            bool isDefault = Is("default");
            string? prefix = null;
            if (isDefault)
            {
                if (defaultNamespace is not null || namespaces.Count != 0)
                    throw new XPathParseException("XPST0003: The default namespace declaration must occur once, before prefix declarations.", parser.Current.Start);
                Require("default"); Require("element"); Require("namespace");
            }
            else
            {
                Require("namespace");
                prefix = parser.GetString(parser.ExpectName());
                if (prefix.Contains(':') || prefix.StartsWith("Q{", StringComparison.Ordinal))
                    throw new XPathParseException("XPST0003: Namespace prefix must be an NCName.", parser.Current.Start);
                parser.Expect(TokenKind.Equal);
            }
            var uri = parser.Unquote(parser.GetString(parser.Expect(TokenKind.StringLiteral)));
            parser.Expect(TokenKind.Semicolon);
            if (prefix is "xml" or "xmlns" || uri is "http://www.w3.org/XML/1998/namespace" or "http://www.w3.org/2000/xmlns/")
                throw new InvalidOperationException("XQST0070: Reserved namespace prefix or URI in namespace declaration.");
            if (isDefault)
                defaultNamespace = uri;
            else if (!namespaces.TryAdd(prefix!, uri))
                throw new InvalidOperationException($"XQST0033: Duplicate namespace declaration for prefix '{prefix}'.");
        }
        if (parser.End == 0)
            return (source, namespaces, defaultNamespace);
        // Keep line numbers and spans stable for diagnostics and streamability analysis.
        var chars = source.ToCharArray();
        for (int i = 0; i < parser.End; i++)
            if (chars[i] is not ('\r' or '\n')) chars[i] = ' ';
        return (new string(chars), namespaces, defaultNamespace);
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private Token Current => _position < _tokens.Length ? _tokens[_position] : Token.Eof;
    private Token Peek(int offset) => _position + offset < _tokens.Length ? _tokens[_position + offset] : Token.Eof;
    private bool IsAtEnd => _position >= _tokens.Length;

    /// <summary>
    /// True when trivia (whitespace or comments) intervenes between two adjacent tokens.
    /// Wildcard QNames such as <c>*:local</c> and <c>prefix:*</c> are single lexical units:
    /// trivia between their parts is a syntax error (K2-Axes-5..16).
    /// </summary>
    private static bool HasTriviaGap(Token before, Token after) => before.Start + before.Length < after.Start;

    private int End => _position > 0 ? _tokens[_position - 1].Start + _tokens[_position - 1].Length : 0;

    private void Advance() => _position++;

    private bool Match(TokenKind kind)
    {
        if (Current.Kind == kind)
        {
            _position++;
            return true;
        }
        return false;
    }

    private Token Expect(TokenKind kind)
    {
        if (Current.Kind == kind)
        {
            var t = Current;
            _position++;
            return t;
        }
        throw new XPathParseException($"Expected {kind} but found {Current.Kind}", Current.Start);
    }

    /// <summary>
    /// Expects a name token, allowing XPath keywords to be used as names
    /// (e.g., variable names like $mod, $div, $and).
    /// </summary>
    private Token ExpectName()
    {
        if (Current.Kind == TokenKind.Name || IsKeywordName(Current.Kind))
        {
            var t = Current;
            _position++;
            return t;
        }
        throw new XPathParseException($"Expected name but found {Current.Kind}", Current.Start);
    }

    private static bool IsKeywordName(TokenKind kind) => kind switch
    {
        TokenKind.KeywordAnd or TokenKind.KeywordOr or TokenKind.KeywordDiv
        or TokenKind.KeywordIdiv or TokenKind.KeywordMod or TokenKind.KeywordUnion
        or TokenKind.KeywordIntersect or TokenKind.KeywordExcept or TokenKind.KeywordTo
        or TokenKind.KeywordInstance or TokenKind.KeywordOf or TokenKind.KeywordTreat
        or TokenKind.KeywordAs or TokenKind.KeywordCastable or TokenKind.KeywordCast
        or TokenKind.KeywordIf or TokenKind.KeywordThen or TokenKind.KeywordElse
        or TokenKind.KeywordFor or TokenKind.KeywordLet or TokenKind.KeywordIn
        or TokenKind.KeywordReturn or TokenKind.KeywordSome or TokenKind.KeywordEvery
        or TokenKind.KeywordSatisfies or TokenKind.KeywordFunction or TokenKind.KeywordMap
        or TokenKind.KeywordArray or TokenKind.KeywordTry or TokenKind.KeywordCatch
        or TokenKind.ValueEq or TokenKind.ValueNe or TokenKind.ValueLt
        or TokenKind.ValueLe or TokenKind.ValueGt or TokenKind.ValueGe
        or TokenKind.ValueIs => true,
        _ => false
    };

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private static T WithSpan<T>(T node, int start, int end) where T : XPathAstNode
        => node with { Span = new TextSpan(start, end - start) };

    private ReadOnlySpan<char> GetText(Token token) => token.Text(_source.AsSpan());
    private string GetString(Token token) => token.Text(_source.AsSpan()).ToString();
    private string GetSpanText(int start, int end) => _source[start..end];

    // ------------------------------------------------------------------
    // Entry point
    // ------------------------------------------------------------------

    /// <summary>
    /// Parses the token stream as a complete XPath expression, requiring all tokens to be consumed.
    /// </summary>
    /// <returns>The root of the parsed AST.</returns>
    /// <exception cref="XPathParseException">The token stream is not a syntactically valid expression, or tokens remain after it.</exception>
    public XPathAstNode ParseExpression()
    {
        int start = Current.Start;
        var expr = ParseExpr();
        if (!IsAtEnd)
            throw new XPathParseException($"Unexpected token {Current.Kind}", Current.Start);
        return expr;
    }

    // ------------------------------------------------------------------
    // Expression hierarchy (lowest → highest precedence)
    // ------------------------------------------------------------------

    // Expr ::= ExprSingle ("," ExprSingle)*
    private XPathAstNode ParseExpr()
    {
        int start = Current.Start;
        var exprs = new List<XPathAstNode> { ParseExprSingle() };
        while (Match(TokenKind.Comma))
            exprs.Add(ParseExprSingle());

        if (exprs.Count == 1) return exprs[0];
        return WithSpan(new SequenceExpressionNode(exprs), start, End);
    }

    // ExprSingle ::= ForExpr | QuantifiedExpr | IfExpr | OrExpr
    private XPathAstNode ParseExprSingle()
    {
        return Current.Kind switch
        {
            // 'for' and 'let' are FLWOR keywords only when followed by a variable binding.
            // Otherwise they are ordinary names (e.g., name tests) (K2-NameTest-78/79).
            TokenKind.KeywordFor when Peek(1).Kind == TokenKind.Dollar => ParseForExpr(),
            TokenKind.KeywordFor when _allowFullFlwor && IsWindowKeyword(Peek(1)) => ParseForExpr(),
            // XPath 4.0 §4.14.1: 'for member' / 'for key value' bindings iterate arrays/maps.
            TokenKind.KeywordFor when IsMemberEntryBindingStart(Peek(1)) && _xpath40 => ParseForExpr(),
            TokenKind.KeywordFor when IsMemberEntryBindingStart(Peek(1)) =>
                throw new XPathParseException("XPST0003: A 'for member' or 'for key value' binding requires XPath 4.0.", Current.Start),
            TokenKind.KeywordLet when Peek(1).Kind == TokenKind.Dollar => ParseLetExpr(),
            // 'some'/'every' are quantifier keywords only when not followed by '(' or '#'.
            // When they are, they are ordinary function names (xquery30keywords5).
            TokenKind.KeywordSome or TokenKind.KeywordEvery when Peek(1).Kind is TokenKind.LParen or TokenKind.Hash => ParseOrExpr(),
            TokenKind.KeywordSome or TokenKind.KeywordEvery => ParseQuantifiedExpr(),
            // 'if' is the conditional keyword only when followed by '('. Otherwise it
            // is an ordinary name (e.g., a name test) (K2-NameTest-5).
            TokenKind.KeywordIf when Peek(1).Kind == TokenKind.LParen => ParseIfExpr(),
            // 'try' introduces try/catch only when followed by '{'. When followed by '(' or '#'
            // it is an ordinary function name (xquery30keywords5).
            TokenKind.KeywordTry when Peek(1).Kind is TokenKind.LParen or TokenKind.Hash => ParseOrExpr(),
            TokenKind.KeywordTry => ParseTryExpr(),
            // switch/typeswitch are XQuery-only ExprSingle forms; 'switch'/'typeswitch'
            // followed by '(' anywhere else remains an ordinary name (K2-NameTest-*).
            TokenKind.Name when _allowFullFlwor && GetString(Current) == "switch" && Peek(1).Kind == TokenKind.LParen => ParseSwitchExpr(),
            TokenKind.Name when _allowFullFlwor && GetString(Current) == "typeswitch" && Peek(1).Kind == TokenKind.LParen => ParseTypeswitchExpr(),
            _ => ParseOrExpr()
        };
    }

    // FLWORExpr ::= InitialClause IntermediateClause* "return" ExprSingle
    // InitialClause ::= ForClause | LetClause
    // IntermediateClause ::= ForClause | LetClause | WhereClause | CountClause | OrderByClause | GroupByClause
    // ForClause ::= "for" ForBinding ("," ForBinding)*
    // ForBinding ::= "$" VarName ("at" "$" VarName)? "in" ExprSingle
    // LetClause ::= "let" LetBinding ("," LetBinding)*
    // LetBinding ::= "$" VarName (TypeDeclaration)? ":=" ExprSingle        (XPath 3.1 / XQuery)
    //              | "$" DestructuringPattern (TypeDeclaration)? ":=" ExprSingle   (XPath 4.0, PR1131)
    // DestructuringPattern ::= ("(" | "[" | "{") "$" VarName (TypeDeclaration)? ("," ...)* (")" | "]" | "}")
    // WhereClause ::= "where" ExprSingle
    // CountClause ::= "count" "$" VarName
    // OrderByClause ::= "order by" OrderSpec ("," OrderSpec)*
    // OrderSpec ::= ExprSingle ("ascending" | "descending")? ("empty" ("least" | "greatest"))? ("collation" URILiteral)?
    // GroupByClause ::= "group by" GroupingSpec ("," GroupingSpec)*
    // GroupingSpec ::= "$" VarName (":=" ExprSingle)? ("collation" URILiteral)?
    // WindowClause ::= "for" ("tumbling" | "sliding") "window" "$" VarName "in" ExprSingle WindowStartCondition WindowEndCondition?
    // WindowStartCondition ::= "start" WindowVars "when" ExprSingle
    // WindowEndCondition ::= ("only")? "end" WindowVars "when" ExprSingle
    // WindowVars ::= ("$" VarName)? ("at" "$" VarName)? ("previous" "$" VarName)? ("next" "$" VarName)?
    private XPathAstNode ParseForExpr() => ParseFlworExpr();

    private XPathAstNode ParseLetExpr() => ParseFlworExpr();

    private XPathAstNode ParseFlworExpr()
    {
        int start = Current.Start;
        var clauses = new List<FlworClauseNode>();

        // Initial clause (dispatch guarantees 'for' or 'let').
        if (Current.Kind == TokenKind.KeywordFor)
        {
            if (IsWindowKeyword(Peek(1)))
            {
                if (!_allowFullFlwor)
                    throw new XPathParseException("XPST0003: XPath does not allow a window clause.", Current.Start);
                clauses.Add(ParseWindowClause());
            }
            else
            {
                clauses.Add(new ForClauseNode(ParseForClauseBindings()));
            }
        }
        else
        {
            clauses.Add(new LetClauseNode(ParseLetClauseBindings()));
        }

        // Intermediate clauses.
        while (true)
        {
            if (Current.Kind == TokenKind.KeywordFor)
            {
                // XPath 3.1 allows a single for/let clause (LetExpr020a); XPath 4.0
                // permits consecutive for/let clauses like XQuery (csv-doc-008).
                if (!_allowFullFlwor && !_xpath40)
                    throw new XPathParseException("XPST0003: XPath does not allow multiple for/let clauses in a FLWOR expression.", Current.Start);
                if (IsWindowKeyword(Peek(1)))
                    clauses.Add(ParseWindowClause());
                else
                    clauses.Add(new ForClauseNode(ParseForClauseBindings()));
            }
            else if (Current.Kind == TokenKind.KeywordLet)
            {
                if (!_allowFullFlwor && !_xpath40)
                    throw new XPathParseException("XPST0003: XPath does not allow multiple for/let clauses in a FLWOR expression.", Current.Start);
                clauses.Add(new LetClauseNode(ParseLetClauseBindings()));
            }
            else if (Current.Kind == TokenKind.Name && GetString(Current) == "where")
            {
                Advance();
                clauses.Add(new WhereClauseNode(ParseExprSingle()));
            }
            else if (Current.Kind == TokenKind.Name && GetString(Current) == "count" && Peek(1).Kind == TokenKind.Dollar)
            {
                if (!_allowFullFlwor)
                    throw new XPathParseException("XPST0003: XPath does not allow a count clause.", Current.Start);
                Advance();
                Expect(TokenKind.Dollar);
                var nameTok = ExpectName();
                var (prefix, local, ns) = SplitQName(GetString(nameTok));
                clauses.Add(new CountClauseNode(local, prefix, ns));
            }
            else if (Current.Kind == TokenKind.Name && GetString(Current) == "order")
            {
                if (!_allowFullFlwor)
                    throw new XPathParseException("XPST0003: XPath does not allow an order by clause.", Current.Start);
                Advance();
                if (Current.Kind == TokenKind.Name && GetString(Current) == "by")
                {
                    Advance();
                    clauses.Add(new OrderByClauseNode(ParseOrderBySpecs()));
                }
                else
                {
                    throw new XPathParseException("XPST0003: Expected 'by' after 'order'.", Current.Start);
                }
            }
            else if (Current.Kind == TokenKind.Name && GetString(Current) == "stable" &&
                     Peek(1).Kind == TokenKind.Name && GetString(Peek(1)) == "order")
            {
                // "stable" is the default ordering behavior; parse and ignore it.
                if (!_allowFullFlwor)
                    throw new XPathParseException("XPST0003: XPath does not allow an order by clause.", Current.Start);
                Advance();
                Advance();
                if (Current.Kind == TokenKind.Name && GetString(Current) == "by")
                {
                    Advance();
                    clauses.Add(new OrderByClauseNode(ParseOrderBySpecs()));
                }
                else
                {
                    throw new XPathParseException("XPST0003: Expected 'by' after 'stable order'.", Current.Start);
                }
            }
            else if (Current.Kind == TokenKind.Name && GetString(Current) == "group")
            {
                if (!_allowFullFlwor)
                    throw new XPathParseException("XPST0003: XPath does not allow a group by clause.", Current.Start);
                Advance();
                if (Current.Kind == TokenKind.Name && GetString(Current) == "by")
                {
                    Advance();
                    clauses.Add(new GroupByClauseNode(ParseGroupingSpecs()));
                }
                else
                {
                    throw new XPathParseException("XPST0003: Expected 'by' after 'group'.", Current.Start);
                }
            }
            else
            {
                break;
            }
        }

        Expect(TokenKind.KeywordReturn);
        var body = ParseExprSingle();

        // For simple cases with no order by, count, or group by (and only one initial for/let + optional where),
        // preserve the existing nested For/Let/If AST for backward compatibility.
        if (clauses.Count == 1 && clauses[0] is ForClauseNode forClause && !clauses.Any(c => c is OrderByClauseNode or CountClauseNode or GroupByClauseNode))
        {
            return WithSpan(new ForExpressionNode(forClause.Bindings, body), start, End);
        }
        if (clauses.Count == 1 && clauses[0] is LetClauseNode letClause && !clauses.Any(c => c is OrderByClauseNode or CountClauseNode or GroupByClauseNode))
        {
            return WithSpan(new LetExpressionNode(letClause.Bindings, body), start, End);
        }
        if (clauses.Count == 2 && clauses[0] is ForClauseNode forClause2 && clauses[1] is WhereClauseNode whereClause && !clauses.Any(c => c is OrderByClauseNode or CountClauseNode or GroupByClauseNode))
        {
            var filteredBody = WithSpan(new IfExpressionNode(whereClause.Condition, body,
                new SequenceExpressionNode(Array.Empty<XPathAstNode>())), start, End);
            return WithSpan(new ForExpressionNode(forClause2.Bindings, filteredBody), start, End);
        }
        if (clauses.Count == 2 && clauses[0] is LetClauseNode letClause2 && clauses[1] is WhereClauseNode whereClause2 && !clauses.Any(c => c is OrderByClauseNode or CountClauseNode or GroupByClauseNode))
        {
            var filteredBody = WithSpan(new IfExpressionNode(whereClause2.Condition, body,
                new SequenceExpressionNode(Array.Empty<XPathAstNode>())), start, End);
            return WithSpan(new LetExpressionNode(letClause2.Bindings, filteredBody), start, End);
        }

        return WithSpan(new FlworExpressionNode(clauses, body), start, End);
    }

    private IReadOnlyList<OrderSpec> ParseOrderBySpecs()
    {
        var specs = new List<OrderSpec>();
        do
        {
            var key = ParseExprSingle();
            bool descending = false;
            EmptyOrder? emptyOrder = null;
            string? collation = null;

            if (Current.Kind == TokenKind.Name && GetString(Current) == "ascending")
            {
                Advance();
            }
            else if (Current.Kind == TokenKind.Name && GetString(Current) == "descending")
            {
                Advance();
                descending = true;
            }

            if (Current.Kind == TokenKind.Name && GetString(Current) == "empty")
            {
                Advance();
                if (Current.Kind == TokenKind.Name && GetString(Current) == "greatest")
                {
                    Advance();
                    emptyOrder = EmptyOrder.Greatest;
                }
                else if (Current.Kind == TokenKind.Name && GetString(Current) == "least")
                {
                    Advance();
                    emptyOrder = EmptyOrder.Least;
                }
                else
                {
                    throw new XPathParseException("XPST0003: Expected 'greatest' or 'least' after 'empty'.", Current.Start);
                }
            }

            if (Current.Kind == TokenKind.Name && GetString(Current) == "collation")
            {
                Advance();
                var lit = Expect(TokenKind.StringLiteral);
                collation = Unquote(GetString(lit));
            }

            specs.Add(new OrderSpec(key, descending, emptyOrder, collation));
        } while (Match(TokenKind.Comma));
        return specs;
    }

    private IReadOnlyList<GroupingSpec> ParseGroupingSpecs()
    {
        var specs = new List<GroupingSpec>();
        do
        {
            Expect(TokenKind.Dollar);
            var nameTok = ExpectName();
            var (prefix, local, ns) = SplitQName(GetString(nameTok));

            FlworTypeDeclaration? declaredType = null;
            if (Current.Kind == TokenKind.KeywordAs)
            {
                Advance();
                var (typePrefix, typeLocal, occurrence) = ParseSequenceType();
                declaredType = new FlworTypeDeclaration(typeLocal, typePrefix, occurrence);
                // A type declaration in a grouping spec is only allowed together with a
                // ':= value' clause (GroupingSpec ::= "$" VarName (TypeDeclaration? ":=" ExprSingle)? ...).
                if (Current.Kind != TokenKind.Assign)
                    throw new XPathParseException("XPST0003: A type declaration in a 'group by' spec requires a ':= value' clause.", Current.Start);
            }

            XPathAstNode? keyExpression = null;
            if (Match(TokenKind.Assign))
            {
                keyExpression = ParseExprSingle();
            }

            string? collation = null;
            if (Current.Kind == TokenKind.Name && GetString(Current) == "collation")
            {
                Advance();
                var lit = Expect(TokenKind.StringLiteral);
                collation = Unquote(GetString(lit));
            }

            specs.Add(new GroupingSpec(local, keyExpression, collation, prefix, ns, declaredType));
        } while (Match(TokenKind.Comma));
        return specs;
    }

    private bool IsWindowKeyword(Token token) =>
        token.Kind == TokenKind.Name && (GetString(token) == "tumbling" || GetString(token) == "sliding");

    private WindowClauseNode ParseWindowClause()
    {
        // Current is 'for'; the next token is 'tumbling' or 'sliding'.
        Expect(TokenKind.KeywordFor);
        bool sliding = GetString(Current) == "sliding";
        Advance();

        if (Current.Kind != TokenKind.Name || GetString(Current) != "window")
            throw new XPathParseException("XPST0003: Expected 'window' after 'tumbling'/'sliding'.", Current.Start);
        Advance();

        Expect(TokenKind.Dollar);
        var nameTok = ExpectName();
        var (prefix, local, ns) = SplitQName(GetString(nameTok));

        FlworTypeDeclaration? declaredType = null;
        if (Current.Kind == TokenKind.KeywordAs)
        {
            Advance();
            var (typePrefix, typeLocal, occurrence) = ParseSequenceType();
            declaredType = new FlworTypeDeclaration(typeLocal, typePrefix, occurrence);
        }

        Expect(TokenKind.KeywordIn);
        var inExpression = ParseExprSingle();

        var startCondition = ParseWindowCondition("start");

        // The end condition is optional; a tumbling window without one closes when the
        // next window starts (or at the end of the input sequence), and a sliding
        // window without one extends to the end of the input sequence.
        bool onlyEnd = false;
        WindowCondition? endCondition = null;
        if (Current.Kind == TokenKind.Name && GetString(Current) == "only")
        {
            onlyEnd = true;
            Advance();
            endCondition = ParseWindowCondition("end");
        }
        else if (Current.Kind == TokenKind.Name && GetString(Current) == "end")
        {
            endCondition = ParseWindowCondition("end");
        }

        // XQST0103: all variables bound by a single window clause must be distinct.
        var boundNames = new List<string> { local };
        void Collect(string? name)
        {
            if (name is not null)
                boundNames.Add(name);
        }
        Collect(startCondition.CurrentItemVariable);
        Collect(startCondition.PositionalVariable);
        Collect(startCondition.PreviousItemVariable);
        Collect(startCondition.NextItemVariable);
        if (endCondition is not null)
        {
            Collect(endCondition.CurrentItemVariable);
            Collect(endCondition.PositionalVariable);
            Collect(endCondition.PreviousItemVariable);
            Collect(endCondition.NextItemVariable);
        }
        if (boundNames.Distinct().Count() != boundNames.Count)
            throw new XPathParseException("XQST0103: Duplicate variable binding in window clause.", Current.Start);

        return new WindowClauseNode(sliding, local, inExpression, startCondition, endCondition, onlyEnd, prefix, ns, declaredType);
    }

    private WindowCondition ParseWindowCondition(string keyword)
    {
        // Current must be the contextual keyword ('start' or 'end').
        if (Current.Kind != TokenKind.Name || GetString(Current) != keyword)
            throw new XPathParseException($"XPST0003: Expected '{keyword}' condition in window clause.", Current.Start);
        Advance();

        string? currentItem = null, positional = null, previousItem = null, nextItem = null;
        if (Current.Kind == TokenKind.Dollar)
        {
            Advance();
            currentItem = GetString(ExpectName());
        }
        if (Current.Kind == TokenKind.Name && GetString(Current) == "at")
        {
            Advance();
            Expect(TokenKind.Dollar);
            positional = GetString(ExpectName());
        }
        if (Current.Kind == TokenKind.Name && GetString(Current) == "previous")
        {
            Advance();
            Expect(TokenKind.Dollar);
            previousItem = GetString(ExpectName());
        }
        if (Current.Kind == TokenKind.Name && GetString(Current) == "next")
        {
            Advance();
            Expect(TokenKind.Dollar);
            nextItem = GetString(ExpectName());
        }

        if (Current.Kind != TokenKind.Name || GetString(Current) != "when")
            throw new XPathParseException($"XPST0003: Expected 'when' in window {keyword} condition.", Current.Start);
        Advance();

        var whenExpression = ParseExprSingle();
        return new WindowCondition(whenExpression, currentItem, positional, previousItem, nextItem);
    }

    private IReadOnlyList<QuantifiedBinding> ParseForClauseBindings()
    {
        Expect(TokenKind.KeywordFor);
        var bindings = new List<QuantifiedBinding>();
        do
        {
            bindings.Add(ParseMemberEntryOrSimpleForBinding());
        } while (Match(TokenKind.Comma));
        return bindings;
    }

    // ForBinding ::= ForItemBinding | ForMemberBinding | ForEntryBinding (XPath 4.0 §4.14.1).
    private QuantifiedBinding ParseMemberEntryOrSimpleForBinding()
    {
        if (Current.Kind == TokenKind.Name)
        {
            if (GetString(Current) == "member")
            {
                if (!_xpath40)
                    throw new XPathParseException("XPST0003: A 'for member' binding requires XPath 4.0.", Current.Start);
                Advance();
                return ParseMemberBinding();
            }
            if (GetString(Current) is "key" or "value")
            {
                if (!_xpath40)
                    throw new XPathParseException("XPST0003: A 'for key value' binding requires XPath 4.0.", Current.Start);
                return ParseEntryBinding();
            }
        }
        return ParseSimpleForBinding(allowPositional: true);
    }

    // ForMemberBinding ::= "member" VarNameAndType PositionalVar? "in" ExprSingle
    // ForEntryBinding  ::= (("key" VarNameAndType)? ("value" VarNameAndType)?) PositionalVar? "in" ExprSingle
    // (at least one of key/value must be present — checked below).
    private QuantifiedBinding ParseEntryBinding()
    {
        string? keyName = null, keyPrefix = null, keyNs = null;
        FlworTypeDeclaration? keyDecl = null, valueDecl = null;
        string? valueName = null, valuePrefix = null, valueNs = null;
        if (Current.Kind == TokenKind.Name && GetString(Current) == "key")
        {
            Advance();
            (keyPrefix, keyName, keyNs, keyDecl) = ParseVarNameAndType();
        }
        if (Current.Kind == TokenKind.Name && GetString(Current) == "value")
        {
            Advance();
            (valuePrefix, valueName, valueNs, valueDecl) = ParseVarNameAndType();
        }
        if (keyName is null && valueName is null)
            throw new XPathParseException("XPST0003: Expected 'value' after 'key' in a for entry binding.", Current.Start);
        // XQST0089: key and value variables must have distinct names.
        if (keyName is not null && valueName is not null
            && keyName == valueName && (keyNs ?? keyPrefix ?? "") == (valueNs ?? valuePrefix ?? ""))
            throw new XPathParseException($"XQST0089: The key and value variables of a for binding must have distinct names ('${keyName}').", Current.Start);

        // VariableName holds the key variable (or the value variable when no key is
        // declared); EntryValueVariableName holds the companion value variable.
        bool both = keyName is not null && valueName is not null;
        return ParseMemberEntryPositionalAndIn(keyName ?? valueName!, keyPrefix ?? valuePrefix, keyNs ?? valueNs,
            keyName is null ? ForBindingKind.EntryValueOnly
                : valueName is null ? ForBindingKind.EntryKeyOnly : ForBindingKind.EntryKeyValue,
            both ? valueName : null, both ? valuePrefix : null, both ? valueNs : null)
            with { DeclaredType = keyName is null ? valueDecl : keyDecl, EntryValueDeclaredType = both ? valueDecl : null };
    }

    // VarNameAndType ::= "$" EQName TypeDeclaration? — the declared type is XQuery-only,
    // matching the ordinary for binding rule.
    private (string? Prefix, string Local, string? Ns, FlworTypeDeclaration? DeclaredType) ParseVarNameAndType()
    {
        Expect(TokenKind.Dollar);
        var nameTok = ExpectName();
        var (prefix, local, ns) = SplitQName(GetString(nameTok));
        if (Current.Kind != TokenKind.KeywordAs)
            return (prefix, local, ns, null);
        if (!_allowFullFlwor)
            throw new XPathParseException("XPST0003: XPath does not allow a type declaration in a for binding.", Current.Start);
        Advance();
        var (typePrefix, typeLocal, occurrence) = ParseSequenceType();
        return (prefix, local, ns, new FlworTypeDeclaration(typeLocal, typePrefix, occurrence));
    }

    // 'member' has already been consumed; parse VarNameAndType PositionalVar? "in" ExprSingle.
    private QuantifiedBinding ParseMemberBinding()
    {
        var (prefix, local, ns, declaredType) = ParseVarNameAndType();
        return ParseMemberEntryPositionalAndIn(local, prefix, ns, ForBindingKind.Member,
            null, null, null) with { DeclaredType = declaredType };
    }

    // Shared tail of a member/entry binding: PositionalVar? "in" ExprSingle.
    private QuantifiedBinding ParseMemberEntryPositionalAndIn(string local, string? prefix, string? ns,
        ForBindingKind kind, string? entryValueName, string? entryValuePrefix, string? entryValueNs)
    {
        string? positionalVar = null;
        if (Current.Kind == TokenKind.Name && GetString(Current) == "at")
        {
            Advance();
            Expect(TokenKind.Dollar);
            var posTok = ExpectName();
            var (posPrefix, posLocal, posNs) = SplitQName(GetString(posTok));
            // XQST0089: the positional variable must differ from all range variables.
            if ((posLocal == local && (posNs ?? posPrefix ?? "") == (ns ?? prefix ?? ""))
                || (entryValueName is not null && posLocal == entryValueName && (posNs ?? posPrefix ?? "") == (entryValueNs ?? entryValuePrefix ?? "")))
                throw new XPathParseException($"XQST0089: The positional variable '${GetString(posTok)}' has the same name as a range variable.", posTok.Start);
            positionalVar = posLocal;
        }

        Expect(TokenKind.KeywordIn);
        var expr = ParseExprSingle();
        return new QuantifiedBinding(local, expr, positionalVar, prefix, ns,
            BindingKind: kind, EntryValueVariableName: entryValueName,
            EntryValueVariablePrefix: entryValuePrefix,
            EntryValueVariableNamespaceUri: entryValueNs);
    }

    private bool IsMemberEntryBindingStart(Token token)
        => token.Kind == TokenKind.Name && (GetString(token) is "member" or "key" or "value");

    private IReadOnlyList<QuantifiedBinding> ParseLetClauseBindings()
    {
        Expect(TokenKind.KeywordLet);
        var bindings = new List<QuantifiedBinding>();
        do
        {
            bindings.Add(ParseSimpleLetBinding());
        } while (Match(TokenKind.Comma));
        return bindings;
    }

    private QuantifiedBinding ParseSimpleForBinding(bool allowPositional = false)
    {
        Expect(TokenKind.Dollar);
        var nameTok = ExpectName();
        var (prefix, local, ns) = SplitQName(GetString(nameTok));

        // XQuery TypeDeclaration ("as SequenceType"); XPath 3.1 does not allow it.
        FlworTypeDeclaration? declaredType = null;
        if (Current.Kind == TokenKind.KeywordAs)
        {
            if (!_allowFullFlwor)
                throw new XPathParseException("XPST0003: XPath does not allow a type declaration in a for binding.", Current.Start);
            Advance();
            var (typePrefix, typeLocal, occurrence) = ParseSequenceType();
            declaredType = new FlworTypeDeclaration(typeLocal, typePrefix, occurrence);
        }

        // Grammar order: TypeDeclaration? AllowingEmpty? PositionalVar? — 'allowing empty'
        // precedes 'at $p' (outer-003). XQuery only; XPath 3.1 does not allow it.
        bool allowingEmpty = false;
        if (Current.Kind == TokenKind.Name && GetString(Current) == "allowing")
        {
            if (!_allowFullFlwor)
                throw new XPathParseException("XPST0003: XPath does not allow 'allowing empty' in a for binding.", Current.Start);
            Advance();
            if (Current.Kind != TokenKind.Name || GetString(Current) != "empty")
                throw new XPathParseException("XPST0003: Expected 'empty' after 'allowing'.", Current.Start);
            Advance();
            allowingEmpty = true;
        }

        string? positionalVar = null;
        // PositionalVar ::= "at" "$" VarName  (contextual keyword, lexed as Name)
        if (allowPositional && Current.Kind == TokenKind.Name && GetString(Current) == "at")
        {
            Advance();
            Expect(TokenKind.Dollar);
            var posTok = ExpectName();
            // XQST0089: the positional variable must not have the same name as the range variable.
            if (GetString(posTok) == GetString(nameTok))
                throw new XPathParseException($"XQST0089: The positional variable '${GetString(posTok)}' has the same name as the range variable.", posTok.Start);
            var (_, posLocal, _) = SplitQName(GetString(posTok));
            positionalVar = posLocal;
        }

        Expect(TokenKind.KeywordIn);
        var expr = ParseExprSingle();
        return new QuantifiedBinding(local, expr, positionalVar, prefix, ns, declaredType, allowingEmpty);
    }

    private QuantifiedBinding ParseSimpleLetBinding()
    {
        Expect(TokenKind.Dollar);

        // XPath 4.0 destructuring (PR1131): 'let $(...)' (sequence), 'let $[...]' (array),
        // 'let ${...}' (map). In 3.1 a '$' not followed by a variable name is always a
        // syntax error; name the destructuring forms explicitly in the rejection path.
        if (Current.Kind is TokenKind.LParen or TokenKind.LBracket or TokenKind.LBrace)
        {
            if (!_xpath40)
                throw new XPathParseException("XPST0003: A destructuring let binding ('$(...)', '$[...]', or '${...}') requires XPath 4.0.", Current.Start);
            return ParseDestructuringLetBinding();
        }

        var nameTok = ExpectName();
        var (prefix, local, ns) = SplitQName(GetString(nameTok));

        // XQuery TypeDeclaration ("as SequenceType"); XPath 3.1 does not allow it, but
        // XPath 4.0 adopts it with coercion semantics (PR1131, prod-LetClause letexprwith-*).
        FlworTypeDeclaration? declaredType = null;
        if (Current.Kind == TokenKind.KeywordAs)
        {
            if (!_allowFullFlwor && !_xpath40)
                throw new XPathParseException("XPST0003: XPath does not allow a type declaration in a let binding.", Current.Start);
            Advance();
            var (typePrefix, typeLocal, occurrence) = ParseSequenceType();
            declaredType = new FlworTypeDeclaration(typeLocal, typePrefix, occurrence);
        }

        Expect(TokenKind.Assign);  // := 
        var expr = ParseExprSingle();
        return new QuantifiedBinding(local, expr, null, prefix, ns, declaredType);
    }

    // DestructuringBinding ::=
    //   "$" ( "(" | "[" | "{" ) DestructuringVariable ("," DestructuringVariable)* (")" | "]" | "}")
    //   ("as" SequenceType)? ":=" ExprSingle
    // DestructuringVariable ::= "$" VarName ("as" SequenceType)?
    private QuantifiedBinding ParseDestructuringLetBinding()
    {
        var kind = Current.Kind switch
        {
            TokenKind.LParen => LetDestructuringKind.Sequence,
            TokenKind.LBracket => LetDestructuringKind.Array,
            _ => LetDestructuringKind.Map,
        };
        var closing = Current.Kind switch
        {
            TokenKind.LParen => TokenKind.RParen,
            TokenKind.LBracket => TokenKind.RBracket,
            _ => TokenKind.RBrace,
        };
        Advance();

        var variables = new List<DestructuringVariable>();
        if (Current.Kind != closing)
        {
            do
            {
                Expect(TokenKind.Dollar);
                var varTok = ExpectName();
                var (varPrefix, varLocal, varNs) = SplitQName(GetString(varTok));
                FlworTypeDeclaration? varType = null;
                if (Current.Kind == TokenKind.KeywordAs)
                {
                    Advance();
                    var (typePrefix, typeLocal, occurrence) = ParseSequenceType();
                    varType = new FlworTypeDeclaration(typeLocal, typePrefix, occurrence);
                }
                variables.Add(new DestructuringVariable(varLocal, varPrefix, varNs, varType));
            } while (Match(TokenKind.Comma));
        }
        Expect(closing);
        if (variables.Count == 0)
            throw new XPathParseException("XPST0003: A destructuring let binding must declare at least one variable.", Current.Start);

        // Optional whole-pattern type declaration applies to the bound value as a whole
        // (let-seq-006/008, let-arr-006/008, let-map-006/008).
        FlworTypeDeclaration? declaredType = null;
        if (Current.Kind == TokenKind.KeywordAs)
        {
            Advance();
            var (typePrefix, typeLocal, occurrence) = ParseSequenceType();
            declaredType = new FlworTypeDeclaration(typeLocal, typePrefix, occurrence);
        }

        Expect(TokenKind.Assign);  // :=
        var expr = ParseExprSingle();
        return new QuantifiedBinding(
            variables[0].VariableName, expr,
            VariablePrefix: variables[0].VariablePrefix,
            VariableNamespaceUri: variables[0].VariableNamespaceUri,
            DeclaredType: declaredType,
            Destructuring: kind,
            DestructuringVariables: variables);
    }

    // QuantifiedExpr ::= ("some" | "every") SimpleForBinding ("satisfies" ExprSingle)+
    private XPathAstNode ParseQuantifiedExpr()
    {
        int start = Current.Start;
        var quantifier = Match(TokenKind.KeywordSome) ? QuantifierKind.Some : QuantifierKind.Every;
        if (quantifier == QuantifierKind.Every) Expect(TokenKind.KeywordEvery);
        var bindings = new List<QuantifiedBinding>();
        do
        {
            bindings.Add(ParseSimpleForBinding());
        } while (Match(TokenKind.Comma));
        Expect(TokenKind.KeywordSatisfies);
        var body = ParseExprSingle();
        return WithSpan(new QuantifiedExpressionNode(quantifier, bindings, body), start, End);
    }

    // IfExpr ::= "if" "(" Expr ")" "then" ExprSingle "else" ExprSingle
    // XPath 4.0 additionally allows EnclosedExpr ("{" Expr "}") in place of the
    // "then"/"else" keyword + ExprSingle branches (atomic-equal-021 brace mode).
    private XPathAstNode ParseIfExpr()
    {
        int start = Current.Start;
        Expect(TokenKind.KeywordIf);
        Expect(TokenKind.LParen);
        var cond = ParseExpr();
        Expect(TokenKind.RParen);
        bool thenBraced = Current.Kind == TokenKind.LBrace && _xpath40;
        var thenBranch = thenBraced
            ? ParseEnclosedBranch()
            : ParseThenBranch();
        // XPath 4.0: the "else" branch may be omitted when the "then" branch is
        // braced — a false condition yields the empty sequence (atomic-equal-021).
        XPathAstNode elseBranch;
        if (Current.Kind == TokenKind.KeywordElse)
        {
            Advance();
            elseBranch = Current.Kind == TokenKind.LBrace
                ? ParseEnclosedBranch()
                : ParseExprSingle();
        }
        else if (thenBraced)
        {
            elseBranch = new SequenceExpressionNode(Array.Empty<XPathAstNode>());
        }
        else
        {
            throw new XPathParseException("XPST0003: Expected 'else' in if expression.", Current.Start);
        }
        return WithSpan(new IfExpressionNode(cond, thenBranch, elseBranch), start, End);

        XPathAstNode ParseThenBranch()
        {
            Expect(TokenKind.KeywordThen);
            return ParseExprSingle();
        }

        XPathAstNode ParseEnclosedBranch()
        {
            Expect(TokenKind.LBrace);
            var expr = ParseExpr();
            Expect(TokenKind.RBrace);
            return expr;
        }
    }

    // TryExpr ::= TryClause CatchClause+
    // TryClause ::= "try" "{" Expr "}"
    // CatchClause ::= "catch" CatchErrorList "{" Expr "}"
    // CatchErrorList ::= NameTest ("|" NameTest)*   — error-code name tests:
    //   '*', 'prefix:local', 'prefix:*', '*:local', 'Q{uri}local', 'Q{uri}*', NCName
    private XPathAstNode ParseTryExpr()
    {
        int start = Current.Start;
        Expect(TokenKind.KeywordTry);
        Expect(TokenKind.LBrace);
        // An empty try body is the empty sequence (try-019).
        var tryBody = Current.Kind == TokenKind.RBrace
            ? new SequenceExpressionNode(Array.Empty<XPathAstNode>())
            : ParseExpr();
        Expect(TokenKind.RBrace);

        var clauses = new List<TryCatchClause>();
        while (Current.Kind == TokenKind.KeywordCatch)
        {
            Advance();
            var patterns = new List<CatchCodePattern>();
            do
            {
                patterns.Add(ParseCatchCodePattern());
            } while (Match(TokenKind.VBar));
            Expect(TokenKind.LBrace);
            // An empty catch body is the empty sequence (try-020).
            var catchBody = Current.Kind == TokenKind.RBrace
                ? new SequenceExpressionNode(Array.Empty<XPathAstNode>())
                : ParseExpr();
            Expect(TokenKind.RBrace);
            clauses.Add(new TryCatchClause(patterns, catchBody));
        }
        if (clauses.Count == 0)
            throw new XPathParseException("XPST0003: Expected at least one catch clause after 'try { ... }'.", Current.Start);
        return WithSpan(new TryCatchNode(tryBody, clauses), start, End);
    }

    // Parses one error-code name test of a catch clause.
    private CatchCodePattern ParseCatchCodePattern()
    {
        int start = Current.Start;

        // Wildcard: '*' (any error) or '*:local' (any namespace).
        if (Match(TokenKind.Star))
        {
            if (Match(TokenKind.Colon))
            {
                var wildcardLocal = GetString(ExpectName());
                return new CatchCodePattern("*", wildcardLocal, null);
            }
            return new CatchCodePattern(null, null, null);
        }

        if (Current.Kind == TokenKind.Name || IsKeywordName(Current.Kind))
        {
            var name = GetString(Current);

            // URI-qualified wildcard: Q{uri}* (including the empty URI Q{}*).
            if (name.Length > 2 && name[0] == 'Q' && name[1] == '{' && name[^1] == '*')
            {
                int closeBrace = name.IndexOf('}');
                if (closeBrace >= 2)
                {
                    Advance();
                    return new CatchCodePattern(null, null, name[2..closeBrace]);
                }
            }

            Advance();

            // prefix:* (namespace wildcard).
            if (Match(TokenKind.Colon) && Match(TokenKind.Star))
                return new CatchCodePattern(name, null, null);

            var (prefix, local, nsUri) = SplitQName(name);
            if (nsUri is not null)
                return new CatchCodePattern(null, local, nsUri);
            if (prefix is not null)
                return new CatchCodePattern(prefix, local, null);
            // An unprefixed code name matches the empty namespace.
            return new CatchCodePattern(null, local, "");
        }

        throw new XPathParseException($"XPST0003: Expected error code pattern but found {Current.Kind}", start);
    }

    // SwitchExpr ::= "switch" "(" Expr ")" SwitchCaseClause+ "default" "return" ExprSingle
    // SwitchCaseClause ::= ("case" ExprSingle)+ "return" ExprSingle
    // Consecutive 'case' keywords before a 'return' accumulate values of one clause.
    private XPathAstNode ParseSwitchExpr()
    {
        int start = Current.Start;
        Advance(); // 'switch'
        Expect(TokenKind.LParen);
        var operand = ParseExpr();
        Expect(TokenKind.RParen);

        var cases = new List<SwitchCaseClause>();
        while (Current.Kind == TokenKind.Name && GetString(Current) == "case")
        {
            Advance();
            var values = new List<XPathAstNode> { ParseExprSingle() };
            while (Current.Kind == TokenKind.Name && GetString(Current) == "case")
            {
                Advance();
                values.Add(ParseExprSingle());
            }
            Expect(TokenKind.KeywordReturn);
            cases.Add(new SwitchCaseClause(values, ParseExprSingle()));
        }
        if (cases.Count == 0)
            throw new XPathParseException("XPST0003: A switch expression requires at least one case clause.", Current.Start);
        if (Current.Kind != TokenKind.Name || GetString(Current) != "default")
            throw new XPathParseException("XPST0003: Expected 'default' in switch expression.", Current.Start);
        Advance();
        Expect(TokenKind.KeywordReturn);
        var defaultReturn = ParseExprSingle();
        return WithSpan(new SwitchExpressionNode(operand, cases, defaultReturn), start, End);
    }

    // TypeswitchExpr ::= "typeswitch" "(" Expr ")" CaseClause+ "default" ("$" VarName)? "return" ExprSingle
    // CaseClause ::= "case" ("$" VarName "as")? SequenceType "return" ExprSingle
    private XPathAstNode ParseTypeswitchExpr()
    {
        int start = Current.Start;
        Advance(); // 'typeswitch'
        Expect(TokenKind.LParen);
        var operand = ParseExpr();
        Expect(TokenKind.RParen);

        var cases = new List<TypeswitchCaseClause>();
        while (Current.Kind == TokenKind.Name && GetString(Current) == "case")
        {
            Advance();
            string? varLocal = null, varPrefix = null, varNs = null;
            if (Current.Kind == TokenKind.Dollar)
            {
                Advance();
                var nameTok = ExpectName();
                (varPrefix, varLocal, varNs) = SplitQName(GetString(nameTok));
                Expect(TokenKind.KeywordAs);
            }
            // SequenceTypeUnion ::= SequenceType ("|" SequenceType)*
            var types = new List<TypeswitchCaseType>();
            var (typePrefix, typeLocal, occurrence) = ParseSequenceType();
            types.Add(new TypeswitchCaseType(typePrefix, typeLocal, occurrence));
            while (Match(TokenKind.VBar))
            {
                (typePrefix, typeLocal, occurrence) = ParseSequenceType();
                types.Add(new TypeswitchCaseType(typePrefix, typeLocal, occurrence));
            }
            Expect(TokenKind.KeywordReturn);
            cases.Add(new TypeswitchCaseClause(types, ParseExprSingle(), varLocal, varPrefix, varNs));
        }
        if (cases.Count == 0)
            throw new XPathParseException("XPST0003: A typeswitch expression requires at least one case clause.", Current.Start);
        if (Current.Kind != TokenKind.Name || GetString(Current) != "default")
            throw new XPathParseException("XPST0003: Expected 'default' in typeswitch expression.", Current.Start);
        Advance();
        string? defLocal = null, defPrefix = null, defNs = null;
        if (Current.Kind == TokenKind.Dollar)
        {
            Advance();
            var nameTok = ExpectName();
            (defPrefix, defLocal, defNs) = SplitQName(GetString(nameTok));
        }
        Expect(TokenKind.KeywordReturn);
        var defaultReturn = ParseExprSingle();
        return WithSpan(new TypeswitchExpressionNode(operand, cases, defaultReturn, defLocal, defPrefix, defNs), start, End);
    }

    // OrExpr ::= AndExpr ("or" AndExpr)*
    private XPathAstNode ParseOrExpr()
    {
        int start = Current.Start;
        var left = ParseAndExpr();
        while (Match(TokenKind.KeywordOr))
        {
            var right = ParseAndExpr();
            left = WithSpan(new BinaryExpressionNode(left, BinaryOperator.Or, right), start, End);
        }
        return left;
    }

    // AndExpr ::= ComparisonExpr ("and" ComparisonExpr)*
    private XPathAstNode ParseAndExpr()
    {
        int start = Current.Start;
        var left = ParseComparisonExpr();
        while (Match(TokenKind.KeywordAnd))
        {
            var right = ParseComparisonExpr();
            left = WithSpan(new BinaryExpressionNode(left, BinaryOperator.And, right), start, End);
        }
        return left;
    }

    // ComparisonExpr ::= OtherwiseExpr (ComparisonOp OtherwiseExpr)?
    private XPathAstNode ParseComparisonExpr()
    {
        int start = Current.Start;
        var left = ParseOtherwiseExpr();
        BinaryOperator? op = Current.Kind switch
        {
            TokenKind.Equal => BinaryOperator.Equal,
            TokenKind.NotEqual => BinaryOperator.NotEqual,
            TokenKind.LessThan => BinaryOperator.LessThan,
            TokenKind.LessThanOrEqual => BinaryOperator.LessThanOrEqual,
            TokenKind.GreaterThan => BinaryOperator.GreaterThan,
            TokenKind.GreaterThanOrEqual => BinaryOperator.GreaterThanOrEqual,
            TokenKind.ValueEq => BinaryOperator.Eq,
            TokenKind.ValueNe => BinaryOperator.Ne,
            TokenKind.ValueLt => BinaryOperator.Lt,
            TokenKind.ValueLe => BinaryOperator.Le,
            TokenKind.ValueGt => BinaryOperator.Gt,
            TokenKind.ValueGe => BinaryOperator.Ge,
            TokenKind.ValueIs => BinaryOperator.Is,
            TokenKind.NodeBefore => BinaryOperator.Precedes,
            TokenKind.NodeAfter => BinaryOperator.Follows,
            _ => null
        };
        if (op.HasValue)
        {
            Advance();
            var right = ParseOtherwiseExpr();
            left = WithSpan(new BinaryExpressionNode(left, op.Value, right), start, End);
        }
        return left;
    }

    // OtherwiseExpr ::= StringConcatExpr ("??" StringConcatExpr)*   [XPath 4.0]
    // Binds more tightly than comparisons (=, eq, ...) but less tightly than
    // string concatenation (||) and arithmetic (XPath 4.0 §4.17).
    private XPathAstNode ParseOtherwiseExpr()
    {
        int start = Current.Start;
        var left = ParseStringConcatExpr();
        while (Current.Kind == TokenKind.Otherwise)
        {
            if (!_xpath40)
                throw new XPathParseException("The '??' (otherwise) operator requires XPath 4.0; it is not allowed in XPath 3.1", Current.Start);
            Advance();
            var right = ParseStringConcatExpr();
            left = WithSpan(new BinaryExpressionNode(left, BinaryOperator.Otherwise, right), start, End);
        }
        return left;
    }

    // StringConcatExpr ::= RangeExpr ("||" RangeExpr)*
    private XPathAstNode ParseStringConcatExpr()
    {
        int start = Current.Start;
        var left = ParseRangeExpr();
        while (Match(TokenKind.StringConcat))
        {
            var right = ParseRangeExpr();
            left = WithSpan(new BinaryExpressionNode(left, BinaryOperator.StringConcat, right), start, End);
        }
        return left;
    }

    // RangeExpr ::= AdditiveExpr ("to" AdditiveExpr)?
    private XPathAstNode ParseRangeExpr()
    {
        int start = Current.Start;
        var left = ParseAdditiveExpr();
        if (Match(TokenKind.KeywordTo))
        {
            var right = ParseAdditiveExpr();
            return WithSpan(new RangeExpressionNode(left, right), start, End);
        }
        return left;
    }

    // AdditiveExpr ::= MultiplicativeExpr (("+" | "-") MultiplicativeExpr)*
    private XPathAstNode ParseAdditiveExpr()
    {
        int start = Current.Start;
        var left = ParseMultiplicativeExpr();
        while (true)
        {
            if (Match(TokenKind.Plus))
            {
                var right = ParseMultiplicativeExpr();
                left = WithSpan(new BinaryExpressionNode(left, BinaryOperator.Plus, right), start, End);
            }
            else if (Match(TokenKind.Minus))
            {
                var right = ParseMultiplicativeExpr();
                left = WithSpan(new BinaryExpressionNode(left, BinaryOperator.Minus, right), start, End);
            }
            else break;
        }
        return left;
    }

    // MultiplicativeExpr ::= UnionExpr (("*" | "div" | "idiv" | "mod") UnionExpr)*
    private XPathAstNode ParseMultiplicativeExpr()
    {
        int start = Current.Start;
        var left = ParseUnionExpr();
        while (true)
        {
            if (Match(TokenKind.Star))
            {
                var right = ParseUnionExpr();
                left = WithSpan(new BinaryExpressionNode(left, BinaryOperator.Multiply, right), start, End);
            }
            else if (Match(TokenKind.KeywordDiv))
            {
                var right = ParseUnionExpr();
                left = WithSpan(new BinaryExpressionNode(left, BinaryOperator.Divide, right), start, End);
            }
            else if (Match(TokenKind.KeywordIdiv))
            {
                var right = ParseUnionExpr();
                left = WithSpan(new BinaryExpressionNode(left, BinaryOperator.Idiv, right), start, End);
            }
            else if (Match(TokenKind.KeywordMod))
            {
                var right = ParseUnionExpr();
                left = WithSpan(new BinaryExpressionNode(left, BinaryOperator.Mod, right), start, End);
            }
            else break;
        }
        return left;
    }

    // UnionExpr ::= IntersectExceptExpr (("union" | "|") IntersectExceptExpr)*
    private XPathAstNode ParseUnionExpr()
    {
        int start = Current.Start;
        var left = ParseIntersectExceptExpr();
        while (true)
        {
            if (Match(TokenKind.KeywordUnion) || Match(TokenKind.VBar))
            {
                var right = ParseIntersectExceptExpr();
                left = WithSpan(new BinaryExpressionNode(left, BinaryOperator.Union, right), start, End);
            }
            else break;
        }
        return left;
    }

    // IntersectExceptExpr ::= ButWithExpr (("intersect" | "except") ButWithExpr)*
    private XPathAstNode ParseIntersectExceptExpr()
    {
        int start = Current.Start;
        var left = ParseButWithExpr();
        while (true)
        {
            if (Match(TokenKind.KeywordIntersect))
            {
                var right = ParseButWithExpr();
                left = WithSpan(new BinaryExpressionNode(left, BinaryOperator.Intersect, right), start, End);
            }
            else if (Match(TokenKind.KeywordExcept))
            {
                var right = ParseButWithExpr();
                left = WithSpan(new BinaryExpressionNode(left, BinaryOperator.Except, right), start, End);
            }
            else break;
        }
        return left;
    }

    // ButWithExpr ::= InstanceofExpr ("but" "with" InstanceofExpr)*
    // XPath 4.0 §4.15.4: '$A but with $B' returns a record like $A with the entries of
    // $B merged in (use-last); 'but'/'with' are contextual keywords. Left-associative,
    // sitting directly under IntersectExceptExpr in the grammar chain.
    private XPathAstNode ParseButWithExpr()
    {
        int start = Current.Start;
        var left = ParseInstanceofExpr();
        while (Current.Kind == TokenKind.Name && GetString(Current) == "but"
            && Peek(1).Kind == TokenKind.Name && GetString(Peek(1)) == "with")
        {
            if (!_xpath40)
                throw new XPathParseException("XPST0003: The 'but with' operator requires XPath 4.0.", Current.Start);
            Advance(); // 'but'
            Advance(); // 'with'
            var right = ParseInstanceofExpr();
            left = WithSpan(new BinaryExpressionNode(left, BinaryOperator.ButWith, right), start, End);
        }
        return left;
    }

    // InstanceofExpr ::= TreatExpr ("instance" "of" SequenceType)?
    private XPathAstNode ParseInstanceofExpr()
    {
        int start = Current.Start;
        var left = ParseTreatExpr();
        if (Match(TokenKind.KeywordInstance))
        {
            Expect(TokenKind.KeywordOf);
            var (typePrefix, typeLocal, occurrence) = ParseSequenceType();
            return WithSpan(new InstanceOfNode(left, typeLocal, typePrefix, occurrence), start, End);
        }
        return left;
    }

    // TreatExpr ::= CastableExpr ("treat" "as" SequenceType)?
    private XPathAstNode ParseTreatExpr()
    {
        int start = Current.Start;
        var left = ParseCastableExpr();
        if (Match(TokenKind.KeywordTreat))
        {
            Expect(TokenKind.KeywordAs);
            var (typePrefix, typeLocal, occurrence) = ParseSequenceType();
            return WithSpan(new TreatNode(left, typeLocal, typePrefix, occurrence), start, End);
        }
        return left;
    }

    // CastableExpr ::= CastExpr ("castable" "as" SingleType)?
    private XPathAstNode ParseCastableExpr()
    {
        int start = Current.Start;
        var left = ParseCastExpr();
        if (Match(TokenKind.KeywordCastable))
        {
            Expect(TokenKind.KeywordAs);
            var (typePrefix, typeLocal, occurrence) = ParseSingleType();
            return WithSpan(new CastableNode(left, typeLocal, typePrefix, occurrence), start, End);
        }
        return left;
    }

    // CastExpr ::= PipelineExpr ("cast" "as" SingleType)?
    // PipelineExpr (XPath 4.0 §4.20) sits between the cast and the arrow level:
    // PipelineExpr ::= (ArrowExpr ++ "->")
    private XPathAstNode ParseCastExpr()
    {
        int start = Current.Start;
        var left = ParsePipelineExpr();
        if (Match(TokenKind.KeywordCast))
        {
            Expect(TokenKind.KeywordAs);
            var (typePrefix, typeLocal, occurrence) = ParseSingleType();
            return WithSpan(new CastNode(left, typeLocal, typePrefix, occurrence), start, End);
        }
        return left;
    }

    // PipelineExpr ::= (ArrowExpr ++ "->")
    // E1 -> E2 evaluates E1 and binds the result as a whole to the context value
    // (an inner fixed focus with position 1 and size 1) before evaluating E2 once.
    private XPathAstNode ParsePipelineExpr()
    {
        int start = Current.Start;
        var left = ParseArrowExpr();
        while (Current.Kind == TokenKind.PipelineArrow)
        {
            if (!_xpath40)
                throw new XPathParseException("XPST0003: The pipeline operator '->' requires XPath 4.0.", Current.Start);
            Advance();
            var target = ParseArrowExpr();
            left = WithSpan(new PipelineExprNode(left, target), start, End);
        }
        return left;
    }

    // ArrowExpr ::= UnaryExpr (("=>" | "=!>") ArrowFunctionSpecifier)*
    // The XPath 4.0 mapping arrow '=!>' applies the target function to each item of
    // the source: U =!> F(A, B) ≡ U ! F(., A, B) (XPath 4.0 §4.22.2), desugared here.
    private XPathAstNode ParseArrowExpr()
    {
        int start = Current.Start;
        var left = ParseUnaryExpr();
        while (Current.Kind is TokenKind.Arrow or TokenKind.MappingArrow)
        {
            bool mapping = Current.Kind == TokenKind.MappingArrow;
            if (mapping && !_xpath40)
                throw new XPathParseException("XPST0003: The mapping arrow operator '=!>' requires XPath 4.0.", Current.Start);
            Advance();
            var target = ParseArrowTarget();
            left = mapping
                ? WithSpan(new BinaryExpressionNode(left, BinaryOperator.SimpleMap, PrependContextItemArgument(target)), start, End)
                : WithSpan(new ArrowExprNode(left, target), start, End);
        }
        return left;
    }

    // U =!> F(A, B, ...) is equivalent to U ! F(., A, B, ...): the context item is
    // inserted as the first positional argument of the target call.
    private static XPathAstNode PrependContextItemArgument(XPathAstNode target) => target switch
    {
        FunctionCallNode call => call with
        {
            Arguments = new List<XPathAstNode> { new ContextItemNode() }.Concat(call.Arguments).ToList()
        },
        DynamicFunctionCallNode call => call with
        {
            Arguments = new List<XPathAstNode> { new ContextItemNode() }.Concat(call.Arguments).ToList()
        },
        _ => target,
    };

    private XPathAstNode ParseArrowTarget()
    {
        int start = Current.Start;
        if (Current.Kind == TokenKind.Name)
        {
            // XPath 4.0: 'fn' introduces an inline function: $x => fn($a) { $a + 1 }()
            if (_xpath40 && GetString(Current) == "fn" && Peek(1).Kind is TokenKind.LParen or TokenKind.LBrace)
            {
                var inlineFunc = ParseInlineFunction(start);
                var (fnArgs, fnKeywords) = ParseArgumentList();
                ThrowIfKeywordsOnDynamicCall(fnKeywords, start);
                return WithSpan(new DynamicFunctionCallNode(inlineFunc, fnArgs), start, End);
            }
            var name = GetString(Current);
            var (prefix, local, _) = SplitQName(name);
            Advance();
            var (args, keywords) = ParseArgumentList();
            return WithSpan(new FunctionCallNode(local, args, prefix, KeywordArguments: keywords), start, End);
        }
        if (Current.Kind == TokenKind.Dollar)
        {
            // Variable reference as function: $x => $f()
            Advance();
            var nameTok = ExpectName();
            var (prefix, local, _) = SplitQName(GetString(nameTok));
            var (args, keywords) = ParseArgumentList();
            ThrowIfKeywordsOnDynamicCall(keywords, start);
            return WithSpan(new DynamicFunctionCallNode(new VariableReferenceNode(local, prefix), args), start, End);
        }
        if (Current.Kind == TokenKind.LParen)
        {
            // Parenthesized expression as function: $x => ($f)()
            Advance();
            var expr = ParseExpr();
            Expect(TokenKind.RParen);
            var (args, keywords) = ParseArgumentList();
            ThrowIfKeywordsOnDynamicCall(keywords, start);
            return WithSpan(new DynamicFunctionCallNode(expr, args), start, End);
        }
        if (Current.Kind is TokenKind.KeywordEvery or TokenKind.KeywordSome
            && Peek(1).Kind == TokenKind.LParen)
        {
            // XPath 4.0: the quantifier keywords double as function names
            // (fn:every / fn:some), so $seq => every() is a legal arrow target
            // (atomic-equal-010).
            var name = GetString(Current);
            Advance();
            var (args, keywords) = ParseArgumentList();
            return WithSpan(new FunctionCallNode(name, args, Prefix: null, KeywordArguments: keywords), start, End);
        }
        if (Current.Kind == TokenKind.KeywordFunction)
        {
            var inlineFunc = ParseInlineFunction(start);
            var (args, keywords) = ParseArgumentList();
            ThrowIfKeywordsOnDynamicCall(keywords, start);
            return WithSpan(new DynamicFunctionCallNode(inlineFunc, args), start, End);
        }
        throw new XPathParseException("Expected function name, variable reference, or parenthesized expression after =>", Current.Start);
    }

    // Keyword arguments require the static signature of a named function; a dynamic
    // function call has none, so it is a static error (XPST0017, XPath 4.0 §4.6.1).
    private static void ThrowIfKeywordsOnDynamicCall(List<KeywordArgumentNode>? keywords, int position)
    {
        if (keywords is not null)
            throw new XPathParseException("XPST0017: Keyword arguments can only be used in calls of statically-known functions.", position);
    }

    // UnaryExpr ::= ("+" | "-")* ValueExpr
    private XPathAstNode ParseUnaryExpr()
    {
        int start = Current.Start;
        var ops = new List<UnaryOperator>();
        while (true)
        {
            if (Match(TokenKind.Plus)) ops.Add(UnaryOperator.Plus);
            else if (Match(TokenKind.Minus)) ops.Add(UnaryOperator.Minus);
            else break;
        }
        var expr = _allowFullFlwor && Current.Kind == TokenKind.Pragma ? ParseExtensionExpression()
            : IsValidateExpressionStart() ? ParseValidateExpression(Current.Start) : ParseSimpleMapExpr();
        for (int i = ops.Count - 1; i >= 0; i--)
            expr = WithSpan(new UnaryExpressionNode(ops[i], expr), start, End);
        return expr;
    }

    private XPathAstNode ParseExtensionExpression()
    {
        int start = Current.Start;
        var names = new List<QNameLiteralNode>();
        do
        {
            string text = GetString(Current)[2..^2];
            int offset = 0;
            while (offset < text.Length && IsPragmaWhitespace(text[offset])) offset++;
            if (offset == text.Length || text[offset] == '(')
                throw new XPathParseException("XPST0003: A pragma requires an EQName.", Current.Start);
            var lexer = new XPathLexer(text.AsSpan(offset));
            var token = lexer.NextToken();
            if (token.Start != 0)
                throw new XPathParseException("XPST0003: Only XML whitespace may precede a pragma name.", Current.Start);
            string name = token.Text(text.AsSpan(offset)).ToString();
            var (prefix, local, uri) = SplitQName(name);
            try
            {
                System.Xml.XmlConvert.VerifyNCName(local);
                if (prefix is not null) System.Xml.XmlConvert.VerifyNCName(prefix);
                System.Xml.XmlConvert.VerifyXmlChars(text);
            }
            catch (Exception ex) when (ex is System.Xml.XmlException or ArgumentException)
            { throw new XPathParseException("XPST0003: Invalid pragma EQName or content.", Current.Start); }
            int remainder = offset + token.Length;
            if (remainder < text.Length && !IsPragmaWhitespace(text[remainder]))
                throw new XPathParseException("XPST0003: Whitespace must separate a pragma name from its content.", Current.Start);
            names.Add(new QNameLiteralNode(local, prefix, uri));
            Advance();
        } while (Current.Kind == TokenKind.Pragma);
        Expect(TokenKind.LBrace);
        if (Current.Kind == TokenKind.RBrace)
            throw new XPathParseException("XQST0079: An ignored pragma requires an associated expression.", start);
        var expression = ParseExpr();
        Expect(TokenKind.RBrace);
        return WithSpan(new ExtensionExpressionNode(names, expression), start, End);
    }

    private static bool IsPragmaWhitespace(char c) => c is ' ' or '\t' or '\r' or '\n';

    private bool IsValidateExpressionStart() => _allowFullFlwor && Current.Kind == TokenKind.Name
        && GetString(Current) == "validate"
        && (Peek(1).Kind == TokenKind.LBrace || Peek(1).Kind == TokenKind.Name && GetString(Peek(1)) is "strict" or "lax" or "type");

    // SimpleMapExpr ::= PathExpr ("!" PathExpr)*
    private XPathAstNode ParseSimpleMapExpr()
    {
        int start = Current.Start;
        var left = ParsePathExpr();
        while (Match(TokenKind.Bang))
        {
            var right = ParsePathExpr();
            left = WithSpan(new BinaryExpressionNode(left, BinaryOperator.SimpleMap, right), start, End);
        }
        return left;
    }

    // ------------------------------------------------------------------
    // Path expressions
    // ------------------------------------------------------------------

    // PathExpr ::= ("/" RelativePathExpr?) | ("//" RelativePathExpr) | RelativePathExpr
    // In XQuery, '<' after '/' or '//' begins a direct element constructor — when the
    // lexer could not scan one it is a syntax error, not the less-than operator
    // (Steps-leading-lone-slash-2/3/4/5, PathExpr-5/7/8/9).
    private void ThrowIfConstructorLessThan()
    {
        if (_allowFullFlwor && Current.Kind == TokenKind.LessThan)
            throw new XPathParseException("XPST0003: '<' after '/' does not start a valid direct element constructor.", Current.Start);
    }

    private XPathAstNode ParsePathExpr()
    {
        int start = Current.Start;
        if (Match(TokenKind.Slash))
        {
            ThrowIfConstructorLessThan();
            if (IsAtEnd || !CanStartStepExpr(Current))
                return WithSpan(new PathExprNode(true, Array.Empty<XPathAstNode>()), start, End);
            var steps = ParseRelativePathExpr();
            return WithSpan(new PathExprNode(true, steps), start, End);
        }
        if (Match(TokenKind.SlashSlash))
        {
            ThrowIfConstructorLessThan();
            var steps = ParseRelativePathExpr();
            steps.Insert(0, new StepNode(XdmAxis.DescendantOrSelf, new NodeTest(NameTestKind.KindTest, "node"), Array.Empty<XPathAstNode>()));
            return WithSpan(new PathExprNode(true, steps), start, End);
        }
        var relSteps = ParseRelativePathExpr();
        if (relSteps.Count == 1)
            return relSteps[0];
        return WithSpan(new PathExprNode(false, relSteps), start, End);
    }

    // RelativePathExpr ::= StepExpr (("/" | "//") StepExpr)*
    private List<XPathAstNode> ParseRelativePathExpr()
    {
        var steps = new List<XPathAstNode> { ParseStepExpr(firstStep: true) };
        while (true)
        {
            if (Match(TokenKind.Slash))
            {
                ThrowIfConstructorLessThan();
                steps.Add(ParseStepExpr(firstStep: false));
            }
            else if (Match(TokenKind.SlashSlash))
            {
                ThrowIfConstructorLessThan();
                steps.Add(new StepNode(XdmAxis.DescendantOrSelf, new NodeTest(NameTestKind.KindTest, "node"), Array.Empty<XPathAstNode>()));
                steps.Add(ParseStepExpr(firstStep: false));
            }
            else break;
        }
        return steps;
    }

    // StepExpr ::= PostfixExpr | AxisStep
    private XPathAstNode ParseStepExpr(bool firstStep)
    {
        int start = Current.Start;

        // Abbreviated reverse step: ..
        if (Current.Kind == TokenKind.DotDot)
        {
            Advance();
            var preds = ParsePredicateList();
            return WithSpan(new StepNode(XdmAxis.Parent, new NodeTest(NameTestKind.KindTest, "node"), preds), start, End);
        }

        // Abbreviated forward step: @ NodeTest
        if (Current.Kind == TokenKind.At)
        {
            Advance();
            var test = ParseNodeTest();
            var preds = ParsePredicateList();
            return WithSpan(new StepNode(XdmAxis.Attribute, test, preds), start, End);
        }

        // Explicit axis: axis::NodeTest
        if ((Current.Kind == TokenKind.Name || IsKeywordName(Current.Kind)) && Peek(1).Kind == TokenKind.DoubleColon)
        {
            return ParseAxisStep(start);
        }

        // Name that is a kind test: node(), text(), etc.
        // Prefixed names are always function calls, never kind tests.
        // A braced URI literal (Q{uri}text) is also never a kind test: SplitQName
        // drops its namespace, leaving local 'text', so without this guard a
        // braced function call in step position (A ! Q{ns}text(...)) would be
        // misparsed as a text() kind-test step (sx-treat-107/108/109).
        if (Current.Kind == TokenKind.Name || IsKeywordName(Current.Kind))
        {
            var name = GetString(Current);
            var (prefix, local, _) = SplitQName(name);
            if (!name.StartsWith("Q{", StringComparison.Ordinal)
                && string.IsNullOrEmpty(prefix) && IsKindTestName(local) && Peek(1).Kind == TokenKind.LParen)
            {
                return ParseAxisStep(start);
            }
        }

        // XQuery computed constructors (element/attribute/text/document/comment/PI/namespace)
        // are primary expressions, not name-test steps.
        if (_allowFullFlwor && Current.Kind == TokenKind.Name && IsComputedConstructorForm(GetString(Current)))
        {
            return ParsePostfixExpr();
        }

        // OrderedExpr / UnorderedExpr (XQuery only) are primary expressions, not name-test steps.
        if (_allowFullFlwor && Current.Kind == TokenKind.Name
            && GetString(Current) is "ordered" or "unordered"
            && Peek(1).Kind == TokenKind.LBrace)
        {
            return ParsePostfixExpr();
        }

        // Name test or wildcard in a step context
        // Exclude names followed by LParen (function calls/kind tests already handled)
        // Exclude names followed by Hash (named function refs)
        // Exclude keyword primary-expr starters (map {, array {, array [, function () when followed by their opener)
        bool isPrimaryExprKeyword = (Current.Kind == TokenKind.KeywordMap && Peek(1).Kind == TokenKind.LBrace)
            || (Current.Kind == TokenKind.KeywordArray && (Peek(1).Kind == TokenKind.LBrace || Peek(1).Kind == TokenKind.LBracket))
            || (Current.Kind == TokenKind.KeywordFunction && Peek(1).Kind is TokenKind.LParen or TokenKind.LBrace);
        // XPath 4.0: 'fn {' / 'fn (' starts an inline function, never a name test.
        bool isFnInlineFunction = _xpath40 && Current.Kind == TokenKind.Name && GetString(Current) == "fn"
            && Peek(1).Kind is TokenKind.LBrace or TokenKind.LParen;
        if (!isFnInlineFunction && ((Current.Kind == TokenKind.Name || (IsKeywordName(Current.Kind) && !isPrimaryExprKeyword)) && Peek(1).Kind != TokenKind.LParen && Peek(1).Kind != TokenKind.Hash) || Current.Kind == TokenKind.Star)
        {
            return ParseAxisStep(start);
        }

        // XPath 4.0: a string literal in step position after "/" or "//" is a map key
        // lookup step ($m/"key" ≡ $m?"key"; $m//"key" also descends through nested
        // maps and arrays). It never applies to the first step of a path, where a
        // string literal remains a primary expression (parse-xml('<a/>') arguments).
        if (!firstStep && _xpath40 && Current.Kind == TokenKind.StringLiteral)
        {
            string key = Unquote(GetString(Current));
            Advance();
            var preds = ParsePredicateList();
            return WithSpan(new StepNode(XdmAxis.Child, new NodeTest(NameTestKind.LookupKey, key), preds), start, End);
        }

        // XPath 4.0: an integer literal in step position after "/" or "//" selects the
        // child JNode whose key equals that integer ([4,5,6]/2 is the member JNode keyed 2;
        // {1:'a'}/1 is the entry JNode with integer key 1).
        if (!firstStep && _xpath40 && Current.Kind == TokenKind.IntegerLiteral)
        {
            string index = GetString(Current);
            Advance();
            var preds = ParsePredicateList();
            return WithSpan(new StepNode(XdmAxis.Child, new NodeTest(NameTestKind.LookupIndex, index), preds), start, End);
        }

        // Otherwise, it's a postfix expression (primary + predicates/args/lookup)
        return ParsePostfixExpr();
    }

    private StepNode ParseAxisStep(int start)
    {
        XdmAxis axis = XdmAxis.Child;
        bool axisExplicit = false;
        if ((Current.Kind == TokenKind.Name || IsKeywordName(Current.Kind)) && Peek(1).Kind == TokenKind.DoubleColon)
        {
            axis = ParseAxisName();
            // XPath 2.0+ removed the namespace axis; XQuery does not support it at all
            // (K2-Axes-54). XPath/XSLT keep the engine's namespace-axis support.
            if (axis == XdmAxis.Namespace && _allowFullFlwor)
                throw new XPathParseException("XPST0003: The namespace axis is not supported in XQuery.", start);
            Expect(TokenKind.DoubleColon);
            axisExplicit = true;
        }
        var test = ParseNodeTest();
        var preds = ParsePredicateList();

        // XQST0134: an implicit-axis namespace-node() step uses the namespace axis,
        // which XQuery does not support (Axes112). Explicit axes (self, attribute, and
        // the engine's namespace-axis support) are unaffected.
        if (!axisExplicit && _allowFullFlwor
            && test.Kind == NameTestKind.KindTest && test.Name == "namespace-node")
        {
            throw new XPathParseException("XQST0134: The namespace axis is not supported in XQuery.", start);
        }

        // XPath 2.0 §3.2.1.1: default axis for attribute/namespace kind tests
        if (!axisExplicit && test.Kind == NameTestKind.KindTest)
        {
            axis = test.Name switch
            {
                "attribute" or "schema-attribute" => XdmAxis.Attribute,
                "namespace-node" => XdmAxis.Namespace,
                _ => axis
            };
        }

        return WithSpan(new StepNode(axis, test, preds), start, End);
    }

    private XdmAxis ParseAxisName()
    {
        var name = GetString(Current).ToLowerInvariant();
        Advance();
        return name switch
        {
            "ancestor" => XdmAxis.Ancestor,
            "ancestor-or-self" => XdmAxis.AncestorOrSelf,
            "attribute" => XdmAxis.Attribute,
            "child" => XdmAxis.Child,
            "descendant" => XdmAxis.Descendant,
            "descendant-or-self" => XdmAxis.DescendantOrSelf,
            "following" => XdmAxis.Following,
            "following-sibling" => XdmAxis.FollowingSibling,
            "namespace" => XdmAxis.Namespace,
            "parent" => XdmAxis.Parent,
            "preceding" => XdmAxis.Preceding,
            "preceding-sibling" => XdmAxis.PrecedingSibling,
            "self" => XdmAxis.Self,
            _ => throw new XPathParseException($"Unknown axis: {name}", Current.Start)
        };
    }

    private NodeTest ParseNodeTest()
    {
        int start = Current.Start;

        // XPath 4.0 (PR2667): a braced key selector — child::{K} — selects the child
        // JNode whose key equals the evaluated key expression (arrays: position or any
        // atomic key; maps: matching atomic key).
        if (Current.Kind == TokenKind.LBrace)
        {
            if (!_xpath40)
                throw new XPathParseException("XPST0003: A braced key selector in a step requires XPath 4.0.", start);
            Advance();
            var keyExpr = ParseExpr();
            Expect(TokenKind.RBrace);
            return new NodeTest(NameTestKind.LookupComputed, LookupExpression: keyExpr);
        }

        // Wildcard: *
        if (Match(TokenKind.Star))
        {
            var starTok = _tokens[_position - 1];
            // *:local — greedy, except inside a map-constructor key where the wildcard
            // form applies only when the entry ':' follows the local name; otherwise
            // '*' alone is the key and the first ':' is the entry separator (map{* :b}).
            if (Current.Kind == TokenKind.Colon &&
                (_mapKeyDepth == 0
                    || (Peek(1).Kind == TokenKind.Name && !GetString(Peek(1)).Contains(':')
                        && Peek(2).Kind == TokenKind.Colon)))
            {
                // Whitespace or comments may not intervene between the parts of a
                // wildcard QName (K2-Axes-5..8/11/13/15/16).
                if (HasTriviaGap(starTok, Current))
                    throw new XPathParseException("XPST0003: Whitespace and comments are not allowed between '*' and ':' in a wildcard name test.", starTok.Start);
                var colonTok = Current;
                Advance(); // ':'
                var local = ExpectName();
                if (HasTriviaGap(colonTok, local))
                    throw new XPathParseException("XPST0003: Whitespace and comments are not allowed between ':' and the local name in a wildcard name test.", colonTok.Start);
                return new NodeTest(NameTestKind.QName, GetString(local), "*");
            }
            return new NodeTest(NameTestKind.AnyName);
        }

        if (Current.Kind == TokenKind.Name || IsKeywordName(Current.Kind))
        {
            var nameTok = Current;
            var name = GetString(Current);
            var (prefix, local, nsUri) = SplitQName(name);

            // URI-qualified wildcard: Q{uri}* (including empty URI Q{}*). The URI part is
            // whitespace-normalized, so Q{   }* matches the empty namespace (eqname-023).
            if (name.Length > 3 && name[0] == 'Q' && name[1] == '{' && name[^1] == '*')
            {
                int closeBrace = name.IndexOf('}');
                if (closeBrace >= 2)
                {
                    Advance();
                    var wildcardNs = string.Join(' ', name[2..closeBrace].Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries));
                    return new NodeTest(NameTestKind.NamespaceAny, null, wildcardNs);
                }
            }

            // Kind test: node(), text(), etc.
            // Prefixed names are always function calls, never kind tests.
            if (string.IsNullOrEmpty(prefix) && IsKindTestName(local) && Peek(1).Kind == TokenKind.LParen)
            {
                return ParseKindTest();
            }

            Advance();

            // prefix:* — peek rather than consume: a ':' not followed by '*' is a
            // map-constructor entry separator (map{b:2}), not part of the name test.
            // Inside a map key the wildcard form applies only when the entry ':' follows
            // the '*' (map{a:b:*} vs map{a:*:c}, MapConstructor-028/030).
            if (Current.Kind == TokenKind.Colon && Peek(1).Kind == TokenKind.Star &&
                (_mapKeyDepth == 0 || Peek(2).Kind == TokenKind.Colon))
            {
                // A braced URI literal is never followed by a colon: Q{uri}:* is malformed
                // (nametest-23; the URI-qualified wildcard form is Q{uri}*).
                if (name.StartsWith("Q{", StringComparison.Ordinal))
                    throw new XPathParseException($"XPST0003: A braced URI literal must not be followed by ':*' ('{name}:*').", Current.Start);
                // Whitespace or comments may not intervene between the parts of a
                // wildcard QName (K2-Axes-9/10/12/14).
                if (HasTriviaGap(nameTok, Current) || HasTriviaGap(Current, Peek(1)))
                    throw new XPathParseException($"XPST0003: Whitespace and comments are not allowed within the wildcard name test '{name}:*'.", nameTok.Start);
                Advance(); // ':'
                Advance(); // '*'
                return new NodeTest(NameTestKind.NamespaceAny, name);
            }

            if (!string.IsNullOrEmpty(nsUri))
                return new NodeTest(NameTestKind.QName, local, nsUri);
            if (prefix is null)
                return new NodeTest(NameTestKind.LocalName, local, nsUri);

            // The xml prefix is predefined in every XML document. Resolve it to the
            // standard XML namespace so node tests such as @xml:lang match attributes
            // in that namespace rather than being treated as prefix-only wildcards.
            if (prefix == "xml")
                return new NodeTest(NameTestKind.QName, local, "http://www.w3.org/XML/1998/namespace");

            return new NodeTest(NameTestKind.QName, local, prefix);
        }

        throw new XPathParseException($"Expected node test but found {Current.Kind}", start);
    }

    private NodeTest ParseKindTest()
    {
        var nameTok = Current;
        var name = GetString(Current);
        Advance();
        Expect(TokenKind.LParen);

        string? argument = null;
        string? typeName = null;
        string? innerName = null;

        // item() is an ItemType in SequenceType syntax only; as a node test in a step
        // it is a reserved-name syntax error (function-call-reserved-function-names-026).
        if (name == "item")
            throw new XPathParseException("XPST0003: item() is not a node test and cannot appear in a path step.", nameTok.Start);

        // Kind tests that take no argument at all (K2-NodeTest-4/5/6).
        if (name is "text" or "comment" or "node" or "namespace-node")
        {
            if (Current.Kind != TokenKind.RParen)
                throw new XPathParseException($"XPST0003: The {name}() kind test does not allow an argument.", Current.Start);
        }
        else if (name == "document-node")
        {
            if (Current.Kind == TokenKind.RParen)
            {
                // Empty document-node() is accepted (matches any document node), e.g.
                // K2-Axes-105 self::document-node().
            }
            else
            {
                // Only element() or schema-element() tests may appear inside document-node()
                // (K2-NodeTest-7/12/14..20/22).
                (argument, innerName, typeName) = ParseDocumentNodeContent();
            }
        }
        else if (name == "processing-instruction")
        {
            if (Current.Kind != TokenKind.RParen)
            {
                // The argument must be an NCName or a string literal holding a valid NCName
                // (anything else is XPST0003); a string literal is whitespace-trimmed and
                // validated (XPTY0004, K2-NameTest-21/23).
                if (Current.Kind == TokenKind.StringLiteral)
                {
                    argument = Unquote(GetString(Current)).Trim();
                    if (!IsValidNCName(argument))
                        throw new XPathParseException($"XPTY0004: The processing-instruction() name '{argument}' is not a valid NCName.", Current.Start);
                    Advance();
                }
                else if (Current.Kind == TokenKind.Name)
                {
                    argument = GetString(Current);
                    // Only an unprefixed NCName is a syntactically valid PI name (K2-NameTest-25).
                    if (!IsValidNCName(argument))
                        throw new XPathParseException($"XPST0003: The processing-instruction() name '{argument}' is not a valid NCName.", Current.Start);
                    Advance();
                }
                else
                {
                    throw new XPathParseException($"XPST0003: The processing-instruction() argument must be a name or string literal but found {Current.Kind}.", Current.Start);
                }
                // skip to closing paren
                while (!IsAtEnd && Current.Kind != TokenKind.RParen)
                    Advance();
            }
        }
        else if (name is "element" or "attribute" or "schema-element" or "schema-attribute")
        {
            // Schema-aware kind tests require schema awareness. Grammar errors are checked
            // here: the empty form, a wildcard, and a string literal argument are XPST0003
            // (K2-Axes-85, K2-NodeTest-8/9, K2-NameTest-33/34). Without schema awareness an
            // unprefixed name is XPST0008 (K2-Axes-84); prefixed names are namespace-checked
            // at compile time (XPST0081, K2-NodeTest-23..27). With schema awareness
            // (REQ-104) the name argument parses freely and its declaration is validated
            // against the compiled schema set at compile time (XPST0008 when absent).
            if (name is "schema-element" or "schema-attribute")
            {
                if (Current.Kind == TokenKind.RParen)
                    throw new XPathParseException($"XPST0003: The {name}() kind test requires a name argument.", Current.Start);
                if (Current.Kind == TokenKind.Star)
                    throw new XPathParseException($"XPST0003: The {name}() kind test requires a name, not a wildcard.", Current.Start);
                if (Current.Kind == TokenKind.StringLiteral)
                    throw new XPathParseException($"XPST0003: The {name}() kind test requires a name, not a string literal.", Current.Start);
                if (!_schemaAware && Current.Kind == TokenKind.Name && !GetString(Current).Contains(':'))
                    throw new XPathParseException($"XPST0008: Schema-aware kind test {name}() is not supported (no schema awareness).", Current.Start);
            }

            if (Current.Kind != TokenKind.RParen)
            {
                // argument is a name test (QName, *, prefix:*, or NCName), optionally followed
                // by a comma and a schema type name (attribute(foo, xs:integer)).
                if (Current.Kind == TokenKind.Star)
                {
                    argument = "*";
                    Advance();
                }
                else if (Current.Kind == TokenKind.Name)
                {
                    var argName = GetString(Current);
                    Advance();
                    if (Current.Kind == TokenKind.Colon)
                    {
                        Advance();
                        if (Current.Kind == TokenKind.Star)
                        {
                            argument = argName + ":*";
                            Advance();
                        }
                        else if (Current.Kind == TokenKind.Name)
                        {
                            argument = argName + ":" + GetString(Current);
                            Advance();
                        }
                        else
                        {
                            throw new XPathParseException($"XPST0003: Expected a local name or '*' after ':' in the {name}() name test.", Current.Start);
                        }
                    }
                    else
                    {
                        argument = argName;
                    }
                }
                else
                {
                    // Anything but a name or wildcard is a syntax error: reserved function
                    // names used as calls (element(1), attribute(1), ...) land here (K2-NodeTest
                    // via function-call-reserved-function-names-001/004/020/023).
                    throw new XPathParseException($"XPST0003: The {name}() kind test argument must be a name or '*', not {Current.Kind}.", Current.Start);
                }
                // Optional schema type name after a comma (validated at evaluation time).
                if (Match(TokenKind.Comma))
                {
                    if (Current.Kind == TokenKind.Name || IsKeywordName(Current.Kind))
                    {
                        typeName = GetString(Current);
                        Advance();
                    }
                    // An occurrence indicator may follow the type name; it does not affect
                    // single-node kind-test matching.
                    if (Current.Kind == TokenKind.Question)
                        Advance();
                }
                // skip any remaining content to the closing paren
                while (!IsAtEnd && Current.Kind != TokenKind.RParen)
                    Advance();
            }
        }
        else
        {
            // For other kind tests skip content.
            int depth = 1;
            while (!IsAtEnd && depth > 0)
            {
                if (Current.Kind == TokenKind.LParen) depth++;
                else if (Current.Kind == TokenKind.RParen) depth--;
                if (depth > 0) Advance();
            }
        }

        Expect(TokenKind.RParen);
        return new NodeTest(NameTestKind.KindTest, name, KindTestArgument: argument, KindTestTypeName: typeName, KindTestInnerName: innerName);
    }

    /// <summary>
    /// Parses the content of <c>document-node(...)</c>: only an <c>element()</c> or
    /// <c>schema-element()</c> test is allowed inside. Returns the inner argument, the
    /// inner test name ("element" or "schema-element"), and the optional inner schema
    /// type name (<c>element(E, T)</c>).
    /// </summary>
    private (string? Argument, string? InnerName, string? TypeName) ParseDocumentNodeContent()
    {
        if (Current.Kind == TokenKind.RParen)
            throw new XPathParseException("XPST0003: The document-node() kind test requires an element() or schema-element() test, not empty parentheses.", Current.Start);
        if (Current.Kind == TokenKind.Star)
            throw new XPathParseException("XPST0003: The document-node() kind test requires an element() or schema-element() test, not a wildcard.", Current.Start);
        if (Current.Kind != TokenKind.Name && !IsKeywordName(Current.Kind))
            throw new XPathParseException($"XPST0003: The document-node() kind test requires an element() or schema-element() test but found {Current.Kind}.", Current.Start);

        var inner = GetString(Current);
        if (inner is not ("element" or "schema-element"))
            throw new XPathParseException($"XPST0003: Only element() or schema-element() tests are allowed inside document-node(), not {inner}().", Current.Start);
        Advance();
        Expect(TokenKind.LParen);

        string? argument = null;
        string? typeName = null;

        if (inner == "schema-element")
        {
            // Mirror the top-level schema-element() checks: the empty form, a wildcard,
            // and a string literal are XPST0003; an unprefixed name is XPST0008 unless
            // schema awareness is enabled (K2-NodeTest-19, REQ-104).
            if (Current.Kind == TokenKind.RParen)
                throw new XPathParseException("XPST0003: The schema-element() kind test requires a name argument.", Current.Start);
            if (Current.Kind == TokenKind.Star)
                throw new XPathParseException("XPST0003: The schema-element() kind test requires a name, not a wildcard.", Current.Start);
            if (Current.Kind == TokenKind.StringLiteral)
                throw new XPathParseException("XPST0003: The schema-element() kind test requires a name, not a string literal.", Current.Start);
            if (!_schemaAware && Current.Kind == TokenKind.Name && !GetString(Current).Contains(':'))
                throw new XPathParseException("XPST0008: Schema-aware kind test schema-element() is not supported (no schema awareness).", Current.Start);
        }

        // Inner element()/schema-element() argument: a name test (QName, *, prefix:*),
        // optionally followed by a comma and a schema type name.
        if (Current.Kind == TokenKind.Star)
        {
            argument = "*";
            Advance();
        }
        else if (Current.Kind == TokenKind.Name)
        {
            var argName = GetString(Current);
            Advance();
            if (Current.Kind == TokenKind.Colon)
            {
                Advance();
                if (Current.Kind == TokenKind.Star)
                {
                    argument = argName + ":*";
                    Advance();
                }
                else if (Current.Kind == TokenKind.Name)
                {
                    argument = argName + ":" + GetString(Current);
                    Advance();
                }
                else
                {
                    throw new XPathParseException("XPST0003: Expected a local name or '*' after ':' in the schema-element()/element() name test.", Current.Start);
                }
            }
            else
            {
                argument = argName;
            }
        }
        else
        {
            throw new XPathParseException($"XPST0003: The {inner}() kind test argument must be a name or '*', not {Current.Kind}.", Current.Start);
        }

        // Optional schema type name after a comma (validated at evaluation time).
        if (Match(TokenKind.Comma))
        {
            if (Current.Kind == TokenKind.Name || IsKeywordName(Current.Kind))
            {
                typeName = GetString(Current);
                Advance();
            }
            if (Current.Kind == TokenKind.Question)
                Advance();
        }
        // skip any remaining content to the closing paren
        while (!IsAtEnd && Current.Kind != TokenKind.RParen)
            Advance();

        Expect(TokenKind.RParen);
        return (argument, inner, typeName);
    }

    private List<XPathAstNode> ParsePredicateList()
    {
        var preds = new List<XPathAstNode>();
        while (Current.Kind == TokenKind.LBracket)
        {
            preds.Add(ParsePredicate());
        }
        return preds;
    }

    private XPathAstNode ParsePredicate()
    {
        int start = Current.Start;
        Expect(TokenKind.LBracket);
        var expr = ParseExpr();
        Expect(TokenKind.RBracket);
        return WithSpan(new PredicateNode(expr), start, End);
    }

    // ------------------------------------------------------------------
    // Postfix expressions
    // ------------------------------------------------------------------

    private XPathAstNode ParsePostfixExpr()
    {
        int start = Current.Start;
        var expr = ParsePrimaryExpr();
        while (true)
        {
            if (Current.Kind == TokenKind.LBracket)
            {
                var pred = ParsePredicate();
                expr = WithSpan(new PostfixPredicateNode(expr, pred), start, End);
            }
            else if (Current.Kind == TokenKind.LParen)
            {
                // Dynamic function call: $f(1,2) or (fn:abs#1)(3) or function-lookup(...)(...)
                var (args, keywords) = ParseArgumentList();
                ThrowIfKeywordsOnDynamicCall(keywords, start);
                expr = WithSpan(new DynamicFunctionCallNode(expr, args), start, End);
            }
            else if (Current.Kind == TokenKind.Question)
            {
                Advance();
                if (Match(TokenKind.Star))
                {
                    expr = WithSpan(new LookupWildcardNode(expr), start, End);
                }
                else
                {
                    var key = ParseLookupKey();
                    expr = WithSpan(new LookupNode(expr, key), start, End);
                }
            }
            else break;
        }
        return expr;
    }

    // Converts an IntegerLiteral token's text to a literal AST node. Handles the
    // XPath 4.0 forms: hexadecimal (0x...), binary (0b...), and underscore separators.
    private static XPathAstNode IntegerLiteralFromText(string str)
    {
        if (str.StartsWith("0x", StringComparison.Ordinal) || str.StartsWith("0b", StringComparison.Ordinal))
        {
            int numberBase = str[1] == 'x' ? 16 : 2;
            System.Numerics.BigInteger value = 0;
            foreach (char d in str.AsSpan(2))
            {
                if (d == '_') continue;
                int digit = d <= '9' ? d - '0' : (char.ToLowerInvariant(d) - 'a' + 10);
                value = value * numberBase + digit;
            }
            if (value <= long.MaxValue)
                return new IntegerLiteralNode((long)value);
            // Beyond long: still xs:integer — tag the decimal fallback (see change 1.56).
            return new DecimalLiteralNode((decimal)value, IsIntegerLiteral: true);
        }

        var cleaned = str.Replace("_", "", StringComparison.Ordinal);
        if (long.TryParse(cleaned, NumberStyles.Integer, CultureInfo.InvariantCulture, out var i))
            return new IntegerLiteralNode(i);
        if (decimal.TryParse(cleaned, NumberStyles.Float, CultureInfo.InvariantCulture, out var dec))
            // An integer literal beyond the long range is still an xs:integer
            // (cbcl-numeric-multiply-026) — tag it so it is not typed xs:decimal.
            return new DecimalLiteralNode(dec, IsIntegerLiteral: true);
        return new DoubleLiteralNode(double.Parse(cleaned, CultureInfo.InvariantCulture));
    }

    private XPathAstNode ParseLookupKey()
    {
        int start = Current.Start;
        if (Match(TokenKind.Star))
            return WithSpan(new StringLiteralNode("*"), start, End);
        if (Current.Kind == TokenKind.IntegerLiteral)
        {
            var node = IntegerLiteralFromText(GetString(Current));
            Advance();
            return WithSpan(node, start, End);
        }
        if (Current.Kind == TokenKind.Name || IsKeywordName(Current.Kind))
        {
            var name = GetString(Current);
            // KeySpecifier allows only a plain NCName — qualified names (xs:integer,
            // Q{}integer) are a static error here (Lookup-156/157).
            if (name.Contains(':') || name.Contains('{'))
                throw new XPathParseException($"XPST0003: Qualified name '{name}' is not allowed as a lookup key", Current.Start);
            Advance();
            return WithSpan(new StringLiteralNode(name), start, End);
        }
        if (Current.Kind == TokenKind.StringLiteral)
        {
            var str = Unquote(GetString(Current));
            Advance();
            return WithSpan(new StringLiteralNode(str), start, End);
        }
        if (Current.Kind == TokenKind.LParen)
        {
            Advance();
            if (Match(TokenKind.RParen))
                return WithSpan(new SequenceExpressionNode(Array.Empty<XPathAstNode>()), start, End);
            var expr = ParseExpr();
            Expect(TokenKind.RParen);
            return WithSpan(new ParenthesizedExprNode(expr), start, End);
        }
        if (Current.Kind == TokenKind.Dollar)
        {
            // XPath 4.0 (PR2962): a variable reference is a legal lookup key
            // ($map?$key) alongside literals, NCNames, and parenthesized keys.
            Advance();
            var varTok = ExpectName();
            var (vp, vl, vns) = SplitQName(GetString(varTok));
            return WithSpan(new VariableReferenceNode(vl, vp, vns), start, End);
        }
        throw new XPathParseException("Expected lookup key", Current.Start);
    }

    // ------------------------------------------------------------------
    // Primary expressions
    // ------------------------------------------------------------------

    private XPathAstNode ParsePrimaryExpr()
    {
        int start = Current.Start;
        switch (Current.Kind)
        {
            case TokenKind.Constructor:
                return ParseDirectElementConstructor();

            case TokenKind.StringLiteral:
                var s = Unquote(GetString(Current));
                Advance();
                return WithSpan(new StringLiteralNode(s), start, End);

            case TokenKind.StringTemplate:
                return ParseStringTemplate(start);

            case TokenKind.IntegerLiteral:
                var nodeI = IntegerLiteralFromText(GetString(Current));
                Advance();
                return WithSpan(nodeI, start, End);

            case TokenKind.DecimalLiteral:
                // XPath 4.0 allows underscore separators; they carry no value.
                var strD = GetString(Current).Replace("_", "", StringComparison.Ordinal);
                XPathAstNode nodeD;
                if (decimal.TryParse(strD, NumberStyles.Float, CultureInfo.InvariantCulture, out var d))
                    nodeD = new DecimalLiteralNode(d);
                else
                    nodeD = new DoubleLiteralNode(double.Parse(strD, CultureInfo.InvariantCulture));
                Advance();
                return WithSpan(nodeD, start, End);

            case TokenKind.DoubleLiteral:
                var f = double.Parse(GetString(Current).Replace("_", "", StringComparison.Ordinal), CultureInfo.InvariantCulture);
                Advance();
                return WithSpan(new DoubleLiteralNode(f), start, End);

            case TokenKind.Dollar:
                Advance();
                var varTok = ExpectName();
                var (vp, vl, vns) = SplitQName(GetString(varTok));
                return WithSpan(new VariableReferenceNode(vl, vp, vns), start, End);

            case TokenKind.Hash:
                // XPath 4.0 QName literal: #local, #prefix:local, or #Q{uri}local
                // (PR1976/PR2227). Whitespace and comments after '#' are permitted
                // (Literals-40-925/926: the lexer skips them before the next token).
                if (!_xpath40)
                    throw new XPathParseException("XPST0003: QName literals (#) require XPath 4.0.", start);
                Advance();
                if (Current.Kind != TokenKind.Name && !IsKeywordName(Current.Kind))
                    throw new XPathParseException($"XPST0003: Expected a QName after '#' but found {Current.Kind}", Current.Start);
                return ParseQNameLiteral(start);

            case TokenKind.LParen:
                Advance();
                if (Match(TokenKind.RParen))
                    return WithSpan(new SequenceExpressionNode(Array.Empty<XPathAstNode>()), start, End);
                var inner = ParseExpr();
                Expect(TokenKind.RParen);
                return WithSpan(new ParenthesizedExprNode(inner), start, End);

            case TokenKind.Dot:
                Advance();
                return WithSpan(new ContextItemNode(), start, End);

            case TokenKind.Question:
                // UnaryLookup: ?KS is equivalent to .?KS (lookup on the context item).
                Advance();
                if (Match(TokenKind.Star))
                    return WithSpan(new LookupWildcardNode(new ContextItemNode()), start, End);
                return WithSpan(new LookupNode(new ContextItemNode(), ParseLookupKey()), start, End);

            case TokenKind.Name:
                var name = GetString(Current);
                if (_allowFullFlwor && IsComputedConstructorForm(name))
                    return ParseComputedConstructor(start);
                // OrderedExpr / UnorderedExpr (XQuery only): identity in this engine —
                // sequences are always produced in document order, which is a valid
                // implementation of both ordering modes. An empty body is the empty
                // sequence (K-OrderExpr-1a/2a).
                if (_allowFullFlwor && name is "ordered" or "unordered" && Peek(1).Kind == TokenKind.LBrace)
                {
                    Advance();
                    Expect(TokenKind.LBrace);
                    if (Match(TokenKind.RBrace))
                        return WithSpan(new SequenceExpressionNode(Array.Empty<XPathAstNode>()), start, End);
                    var orderedBody = ParseExpr();
                    Expect(TokenKind.RBrace);
                    return orderedBody;
                }
                // XPath 4.0 §4.6.6: 'fn' is a synonym for the 'function' keyword in an
                // inline function expression (fn($a) { ... } or the focus form fn { ... }).
                if (name == "fn" && Peek(1).Kind is TokenKind.LBrace or TokenKind.LParen)
                {
                    if (!_xpath40)
                        throw new XPathParseException("XPST0003: The 'fn' inline function keyword requires XPath 4.0.", start);
                    return ParseInlineFunction(start);
                }
                var (prefix, local, _) = SplitQName(name);
                if (Peek(1).Kind == TokenKind.LParen)
                    return ParseFunctionCall(start);
                if (Peek(1).Kind == TokenKind.Hash)
                    return ParseNamedFunctionRef(start);
                throw new XPathParseException($"Unexpected name '{name}' in primary expression", start);

            case TokenKind.Percent:
                // Annotations on an inline function expression (annotation-3/30/31/32).
                // Annotations are an XQuery-only grammar extension (inline-fn-016).
                if (!_allowFullFlwor)
                    throw new XPathParseException("XPST0003: Annotations are not allowed in XPath.", start);
                SkipInlineAnnotations();
                if (Current.Kind != TokenKind.KeywordFunction)
                    throw new XPathParseException($"XPST0003: Expected 'function' after annotations but found {Current.Kind}", Current.Start);
                return ParseInlineFunction(start);

            case TokenKind.KeywordFunction:
                return ParseInlineFunction(start);

            case TokenKind.KeywordMap:
                return ParseMapConstructor(start);

            case TokenKind.KeywordArray:
                return ParseCurlyArrayConstructor(start);

            case TokenKind.LBrace:
                // XPath 4.0 (PR2778): the "map" keyword is optional — a bare {…} is a
                // map constructor. In 3.1 mode '{' remains invalid in primary position.
                if (!_xpath40)
                    throw new XPathParseException("XPST0003: Unexpected '{' in primary expression", start);
                return ParseBracedMapConstructor(start);

            case TokenKind.LBracket:
                return ParseSquareArrayConstructor(start);

            default:
                // XQuery allows most keywords to be used as function names when they are
                // followed by '(' or '#' in a primary-expression context (xquery30keywords5).
                // Reserved function names (e.g., 'if', 'function', 'map', 'array') remain
                // rejected; they are handled by dedicated grammar rules above.
                // Only keyword tokens can act as names here: operator symbols ('<', '>',
                // '<<', '>>') and invalid tokens are never function names — a digit-led or
                // operator-led "call" such as 1fd() or >() is a syntax error (XPST0003,
                // K-FunctionCallExpr-9, K-NodeAfter-5/7, K-NodeBefore-5/7).
                {
                    var kwName = GetString(Current);
                    if (IsKeywordName(Current.Kind) && !ReservedFunctionNames.Contains(kwName))
                    {
                        if (Peek(1).Kind == TokenKind.LParen)
                            return ParseFunctionCall(start);
                        if (Peek(1).Kind == TokenKind.Hash)
                            return ParseNamedFunctionRef(start);
                    }
                    throw new XPathParseException($"Unexpected token {Current.Kind} in primary expression", start);
                }
        }
    }

    // ------------------------------------------------------------------
    // XQuery computed constructors
    // ------------------------------------------------------------------

    private bool IsComputedConstructorForm(string name)
    {
        switch (name)
        {
            case "element":
            case "attribute":
            case "processing-instruction":
            case "namespace":
                // "keyword" "{" | "keyword" QName "{"
                // The name may itself be a keyword used as an ordinary NCName
                // (e.g. 'attribute return {()}' constructs an attribute named 'return').
                return Peek(1).Kind == TokenKind.LBrace ||
                       ((Peek(1).Kind == TokenKind.Name || IsKeywordName(Peek(1).Kind)) && Peek(2).Kind == TokenKind.LBrace);
            case "text":
            case "document":
            case "comment":
                return Peek(1).Kind == TokenKind.LBrace;
            default:
                return false;
        }
    }

    private XPathAstNode ParseComputedConstructor(int start)
    {
        string keyword = GetString(Current);
        Advance();

        switch (keyword)
        {
            case "element":
            case "attribute":
            case "processing-instruction":
            case "namespace":
            {
                // Name form: EQName (possibly Q{uri}local) or computed "{" Expr "}".
                XPathAstNode? nameExpression = null;
                string? local = null, prefix = null, ns = null;
                if (Current.Kind == TokenKind.LBrace)
                {
                    Advance();
                    nameExpression = ParseExpr();
                    Expect(TokenKind.RBrace);
                }
                else
                {
                    var nameTok = ExpectName();
                    (prefix, local, ns) = SplitQName(GetString(nameTok));
                    // A static processing-instruction target must be an NCName; a
                    // prefixed or URI-qualified name is a syntax error (XPST0003).
                    if (keyword == "processing-instruction" && (prefix is not null || ns is not null))
                        throw new XPathParseException($"XPST0003: A processing-instruction target must be an unprefixed NCName, not '{GetString(nameTok)}'.", start);
                }
                Expect(TokenKind.LBrace);
                // Computed constructor content may be empty ({}), producing the empty sequence.
                var content = Current.Kind == TokenKind.RBrace
                    ? new SequenceExpressionNode(Array.Empty<XPathAstNode>())
                    : ParseExpr();
                Expect(TokenKind.RBrace);
                return keyword switch
                {
                    "element" => WithSpan(new ComputedElementConstructorNode(nameExpression, local, prefix, ns, content), start, End),
                    "attribute" => WithSpan(new ComputedAttributeConstructorNode(nameExpression, local, prefix, ns, content), start, End),
                    "processing-instruction" => WithSpan(new ComputedPIConstructorNode(nameExpression, local, content), start, End),
                    _ => WithSpan(new ComputedNamespaceConstructorNode(nameExpression, local, content), start, End)
                };
            }
            case "text":
            case "document":
            case "comment":
            {
                Expect(TokenKind.LBrace);
                // Computed constructor content may be empty ({}), producing the empty sequence.
                var content = Current.Kind == TokenKind.RBrace
                    ? new SequenceExpressionNode(Array.Empty<XPathAstNode>())
                    : ParseExpr();
                Expect(TokenKind.RBrace);
                return keyword switch
                {
                    "text" => WithSpan(new ComputedTextConstructorNode(content), start, End),
                    "document" => WithSpan(new ComputedDocumentConstructorNode(content), start, End),
                    _ => WithSpan(new ComputedCommentConstructorNode(content), start, End)
                };
            }
            default:
                throw new XPathParseException($"XPST0003: Unknown computed constructor '{keyword}'.", start);
        }
    }

    private XPathAstNode ParseValidateExpression(int start)
    {
        if (Current.Kind != TokenKind.Name || GetString(Current) != "validate")
            throw new XPathParseException($"XPST0003: Expected 'validate' but found {Current.Kind}.", Current.Start);
        Advance();

        string? mode = null;
        string? typePrefix = null;
        string? typeName = null;
        if (Current.Kind == TokenKind.Name)
        {
            var modeName = GetString(Current);
            if (modeName is "strict" or "lax")
            {
                mode = modeName;
                Advance();
            }
            else if (modeName == "type")
            {
                Advance();
                var (prefix, local, hasParens) = ParseTypeNameAndParens();
                if (hasParens)
                    throw new XPathParseException("XPST0003: Type name in 'validate type' must not be parenthesised.", Current.Start);
                typePrefix = prefix;
                typeName = local;
            }
        }

        Expect(TokenKind.LBrace);
        if (Match(TokenKind.RBrace))
            throw new XPathParseException("XPST0003: A validate expression must have a non-empty operand.", Current.Start);
        var body = ParseExpr();
        Expect(TokenKind.RBrace);
        return WithSpan(new ValidateExpressionNode(body, mode, typeName, typePrefix), start, End);
    }

    private FunctionCallNode ParseFunctionCall(int start)
    {
        var name = GetString(Current);
        var (prefix, local, nsUri) = SplitQName(name);
        ThrowIfRemovedFunction(nsUri, local, start);
        // An unprefixed call to a reserved function name is a syntax error
        // (function-call-reserved-function-names-005: empty-sequence()).
        if (string.IsNullOrEmpty(nsUri))
            ThrowIfReservedFunctionName(prefix, local, start);
        Advance();
        var (args, keywords) = ParseArgumentList();
        return WithSpan(new FunctionCallNode(local, args, prefix, nsUri, keywords), start, End);
    }

    private NamedFunctionRefNode ParseNamedFunctionRef(int start)
    {
        var name = GetString(Current);
        var (prefix, local, nsUri) = SplitQName(name);
        ThrowIfRemovedFunction(nsUri, local, start);
        ThrowIfReservedFunctionName(prefix, local, start);
        Advance(); // name
        Advance(); // #
        var arityTok = Expect(TokenKind.IntegerLiteral);
        var arityText = GetString(arityTok);
        if (!int.TryParse(arityText, NumberStyles.Integer, CultureInfo.InvariantCulture, out var arity))
        {
            // Arity literal exceeds Int32 (e.g. fn:concat#340282366920938463463374607431768211456).
            // No real function has this arity; clamp to int.MaxValue so function resolution
            // fails with FOAR0002 instead of a parser OverflowException.
            arity = int.MaxValue;
        }
        return WithSpan(new NamedFunctionRefNode(local, arity, prefix, nsUri), start, End);
    }

    // XPath 4.0 QName literal (PR1976/PR2227): the name token is Q{uri}local,
    // Q{uri}prefix:local, prefix:local, or plain local. The lexical prefix (when
    // present) is retained in the QName value; a prefixed lexical form keeps a null
    // NamespaceUri so the API compile pass resolves it against the static context
    // (XPST0081 when unresolvable).
    private XPathAstNode ParseQNameLiteral(int start)
    {
        var nameTok = ExpectName();
        var (prefix, local, ns) = SplitQName(GetString(nameTok), allowPrefixedBracedLocal: true);
        // Braced form with a prefix but an empty namespace URI is a static error (eqname-914).
        if (ns is not null && ns.Length == 0 && !string.IsNullOrEmpty(prefix))
            throw new XPathParseException("XPST0154: A QName literal with a prefix must not have an empty namespace URI.", start);
        return WithSpan(new QNameLiteralNode(local, prefix, ns), start, End);
    }

    private static void ThrowIfRemovedFunction(string? nsUri, string localName, int position)
    {
        if (nsUri == OldMapNamespace)
            throw new XPathParseException($"XPST0017: Function in obsolete map namespace '{nsUri}' is not available", position);

        if (!string.IsNullOrEmpty(nsUri) && RemovedFunctions.Contains((nsUri, localName)))
            throw new XPathParseException($"XPST0017: Function {{{nsUri}}}{localName} has been removed", position);
    }

    private static void ThrowIfReservedFunctionName(string? prefix, string localName, int position)
    {
        if (string.IsNullOrEmpty(prefix) && ReservedFunctionNames.Contains(localName))
            throw new XPathParseException($"XPST0003: '{localName}' is a reserved function name and cannot be used in a function call or named function reference", position);
    }

    // ArgumentList ::= "(" ((PositionalArguments ("," KeywordArguments)?) | KeywordArguments)? ")"
    // (XPath 4.0 §4.6.1; positional arguments may be followed by keyword arguments,
    // never the other way around). Keyword arguments are an XPath 4.0 feature: in
    // XPath 3.1 mode a 'name := expr' argument start is rejected with XPST0003.
    private (List<XPathAstNode> Positional, List<KeywordArgumentNode>? Keywords) ParseArgumentList()
    {
        Expect(TokenKind.LParen);
        var args = new List<XPathAstNode>();
        List<KeywordArgumentNode>? keywords = null;
        if (!Match(TokenKind.RParen))
        {
            bool keywordMode = false;
            do
            {
                if (IsKeywordArgumentStart())
                {
                    if (!_xpath40)
                        throw new XPathParseException("XPST0003: Keyword arguments ('name := value') are an XPath 4.0 feature and are not available in XPath 3.1.", Current.Start);
                    keywordMode = true;
                    var nameTok = Current;
                    Advance(); // the keyword name
                    Advance(); // ':='
                    var value = ParseExprSingle();
                    (keywords ??= new List<KeywordArgumentNode>()).Add(new KeywordArgumentNode(GetString(nameTok), value));
                }
                else
                {
                    if (keywordMode)
                        throw new XPathParseException("XPST0003: Positional arguments must not follow keyword arguments in a function call.", Current.Start);
                    // A bare '?' is an argument placeholder only when it cannot start a
                    // UnaryLookup, i.e. when the next token ends the argument (',' or ')').
                    // Otherwise ('?1', '?name', '?(') it is a lookup on the context item.
                    if (Current.Kind == TokenKind.Question
                        && (Peek(1).Kind == TokenKind.Comma || Peek(1).Kind == TokenKind.RParen))
                    {
                        Advance();
                        args.Add(new ArgumentPlaceholderNode());
                    }
                    else
                    {
                        args.Add(ParseExprSingle());
                    }
                }
            } while (Match(TokenKind.Comma));
            Expect(TokenKind.RParen);
        }
        return (args, keywords);
    }

    // A keyword argument starts with an EQName (possibly a keyword-token name such as
    // 'then') immediately followed by ':='.
    private bool IsKeywordArgumentStart()
        => (Current.Kind == TokenKind.Name || IsKeywordName(Current.Kind)) && Peek(1).Kind == TokenKind.Assign;

    // ------------------------------------------------------------------
    // XPath 3.1 constructors
    // ------------------------------------------------------------------

    // InlineFunctionExpr ::= ("function" | "fn") FunctionSignature? FunctionBody (XPath 4.0 §4.6.6).
    // The keyword is already known to be 'function' (keyword token) or 'fn' (contextual
    // name, XPath 4.0). A signature omitted before '{' is a focus function (§4.6.6.1):
    // fn { EXPR } ≡ function($Z as item()*) { $Z -> EXPR } with a fixed focus (Z, 1, 1).
    private InlineFunctionNode ParseInlineFunction(int start)
    {
        if (Current.Kind == TokenKind.KeywordFunction)
            Advance();
        else if (Current.Kind == TokenKind.Name && GetString(Current) == "fn")
            Advance();
        else
            Expect(TokenKind.KeywordFunction);

        if (Current.Kind == TokenKind.LBrace)
        {
            if (!_xpath40)
                throw new XPathParseException("XPST0003: A focus function (an inline function without a parameter list) requires XPath 4.0.", Current.Start);
            const string focusNs = "urn:bosak:internal:focus-function";
            var focusParam = new ParamNode($"Q{{{focusNs}}}Z", null);
            Advance();
            // EnclosedExpr ::= "{" Expr? "}" — an empty body evaluates to the empty sequence.
            XPathAstNode focusBody = Current.Kind == TokenKind.RBrace
                ? new SequenceExpressionNode(Array.Empty<XPathAstNode>())
                : ParseExpr();
            Expect(TokenKind.RBrace);
            var argRef = WithSpan(new VariableReferenceNode("Z", null, focusNs), start, End);
            var pipeline = WithSpan(new PipelineExprNode(argRef, focusBody), start, End);
            return WithSpan(new InlineFunctionNode(new List<ParamNode> { focusParam }, pipeline), start, End);
        }

        Expect(TokenKind.LParen);
        var parameters = new List<ParamNode>();
        if (!Match(TokenKind.RParen))
        {
            do
            {
                Expect(TokenKind.Dollar);
                var nameTok = ExpectName();
                string? typeName = null;
                if (Current.Kind == TokenKind.KeywordAs)
                {
                    Advance(); // as
                    typeName = SkipSequenceType();
                }
                parameters.Add(new ParamNode(GetString(nameTok), typeName));
            } while (Match(TokenKind.Comma));
            Expect(TokenKind.RParen);

            // Check for duplicate parameter names (XQST0039). EQName forms are
            // normalized first: $Q{ }a and $a both expand to ('', 'a') (eqname-913).
            var seenNames = new HashSet<(string NsOrPrefix, string Local)>();
            foreach (var param in parameters)
            {
                var (pPrefix, pLocal, pNs) = SplitQName(param.Name);
                var key = (pNs ?? pPrefix ?? "", pLocal);
                if (!seenNames.Add(key))
                    throw new XPathParseException($"XQST0039: Duplicate parameter name ${param.Name} in inline function.", start);
            }
        }
        string? returnType = null;
        if (Current.Kind == TokenKind.KeywordAs)
        {
            Advance(); // as
            returnType = SkipSequenceType();
        }
        XPathAstNode body;
        if (Current.Kind == TokenKind.LBrace)
        {
            Advance();
            // EnclosedExpr ::= "{" Expr? "}" — an empty body evaluates to the empty sequence.
            body = Current.Kind == TokenKind.RBrace
                ? new SequenceExpressionNode(Array.Empty<XPathAstNode>())
                : ParseExpr();
            Expect(TokenKind.RBrace);
        }
        else
        {
            body = ParsePrimaryExpr();
        }
        return WithSpan(new InlineFunctionNode(parameters, body, returnType), start, End);
    }

    // Parses and discards annotations on an inline function expression:
    // ('%' EQName ('(' Literal (',' Literal)* ')')?)*. Annotation names are
    // implementation-defined; unrecognized annotations are ignored (XQuery 3.1 §4.15).
    private void SkipInlineAnnotations()
    {
        while (Current.Kind == TokenKind.Percent)
        {
            Advance();
            if (Current.Kind != TokenKind.Name)
                throw new XPathParseException($"XPST0003: Expected an annotation name after '%' but found {Current.Kind}", Current.Start);
            // XQST0125: an inline function must not be annotated %public or %private —
            // those are function-declaration annotations only.
            if (GetString(Current) is "public" or "private")
                throw new XPathParseException($"XQST0125: An inline function expression must not be annotated %{GetString(Current)}.", Current.Start);
            Advance(); // EQName (plain, prefixed, or Q{uri}local)
            if (Current.Kind == TokenKind.LParen)
                SkipAnnotationArguments();
        }
    }

    // Annotation arguments must be literals: '(' Literal (',' Literal)* ')' — a
    // non-literal expression such as true() is XPST0003 (annotation-33).
    private void SkipAnnotationArguments()
    {
        Expect(TokenKind.LParen);
        SkipAnnotationLiteral();
        while (Match(TokenKind.Comma))
            SkipAnnotationLiteral();
        Expect(TokenKind.RParen);
    }

    private void SkipAnnotationLiteral()
    {
        if (Current.Kind is not (TokenKind.StringLiteral or TokenKind.IntegerLiteral or TokenKind.DecimalLiteral or TokenKind.DoubleLiteral))
            throw new XPathParseException($"XPST0003: Expected a literal in the annotation argument list but found {Current.Kind}", Current.Start);
        Advance();
    }

    // ------------------------------------------------------------------
    // XQuery direct element constructors
    // ------------------------------------------------------------------

    private XPathAstNode ParseDirectElementConstructor()
    {
        // The lexer emitted the whole constructor as a single token; build the AST by
        // scanning the raw source text (attribute values and text are not tokenizable).
        int start = Current.Start;
        int pos = start;
        char after = pos + 1 < _source.Length ? _source[pos + 1] : '\0';
        XPathAstNode node;
        if (_source[pos] == '`')
        {
            node = ScanStringConstructor(ref pos, start);
        }
        else if (after == '?')
        {
            node = ScanPiConstructor(ref pos, start);
        }
        else if (after == '!')
        {
            node = ScanCommentConstructor(ref pos, start);
        }
        else
        {
            node = ScanElementConstructor(ref pos, start);
        }
        Advance();
        return WithSpan(node, start, pos);
    }

    // Scans an XQuery string constructor "``[ ... ]``": literal text runs become
    // StringLiteralNode parts, interpolations "`{` Expr `}`" become expression parts.
    private XPathAstNode ScanStringConstructor(ref int pos, int ctorStart)
    {
        // pos is at the first '`' of "``[".
        pos += 3;
        var parts = new List<XPathAstNode>();
        var text = new StringBuilder();
        void FlushText()
        {
            if (text.Length > 0)
            {
                parts.Add(new StringLiteralNode(text.ToString()));
                text.Clear();
            }
        }
        while (true)
        {
            if (pos >= _source.Length)
                throw ConstructorError("unterminated string constructor", ctorStart);
            char c = _source[pos];
            if (c == ']' && pos + 2 < _source.Length && _source[pos + 1] == '`' && _source[pos + 2] == '`')
            {
                pos += 3;
                FlushText();
                return new StringConstructorNode(parts);
            }
            if (c == '`' && pos + 1 < _source.Length && _source[pos + 1] == '{')
            {
                FlushText();
                parts.Add(ScanStringInterpolation(ref pos, ctorStart));
                continue;
            }
            text.Append(c);
            pos++;
        }
    }

    // ------------------------------------------------------------------
    // XPath 4.0 string templates
    // ------------------------------------------------------------------

    // The lexer emitted the whole template as one raw StringTemplate token; build the
    // AST by re-scanning the raw source text. Fixed parts become StringLiteralNode parts
    // ('{{' '}}' and '``' escapes unescaped; a lone '}' is XPST0003), interpolations
    // become expression parts. Per XPath 4.0 §4.10.2 an empty, whitespace-only, or
    // comment-only interpolation is equivalent to an omitted one.
    private XPathAstNode ParseStringTemplate(int start)
    {
        int pos = Current.Start + 1; // past the opening backtick
        int end = Current.Start + Current.Length - 1; // at the closing backtick
        var parts = new List<XPathAstNode>();
        var text = new StringBuilder();
        void FlushText()
        {
            if (text.Length > 0)
            {
                parts.Add(new StringLiteralNode(text.ToString()));
                text.Clear();
            }
        }
        while (pos < end)
        {
            char c = _source[pos];
            if (c == '`')
            {
                // Escaped backtick: a lone backtick would have ended the token (longest token).
                text.Append('`');
                pos += 2;
                continue;
            }
            if (c == '{')
            {
                if (pos + 1 < end && _source[pos + 1] == '{')
                {
                    text.Append('{');
                    pos += 2;
                    continue;
                }
                FlushText();
                parts.Add(ScanTemplateInterpolation(ref pos, end, start));
                continue;
            }
            if (c == '}')
            {
                if (pos + 1 < end && _source[pos + 1] == '}')
                {
                    text.Append('}');
                    pos += 2;
                    continue;
                }
                throw new XPathParseException("XPST0003: A '}' in a string template must be written as '}}'.", pos);
            }
            text.Append(c);
            pos++;
        }
        FlushText();
        Advance();
        return WithSpan(new StringTemplateNode(parts), start, End);
    }

    // Scans one string-template interpolation body (pos is at the '{' that opens it,
    // which must be a single '{': '{{' is always an escaped brace) and returns the
    // parsed expression. The interpolation ends at the '}' that closes brace depth
    // zero; strings, comments, and nested string templates are skipped.
    private XPathAstNode ScanTemplateInterpolation(ref int pos, int limit, int templateStart)
    {
        int exprStart = ++pos;
        int depth = 1;
        while (pos < limit)
        {
            char c = _source[pos];
            if (c == '\'' || c == '"')
            {
                char q = c;
                pos++;
                while (pos < limit)
                {
                    if (_source[pos] == q)
                    {
                        if (pos + 1 < limit && _source[pos + 1] == q)
                        {
                            pos += 2;
                            continue;
                        }
                        pos++;
                        break;
                    }
                    pos++;
                }
                continue;
            }
            if (c == '(' && pos + 1 < limit && _source[pos + 1] == ':')
            {
                SkipConstructorComment(ref pos);
                continue;
            }
            if (c == '`')
            {
                // A nested string template inside the interpolation expression.
                pos = SkipStringTemplateSpan(pos + 1, limit);
                if (pos < 0)
                    throw ConstructorError("unterminated string template in interpolation", templateStart);
                continue;
            }
            if (c == '{')
            {
                depth++;
            }
            else if (c == '}')
            {
                depth--;
                if (depth == 0)
                {
                    var inner = _source[exprStart..pos];
                    pos++;
                    // An empty or comment-only interpolation contributes nothing.
                    if (string.IsNullOrWhiteSpace(StripXQueryComments(inner)))
                        return new SequenceExpressionNode(Array.Empty<XPathAstNode>());
                    return Parse(inner, _allowFullFlwor, xpath40: true);
                }
            }
            pos++;
        }
        throw ConstructorError("unterminated interpolation in string template", templateStart);
    }

    // Skips a nested string-template span (pos is just past its opening backtick),
    // interpolation-aware. Returns the position just past the closing backtick or -1
    // when unterminated.
    private int SkipStringTemplateSpan(int pos, int limit)
    {
        while (pos < limit)
        {
            char c = _source[pos];
            if (c == '`')
            {
                if (pos + 1 < limit && _source[pos + 1] == '`')
                {
                    pos += 2; // escaped backtick
                    continue;
                }
                return pos + 1;
            }
            if (c == '{')
            {
                if (pos + 1 < limit && _source[pos + 1] == '{')
                {
                    pos += 2; // escaped brace
                    continue;
                }
                // Skip the interpolation body with the same scanning rules.
                int depth = 1;
                pos++;
                while (pos < limit)
                {
                    char ic = _source[pos];
                    if (ic == '\'' || ic == '"')
                    {
                        char q = ic;
                        pos++;
                        while (pos < limit)
                        {
                            if (_source[pos] == q)
                            {
                                if (pos + 1 < limit && _source[pos + 1] == q)
                                {
                                    pos += 2;
                                    continue;
                                }
                                pos++;
                                break;
                            }
                            pos++;
                        }
                        continue;
                    }
                    if (ic == '(' && pos + 1 < limit && _source[pos + 1] == ':')
                    {
                        SkipConstructorComment(ref pos);
                        continue;
                    }
                    if (ic == '`')
                    {
                        pos = SkipStringTemplateSpan(pos + 1, limit);
                        if (pos < 0)
                            return -1;
                        continue;
                    }
                    if (ic == '{') depth++;
                    else if (ic == '}')
                    {
                        depth--;
                        if (depth == 0)
                        {
                            pos++;
                            break;
                        }
                    }
                    pos++;
                }
                continue;
            }
            if (c == '}' && pos + 1 < limit && _source[pos + 1] == '}')
            {
                pos += 2; // escaped brace
                continue;
            }
            pos++;
        }
        return -1;
    }

    // Scans one string-constructor interpolation body (pos is at the '`' of "`{") and
    // returns the parsed expression; an empty or comment-only body is the empty sequence.
    private XPathAstNode ScanStringInterpolation(ref int pos, int ctorStart)
    {
        int exprStart = (pos += 2);
        int depth = 1;
        while (pos < _source.Length)
        {
            char c = _source[pos];
            if (_allowFullFlwor && c == '(' && pos + 1 < _source.Length && _source[pos + 1] == '#')
            {
                pos += XPathLexer.ScanPragmaLength(_source.AsSpan(pos));
                continue;
            }

            if (c == '\'' || c == '"')
            {
                char q = c;
                pos++;
                while (pos < _source.Length)
                {
                    if (_source[pos] == q)
                    {
                        if (pos + 1 < _source.Length && _source[pos + 1] == q)
                        {
                            pos += 2;
                            continue;
                        }
                        pos++;
                        break;
                    }
                    pos++;
                }
                continue;
            }
            if (c == '(' && pos + 1 < _source.Length && _source[pos + 1] == ':')
            {
                SkipConstructorComment(ref pos);
                continue;
            }
            if (c == '`' && pos + 2 < _source.Length && _source[pos + 1] == '`' && _source[pos + 2] == '[')
            {
                // A nested string constructor inside the interpolation expression.
                if (!SkipStringConstructorSpan(ref pos))
                    throw ConstructorError("unterminated string constructor", ctorStart);
                continue;
            }
            if (c == '{')
            {
                depth++;
            }
            else if (c == '}')
            {
                depth--;
                if (depth == 0)
                {
                    // The interpolation must close with '}`' (XPST0003 otherwise).
                    if (pos + 1 >= _source.Length || _source[pos + 1] != '`')
                        throw new XPathParseException("XPST0003: An interpolation in a string constructor must end with '}`'.", pos);
                    var inner = _source[exprStart..pos];
                    pos += 2;
                    // An empty or comment-only interpolation is the empty sequence.
                    if (string.IsNullOrWhiteSpace(StripXQueryComments(inner)))
                        return new SequenceExpressionNode(Array.Empty<XPathAstNode>());
                    return Parse(inner, _allowFullFlwor);
                }
            }
            pos++;
        }
        throw ConstructorError("unterminated interpolation in string constructor", ctorStart);
    }

    // Skips a nested string constructor span (pos is at the first '`' of "``["),
    // interpolation-aware. Returns false when unterminated.
    private bool SkipStringConstructorSpan(ref int pos)
    {
        pos += 3;
        while (pos < _source.Length)
        {
            char c = _source[pos];
            if (c == ']' && pos + 2 < _source.Length && _source[pos + 1] == '`' && _source[pos + 2] == '`')
            {
                pos += 3;
                return true;
            }
            if (c == '`' && pos + 1 < _source.Length && _source[pos + 1] == '{')
            {
                // Skip the nested interpolation with the same scanning rules.
                int exprStart = (pos += 2);
                int depth = 1;
                bool closed = false;
                while (pos < _source.Length)
                {
                    char ic = _source[pos];
                    if (ic == '\'' || ic == '"')
                    {
                        char q = ic;
                        pos++;
                        while (pos < _source.Length)
                        {
                            if (_source[pos] == q)
                            {
                                if (pos + 1 < _source.Length && _source[pos + 1] == q)
                                {
                                    pos += 2;
                                    continue;
                                }
                                pos++;
                                break;
                            }
                            pos++;
                        }
                        continue;
                    }
                    if (ic == '(' && pos + 1 < _source.Length && _source[pos + 1] == ':')
                    {
                        SkipConstructorComment(ref pos);
                        continue;
                    }
                    if (ic == '`' && pos + 2 < _source.Length && _source[pos + 1] == '`' && _source[pos + 2] == '[')
                    {
                        if (!SkipStringConstructorSpan(ref pos))
                            return false;
                        continue;
                    }
                    if (ic == '{')
                    {
                        depth++;
                    }
                    else if (ic == '}')
                    {
                        depth--;
                        if (depth == 0)
                        {
                            if (pos + 1 >= _source.Length || _source[pos + 1] != '`')
                                return false;
                            pos += 2;
                            closed = true;
                            break;
                        }
                    }
                    pos++;
                }
                if (!closed)
                    return false;
                continue;
            }
            pos++;
        }
        return false;
    }

    private void SkipConstructorComment(ref int pos)
    {
        // pos is at '(:' — XQuery comments nest.
        int depth = 1;
        pos += 2;
        while (pos < _source.Length && depth > 0)
        {
            if (_source[pos] == '(' && pos + 1 < _source.Length && _source[pos + 1] == ':') { depth++; pos += 2; }
            else if (_source[pos] == ':' && pos + 1 < _source.Length && _source[pos + 1] == ')') { depth--; pos += 2; }
            else pos++;
        }
    }

    private DirectProcessingInstructionNode ScanPiConstructor(ref int pos, int ctorStart)
    {
        // pos is at '<', source[pos+1] is '?'.
        pos += 2;
        int targetStart = pos;
        if (pos >= _source.Length || (!char.IsLetter(_source[pos]) && _source[pos] != '_'))
            throw ConstructorError("expected a processing instruction target", pos);
        while (pos < _source.Length && IsConstructorNameChar(_source[pos]))
            pos++;
        var target = _source[targetStart..pos];
        if (target.Equals("xml", StringComparison.OrdinalIgnoreCase))
            throw ConstructorError("processing instruction target 'xml' is reserved", targetStart);
        // The target is an NCName: anything other than whitespace or the closing '?>'
        // directly after it (e.g. '|' or ':') is a syntax error (K2-DirectConOther-21/22).
        if (pos >= _source.Length || (!char.IsWhiteSpace(_source[pos]) &&
            !(_source[pos] == '?' && pos + 1 < _source.Length && _source[pos + 1] == '>')))
            throw ConstructorError($"invalid character after processing instruction target '{target}'", pos);

        SkipConstructorWhitespace(ref pos);
        int close = _source.IndexOf("?>", pos, StringComparison.Ordinal);
        if (close < 0)
            throw ConstructorError("unterminated processing instruction", ctorStart);
        var data = _source[pos..close];
        pos = close + 2;
        return new DirectProcessingInstructionNode(target, data);
    }

    private DirectCommentNode ScanCommentConstructor(ref int pos, int ctorStart)
    {
        // pos is at '<', source is "<!--".
        int dataStart = pos + 4;
        int close = _source.IndexOf("-->", dataStart, StringComparison.Ordinal);
        if (close < 0)
            throw ConstructorError("unterminated comment", ctorStart);
        var data = _source[dataStart..close];
        if (data.Contains("--", StringComparison.Ordinal) || data.EndsWith('-'))
            throw ConstructorError("comment must not contain '--' or end with '-'", dataStart);
        pos = close + 3;
        return new DirectCommentNode(data);
    }

    private XPathAstNode ScanElementConstructor(ref int pos, int ctorStart)
    {
        // pos is at '<'.
        pos++;
        var (tagPrefix, tagLocal) = ScanConstructorQName(ref pos, ctorStart);

        var attributes = new List<DirectAttributeNode>();
        var content = new List<XPathAstNode>();
        var declaredPrefixes = new HashSet<string>(StringComparer.Ordinal);
        bool xmlSpacePreserve = false;

        while (true)
        {
            int wsStart = pos;
            SkipConstructorWhitespace(ref pos);
            bool hadWhitespace = pos != wsStart;
            if (pos >= _source.Length)
                throw ConstructorError("unterminated element constructor", ctorStart);
            char c = _source[pos];
            if (c == '>')
            {
                pos++;
                break;
            }
            if (c == '/' && pos + 1 < _source.Length && _source[pos + 1] == '>')
            {
                pos += 2;
                return new DirectElementConstructorNode(tagLocal, tagPrefix, attributes, content);
            }

            // Whitespace is required between two attributes (K2-DirectConElemAttr-48/51).
            if (attributes.Count > 0 && !hadWhitespace)
                throw ConstructorError("expected whitespace between attributes", pos);
            var (attrPrefix, attrLocal) = ScanConstructorQName(ref pos, ctorStart);
            SkipConstructorWhitespace(ref pos);
            if (pos >= _source.Length || _source[pos] != '=')
                throw ConstructorError("expected '=' after attribute name", pos);
            pos++;
            SkipConstructorWhitespace(ref pos);
            if (pos >= _source.Length || (_source[pos] != '"' && _source[pos] != '\''))
                throw ConstructorError("expected quoted attribute value", pos);
            char quote = _source[pos++];
            bool isNamespaceDecl = (attrLocal == "xmlns" && attrPrefix is null) || attrPrefix == "xmlns";
            var valueParts = ScanConstructorAttributeValue(ref pos, quote, ctorStart, isNamespaceDecl);

            // XQST0070: the xml prefix must only be declared with the XML namespace URI,
            // no other prefix may use the XML namespace URI, and xmlns must not be declared.
            if (isNamespaceDecl)
            {
                var nsValue = string.Concat(valueParts.OfType<StringLiteralNode>().Select(p => p.Value));
                if (attrPrefix == "xmlns" && attrLocal == "xmlns")
                    throw new XPathParseException("XQST0070: The 'xmlns' prefix must not be declared.", ctorStart);
                if (attrPrefix == "xmlns" && attrLocal == "xml" &&
                    nsValue != "http://www.w3.org/XML/1998/namespace")
                    throw new XPathParseException("XQST0070: The 'xml' prefix must only be bound to the XML namespace URI.", ctorStart);
                if (attrPrefix == "xmlns" && attrLocal != "xml" &&
                    nsValue == "http://www.w3.org/XML/1998/namespace")
                    throw new XPathParseException("XQST0070: The XML namespace URI must only be bound to the 'xml' prefix.", ctorStart);
            }

            // xml:space is an ordinary attribute for element constructors: it does NOT
            // affect boundary-whitespace stripping (XQuery 3.1 §3.9.1.1 note; the
            // serializer honors it instead). XQST0071: duplicate prefix declarations.
            if (isNamespaceDecl)
            {
                string declPrefix = attrPrefix == "xmlns" ? attrLocal : "";
                if (!declaredPrefixes.Add(declPrefix))
                    throw new XPathParseException($"XQST0071: The namespace prefix '{(declPrefix.Length == 0 ? "(default)" : declPrefix)}' is declared more than once.", ctorStart);
            }

            attributes.Add(new DirectAttributeNode(attrLocal, attrPrefix, valueParts));
        }

        ScanConstructorContent(ref pos, tagLocal, tagPrefix, content, ctorStart, xmlSpacePreserve);

        return new DirectElementConstructorNode(tagLocal, tagPrefix, attributes, content);
    }

    private void ScanConstructorContent(ref int pos, string tagLocal, string? tagPrefix, List<XPathAstNode> content, int ctorStart, bool xmlSpacePreserve)
    {
        var text = new StringBuilder();
        bool textHasReference = false;
        void FlushText()
        {
            if (text.Length > 0)
            {
                // Text containing a character/entity reference is never boundary whitespace.
                // A plain whitespace-only literal run IS boundary whitespace and is stripped
                // when the boundary-space policy is strip (the default), unless
                // xml:space="preserve". Enclosed expressions never pass through here, so a
                // whitespace-only {' '} result is always preserved.
                if (textHasReference || xmlSpacePreserve || !_boundarySpaceStrip || !IsXmlWhitespaceOnly(text.ToString()))
                {
                    content.Add(textHasReference
                        ? new SignificantTextNode(text.ToString())
                        : new StringLiteralNode(text.ToString()));
                }
                text.Clear();
            }
            // Always reset: a reference/CDATA only protects the text run it belongs to.
            textHasReference = false;
        }

        while (true)
        {
            if (pos >= _source.Length)
                throw ConstructorError("unterminated element content", ctorStart);
            char c = _source[pos];
            if (c == '<')
            {
                if (pos + 1 >= _source.Length)
                    throw ConstructorError("unterminated element content", ctorStart);
                char next = _source[pos + 1];
                if (next == '/')
                {
                    pos += 2;
                    var (endPrefix, endLocal) = ScanConstructorQName(ref pos, ctorStart);
                    SkipConstructorWhitespace(ref pos);
                    if (pos >= _source.Length || _source[pos] != '>')
                        throw ConstructorError("expected '>' in end tag", pos);
                    pos++;
                    if (endLocal != tagLocal || endPrefix != tagPrefix)
                    {
                        string expected = tagPrefix is null ? tagLocal : $"{tagPrefix}:{tagLocal}";
                        string found = endPrefix is null ? endLocal : $"{endPrefix}:{endLocal}";
                        throw new XPathParseException($"XQST0118: Mismatched end tag '</{found}>' (expected '</{expected}>').", pos);
                    }
                    FlushText();
                    return;
                }
                if (next == '!')
                {
                    if (_source.AsSpan(pos).StartsWith("<!--", StringComparison.Ordinal))
                    {
                        FlushText();
                        int dataStart = pos + 4;
                        int close = _source.IndexOf("-->", dataStart, StringComparison.Ordinal);
                        if (close < 0)
                            throw ConstructorError("unterminated comment", pos);
                        var data = _source[dataStart..close];
                        if (data.Contains("--", StringComparison.Ordinal) || data.EndsWith('-'))
                            throw ConstructorError("comment must not contain '--' or end with '-'", pos);
                        content.Add(new DirectCommentNode(data));
                        pos = close + 3;
                        continue;
                    }
                    if (_source.AsSpan(pos).StartsWith("<![CDATA[", StringComparison.Ordinal))
                    {
                        int dataStart = pos + 9;
                        int close = _source.IndexOf("]]>", dataStart, StringComparison.Ordinal);
                        if (close < 0)
                            throw ConstructorError("unterminated CDATA section", pos);
                        // CDATA content (and its mere presence) is never boundary whitespace:
                        // even an empty CDATA section protects the surrounding text run.
                        text.Append(NormalizeNewlines(_source[dataStart..close]));
                        textHasReference = true;
                        pos = close + 3;
                        continue;
                    }
                    throw ConstructorError("unsupported markup declaration in element content", pos);
                }
                if (next == '?')
                {
                    FlushText();
                    int dataStart = pos + 2;
                    int close = _source.IndexOf("?>", dataStart, StringComparison.Ordinal);
                    if (close < 0)
                        throw ConstructorError("unterminated processing instruction", pos);
                    var pi = _source[dataStart..close];
                    int space = IndexOfWhitespace(pi);
                    var (target, data) = space < 0 ? (pi, string.Empty) : (pi[..space], pi[(space + 1)..]);
                    if (target.Length == 0 || target.Equals("xml", StringComparison.OrdinalIgnoreCase))
                        throw ConstructorError($"invalid processing instruction target '{target}'", pos);
                    content.Add(new DirectProcessingInstructionNode(target, data));
                    pos = close + 2;
                    continue;
                }
                if (char.IsLetter(next) || next == '_')
                {
                    FlushText();
                    content.Add(((DirectElementConstructorNode)ScanElementConstructor(ref pos, ctorStart)) with { IsLiteralChild = true });
                    continue;
                }
                throw ConstructorError("unexpected '<' in element content", pos);
            }
            if (c == '{')
            {
                if (pos + 1 < _source.Length && _source[pos + 1] == '{')
                {
                    text.Append('{');
                    pos += 2;
                    continue;
                }
                FlushText();
                content.Add(ScanEnclosedExpression(ref pos, ctorStart));
                continue;
            }
            if (c == '}')
            {
                if (pos + 1 < _source.Length && _source[pos + 1] == '}')
                {
                    text.Append('}');
                    pos += 2;
                    continue;
                }
                throw ConstructorError("unescaped '}' in element content (use '}}')", pos);
            }
            if (c == '&')
            {
                text.Append(ScanConstructorCharReference(ref pos, ctorStart));
                textHasReference = true;
                continue;
            }
            if (c == '\r')
            {
                text.Append('\n');
                pos++;
                if (pos < _source.Length && _source[pos] == '\n')
                    pos++;
                continue;
            }
            text.Append(c);
            pos++;
        }
    }

    private IReadOnlyList<XPathAstNode> ScanConstructorAttributeValue(ref int pos, char quote, int ctorStart, bool isNamespaceDecl = false)
    {
        var parts = new List<XPathAstNode>();
        var text = new StringBuilder();
        void FlushText()
        {
            if (text.Length > 0)
            {
                parts.Add(new StringLiteralNode(text.ToString()));
                text.Clear();
            }
        }

        while (true)
        {
            if (pos >= _source.Length)
                throw ConstructorError("unterminated attribute value", ctorStart);
            char c = _source[pos];
            if (c == quote)
            {
                // A doubled quote is an escaped literal quote in the value.
                if (pos + 1 < _source.Length && _source[pos + 1] == quote)
                {
                    text.Append(quote);
                    pos += 2;
                    continue;
                }
                pos++;
                FlushText();
                var result = parts;
                // A namespace declaration URI is validated only for being a literal
                // (XQST0022 above); its characters are not restricted — XQST0046 is an
                // implementation option and xs:anyURI accepts spaces (eqname-009).
                return result;
            }
            if (c == '{')
            {
                if (pos + 1 < _source.Length && _source[pos + 1] == '{')
                {
                    text.Append('{');
                    pos += 2;
                    continue;
                }
                if (isNamespaceDecl)
                    throw new XPathParseException("XQST0022: A namespace declaration must have a literal URI.", pos);
                FlushText();
                parts.Add(ScanEnclosedExpression(ref pos, ctorStart));
                continue;
            }
            if (c == '}')
            {
                if (pos + 1 < _source.Length && _source[pos + 1] == '}')
                {
                    text.Append('}');
                    pos += 2;
                    continue;
                }
                throw ConstructorError("unescaped '}' in attribute value (use '}}')", pos);
            }
            if (c == '&')
            {
                text.Append(ScanConstructorCharReference(ref pos, ctorStart));
                continue;
            }
            if (c == '<')
            {
                // A raw '<' is never allowed literally in an attribute value (use '&lt;').
                throw ConstructorError("attribute values must not contain a literal '<'", pos);
            }
            // XML 1.0 §2.11 line-ending normalization (\r\n and lone \r become \n),
            // then XML attribute-value normalization (§3.3.3) turns the newline into
            // a single space. Whitespace runs within a literal are preserved as-is;
            // character references are already expanded verbatim by the '&' branch.
            if (c == '\r')
            {
                if (pos + 1 < _source.Length && _source[pos + 1] == '\n')
                    pos++;
                text.Append(' ');
            }
            else if (c is '\t' or '\n' or ' ')
            {
                text.Append(' ');
            }
            else
            {
                text.Append(c);
            }
            pos++;
        }
    }

    private XPathAstNode ScanEnclosedExpression(ref int pos, int ctorStart)
    {
        // pos is at '{'.
        int exprStart = ++pos;
        int depth = 1;
        while (pos < _source.Length)
        {
            char c = _source[pos];
            if (_allowFullFlwor && c == '(' && pos + 1 < _source.Length && _source[pos + 1] == '#')
            {
                pos += XPathLexer.ScanPragmaLength(_source.AsSpan(pos));
                continue;
            }

            if (c == '{')
            {
                depth++;
            }
            else if (c == '}')
            {
                depth--;
                if (depth == 0)
                {
                    var inner = _source[exprStart..pos];
                    pos++;
                    // XQuery 3.1 allows an empty enclosed expression ("{" Expr? "}"):
                    // it evaluates to the empty sequence (Constr-attr-enclexpr-10/11,
                    // K2-DirectConElemContent-26a). A comment-only expression does the same.
                    if (string.IsNullOrWhiteSpace(StripXQueryComments(inner)))
                        return new SequenceExpressionNode(Array.Empty<XPathAstNode>());
                    return Parse(inner, _allowFullFlwor);
                }
            }
            else if (c == '\'' || c == '"')
            {
                char q = c;
                pos++;
                while (pos < _source.Length)
                {
                    if (_source[pos] == q)
                    {
                        if (pos + 1 < _source.Length && _source[pos + 1] == q)
                        {
                            pos += 2;
                            continue;
                        }
                        break;
                    }
                    pos++;
                }
            }
            else if (c == '(' && pos + 1 < _source.Length && _source[pos + 1] == ':')
            {
                int commentDepth = 1;
                pos += 2;
                while (pos < _source.Length && commentDepth > 0)
                {
                    if (_source[pos] == '(' && pos + 1 < _source.Length && _source[pos + 1] == ':')
                    {
                        commentDepth++;
                        pos += 2;
                    }
                    else if (_source[pos] == ':' && pos + 1 < _source.Length && _source[pos + 1] == ')')
                    {
                        commentDepth--;
                        pos += 2;
                    }
                    else
                    {
                        pos++;
                    }
                }
                continue;
            }
            pos++;
        }
        throw ConstructorError("unterminated enclosed expression", ctorStart);
    }

    private string ScanConstructorCharReference(ref int pos, int ctorStart)
    {
        int semi = _source.IndexOf(';', pos + 1);
        if (semi < 0)
            throw ConstructorError("unterminated entity or character reference", pos);
        var reference = _source[(pos + 1)..semi];
        pos = semi + 1;
        return reference switch
        {
            "amp" => "&",
            "lt" => "<",
            "gt" => ">",
            "quot" => "\"",
            "apos" => "'",
            _ when reference.StartsWith("#x", StringComparison.Ordinal) &&
                   IsAsciiDigitRun(reference[2..], isHex: true) =>
                ExpandNumericCharReference(reference, reference[2..], isHex: true, ctorStart),
            _ when reference.StartsWith('#') &&
                   IsAsciiDigitRun(reference[1..], isHex: false) =>
                ExpandNumericCharReference(reference, reference[1..], isHex: false, ctorStart),
            _ => throw ConstructorError($"invalid entity or character reference '&{reference};'", ctorStart)
        };
    }

    private static bool IsAsciiDigitRun(string digits, bool isHex)
        => digits.Length > 0 && digits.All(isHex ? Uri.IsHexDigit : IsAsciiDigit);

    // XQST0090: a character reference must denote a valid XML 1.1 character (any
    // codepoint except NUL, surrogates, and noncharacters; control characters are
    // permitted as references in XML 1.1).
    private string ValidateCharReference(int codePoint, int ctorStart)
    {
        ValidateXmlCharReference(codePoint, $"#{codePoint}", ctorStart);
        return char.ConvertFromUtf32(codePoint);
    }

    private (string? Prefix, string Local) ScanConstructorQName(ref int pos, int ctorStart)
    {
        int nameStart = pos;
        if (pos >= _source.Length || (!char.IsLetter(_source[pos]) && _source[pos] != '_'))
            throw ConstructorError("expected a name", pos);
        pos++;
        while (pos < _source.Length && IsConstructorNameChar(_source[pos]))
            pos++;
        var first = _source[nameStart..pos];
        if (pos < _source.Length && _source[pos] == ':')
        {
            pos++;
            int localStart = pos;
            if (pos >= _source.Length || (!char.IsLetter(_source[pos]) && _source[pos] != '_'))
                throw ConstructorError("expected a local name after ':'", pos);
            pos++;
            while (pos < _source.Length && IsConstructorNameChar(_source[pos]))
                pos++;
            return (first, _source[localStart..pos]);
        }
        return (null, first);
    }

    private static bool IsConstructorNameChar(char c) =>
        char.IsLetterOrDigit(c) || c is '_' or '-' or '.';

    // XML NCName: letter or '_' start, then letters/digits/'_'/'-'/'.'.
    private static bool IsValidNCName(string name)
    {
        if (name.Length == 0 || !(char.IsLetter(name[0]) || name[0] == '_'))
            return false;
        for (int i = 1; i < name.Length; i++)
        {
            char c = name[i];
            if (!char.IsLetterOrDigit(c) && c is not ('_' or '-' or '.'))
                return false;
        }
        return true;
    }

    private void SkipConstructorWhitespace(ref int pos)
    {
        while (pos < _source.Length && char.IsWhiteSpace(_source[pos]))
            pos++;
    }

    private static int IndexOfWhitespace(string text)
    {
        for (int i = 0; i < text.Length; i++)
        {
            if (char.IsWhiteSpace(text[i]))
                return i;
        }
        return -1;
    }

    private static string NormalizeNewlines(string text) =>
        text.Replace("\r\n", "\n").Replace('\r', '\n');

    /// <summary>Removes XQuery comments (possibly nested) so emptiness can be detected.</summary>
    private static string StripXQueryComments(string text)
    {
        var sb = new StringBuilder(text.Length);
        int i = 0;
        while (i < text.Length)
        {
            if (text[i] == '(' && i + 1 < text.Length && text[i + 1] == ':')
            {
                int depth = 1;
                i += 2;
                while (i < text.Length && depth > 0)
                {
                    if (text[i] == '(' && i + 1 < text.Length && text[i + 1] == ':') { depth++; i += 2; }
                    else if (text[i] == ':' && i + 1 < text.Length && text[i + 1] == ')') { depth--; i += 2; }
                    else i++;
                }
                continue;
            }
            sb.Append(text[i]);
            i++;
        }
        return sb.ToString();
    }

    private static bool IsXmlWhitespaceOnly(string text)
    {
        foreach (char c in text)
        {
            if (c is not (' ' or '\t' or '\n' or '\r'))
                return false;
        }
        return true;
    }

    private XPathParseException ConstructorError(string message, int pos) =>
        new($"XPST0003: {message}.", pos);

    private MapConstructorNode ParseMapConstructor(int start)
    {
        Expect(TokenKind.KeywordMap);
        return ParseBracedMapConstructor(start);
    }

    // The braced body of a map constructor, shared by the 'map {' keyword form and the
    // XPath 4.0 bare '{…}' form (PR2778).
    private MapConstructorNode ParseBracedMapConstructor(int start)
    {
        Expect(TokenKind.LBrace);
        var entries = new List<MapEntryNode>();
        if (!Match(TokenKind.RBrace))
        {
            do
            {
                var key = ParseMapConstructorKey();
                if (Current.Kind == TokenKind.Assign)
                    throw new XPathParseException("XPST0003: Invalid map constructor syntax (use ':' to separate key and value)", Current.Start);
                Expect(TokenKind.Colon);
                var value = ParseExprSingle();
                entries.Add(new MapEntryNode(key, value));
            } while (Match(TokenKind.Comma));
            Expect(TokenKind.RBrace);
        }
        return WithSpan(new MapConstructorNode(entries), start, End);
    }

    // Parses a map-constructor key. Inside the key, '*:local' name tests are not greedy
    // (_mapKeyDepth gates ParseNodeTest): '*' alone is the key when no entry ':' follows
    // the local name (map{* :b} vs map{*:b:*}). A merged '*:b:b' token run is split so
    // that '*:b' becomes the key and 'b' the value (MapConstructor-019).
    private XPathAstNode ParseMapConstructorKey()
    {
        if (Current.Kind == TokenKind.Star && Peek(1).Kind == TokenKind.Colon &&
            Peek(2).Kind == TokenKind.Name && GetString(Peek(2)).Contains(':'))
        {
            var merged = Peek(2);
            var text = GetString(merged);
            int colonIdx = text.IndexOf(':');
            var parts = new[]
            {
                new Token(TokenKind.Name, merged.Start, colonIdx),
                new Token(TokenKind.Colon, merged.Start + colonIdx, 1),
                new Token(TokenKind.Name, merged.Start + colonIdx + 1, merged.Length - colonIdx - 1)
            };
            var list = _tokens.ToList();
            list.RemoveAt(_position + 2);
            list.InsertRange(_position + 2, parts);
            _tokens = list.ToArray();
        }
        _mapKeyDepth++;
        try
        {
            return ParseExprSingle();
        }
        finally
        {
            _mapKeyDepth--;
        }
    }

    private ArrayConstructorNode ParseSquareArrayConstructor(int start)
    {
        Expect(TokenKind.LBracket);
        var items = new List<XPathAstNode>();
        if (!Match(TokenKind.RBracket))
        {
            do
            {
                items.Add(ParseExprSingle());
            } while (Match(TokenKind.Comma));
            Expect(TokenKind.RBracket);
        }
        return WithSpan(new ArrayConstructorNode(items, IsSquare: true), start, End);
    }

    private ArrayConstructorNode ParseCurlyArrayConstructor(int start)
    {
        Expect(TokenKind.KeywordArray);
        Expect(TokenKind.LBrace);
        var items = new List<XPathAstNode>();
        if (!Match(TokenKind.RBrace))
        {
            var expr = ParseExpr();
            // Wrap single expression as the array content
            items.Add(expr);
            Expect(TokenKind.RBrace);
        }
        return WithSpan(new ArrayConstructorNode(items, IsSquare: false), start, End);
    }

    // ------------------------------------------------------------------
    // Utilities
    // ------------------------------------------------------------------

    private static (string? Prefix, string Local, string? NamespaceUri) SplitQName(string qname)
        => SplitQName(qname, allowPrefixedBracedLocal: false);

    // allowPrefixedBracedLocal: QName literals (PR2227) permit Q{uri}prefix:local, retaining
    // the prefix in the value; every other EQName position requires a plain local name.
    private static (string? Prefix, string Local, string? NamespaceUri) SplitQName(string qname, bool allowPrefixedBracedLocal)
    {
        // Braced URI literal: Q{uri}localname
        // The empty URI form Q{}local is permitted and means "no namespace".
        // Whitespace in the URI part is not significant: leading/trailing whitespace
        // is stripped and internal runs are collapsed to a single space.
        if (qname.Length > 2 && qname[0] == 'Q' && qname[1] == '{')
        {
            int closeBrace = qname.IndexOf('}');
            if (closeBrace >= 2)
            {
                // Braced URI literals may not contain braces (XPST0003).
                if (qname[2..closeBrace].Contains('{'))
                    throw new XPathParseException($"XPST0003: Braces are not allowed in the URI part of an EQName ('{qname}').", 0);
                string nsUri = NormalizeEQNameUri(ExpandEQNameRefs(qname[2..closeBrace]));
                // The URI literal must be interpretable as an IRI reference: percent signs
                // must introduce two hex digits and a fragment (after '#') may not contain
                // further '#' or illegal characters (eqname-911/912, XQST0046).
                if (!IsValidUriLiteral(nsUri))
                    throw new XPathParseException($"XQST0046: The URI literal '{nsUri}' is not a valid URI reference.", 0);
                // The xmlns namespace must not appear in any EQName (eqname-910).
                if (nsUri == "http://www.w3.org/2000/xmlns/")
                    throw new XPathParseException($"XQST0070: The namespace URI '{nsUri}' is reserved and must not be used in an EQName.", 0);
                string rest = qname[(closeBrace + 1)..];
                // A braced URI literal is followed by a single NCName only: a colon
                // after '}' is a syntax error (eqname-901/904). QName literals relax
                // this and retain the lexical prefix (PR2227, eqname-042).
                if (rest.Contains(':'))
                {
                    if (!allowPrefixedBracedLocal)
                        throw new XPathParseException($"XPST0003: A braced URI literal must be followed by a local name only, not '{qname}'.", 0);
                    int bracedColon = rest.IndexOf(':');
                    string bracedLocal = rest[(bracedColon + 1)..];
                    if (bracedLocal.Contains(':'))
                        throw new XPathParseException($"XPST0003: Invalid QName literal '{qname}'.", 0);
                    // The lexical prefix is retained in the QName value (eqname-042).
                    return (rest[..bracedColon], bracedLocal, nsUri);
                }
                return (null, rest, nsUri);
            }
        }

        int colon = qname.IndexOf(':');
        return colon < 0 ? (null, qname, null) : (qname[..colon], qname[(colon + 1)..], null);
    }

    /// <summary>
    /// Normalizes the URI part of an EQName: strips leading/trailing whitespace and
    /// collapses internal whitespace runs (space, tab, CR, LF) to a single space.
    /// </summary>
    private static string NormalizeEQNameUri(string uri)
    {
        uri = uri.Trim();
        if (uri.Length == 0) return uri;
        var sb = new System.Text.StringBuilder(uri.Length);
        bool pendingSpace = false;
        foreach (char c in uri)
        {
            if (c is ' ' or '\t' or '\n' or '\r')
            {
                pendingSpace = true;
                continue;
            }
            if (pendingSpace && sb.Length > 0)
                sb.Append(' ');
            pendingSpace = false;
            sb.Append(c);
        }
        return sb.ToString();
    }

    /// <summary>
    /// Validates the URI part of a braced URI literal as an IRI reference (XQST0046):
    /// every '%' must start a two-hex-digit escape sequence, and everything after a
    /// '#' (the fragment) must consist of fragment-legal characters only.
    /// </summary>
    private static bool IsValidUriLiteral(string uri)
    {
        const string hex = "0123456789abcdefABCDEF";
        for (int i = 0; i < uri.Length; i++)
        {
            char c = uri[i];
            if (c == '%')
            {
                if (i + 2 >= uri.Length || !hex.Contains(uri[i + 1]) || !hex.Contains(uri[i + 2]))
                    return false;
                i += 2;
                continue;
            }
            if (c == '#')
            {
                for (int j = i + 1; j < uri.Length; j++)
                {
                    char f = uri[j];
                    if (f == '%')
                    {
                        if (j + 2 >= uri.Length || !hex.Contains(uri[j + 1]) || !hex.Contains(uri[j + 2]))
                            return false;
                        j += 2;
                        continue;
                    }
                    if (!IsUriFragmentChar(f))
                        return false;
                }
                return true;
            }
        }
        return true;
    }

    private static bool IsUriFragmentChar(char c) =>
        char.IsLetterOrDigit(c) || c is '-' or '.' or '_' or '~' or '!' or '$' or '&' or '\''
            or '(' or ')' or '*' or '+' or ',' or ';' or '=' or ':' or '@' or '/' or '?';

    /// <summary>
    /// Expands character references (<c>&amp;#x20;</c>, <c>&amp;#32;</c>) and predefined
    /// entity references (<c>&amp;amp;</c>, <c>&amp;lt;</c>, <c>&amp;gt;</c>, <c>&amp;quot;</c>,
    /// <c>&amp;apos;</c>) in the braced URI literal of an EQName. Malformed or unknown
    /// references are a syntax error (XPST0003).
    /// </summary>
    private static string ExpandEQNameRefs(string uri)
    {
        if (!uri.Contains('&'))
            return uri;
        var sb = new System.Text.StringBuilder(uri.Length);
        for (int i = 0; i < uri.Length; i++)
        {
            char c = uri[i];
            if (c != '&')
            {
                sb.Append(c);
                continue;
            }
            int semi = uri.IndexOf(';', i + 1);
            if (semi < 0)
                throw new XPathParseException($"XPST0003: Unterminated reference in EQName URI ('{uri}').", 0);
            var body = uri[(i + 1)..semi];
            if (body.StartsWith("#x", StringComparison.Ordinal) || body.StartsWith("#X", StringComparison.Ordinal))
            {
                if (!int.TryParse(body[2..], System.Globalization.NumberStyles.HexNumber, null, out int hex) || hex is < 1 or > 0x10FFFF)
                    throw new XPathParseException($"XPST0003: Invalid character reference '&{body};' in EQName URI.", 0);
                sb.Append(char.ConvertFromUtf32(hex));
            }
            else if (body.StartsWith('#'))
            {
                if (!int.TryParse(body[1..], System.Globalization.NumberStyles.None, null, out int dec) || dec is < 1 or > 0x10FFFF)
                    throw new XPathParseException($"XPST0003: Invalid character reference '&{body};' in EQName URI.", 0);
                sb.Append(char.ConvertFromUtf32(dec));
            }
            else
            {
                sb.Append(body switch
                {
                    "amp" => '&',
                    "lt" => '<',
                    "gt" => '>',
                    "quot" => '"',
                    "apos" => '\'',
                    _ => throw new XPathParseException($"XPST0003: Unknown entity reference '&{body};' in EQName URI.", 0)
                });
            }
            i = semi;
        }
        return sb.ToString();
    }

    private static bool IsKindTestName(string localName) => localName switch
    {
        "node" or "text" or "comment" or "processing-instruction" or "namespace-node"
        or "element" or "attribute" or "schema-element" or "schema-attribute"
        or "document-node" or "item" => true,
        _ => false
    };

    private string Unquote(string text)
    {
        if (text.Length >= 2 &&
            ((text[0] == '\'' && text[^1] == '\'') || (text[0] == '"' && text[^1] == '"')))
        {
            char quote = text[0];
            var inner = text[1..^1];
            var sb = new StringBuilder(inner.Length);
            for (int i = 0; i < inner.Length; i++)
            {
                // Predefined entity and character references expand in XQuery string
                // literals only; XPath 3.1 does not expand them (assert-eq expectations
                // evaluate per XPath rules, e.g. string-constructor-029).
                if (inner[i] == '&' && _allowFullFlwor)
                {
                    sb.Append(ExpandCharReference(inner, ref i));
                    continue;
                }
                // XML 1.0 end-of-line normalization (XQuery 3.1 A.2.2) applies to the
                // literal characters of the query text: #xD#xA and lone #xD become #xA.
                // Characters produced by character references are exact and never
                // normalized (line-ending-Q002/Q003). XML 1.1 mode normalizes below.
                if (inner[i] == '\r' && _allowFullFlwor && !_xml11LineEndings)
                {
                    sb.Append('\n');
                    if (i + 1 < inner.Length && inner[i + 1] == '\n')
                        i++;
                    continue;
                }
                sb.Append(inner[i]);
                if (inner[i] == quote && i + 1 < inner.Length && inner[i + 1] == quote)
                    i++;
            }
            // Line-ending normalization applies only in XML 1.1 mode (xml-version
            // dependency); otherwise references produce their exact characters.
            return _xml11LineEndings ? NormalizeXml11LineEndings(sb.ToString()) : sb.ToString();
        }
        return text;
    }

    // XML 1.1 line-ending normalization (applied only in XML 1.1 mode): #xD#xA and
    // #xD#x85 normalize to #xA, and lone #xD, #x85 (NEL), and #x2028 (LS) to #xA.
    private static string NormalizeXml11LineEndings(string text)
    {
        if (text.IndexOfAny('\r', '\u0085', '\u2028') < 0)
            return text;
        var sb = new StringBuilder(text.Length);
        for (int i = 0; i < text.Length; i++)
        {
            char c = text[i];
            if (c == '\r')
            {
                sb.Append('\n');
                if (i + 1 < text.Length && (text[i + 1] == '\n' || text[i + 1] == '\u0085'))
                    i++;
                continue;
            }
            if (c is '\u0085' or '\u2028')
            {
                sb.Append('\n');
                continue;
            }
            sb.Append(c);
        }
        return sb.ToString();
    }

    private string ExpandCharReference(string inner, ref int i)
    {
        int semi = inner.IndexOf(';', i + 1);
        if (semi < 0)
            throw new XPathParseException("XPST0003: Unterminated entity or character reference in string literal.", Current.Start);
        var reference = inner[(i + 1)..semi];
        string result = reference switch
        {
            "amp" => "&",
            "lt" => "<",
            "gt" => ">",
            "quot" => "\"",
            "apos" => "'",
            _ when reference.StartsWith("#x", StringComparison.Ordinal) =>
                ExpandNumericCharReference(reference, reference[2..], isHex: true, Current.Start),
            _ when reference.StartsWith('#') =>
                ExpandNumericCharReference(reference, reference[1..], isHex: false, Current.Start),
            _ => throw new XPathParseException($"XPST0003: Invalid entity or character reference '&{reference};' in string literal.", Current.Start)
        };
        i = semi;
        return result;
    }

    // Expands the digit run of a character reference. Syntactically invalid references
    // (empty, a sign, or non-digits) are XPST0003 (K2-Literals-25); values that do not
    // denote a valid XML character — including values overflowing the codepoint range —
    // are XQST0090 (K2-Literals-1/16..19, cbcl-literals-004/008).
    private static string ExpandNumericCharReference(string reference, string digits, bool isHex, int errorPosition)
    {
        if (digits.Length == 0 || !digits.All(isHex ? Uri.IsHexDigit : IsAsciiDigit))
            throw new XPathParseException($"XPST0003: Invalid entity or character reference '&{reference};' in string literal.", errorPosition);
        // More digits than the maximum codepoint (0x10FFFF) needs: the value overflows
        // even if it exceeds 64 bits (K2-Literals-18/19).
        var trimmed = digits.TrimStart('0');
        if (trimmed.Length > (isHex ? 6 : 7))
            throw new XPathParseException($"XQST0090: Character reference '&{reference};' does not denote a valid XML character.", errorPosition);
        int codePoint = isHex
            ? int.Parse(digits, NumberStyles.HexNumber, CultureInfo.InvariantCulture)
            : int.Parse(digits, NumberStyles.None, CultureInfo.InvariantCulture);
        ValidateXmlCharReference(codePoint, reference, errorPosition);
        return char.ConvertFromUtf32(codePoint);
    }

    // XQST0090: a character reference must denote a valid XML 1.1 character (any
    // codepoint except NUL, surrogates, and noncharacters; control characters are
    // permitted as references in XML 1.1).
    private static void ValidateXmlCharReference(int codePoint, string reference, int errorPosition)
    {
        bool valid = codePoint is >= 0x1 and <= 0xD7FF
            || (codePoint >= 0xE000 && codePoint <= 0xFFFD)
            || (codePoint >= 0x10000 && codePoint <= 0x10FFFF);
        if (!valid)
            throw new XPathParseException($"XQST0090: Character reference '&{reference};' does not denote a valid XML character.", errorPosition);
    }

    private static bool IsAsciiDigit(char c) => c is >= '0' and <= '9';

    private static bool CanStartStepExpr(Token token) => token.Kind switch
    {
        TokenKind.Dot or TokenKind.DotDot or TokenKind.At or TokenKind.Star
        or TokenKind.Name or TokenKind.Dollar or TokenKind.LParen
        or TokenKind.StringLiteral or TokenKind.IntegerLiteral
        or TokenKind.DecimalLiteral or TokenKind.DoubleLiteral
        or TokenKind.KeywordFunction or TokenKind.KeywordMap
        or TokenKind.KeywordArray or TokenKind.LBracket
        or TokenKind.Constructor => true,
        _ => IsKeywordName(token.Kind)
    };



    /// <summary>
    /// Skips over a SequenceType and returns a string representation.
    /// Handles simple types, item(), element(name), function(...) as type, etc.
    /// </summary>
    private string SkipSequenceType()
    {
        int start = _position;
        int parenDepth = 0;
        while (true)
        {
            if (Current.Kind == TokenKind.Eof)
                break;

            // Inline signatures retain their type text rather than using ParseSequenceType.
            // Apply the same record gate here, including nested map/array/function types.
            if (!_xpath40 && Current.Kind == TokenKind.Name && GetString(Current) == "record"
                && Peek(1).Kind == TokenKind.LParen)
                throw new XPathParseException("XPST0003: A record type ('record(...)') requires XPath 4.0.", Current.Start);

            if (Current.Kind == TokenKind.LParen)
            {
                parenDepth++;
                Advance();
                continue;
            }

            if (Current.Kind == TokenKind.RParen)
            {
                if (parenDepth == 0)
                    break; // RParen belongs to the caller, not the sequence type

                parenDepth--;
                Advance();
                // Occurrence indicator after closing paren
                if (Current.Kind == TokenKind.Question ||
                    Current.Kind == TokenKind.Star ||
                    Current.Kind == TokenKind.Plus)
                {
                    Advance();
                }
                // Function return type: function(...) as ReturnType
                if (Current.Kind == TokenKind.KeywordAs)
                {
                    Advance(); // as
                    continue;
                }
                if (parenDepth <= 0)
                    break;
                continue;
            }

            if (parenDepth == 0)
            {
                if (Current.Kind == TokenKind.Comma ||
                    Current.Kind == TokenKind.RParen ||
                    Current.Kind == TokenKind.LBrace)
                {
                    break;
                }
                // Expression boundaries: a sequence type never contains these at top level,
                // so a function-type return type must stop here (let-`as` before ':=' /
                // 'in' / 'return', typeswitch unions before '|', if-conditions before
                // 'then', etc.).
                if (Current.Kind is TokenKind.Assign or TokenKind.VBar
                    or TokenKind.KeywordIn or TokenKind.KeywordReturn or TokenKind.KeywordThen
                    or TokenKind.KeywordElse or TokenKind.KeywordSatisfies
                    or TokenKind.KeywordFor or TokenKind.KeywordLet)
                {
                    break;
                }
                // 'as' at top level is part of function return type
                if (Current.Kind == TokenKind.KeywordAs)
                {
                    Advance();
                    continue;
                }
            }

            Advance();
        }
        if (_position == start)
            return string.Empty;
        int charStart = _tokens[start].Start;
        int charEnd = _tokens[_position - 1].Start + _tokens[_position - 1].Length;
        return _source[charStart..charEnd];
    }

    private (string? Prefix, string Local, OccurrenceIndicator Occurrence) ParseSequenceType()
    {
        // A sequence type may be parenthesized: (function(xs:integer) as xs:integer)*
        // (hof-013). The inner occurrence stays inside the text.
        if (Match(TokenKind.LParen))
        {
            var inner = ParseSequenceType();

            // XPath 4.0 §3.2.5 ChoiceItemType: "(ItemType ++ "|")". Alternatives are
            // collected verbatim and re-serialized as (alt1|alt2|...) for the runtime
            // type matcher; a singleton parenthesized type keeps the existing path.
            if (Current.Kind == TokenKind.VBar)
            {
                if (!_xpath40)
                    throw new XPathParseException("XPST0003: A choice item type ('|' alternatives in parentheses) requires XPath 4.0.", Current.Start);
                var alternatives = new List<(string? Prefix, string Local, OccurrenceIndicator Occurrence)> { inner };
                while (Match(TokenKind.VBar))
                    alternatives.Add(ParseSequenceType());
                Expect(TokenKind.RParen);
                var sb = new System.Text.StringBuilder("(");
                for (int i = 0; i < alternatives.Count; i++)
                {
                    if (i > 0) sb.Append('|');
                    var alt = alternatives[i];
                    sb.Append(alt.Prefix is null ? alt.Local : $"{alt.Prefix}:{alt.Local}");
                    sb.Append(alt.Occurrence switch
                    {
                        OccurrenceIndicator.ZeroOrOne => "?",
                        OccurrenceIndicator.ZeroOrMore => "*",
                        OccurrenceIndicator.OneOrMore => "+",
                        _ => ""
                    });
                }
                sb.Append(')');
                OccurrenceIndicator choiceOccurrence = OccurrenceIndicator.One;
                if (Match(TokenKind.Question))
                    choiceOccurrence = OccurrenceIndicator.ZeroOrOne;
                else if (Match(TokenKind.Star))
                    choiceOccurrence = OccurrenceIndicator.ZeroOrMore;
                else if (Match(TokenKind.Plus))
                    choiceOccurrence = OccurrenceIndicator.OneOrMore;
                return (null, sb.ToString(), choiceOccurrence);
            }

            Expect(TokenKind.RParen);
            var innerText = (inner.Prefix is null ? inner.Local : $"{inner.Prefix}:{inner.Local}")
                + inner.Occurrence switch
                {
                    OccurrenceIndicator.ZeroOrOne => "?",
                    OccurrenceIndicator.ZeroOrMore => "*",
                    OccurrenceIndicator.OneOrMore => "+",
                    _ => ""
                };
            OccurrenceIndicator outerOccurrence = OccurrenceIndicator.One;
            if (Match(TokenKind.Question))
                outerOccurrence = OccurrenceIndicator.ZeroOrOne;
            else if (Match(TokenKind.Star))
                outerOccurrence = OccurrenceIndicator.ZeroOrMore;
            else if (Match(TokenKind.Plus))
                outerOccurrence = OccurrenceIndicator.OneOrMore;
            return (null, $"({innerText})", outerOccurrence);
        }

        var (prefix, local, _) = ParseTypeNameAndParens();

        // "empty-sequence()" is a complete sequence type by itself; an occurrence
        // indicator after it is a syntax error (K-QuantExprWith-7/8).
        if (prefix is null && local == "empty-sequence()"
            && Current.Kind is TokenKind.Question or TokenKind.Star or TokenKind.Plus)
        {
            throw new XPathParseException("XPST0003: empty-sequence() must not have an occurrence indicator.", Current.Start);
        }

        OccurrenceIndicator occurrence = OccurrenceIndicator.One;
        if (Match(TokenKind.Question))
            occurrence = OccurrenceIndicator.ZeroOrOne;
        else if (Match(TokenKind.Star))
            occurrence = OccurrenceIndicator.ZeroOrMore;
        else if (Match(TokenKind.Plus))
            occurrence = OccurrenceIndicator.OneOrMore;
        return (prefix, local, occurrence);
    }

    private (string? Prefix, string Local, OccurrenceIndicator Occurrence) ParseSingleType()
    {
        // XPath 4.0 §3.2.5: a choice item type (all-generalized-atomic) or an enumeration
        // type may appear as the target of 'cast'/'castable as' (e.g.
        // "cast @when as (xs:date | xs:dateTime)"). Parse via the full sequence-type
        // production so enum(...) and parenthesized choices flow through; non-atomic
        // targets are rejected at runtime (XQST0052/XPST0051) as before.
        if (_xpath40 && Current.Kind == TokenKind.LParen)
        {
            var choice = ParseSequenceType();
            var choiceLocal = choice.Local;
            // A singleton choice designates the inner type itself (XPath 4.0 §3.2.5);
            // unwrap it so the runtime cast sees a plain type name.
            if (choiceLocal.Length > 1 && choiceLocal[0] == '(' && choiceLocal[^1] == ')' && !choiceLocal.Contains('|'))
                choiceLocal = choiceLocal[1..^1];
            if (Match(TokenKind.Question))
                return (choice.Prefix, choiceLocal, OccurrenceIndicator.ZeroOrOne);
            if (choice.Occurrence is OccurrenceIndicator.ZeroOrMore or OccurrenceIndicator.OneOrMore)
                throw new XPathParseException("XPST0003: '*' and '+' are not allowed as occurrence indicators in 'cast' or 'castable as' expressions.", Current.Start);
            return (choice.Prefix, choiceLocal, choice.Occurrence);
        }

        var (prefix, local, hasParens) = ParseTypeNameAndParens();
        if (hasParens && !_xpath40)
            throw new XPathParseException("XPST0003: Type tests with parentheses are not allowed in 'cast' or 'castable as' expressions.", Current.Start);

        if (Match(TokenKind.Question))
            return (prefix, local, OccurrenceIndicator.ZeroOrOne);
        if (Current.Kind is TokenKind.Star or TokenKind.Plus)
        {
            // '*' and '+' are not valid occurrence indicators in a SingleType. If the next token
            // can start a new operand, treat them as the surrounding additive/multiplicative
            // operator rather than raising an occurrence-indicator error.
            if (!CanStartUnaryExpr(Peek(1).Kind))
                throw new XPathParseException("XPST0003: '*' and '+' are not allowed as occurrence indicators in 'cast' or 'castable as' expressions.", Current.Start);
        }
        return (prefix, local, OccurrenceIndicator.One);
    }

    private static bool CanStartUnaryExpr(TokenKind kind)
    {
        return kind switch
        {
            TokenKind.Plus or TokenKind.Minus or TokenKind.Star or TokenKind.Name or
            TokenKind.Dollar or TokenKind.LParen or TokenKind.StringLiteral or
            TokenKind.IntegerLiteral or TokenKind.DecimalLiteral or TokenKind.DoubleLiteral or
            TokenKind.Dot or TokenKind.DotDot or TokenKind.At or
            TokenKind.Slash or TokenKind.SlashSlash or
            TokenKind.KeywordFunction or TokenKind.KeywordMap or TokenKind.KeywordArray => true,
            _ => false,
        };
    }

    private (string? Prefix, string Local, bool HasParens) ParseTypeNameAndParens()
    {
        // Annotation assertions preceding a function test are captured verbatim into the
        // type text; the runtime type matcher validates (XQST0045) and ignores them.
        string annotations = CaptureAnnotations();
        string name;
        if (Current.Kind == TokenKind.Name)
        {
            name = GetString(Current);
            Advance();
        }
        else if (Current.Kind == TokenKind.KeywordFunction)
        {
            name = "function";
            Advance();
        }
        else if (Current.Kind == TokenKind.KeywordMap)
        {
            name = "map";
            Advance();
        }
        else if (Current.Kind == TokenKind.KeywordArray)
        {
            name = "array";
            Advance();
        }
        else
        {
            throw new XPathParseException($"Expected sequence type but found {Current.Kind}", Current.Start);
        }

        var (prefix, local, nsUri) = SplitQName(name);

        // If the input was a braced URI literal (e.g. Q{http://www.w3.org/2001/XMLSchema}double),
        // restore the conventional prefix so that downstream sequence-type processing can
        // recognise standard type families (xs:*, map:*, array:*). For other namespaces
        // (including the empty namespace Q{}local), preserve the EQName lexical form so that
        // the namespace is not lost when the type string is reconstructed from (prefix,local).
        if (string.IsNullOrEmpty(prefix) && nsUri is not null)
        {
            prefix = nsUri switch
            {
                "http://www.w3.org/2001/XMLSchema" => "xs",
                "http://www.w3.org/2005/xpath-functions/map" => "map",
                "http://www.w3.org/2005/xpath-functions/array" => "array",
                _ => null
            };

            if (prefix is null)
            {
                local = $"Q{{{nsUri}}}{local}";
            }
        }

        if (string.IsNullOrEmpty(prefix) && local == "fn" && Current.Kind == TokenKind.LParen && !_xpath40)
            throw new XPathParseException("XPST0003: The fn function-type synonym requires XPath 4.0.", Current.Start);
        if (_xpath40 && string.IsNullOrEmpty(prefix) && local is "function" or "fn" && Current.Kind == TokenKind.LParen)
        {
            var functionType = ParseFunctionSequenceType();
            return (null, annotations.Length > 0 ? annotations + " " + functionType : functionType, true);
        }

        // Consume optional parens and their contents: item(), node(), empty-sequence(), function(*), function(int) as int, map(*), element(foo), etc.
        bool hasParens = false;
        var baseLocal = local;
        if (Current.Kind == TokenKind.LParen)
        {
            hasParens = true;
            int parenDepth = 0;
            var sb = new System.Text.StringBuilder();
            sb.Append(local);
            do
            {
                if (Current.Kind == TokenKind.LParen)
                {
                    parenDepth++;
                    sb.Append(GetString(Current));
                    Advance();
                }
                else if (Current.Kind == TokenKind.RParen)
                {
                    parenDepth--;
                    sb.Append(GetString(Current));
                    Advance();
                }
                else if (Current.Kind == TokenKind.KeywordAs)
                {
                    // Nested function tests: keep ' as ' separated so that the
                    // concatenated type string remains parseable (ArrayTest-063).
                    sb.Append(' ');
                    sb.Append(GetString(Current));
                    sb.Append(' ');
                    Advance();
                }
                else
                {
                    if (!_xpath40 && baseLocal == "function" && Current.Kind == TokenKind.Dollar)
                        throw new XPathParseException("XPST0003: Named function-type parameters require XPath 4.0.", Current.Start);
                    sb.Append(GetString(Current));
                    Advance();
                }
            } while (parenDepth > 0 && Current.Kind != TokenKind.Eof);
            local = sb.ToString();

            if (baseLocal == "processing-instruction" && string.IsNullOrEmpty(prefix))
                TryParseProcessingInstructionTypeTarget(local, out _);

            // XPath 4.0 §3.2.6 EnumerationType: enum("red", "green", ...). 'enum' is
            // contextual — this branch only fires for a type-position Name 'enum'
            // followed by '('; calls to a function named enum(...) never reach here.
            if (baseLocal.Equals("enum", StringComparison.OrdinalIgnoreCase) && string.IsNullOrEmpty(prefix))
            {
                if (!_xpath40)
                    throw new XPathParseException("XPST0003: An enumeration type ('enum(...)') requires XPath 4.0.", Current.Start);
                ValidateEnumTypeLiterals(local);
            }

            // XPath 4.0 §3.2.10 RecordType: record(*) or record(field, ...). Like enum,
            // 'record' is contextual here — this branch only fires for a type-position
            // Name 'record' followed by '('. The field list is parsed from the verbatim
            // text so the runtime can attach/validate record annotations on maps.
            if (baseLocal.Equals("record", StringComparison.Ordinal) && string.IsNullOrEmpty(prefix))
            {
                if (!_xpath40)
                    throw new XPathParseException("XPST0003: A record type ('record(...)') requires XPath 4.0.", Current.Start);
                ValidateRecordTypeFields(local);
            }

            // "document" is neither a kind test nor a type name: document() and document(*)
            // in a SequenceType are syntax errors (K2-NodeTest-12/13).
            if (baseLocal == "document" && string.IsNullOrEmpty(prefix))
            {
                var parensContent = local[baseLocal.Length..];
                if (parensContent is "()" or "(*)")
                    throw new XPathParseException("XPST0003: document() and document(*) are not valid sequence types.", Current.Start);
            }

            // A function test that lists argument types (anything other than the
            // any-function form function(*)) is a TypedFunctionTest and requires an
            // 'as' return type: a bare function(xs:integer) is a syntax error (hof-910).
            if (local.StartsWith("function(", StringComparison.OrdinalIgnoreCase)
                && !local.StartsWith("function(*)", StringComparison.OrdinalIgnoreCase)
                && Current.Kind != TokenKind.KeywordAs)
            {
                throw new XPathParseException("XPST0003: A function test with argument types requires an 'as' return type.", Current.Start);
            }

            // Function tests may have a return type: function(item()*) as xs:double
            if (local.StartsWith("function", StringComparison.OrdinalIgnoreCase)
                && Current.Kind == TokenKind.KeywordAs)
            {
                sb.Append(' ');
                sb.Append(GetString(Current)); // 'as'
                Advance();
                sb.Append(' ');
                string returnType = SkipSequenceType();
                sb.Append(returnType);
                local = sb.ToString();
            }

            if (parenDepth > 0)
            {
                throw new XPathParseException("Unclosed sequence type parenthesis", Current.Start);
            }
        }

        return (prefix, annotations.Length > 0 ? annotations + " " + local : local, hasParens);
    }

    private string ParseFunctionSequenceType()
    {
        Expect(TokenKind.LParen);
        if (Match(TokenKind.Star))
        {
            Expect(TokenKind.RParen);
            return "function(*)";
        }
        var parameters = new List<string>();
        var names = new HashSet<string>(StringComparer.Ordinal);
        if (Current.Kind != TokenKind.RParen)
        {
            do
            {
                var parameterName = string.Empty;
                if (Match(TokenKind.Dollar))
                {
                    var name = GetString(ExpectName());
                    SplitQName(name);
                    if (!names.Add(name)) throw new XPathParseException("XQST0039: Duplicate function-type parameter name.", Current.Start);
                    Expect(TokenKind.KeywordAs);
                    parameterName = "$" + name + " as ";
                }
                parameters.Add(parameterName + RenderSequenceType(ParseSequenceType()));
            } while (Match(TokenKind.Comma));
        }
        Expect(TokenKind.RParen);
        Expect(TokenKind.KeywordAs);
        return "function(" + string.Join(",", parameters) + ") as " + RenderSequenceType(ParseSequenceType());
    }

    private static string RenderSequenceType((string? Prefix, string Local, OccurrenceIndicator Occurrence) type)
        => (type.Prefix is null ? type.Local : type.Prefix + ":" + type.Local) + (type.Occurrence switch
        {
            OccurrenceIndicator.ZeroOrOne => "?",
            OccurrenceIndicator.ZeroOrMore => "*",
            OccurrenceIndicator.OneOrMore => "+",
            _ => string.Empty
        });

    // Shared parsing keeps PI targets as case-sensitive NCNames rather than type QNames.
    internal static bool TryParseProcessingInstructionTypeTarget(string text, out string? target)
    {
        target = null;
        var opening = text.IndexOf('(');
        if (opening < 0 || text[..opening].Trim() != "processing-instruction") return false;
        if (!text.EndsWith(')')) throw new XPathParseException("XPST0003: Unclosed processing-instruction type.", 0);
        var inner = text[(opening + 1)..^1].Trim();
        if (inner.Length == 0) return true;
        if (inner[0] is '\'' or '"')
        {
            var quote = inner[0];
            var decoded = new StringBuilder();
            int i = 1;
            bool closed = false;
            while (i < inner.Length)
            {
                var c = inner[i++];
                if (c != quote) { decoded.Append(c); continue; }
                if (i < inner.Length && inner[i] == quote) { decoded.Append(quote); i++; continue; }
                closed = true;
                break;
            }
            if (!closed || i != inner.Length) throw new XPathParseException("XPST0003: A processing-instruction type requires one name or string literal.", 0);
            target = decoded.ToString().Trim();
            if (!IsValidNCName(target)) throw new XPathParseException("XPTY0004: A processing-instruction target must be an NCName.", 0);
        }
        else
        {
            if (!IsValidNCName(inner)) throw new XPathParseException("XPST0003: A processing-instruction type requires an unprefixed NCName or string literal.", 0);
            target = inner;
        }
        return true;
    }

    // Validates the inner text of an EnumerationType (enum("a", "b", ...)): a non-empty
    // comma-separated list of string literals (quote-aware: literals may contain commas,
    // parentheses and doubled quotes). The runtime matcher re-parses the same text.
    private static void ValidateEnumTypeLiterals(string enumText)
    {
        int open = enumText.IndexOf('(', StringComparison.Ordinal);
        if (open < 0 || !enumText.EndsWith(")", StringComparison.Ordinal))
            throw new XPathParseException("XPST0003: An enumeration type must have the form enum(\"value\", ...).", 0);
        string inner = enumText[(open + 1)..^1];
        int pos = 0;
        int count = 0;
        while (true)
        {
            while (pos < inner.Length && char.IsWhiteSpace(inner[pos])) pos++;
            if (pos >= inner.Length)
                break;
            if (inner[pos] is not ('\'' or '"'))
                throw new XPathParseException("XPST0003: Enumeration values must be string literals.", 0);
            char quote = inner[pos++];
            bool closed = false;
            while (pos < inner.Length)
            {
                if (inner[pos] == quote)
                {
                    if (pos + 1 < inner.Length && inner[pos + 1] == quote) { pos += 2; continue; }
                    pos++; closed = true; break;
                }
                pos++;
            }
            if (!closed)
                throw new XPathParseException("XPST0003: Unterminated string literal in enumeration type.", 0);
            count++;
            while (pos < inner.Length && char.IsWhiteSpace(inner[pos])) pos++;
            if (pos >= inner.Length)
                break;
            if (inner[pos] != ',')
                throw new XPathParseException("XPST0003: Enumeration values must be separated by commas.", 0);
            pos++;
        }
        if (count == 0)
            throw new XPathParseException("XPST0003: An enumeration type must list at least one value.", 0);
    }

    // Parses the member values out of a validated EnumerationType text, unescaping doubled
    // quotes. Returns null when the text is not a well-formed enumeration type.
    internal static string[]? TryParseEnumTypeMembers(string enumText)
    {
        string trimmed = enumText.Trim();
        if (!trimmed.StartsWith("enum(", StringComparison.OrdinalIgnoreCase) || !trimmed.EndsWith(')'))
            return null;
        string inner = trimmed[5..^1];
        var members = new List<string>();
        int pos = 0;
        while (true)
        {
            while (pos < inner.Length && char.IsWhiteSpace(inner[pos])) pos++;
            if (pos >= inner.Length)
                break;
            if (inner[pos] is not ('\'' or '"'))
                return null;
            char quote = inner[pos++];
            var sb = new System.Text.StringBuilder();
            bool closed = false;
            while (pos < inner.Length)
            {
                if (inner[pos] == quote)
                {
                    if (pos + 1 < inner.Length && inner[pos + 1] == quote) { sb.Append(quote); pos += 2; continue; }
                    pos++; closed = true; break;
                }
                sb.Append(inner[pos]);
                pos++;
            }
            if (!closed)
                return null;
            members.Add(sb.ToString());
            while (pos < inner.Length && char.IsWhiteSpace(inner[pos])) pos++;
            if (pos >= inner.Length)
                break;
            if (inner[pos] != ',')
                return null;
            pos++;
        }
        return members.Count > 0 ? members.ToArray() : null;
    }

    // Validates the inner text of a RecordType (record(...)): 'record(*)', the empty
    // record 'record()', or a comma-separated list of FieldDeclarations
    // (FieldName ('as' SequenceType)?, with an optional trailing comma). Field names may
    // be NCNames or string literals; duplicate field names are XPST0021. The runtime
    // re-parses the same text via TryParseRecordTypeFields.
    private static void ValidateRecordTypeFields(string recordText)
    {
        var trimmed = recordText.Trim();
        bool wellFormed = trimmed.Equals("record(*)", StringComparison.Ordinal)
            || TryParseRecordTypeFields(recordText) is not null;
        if (!wellFormed)
            throw new XPathParseException("XPST0003: A record type must have the form record(*), record(), or record(field ('as' SequenceType)?, ...).", 0);
    }

    // Parses the field declarations out of a RecordType text into the Core XDM
    // representation. Returns null when the text is not a well-formed record type;
    // throws XPST0021 on duplicate field names (the declaration is well-formed but
    // illegal). Quote- and paren-aware: field names may be string literals containing
    // commas or parentheses, and field types may contain parenthesized or nested types.
    internal static XdmRecordField[]? TryParseRecordTypeFields(string recordText)
    {
        string trimmed = recordText.Trim();
        if (!trimmed.StartsWith("record(", StringComparison.Ordinal) || !trimmed.EndsWith(')'))
            return null;
        string inner = trimmed[7..^1];
        var fields = new List<XdmRecordField>();
        var seen = new HashSet<string>(StringComparer.Ordinal);
        int pos = 0;
        SkipWhite(inner, ref pos);
        // 'record()' (the grammar's zero-repetition form) declares the empty record;
        // 'record(*)' is the wildcard and is not a field list.
        if (pos >= inner.Length)
            return fields.ToArray();
        if (inner[pos] == '*')
            return null;
        while (true)
        {
            SkipWhite(inner, ref pos);
            if (pos >= inner.Length)
                return null;
            string name;
            if (inner[pos] is '\'' or '"')
            {
                if (!TryReadFieldNameLiteral(inner, ref pos, out name))
                    return null;
            }
            else
            {
                int nameStart = pos;
                while (pos < inner.Length && !char.IsWhiteSpace(inner[pos]) && inner[pos] != ',')
                    pos++;
                name = inner[nameStart..pos];
                if (!IsFieldNameNcName(name))
                    return null;
            }
            if (!seen.Add(name))
                throw new XPathParseException($"XPST0021: The record type declares the field '{name}' more than once.", 0);

            SkipWhite(inner, ref pos);
            string typeText = "item()*";
            bool allowsEmpty = true;
            if (pos < inner.Length
                && inner[pos] == 'a' && pos + 1 < inner.Length && inner[pos + 1] == 's'
                && (pos + 2 >= inner.Length || char.IsWhiteSpace(inner[pos + 2])))
            {
                pos += 2;
                SkipWhite(inner, ref pos);
                int typeStart = pos;
                int depth = 0;
                while (pos < inner.Length)
                {
                    char c = inner[pos];
                    if (c is '\'' or '"')
                    {
                        if (!SkipFieldTypeLiteral(inner, ref pos))
                            return null;
                        continue;
                    }
                    if (c == '(') depth++;
                    else if (c == ')') { if (depth == 0) return null; depth--; }
                    else if (c == ',' && depth == 0) break;
                    pos++;
                }
                if (depth != 0)
                    return null;
                typeText = inner[typeStart..pos].Trim();
                if (typeText.Length == 0)
                    return null;
                allowsEmpty = typeText[^1] is '?' or '*'
                    || typeText.Equals("empty-sequence()", StringComparison.Ordinal);
            }
            fields.Add(new XdmRecordField(name, typeText, allowsEmpty));

            SkipWhite(inner, ref pos);
            if (pos >= inner.Length)
                break;
            if (inner[pos] != ',')
                return null;
            pos++;
            // The grammar allows a trailing comma: record(a, b,).
            SkipWhite(inner, ref pos);
            if (pos >= inner.Length)
                break;
        }
        return fields.ToArray();
    }

    private static void SkipWhite(string text, ref int pos)
    {
        while (pos < text.Length && char.IsWhiteSpace(text[pos])) pos++;
    }

    // Reads a string-literal field name ("..." or '...'), unescaping doubled quotes.
    private static bool TryReadFieldNameLiteral(string text, ref int pos, out string value)
    {
        value = string.Empty;
        char quote = text[pos++];
        var sb = new StringBuilder();
        while (pos < text.Length)
        {
            if (text[pos] == quote)
            {
                if (pos + 1 < text.Length && text[pos + 1] == quote) { sb.Append(quote); pos += 2; continue; }
                pos++;
                value = sb.ToString();
                return true;
            }
            sb.Append(text[pos]);
            pos++;
        }
        return false;
    }

    // Skips a string literal inside a field type (literals may contain commas or parens).
    private static bool SkipFieldTypeLiteral(string text, ref int pos)
    {
        char quote = text[pos++];
        while (pos < text.Length)
        {
            if (text[pos] == quote)
            {
                if (pos + 1 < text.Length && text[pos + 1] == quote) { pos += 2; continue; }
                pos++;
                return true;
            }
            pos++;
        }
        return false;
    }

    // A field name written as an NCName: letter or '_' start, then letters, digits,
    // '.', '-' or '_'. (A pragmatic NCName check; the lexer validated NCNames in the
    // source, this re-validates the concatenated verbatim text.)
    private static bool IsFieldNameNcName(string name)
    {
        if (name.Length == 0 || !(char.IsLetter(name[0]) || name[0] == '_'))
            return false;
        foreach (char c in name)
            if (!(char.IsLetterOrDigit(c) || c is '.' or '-' or '_'))
                return false;
        return true;
    }

    // Captures the verbatim source text of annotation assertions
    // ('%' EQName ('(' Literal (',' Literal)* ')')?)* preceding a function test;
    // returns the empty string when there are none.
    private string CaptureAnnotations()
    {
        if (Current.Kind != TokenKind.Percent)
            return string.Empty;
        // Annotation assertions are an XQuery-only grammar extension (inline-fn-016).
        if (!_allowFullFlwor)
            throw new XPathParseException("XPST0003: Annotations are not allowed in XPath.", Current.Start);
        int start = Current.Start;
        int end = Current.Start;
        while (Current.Kind == TokenKind.Percent)
        {
            Advance();
            if (Current.Kind != TokenKind.Name)
                throw new XPathParseException($"XPST0003: Expected an annotation name after '%' but found {Current.Kind}", Current.Start);
            end = Current.Start + Current.Length;
            Advance(); // EQName (plain, prefixed, or Q{uri}local)
            if (Current.Kind == TokenKind.LParen)
            {
                SkipAnnotationArguments();
                end = End;
            }
        }
        return _source[start..end];
    }
}

// ------------------------------------------------------------------
// Supporting AST nodes used by parser
// ------------------------------------------------------------------


