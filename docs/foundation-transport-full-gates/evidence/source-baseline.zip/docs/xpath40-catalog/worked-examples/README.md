<div align="center">
  <img src="../../../assets/logos/fytala-logo-color-dark.svg" width="100" alt="Fytala Bosak reference guide worked examples">
  <br><br>
  <h1>Worked Examples and Chapter Plan</h1>
  <p>Learn XPath and XSLT through practical document-processing tasks</p>
</div>

**REQ-126 complete for the accepted bounded catalog — 26 October 2026:** [Owner acceptance](../CATALOG-ACCEPTANCE.md) closes C13 and all 13 workpackages; zero remain open. AC-01 through AC-04 are explicitly accepted for 76 entries/235 bounded contract groups; AC-05 maintained. All 38 catalog dispositions are accepted while all 48 unmet batch observations and original technical exit criteria remain unchanged. No full current-draft compliance, engine fix, gate change or release follows. Earlier open-state notices are historical.


**REQ-126 C13 review prepared — 26 October 2026:** [Final closure review](../FINAL-CLOSURE-REVIEW.md) consolidates 76 entries, 235 bounded contract groups and 38 proposed disposition records. All 3,172 fresh documentation tests pass. Six Known Uses sections now state their evidence/gate boundary directly. The [acceptance proposal](../C13-ACCEPTANCE-PROPOSAL.md) would close the documentation catalog with explicit limits and open technical follow-ups; it is not approved. All 48 unmet batch observations remain unmet. C13 remains open, AC-01 through AC-04 unchecked and REQ-126 In Progress; no engine, fixture, gate, version or release change. Earlier checkpoints are historical.


## Reading path

Start with a business problem and follow the transformation from input to expected output. Each chapter has complete runnable files and named verification tests. The [feature catalog](../README.md) supplies detailed syntax and compatibility reference material when you need it.

| Chapter | Status | What it teaches |
|---|---|---|
| [Supplier invoices to ERP XML](invoice-to-erp/README.md) | Implemented; executable fixtures and tests supplied | Namespaces, selection, templates, optional fields, decimal calculations, grouping, exception output; a separate 3.1/4.0 migration pair. |
| [XML manual to HTML](manual-to-html/README.md) | Implemented; fixtures and three checks | Mixed content, template modes, stable heading IDs, internal links, table of contents, and missing-link detection. |
| [Order reconciliation report](order-reconciliation/README.md) | Implemented; fixtures and three checks | Customer/product grouping, lookup joins, missing reference data, and report/exception separation. |
| [Order validation and routing](order-routing/README.md) | Implemented; complete fixtures and eleven checks | Standalone XSLT 4.0 routing in source 1.1.1; explicit XPath40 planning plus XSLT 3.0 remains the 1.1.0 alternative. |

The first three chapters cover business mapping, document publishing, and operational reconciliation. Follow them in that order, or start with the task closest to your application. The [catalog examples](../examples/README.md) add 3,148 focused checks, including earlier-version baselines and compatibility refusals.

## Worked-example contract

1. State the user's problem and the output contract, including what a host must decide.
2. Declare assumptions and simplifications; identify synthetic vocabularies and sample data.
3. Supply complete input, code, expected output, required context, and compatibility level. Each chapter README shows full complete/edge-case input and output documents inline, with links to the executable fixtures.
4. Walk through the solution before discussing internal engine implementation. Explain source-to-target fields, validation and rejection rules, and every XSLT element used; identify the XPath constructs that make the solution work.
5. Explain choices and alternatives, including earlier-version idioms where useful.
6. Include at least one meaningful edge case and executable evidence for every claimed result.
7. Link back to relevant feature entries and forward to the next chapter.

The executable files are part of the teaching material. XSLT files carry a
standalone input/output contract, a change history, documented helper edge cases,
and template preconditions. Follow the [applicable XSLT comment conventions](../../XSLT_STYLE_GUIDE.md).

The original three planned chapters and the new routing chapter are supplied and executable. The catalog has practical cases for its 68 current entries, but the wider inventory of shipped functions and deferred decisions remains incomplete; REQ-126 stays in progress.
