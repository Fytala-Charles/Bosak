<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="4.0"><xsl:output method="text"/><xsl:template match="/"><xsl:value-of select="0x10"/></xsl:template></xsl:stylesheet>
