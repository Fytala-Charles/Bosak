<?xml version="1.0" encoding="utf-8"?>
<!--
AUTHOR: Charles Korthout
CREATE DATE: 12 October 2026
PURPOSE: Verify deferred XSLT named type declarations or portable invoice validation.
SPECIAL NOTES: Synthetic invoice projection exercising named record coercion.
COPYRIGHT: Fytala
LICENSE: license.md (Apache-2.0)
SPDX-License-Identifier: Apache-2.0
Change History: Charles Korthout | 0.1 | 12-10-2026 | Creation
Change History: Charles Korthout | 0.2 | 13-10-2026 | Document implemented nominative binding conversion
Input: invoice attributes id, currency and amount. Output: text report or declared error.
Named binding converts the plain map to the declared invoice record; output is INV-2048.
-->
<xsl:stylesheet version="4.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns:erp="urn:example:erp" xmlns:map="http://www.w3.org/2005/xpath-functions/map">
  <xsl:output method="text"/>
<xsl:record-type name="erp:invoice" constructor="yes"><xsl:field name="id" as="xs:string"/><xsl:field name="currency" as="xs:string"/></xsl:record-type>
  <!-- Context: document node; result: text or error. Local values are evaluated when used. -->
  <xsl:template match="/">
<xsl:variable name="r" as="erp:invoice" select="map {'id': 'INV-2048', 'currency': 'EUR'}"/><xsl:value-of select="$r?id"/>
  </xsl:template>
</xsl:stylesheet>
