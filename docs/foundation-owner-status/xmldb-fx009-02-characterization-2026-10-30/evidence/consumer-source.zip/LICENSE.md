# Proprietary License

Copyright (c) Fytala. All rights reserved.

This software and associated documentation files (the "Software") are the
proprietary and confidential property of Fytala.

No part of the Software may be copied, modified, distributed, sublicensed,
or used in any form without the prior written permission of Fytala,
except as expressly agreed in a separate written license agreement.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED. IN NO EVENT SHALL Fytala BE LIABLE FOR ANY CLAIM, DAMAGES,
OR OTHER LIABILITY ARISING FROM THE USE OF THE SOFTWARE.
