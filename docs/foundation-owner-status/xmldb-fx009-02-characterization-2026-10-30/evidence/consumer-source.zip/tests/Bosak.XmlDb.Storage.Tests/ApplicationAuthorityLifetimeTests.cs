// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Qualifies paired authority inspection, exclusive modes and actual operation drain.
// SPECIAL NOTES        : Fresh private test roots only; no live store, provisioning capability or write authority is exercised.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Qualifies paired authority inspection, exclusive modes and actual operation drain.</summary>
public sealed class ApplicationAuthorityLifetimeTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ep7c-" + Guid.NewGuid().ToString("N"));
    private string Host => Path.Combine(_area, "host");
    private string Root => Path.Combine(_area, "authority");
    private string Data => Path.Combine(_area, "source");
    private static Guid AdminId => Guid.Parse("20314253-6475-8697-a8b9-cadbecfd0e1f");
    private static Guid AuthorityId => Guid.Parse("10213243-5465-7687-98a9-bacbdcedfe0f");
    private static byte[] Fixture(string name) => Convert.FromHexString(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "TestData", name)).Trim());
    private static ApplicationAuthorityConfiguration Configuration() => new(AuthorityId, AdminId, "embedded-pilot", "orders", "admin-root", "application-root");
    private Dictionary<string, string> Roots() => new(StringComparer.Ordinal)
    {
        ["admin-root"] = Host,
        ["application-root"] = Root,
        ["source-root"] = Data,
        ["candidate-root"] = Path.Combine(_area, "bundle", "store"),
        ["artifact-root"] = Path.Combine(_area, "artifact"),
        ["bundle-root"] = Path.Combine(_area, "bundle")
    };
    private void Seed(bool empty = false)
    {
        Directory.CreateDirectory(Host); Directory.CreateDirectory(Root); Directory.CreateDirectory(Data);
        File.WriteAllBytes(Path.Combine(Host, "owner.lock"), []);
        File.WriteAllBytes(Path.Combine(Host, "host.meta"), HostJournalCodec.EncodeMetadata(AdminId, "embedded-pilot", "orders"));
        File.WriteAllBytes(Path.Combine(Host, "journal.bin"), []);
        File.WriteAllBytes(Path.Combine(Root, "authority.lock"), []);
        File.WriteAllBytes(Path.Combine(Root, "authority.meta"), ApplicationAuthorityCodec.EncodeMetadata(Configuration()));
        File.WriteAllBytes(Path.Combine(Root, "authority.log"), empty ? [] : Fixture("application-authority-enroll-v1.hex"));
    }
    private EmbeddedHostLifetime Parent() => EmbeddedHostLifetime.OpenExisting(Host, "embedded-pilot", "orders", [Data, Root]);
    private static EmbeddedHostInspectionEvidence Evidence(EmbeddedHostLifetime parent) => new(parent.Context, true, true, true, true, true);
    private static EmbeddedHostAdmissionEvidence Admission(EmbeddedHostLifetime parent) => new(parent.Context, true, true, true, true, true, true);
    private ApplicationAuthorityLifetime Open(EmbeddedHostLifetime parent) => ApplicationAuthorityLifetime.OpenExisting(parent,
        parent.JournalStatus.KnownPosition, Evidence(parent), Root, Configuration(), Roots());
    private Dictionary<string, byte[]> Bytes() => Directory.GetFiles(_area, "*", SearchOption.AllDirectories).ToDictionary(p => Path.GetRelativePath(_area, p), File.ReadAllBytes);
    private void AssertBytes(Dictionary<string, byte[]> before)
    {
        var after = Bytes(); Assert.Equal(before.Keys.Order(), after.Keys.Order());
        foreach (var pair in before) Assert.Equal(pair.Value, after[pair.Key]);
    }

    /// <summary>Only existing metadata/history is inspected; all bytes and stopped admissions remain unchanged.</summary>
    /// <param name="empty">Whether the reopened log has no enrollment.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void OpenExisting_ValidOrEmpty_RemainsStoppedAndUnchanged(bool empty)
    {
        Seed(empty); var before = Bytes(); var identity = ApplicationAuthorityFileIdentity.PathIdentity(Root, true);
        var roles = Directory.GetFiles(Root).ToDictionary(p => p, p => ApplicationAuthorityFileIdentity.PathIdentity(p, false));
        Assert.Equal(3, roles.Values.Distinct().Count()); using var parent = Parent();
        using (var authority = Open(parent))
        {
            Assert.True(authority.WritersMustRemainStopped); Assert.False(parent.AdmissionsOpen); Assert.Equal(1, parent.ActiveOperations);
            var history = authority.Inspect(); Assert.Equal(empty ? 0 : 1, history.Frames.Length); Assert.True(history.WritersMustRemainStopped);
            Assert.False(authority.IsReleased); Assert.False(authority.IsFaulted); Assert.Equal(0, authority.ActiveInspections);
        }
        Assert.Equal(0, parent.ActiveOperations); parent.Dispose(); AssertBytes(before);
        Assert.Equal(identity, ApplicationAuthorityFileIdentity.PathIdentity(Root, true));
        foreach (var role in roles) Assert.Equal(role.Value, ApplicationAuthorityFileIdentity.PathIdentity(role.Key, false));
    }

    /// <summary>Every competing administrative path is excluded while the paired mode holds authority handles.</summary>
    /// <param name="mode">Competing operation.</param>
    [Theory]
    [InlineData("admission")]
    [InlineData("operation")]
    [InlineData("reconciliation-read")]
    [InlineData("reconciliation-token")]
    [InlineData("executor")]
    [InlineData("stopped")]
    [InlineData("second-application")]
    [InlineData("enable")]
    [InlineData("append")]
    public void ApplicationMode_CompetingModes_RejectWithoutWrites(string mode)
    {
        Seed(); var before = Bytes(); using var parent = Parent(); using var authority = Open(parent); var position = parent.JournalStatus.KnownPosition;
        Assert.Throws<InvalidOperationException>(() =>
        {
            switch (mode)
            {
                case "admission": parent.OpenAdministrativeAdmissions(Admission(parent)); break;
                case "operation": using (parent.BeginOperation()) { } break;
                case "reconciliation-read": parent.ReadJournalForReconciliation(); break;
                case "reconciliation-token": using (parent.BeginReconciliationOperation()) { } break;
                case "executor": using (parent.BeginExclusiveExecutor(Guid.NewGuid())) { } break;
                case "stopped": using (parent.BeginStoppedReconciliation(position, Evidence(parent))) { } break;
                case "second-application": using (Open(parent)) { } break;
                case "enable": parent.EnableJournalAppend(position, Admission(parent)); break;
                case "append":
                    var intent = new EpochAdministrativeAttemptDescriptor(Guid.NewGuid(), EpochPublicationKind.LegacyMigration, Path.Combine(_area, "artifact"), Path.Combine(_area, "bundle"), new string('a', 64), Guid.NewGuid(), 7, 0, null, EpochProfile.ScalarWal, DurabilityMode.ProcessCrash);
                    var snapshot = new HostLedgerSnapshot(new(Guid.NewGuid(), "embedded-pilot", "orders", intent, 1, parent.Context.SessionId, 1), HostLedgerStage.Recorded);
                    parent.AppendJournal(position, HostJournalEvent.RecordIntent, snapshot); break;
            }
        });
        Assert.False(parent.AdmissionsOpen); Assert.Equal(1, parent.ActiveOperations); authority.Dispose(); parent.Dispose(); AssertBytes(before);
    }

    /// <summary>Invalid scope/position/facts or active parent operations cannot reserve or adopt authority.</summary>
    /// <param name="fault">Admission or binding error.</param>
    [Theory]
    [InlineData("foreign-evidence")]
    [InlineData("stale-evidence")]
    [InlineData("writers")]
    [InlineData("publishers")]
    [InlineData("prior-executor")]
    [InlineData("queue")]
    [InlineData("position")]
    [InlineData("admissions-open")]
    [InlineData("operation-active")]
    [InlineData("closed-parent")]
    [InlineData("admin-id")]
    [InlineData("deployment")]
    [InlineData("scope")]
    [InlineData("policy")]
    [InlineData("map-parent")]
    [InlineData("map-authority")]
    [InlineData("authority-id")]
    [InlineData("faulted-parent")]
    public void OpenExisting_InvalidParentOrBinding_Rejects(string fault)
    {
        Seed(); var before = Bytes(); using var parent = Parent(); var evidence = Evidence(parent); var position = parent.JournalStatus.KnownPosition;
        var config = Configuration(); var roots = Roots(); IDisposable? operation = null;
        switch (fault)
        {
            case "foreign-evidence": evidence = evidence with { Context = parent.Context with { SessionId = Guid.NewGuid() } }; break;
            case "stale-evidence": evidence = evidence with { Fresh = false }; break;
            case "writers": evidence = evidence with { AllWritersControlled = false }; break;
            case "publishers": evidence = evidence with { AllPublishersControlled = false }; break;
            case "prior-executor": evidence = evidence with { PriorExecutorsExcluded = false }; break;
            case "queue": evidence = evidence with { QueueFree = false }; break;
            case "position": position = position with { Length = 1 }; break;
            case "admissions-open": parent.OpenAdministrativeAdmissions(Admission(parent)); break;
            case "operation-active": operation = parent.BeginReconciliationOperation(); break;
            case "closed-parent": parent.Dispose(); break;
            case "authority-id": config = config with { AuthorityId = Guid.NewGuid() }; break;
            case "faulted-parent": File.WriteAllText(Path.Combine(Host, "unexpected"), "test"); Assert.Throws<InvalidDataException>(() => parent.ReadJournalForReconciliation()); File.Delete(Path.Combine(Host, "unexpected")); break;
            case "admin-id": config = config with { AdministrativeJournalId = Guid.NewGuid() }; break;
            case "deployment": config = config with { Deployment = "other" }; break;
            case "scope": config = config with { ResourceScope = "other" }; break;
            case "policy": config = config with { Durability = DurabilityMode.FileAndDirectoryFlush }; break;
            case "map-parent": roots[config.AdministrativeRootKey] = Data; break;
            case "map-authority": roots[config.AuthorityRootKey] = Data; break;
        }
        try { Assert.NotNull(Record.Exception(() => { using var rejected = ApplicationAuthorityLifetime.OpenExisting(parent, position, evidence, Root, config, roots); })); }
        finally { operation?.Dispose(); }
        parent.Dispose(); AssertBytes(before);
    }

    /// <summary>Invalid, missing, oversized or changed authority roles preserve inventory and release failed acquisitions.</summary>
    /// <param name="fault">Authority namespace or content fault.</param>
    [Theory]
    [InlineData("missing-root")]
    [InlineData("missing-owner")]
    [InlineData("owner-content")]
    [InlineData("metadata-short")]
    [InlineData("metadata-corrupt")]
    [InlineData("log-corrupt")]
    [InlineData("log-directory")]
    [InlineData("extra-role")]
    [InlineData("missing-map")]
    [InlineData("overlap-data")]
    [InlineData("small-inventory")]
    [InlineData("large-inventory")]
    [InlineData("relative-root")]
    [InlineData("oversized-log")]
    public void OpenExisting_InvalidAuthority_PreservesBytesAndHandles(string fault)
    {
        Seed(); var roots = Roots(); var root = Root;
        switch (fault)
        {
            case "missing-root": root = Path.Combine(_area, "absent"); roots["application-root"] = root; break;
            case "missing-owner": File.Delete(Path.Combine(Root, "authority.lock")); break;
            case "owner-content": File.WriteAllBytes(Path.Combine(Root, "authority.lock"), [1]); break;
            case "metadata-short": File.WriteAllBytes(Path.Combine(Root, "authority.meta"), [1]); break;
            case "metadata-corrupt": var meta = File.ReadAllBytes(Path.Combine(Root, "authority.meta")); meta[^1] ^= 1; File.WriteAllBytes(Path.Combine(Root, "authority.meta"), meta); break;
            case "log-corrupt": File.WriteAllBytes(Path.Combine(Root, "authority.log"), [1]); break;
            case "log-directory": File.Delete(Path.Combine(Root, "authority.log")); Directory.CreateDirectory(Path.Combine(Root, "authority.log")); break;
            case "extra-role": File.WriteAllText(Path.Combine(Root, "unknown"), "preserve"); break;
            case "missing-map": roots.Remove("source-root"); break;
            case "overlap-data": roots["source-root"] = Path.Combine(Root, "nested"); break;
            case "small-inventory": roots.Clear(); break;
            case "large-inventory": for (var i = 0; i < 65; i++) roots.Add("extra-" + i, Data); break;
            case "relative-root": root = "authority"; break;
            case "oversized-log": using (var file = File.OpenWrite(Path.Combine(Root, "authority.log"))) file.SetLength(ApplicationAuthorityCodec.MaximumJournalBytes + 1L); break;
        }
        var before = Bytes(); var directories = Directory.GetDirectories(_area, "*", SearchOption.AllDirectories).Order().ToArray();
        using var parent = Parent();
        Assert.NotNull(Record.Exception(() => { using var rejected = ApplicationAuthorityLifetime.OpenExisting(parent, parent.JournalStatus.KnownPosition, Evidence(parent), root, Configuration(), roots); }));
        Assert.Equal(0, parent.ActiveOperations); Assert.False(parent.AdmissionsOpen); parent.Dispose(); AssertBytes(before);
        Assert.Equal(directories, Directory.GetDirectories(_area, "*", SearchOption.AllDirectories).Order().ToArray()); Assert.False(Directory.Exists(Path.Combine(_area, "absent")));
        if (File.Exists(Path.Combine(Root, "authority.lock"))) using (new FileStream(Path.Combine(Root, "authority.lock"), FileMode.Open, FileAccess.ReadWrite, FileShare.None)) { }
    }

    /// <summary>Disposal while an actual read is paused retains both owners until that operation completes.</summary>
    /// <returns>A task that completes when qualification finishes.</returns>
    [Fact]
    public async Task Dispose_PausedInspection_RetainsBothOwnersUntilActualDrain()
    {
        Seed(); using var parent = Parent(); using var authority = Open(parent);
        using var entered = new ManualResetEventSlim(); using var release = new ManualResetEventSlim();
        var read = Task.Run(() => authority.InspectCore(() => { entered.Set(); Assert.True(release.Wait(TimeSpan.FromSeconds(20))); }));
        try
        {
            Assert.True(entered.Wait(TimeSpan.FromSeconds(10))); authority.Dispose(); parent.Dispose();
            Assert.Equal(1, authority.ActiveInspections); Assert.False(authority.WhenReleased.IsCompleted); Assert.False(parent.WhenReleased.IsCompleted);
            Assert.Throws<IOException>(() => { using var contender = Parent(); });
            Assert.Throws<IOException>(() => { using var contender = new FileStream(Path.Combine(Root, "authority.lock"), FileMode.Open, FileAccess.ReadWrite, FileShare.None); });
            Assert.Throws<ObjectDisposedException>(() => authority.Inspect());
        }
        finally { release.Set(); }
        Assert.True((await read).WritersMustRemainStopped); await authority.WhenReleased.WaitAsync(TimeSpan.FromSeconds(5)); await parent.WhenReleased.WaitAsync(TimeSpan.FromSeconds(5));
        Assert.True(authority.IsReleased); Assert.True(parent.IsReleased);
        using var nextParent = Parent(); using var nextAuthority = Open(nextParent); Assert.True(nextAuthority.WritersMustRemainStopped);
    }

    /// <summary>Parent shutdown cannot release a still-live child or allow a new child read.</summary>
    /// <returns>A task that completes when qualification finishes.</returns>
    [Fact]
    public async Task ParentDispose_LiveChild_RetainsUntilChildDisposal()
    {
        Seed(); using var parent = Parent(); using var authority = Open(parent); parent.Dispose();
        Assert.False(parent.WhenReleased.IsCompleted); Assert.Throws<ObjectDisposedException>(() => authority.Inspect());
        await Task.WhenAll(Enumerable.Range(0, 16).Select(_ => Task.Run(authority.Dispose)));
        await authority.WhenReleased.WaitAsync(TimeSpan.FromSeconds(5)); await parent.WhenReleased.WaitAsync(TimeSpan.FromSeconds(5));
        Assert.Equal(0, parent.ActiveOperations); Assert.True(authority.IsReleased);
    }

    /// <summary>Inspection failures permanently stop this child without releasing ownership early or mutating bytes.</summary>
    [Fact]
    public void Inspect_Failure_IsStickyAndPreservesBytes()
    {
        Seed(); var before = Bytes(); using var parent = Parent(); using var authority = Open(parent);
        Assert.Throws<IOException>(() => authority.InspectCore(() => throw new IOException("injected before-read failure")));
        Assert.True(authority.IsFaulted); Assert.Throws<InvalidOperationException>(() => authority.Inspect());
        Assert.False(authority.WhenReleased.IsCompleted); Assert.Equal(1, parent.ActiveOperations); authority.Dispose(); parent.Dispose(); AssertBytes(before);
    }

    /// <summary>Parent shutdown at every acquisition checkpoint rejects return and releases all acquired authority handles.</summary>
    /// <param name="stage">Checkpoint before final publication to the caller.</param>
    /// <returns>A task that completes when qualification finishes.</returns>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(2)]
    [InlineData(3)]
    public async Task OpenExisting_ParentShutdownDuringAcquisition_ReleasesInReverse(int stage)
    {
        Seed(); var before = Bytes(); using var parent = Parent();
        Assert.Throws<ObjectDisposedException>(() => ApplicationAuthorityLifetime.OpenExistingCore(parent, parent.JournalStatus.KnownPosition, Evidence(parent), Root,
            Configuration(), Roots(), point => { if ((int)point == stage) parent.Dispose(); }));
        await parent.WhenReleased.WaitAsync(TimeSpan.FromSeconds(5)); AssertBytes(before);
        using var next = Parent(); using var authority = Open(next);
    }

    /// <summary>Opaque registrations reject forged/foreign/disposed use and retain mode exclusion through active reads.</summary>
    [Fact]
    public void Registration_ForeignForgedAndDisposed_RejectsWithoutPrematureRelease()
    {
        Seed(); using var parent = Parent();
        using var forged = new EmbeddedHostLifetime.ApplicationInspectionRegistration(parent);
        Assert.Throws<InvalidOperationException>(() => forged.BeginRead(parent));
        using var registration = parent.BeginApplicationInspection(parent.JournalStatus.KnownPosition, Evidence(parent));
        Assert.Throws<InvalidOperationException>(() => registration.BeginRead(null!));
        using var read = registration.BeginRead(parent); registration.Dispose();
        Assert.Throws<ObjectDisposedException>(() => registration.BeginRead(parent));
        Assert.Throws<InvalidOperationException>(() => parent.OpenAdministrativeAdmissions(Admission(parent)));
        Assert.Equal(2, parent.ActiveOperations); read.Dispose(); Assert.Equal(0, parent.ActiveOperations);
    }

    /// <summary>Stopped reconciliation and an active executor exclude application acquisition in the reverse direction.</summary>
    /// <param name="stopped">Whether to hold a stopped session instead of an executor.</param>
    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public void OpenExisting_CompetingParentMode_Rejects(bool stopped)
    {
        Seed();
        var intent = new EpochAdministrativeAttemptDescriptor(Guid.NewGuid(), EpochPublicationKind.LegacyMigration,
            Path.Combine(_area, "artifact"), Path.Combine(_area, "bundle"), new string('a', 64), Guid.NewGuid(), 7, 0, null, EpochProfile.ScalarWal, DurabilityMode.ProcessCrash);
        var snapshot = new HostLedgerSnapshot(new(Guid.NewGuid(), "embedded-pilot", "orders", intent, 1, Guid.NewGuid(), 1), HostLedgerStage.Recorded);
        File.WriteAllBytes(Path.Combine(Host, "journal.bin"), HostJournalCodec.EncodeFrame(AdminId, 1, new string('0', 64), HostJournalEvent.RecordIntent, snapshot));
        var before = Bytes(); using var parent = Parent(); IDisposable token;
        if (stopped) token = parent.BeginStoppedReconciliation(parent.JournalStatus.KnownPosition, Evidence(parent));
        else { parent.OpenAdministrativeAdmissions(Admission(parent)); token = parent.BeginExclusiveExecutor(intent.AttemptId); parent.CloseAdmissions(); }
        using (token) Assert.Throws<InvalidOperationException>(() => Open(parent));
        parent.Dispose(); AssertBytes(before);
    }

    /// <summary>The base registration plus its actual child reads obey the shared operation bound and drain exactly once.</summary>
    /// <returns>A task that completes when qualification finishes.</returns>
    [Fact]
    public async Task Registration_ReadLimitAndRepeatedDisposal_DrainsExactlyOnce()
    {
        Seed(); using var parent = Parent(); var registration = parent.BeginApplicationInspection(parent.JournalStatus.KnownPosition, Evidence(parent));
        var reads = new List<IDisposable>();
        try
        {
            for (var index = 1; index < EmbeddedHostLifetime.MaximumOperations; index++) reads.Add(registration.BeginRead(parent));
            Assert.Throws<InvalidOperationException>(() => registration.BeginRead(parent)); registration.Dispose(); parent.Dispose();
            Assert.False(parent.WhenReleased.IsCompleted);
            await Task.WhenAll(Enumerable.Range(0, 16).Select(_ => Task.Run(reads[0].Dispose)));
            Assert.Equal(EmbeddedHostLifetime.MaximumOperations - 1, parent.ActiveOperations);
        }
        finally { foreach (var read in reads) read.Dispose(); registration.Dispose(); }
        await parent.WhenReleased.WaitAsync(TimeSpan.FromSeconds(5)); Assert.Equal(0, parent.ActiveOperations);
    }

    /// <summary>Repeated simultaneous inspection/shutdown schedules retain every admitted operation and release both leases.</summary>
    /// <returns>A task that completes when qualification finishes.</returns>
    [Fact]
    public async Task InspectAndDispose_SimultaneousSchedules_AlwaysDrain()
    {
        Seed(); var before = Bytes();
        for (var repeat = 0; repeat < 8; repeat++)
        {
            using var parent = Parent(); using var authority = Open(parent); using var start = new ManualResetEventSlim();
            var reads = Enumerable.Range(0, 4).Select(_ => Task.Run(() =>
            {
                start.Wait(); try { Assert.True(authority.Inspect().WritersMustRemainStopped); } catch (ObjectDisposedException) { }
            })).ToArray();
            var close = Task.Run(() => { start.Wait(); authority.Dispose(); parent.Dispose(); }); start.Set();
            await Task.WhenAll(reads.Append(close)); await authority.WhenReleased.WaitAsync(TimeSpan.FromSeconds(5)); await parent.WhenReleased.WaitAsync(TimeSpan.FromSeconds(5));
            Assert.True(authority.IsReleased); Assert.True(parent.IsReleased); Assert.Equal(0, authority.ActiveInspections); Assert.Equal(0, parent.ActiveOperations);
        }
        AssertBytes(before);
    }
    /// <summary>Deletes only this test's freshly owned isolated fixture tree after handles close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
