// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Tests existing host ownership, bound admissions and operation-drained release.
// SPECIAL NOTES        : Controlled cooperative namespace only; no provisioning, durable writer or global fence.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Qualifies cooperative lifetime ownership without provisioning or journal append.</summary>
public sealed class EmbeddedHostLifetimeTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ep3-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "host");
    private string Data => Path.Combine(_area, "data");
    private EmbeddedHostLifetime Open(string? scope = null) => EmbeddedHostLifetime.OpenExisting(Root, "pilot", scope ?? "scope", [Data]);
    private void Seed()
    {
        Directory.CreateDirectory(Root); Directory.CreateDirectory(Data);
        File.WriteAllBytes(Path.Combine(Root, "owner.lock"), []);
        File.WriteAllBytes(Path.Combine(Root, "host.meta"), HostJournalCodec.EncodeMetadata(Guid.NewGuid(), "pilot", "scope"));
        File.WriteAllBytes(Path.Combine(Root, "journal.bin"), []);
    }
    private static EmbeddedHostAdmissionEvidence Evidence(EmbeddedHostLifetime owner) => new(owner.Context, true, true, true, true, true, true);

    /// <summary>Closing retains the OS lease through every operation and child token; cancellation never counts as completion.</summary>
    [Fact]
    public async Task Shutdown_HoldsOwnershipUntilActualDrain()
    {
        Seed(); var before = Bytes(); using var owner = Open(); Assert.False(owner.AdmissionsOpen); Assert.True(owner.WritersMustRemainStopped);
        Assert.Throws<InvalidOperationException>(() => owner.BeginOperation()); owner.OpenAdministrativeAdmissions(Evidence(owner));
        using var operation = owner.BeginOperation(); using var child = owner.BeginOperation(); Assert.Equal(2, owner.ActiveOperations);
        owner.CloseAdmissions(); Assert.Throws<InvalidOperationException>(() => owner.BeginOperation());
        owner.Dispose(); Assert.False(owner.WhenReleased.IsCompleted); Assert.Throws<ObjectDisposedException>(() => owner.BeginOperation());
        Assert.Throws<ObjectDisposedException>(() => owner.OpenAdministrativeAdmissions(Evidence(owner)));
        using var cancelled = new CancellationTokenSource(); cancelled.Cancel();
        await Assert.ThrowsAnyAsync<OperationCanceledException>(() => owner.WhenReleased.WaitAsync(cancelled.Token));
        Assert.Equal(2, owner.ActiveOperations); Assert.Throws<IOException>(() => { using var contender = Open(); });
        operation.Dispose(); operation.Dispose(); Assert.Equal(1, owner.ActiveOperations); Assert.False(owner.WhenReleased.IsCompleted);
        Assert.Throws<IOException>(() => { using var contender = Open(); }); child.Dispose(); await owner.WhenReleased.WaitAsync(TimeSpan.FromSeconds(5));
        Assert.True(owner.IsReleased); Assert.Equal(0, owner.ActiveOperations);
        using var reopened = Open(); Assert.NotEqual(owner.Context.SessionId, reopened.Context.SessionId); Assert.False(reopened.AdmissionsOpen); reopened.Dispose(); AssertBytes(before);
    }

    /// <summary>Admission evidence is scoped to this fresh live owner and must establish every controlled-scope assumption.</summary>
    /// <param name="fault">Invalid or missing fact.</param>
    [Theory]
    [InlineData("null")]
    [InlineData("stale")]
    [InlineData("deployment")]
    [InlineData("scope")]
    [InlineData("journal")]
    [InlineData("session")]
    [InlineData("writer")]
    [InlineData("publisher")]
    [InlineData("prior")]
    [InlineData("reconciled")]
    [InlineData("queue")]
    public void Admission_InvalidEvidence_DoesNotOpen(string fault)
    {
        Seed(); using var owner = Open(); var e = Evidence(owner);
        e = fault switch
        {
            "stale" => e with { Fresh = false },
            "deployment" => e with { Context = e.Context with { Deployment = "other" } },
            "scope" => e with { Context = e.Context with { ResourceScope = "other" } },
            "journal" => e with { Context = e.Context with { JournalId = Guid.NewGuid() } },
            "session" => e with { Context = e.Context with { SessionId = Guid.NewGuid() } },
            "writer" => e with { AllWritersControlled = false },
            "publisher" => e with { AllPublishersControlled = false },
            "prior" => e with { PriorExecutorsExcluded = false },
            "reconciled" => e with { Reconciled = false },
            "queue" => e with { QueueFree = false },
            _ => e
        };
        if (fault == "null") Assert.Throws<ArgumentNullException>(() => owner.OpenAdministrativeAdmissions(null!));
        else Assert.Throws<InvalidOperationException>(() => owner.OpenAdministrativeAdmissions(e));
        Assert.False(owner.AdmissionsOpen); Assert.Equal(0, owner.ActiveOperations);
    }

    /// <summary>Existing-root failures never create/repair roles and release any acquired ownership before return.</summary>
    /// <param name="fault">Malformed or incomplete host namespace.</param>
    [Theory]
    [InlineData("missing-owner")]
    [InlineData("missing-meta")]
    [InlineData("missing-journal")]
    [InlineData("owner-bytes")]
    [InlineData("metadata")]
    [InlineData("metadata-size")]
    [InlineData("journal-tail")]
    [InlineData("scope")]
    [InlineData("extra")]
    [InlineData("directory")]
    public void InvalidExistingRoot_IsUnchangedAndDoesNotLeakLease(string fault)
    {
        Seed(); var valid = Bytes(); var role = fault switch { "missing-owner" => "owner.lock", "missing-meta" => "host.meta", _ => "journal.bin" };
        if (fault.StartsWith("missing-", StringComparison.Ordinal)) File.Delete(Path.Combine(Root, role));
        else if (fault == "owner-bytes") File.WriteAllBytes(Path.Combine(Root, "owner.lock"), [1]);
        else if (fault == "metadata") { var bytes = File.ReadAllBytes(Path.Combine(Root, "host.meta")); bytes[^1] ^= 1; File.WriteAllBytes(Path.Combine(Root, "host.meta"), bytes); }
        else if (fault == "metadata-size") File.WriteAllBytes(Path.Combine(Root, "host.meta"), [1]);
        else if (fault == "journal-tail") File.WriteAllBytes(Path.Combine(Root, "journal.bin"), [1]);
        else if (fault == "extra") File.WriteAllText(Path.Combine(Root, "unexpected"), "retain");
        else if (fault == "directory") { File.Delete(Path.Combine(Root, "journal.bin")); Directory.CreateDirectory(Path.Combine(Root, "journal.bin")); }
        var before = Bytes(); var dirs = Directory.GetDirectories(Root);
        var error = Record.Exception(() => { using var owner = Open(fault == "scope" ? "wrong" : null); }); Assert.True(error is InvalidDataException or IOException, error?.ToString() ?? "Unexpected open success.");
        AssertBytes(before); Assert.Equal(dirs, Directory.GetDirectories(Root));
        if (fault == "extra") File.Delete(Path.Combine(Root, "unexpected"));
        if (fault == "directory") Directory.Delete(Path.Combine(Root, "journal.bin"));
        foreach (var pair in valid) File.WriteAllBytes(Path.Combine(Root, pair.Key), pair.Value);
        using var repairedByTest = Open(); Assert.False(repairedByTest.AdmissionsOpen);
    }

    /// <summary>Root/protected-path overlap rejects before ownership; missing roots are never initialized.</summary>
    /// <param name="fault">Placement/input error.</param>
    [Theory]
    [InlineData("equal")]
    [InlineData("descendant")]
    [InlineData("ancestor")]
    [InlineData("relative")]
    [InlineData("empty-inventory")]
    [InlineData("missing-root")]
    [InlineData("strong-policy")]
    [InlineData("too-long")]
    [InlineData("too-many")]
    [InlineData("file-inventory")]
    public void PlacementOrPolicyError_NeverInitializes(string fault)
    {
        Seed(); var before = Bytes(); var file = Path.Combine(_area, "protected-file"); File.WriteAllText(file, "test");
        var root = fault == "too-long" ? Path.Combine(_area, new string('x', 4097)) : fault == "missing-root" ? Path.Combine(_area, "absent") : fault == "relative" ? "host" : Root;
        string[] inventory = fault switch { "equal" => [Root], "descendant" => [Path.Combine(Root, "data")], "ancestor" => [_area], "empty-inventory" => [], "too-many" => Enumerable.Repeat(Data, 65).ToArray(), "file-inventory" => [file], _ => [Data] };
        Assert.NotNull(Record.Exception(() =>
        {
            using var owner = EmbeddedHostLifetime.OpenExisting(root, "pilot", "scope", inventory,
            fault == "strong-policy" ? DurabilityMode.FileAndDirectoryFlush : DurabilityMode.ProcessCrash);
        }));
        Assert.False(Directory.Exists(Path.Combine(_area, "absent"))); AssertBytes(before); using var valid = Open();
    }

    /// <summary>Registered work is bounded and each token can complete only once even concurrently.</summary>
    [Fact]
    public async Task OperationLimitAndDuplicateDisposal_CannotReleaseEarly()
    {
        Seed(); using var owner = Open(); owner.OpenAdministrativeAdmissions(Evidence(owner)); var tokens = new List<IDisposable>();
        try
        {
            for (var index = 0; index < EmbeddedHostLifetime.MaximumOperations; index++) tokens.Add(owner.BeginOperation());
            Assert.Throws<InvalidOperationException>(() => owner.BeginOperation()); owner.Dispose();
            await Task.WhenAll(Enumerable.Range(0, 16).Select(_ => Task.Run(tokens[0].Dispose))); Assert.Equal(EmbeddedHostLifetime.MaximumOperations - 1, owner.ActiveOperations);
            Assert.False(owner.WhenReleased.IsCompleted); Assert.Throws<IOException>(() => { using var contender = Open(); });
        }
        finally { foreach (var token in tokens) token.Dispose(); }
        await owner.WhenReleased.WaitAsync(TimeSpan.FromSeconds(5)); Assert.True(owner.IsReleased);
    }

    /// <summary>Concurrent shutdown and admission either reject or retain every admitted token until it actually completes.</summary>
    [Fact]
    public async Task AdmissionAndShutdownRace_DrainsEveryAcceptedOperation()
    {
        Seed(); using var owner = Open(); owner.OpenAdministrativeAdmissions(Evidence(owner)); using var start = new ManualResetEventSlim();
        var tokens = new System.Collections.Concurrent.ConcurrentBag<IDisposable>();
        try
        {
            var workers = Enumerable.Range(0, 16).Select(_ => Task.Run(() => { start.Wait(); try { tokens.Add(owner.BeginOperation()); } catch (ObjectDisposedException) { } })).ToArray();
            var shutdown = Task.Run(() => { start.Wait(); owner.Dispose(); }); start.Set(); await Task.WhenAll(workers.Append(shutdown));
            Assert.Equal(tokens.Count, owner.ActiveOperations); Assert.False(owner.AdmissionsOpen);
            if (!tokens.IsEmpty) { Assert.False(owner.WhenReleased.IsCompleted); Assert.Throws<IOException>(() => { using var contender = Open(); }); }
        }
        finally { foreach (var token in tokens) token.Dispose(); }
        await owner.WhenReleased.WaitAsync(TimeSpan.FromSeconds(5)); Assert.True(owner.IsReleased);
    }

    /// <summary>Dot aliases resolve to the same stable lock; opening and reopening never modifies host file bytes.</summary>
    [Fact]
    public void CanonicalAlias_ContendsOnSameOwnerFile()
    {
        Seed(); var before = Bytes(); using var owner = Open();
        Assert.Throws<IOException>(() => { using var alias = EmbeddedHostLifetime.OpenExisting(Path.Combine(Root, "."), "pilot", "scope", [Data]); });
        owner.Dispose(); AssertBytes(before);
    }
    private Dictionary<string, byte[]> Bytes() => Directory.GetFiles(Root).ToDictionary(path => Path.GetFileName(path)!, File.ReadAllBytes);
    private void AssertBytes(Dictionary<string, byte[]> before) { var after = Bytes(); Assert.Equal(before.Keys.Order(), after.Keys.Order()); foreach (var pair in before) Assert.Equal(pair.Value, after[pair.Key]); }
    /// <summary>Deletes this test's isolated tree only after owned lease/token scopes have closed.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
