// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies fixed-sequence backups, sealed integrity, restore and storage failures.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================


using System.Text;
using Bosak.XmlDb.Core;
using Xunit;
using Xunit.Abstractions;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Verifies fixed-sequence backups, sealed integrity, restore and storage failures.</summary>
public sealed class BackupTests(ITestOutputHelper output) : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-backup-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "source");
    private string Backup => Path.Combine(_area, "backup");

    /// <summary>Base-only and committed histories restore identical node identities and values and remain independently writable.</summary>
    /// <param name="commits">Number of scalar changes.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(2)]
    public void Backup_FixedSequence_RestoresFullHistoryWithoutChangingSource(int commits)
    {
        Seed();
        using var database = EmbeddedXmlDatabase.Open(Root);
        using var old = database.BeginRead(cacheBytes: 0);
        for (var i = 0; i < commits; i++) Commit(database, "v" + i);
        if (commits > 0) database.CreateRecoveryAnchor();
        var before = Bytes(Root);
        var identity = database.CreateBackup(Backup);
        Assert.Equal((ulong)commits, identity.CommitSequence);
        AssertBytes(before, Root);
        Assert.Equal("old", old.ReadValue(Target(old)));
        Assert.False(Directory.Exists(Path.Combine(Backup, "data", ".transactions", "readers")));
        Assert.False(Directory.Exists(Path.Combine(Backup, "data", ".transactions", "checkpoints")));
        Assert.False(File.Exists(Path.Combine(Backup, "data", ".transactions", "writer.lock")));
        var destination = Path.Combine(_area, "restored");
        Assert.Equal(identity, EmbeddedXmlDatabase.RestoreBackup(Backup, destination));
        using var restored = EmbeddedXmlDatabase.Open(destination);
        Assert.Equal((ulong)commits, restored.CommitSequence);
        Assert.Equal(0, restored.LastRecovery.GenerationsReplayed);
        using var expected = database.BeginRead();
        using var actual = restored.BeginRead();
        Assert.Equal(expected.NodeCount, actual.NodeCount);
        for (ulong id = 1; id <= (ulong)actual.NodeCount; id++)
        {
            var a = expected.GetNode(id); var b = actual.GetNode(id);
            Assert.Equal(a with { Children = b.Children, Attributes = b.Attributes, Namespaces = b.Namespaces }, b);
            Assert.Equal(a.Children, b.Children); Assert.Equal(a.Attributes, b.Attributes); Assert.Equal(a.Namespaces, b.Namespaces);
            Assert.Equal(expected.ReadValue(id), actual.ReadValue(id));
        }
        Commit(restored, "branch");
        Assert.Equal((ulong)commits, database.CommitSequence);
        Assert.False(database.PlanRetention().CanReclaim);
    }

    /// <summary>Corrupt, missing and extra backup data never produce a restored destination.</summary>
    /// <param name="artifact">Artifact to corrupt or add.</param>
    [Theory]
    [InlineData("inventory.bin")]
    [InlineData("COMPLETE")]
    [InlineData("data/FORMAT")]
    [InlineData("data/.transactions/CONTROL")]
    [InlineData("data/.transactions/CURRENT")]
    [InlineData("data/.transactions/wal/00000000000000000001.wal")]
    [InlineData("data/fragments/1.bin")]
    [InlineData("extra.bin")]
    public void Restore_DamagedArtifact_RefusesBeforePublishing(string artifact)
    {
        Seed();
        using (var database = EmbeddedXmlDatabase.Open(Root)) { Commit(database, "v1"); database.CreateBackup(Backup); }
        File.WriteAllBytes(Path.Combine(Backup, artifact), [0]);
        var destination = Path.Combine(_area, "refused");
        Assert.Throws<InvalidDataException>(() => EmbeddedXmlDatabase.RestoreBackup(Backup, destination));
        Assert.False(Directory.Exists(destination));
        using var source = EmbeddedXmlDatabase.Open(Root);
        Assert.Equal(1UL, source.CommitSequence);
    }

    /// <summary>Overlapping and existing destinations are never changed.</summary>
    [Fact]
    public void Backup_InvalidDestination_RefusesWithoutFaultingOrOverwriting()
    {
        Seed();
        using var database = EmbeddedXmlDatabase.Open(Root);
        Assert.Throws<ArgumentException>(() => database.CreateBackup(Root));
        Assert.Throws<ArgumentException>(() => database.CreateBackup(Path.Combine(Root, "nested")));
        Assert.Throws<ArgumentException>(() => database.CreateBackup(_area));
        Assert.Throws<ArgumentException>(() => database.CreateBackup(Path.Combine(_area, "alias.")));
        Assert.Throws<ArgumentException>(() => database.CreateBackup(Path.Combine(_area, "NUL")));
        Assert.Throws<ArgumentException>(() => database.CreateBackup(Path.Combine(_area, "SHORT~1")));
        Directory.CreateDirectory(Backup);
        File.WriteAllText(Path.Combine(Backup, "owned.txt"), "keep");
        Assert.Throws<IOException>(() => database.CreateBackup(Backup));
        Assert.Equal("keep", File.ReadAllText(Path.Combine(Backup, "owned.txt")));
        Assert.Equal(0UL, database.CommitSequence);
    }

    /// <summary>Unix linked source/destination ancestors cannot escape the declared path boundary.</summary>
    [Fact]
    public void Backup_LinkedAncestor_RefusesWithoutWritingThroughIt()
    {
        if (!OperatingSystem.IsLinux()) return; // Native symlink creation does not require Windows developer privileges.
        Seed();
        var link = Path.Combine(_area, "link");
        Directory.CreateSymbolicLink(link, _area);
        try
        {
            using var database = EmbeddedXmlDatabase.Open(Root);
            Assert.Throws<InvalidDataException>(() => database.CreateBackup(Path.Combine(link, "escape")));
            Assert.False(Directory.Exists(Path.Combine(_area, "escape")));
        }
        finally { Directory.Delete(link); }
    }

    /// <summary>Sealed codec bytes match independent fixtures and reject every truncation.</summary>
    [Fact]
    public void Codec_GoldenInventoryAndCompletion_RejectsTruncationsAndTraversal()
    {
        var inventory = new BackupInventory(new(new Guid("00112233-4455-6677-8899-aabbccddeeff"), 1, 0), new byte[32], new byte[32], [new("FORMAT", 45, new byte[32])]);
        var bytes = BackupCodec.Encode(inventory);
        Assert.Equal(Hex("backup-inventory-v1.hex"), bytes);
        Assert.Equal(Hex("backup-completion-v1.hex"), BackupCodec.Complete(bytes));
        for (var length = 0; length < bytes.Length; length++) Assert.Throws<InvalidDataException>(() => BackupCodec.Decode(bytes[..length]));
        Assert.Throws<InvalidDataException>(() => BackupCodec.Decode(BackupCodec.Encode(inventory with { Files = [new("../FORMAT", 45, new byte[32])] })));
        Assert.Throws<InvalidDataException>(() => BackupCodec.Decode(BackupCodec.Encode(inventory with { Files = [new("FORMAT", 45, new byte[32]), new("format", 45, new byte[32])] })));
    }

    /// <summary>Every persistence boundary and real partial write recovers without changing the source or accepting incomplete artifacts.</summary>
    /// <param name="restore">Whether to inject restore rather than capture.</param>
    /// <param name="fault">Fault timing or partial write.</param>
    [Theory]
    [InlineData(false, "before")]
    [InlineData(false, "after")]
    [InlineData(false, "partial")]
    [InlineData(true, "before")]
    [InlineData(true, "after")]
    [InlineData(true, "partial")]
    public void BackupAndRestore_InjectedFailures_NeverPublishUnverifiedState(bool restore, string fault)
    {
        Seed();
        using (var source = EmbeddedXmlDatabase.Open(Root)) source.CreateBackup(Backup);
        var recording = new FaultingTransactionStorage();
        using (var owner = EmbeddedXmlDatabase.OpenCore(Root, 1, null, recording))
        {
            recording.Arm();
            if (restore) EmbeddedXmlDatabase.RestoreBackupCore(Backup, Path.Combine(_area, "reference"), recording, null);
            else owner.CreateBackup(Path.Combine(_area, "reference"));
        }
        var calls = recording.Calls.Select((call, index) => (call, index)).Where(item => fault == "partial"
            ? item.call.Operation == "WriteFile" && item.call.Moment == "before" : item.call.Moment == fault).ToArray();
        Assert.NotEmpty(calls);
        foreach (var (_, index) in calls)
        {
            var destination = Path.Combine(_area, "attempt-" + index);
            var storage = new FaultingTransactionStorage();
            using (var owner = EmbeddedXmlDatabase.OpenCore(Root, 1, null, storage))
            {
                storage.Arm(index, fault == "partial");
                Assert.Throws<IOException>(() =>
                {
                    if (restore) EmbeddedXmlDatabase.RestoreBackupCore(Backup, destination, storage, null);
                    else owner.CreateBackup(destination);
                });
                Assert.True(storage.Fired);
                if (!restore) Assert.Throws<InvalidOperationException>(() => owner.BeginRead());
            }
            if (Directory.Exists(destination))
            {
                if (restore) { using var valid = EmbeddedXmlDatabase.Open(destination); Assert.Equal(0UL, valid.CommitSequence); }
                else EmbeddedXmlDatabase.RestoreBackup(destination, Path.Combine(_area, "verified-" + index));
            }
            using var reopened = EmbeddedXmlDatabase.Open(Root);
            Assert.Equal(0UL, reopened.CommitSequence);
        }
        output.WriteLine($"{(restore ? "restore" : "backup")}/{fault}: {calls.Length} fault positions verified.");
    }

    /// <summary>Capture serialization excludes later commits while an old uncached snapshot remains valid.</summary>
    [Fact]
    public async Task Backup_ConcurrentCommit_WaitsForFixedSequenceCapture()
    {
        Seed();
        using var captured = new ManualResetEventSlim();
        using var release = new ManualResetEventSlim();
        using var owner = EmbeddedXmlDatabase.OpenCore(Root, 1, stage =>
        {
            if (stage == CommitStage.BackupCopied)
            {
                captured.Set();
                if (!release.Wait(TimeSpan.FromSeconds(20))) throw new TimeoutException("Capture test timed out.");
            }
        });
        using var old = owner.BeginRead(cacheBytes: 0);
        var capture = Task.Run(() => owner.CreateBackup(Backup));
        try
        {
            Assert.True(captured.Wait(TimeSpan.FromSeconds(20)));
            var commit = Task.Run(() => Commit(owner, "later"));
            Assert.NotSame(commit, await Task.WhenAny(commit, Task.Delay(100)));
            release.Set();
            Assert.Equal(0UL, (await capture).CommitSequence);
            await commit;
            Assert.Equal(1UL, owner.CommitSequence);
            Assert.Equal("old", old.ReadValue(Target(old)));
            var restored = Path.Combine(_area, "fixed");
            EmbeddedXmlDatabase.RestoreBackup(Backup, restored);
            using var fixedOwner = EmbeddedXmlDatabase.Open(restored);
            Assert.Equal(0UL, fixedOwner.CommitSequence);
        }
        finally { release.Set(); await capture; }
    }

    /// <summary>Requested directory barriers apply to both capture and restore without fallback.</summary>
    [Fact]
    public void BackupAndRestore_DirectoryBarriers_ReproduceCommittedState()
    {
        Seed();
        var storage = OperatingSystem.IsLinux() ? (ITransactionStorage)new LocalTransactionStorage(DurabilityMode.FileAndDirectoryFlush)
            : new FaultingTransactionStorage(DurabilityMode.FileAndDirectoryFlush);
        using (var owner = EmbeddedXmlDatabase.OpenCore(Root, 1, null, storage))
        {
            Commit(owner, "native"); owner.CreateBackup(Backup);
        }
        var destination = Path.Combine(_area, "native-restored");
        EmbeddedXmlDatabase.RestoreBackupCore(Backup, destination, storage, null);
        using var restored = EmbeddedXmlDatabase.Open(destination);
        Assert.Equal(1UL, restored.CommitSequence);
        using var read = restored.BeginRead();
        Assert.Equal("native", read.ReadValue(Target(read)));
    }

    /// <summary>Even a consistently resealed inventory cannot substitute another head identity.</summary>
    [Fact]
    public void Restore_ResealedWrongHeadOrMissingHistory_FailsFullVerification()
    {
        Seed();
        using (var owner = EmbeddedXmlDatabase.Open(Root)) { Commit(owner, "v1"); owner.CreateBackup(Backup); }
        var path = Path.Combine(Backup, "inventory.bin");
        var inventory = BackupCodec.Decode(File.ReadAllBytes(path));
        var bytes = BackupCodec.Encode(inventory with { HeadHash = new byte[32] });
        File.WriteAllBytes(path, bytes);
        File.WriteAllBytes(Path.Combine(Backup, "COMPLETE"), BackupCodec.Complete(bytes));
        var destination = Path.Combine(_area, "wrong-head");
        Assert.Throws<InvalidDataException>(() => EmbeddedXmlDatabase.RestoreBackup(Backup, destination));
        Assert.False(Directory.Exists(destination));
        File.Delete(Path.Combine(Backup, "data", ".transactions", "wal", "00000000000000000001.wal"));
        Assert.Throws<InvalidDataException>(() => EmbeddedXmlDatabase.RestoreBackup(Backup, Path.Combine(_area, "missing-history")));
    }

    /// <summary>Unknown source extensions are not silently dropped and failures retain the source.</summary>
    [Fact]
    public void Backup_UnknownDependency_FailsClosed()
    {
        Seed();
        using var owner = EmbeddedXmlDatabase.Open(Root);
        File.WriteAllText(Path.Combine(Root, "future-catalog.bin"), "unknown");
        Assert.Throws<InvalidDataException>(() => owner.CreateBackup(Backup));
        Assert.False(Directory.Exists(Backup));
        Assert.Equal("unknown", File.ReadAllText(Path.Combine(Root, "future-catalog.bin")));
    }

    private void Seed()
    {
        Directory.CreateDirectory(_area);
        using var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID><line>unchanged</line></r>"));
        XmlFragmentImporter.Import(input, Root);
    }
    private static ulong Target(ImmutableXmlSnapshot snapshot) => Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id))
        .Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();
    private static void Commit(EmbeddedXmlDatabase database, string value)
    {
        using var read = database.BeginRead(); using var transaction = database.BeginWrite();
        transaction.ReplaceNodeValue(Target(read), value); transaction.Commit();
    }
    private static Dictionary<string, byte[]> Bytes(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories)
        .Where(path => Path.GetFileName(path) != "writer.lock").ToDictionary(path => Path.GetRelativePath(root, path), File.ReadAllBytes);
    private static void AssertBytes(Dictionary<string, byte[]> before, string root)
    {
        var after = Bytes(root); Assert.Equal(before.Keys.Order(), after.Keys.Order());
        foreach (var entry in before) Assert.Equal(entry.Value, after[entry.Key]);
    }
    private static byte[] Hex(string name) => Convert.FromHexString(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "TestData", name)).Trim());
    /// <inheritdoc />
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}

