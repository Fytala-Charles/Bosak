// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Qualifies pure pilot authority classification and retained acceptance obligations.
// SPECIAL NOTES        : No filesystem, callbacks, ownership acquisition, routing or database execution is used.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Collections.Immutable;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Qualifies pure pilot authority classification and retained acceptance obligations.</summary>
public sealed class EmbeddedPilotAuthorityClassifierTests
{
    /// <summary>Exact zero-work assumptions permit only a new stopped workflow for the observed branch.</summary>
    /// <param name="candidate">Whether the candidate is selected.</param>
    /// <param name="epochSource">Whether source has real epoch identity rather than legacy identity.</param>
    [Theory]
    [InlineData(false, false)]
    [InlineData(true, false)]
    [InlineData(false, true)]
    [InlineData(true, true)]
    public void Classify_ExactZeroWork_OnlyNewStoppedWorkflow(bool candidate, bool epochSource)
    {
        var input = Good(candidate, epochSource);
        var before = input;
        var result = EmbeddedPilotAuthorityClassifier.Classify(input);
        Assert.Equal(candidate ? PilotAuthorityDecision.NewCandidateReadinessEligible : PilotAuthorityDecision.NewSourceReadinessEligible, result.Decision);
        Assert.Equal(PilotAuthorityReason.ReadyForNewWorkflow, result.Reason);
        Assert.True(result.WritersMustRemainStopped);
        Assert.Equal(before, input);
    }

    /// <summary>Missing, stale, foreign and contradictory facts never establish authority.</summary>
    /// <param name="fault">Changed input fact.</param>
    /// <param name="reason">Required conservative diagnostic.</param>
    [Theory]
    [InlineData("all-missing", "MissingEvidence")]
    [InlineData("expected-missing", "MissingEvidence")]
    [InlineData("owner-missing", "MissingEvidence")]
    [InlineData("authority-missing", "MissingEvidence")]
    [InlineData("histories-missing", "MissingEvidence")]
    [InlineData("publication-missing", "MissingEvidence")]
    [InlineData("work-missing", "MissingEvidence")]
    [InlineData("owner-context", "ContextMismatch")]
    [InlineData("authority-context", "ContextMismatch")]
    [InlineData("history-context", "ContextMismatch")]
    [InlineData("publication-context", "ContextMismatch")]
    [InlineData("work-context", "ContextMismatch")]
    [InlineData("null-context", "ContextMismatch")]
    [InlineData("stale-owner", "StaleEvidence")]
    [InlineData("stale-authority", "StaleEvidence")]
    [InlineData("stale-histories", "StaleEvidence")]
    [InlineData("stale-publication", "StaleEvidence")]
    [InlineData("stale-work", "StaleEvidence")]
    [InlineData("owners-lost", "OwnershipUnknown")]
    [InlineData("exclusion-unknown", "OwnershipUnknown")]
    [InlineData("ingress-open", "OwnershipUnknown")]
    [InlineData("executor-running", "OwnershipUnknown")]
    [InlineData("unvalidated-history", "AuthorityUnconfirmed")]
    [InlineData("rollback-unknown", "AuthorityUnconfirmed")]
    [InlineData("baseline-unknown", "AuthorityUnconfirmed")]
    [InlineData("selection-ack-lost", "SelectionUnconfirmed")]
    [InlineData("unverified-roots", "HistoriesUnconfirmed")]
    [InlineData("source-changed", "HistoriesUnconfirmed")]
    [InlineData("candidate-changed", "HistoriesUnconfirmed")]
    [InlineData("artifact-only", "PublicationUnconfirmed")]
    [InlineData("admin-conflict", "PublicationUnconfirmed")]
    [InlineData("work-incomplete", "AccountingUnknown")]
    [InlineData("prior-work-unknown", "AccountingUnknown")]
    [InlineData("source-count-unknown", "AccountingUnknown")]
    [InlineData("candidate-count-unknown", "AccountingUnknown")]
    [InlineData("records-missing", "AccountingUnknown")]
    [InlineData("source-summary-conflict", "InvalidWorkEvidence")]
    [InlineData("candidate-summary-conflict", "InvalidWorkEvidence")]
    [InlineData("source-count-overflow", "CapacityExhausted")]
    [InlineData("candidate-count-overflow", "CapacityExhausted")]
    [InlineData("record-bound", "CapacityExhausted")]
    public void Classify_UncertainEvidence_ReconciliationRequired(string fault, string reason)
    {
        var e = Good();
        var changed = e.Expected! with { OwnerSession = Guid.NewGuid() };
        PilotAuthorityEvidence? input = fault switch
        {
            "all-missing" => null,
            "expected-missing" => e with { Expected = null },
            "owner-missing" => e with { Ownership = null },
            "authority-missing" => e with { Authority = null },
            "histories-missing" => e with { Histories = null },
            "publication-missing" => e with { Publication = null },
            "work-missing" => e with { Work = null },
            "owner-context" => e with { Ownership = e.Ownership! with { Context = changed } },
            "authority-context" => e with { Authority = e.Authority! with { Context = changed } },
            "history-context" => e with { Histories = e.Histories! with { Context = changed } },
            "publication-context" => e with { Publication = e.Publication! with { Context = changed } },
            "work-context" => e with { Work = e.Work! with { Context = changed } },
            "null-context" => e with { Work = e.Work! with { Context = null! } },
            "stale-owner" => e with { Ownership = e.Ownership! with { Fresh = false } },
            "stale-authority" => e with { Authority = e.Authority! with { Fresh = false } },
            "stale-histories" => e with { Histories = e.Histories! with { Fresh = false } },
            "stale-publication" => e with { Publication = e.Publication! with { Fresh = false } },
            "stale-work" => e with { Work = e.Work! with { Fresh = false } },
            "owners-lost" => e with { Ownership = e.Ownership! with { OwnersHeld = false } },
            "exclusion-unknown" => e with { Ownership = e.Ownership! with { AllWritersAndPublishersExcluded = false } },
            "ingress-open" => e with { Ownership = e.Ownership! with { IngressClosed = false } },
            "executor-running" => e with { Ownership = e.Ownership! with { ActualOperationsDrained = false } },
            "unvalidated-history" => e with { Authority = e.Authority! with { CompleteHistoryValidated = false } },
            "rollback-unknown" => e with { Authority = e.Authority! with { IndependentFreshnessEstablished = false } },
            "baseline-unknown" => e with { Authority = e.Authority! with { EnrollmentBaselineReconciled = false } },
            "selection-ack-lost" => e with { Authority = e.Authority! with { SelectionAcknowledgmentKnown = false } },
            "unverified-roots" => e with { Histories = e.Histories! with { IndependentlyVerified = false } },
            "source-changed" => e with { Histories = e.Histories! with { Source = e.Expected!.Source with { InitialHistoryDigest = Digest('e') } } },
            "candidate-changed" => e with { Histories = e.Histories! with { Candidate = e.Expected!.Candidate with { Epoch = new(Guid.NewGuid(), Guid.NewGuid(), 7) } } },
            "artifact-only" => e with { Publication = e.Publication! with { ExactAttemptMatched = false } },
            "admin-conflict" => e with { Publication = e.Publication! with { AdministrativeHistoryAgrees = false } },
            "work-incomplete" => e with { Work = e.Work! with { Complete = false } },
            "prior-work-unknown" => e with { Work = e.Work! with { PriorWorkReconciled = false } },
            "source-count-unknown" => e with { Work = e.Work! with { SourceAccepted = null } },
            "candidate-count-unknown" => e with { Work = e.Work! with { CandidateAccepted = null } },
            "records-missing" => e with { Work = e.Work! with { Acceptances = default } },
            "source-summary-conflict" => e with { Work = e.Work! with { SourceAccepted = 1 } },
            "candidate-summary-conflict" => e with { Work = e.Work! with { CandidateAccepted = 1 } },
            "source-count-overflow" => e with { Work = e.Work! with { SourceAccepted = ulong.MaxValue } },
            "candidate-count-overflow" => e with { Work = e.Work! with { CandidateAccepted = ulong.MaxValue } },
            "record-bound" => e with { Work = e.Work! with { Acceptances = Enumerable.Repeat<PilotWorkAcceptance>(null!, 1025).ToImmutableArray() } },
            _ => throw new ArgumentOutOfRangeException(nameof(fault))
        };
        Reject(input, reason);
    }

    /// <summary>Malformed expected identities and exhausted counters fail closed rather than throwing or wrapping.</summary>
    /// <param name="fault">Context field to invalidate.</param>
    /// <param name="reason">Expected diagnostic.</param>
    [Theory]
    [InlineData("authority", "InvalidContext")]
    [InlineData("admin", "InvalidContext")]
    [InlineData("owner", "InvalidContext")]
    [InlineData("baseline", "InvalidContext")]
    [InlineData("deployment", "InvalidContext")]
    [InlineData("scope", "InvalidContext")]
    [InlineData("nul-key", "InvalidContext")]
    [InlineData("long-key", "InvalidContext")]
    [InlineData("zero-sequence", "InvalidContext")]
    [InlineData("zero-revision", "InvalidContext")]
    [InlineData("future-revision", "InvalidContext")]
    [InlineData("head-digest", "InvalidContext")]
    [InlineData("branch", "InvalidContext")]
    [InlineData("null-source", "InvalidContext")]
    [InlineData("null-candidate", "InvalidContext")]
    [InlineData("source-kind", "InvalidContext")]
    [InlineData("legacy-fake-epoch", "InvalidContext")]
    [InlineData("candidate-legacy", "InvalidContext")]
    [InlineData("candidate-epoch-missing", "InvalidContext")]
    [InlineData("candidate-epoch-empty", "InvalidContext")]
    [InlineData("document-mismatch", "InvalidContext")]
    [InlineData("epoch-document-mismatch", "InvalidContext")]
    [InlineData("same-root", "InvalidContext")]
    [InlineData("same-admission", "InvalidContext")]
    [InlineData("source-hash", "InvalidContext")]
    [InlineData("source-head-bound", "InvalidContext")]
    [InlineData("different-heads", "InvalidContext")]
    [InlineData("publication-missing", "InvalidContext")]
    [InlineData("attempt-empty", "InvalidContext")]
    [InlineData("artifact-hash", "InvalidContext")]
    [InlineData("admin-head-empty", "InvalidContext")]
    [InlineData("admin-sequence-zero", "InvalidContext")]
    [InlineData("sequence-overflow", "CapacityExhausted")]
    [InlineData("revision-overflow", "CapacityExhausted")]
    [InlineData("admin-sequence-overflow", "CapacityExhausted")]
    public void Classify_MalformedContext_ReconciliationRequired(string fault, string reason)
    {
        var e = Good(); var c = e.Expected!;
        c = fault switch
        {
            "authority" => c with { AuthorityId = Guid.Empty },
            "admin" => c with { AdministrativeJournalId = Guid.Empty },
            "owner" => c with { OwnerSession = Guid.Empty },
            "baseline" => c with { BaselineId = Guid.Empty },
            "deployment" => c with { Deployment = null! },
            "scope" => c with { ResourceScope = " " },
            "nul-key" => c with { ResourceScope = "a\0b" },
            "long-key" => c with { Deployment = new string('x', 4097) },
            "zero-sequence" => c with { Sequence = 0 },
            "zero-revision" => c with { SelectionRevision = 0 },
            "future-revision" => c with { SelectionRevision = c.Sequence + 1 },
            "head-digest" => c with { HeadDigest = Digest('G') },
            "branch" => c with { Selected = (PilotBranch)99 },
            "null-source" => c with { Source = null! },
            "null-candidate" => c with { Candidate = null! },
            "source-kind" => c with { Source = c.Source with { Kind = (PilotRootKind)99 } },
            "legacy-fake-epoch" => c with { Source = c.Source with { Epoch = c.Candidate.Epoch } },
            "candidate-legacy" => c with { Candidate = c.Candidate with { Kind = PilotRootKind.Legacy, Epoch = null } },
            "candidate-epoch-missing" => c with { Candidate = c.Candidate with { Epoch = null } },
            "candidate-epoch-empty" => c with { Candidate = c.Candidate with { Epoch = new(Guid.Empty, Guid.NewGuid(), 7) } },
            "document-mismatch" => c with { Source = c.Source with { DocumentId = 8 } },
            "epoch-document-mismatch" => c with { Candidate = c.Candidate with { Epoch = new(Guid.NewGuid(), Guid.NewGuid(), 8) } },
            "same-root" => c with { Candidate = c.Candidate with { RootKey = c.Source.RootKey.ToUpperInvariant() } },
            "same-admission" => c with { Candidate = c.Candidate with { AdmissionKey = c.Source.AdmissionKey.ToUpperInvariant() } },
            "source-hash" => c with { Source = c.Source with { InitialHistoryDigest = "" } },
            "different-heads" => c with { Candidate = c.Candidate with { InitialSequence = 2 } },
            "source-head-bound" => c with { Source = c.Source with { InitialSequence = 10_001 } },
            "publication-missing" => c with { Publication = null! },
            "attempt-empty" => c with { Publication = c.Publication with { AttemptId = Guid.Empty } },
            "artifact-hash" => c with { Publication = c.Publication with { ArtifactDigest = null! } },
            "admin-head-empty" => c with { Publication = c.Publication with { AdministrativeHeadDigest = "" } },
            "admin-sequence-zero" => c with { Publication = c.Publication with { AdministrativeSequence = 0 } },
            "sequence-overflow" => c with { Sequence = ulong.MaxValue },
            "revision-overflow" => c with { Sequence = ulong.MaxValue, SelectionRevision = ulong.MaxValue },
            "admin-sequence-overflow" => c with { Publication = c.Publication with { AdministrativeSequence = ulong.MaxValue } },
            _ => throw new ArgumentOutOfRangeException(nameof(fault))
        };
        Reject(Rebind(e, c), reason);
    }

    /// <summary>Completion and confirmed no-effect results cannot erase historical acceptance on either branch.</summary>
    /// <param name="branch">Branch that accepted work.</param>
    /// <param name="outcome">Retained actual or unresolved outcome.</param>
    [Theory]
    [InlineData(0, 0)]
    [InlineData(0, 1)]
    [InlineData(0, 2)]
    [InlineData(1, 0)]
    [InlineData(1, 1)]
    [InlineData(1, 2)]
    public void Classify_AcceptedWork_ObligationSurvivesCompletion(int branch, int outcome)
    {
        var e = Good(); var work = Acceptance(e, (PilotBranch)branch) with { Outcome = (PilotWorkOutcome)outcome };
        Reject(WithWork(e, [work]), outcome == 0 ? "WorkOutcomeUnknown" : "WorkAccepted");
    }

    /// <summary>Work records must preserve exact baseline, branch, target, revision and request identity.</summary>
    /// <param name="fault">Work corruption or conflicting summary.</param>
    [Theory]
    [InlineData("null")]
    [InlineData("empty-id")]
    [InlineData("baseline")]
    [InlineData("branch")]
    [InlineData("target")]
    [InlineData("revision-zero")]
    [InlineData("revision-future")]
    [InlineData("wrong-current-selection")]
    [InlineData("intent")]
    [InlineData("outcome")]
    [InlineData("counter-reset")]
    public void Classify_InvalidWork_ReconciliationRequired(string fault)
    {
        var e = Good(); var record = Acceptance(e, PilotBranch.Source);
        record = fault switch
        {
            "null" => null!,
            "empty-id" => record with { WorkId = Guid.Empty },
            "baseline" => record with { BaselineId = Guid.NewGuid() },
            "branch" => record with { Branch = (PilotBranch)99 },
            "target" => record with { Target = e.Expected!.Candidate },
            "revision-zero" => record with { SelectionRevision = 0 },
            "revision-future" => record with { SelectionRevision = e.Expected!.SelectionRevision + 1 },
            "wrong-current-selection" => record with { Branch = PilotBranch.Candidate, Target = e.Expected!.Candidate, SelectionRevision = e.Expected.SelectionRevision },
            "intent" => record with { IntentDigest = "bad" },
            "outcome" => record with { Outcome = (PilotWorkOutcome)99 },
            "counter-reset" => record,
            _ => throw new ArgumentOutOfRangeException(nameof(fault))
        };
        var input = WithWork(e, [record]);
        if (fault == "counter-reset") input = input with { Work = input.Work! with { SourceAccepted = 0 } };
        Reject(input, "InvalidWorkEvidence");
    }

    /// <summary>Identical duplicate work IDs remain invalid even when counts and outcomes agree.</summary>
    [Fact]
    public void Classify_DuplicateWorkIds_ReconciliationRequired()
    {
        var e = Good(); var record = Acceptance(e, PilotBranch.Source);
        Reject(WithWork(e, [record, record]), "DuplicateWork");
    }

    /// <summary>Epoch source and destination identities cannot reuse either store or epoch identity.</summary>
    /// <param name="store">Whether to duplicate the store ID instead of epoch ID.</param>
    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public void Classify_ReusedEpochIdentity_ReconciliationRequired(bool store)
    {
        var e = Good(epochSource: true); var c = e.Expected!;
        var epoch = c.Candidate.Epoch!;
        c = c with { Candidate = c.Candidate with { Epoch = store ? epoch with { StoreId = c.Source.Epoch!.StoreId } : epoch with { EpochId = c.Source.Epoch!.EpochId } } };
        Reject(Rebind(e, c), "InvalidContext");
    }

    /// <summary>Exact authority bindings cannot be replaced by equally fresh observations of another position.</summary>
    /// <param name="field">Binding changed only in observed evidence.</param>
    [Theory]
    [InlineData("authority")]
    [InlineData("admin")]
    [InlineData("deployment")]
    [InlineData("scope")]
    [InlineData("baseline")]
    [InlineData("sequence")]
    [InlineData("head")]
    [InlineData("revision")]
    [InlineData("selection")]
    [InlineData("attempt")]
    [InlineData("artifact")]
    [InlineData("admin-sequence")]
    [InlineData("admin-head")]
    [InlineData("root")]
    [InlineData("admission")]
    public void Classify_ChangedBinding_ReconciliationRequired(string field)
    {
        var e = Good(); var c = e.Expected!;
        c = field switch
        {
            "authority" => c with { AuthorityId = Guid.NewGuid() },
            "admin" => c with { AdministrativeJournalId = Guid.NewGuid() },
            "deployment" => c with { Deployment = "other" },
            "scope" => c with { ResourceScope = "other" },
            "baseline" => c with { BaselineId = Guid.NewGuid() },
            "sequence" => c with { Sequence = c.Sequence + 1 },
            "head" => c with { HeadDigest = Digest('a') },
            "revision" => c with { SelectionRevision = c.SelectionRevision + 1 },
            "selection" => c with { Selected = PilotBranch.Candidate },
            "attempt" => c with { Publication = c.Publication with { AttemptId = Guid.NewGuid() } },
            "artifact" => c with { Publication = c.Publication with { ArtifactDigest = Digest('a') } },
            "admin-sequence" => c with { Publication = c.Publication with { AdministrativeSequence = 5 } },
            "admin-head" => c with { Publication = c.Publication with { AdministrativeHeadDigest = Digest('a') } },
            "root" => c with { Source = c.Source with { RootKey = "different" } },
            "admission" => c with { Candidate = c.Candidate with { AdmissionKey = "different" } },
            _ => throw new ArgumentOutOfRangeException(nameof(field))
        };
        Reject(e with { Publication = e.Publication! with { Context = c } }, "ContextMismatch");
    }

    /// <summary>The model bound retains every accepted obligation without truncation or overflow.</summary>
    [Fact]
    public void Classify_MaximumRetainedWork_StillAccepted()
    {
        var e = Good();
        var records = Enumerable.Range(0, EmbeddedPilotAuthorityClassifier.MaximumWorkRecords)
            .Select(_ => Acceptance(e, PilotBranch.Source)).ToImmutableArray();
        Reject(WithWork(e, records), "WorkAccepted");
        Assert.Equal(EmbeddedPilotAuthorityClassifier.MaximumWorkRecords, records.Length);
    }

    /// <summary>Work ID uniqueness covers both branches rather than only per-branch counters.</summary>
    [Fact]
    public void Classify_DuplicateAcrossBranches_ReconciliationRequired()
    {
        var e = Good(); var source = Acceptance(e, PilotBranch.Source);
        var candidate = Acceptance(e, PilotBranch.Candidate) with { WorkId = source.WorkId };
        Reject(WithWork(e, [source, candidate]), "DuplicateWork");
    }

    /// <summary>Both zero and the supported historical bound can form supplied baseline evidence.</summary>
    /// <param name="sequence">Source and candidate initial sequence.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(10000)]
    public void Classify_SupportedHistoryBoundary_StoppedWorkflow(int sequence)
    {
        var e = Good(); var c = e.Expected!;
        c = c with { Source = c.Source with { InitialSequence = (ulong)sequence }, Candidate = c.Candidate with { InitialSequence = (ulong)sequence } };
        e = Rebind(e, c) with { Histories = e.Histories! with { Context = c, Source = c.Source, Candidate = c.Candidate } };
        var result = EmbeddedPilotAuthorityClassifier.Classify(e);
        Assert.Equal(PilotAuthorityDecision.NewSourceReadinessEligible, result.Decision);
        Assert.True(result.WritersMustRemainStopped);
    }
    private static void Reject(PilotAuthorityEvidence? input, string reason)
    {
        var result = EmbeddedPilotAuthorityClassifier.Classify(input);
        Assert.Equal(PilotAuthorityDecision.ReconciliationRequired, result.Decision);
        Assert.Equal(reason, result.Reason.ToString());
        Assert.True(result.WritersMustRemainStopped);
    }

    private static PilotAuthorityEvidence Rebind(PilotAuthorityEvidence e, PilotAuthorityContext c) => e with
    {
        Expected = c,
        Ownership = e.Ownership! with { Context = c },
        Authority = e.Authority! with { Context = c },
        Histories = e.Histories! with { Context = c },
        Publication = e.Publication! with { Context = c },
        Work = e.Work! with { Context = c }
    };
    private static PilotAuthorityEvidence WithWork(PilotAuthorityEvidence e, ImmutableArray<PilotWorkAcceptance> records) => e with
    {
        Work = e.Work! with
        {
            SourceAccepted = (ulong)records.Count(r => r is null || r.Branch == PilotBranch.Source),
            CandidateAccepted = (ulong)records.Count(r => r is not null && r.Branch == PilotBranch.Candidate),
            Acceptances = records
        }
    };
    private static PilotWorkAcceptance Acceptance(PilotAuthorityEvidence e, PilotBranch branch) => new(Guid.NewGuid(), e.Expected!.BaselineId,
        branch, branch == PilotBranch.Source ? e.Expected.Source : e.Expected.Candidate, 1, Digest('e'), PilotWorkOutcome.Committed);
    private static string Digest(char value) => new(value, 64);
    private static PilotAuthorityEvidence Good(bool candidate = false, bool epochSource = false)
    {
        var source = new PilotRootBinding(epochSource ? PilotRootKind.ScalarEpoch : PilotRootKind.Legacy, "source-root", "source-admission", 7,
            epochSource ? new(Guid.NewGuid(), Guid.NewGuid(), 7) : null, 3, Digest('a'));
        var destination = new PilotRootBinding(PilotRootKind.ScalarEpoch, "candidate-root", "candidate-admission", 7,
            new(Guid.NewGuid(), Guid.NewGuid(), 7), 3, Digest('b'));
        var c = new PilotAuthorityContext(Guid.NewGuid(), Guid.NewGuid(), "deployment", "resource", Guid.NewGuid(), Guid.NewGuid(), source,
            destination, new(Guid.NewGuid(), Digest('c'), 4, Digest('d')), 10, Digest('f'), 3, candidate ? PilotBranch.Candidate : PilotBranch.Source);
        return new(c, new(c, true, true, true, true, true), new(c, true, true, true, true, true), new(c, true, true, source, destination),
            new(c, true, true, true), new(c, true, true, true, 0, 0, []));
    }
}
