// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies epoch recovery classification and preservation of rejected publication evidence.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Security.Cryptography;
using System.Text;
using Bosak.XmlDb.Core;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Verifies adversarial recovery classification before persistent mutation.</summary>
public sealed class EpochRecoveryMatrixTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-et7-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "epoch");
    private string Foreign => Path.Combine(_area, "foreign");
    private string Source => Path.Combine(_area, "source");

    /// <summary>Gets corruptions with and without an earlier missing generation requiring redo.</summary>
    public static IEnumerable<object[]> Corruptions => new[]
    {
        "foreign-BASE", "foreign-CONTROL", "foreign-WAL", "foreign-CURRENT", "foreign-GENERATION", "foreign-reader",
        "role-WAL", "role-GENERATION", "role-CURRENT", "role-reader",
        "wal-base", "wal-format", "wal-sequence", "wal-predecessor", "wal-manifest-predecessor", "duplicate-id",
        "gap", "missing-final-wal", "torn-final-wal", "reader-ahead", "current-manifest", "current-wal", "current-ahead",
        "generation-manifest", "generation-wal", "generation-predecessor", "generation-sequence",
        "generation-directory", "generation-fragment", "unknown-wal", "unknown-generation", "unknown-reader", "unknown-authority",
        "foreign-torn-wal", "unsupported-torn-wal", "trailing-wal", "element-operation", "empty-text-operation",
        "resealed-wrong-value", "resealed-wrong-uri", "unwitnessed-torn-role", "unwitnessed-torn-sequence", "unwitnessed-torn-binding"
    }.SelectMany(scenario => new[] { new object[] { scenario, false }, new object[] { scenario, true } });

    /// <summary>Rejected histories preserve all bytes, paths and identities without starting redo or tail cleanup.</summary>
    /// <param name="scenario">Invalid authority or publication combination.</param>
    /// <param name="missingPredecessor">Whether an earlier generation also requires recovery.</param>
    [Theory]
    [MemberData(nameof(Corruptions))]
    public void Open_AdversarialHistory_RejectsBeforeRecoveryWritesAndPreservesEvidence(string scenario, bool missingPredecessor)
    {
        Seed(); Corrupt(scenario);
        if (missingPredecessor) Directory.Delete(EpochScalarHistory.Generation(Root, 1), true);
        var before = Bytes(Root); var directories = Directories(Root);
        var identity = EpochAdmission.ReadIdentity(Root, EpochProfile.ScalarWal);
        for (var repeat = 0; repeat < 2; repeat++)
        {
            var storage = new FaultingTransactionStorage(); storage.Arm();
            var error = Record.Exception(() => EpochScalarCoordinator.Open(Root, storage));
            Assert.True(error is InvalidDataException or NotSupportedException, error?.ToString() ?? "Unexpected successful recovery.");
            Assert.DoesNotContain(storage.Calls, call => call.Operation is "CreateFile" or "WriteFile" or "CreateDirectory" or "MoveFile" or "MoveDirectory" or "DeleteFile" or "DeleteDirectory");
            AssertBytes(before, Root); Assert.Equal(directories, Directories(Root));
            using var exclusive = EpochAdmission.Acquire(Root, identity, true, EpochProfile.ScalarWal);
        }
    }

    /// <summary>Missing or stale valid CURRENT recovers all absent generations without touching retained authority bytes.</summary>
    /// <param name="pointer">Pointer state.</param>
    /// <param name="keepLater">Whether a later published generation is retained as a checked witness.</param>
    [Theory]
    [InlineData("absent", false)]
    [InlineData("absent", true)]
    [InlineData("prefix", false)]
    [InlineData("prefix", true)]
    public void Open_ValidMultiGenerationRedo_SelectsLatestAndPreservesIdentities(string pointer, bool keepLater)
    {
        Seed(); var expected = Bytes(Root); var binding = Binding(Root);
        var record = Wal(Root, 1);
        if (pointer == "absent") File.Delete(Tx("CURRENT"));
        else File.WriteAllBytes(Tx("CURRENT"), EpochAuthorityCodec.EncodeCurrent(new(binding, 1, record.ManifestHash, SHA256.HashData(File.ReadAllBytes(WalPath(Root, 1))))));
        for (ulong sequence = 1; sequence <= (keepLater ? 2UL : 3UL); sequence++) Directory.Delete(EpochScalarHistory.Generation(Root, sequence), true);
        var temporary = Tx("current-" + Guid.NewGuid().ToString("N") + ".tmp"); File.WriteAllBytes(temporary, [0]);
        var stage = Path.Combine(Tx("staging"), Guid.NewGuid().ToString("N")); Directory.CreateDirectory(stage); File.WriteAllText(Path.Combine(stage, "abandoned"), "not authority");
        var readerTemp = EpochGenerationReader.PathFor(Root, 3) + ".tmp-" + Guid.NewGuid().ToString("N"); File.WriteAllBytes(readerTemp, [0]);
        for (var repeat = 0; repeat < 2; repeat++)
        {
            using var owner = EpochScalarCoordinator.Open(Root, NativeStorage()); using var read = owner.BeginRead(0);
            Assert.Equal(3UL, read.CommitSequence); Assert.Equal("three", read.ReadValue(Target(read))); Assert.Equal("line-two", read.ReadValue(Line(read)));
            read.Dispose(); owner.Dispose();
            foreach (var item in expected.Where(item => item.Key != Path.Combine(".transactions", "CURRENT")))
                Assert.Equal(item.Value, File.ReadAllBytes(Path.Combine(Root, item.Key)));
            Assert.Equal(new byte[] { 0 }, File.ReadAllBytes(temporary)); Assert.Equal(new byte[] { 0 }, File.ReadAllBytes(readerTemp));
            Assert.Equal("not authority", File.ReadAllText(Path.Combine(stage, "abandoned")));
        }
    }

    private void Corrupt(string scenario)
    {
        var binding = Binding(Root); var wal = Wal(Root, 3); var walPath = WalPath(Root, 3);
        var generationPath = Path.Combine(EpochScalarHistory.Generation(Root, 3), "GENERATION");
        var generation = EpochAuthorityCodec.DecodeGeneration(File.ReadAllBytes(generationPath), binding);
        var current = EpochAuthorityCodec.DecodeCurrent(File.ReadAllBytes(Tx("CURRENT")), binding);
        if (scenario.StartsWith("foreign-", StringComparison.Ordinal) && scenario != "foreign-torn-wal")
        {
            var role = scenario[8..];
            var relative = role switch
            {
                "BASE" => "BASE",
                "CONTROL" => Path.Combine(".transactions", "CONTROL"),
                "CURRENT" => Path.Combine(".transactions", "CURRENT"),
                "WAL" => Path.GetRelativePath(Root, walPath),
                "GENERATION" => Path.GetRelativePath(Root, generationPath),
                "reader" => Path.GetRelativePath(Root, EpochGenerationReader.PathFor(Root, 3)),
                _ => throw new InvalidOperationException()
            };
            File.WriteAllBytes(Path.Combine(Root, relative), File.ReadAllBytes(Path.Combine(Foreign, relative))); return;
        }
        switch (scenario)
        {
            case "role-WAL": File.WriteAllBytes(walPath, File.ReadAllBytes(generationPath)); break;
            case "role-GENERATION": File.WriteAllBytes(generationPath, File.ReadAllBytes(walPath)); break;
            case "role-CURRENT": File.WriteAllBytes(Tx("CURRENT"), File.ReadAllBytes(EpochGenerationReader.PathFor(Root, 3))); break;
            case "role-reader": File.WriteAllBytes(EpochGenerationReader.PathFor(Root, 3), File.ReadAllBytes(Tx("CURRENT"))); break;
            case "wal-base": Write(wal with { Binding = binding with { BaseHash = new byte[32] } }); break;
            case "wal-format": Write(wal with { Binding = binding with { FormatHash = new byte[32] } }); break;
            case "wal-sequence": Write(wal with { Sequence = 4 }); break;
            case "wal-predecessor": Write(wal with { PreviousWalHash = new byte[32] }); break;
            case "wal-manifest-predecessor": Write(wal with { PreviousManifestHash = new byte[32] }); break;
            case "duplicate-id": Write(wal with { TransactionId = Wal(Root, 1).TransactionId }); break;
            case "gap": File.Delete(WalPath(Root, 2)); break;
            case "missing-final-wal": File.Delete(walPath); break;
            case "torn-final-wal": File.WriteAllBytes(walPath, File.ReadAllBytes(walPath)[..150]); break;
            case "reader-ahead": File.WriteAllBytes(EpochGenerationReader.PathFor(Root, 4), EpochAuthorityCodec.EncodeReader(new(binding, 4, wal.ManifestHash))); break;
            case "current-manifest": File.WriteAllBytes(Tx("CURRENT"), EpochAuthorityCodec.EncodeCurrent(current with { ManifestHash = new byte[32] })); break;
            case "current-wal": File.WriteAllBytes(Tx("CURRENT"), EpochAuthorityCodec.EncodeCurrent(current with { WalHash = Enumerable.Repeat((byte)1, 32).ToArray() })); break;
            case "current-ahead": File.WriteAllBytes(Tx("CURRENT"), EpochAuthorityCodec.EncodeCurrent(current with { Sequence = 4 })); break;
            case "generation-manifest": WriteGeneration(generation with { ManifestHash = new byte[32] }); break;
            case "generation-wal": WriteGeneration(generation with { WalHash = Enumerable.Repeat((byte)1, 32).ToArray() }); break;
            case "generation-predecessor": WriteGeneration(generation with { PreviousManifestHash = new byte[32] }); break;
            case "generation-sequence": WriteGeneration(generation with { Sequence = 4 }); break;
            case "generation-directory": File.WriteAllBytes(Path.Combine(EpochScalarHistory.Generation(Root, 3), "documents", "1", "directory.bin"), [0]); break;
            case "generation-fragment": File.WriteAllBytes(Path.Combine(EpochScalarHistory.Generation(Root, 3), "fragments", "1.bin"), [0]); break;
            case "unknown-wal": File.WriteAllBytes(Path.Combine(Tx("wal"), "future.wal"), [0]); break;
            case "unknown-generation": Directory.CreateDirectory(Path.Combine(Tx("generations"), "future")); break;
            case "unknown-reader": File.WriteAllBytes(Path.Combine(Tx("readers"), "future.lease"), [0]); break;
            case "unknown-authority": File.WriteAllBytes(Tx("future"), [0]); break;
            case "foreign-torn-wal": File.WriteAllBytes(walPath, File.ReadAllBytes(WalPath(Foreign, 3))[..150]); break;
            case "unsupported-torn-wal":
                var prefix = File.ReadAllBytes(walPath)[..150]; prefix[6] = 1; File.WriteAllBytes(walPath, prefix); break;
            case "trailing-wal": File.WriteAllBytes(walPath, File.ReadAllBytes(walPath).Concat(new byte[] { 0 }).ToArray()); break;
            case "element-operation":
                using (var snapshot = ImmutableXmlSnapshot.Open(Source)) Write(wal with { NodeId = snapshot.GetNode(Target(snapshot)).ParentId }); break;
            case "empty-text-operation": Write(wal with { Value = "" }); break;
            case "unwitnessed-torn-role":
            case "unwitnessed-torn-sequence":
            case "unwitnessed-torn-binding":
                Directory.Delete(EpochScalarHistory.Generation(Root, 3), true); File.Delete(EpochGenerationReader.PathFor(Root, 3));
                var second = Wal(Root, 2);
                File.WriteAllBytes(Tx("CURRENT"), EpochAuthorityCodec.EncodeCurrent(new(binding, 2, second.ManifestHash, SHA256.HashData(File.ReadAllBytes(WalPath(Root, 2))))));
                var torn = File.ReadAllBytes(walPath)[..150];
                torn[scenario == "unwitnessed-torn-role" ? 116 : scenario == "unwitnessed-torn-sequence" ? 117 : 12] ^= 1;
                File.WriteAllBytes(walPath, torn); break;
            case "resealed-wrong-value": Reseal(wal with { Value = "unpublished" }); break;
            case "resealed-wrong-uri":
                var manifestPath = Path.Combine(EpochScalarHistory.Generation(Root, 3), "documents", "1", "manifest.bin");
                var manifest = StoreCodec.ReadManifest(File.ReadAllBytes(manifestPath));
                var bytes = StoreCodec.WriteManifest(manifest with { DocumentUri = "https://foreign.test/wrong" }); File.WriteAllBytes(manifestPath, bytes);
                Reseal(wal with { ManifestHash = SHA256.HashData(bytes) }); break;
            default: throw new InvalidOperationException("Unknown matrix scenario.");
        }
        void Write(EpochWalRecord record) => File.WriteAllBytes(walPath, EpochAuthorityCodec.EncodeWal(record));
        void WriteGeneration(EpochGenerationRecord record) => File.WriteAllBytes(generationPath, EpochAuthorityCodec.EncodeGeneration(record));
        void Reseal(EpochWalRecord record)
        {
            Write(record); var digest = SHA256.HashData(File.ReadAllBytes(walPath));
            WriteGeneration(generation with { ManifestHash = record.ManifestHash, WalHash = digest });
            File.WriteAllBytes(Tx("CURRENT"), EpochAuthorityCodec.EncodeCurrent(current with { ManifestHash = record.ManifestHash, WalHash = digest }));
        }
    }

    private void Seed()
    {
        Directory.CreateDirectory(_area); using var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID><line>line</line></r>"));
        XmlFragmentImporter.Import(input, Source, documentUri: "https://example.test/et7.xml");
        foreach (var root in new[] { Root, Foreign })
        {
            EpochEmptyRoot.CreateFixture(Source, root, 1, new LocalTransactionStorage()); using var owner = EpochScalarCoordinator.Open(root); using var read = owner.BeginRead();
            for (var index = 1; index <= 3; index++)
            { using var tx = owner.BeginTransaction(); tx.ReplaceNodeValue(index == 2 ? Line(read) : Target(read), index == 1 ? "one" : index == 2 ? "line-two" : "three"); tx.Commit(); }
        }
    }
    private static LocalTransactionStorage NativeStorage() => new(OperatingSystem.IsLinux() ? DurabilityMode.FileAndDirectoryFlush : DurabilityMode.ProcessCrash);
    private string Tx(string name) => Path.Combine(Root, ".transactions", name);
    private static string WalPath(string root, ulong sequence) => Path.Combine(root, ".transactions", "wal", EpochAuthorityCodec.WalFileName(sequence));
    private static EpochAuthorityBinding Binding(string root) => EpochEmptyCoordinator.ReadAuthority(root, EpochAdmission.ReadIdentity(root, EpochProfile.ScalarWal), true);
    private static EpochWalRecord Wal(string root, ulong sequence) => EpochAuthorityCodec.DecodeWal(File.ReadAllBytes(WalPath(root, sequence)), Binding(root));
    private static ulong Target(ImmutableXmlSnapshot snapshot) => Node(snapshot, "DocumentID");
    private static ulong Line(ImmutableXmlSnapshot snapshot) => Node(snapshot, "line");
    private static ulong Node(ImmutableXmlSnapshot snapshot, string name) => Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id))
        .Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == name).Children.Single();
    private static Dictionary<string, byte[]> Bytes(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories).ToDictionary(path => Path.GetRelativePath(root, path), File.ReadAllBytes);
    private static string[] Directories(string root) => Directory.GetDirectories(root, "*", SearchOption.AllDirectories).Select(path => Path.GetRelativePath(root, path)).Order().ToArray();
    private static void AssertBytes(Dictionary<string, byte[]> expected, string root)
    { var actual = Bytes(root); Assert.Equal(expected.Keys.Order(), actual.Keys.Order()); foreach (var item in expected) Assert.Equal(item.Value, actual[item.Key]); }
    /// <summary>Removes isolated fixtures after all handles close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
