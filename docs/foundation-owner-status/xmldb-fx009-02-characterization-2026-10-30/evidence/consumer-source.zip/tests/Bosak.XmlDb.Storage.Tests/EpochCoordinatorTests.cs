// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies empty-chain epoch authority, lock ordering, snapshots and initialization faults.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Text;
using Bosak.XmlDb.Core;
using Xunit;
using Xunit.Abstractions;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Verifies empty-chain epoch authority, lock ordering, snapshots and initialization faults.</summary>
public sealed class EpochCoordinatorTests(ITestOutputHelper output) : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-et4-" + Guid.NewGuid().ToString("N"));
    private string Source => Path.Combine(_area, "source");
    private string Root => Path.Combine(_area, "epoch");

    /// <summary>Snapshots retain both explicit-profile admission and stable base ownership after coordinator disposal and reopen.</summary>
    [Fact]
    public void Coordinator_IndependentSnapshots_PreserveBaseAndStableIdentitiesAcrossOwners()
    {
        var identity = Seed(); var before = Bytes(Source);
        var owner = EpochEmptyCoordinator.Open(Root);
        var snapshot = owner.BeginRead(0); var second = owner.BeginRead(0);
        Assert.Throws<IOException>(() => EpochEmptyCoordinator.Open(Root));
        Assert.Throws<IOException>(() => Exclusive(identity));
        owner.Dispose(); Assert.Throws<ObjectDisposedException>(() => owner.BeginRead());
        using (var next = EpochEmptyCoordinator.Open(Root))
        using (var read = next.BeginRead(0)) Assert.Equal("old", read.ReadValue(Target(read)));
        Assert.Equal("old", snapshot.ReadValue(Target(snapshot)));
        Assert.Throws<IOException>(() => new FileStream(EpochBaseReader.PathFor(Root), FileMode.Open, FileAccess.ReadWrite, FileShare.None));
        var stable = File.ReadAllBytes(EpochBaseReader.PathFor(Root));
        snapshot.Dispose(); Assert.Throws<IOException>(() => Exclusive(identity));
        second.Dispose();
        using (var maintenance = Exclusive(identity)) Assert.Equal(EpochProfile.ScalarWal, maintenance.Profile);
        using (var generation = new FileStream(EpochBaseReader.PathFor(Root), FileMode.Open, FileAccess.ReadWrite, FileShare.None)) { }
        Assert.Equal(stable, File.ReadAllBytes(EpochBaseReader.PathFor(Root)));
        AssertBytes(before, Source);
        Assert.False(File.Exists(Path.Combine(Root, ".transactions", "CURRENT")));
    }

    /// <summary>Nonempty or unknown state is refused before writer creation and never cleaned or replayed.</summary>
    /// <param name="artifact">Unsupported history/witness.</param>
    [Theory]
    [InlineData("wal")]
    [InlineData("generation")]
    [InlineData("current")]
    [InlineData("unknown")]
    public void Open_UnsupportedState_RejectsWithoutMutation(string artifact)
    {
        var identity = Seed();
        var binding = EpochEmptyCoordinator.ReadAuthority(Root, identity);
        if (artifact == "wal") File.WriteAllBytes(Path.Combine(Root, ".transactions", "wal", EpochAuthorityCodec.WalFileName(1)), [0]);
        if (artifact == "generation") Directory.CreateDirectory(Path.Combine(Root, ".transactions", "generations", EpochAuthorityCodec.GenerationName(1)));
        if (artifact == "unknown") File.WriteAllText(Path.Combine(Root, ".transactions", "future-authority"), "keep");
        if (artifact == "current") File.WriteAllBytes(Path.Combine(Root, ".transactions", "CURRENT"), EpochAuthorityCodec.EncodeCurrent(new(binding, 1, binding.BaseHash, Enumerable.Repeat((byte)1, 32).ToArray())));
        var before = Bytes(Root);
        Assert.Throws<NotSupportedException>(() => EpochEmptyCoordinator.Open(Root));
        Assert.False(File.Exists(Path.Combine(Root, ".transactions", "writer.lock")));
        AssertBytes(before, Root); using var exclusive = Exclusive(identity);
    }

    /// <summary>Corrupt authority or base data is rejected before ownership/runtime publication.</summary>
    /// <param name="artifact">Required data to damage.</param>
    [Theory]
    [InlineData("BASE")]
    [InlineData(".transactions/CONTROL")]
    [InlineData("documents/1/directory.bin")]
    [InlineData("fragments/1.bin")]
    public void Open_CorruptRequiredData_RejectsWithoutWriterOrAdmissionLeak(string artifact)
    {
        var identity = Seed(); File.WriteAllBytes(Path.Combine(Root, artifact), [0]); var before = Bytes(Root);
        Assert.Throws<InvalidDataException>(() => EpochEmptyCoordinator.Open(Root));
        AssertBytes(before, Root); using var exclusive = Exclusive(identity);
    }

    /// <summary>A corrupt canonical reader identity is never replaced.</summary>
    [Fact]
    public void Open_CorruptStableReader_NeverReplacesIdentity()
    {
        var identity = Seed(); using (EpochEmptyCoordinator.Open(Root)) { }
        var path = EpochBaseReader.PathFor(Root); File.WriteAllBytes(path, [0]);
        Assert.Throws<InvalidDataException>(() => EpochEmptyCoordinator.Open(Root));
        Assert.Equal(new byte[] { 0 }, File.ReadAllBytes(path)); using var exclusive = Exclusive(identity);
    }

    /// <summary>A child acquired outside the gate releases safely if owner disposal wins selection.</summary>
    [Fact]
    public async Task BeginRead_DisposeAfterAdmissionBeforeGate_ReleasesOnlyRacingChild()
    {
        var identity = Seed(); var owner = EpochEmptyCoordinator.Open(Root);
        using var admitted = new ManualResetEventSlim(); using var proceed = new ManualResetEventSlim();
        var operation = Task.Run(() => Assert.Throws<ObjectDisposedException>(() => owner.BeginRead(admitted: () =>
        { admitted.Set(); if (!proceed.Wait(TimeSpan.FromSeconds(20))) throw new TimeoutException("Race test timed out."); })));
        try
        {
            Assert.True(admitted.Wait(TimeSpan.FromSeconds(20))); owner.Dispose();
            Assert.Throws<IOException>(() => Exclusive(identity));
            proceed.Set(); await operation;
            using var exclusive = Exclusive(identity);
        }
        finally { proceed.Set(); await operation; owner.Dispose(); }
    }

    /// <summary>Mutable profile is retained in forks while immutable admission/data paths keep rejecting it.</summary>
    [Fact]
    public void Admission_ExplicitMutableForkAndSnapshotLoader_StayProfileBound()
    {
        var identity = Seed();
        Assert.Throws<InvalidDataException>(() => EpochAdmission.Acquire(Root, identity));
        Assert.Throws<InvalidDataException>(() => ReadOnlyEpochDatabase.Open(Root));
        using (var parent = EpochAdmission.Acquire(Root, identity, profile: EpochProfile.ScalarWal))
        {
            using var child = parent.ForkShared(); Assert.Equal(EpochProfile.ScalarWal, child.Profile);
            Assert.Throws<InvalidDataException>(() => ImmutableXmlSnapshot.OpenEpoch(Root, parent.ForkShared(), TransactionCodec.ManifestHash(Root, 1), 0));
        }
        using var exclusive = Exclusive(identity);
    }

    /// <summary>Native stronger-mode reopen while an old snapshot is alive does not write through shared identity handles.</summary>
    [Fact]
    public void StrongerAdoption_LiveEpochSnapshot_PreservesAdmissionAndReaderInodes()
    {
        var identity = Seed(); ImmutableXmlSnapshot read;
        using (var first = EpochEmptyCoordinator.Open(Root)) read = first.BeginRead(0);
        using (read)
        {
            var storage = OperatingSystem.IsLinux() ? (ITransactionStorage)new LocalTransactionStorage(DurabilityMode.FileAndDirectoryFlush)
                : new FaultingTransactionStorage(DurabilityMode.FileAndDirectoryFlush);
            using var next = EpochEmptyCoordinator.Open(Root, storage);
            using var second = next.BeginRead(0); Assert.Equal("old", second.ReadValue(Target(second)));
            Assert.Equal("old", read.ReadValue(Target(read)));
        }
        using var exclusive = Exclusive(identity);
    }

    /// <summary>Observed initialization errors and partial reader publication leave no owner leak and support later reopen.</summary>
    /// <param name="strong">Modeled stronger adoption policy.</param>
    /// <param name="fault">Failure timing or partial write.</param>
    [Theory]
    [InlineData(false, "before")]
    [InlineData(false, "after")]
    [InlineData(false, "partial")]
    [InlineData(true, "before")]
    [InlineData(true, "after")]
    [InlineData(true, "partial")]
    public void Open_InjectedPersistenceFailure_ReleasesOwnerAndReopens(bool strong, string fault)
    {
        SeedSource();
        var reference = Path.Combine(_area, "reference"); EpochEmptyRoot.CreateFixture(Source, reference, 1, new LocalTransactionStorage());
        var mode = strong ? DurabilityMode.FileAndDirectoryFlush : DurabilityMode.ProcessCrash;
        var recording = new FaultingTransactionStorage(mode); recording.Arm();
        using (EpochEmptyCoordinator.Open(reference, recording)) { }
        var calls = recording.Calls.Select((call, index) => (call, index)).Where(item => fault == "partial"
            ? item.call.Operation == "WriteFile" && item.call.Moment == "before" : item.call.Moment == fault).ToArray();
        Assert.NotEmpty(calls);
        foreach (var (_, index) in calls)
        {
            var target = Path.Combine(_area, "attempt-" + index); var identity = EpochEmptyRoot.CreateFixture(Source, target, 1, new LocalTransactionStorage());
            var storage = new FaultingTransactionStorage(mode); storage.Arm(index, fault == "partial");
            Assert.Throws<IOException>(() => EpochEmptyCoordinator.Open(target, storage)); Assert.True(storage.Fired);
            using (var exclusive = EpochAdmission.Acquire(target, identity, exclusive: true, profile: EpochProfile.ScalarWal)) { }
            for (var attempt = 0; attempt < 2; attempt++)
            {
                using var owner = EpochEmptyCoordinator.Open(target); using var read = owner.BeginRead(0);
                Assert.Equal("old", read.ReadValue(Target(read)));
            }
        }
        output.WriteLine($"et4-{(strong ? "strong" : "process")}/{fault}: {calls.Length} fault positions verified.");
    }

    /// <summary>A pending transaction context captures base identity and retains both handles until rollback after its owner closes.</summary>
    [Fact]
    public void TransactionContext_OwnerDisposed_RetainsIndependentBaseUntilRollback()
    {
        var identity = Seed(); var owner = EpochEmptyCoordinator.Open(Root);
        ulong target;
        using (var read = owner.BeginRead()) target = Target(read);
        var context = owner.BeginTransaction(); owner.Dispose();
        Assert.NotEqual(Guid.Empty, context.TransactionId); Assert.Equal(identity, context.Identity);
        Assert.Same(owner, context.Owner); Assert.Equal(0UL, context.BaseSequence);
        Assert.Equal(TransactionCodec.ManifestHash(Root, 1), context.BaseManifestHash.ToArray());
        Assert.Equal("old", context.ReadValue(target));
        Assert.Throws<IOException>(() => Exclusive(identity));
        Assert.Throws<IOException>(() => new FileStream(EpochBaseReader.PathFor(Root), FileMode.Open, FileAccess.ReadWrite, FileShare.None));
        context.Rollback(); context.Dispose();
        Assert.Throws<ObjectDisposedException>(() => context.ReadValue(target));
        using var exclusive = Exclusive(identity);
    }

    private EpochIdentity Seed() { SeedSource(); return EpochEmptyRoot.CreateFixture(Source, Root, 1, new LocalTransactionStorage()); }
    private void SeedSource()
    {
        Directory.CreateDirectory(_area); using var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID><line>line</line></r>"));
        XmlFragmentImporter.Import(input, Source);
    }
    private EpochAdmissionLease Exclusive(EpochIdentity identity) => EpochAdmission.Acquire(Root, identity, exclusive: true, profile: EpochProfile.ScalarWal);
    private static ulong Target(ImmutableXmlSnapshot snapshot) => Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id))
        .Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();
    private static Dictionary<string, byte[]> Bytes(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories).ToDictionary(path => Path.GetRelativePath(root, path), File.ReadAllBytes);
    private static void AssertBytes(Dictionary<string, byte[]> before, string root)
    { var after = Bytes(root); Assert.Equal(before.Keys.Order(), after.Keys.Order()); foreach (var item in before) Assert.Equal(item.Value, after[item.Key]); }
    /// <inheritdoc />
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
