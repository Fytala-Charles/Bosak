// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 30 October 2026
// PURPOSE              : Qualifies restart-only source retention, permanent stop and actual ownership drain.
// SPECIAL NOTES        : SR2-A real source fixtures; no paired authority observation or handoff permission.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 30-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Text;
using Bosak.XmlDb.Core;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Qualifies restart-only source retention, permanent stop and actual ownership drain.</summary>
public sealed class RestartSourceRetentionTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-sr2a-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "source");
    private string Writer => Path.Combine(Root, ".transactions", "writer.lock");
    private void Seed(int commits = 0)
    {
        using var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"));
        XmlFragmentImporter.Import(input, Root);
        using var owner = EmbeddedXmlDatabase.Open(Root);
        for (var i = 0; i < commits; i++)
        {
            using var read = owner.BeginRead(); using var tx = owner.BeginWrite();
            tx.ReplaceNodeValue(Target(read), "new-" + i); tx.Commit();
        }
    }
    private static ulong Target(ImmutableXmlSnapshot read) => Enumerable.Range(1, read.NodeCount).Select(i => read.GetNode((ulong)i))
        .Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();
    private Dictionary<string, byte[]> Bytes() => Directory.GetFiles(_area, "*", SearchOption.AllDirectories).Where(p => Path.GetFileName(p) != "writer.lock").ToDictionary(p => p, File.ReadAllBytes);
    private string[] Inventory() => Directory.GetFileSystemEntries(_area, "*", SearchOption.AllDirectories).Order().ToArray();
    private void Preserved(Dictionary<string, byte[]> bytes, string[] inventory)
    {
        Assert.Equal(inventory, Inventory()); var after = Bytes(); Assert.Equal(bytes.Keys.Order(), after.Keys.Order());
        foreach (var pair in bytes) Assert.Equal(pair.Value, after[pair.Key]);
    }
    private void Blocked() => Assert.Throws<IOException>(() => { using var blocked = new FileStream(Writer, FileMode.Open, FileAccess.ReadWrite, FileShare.None); });

    /// <summary>Original usable ownership survives wrapper closing and is released only by actual drain.</summary>
    /// <param name="sourceFirst">Whether owner close precedes child close.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Dispose_ActualChildDrain_RetainsOriginalOwnership(bool sourceFirst)
    {
        Seed(); using var owner = EmbeddedXmlDatabase.Open(Root); using var snapshot = owner.BeginRead();
        using var child = EmbeddedXmlDatabase.RetainedRestartSource.Acquire(owner, true);
        var initial = child.InspectState(); var bytes = Bytes(); var inventory = Inventory(); var released = owner.WhenEnrollmentOwnershipReleased;
        Assert.True(owner.EnrollmentOwnershipStatus.HasRetainer); Assert.True(owner.EnrollmentOwnershipStatus.StopLatched);
        if (sourceFirst)
        {
            owner.Dispose(); Blocked(); Assert.False(released.IsCompleted);
            var closing = child.InspectState(); Assert.True(closing.OwnerClosing); Assert.Equal(initial.AdmissionIdentity, closing.AdmissionIdentity);
            Assert.Equal(initial.RootIdentity, closing.RootIdentity); Assert.Equal(initial.Source.ManifestHash, closing.Source.ManifestHash);
            Assert.Throws<ObjectDisposedException>(() => child.RequireCurrent(owner));
        }
        child.Dispose(); child.Dispose(); Assert.Equal(RestartSourceState.Released, child.State);
        if (!sourceFirst) { Blocked(); Assert.False(released.IsCompleted); Assert.Throws<InvalidOperationException>(() => owner.BeginWrite()); owner.Dispose(); }
        Assert.True(released.IsCompletedSuccessfully); Assert.False(owner.EnrollmentOwnershipStatus.HasRetainer);
        using (var available = new FileStream(Writer, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) { }
        Assert.Equal("old", snapshot.ReadValue(Target(snapshot))); Preserved(bytes, inventory);
    }

    /// <summary>Every cooperating mutation or publisher stays blocked after admission and after child disposal.</summary>
    /// <param name="operation">Cooperating entry.</param>
    /// <param name="drained">Whether the actual child already drained.</param>
    [Theory]
    [InlineData("begin", false)]
    [InlineData("begin", true)]
    [InlineData("commit", false)]
    [InlineData("commit", true)]
    [InlineData("checkpoint", false)]
    [InlineData("checkpoint", true)]
    [InlineData("anchor", false)]
    [InlineData("anchor", true)]
    [InlineData("backup", false)]
    [InlineData("backup", true)]
    [InlineData("freeze", false)]
    [InlineData("freeze", true)]
    [InlineData("restart", false)]
    [InlineData("restart", true)]
    public void Acquire_PermanentStop_ExcludesMutationsAndPublishers(string operation, bool drained)
    {
        Seed(); using var owner = EmbeddedXmlDatabase.Open(Root); using var read = owner.BeginRead(); using var pending = owner.BeginWrite();
        pending.ReplaceNodeValue(Target(read), "forbidden");
        using var child = EmbeddedXmlDatabase.RetainedRestartSource.Acquire(owner, true); if (drained) child.Dispose();
        var bytes = Bytes(); var inventory = Inventory();
        Assert.Throws<InvalidOperationException>(() =>
        {
            switch (operation)
            {
                case "begin": using (owner.BeginWrite()) { } break;
                case "commit": pending.Commit(); break;
                case "checkpoint": owner.CreateCheckpoint(); break;
                case "anchor": owner.CreateRecoveryAnchor(); break;
                case "backup": owner.CreateBackup(Path.Combine(_area, "blocked")); break;
                case "freeze": using (MigrationSourceFreeze.Acquire(owner, true)) { } break;
                default: using (EmbeddedXmlDatabase.RetainedRestartSource.Acquire(owner, true)) { } break;
            }
        });
        Assert.Equal("old", read.ReadValue(Target(read))); Preserved(bytes, inventory);
    }

    /// <summary>Rejected admission never consumes or stops an otherwise usable source.</summary>
    /// <param name="condition">Admission failure.</param>
    [Theory]
    [InlineData("attestation")]
    [InlineData("freeze")]
    [InlineData("closed")]
    public void Acquire_IncompatibleOwner_Refuses(string condition)
    {
        Seed(); using var owner = EmbeddedXmlDatabase.Open(Root);
        if (condition == "closed") { owner.Dispose(); Assert.Throws<ObjectDisposedException>(() => EmbeddedXmlDatabase.RetainedRestartSource.Acquire(owner, true)); return; }
        if (condition == "freeze")
        {
            using var freeze = MigrationSourceFreeze.Acquire(owner, true);
            Assert.Throws<InvalidOperationException>(() => EmbeddedXmlDatabase.RetainedRestartSource.Acquire(owner, true));
        }
        else Assert.Throws<InvalidOperationException>(() => EmbeddedXmlDatabase.RetainedRestartSource.Acquire(owner, false));
        Assert.False(owner.EnrollmentOwnershipStatus.StopLatched); Assert.False(owner.EnrollmentOwnershipStatus.HasRetainer);
        using var write = owner.BeginWrite();
    }

    /// <summary>Null admission is an argument failure without source effects.</summary>
    [Fact]
    public void Acquire_NullOwner_Refuses() => Assert.Throws<ArgumentNullException>(() => EmbeddedXmlDatabase.RetainedRestartSource.Acquire(null!, true));

    /// <summary>Inspection is outside the source gate and cannot make a foreign owner current.</summary>
    [Fact]
    public void Inspect_NativePhase_OutsideGateAndExactOwner()
    {
        Seed(); using var owner = EmbeddedXmlDatabase.Open(Root); using var child = EmbeddedXmlDatabase.RetainedRestartSource.Acquire(owner, true);
        var called = false; var state = child.InspectStateCore(() => { Assert.False(child.IsSourceGateEntered); called = true; });
        Assert.True(called); Assert.False(state.OwnerClosing); child.RequireCurrent(owner);
        Assert.Throws<InvalidOperationException>(() => child.RequireCurrent(null!)); Blocked();
    }

    /// <summary>A native check failure poisons inspection while preserving ownership and permanent stop.</summary>
    [Fact]
    public void Inspect_NonemptyOriginalWriter_FaultsWithoutRepair()
    {
        Seed(); File.WriteAllBytes(Writer, [1]); using var owner = EmbeddedXmlDatabase.Open(Root);
        using var child = EmbeddedXmlDatabase.RetainedRestartSource.Acquire(owner, true); var bytes = Bytes(); var inventory = Inventory();
        Assert.Throws<InvalidDataException>(() => child.InspectState()); Assert.Equal(RestartSourceState.Faulted, child.State);
        Assert.Throws<InvalidOperationException>(() => child.InspectState()); Assert.Throws<InvalidOperationException>(() => child.RequireCurrent(owner));
        Blocked(); child.Dispose(); Assert.Throws<InvalidOperationException>(() => owner.BeginWrite()); Preserved(bytes, inventory);
    }

    /// <summary>Foreign-thread calls cannot inspect, validate or release the actual child.</summary>
    /// <param name="operation">Foreign-thread entry.</param>
    [Theory]
    [InlineData("inspect")]
    [InlineData("require")]
    [InlineData("dispose")]
    public void Child_ForeignThread_RefusesWithoutRelease(string operation)
    {
        Seed(); using var owner = EmbeddedXmlDatabase.Open(Root); using var child = EmbeddedXmlDatabase.RetainedRestartSource.Acquire(owner, true);
        Exception? error = null;
        var thread = new Thread(() => error = Record.Exception(() => { if (operation == "inspect") child.InspectState(); else if (operation == "require") child.RequireCurrent(owner); else child.Dispose(); }));
        thread.Start(); Assert.True(thread.Join(TimeSpan.FromSeconds(30))); Assert.IsType<InvalidOperationException>(error); Blocked(); child.RequireCurrent(owner);
    }

    /// <summary>Before/after/no-op close faults are unconfirmed and attempted only once.</summary>
    /// <param name="mode">Injected physical close outcome.</param>
    [Theory]
    [InlineData("before")]
    [InlineData("after")]
    [InlineData("noop")]
    public void Dispose_CloseFault_UnknownWithoutRetry(string mode)
    {
        Seed(); using var owner = EmbeddedXmlDatabase.Open(Root); var closer = new Closer(mode);
        var child = EmbeddedXmlDatabase.RetainedRestartSource.AcquireCore(owner, true, closer); var released = owner.WhenEnrollmentOwnershipReleased;
        var bytes = Bytes(); var inventory = Inventory();
        try
        {
            owner.Dispose(); Assert.Throws<IOException>(child.Dispose);
            Assert.Equal(RestartSourceState.ReleaseUnknown, child.State); Assert.True(released.IsFaulted);
            Assert.Equal(EnrollmentSourceReleaseState.Unknown, owner.EnrollmentOwnershipStatus.ReleaseState);
            Assert.True(owner.EnrollmentOwnershipStatus.HasRetainer); child.Dispose(); owner.Dispose(); Assert.Equal(1, closer.Calls);
            if (mode == "after") { using var available = new FileStream(Writer, FileMode.Open, FileAccess.ReadWrite, FileShare.None); }
            else Blocked();
            Preserved(bytes, inventory);
        }
        finally { closer.Stream?.Dispose(); } // Only this fresh test's original handle; no logical task or production retry is changed.
    }

    /// <summary>A later explicit source owner inherits no persistent fence from a closed stopped object.</summary>
    [Fact]
    public void Owner_ExplicitReopen_DoesNotInheritLatch()
    {
        Seed(); using (var owner = EmbeddedXmlDatabase.Open(Root)) using (EmbeddedXmlDatabase.RetainedRestartSource.Acquire(owner, true)) { }
        using var next = EmbeddedXmlDatabase.Open(Root); Assert.False(next.EnrollmentOwnershipStatus.StopLatched); using var write = next.BeginWrite();
    }

    /// <summary>Faulted owners and caller-held source gates cannot admit a restart child.</summary>
    /// <param name="faulted">Whether the owner is faulted instead of caller-gate entry.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Acquire_UnusableOwner_RejectsWithoutRegistration(bool faulted)
    {
        Seed(); using var owner = EmbeddedXmlDatabase.Open(Root);
        var flags = System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic;
        if (faulted)
        {
            typeof(EmbeddedXmlDatabase).GetField("_faulted", flags)!.SetValue(owner, true);
            Assert.Throws<InvalidOperationException>(() => EmbeddedXmlDatabase.RetainedRestartSource.Acquire(owner, true));
        }
        else
        {
            var gate = typeof(EmbeddedXmlDatabase).GetField("_gate", flags)!.GetValue(owner)!;
            lock (gate) Assert.Throws<InvalidOperationException>(() => EmbeddedXmlDatabase.RetainedRestartSource.Acquire(owner, true));
        }
        Assert.False(owner.EnrollmentOwnershipStatus.HasRetainer); Assert.False(owner.EnrollmentOwnershipStatus.StopLatched);
    }

    /// <summary>Existing original capture association and armed-owner stop are never bypassed.</summary>
    [Fact]
    public void Acquire_ExistingEnrollmentOwner_RemainsStrict()
    {
        Seed(); using var owner = EmbeddedXmlDatabase.Open(Root); using var freeze = MigrationSourceFreeze.Acquire(owner, true);
        var capture = freeze.Capture(Path.Combine(_area, "capture")); using var original = freeze.RetainForEnrollment(capture);
        Assert.Throws<InvalidOperationException>(() => EmbeddedXmlDatabase.RetainedRestartSource.Acquire(owner, true));
        original.InspectState(); original.Arm(); freeze.Dispose(); original.Dispose();
        Assert.Throws<InvalidOperationException>(() => EmbeddedXmlDatabase.RetainedRestartSource.Acquire(owner, true));
        Assert.True(owner.EnrollmentOwnershipStatus.StopLatched); Assert.False(owner.EnrollmentOwnershipStatus.HasRetainer);
    }

    /// <summary>Closing during an unlocked native phase retains the actual stream but prevents current-owner use.</summary>
    [Fact]
    public void Inspect_OwnerClosesDuringNativePhase_DrainsOriginalHandle()
    {
        Seed(); using var owner = EmbeddedXmlDatabase.Open(Root); using var child = EmbeddedXmlDatabase.RetainedRestartSource.Acquire(owner, true);
        var state = child.InspectStateCore(() => { Assert.False(child.IsSourceGateEntered); owner.Dispose(); Blocked(); });
        Assert.True(state.OwnerClosing); Assert.Throws<ObjectDisposedException>(() => child.RequireCurrent(owner));
        Assert.False(owner.WhenEnrollmentOwnershipReleased.IsCompleted); child.Dispose(); Assert.True(owner.WhenEnrollmentOwnershipReleased.IsCompletedSuccessfully);
    }

    /// <summary>Positive-H state copies cannot modify the owner's manifest and old snapshots survive drain.</summary>
    [Fact]
    public void Inspect_PositiveHistory_CopiesStateAndPreservesSnapshot()
    {
        Seed(1); using var owner = EmbeddedXmlDatabase.Open(Root); using var read = owner.BeginRead();
        using var child = EmbeddedXmlDatabase.RetainedRestartSource.Acquire(owner, true);
        var first = child.InspectState(); var original = (byte[])first.Source.ManifestHash.Clone(); first.Source.ManifestHash[0] ^= 255;
        Assert.Equal(1ul, first.Source.Sequence); Assert.Equal(original, child.InspectState().Source.ManifestHash);
        owner.Dispose(); child.Dispose(); Assert.Equal("new-0", read.ReadValue(Target(read)));
    }

    /// <summary>Repeated close/admit schedules preserve either closed-before-admission or actual retained ownership.</summary>
    [Fact]
    public void Acquire_RacesOwnerClose_QualifiesBothSafeEndpoints()
    {
        for (var repeat = 0; repeat < 8; repeat++)
        {
            using var fixture = new RestartSourceRetentionTests(); fixture.Seed(); using var owner = EmbeddedXmlDatabase.Open(fixture.Root);
            using var start = new ManualResetEventSlim(); Exception? closeError = null;
            var thread = new Thread(() => { start.Wait(); closeError = Record.Exception(owner.Dispose); });
            thread.Start(); start.Set(); EmbeddedXmlDatabase.RetainedRestartSource? child = null;
            var error = Record.Exception(() => child = EmbeddedXmlDatabase.RetainedRestartSource.Acquire(owner, true));
            Assert.True(thread.Join(TimeSpan.FromSeconds(30))); Assert.Null(closeError);
            if (error is null)
            {
                Assert.NotNull(child); fixture.Blocked(); Assert.True(child.InspectState().OwnerClosing); child.Dispose();
            }
            else Assert.IsType<ObjectDisposedException>(error);
            Assert.True(owner.WhenEnrollmentOwnershipReleased.IsCompletedSuccessfully);
        }
    }

    /// <summary>A later independent owner-close failure does not retry the drained child or clear its stop.</summary>
    /// <param name="mode">Injected physical close result.</param>
    [Theory]
    [InlineData("before")]
    [InlineData("after")]
    [InlineData("noop")]
    public void Dispose_LaterOwnerCloseFault_StaysUnknownWithoutRetry(string mode)
    {
        Seed(); using var owner = EmbeddedXmlDatabase.Open(Root); var closer = new Closer(mode);
        var child = EmbeddedXmlDatabase.RetainedRestartSource.AcquireCore(owner, true, closer); child.Dispose();
        try
        {
            Assert.Equal(0, closer.Calls); Assert.Throws<IOException>(owner.Dispose);
            Assert.Equal(RestartSourceState.Released, child.State); Assert.False(owner.EnrollmentOwnershipStatus.HasRetainer);
            Assert.True(owner.WhenEnrollmentOwnershipReleased.IsFaulted); Assert.True(owner.EnrollmentOwnershipStatus.StopLatched);
            child.Dispose(); owner.Dispose(); Assert.Equal(1, closer.Calls);
        }
        finally { closer.Stream?.Dispose(); }
    }

    private sealed class Closer(string mode) : IEnrollmentSourceLeaseClose
    {
        internal int Calls { get; private set; }
        internal FileStream? Stream { get; private set; }
        /// <inheritdoc/>
        public void Close(FileStream stream)
        {
            Calls++; Stream = stream;
            if (mode == "after") stream.Dispose();
            if (mode != "noop") throw new IOException("Injected " + mode + " restart source close.");
        }
    }
    /// <summary>Removes only this test's fresh owned workspace after all real handles drain.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
