// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies independent epoch restore, provenance binding and preserved full logical history.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================


using System.Security.Cryptography;
using System.Text;
using Bosak.XmlDb.Core;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Verifies independent restored epoch history and atomic provenance bundle publication.</summary>
public sealed class EpochBackupRestoreTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-et9c-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "epoch");
    private string Backup => Path.Combine(_area, "backup");
    private string Destination => Path.Combine(_area, "restored");

    /// <summary>Restores all sequences with fresh identities and byte-identical XML data and logical transaction history.</summary>
    /// <param name="count">Captured sequence.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(3)]
    public void Restore_CompleteHistory_RebindsIdentityAndPreservesEverySequence(int count)
    {
        Seed(count); using var sourceOwner = EpochScalarCoordinator.Open(Root); using var pinned = sourceOwner.BeginRead(0);
        var sourceBytes = Bytes(Root); var artifact = Bytes(Backup); var stages = new List<EpochRestoreStage>();
        var result = EpochBackupRestore.Restore(Backup, Destination, checkpoint: stages.Add);
        Assert.Equal(Enum.GetValues<EpochRestoreStage>(), stages); Assert.Equal(Path.Combine(Destination, "store"), result.StorePath);
        Assert.Equal((ulong)count, result.CommitSequence); Assert.Equal(sourceOwner.Identity, result.Source);
        Assert.NotEqual(result.Source.StoreId, result.Destination.StoreId); Assert.NotEqual(result.Source.EpochId, result.Destination.EpochId);
        Assert.Equal(result.Source.DocumentId, result.Destination.DocumentId); AssertBytes(sourceBytes, Root); AssertBytes(artifact, Backup);
        var inventoryBytes = File.ReadAllBytes(Path.Combine(Backup, "inventory.bin")); var inventory = EpochBackupStorage.ReadArtifact(Backup);
        var format = File.ReadAllBytes(Path.Combine(result.StorePath, "FORMAT"));
        var originBytes = File.ReadAllBytes(Path.Combine(Destination, "origin.bin"));
        var origin = EpochBackupCodec.ValidateOriginHeaders(originBytes, inventoryBytes, format, File.ReadAllBytes(Path.Combine(result.StorePath, ".transactions", "CURRENT")));
        Assert.Equal(result.RestoreId, origin.RestoreId); Assert.Equal(result.BackupId, origin.BackupId);
        Assert.Throws<InvalidDataException>(() => EpochAdmission.Acquire(result.StorePath, result.Source, profile: EpochProfile.ScalarWal));
        Assert.Throws<InvalidDataException>(() => ReadOnlyEpochDatabase.Open(result.StorePath));
        Assert.Throws<InvalidDataException>(() => EmbeddedXmlDatabase.Open(result.StorePath));
        var bundleError = Record.Exception(() => EpochScalarCoordinator.Open(Destination));
        Assert.True(bundleError is IOException or InvalidDataException, bundleError?.ToString());
        var destBinding = EpochAuthorityBinding.Create(format, inventory.Source.BaseHash);
        using (var sourceAdmission = EpochAdmission.Acquire(Root, result.Source, profile: EpochProfile.ScalarWal))
        using (var destAdmission = EpochAdmission.Acquire(result.StorePath, result.Destination, profile: EpochProfile.ScalarWal))
        {
            var previousWal = new byte[32];
            for (ulong sequence = 0; sequence <= (ulong)count; sequence++)
            {
                var hash = inventory.Source.BaseHash;
                if (sequence > 0)
                {
                    var original = EpochAuthorityCodec.DecodeWal(File.ReadAllBytes(Wal(Root, sequence)), inventory.Source);
                    var bytes = File.ReadAllBytes(Wal(result.StorePath, sequence)); var rebound = EpochAuthorityCodec.DecodeWal(bytes, destBinding);
                    Assert.Equal(EpochAuthorityCodec.EncodeWal(original with { Binding = destBinding, PreviousWalHash = previousWal }), bytes);
                    Assert.Equal(original.TransactionId, rebound.TransactionId); Assert.NotEqual(File.ReadAllBytes(Wal(Root, sequence)), bytes);
                    previousWal = SHA256.HashData(bytes); hash = original.ManifestHash;
                }
                using var expected = EpochScalarHistory.Open(Root, sequence, sourceAdmission, hash);
                using var actual = EpochScalarHistory.Open(result.StorePath, sequence, destAdmission, hash);
                Assert.Equal(expected.NodeCount, actual.NodeCount); Assert.Equal(expected.DocumentUri, actual.DocumentUri);
                for (ulong id = 1; id <= (ulong)expected.NodeCount; id++)
                {
                    var a = expected.GetNode(id); var b = actual.GetNode(id);
                    Assert.Equal(a with { Children = b.Children, Attributes = b.Attributes, Namespaces = b.Namespaces }, b);
                    Assert.Equal(a.Children, b.Children); Assert.Equal(a.Attributes, b.Attributes); Assert.Equal(a.Namespaces, b.Namespaces);
                    Assert.Equal(expected.ReadValue(id), actual.ReadValue(id));
                }
            }
            Assert.Equal(previousWal, origin.DestinationHeadWalHash);
        }
        Assert.Empty(Directory.GetDirectories(_area, ".xmldb-epoch-backup-*"));
        using var restored = EpochScalarCoordinator.Open(result.StorePath); using var read = restored.BeginRead(0);
        restored.Dispose(); // Returned snapshots use the published path, never a stale staging token.
        Assert.Equal(pinned.ReadValue(Target(pinned)), read.ReadValue(Target(read)));
        Assert.Equal(count + 1, Directory.GetFiles(Path.Combine(result.StorePath, ".transactions", "readers")).Length);
        AssertBytes(artifact, Backup);
    }

    /// <summary>Repeated restores create independent branches while source, backup and initial provenance stay unchanged.</summary>
    [Fact]
    public void Restore_RepeatedAndIndependentWrites_PreserveArtifactAndInitialOrigin()
    {
        Seed(3); var artifact = Bytes(Backup);
        var a = EpochBackupRestore.Restore(Backup, Destination); var b = EpochBackupRestore.Restore(Backup, Path.Combine(_area, "second"));
        Assert.NotEqual(a.Destination, b.Destination); Assert.NotEqual(a.RestoreId, b.RestoreId);
        var origin = File.ReadAllBytes(Path.Combine(Destination, "origin.bin")); var secondBefore = Bytes(b.StorePath);
        using (var first = EpochScalarCoordinator.Open(a.StorePath)) Write(first, "branch-a");
        using (var source = EpochScalarCoordinator.Open(Root)) Write(source, "source-later");
        using (var first = EpochScalarCoordinator.Open(a.StorePath))
        using (var read = first.BeginRead()) { Assert.Equal(4UL, read.CommitSequence); Assert.Equal("branch-a", read.ReadValue(Target(read))); }
        using (var second = EpochScalarCoordinator.Open(b.StorePath))
        using (var read = second.BeginRead()) { Assert.Equal(3UL, read.CommitSequence); Assert.Equal("one", read.ReadValue(Target(read))); }
        AssertBytes(secondBefore, b.StorePath); AssertBytes(artifact, Backup); Assert.Equal(origin, File.ReadAllBytes(Path.Combine(Destination, "origin.bin")));
    }

    /// <summary>Header/closure corruption is refused before any output workspace is created.</summary>
    /// <param name="artifact">Required metadata or data to damage.</param>
    [Theory]
    [InlineData("completion")]
    [InlineData("wal")]
    [InlineData("generation")]
    [InlineData("extra")]
    [InlineData("origin-as-inventory")]
    public void Restore_CorruptArtifact_RejectsReadOnlyBeforeWorkspace(string artifact)
    {
        Seed(1);
        if (artifact == "completion") File.WriteAllBytes(Path.Combine(Backup, "COMPLETE"), [0]);
        if (artifact == "wal") File.Delete(Wal(Path.Combine(Backup, "data"), 1));
        if (artifact == "generation") Directory.Delete(EpochScalarHistory.Generation(Path.Combine(Backup, "data"), 1), true);
        if (artifact == "extra") Directory.CreateDirectory(Path.Combine(Backup, "extra"));
        if (artifact == "origin-as-inventory") File.WriteAllBytes(Path.Combine(Backup, "inventory.bin"), Convert.FromHexString(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "TestData", "epoch-restore-origin-v1.hex")).Trim()));
        var before = Bytes(Backup); var source = Bytes(Root);
        Assert.Throws<InvalidDataException>(() => EpochBackupRestore.Restore(Backup, Destination));
        Assert.False(Directory.Exists(Destination)); Assert.Empty(Directory.GetDirectories(_area, ".xmldb-epoch-backup-*")); AssertBytes(before, Backup); AssertBytes(source, Root);
    }

    /// <summary>Existing/overlapping source or backup paths are never replaced and retries need a fresh destination.</summary>
    /// <param name="target">Forbidden destination.</param>
    [Theory]
    [InlineData("source")]
    [InlineData("backup")]
    [InlineData("child")]
    [InlineData("parent")]
    [InlineData("existing")]
    public void Restore_InvalidDestination_RefusesWithoutOverwrite(string target)
    {
        Seed(1); Directory.CreateDirectory(Destination); File.WriteAllText(Path.Combine(Destination, "keep"), "keep");
        var path = target switch { "source" => Root, "backup" => Backup, "child" => Path.Combine(Backup, "nested"), "parent" => _area, _ => Destination };
        var before = Bytes(Backup); var source = Bytes(Root); var error = Record.Exception(() => EpochBackupRestore.Restore(Backup, path));
        Assert.True(error is ArgumentException or IOException, error?.ToString());
        AssertBytes(before, Backup); AssertBytes(source, Root); Assert.Equal("keep", File.ReadAllText(Path.Combine(Destination, "keep")));
    }

    /// <summary>Selected publication failures retain immutable input and never return an incomplete routed root.</summary>
    /// <param name="stage">Injected boundary.</param>
    [Theory]
    [InlineData((int)EpochRestoreStage.SourceVerified)]
    [InlineData((int)EpochRestoreStage.Rebound)]
    [InlineData((int)EpochRestoreStage.DestinationVerified)]
    [InlineData((int)EpochRestoreStage.RuntimeReady)]
    [InlineData((int)EpochRestoreStage.OriginFlushed)]
    [InlineData((int)EpochRestoreStage.BundleVerified)]
    [InlineData((int)EpochRestoreStage.Published)]
    public void Restore_SelectedFailures_LeaveSourceAndBackupUnchanged(int stage)
    {
        Seed(1); var before = Bytes(Backup); var source = Bytes(Root);
        Assert.Throws<IOException>(() => EpochBackupRestore.Restore(Backup, Destination, checkpoint: actual => { if ((int)actual == stage) throw new IOException("injected"); }));
        AssertBytes(before, Backup); AssertBytes(source, Root);
        if (stage == (int)EpochRestoreStage.Published)
        {
            var origin = EpochBackupCodec.DecodeOrigin(File.ReadAllBytes(Path.Combine(Destination, "origin.bin")));
            using var owner = EpochScalarCoordinator.Open(Path.Combine(Destination, "store")); Assert.Equal(origin.Destination, owner.Identity); Assert.Equal(1UL, owner.CommitSequence);
        }
        else Assert.False(Directory.Exists(Destination));
    }

    /// <summary>A changed source payload after verification cannot be accepted as the copied source.</summary>
    [Fact]
    public void Restore_SourceChangesDuringCopy_RejectsBeforePublication()
    {
        Seed(1);
        Assert.Throws<InvalidDataException>(() => EpochBackupRestore.Restore(Backup, Destination, checkpoint: stage =>
        { if (stage == EpochRestoreStage.SourceVerified) File.WriteAllBytes(Path.Combine(Backup, "data", "fragments", "1.bin"), [0]); }));
        Assert.False(Directory.Exists(Destination));
    }

    /// <summary>Destination corruption after rebinding is rejected by the independent verification oracles.</summary>
    [Fact]
    public void Restore_ReboundDataChanges_RejectsBeforePublication()
    {
        Seed(1);
        Assert.Throws<InvalidDataException>(() => EpochBackupRestore.Restore(Backup, Destination, checkpoint: stage =>
        {
            if (stage == EpochRestoreStage.Rebound)
            { var workspace = Directory.GetDirectories(_area, ".xmldb-epoch-backup-*").Single(); File.WriteAllBytes(Path.Combine(workspace, "bundle", "store", "fragments", "1.bin"), [0]); }
        }));
        Assert.False(Directory.Exists(Destination));
    }

    /// <summary>Native Linux restore preserves a live old source snapshot and publishes a fresh root after closing staging handles.</summary>
    [Fact]
    public void Restore_NativeLinuxStrongPolicy_PreservesPinnedSourceAndProvenance()
    {
        if (!OperatingSystem.IsLinux()) return;
        Seed(3); using var source = EpochScalarCoordinator.Open(Root); using var old = source.BeginRead(0);
        var result = EpochBackupRestore.Restore(Backup, Destination, new LocalTransactionStorage(DurabilityMode.FileAndDirectoryFlush));
        using var restored = EpochScalarCoordinator.Open(result.StorePath, new LocalTransactionStorage(DurabilityMode.FileAndDirectoryFlush));
        using var read = restored.BeginRead(0); Assert.Equal(old.ReadValue(Target(old)), read.ReadValue(Target(read))); Assert.Equal(3UL, read.CommitSequence);
    }

    /// <summary>Resealed metadata cannot bypass source logical-history proof before rebinding.</summary>
    [Fact]
    public void Restore_ResealedWrongOperation_FailsSourceOracleBeforeRebinding()
    {
        Seed(1); var data = Path.Combine(Backup, "data"); var inv = EpochBackupStorage.ReadArtifact(Backup);
        var walPath = Wal(data, 1); var record = EpochAuthorityCodec.DecodeWal(File.ReadAllBytes(walPath), inv.Source);
        File.WriteAllBytes(walPath, EpochAuthorityCodec.EncodeWal(record with { Value = "forged" })); var walHash = SHA256.HashData(File.ReadAllBytes(walPath));
        var witnessPath = Path.Combine(EpochScalarHistory.Generation(data, 1), "GENERATION");
        var witness = EpochAuthorityCodec.DecodeGeneration(File.ReadAllBytes(witnessPath), inv.Source);
        File.WriteAllBytes(witnessPath, EpochAuthorityCodec.EncodeGeneration(witness with { WalHash = walHash }));
        File.WriteAllBytes(Path.Combine(data, ".transactions", "CURRENT"), EpochAuthorityCodec.EncodeCurrent(new(inv.Source, 1, inv.HeadManifestHash, walHash)));
        var entries = inv.Files.Select(entry => { var bytes = File.ReadAllBytes(Path.Combine(data, entry.Path)); return new BackupEntry(entry.Path, bytes.Length, SHA256.HashData(bytes)); }).ToArray();
        var inventory = EpochBackupCodec.EncodeInventory(inv with { Files = entries, HeadWalHash = walHash });
        File.WriteAllBytes(Path.Combine(Backup, "inventory.bin"), inventory); File.WriteAllBytes(Path.Combine(Backup, "COMPLETE"), EpochBackupCodec.Complete(inventory));
        EpochBackupStorage.ReadArtifact(Backup); var before = Bytes(Backup); var source = Bytes(Root); var stages = new List<EpochRestoreStage>();
        Assert.Throws<InvalidDataException>(() => EpochBackupRestore.Restore(Backup, Destination, checkpoint: stages.Add));
        Assert.DoesNotContain(EpochRestoreStage.SourceVerified, stages); Assert.False(Directory.Exists(Destination)); AssertBytes(before, Backup); AssertBytes(source, Root);
    }

    /// <summary>Valid checksums cannot substitute provenance identity or inventory commitments before publication.</summary>
    /// <param name="field">Substituted origin field.</param>
    [Theory]
    [InlineData("inventory")]
    [InlineData("source-epoch")]
    [InlineData("destination-epoch")]
    public void Restore_ResealedOriginSubstitution_RejectsBeforePublication(string field)
    {
        Seed(1); var before = Bytes(Backup);
        Assert.Throws<InvalidDataException>(() => EpochBackupRestore.Restore(Backup, Destination, checkpoint: stage =>
        {
            if (stage != EpochRestoreStage.OriginFlushed) return;
            var workspace = Directory.GetDirectories(_area, ".xmldb-epoch-backup-*").Single(); var path = Path.Combine(workspace, "bundle", "origin.bin");
            var origin = EpochBackupCodec.DecodeOrigin(File.ReadAllBytes(path));
            var changed = field switch
            {
                "inventory" => origin with { InventoryHash = new byte[32] },
                "source-epoch" => origin with { Source = origin.Source with { Identity = origin.Source.Identity with { EpochId = Guid.NewGuid() } } },
                _ => origin with { Destination = origin.Destination with { EpochId = Guid.NewGuid() } },
            };
            File.WriteAllBytes(path, EpochBackupCodec.EncodeOrigin(changed));
        }));
        Assert.False(Directory.Exists(Destination)); AssertBytes(before, Backup);
    }

    /// <summary>All stable initial reader identities must be present before bundle publication.</summary>
    [Fact]
    public void Restore_MissingInitialReader_RejectsBeforePublication()
    {
        Seed(3);
        Assert.Throws<InvalidDataException>(() => EpochBackupRestore.Restore(Backup, Destination, checkpoint: stage =>
        {
            if (stage == EpochRestoreStage.RuntimeReady)
            { var workspace = Directory.GetDirectories(_area, ".xmldb-epoch-backup-*").Single(); File.Delete(EpochGenerationReader.PathFor(Path.Combine(workspace, "bundle", "store"), 1)); }
        }));
        Assert.False(Directory.Exists(Destination));
    }

    /// <summary>Linked source/output ancestors are refused without writes through the link.</summary>
    /// <param name="source">Whether the link aliases the artifact instead of the destination parent.</param>
    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public void Restore_LinkedPaths_RejectsWithoutCrossingBoundary(bool source)
    {
        if (!OperatingSystem.IsLinux()) return;
        Seed(1); var outside = Path.Combine(_area, "outside"); Directory.CreateDirectory(outside); File.WriteAllText(Path.Combine(outside, "keep"), "keep");
        var link = Path.Combine(_area, "linked"); Directory.CreateSymbolicLink(link, source ? Backup : outside); var before = Bytes(Backup);
        Assert.Throws<InvalidDataException>(() => EpochBackupRestore.Restore(source ? link : Backup, source ? Destination : Path.Combine(link, "restored")));
        Assert.False(Directory.Exists(Path.Combine(outside, "restored"))); Assert.Equal("keep", File.ReadAllText(Path.Combine(outside, "keep"))); AssertBytes(before, Backup);
    }

    private void Seed(int count)
    {
        Directory.CreateDirectory(_area); var source = Path.Combine(_area, "source");
        using var input = new MemoryStream(Encoding.UTF8.GetBytes("<r xmlns:p='urn:test' xml:base='https://example.test/base/'><DocumentID>old</DocumentID><line code='x'>line</line></r>"));
        XmlFragmentImporter.Import(input, source, documentUri: "https://example.test/et9c.xml"); EpochEmptyRoot.CreateFixture(source, Root, 1, new LocalTransactionStorage());
        using var owner = EpochScalarCoordinator.Open(Root); using var read = owner.BeginRead();
        for (var index = 1; index <= count; index++)
        {
            using var tx = owner.BeginTransaction();
            var node = index == 1 ? Target(read) : index == 2 ? Find(read, "line").Children.Single() : Find(read, "line").Attributes.Single();
            tx.ReplaceNodeValue(node, index == 1 ? "one" : index == 2 ? "two" : ""); tx.Commit();
        }
        owner.CreateBackup(Backup);
    }
    private static StorageNode Find(ImmutableXmlSnapshot snapshot, string name) => Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id))
        .Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == name);
    private static ulong Target(ImmutableXmlSnapshot snapshot) => Find(snapshot, "DocumentID").Children.Single();
    private static void Write(EpochScalarCoordinator owner, string value)
    { using var read = owner.BeginRead(); using var tx = owner.BeginTransaction(); tx.ReplaceNodeValue(Target(read), value); tx.Commit(); }
    private static string Wal(string root, ulong sequence) => Path.Combine(root, ".transactions", "wal", EpochAuthorityCodec.WalFileName(sequence));
    private static Dictionary<string, byte[]> Bytes(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories).Where(path => Path.GetFileName(path) != "writer.lock")
        .ToDictionary(path => Path.GetRelativePath(root, path), File.ReadAllBytes);
    private static void AssertBytes(Dictionary<string, byte[]> expected, string root)
    { var actual = Bytes(root); Assert.Equal(expected.Keys.Order(), actual.Keys.Order()); foreach (var file in expected) Assert.Equal(file.Value, actual[file.Key]); }
    /// <summary>Removes isolated fixtures after all branch handles close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
