// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies fresh-epoch conversion, every-sequence parity and atomic migration provenance.
// SPECIAL NOTES        : Internal conversion tests; public APIs, live source recovery, cutover and retirement stay off.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Security.Cryptography;
using System.Text;
using Bosak.XmlDb.Core;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Verifies internal legacy conversion without enabling cutover or public mutable APIs.</summary>
public sealed class EpochLegacyMigrationTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-mg3-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "legacy");
    private string Backup => Path.Combine(_area, "backup");
    private string Destination => Path.Combine(_area, "migrated");
    private string Data => Path.Combine(Backup, "data");

    /// <summary>Every retained sequence, logical operation and XML byte survives identity-bound conversion.</summary>
    /// <param name="count">Captured head sequence.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(3)]
    public void Convert_EverySequenceAndDocumentByte_PreservesHistory(int count)
    {
        Seed(count); using var sourceOwner = EmbeddedXmlDatabase.Open(Root); using var pinned = sourceOwner.BeginRead(0);
        var source = Bytes(Root, true); var input = Bytes(Backup); sourceOwner.Dispose(); var stages = new List<EpochMigrationStage>();
        var result = EpochLegacyMigration.Convert(Backup, Destination, checkpoint: stages.Add);
        Assert.Equal(Enum.GetValues<EpochMigrationStage>(), stages); Assert.Equal(Path.Combine(Destination, "store"), result.StorePath);
        Assert.Equal((ulong)count, result.CommitSequence); Assert.NotEqual(Guid.Empty, result.MigrationId);
        Assert.Equal(1UL, result.Destination.DocumentId);
        var origin = EpochMigrationCodec.ValidateHeaders(File.ReadAllBytes(Path.Combine(Destination, "migration.bin")),
            File.ReadAllBytes(Path.Combine(Backup, "inventory.bin")), File.ReadAllBytes(Path.Combine(Backup, "COMPLETE")),
            File.ReadAllBytes(Path.Combine(Data, "FORMAT")), File.ReadAllBytes(Path.Combine(Data, ".transactions", "CONTROL")),
            count == 0 ? null : File.ReadAllBytes(Path.Combine(Data, ".transactions", "CURRENT")), File.ReadAllBytes(Path.Combine(result.StorePath, "FORMAT")),
            File.ReadAllBytes(Path.Combine(result.StorePath, ".transactions", "CURRENT")));
        Assert.Equal(result.MigrationId, origin.MigrationId); Assert.Equal(result.BackupId, origin.BackupId); Assert.Equal(result.Destination, origin.Destination);
        var format = File.ReadAllBytes(Path.Combine(result.StorePath, "FORMAT")); var binding = EpochAuthorityBinding.Create(format, origin.BaseHash);
        using (var admission = EpochAdmission.Acquire(result.StorePath, result.Destination, profile: EpochProfile.ScalarWal))
        {
            var prior = new byte[32];
            for (ulong sequence = 0; sequence <= (ulong)count; sequence++)
            {
                var sourceData = Generation(Data, sequence); var targetData = Generation(result.StorePath, sequence);
                Assert.Equal(format, File.ReadAllBytes(Path.Combine(targetData, "FORMAT")));
                foreach (var directory in new[] { "documents", "fragments" }) AssertBytes(Bytes(Path.Combine(sourceData, directory)), Path.Combine(targetData, directory));
                var hash = origin.BaseHash;
                if (sequence > 0)
                {
                    var wal = TransactionCodec.ReadWal(Wal(Data, sequence))!; var bytes = File.ReadAllBytes(Wal(result.StorePath, sequence));
                    var actual = EpochAuthorityCodec.DecodeWal(bytes, binding);
                    Assert.Equal(wal.TransactionId, actual.TransactionId); Assert.Equal(wal.Sequence, actual.Sequence); Assert.Equal(wal.NodeId, actual.NodeId); Assert.Equal(wal.Value, actual.Value);
                    Assert.Equal(wal.PreviousManifestHash, actual.PreviousManifestHash); Assert.Equal(wal.ManifestHash, actual.ManifestHash); Assert.Equal(prior, actual.PreviousWalHash);
                    prior = SHA256.HashData(bytes); hash = wal.ManifestHash;
                }
                using var expected = ImmutableXmlSnapshot.OpenVersion(sourceData, 1, sequence);
                using var actualRead = EpochScalarHistory.Open(result.StorePath, sequence, admission, hash);
                Assert.Equal(expected.DocumentUri, actualRead.DocumentUri); Assert.Equal(expected.NodeCount, actualRead.NodeCount);
                for (ulong id = 1; id <= (ulong)expected.NodeCount; id++)
                {
                    var a = expected.GetNode(id); var b = actualRead.GetNode(id);
                    Assert.Equal(a with { Children = b.Children, Attributes = b.Attributes, Namespaces = b.Namespaces }, b);
                    Assert.Equal(a.Children, b.Children); Assert.Equal(a.Attributes, b.Attributes); Assert.Equal(a.Namespaces, b.Namespaces);
                    Assert.Equal(expected.ReadValue(id), actualRead.ReadValue(id));
                }
            }
            Assert.Equal(prior, origin.DestinationHeadWalHash);
        }
        Assert.Throws<InvalidDataException>(() => EmbeddedXmlDatabase.Open(result.StorePath));
        Assert.Throws<InvalidDataException>(() => ReadOnlyEpochDatabase.Open(result.StorePath));
        Assert.Throws<InvalidOperationException>(() => ImmutableXmlSnapshot.Open(result.StorePath));
        var bundleError = Record.Exception(() => EpochScalarCoordinator.Open(Destination)); Assert.True(bundleError is IOException or InvalidDataException);
        using var owner = EpochScalarCoordinator.Open(result.StorePath); using var read = owner.BeginRead(0); owner.Dispose();
        Assert.Equal(pinned.ReadValue(Target(pinned)), read.ReadValue(Target(read)));
        AssertBytes(input, Backup); AssertBytes(source, Root, true); Assert.Empty(Directory.GetDirectories(_area, ".xmldb-epoch-backup-*"));
    }

    /// <summary>Repeat conversions create independent branches with immutable original prefix provenance.</summary>
    [Fact]
    public void Convert_RepeatedBranches_AreIndependent()
    {
        Seed(3); var input = Bytes(Backup);
        var a = EpochLegacyMigration.Convert(Backup, Destination); var b = EpochLegacyMigration.Convert(Backup, Path.Combine(_area, "second"));
        Assert.NotEqual(a.Destination.StoreId, b.Destination.StoreId); Assert.NotEqual(a.Destination.EpochId, b.Destination.EpochId); Assert.NotEqual(a.MigrationId, b.MigrationId);
        var origin = File.ReadAllBytes(Path.Combine(Destination, "migration.bin")); var second = Bytes(b.StorePath);
        using (var owner = EpochScalarCoordinator.Open(a.StorePath))
        { using var read = owner.BeginRead(); using var tx = owner.BeginTransaction(); tx.ReplaceNodeValue(Target(read), "branch"); Assert.Equal(4UL, tx.Commit()); }
        using (var source = EmbeddedXmlDatabase.Open(Root))
        { using var read = source.BeginRead(); using var tx = source.BeginWrite(); tx.ReplaceNodeValue(Target(read), "source-later"); Assert.Equal(4UL, tx.Commit()); }
        using (var owner = EpochScalarCoordinator.Open(a.StorePath))
        { using var read = owner.BeginRead(); Assert.Equal("branch", read.ReadValue(Target(read))); }
        using (var owner = EpochScalarCoordinator.Open(b.StorePath))
        { using var read = owner.BeginRead(); Assert.Equal(3UL, read.CommitSequence); Assert.Equal("one-β", read.ReadValue(Target(read))); }
        Assert.Equal(origin, File.ReadAllBytes(Path.Combine(Destination, "migration.bin"))); AssertBytes(second, b.StorePath); AssertBytes(input, Backup);
    }

    /// <summary>Every selected interruption preserves inputs, closes handles and leaves absent or wholly verified final output.</summary>
    /// <param name="stage">Checkpoint ordinal.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(2)]
    [InlineData(3)]
    [InlineData(4)]
    [InlineData(5)]
    [InlineData(6)]
    public void Convert_SelectedFailures_HaveExplicitPublicationOutcome(int stage)
    {
        Seed(1); var input = Bytes(Backup); var source = Bytes(Root);
        Assert.Throws<IOException>(() => EpochLegacyMigration.Convert(Backup, Destination, checkpoint: actual => { if ((int)actual == stage) throw new IOException("injected"); }));
        AssertBytes(input, Backup); AssertBytes(source, Root);
        if (stage == (int)EpochMigrationStage.Published) VerifyPublished(Destination, 1);
        else Assert.False(Directory.Exists(Destination));
        foreach (var file in Directory.GetFiles(_area, "*", SearchOption.AllDirectories)) using (new FileStream(file, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) { }
        if (stage != (int)EpochMigrationStage.Published) EpochLegacyMigration.Convert(Backup, Destination);
        var published = Bytes(Destination); Assert.Throws<IOException>(() => EpochLegacyMigration.Convert(Backup, Destination)); AssertBytes(published, Destination);
    }

    /// <summary>Bad source histories reject before any workspace persistence.</summary>
    /// <param name="fault">Source refusal class.</param>
    [Theory]
    [InlineData("inventory")]
    [InlineData("partial-wal")]
    [InlineData("missing-generation")]
    [InlineData("wrong-logical-value")]
    [InlineData("epoch-format")]
    public void Convert_InvalidSource_RejectsWithoutWrites(string fault)
    {
        Seed(1);
        switch (fault)
        {
            case "inventory": var bytes = File.ReadAllBytes(Path.Combine(Backup, "inventory.bin")); bytes[^1] ^= 1; File.WriteAllBytes(Path.Combine(Backup, "inventory.bin"), bytes); break;
            case "partial-wal": File.WriteAllBytes(Wal(Data, 1), File.ReadAllBytes(Wal(Data, 1))[..100]); Reseal(); break;
            case "missing-generation": Directory.Delete(Generation(Data, 1), true); Reseal(); break;
            case "wrong-logical-value": var wal = TransactionCodec.ReadWal(Wal(Data, 1))!; File.WriteAllBytes(Wal(Data, 1), TransactionCodec.EncodeWal(wal with { Value = "forged" })); Reseal(); break;
            case "epoch-format": File.WriteAllBytes(Path.Combine(Data, "FORMAT"), EpochCodec.EncodeProfile(new(Guid.NewGuid(), Guid.NewGuid(), 1), EpochProfile.ScalarWal)); Reseal(); break;
        }
        var input = Bytes(Backup); var storage = new FaultingTransactionStorage(); storage.Arm();
        Assert.Throws<InvalidDataException>(() => EpochLegacyMigration.Convert(Backup, Destination, storage)); Assert.Empty(storage.Calls);
        AssertBytes(input, Backup); Assert.Empty(Directory.GetDirectories(_area, ".xmldb-epoch-backup-*"));
    }

    /// <summary>Output guards reject existing, overlapping and nonexistent-parent destinations.</summary>
    /// <param name="kind">Guard class.</param>
    [Theory]
    [InlineData("overlap")]
    [InlineData("existing")]
    [InlineData("missing-parent")]
    public void Convert_InvalidDestination_PreservesExistingData(string kind)
    {
        Seed(0); var input = Bytes(Backup); var path = kind == "overlap" ? Path.Combine(Backup, "inside") : kind == "missing-parent" ? Path.Combine(_area, "missing", "child") : Destination;
        if (kind == "existing") { Directory.CreateDirectory(path); File.WriteAllText(Path.Combine(path, "keep"), "keep"); }
        var error = Record.Exception(() => EpochLegacyMigration.Convert(Backup, path)); Assert.True(error is ArgumentException or IOException); AssertBytes(input, Backup);
        if (kind == "existing") Assert.Equal("keep", File.ReadAllText(Path.Combine(path, "keep")));
    }

    /// <summary>Source or destination changes after verification cannot publish a result.</summary>
    /// <param name="source">Whether to mutate source rather than transformed destination bytes.</param>
    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public void Convert_ObservedDataMutation_Rejects(bool source)
    {
        Seed(1);
        Assert.Throws<InvalidDataException>(() => EpochLegacyMigration.Convert(Backup, Destination, checkpoint: stage =>
        {
            if (stage != EpochMigrationStage.Rebound) return;
            var root = source ? Data : StagedRoot(); File.WriteAllBytes(Path.Combine(root, "fragments", "1.bin"), [1]);
        }));
        Assert.False(Directory.Exists(Destination));
    }

    /// <summary>Resealed provenance substitutions, including the operation nonce, cannot be silently published.</summary>
    /// <param name="migrationId">Whether to substitute the otherwise unbound operation identifier.</param>
    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public void Convert_ResealedProvenanceSubstitution_Rejects(bool migrationId)
    {
        Seed(1);
        Assert.Throws<InvalidDataException>(() => EpochLegacyMigration.Convert(Backup, Destination, checkpoint: stage =>
        {
            if (stage != EpochMigrationStage.OriginFlushed) return;
            var path = Path.Combine(Path.GetDirectoryName(StagedRoot())!, "migration.bin"); var origin = EpochMigrationCodec.Decode(File.ReadAllBytes(path));
            File.WriteAllBytes(path, EpochMigrationCodec.Encode(migrationId ? origin with { MigrationId = Guid.NewGuid() } : origin with { BackupId = Guid.NewGuid() }));
        }));
        Assert.False(Directory.Exists(Destination));
    }

    /// <summary>Missing initial reader identities reject without being recreated as valid publication.</summary>
    [Fact]
    public void Convert_MissingInitialReader_Rejects()
    {
        Seed(1);
        Assert.Throws<InvalidDataException>(() => EpochLegacyMigration.Convert(Backup, Destination, checkpoint: stage =>
        { if (stage == EpochMigrationStage.RuntimeReady) File.Delete(Path.Combine(StagedRoot(), ".transactions", "readers", EpochAuthorityCodec.ReaderFileName(0))); }));
        Assert.False(Directory.Exists(Destination));
    }

    /// <summary>Linux conversion executes actual strong-policy source and destination verification.</summary>
    [Fact]
    public void Convert_NativeLinuxPolicy_VerifiesBothProfiles()
    {
        if (!OperatingSystem.IsLinux()) return;
        Seed(3); var storage = new FaultingTransactionStorage(DurabilityMode.FileAndDirectoryFlush, true);
        Assert.Equal(DurabilityMode.FileAndDirectoryFlush, storage.EffectiveDurability);
        var result = EpochLegacyMigration.Convert(Backup, Destination, storage); Assert.Equal(3UL, result.CommitSequence); VerifyPublished(Destination, 3);
    }

    /// <summary>Linked input files or output ancestors are refused without crossing the owned boundary.</summary>
    /// <param name="source">Whether to link source payload rather than destination parent.</param>
    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public void Convert_LinuxLinks_Rejects(bool source)
    {
        if (!OperatingSystem.IsLinux()) return;
        Seed(1); var outside = Path.Combine(_area, "outside"); Directory.CreateDirectory(outside); File.WriteAllText(Path.Combine(outside, "keep"), "keep"); var path = Destination;
        if (source) { var file = Path.Combine(Data, "fragments", "1.bin"); File.Delete(file); File.CreateSymbolicLink(file, Path.Combine(outside, "keep")); }
        else { var link = Path.Combine(_area, "link"); Directory.CreateSymbolicLink(link, outside); path = Path.Combine(link, "child"); }
        Assert.Throws<InvalidDataException>(() => EpochLegacyMigration.Convert(Backup, path)); Assert.Equal("keep", File.ReadAllText(Path.Combine(outside, "keep")));
    }

    private string StagedRoot() => Path.Combine(Directory.GetDirectories(_area, ".xmldb-epoch-backup-*").Single(p => Directory.Exists(Path.Combine(p, "bundle"))), "bundle", "store");
    private void Seed(int count)
    {
        Directory.CreateDirectory(_area); using var input = new MemoryStream(Encoding.UTF8.GetBytes("<r xmlns='urn:mg3' xml:base='https://example.test/base/'><DocumentID>old</DocumentID><line code='A'>line</line></r>"));
        XmlFragmentImporter.Import(input, Root, documentUri: "https://example.test/mg3.xml"); using var owner = EmbeddedXmlDatabase.Open(Root);
        for (var index = 0; index < count; index++)
        {
            using var read = owner.BeginRead(); using var tx = owner.BeginWrite();
            var target = index == 1 ? Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Attribute && n.LocalName == "code").Id : Target(read, index == 2 ? "line" : "DocumentID");
            tx.ReplaceNodeValue(target, index == 1 ? "" : index == 2 ? "three-λ" : "one-β"); tx.Commit();
        }
        owner.CreateBackup(Backup);
    }
    private void Reseal()
    {
        var inventory = BackupCodec.Decode(File.ReadAllBytes(Path.Combine(Backup, "inventory.bin")));
        var files = inventory.Files.Where(f => File.Exists(Path.Combine(Data, f.Path))).Select(f => { var bytes = File.ReadAllBytes(Path.Combine(Data, f.Path)); return f with { Length = bytes.Length, Hash = SHA256.HashData(bytes) }; }).ToArray();
        var bytes = BackupCodec.Encode(inventory with { Files = files }); File.WriteAllBytes(Path.Combine(Backup, "inventory.bin"), bytes); File.WriteAllBytes(Path.Combine(Backup, "COMPLETE"), BackupCodec.Complete(bytes));
    }
    private static void VerifyPublished(string bundle, ulong sequence)
    {
        var origin = EpochMigrationCodec.Decode(File.ReadAllBytes(Path.Combine(bundle, "migration.bin")));
        using var owner = EpochScalarCoordinator.Open(Path.Combine(bundle, "store")); using var read = owner.BeginRead(0);
        Assert.Equal(origin.Destination, owner.Identity); Assert.Equal(sequence, read.CommitSequence); Assert.Equal("one-β", read.ReadValue(Target(read)));
    }
    private static ulong Target(ImmutableXmlSnapshot snapshot, string name = "DocumentID") => Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == name).Children.Single();
    private static string Generation(string root, ulong sequence) => EpochScalarHistory.Generation(root, sequence);
    private static string Wal(string root, ulong sequence) => Path.Combine(root, ".transactions", "wal", EpochAuthorityCodec.WalFileName(sequence));
    private static Dictionary<string, byte[]> Bytes(string root, bool skipWriter = false) => Directory.GetFiles(root, "*", SearchOption.AllDirectories).Where(p => !skipWriter || Path.GetFileName(p) != "writer.lock").ToDictionary(p => Path.GetRelativePath(root, p), File.ReadAllBytes);
    private static void AssertBytes(Dictionary<string, byte[]> expected, string root, bool skipWriter = false) { var actual = Bytes(root, skipWriter); Assert.Equal(expected.Keys.Order(), actual.Keys.Order()); foreach (var pair in expected) Assert.Equal(pair.Value, actual[pair.Key]); }
    /// <summary>Removes isolated test-owned data after releasing all handles.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
