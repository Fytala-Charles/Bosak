// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 30 October 2026
// PURPOSE              : Qualifies unlocked retained placement and serialized authority preflight.
// SPECIAL NOTES        : ER-002 real source retention and exact preflight checks; no public surface or format changes.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 30-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Reflection;
using System.Text;
using Bosak.XmlDb.Core;
using Xunit;
using Xunit.Abstractions;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Qualifies unlocked retained placement and serialized authority preflight.</summary>
/// <param name="output">Captures preflight qualification evidence.</param>
public sealed class ApplicationAuthorityEnrollmentPreflightTests(ITestOutputHelper output) : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-er002-" + Guid.NewGuid().ToString("N"));
    private string Source => Path.Combine(_area, "source");
    private string Capture => Path.Combine(_area, "capture");
    private string Host => Path.Combine(_area, "host");
    private string Authority => Path.Combine(_area, "authority");
    private readonly Guid _admin = Guid.NewGuid();
    private ApplicationAuthorityConfiguration Configuration => new(Guid.Parse("10213243-5465-7687-98a9-bacbdcedfe0f"), _admin, "pilot", "orders", "admin", "authority");
    private Dictionary<string, string> Roots => new() { ["admin"] = Host, ["authority"] = Authority, ["source"] = Source, ["capture"] = Capture };
    private static EmbeddedHostInspectionEvidence Inspection(EmbeddedHostLifetime parent) => new(parent.Context, true, true, true, true, true);
    private ApplicationEnrollmentEvidence Evidence(EmbeddedHostLifetime parent) => new(parent.Context, Configuration.AuthorityId, "source", "source-admission", "capture", Guid.NewGuid(), new string('a', 64), true, true, true, true, true, true);
    private EmbeddedHostLifetime Parent()
    {
        Directory.CreateDirectory(Host); File.WriteAllBytes(Path.Combine(Host, "owner.lock"), []);
        File.WriteAllBytes(Path.Combine(Host, "host.meta"), HostJournalCodec.EncodeMetadata(_admin, "pilot", "orders")); File.WriteAllBytes(Path.Combine(Host, "journal.bin"), []);
        return EmbeddedHostLifetime.OpenExisting(Host, "pilot", "orders", [Source, Capture, Authority]);
    }
    private ApplicationAuthorityLifetime Provision(EmbeddedHostLifetime parent) => ApplicationAuthorityLifetime.Provision(parent, parent.JournalStatus.KnownPosition, Inspection(parent), Authority, Configuration, Roots, new(Authority, true, true, true));
    private void Seed(int count = 1)
    {
        Directory.CreateDirectory(_area); using var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>")); XmlFragmentImporter.Import(input, Source);
        using var source = EmbeddedXmlDatabase.Open(Source);
        for (var i = 0; i < count; i++) { using var read = source.BeginRead(); using var tx = source.BeginWrite(); tx.ReplaceNodeValue(Target(read), "new-" + i); tx.Commit(); }
        using var selected = source.BeginRead();
    }
    private static ulong Target(ImmutableXmlSnapshot snapshot) => Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();
    private Dictionary<string, byte[]> Bytes()
    {
        var result = new Dictionary<string, byte[]>();
        foreach (var path in Directory.GetFiles(_area, "*", SearchOption.AllDirectories).Where(p => Path.GetFileName(p) is not ("owner.lock" or "authority.lock" or "writer.lock")))
        {
            using var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            var bytes = new byte[(int)file.Length]; file.ReadExactly(bytes); result.Add(Path.GetRelativePath(_area, path), bytes);
        }
        return result;
    }
    private void AssertBytes(Dictionary<string, byte[]> before)
    {
        var after = Bytes(); Assert.Equal(before.Keys.Order(), after.Keys.Order()); foreach (var pair in before) Assert.Equal(pair.Value, after[pair.Key]);
    }


    /// <summary>Every retained placement pass occurs outside all monitors while all three real owners remain held.</summary>
    /// <param name="mode">Whether to inspect or append through actual retained execution.</param>
    [Theory]
    [InlineData("inspect")]
    [InlineData("append")]
    public void Preflight_AllRetainedPhases_ProtectedPathsUnlockedAndAuthoritySerialized(string mode)
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent); using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); var before = Bytes();
        var probe = new Probe(source, parent, authority, Source, Host, Authority);
        using var plan = authority.PrepareRetainedFirstEnrollmentCore(freeze, capture, evidence, new LocalEnrollmentSourceLeaseClose(), probe);
        Assert.Equal(4, probe.AuthorityReads); Assert.Equal(12, probe.ProtectedReads); Assert.Equal(new[] { Capture, Host, Source }.Order(), probe.Paths.Order());
        if (mode == "inspect")
        {
            using var execution = authority.TryArmRetainedFirstEnrollment(plan, evidence); Assert.NotNull(execution); Assert.True(execution.Inspect().WritersMustRemainStopped); AssertBytes(before);
        }
        else
        {
            var io = new CheckingIo(probe, source, parent, authority); var result = authority.AppendFirstEnrollmentCore(plan, evidence, io); Assert.Equal(ApplicationEnrollmentAppendDisposition.AcknowledgedStopped, result.Disposition); Assert.Equal(1, io.Writes); Assert.Equal(24, io.PathsAtWrite); before[Path.Combine("authority", "authority.log")] = ReadLog(); AssertBytes(before);
        }
        Assert.Equal(24, probe.ProtectedReads); Assert.Equal(8, probe.AuthorityReads); Assert.True(source.EnrollmentOwnershipStatus.StopLatched); Assert.Equal(0, authority.ActiveInspections);
        output.WriteLine("ER002_PHASES mode=" + mode + " protectedPaths=24 authorityBoundaries=8 allPlacementUnlocked=true retainedBeforeInspection=true");
    }

    /// <summary>Authority mutation at the last unlocked placement boundary is rejected by the following serialized check.</summary>
    /// <param name="mutation">Invalid authority state to retain.</param>
    /// <param name="afterArm">Whether the original source was already latched stopped.</param>
    [Theory]
    [InlineData("valid-head", false)]
    [InlineData("torn-head", false)]
    [InlineData("metadata", false)]
    [InlineData("namespace", false)]
    [InlineData("owner-length", false)]
    [InlineData("valid-head", true)]
    [InlineData("torn-head", true)]
    [InlineData("metadata", true)]
    [InlineData("namespace", true)]
    [InlineData("owner-length", true)]
    public void Preflight_AuthorityChangesAfterPlacement_RejectsWithoutWriteOrAdoption(string mutation, bool afterArm)
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent); using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); var probe = new Probe(source, parent, authority, Source, Host, Authority);
        using var plan = authority.PrepareRetainedFirstEnrollmentCore(freeze, capture, evidence, new LocalEnrollmentSourceLeaseClose(), probe); Dictionary<string, byte[]>? invalid = null; string[]? inventory = null;
        void InstallMutation()
        {
            var target = probe.AuthorityReads + 2;
            probe.OnAuthority = count =>
            {
                if (count != target) return;
                var roles = (FileStream[])Field(authority, "_roles");
                if (mutation == "namespace") File.WriteAllText(Path.Combine(Authority, "unexpected"), "retain");
                else if (mutation == "metadata") { roles[1].Position = 0; roles[1].WriteByte(0); roles[1].Flush(); }
                else if (mutation == "owner-length") { roles[0].Position = 0; roles[0].WriteByte(1); roles[0].Flush(); }
                else
                {
                    var metadata = ApplicationAuthorityCodec.DecodeMetadata(ApplicationAuthorityCodec.EncodeMetadata(Configuration), Configuration); var frame = ApplicationAuthorityCodec.EncodeFrame(metadata, 1, new string('0', 64), plan.Description.Entry); roles[2].Position = 0; roles[2].Write(mutation == "valid-head" ? frame : frame[..17]); roles[2].Flush();
                }
                invalid = Bytes(); inventory = Inventory();
            };
        }
        if (!afterArm) InstallMutation();
        var io = new CheckingIo(probe, source, parent, authority); var result = authority.AppendFirstEnrollmentCore(plan, evidence, io, stage => { if (afterArm && stage == ApplicationEnrollmentAppendStage.Armed) InstallMutation(); });
        Assert.Equal(ApplicationEnrollmentAppendDisposition.RefusedBeforeWrite, result.Disposition); Assert.False(result.PossibleOutput); Assert.False(result.ReleaseUnknown); Assert.IsType<InvalidDataException>(result.Error); Assert.Equal(0, io.Writes); Assert.True(plan.Consumed); Assert.Equal(afterArm, source.EnrollmentOwnershipStatus.StopLatched); Assert.False(source.EnrollmentOwnershipStatus.HasRetainer); Assert.True(authority.IsFaulted); Assert.Null(authority.ConfirmedEnrollment); Assert.Empty(authority.History.Frames); Assert.NotNull(invalid); AssertBytes(invalid); Assert.Equal(inventory, Inventory());
    }

    /// <summary>Owner closing can finish on another thread during protected-path inspection without releasing actual children.</summary>
    /// <param name="which">Closing owner or all three.</param>
    [Theory]
    [InlineData("source")]
    [InlineData("authority")]
    [InlineData("parent")]
    [InlineData("all")]
    public void Preflight_ClosingDuringProtectedRead_DrainsWithoutOutput(string which)
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent); using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); var before = Bytes(); var inventory = Inventory(); var probe = new Probe(source, parent, authority, Source, Host, Authority); var ran = false; Exception? error = null;
        probe.OnPath = path =>
        {
            if (ran || path != Source) return; ran = true;
            var worker = new Thread(() =>
            {
                try
                {
                    if (which is "source" or "all") source.Dispose(); if (which is "authority" or "all") authority.Dispose(); if (which is "parent" or "all") parent.Dispose();
                    Assert.True(source.EnrollmentOwnershipStatus.HasRetainer); Assert.False(authority.IsReleased); Assert.False(parent.IsReleased);
                    foreach (var role in new[] { Path.Combine(Source, ".transactions", "writer.lock"), Path.Combine(Authority, "authority.lock"), Path.Combine(Host, "owner.lock") }) Assert.Throws<IOException>(() => { using var blocked = new FileStream(role, FileMode.Open, FileAccess.ReadWrite, FileShare.None); });
                }
                catch (Exception caught) { error = caught; }
            })
            { IsBackground = true };
            worker.Start(); Assert.True(worker.Join(TimeSpan.FromSeconds(30))); Assert.Null(error);
        };
        Assert.Throws<ObjectDisposedException>(() => authority.PrepareRetainedFirstEnrollmentCore(freeze, capture, evidence, new LocalEnrollmentSourceLeaseClose(), probe)); Assert.True(ran); Assert.True(authority.IsFaulted); Assert.False(source.EnrollmentOwnershipStatus.HasRetainer); Assert.False(source.EnrollmentOwnershipStatus.StopLatched); Assert.Equal(0, authority.ActiveInspections); AssertBytes(before); Assert.Equal(inventory, Inventory());
    }
    /// <summary>Explicit freeze disposal keeps exclusion until the actual unarmed child drains, without authority output.</summary>
    [Fact]
    public void Preflight_FreezeClosedDuringProtectedRead_UnarmedDrainHonorsExplicitRelease()
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent); using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); var before = Bytes(); var inventory = Inventory(); var probe = new Probe(source, parent, authority, Source, Host, Authority); var ran = false;
        probe.OnPath = path =>
        {
            if (ran || path != Source) return; ran = true; freeze.Dispose(); Assert.True(source.EnrollmentOwnershipStatus.HasRetainer); Assert.Throws<InvalidOperationException>(() => source.BeginWrite());
        };
        Assert.Throws<ObjectDisposedException>(() => authority.PrepareRetainedFirstEnrollmentCore(freeze, capture, evidence, new LocalEnrollmentSourceLeaseClose(), probe)); Assert.True(ran); Assert.False(source.EnrollmentOwnershipStatus.HasRetainer); Assert.False(source.EnrollmentOwnershipStatus.StopLatched); Assert.Equal(0, authority.ActiveInspections);
        using (source.BeginWrite()) { }
        AssertBytes(before); Assert.Equal(inventory, Inventory());
    }
    /// <summary>Source closing before registration cannot acquire a retainer or start protected-path inspection.</summary>
    [Fact]
    public void Preflight_SourceAlreadyClosed_NoRegistrationOrProtectedInspection()
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent); using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); source.Dispose(); var before = Bytes(); var probe = new Probe(source, parent, authority, Source, Host, Authority);
        Assert.Throws<ObjectDisposedException>(() => authority.PrepareRetainedFirstEnrollmentCore(freeze, capture, evidence, new LocalEnrollmentSourceLeaseClose(), probe)); Assert.Equal(0, probe.ProtectedReads); Assert.Equal(0, probe.AuthorityReads); Assert.False(source.EnrollmentOwnershipStatus.HasRetainer); Assert.Equal(0, authority.ActiveInspections); AssertBytes(before);
    }
    /// <summary>Capture bytes changed during unlocked placement are preserved and rejected without recapture or repair.</summary>
    [Fact]
    public void Preflight_CaptureChangedDuringPlacement_RejectsWithoutRepair()
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent); using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); var probe = new Probe(source, parent, authority, Source, Host, Authority); Dictionary<string, byte[]>? invalid = null; string[]? inventory = null;
        probe.OnPath = path => { if (path != Capture || invalid is not null) return; File.AppendAllText(Path.Combine(Capture, "inventory.bin"), "retain invalid bytes"); invalid = Bytes(); inventory = Inventory(); };
        Assert.Throws<InvalidDataException>(() => authority.PrepareRetainedFirstEnrollmentCore(freeze, capture, evidence, new LocalEnrollmentSourceLeaseClose(), probe)); Assert.True(authority.IsFaulted); Assert.False(source.EnrollmentOwnershipStatus.HasRetainer); Assert.False(source.EnrollmentOwnershipStatus.StopLatched); Assert.NotNull(invalid); AssertBytes(invalid); Assert.Equal(inventory, Inventory());
    }

    private string[] Inventory() => Directory.GetFileSystemEntries(_area, "*", SearchOption.AllDirectories).Order().ToArray();
    private byte[] ReadLog() { using var stream = new FileStream(Path.Combine(Authority, "authority.log"), FileMode.Open, FileAccess.Read, FileShare.ReadWrite); var bytes = new byte[(int)stream.Length]; stream.ReadExactly(bytes); return bytes; }
    private static object Field(object owner, string name) => owner.GetType().GetField(name, BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(owner)!;
    private sealed class Probe(EmbeddedXmlDatabase source, EmbeddedHostLifetime parent, ApplicationAuthorityLifetime authority, string sourceRoot, string parentRoot, string authorityRoot) : IRetainedEnrollmentPreflightProbe
    {
        internal int ProtectedReads { get; private set; }
        internal int AuthorityReads { get; private set; }
        internal HashSet<string> Paths { get; } = [];
        internal Action<string>? OnPath { get; set; }
        internal Action<int>? OnAuthority { get; set; }
        private void AssertUnlockedAndHeld()
        {
            foreach (var gate in new[] { Field(source, "_gate"), Field(parent, "_gate"), Field(parent, "_appendGate"), Field(authority, "_gate"), Field(authority, "_readGate") }) Assert.False(Monitor.IsEntered(gate));
            Assert.True(source.EnrollmentOwnershipStatus.HasRetainer); Assert.Equal(1, authority.ActiveInspections);
            foreach (var path in new[] { Path.Combine(sourceRoot, ".transactions", "writer.lock"), Path.Combine(parentRoot, "owner.lock"), Path.Combine(authorityRoot, "authority.lock") }) Assert.Throws<IOException>(() => { using var blocked = new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None); });
        }
        /// <inheritdoc/>
        public void BeforeProtectedPathRead(string path) { AssertUnlockedAndHeld(); ProtectedReads++; Paths.Add(path); OnPath?.Invoke(path); }
        /// <inheritdoc/>
        public void BeforeAuthorityRead() { AssertUnlockedAndHeld(); AuthorityReads++; OnAuthority?.Invoke(AuthorityReads); }
    }
    private sealed class CheckingIo(Probe probe, EmbeddedXmlDatabase source, EmbeddedHostLifetime parent, ApplicationAuthorityLifetime authority) : IApplicationAuthorityAppendIo
    {
        private readonly object _readGate = Field(authority, "_readGate");
        private readonly object[] _otherGates = [Field(source, "_gate"), Field(parent, "_gate"), Field(parent, "_appendGate"), Field(authority, "_gate")];
        internal int Writes { get; private set; }
        internal int PathsAtWrite { get; private set; }
        private void Check() { Assert.True(Monitor.IsEntered(_readGate)); foreach (var gate in _otherGates) Assert.False(Monitor.IsEntered(gate)); Assert.Equal(PathsAtWrite, probe.ProtectedReads); }
        /// <inheritdoc/>
        public void Write(FileStream stream, ReadOnlySpan<byte> bytes) { Writes++; PathsAtWrite = probe.ProtectedReads; Check(); stream.Write(bytes); }
        /// <inheritdoc/>
        public void Flush(FileStream stream) { Check(); stream.Flush(true); }
        /// <inheritdoc/>
        public void ReadBack(FileStream stream, Span<byte> bytes) { Check(); stream.ReadExactly(bytes); }
    }
    /// <summary>Removes only the fresh owned fixture tree after all retained operations and handles drain.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
