// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Sweeps epoch capture and restore persistence boundaries with real partial writes.
// SPECIAL NOTES        : Injected I/O failures; native Linux durability delegation is tested explicitly.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================


using System.Text;
using Bosak.XmlDb.Core;
using Xunit;
using Xunit.Abstractions;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Exercises every observed persistence boundary without modifying original inputs.</summary>
public sealed class EpochBackupFaultTests(ITestOutputHelper output) : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-et9d-" + Guid.NewGuid().ToString("N"));

    /// <summary>Sweeps capture and restore with process, modeled strong, or actual Linux durability.</summary>
    /// <param name="restore">Whether to restore a sealed artifact.</param>
    /// <param name="mode">Process, modeled strong, or native Linux delegation.</param>
    /// <param name="fault">Before, after, or real partial-write failure.</param>
    [Theory]
    [InlineData(false, 0, "before")]
    [InlineData(false, 0, "after")]
    [InlineData(false, 0, "partial")]
    [InlineData(false, 1, "before")]
    [InlineData(false, 1, "after")]
    [InlineData(false, 1, "partial")]
    [InlineData(false, 2, "before")]
    [InlineData(false, 2, "after")]
    [InlineData(false, 2, "partial")]
    [InlineData(true, 0, "before")]
    [InlineData(true, 0, "after")]
    [InlineData(true, 0, "partial")]
    [InlineData(true, 1, "before")]
    [InlineData(true, 1, "after")]
    [InlineData(true, 1, "partial")]
    [InlineData(true, 2, "before")]
    [InlineData(true, 2, "after")]
    [InlineData(true, 2, "partial")]
    public void EveryPersistenceFault_PreservesInputsAndPublication(bool restore, int mode, string fault)
    {
        if (mode == 2 && !OperatingSystem.IsLinux()) { output.WriteLine("Native Linux sweep not executed on this platform."); return; }
        Directory.CreateDirectory(_area);
        var source = Path.Combine(_area, "source"); var root = Path.Combine(_area, "epoch");
        using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>")))
            XmlFragmentImporter.Import(input, source);
        EpochEmptyRoot.CreateFixture(source, root, 1, new LocalTransactionStorage());
        using (var owner = EpochScalarCoordinator.Open(root))
        {
            using var read = owner.BeginRead(); using var tx = owner.BeginTransaction();
            tx.ReplaceNodeValue(Target(read), "new"); tx.Commit();
            owner.CreateBackup(Path.Combine(_area, "input"));
        }
        var backup = Path.Combine(_area, "input"); var original = Bytes(root); var sealedBytes = Bytes(backup);
        var recording = Storage(mode); var reference = Path.Combine(_area, "reference");
        Run(restore, root, backup, reference, recording, null, false);
        var positions = recording.Calls.Select((call, index) => (call, index))
            .Where(item => fault == "partial" ? item.call.Operation == "WriteFile" && item.call.Moment == "before" : item.call.Moment == fault)
            .Select(item => item.index).ToArray();
        Assert.NotEmpty(positions);
        foreach (var index in positions)
        {
            var destination = Path.Combine(_area, "attempt-" + index); var storage = Storage(mode);
            Run(restore, root, backup, destination, storage, index, fault == "partial");
            Assert.True(storage.Fired); AssertBytes(original, root); AssertBytes(sealedBytes, backup);
            if (Directory.Exists(destination))
            {
                if (restore)
                {
                    var store = Path.Combine(destination, "store");
                    var origin = EpochBackupCodec.ValidateOriginHeaders(File.ReadAllBytes(Path.Combine(destination, "origin.bin")),
                        File.ReadAllBytes(Path.Combine(backup, "inventory.bin")), File.ReadAllBytes(Path.Combine(store, "FORMAT")),
                        File.ReadAllBytes(Path.Combine(store, ".transactions", "CURRENT")));
                    Assert.NotEqual(origin.Source.Identity, origin.Destination);
                    for (var repeat = 0; repeat < 2; repeat++) VerifyStore(store);
                }
                else
                {
                    var inventory = EpochBackupStorage.ReadArtifact(destination);
                    var workspace = EpochBackupStorage.Workspace(Path.Combine(_area, "verify-" + index), new LocalTransactionStorage());
                    EpochBackupStorage.VerifyCopies(Path.Combine(destination, "data"), workspace, inventory, new LocalTransactionStorage());
                    EpochBackupStorage.RemoveWorkspace(workspace, new LocalTransactionStorage());
                }
            }
            VerifyStore(root);
            // Exclusive file opens expose leaked clone/source handles before fixture cleanup on Windows.
            foreach (var path in Directory.GetFiles(_area, "*", SearchOption.AllDirectories))
                using (new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) { }
            foreach (var directory in Directory.GetDirectories(_area, ".xmldb-epoch-backup-*")) Directory.Delete(directory, true);
            if (Directory.Exists(destination)) Directory.Delete(destination, true);
        }
        output.WriteLine($"et9d-{(restore ? "restore" : "capture")}-{mode}/{fault}: {positions.Length} fault positions verified.");
    }

    private static void Run(bool restore, string root, string backup, string destination, FaultingTransactionStorage storage, int? index, bool partial)
    {
        if (restore)
        {
            storage.Arm(index, partial);
            if (index is null) EpochBackupRestore.Restore(backup, destination, storage);
            else Assert.Throws<IOException>(() => EpochBackupRestore.Restore(backup, destination, storage));
        }
        else
        {
            using var owner = EpochScalarCoordinator.Open(root, storage); using var pinned = owner.BeginRead(0);
            storage.Arm(index, partial);
            if (index is null) owner.CreateBackup(destination);
            else
            {
                Assert.Throws<IOException>(() => owner.CreateBackup(destination));
                Assert.Throws<InvalidOperationException>(() => owner.BeginRead());
            }
            Assert.Equal("new", pinned.ReadValue(Target(pinned)));
        }
    }
    private static FaultingTransactionStorage Storage(int mode)
    {
        var storage = new FaultingTransactionStorage(mode == 0 ? DurabilityMode.ProcessCrash : DurabilityMode.FileAndDirectoryFlush, mode == 2);
        Assert.Equal(mode == 2 ? DurabilityMode.FileAndDirectoryFlush : DurabilityMode.ProcessCrash, storage.EffectiveDurability);
        return storage;
    }
    private static void VerifyStore(string root)
    {
        using var owner = EpochScalarCoordinator.Open(root); using var read = owner.BeginRead();
        Assert.Equal(1UL, read.CommitSequence); Assert.Equal("new", read.ReadValue(Target(read)));
        using var admission = EpochAdmission.Acquire(root, owner.Identity, profile: EpochProfile.ScalarWal);
        var binding = EpochEmptyCoordinator.ReadAuthority(root, owner.Identity, true);
        using var old = EpochScalarHistory.Open(root, 0, admission, binding.BaseHash);
        Assert.Equal("old", old.ReadValue(Target(old)));
    }
    private static ulong Target(ImmutableXmlSnapshot snapshot) => Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id))
        .Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();
    private static Dictionary<string, byte[]> Bytes(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories)
        .ToDictionary(path => Path.GetRelativePath(root, path), File.ReadAllBytes);
    private static void AssertBytes(Dictionary<string, byte[]> expected, string root)
    {
        var actual = Bytes(root); Assert.Equal(expected.Keys.Order(), actual.Keys.Order());
        foreach (var entry in expected) Assert.Equal(entry.Value, actual[entry.Key]);
    }
    /// <summary>Deletes isolated test-owned data after all handles have closed.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}

