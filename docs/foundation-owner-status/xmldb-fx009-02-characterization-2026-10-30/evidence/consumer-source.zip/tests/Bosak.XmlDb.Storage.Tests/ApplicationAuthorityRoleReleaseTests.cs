// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 30 October 2026
// PURPOSE              : Qualifies direct authority and parent role-close uncertainty under retained enrollment.
// SPECIAL NOTES        : ER-003 managed before/after/no-op faults; no physical release or retry authority inferred.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 30-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Reflection;
using System.Text;
using Bosak.XmlDb.Core;
using Microsoft.Win32.SafeHandles;
using Xunit;
using Xunit.Abstractions;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Qualifies direct authority and parent role-close uncertainty under retained enrollment.</summary>
/// <param name="output">Captures per-role close-fault qualification evidence.</param>
public sealed class ApplicationAuthorityRoleReleaseTests(ITestOutputHelper output) : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-er003-" + Guid.NewGuid().ToString("N"));
    /// <summary>Enumerates every owned role, actual close boundary and enrollment output state.</summary>
    /// <returns>Thirty-six deterministic role/mode/arm rows.</returns>
    public static IEnumerable<object[]> CloseFaults()
    {
        foreach (var role in new[] { "authority.log", "authority.meta", "authority.lock", "journal.bin", "host.meta", "owner.lock" })
            foreach (var mode in new[] { "before", "after", "noop" })
                foreach (var afterArm in new[] { false, true }) yield return [role, mode, afterArm];
    }
    /// <summary>Unknown role close suppresses acknowledgment, retains exact bytes and never retries or infers physical ownership.</summary>
    /// <param name="role">Original authority or parent role to fault.</param>
    /// <param name="mode">Failure before close, after actual close or without delegation.</param>
    /// <param name="afterArm">Whether closing follows source arm and permits frame publication.</param>
    [Theory]
    [MemberData(nameof(CloseFaults))]
    public void Append_RoleCloseUnconfirmed_ReportsUncertainWithoutReceiptOrRetry(string role, string mode, bool afterArm)
    {
        using var f = new Fixture(_area, role, mode); var before = f.Bytes(); var inventory = f.Inventory();
        var result = f.Authority.AppendFirstEnrollmentCore(f.Plan, f.Evidence, new Io(), stage => { if (stage == (afterArm ? ApplicationEnrollmentAppendStage.Armed : ApplicationEnrollmentAppendStage.BeforeArm)) f.CloseWrappers(); });
        Assert.Equal(ApplicationEnrollmentAppendDisposition.Uncertain, result.Disposition); Assert.Equal(afterArm, result.PossibleOutput); Assert.True(result.ReleaseUnknown); Assert.NotNull(result.Error); Assert.Null(result.Receipt); Assert.Null(f.Authority.ConfirmedEnrollment); Assert.True(f.Authority.IsFaulted); Assert.True(f.Plan.Consumed); Assert.Equal(0, f.Authority.ActiveInspections); Assert.True(f.Source.WhenEnrollmentOwnershipReleased.IsCompletedSuccessfully); Assert.Equal(afterArm, f.Source.EnrollmentOwnershipStatus.StopLatched);
        var authorityFault = role.StartsWith("authority.", StringComparison.Ordinal); var failing = authorityFault ? f.AuthorityClose : f.ParentClose;
        Assert.Equal(new[] { "authority.log", "authority.meta", "authority.lock" }, f.AuthorityClose.Calls);
        if (authorityFault)
        {
            Assert.True(f.Authority.WhenReleased.IsFaulted); Assert.False(f.Authority.IsReleased); Assert.False(f.Parent.WhenReleased.IsCompleted); Assert.Equal(1, f.Parent.ActiveOperations); Assert.Empty(f.ParentClose.Calls);
            Assert.Throws<IOException>(() => { using var blocked = new FileStream(Path.Combine(f.Host, "owner.lock"), FileMode.Open, FileAccess.ReadWrite, FileShare.None); });
        }
        else
        {
            Assert.True(f.Authority.WhenReleased.IsCompletedSuccessfully); Assert.True(f.Authority.IsReleased); Assert.True(f.Parent.WhenReleased.IsFaulted); Assert.False(f.Parent.IsReleased); Assert.Equal(0, f.Parent.ActiveOperations); Assert.Equal(new[] { "journal.bin", "host.meta", "owner.lock" }, f.ParentClose.Calls);
        }
        Assert.Equal(mode == "after", failing.Handles[role].IsClosed); Assert.Single(failing.Calls, r => r == role);
        // The fixture knows the injected physical effect. Product results remain release-unknown
        // even when an after-close failure left every role physically available.
        var path = Path.Combine(authorityFault ? f.AuthorityRoot : f.Host, role);
        if (mode == "after") { using var available = new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None); }
        else Assert.Throws<IOException>(() => { using var blocked = new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None); });
        Assert.Equal("writer.lock", f.Events[0]); Assert.Single(f.SourceClose.Calls);
        if (afterArm)
        {
            var bytes = f.ReadLog(); var metadata = ApplicationAuthorityCodec.DecodeMetadata(ApplicationAuthorityCodec.EncodeMetadata(f.Configuration), f.Configuration); Assert.Equal(f.Plan.Description.Entry, Assert.Single(ApplicationAuthorityCodec.DecodeJournal(bytes, metadata).Frames).Entry); before[Path.Combine("authority", "authority.log")] = bytes;
        }
        else Assert.Empty(f.ReadLog());
        f.AssertBytes(before); Assert.Equal(inventory, f.Inventory()); Assert.Equal("new-0", f.Snapshot.ReadValue(Target(f.Snapshot)));
        var attempts = f.Events.ToArray(); f.CloseWrappers(); f.Authority.Dispose(); f.Parent.Dispose(); f.Plan.Dispose(); Assert.Equal(attempts, f.Events);
        Assert.Throws<InvalidOperationException>(() => f.Authority.AppendFirstEnrollment(f.Plan, f.Evidence)); Assert.Throws<ObjectDisposedException>(() => f.Parent.BeginReconciliationOperation()); f.AssertBytes(before);
        output.WriteLine("ER003_CLOSE role=" + role + " mode=" + mode + " afterArm=" + afterArm + " possibleOutput=" + result.PossibleOutput + " releaseUnknown=true receipt=false noRetry=true");
    }
    /// <summary>Actual confirmed closes run source first, then authority, then parent and permit only the qualified stopped outcome.</summary>
    /// <param name="afterArm">Whether a frame was admitted.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Append_ConfirmedClose_ControlPreservesOrderAndOutcome(bool afterArm)
    {
        using var f = new Fixture(_area); var result = f.Authority.AppendFirstEnrollmentCore(f.Plan, f.Evidence, new Io(), stage => { if (stage == (afterArm ? ApplicationEnrollmentAppendStage.Armed : ApplicationEnrollmentAppendStage.BeforeArm)) f.CloseWrappers(); });
        Assert.Equal(afterArm ? ApplicationEnrollmentAppendDisposition.AcknowledgedStopped : ApplicationEnrollmentAppendDisposition.RefusedBeforeWrite, result.Disposition); Assert.False(result.ReleaseUnknown); Assert.Equal(afterArm, result.PossibleOutput); Assert.Equal(afterArm, result.Receipt is not null); Assert.True(f.Authority.WhenReleased.IsCompletedSuccessfully); Assert.True(f.Parent.WhenReleased.IsCompletedSuccessfully);
        Assert.Equal(new[] { "writer.lock", "authority.log", "authority.meta", "authority.lock", "journal.bin", "host.meta", "owner.lock" }, f.Events); Assert.Equal("new-0", f.Snapshot.ReadValue(Target(f.Snapshot)));
    }
    /// <summary>A later independent owner-close failure reports on its task without rewriting a previously qualified append receipt.</summary>
    /// <param name="authorityFault">Whether authority or parent close fails after real delegation.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Append_LiveOwnersCloseLater_DoesNotInventOrRetractPastAcknowledgment(bool authorityFault)
    {
        using var f = new Fixture(_area, authorityFault ? "authority.lock" : "owner.lock", "after"); var result = f.Authority.AppendFirstEnrollment(f.Plan, f.Evidence); Assert.Equal(ApplicationEnrollmentAppendDisposition.AcknowledgedStopped, result.Disposition); Assert.NotNull(result.Receipt); Assert.Empty(f.Events);
        var receipt = result.Receipt; f.CloseWrappers(); Assert.Equal(receipt, f.Authority.ConfirmedEnrollment); Assert.Equal(ApplicationEnrollmentAppendDisposition.AcknowledgedStopped, result.Disposition); Assert.False(result.ReleaseUnknown);
        Assert.True(authorityFault ? f.Authority.WhenReleased.IsFaulted : f.Parent.WhenReleased.IsFaulted); var attempts = f.Events.ToArray(); f.CloseWrappers(); Assert.Equal(attempts, f.Events); Assert.Throws<InvalidOperationException>(() => f.Authority.AppendFirstEnrollment(f.Plan, f.Evidence));
    }
    /// <summary>Authority release failure keeps the actual parent registration even when its physical authority handles closed.</summary>
    [Fact]
    public void Append_AuthorityAndParentFaultConfigured_ParentCloseNeverStartsEarly()
    {
        using var f = new Fixture(_area, "authority.log", "after", parentFault: "journal.bin"); var result = f.Authority.AppendFirstEnrollmentCore(f.Plan, f.Evidence, new Io(), stage => { if (stage == ApplicationEnrollmentAppendStage.Armed) f.CloseWrappers(); });
        Assert.Equal(ApplicationEnrollmentAppendDisposition.Uncertain, result.Disposition); Assert.True(f.Authority.WhenReleased.IsFaulted); Assert.Empty(f.ParentClose.Calls); Assert.False(f.Parent.WhenReleased.IsCompleted); Assert.Equal(1, f.Parent.ActiveOperations); Assert.All(f.AuthorityClose.Handles.Values, h => Assert.True(h.IsClosed)); Assert.Null(result.Receipt);
    }
    /// <summary>Pending-plan disposal reports parent close failure without any append dispatch or authority output.</summary>
    [Fact]
    public void PendingPlan_DisposeWithParentCloseFault_ThrowsWithoutWritingOrRetrying()
    {
        using var f = new Fixture(_area, "host.meta", "before"); var before = f.Bytes(); f.CloseWrappers(); Assert.Throws<IOException>(f.Plan.Dispose); Assert.True(f.Parent.WhenReleased.IsFaulted); Assert.True(f.Authority.WhenReleased.IsCompletedSuccessfully); Assert.False(f.Plan.Consumed); Assert.True(f.Plan.Disposed); Assert.Null(f.Authority.ConfirmedEnrollment); Assert.Empty(f.ReadLog()); f.AssertBytes(before);
        var attempts = f.Events.ToArray(); f.Plan.Dispose(); f.CloseWrappers(); Assert.Equal(attempts, f.Events); Assert.Throws<InvalidOperationException>(() => f.Authority.AppendFirstEnrollment(f.Plan, f.Evidence));
    }
    private static object Field(object owner, string name) => owner.GetType().GetField(name, BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(owner)!;
    private static ulong Target(ImmutableXmlSnapshot snapshot) => Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();
    private sealed class Closer(List<string> events, string? target = null, string mode = "before") : IRetainedRoleLeaseClose, IEnrollmentSourceLeaseClose
    {
        internal List<string> Calls { get; } = [];
        internal Dictionary<string, SafeFileHandle> Handles { get; } = [];
        internal Action? Check { get; set; }
        /// <inheritdoc/>
        public void Close(FileStream stream)
        {
            Check?.Invoke(); var role = Path.GetFileName(stream.Name); Calls.Add(role); events.Add(role); Handles.Add(role, stream.SafeFileHandle);
            if (role == target && mode == "before") throw new IOException("Injected role close failure before delegation: " + role);
            if (role == target && mode == "noop") return;
            stream.Dispose(); if (role == target && mode == "after") throw new IOException("Injected role close failure after actual close: " + role);
        }
    }
    private sealed class Io : IApplicationAuthorityAppendIo
    {
        /// <inheritdoc/>
        public void Write(FileStream stream, ReadOnlySpan<byte> bytes) => stream.Write(bytes);
        /// <inheritdoc/>
        public void Flush(FileStream stream) => stream.Flush(true);
        /// <inheritdoc/>
        public void ReadBack(FileStream stream, Span<byte> bytes) => stream.ReadExactly(bytes);
    }
    private sealed class Fixture : IDisposable
    {
        private readonly string _area;
        private readonly FileStream[] _actualRoles;
        internal string SourceRoot => Path.Combine(_area, "source");
        internal string Host => Path.Combine(_area, "host");
        internal string AuthorityRoot => Path.Combine(_area, "authority");
        private string Capture => Path.Combine(_area, "capture");
        internal List<string> Events { get; } = [];
        internal Closer SourceClose { get; }
        internal Closer AuthorityClose { get; }
        internal Closer ParentClose { get; }
        internal EmbeddedXmlDatabase Source { get; }
        internal ImmutableXmlSnapshot Snapshot { get; }
        internal EmbeddedHostLifetime Parent { get; }
        internal ApplicationAuthorityLifetime Authority { get; }
        internal MigrationSourceFreeze Freeze { get; }
        internal ApplicationAuthorityLifetime.RetainedEnrollmentPreparation Plan { get; }
        internal ApplicationEnrollmentEvidence Evidence { get; }
        internal ApplicationAuthorityConfiguration Configuration { get; }
        internal Fixture(string area, string? fault = null, string mode = "before", string? parentFault = null)
        {
            _area = area; Directory.CreateDirectory(area); using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, SourceRoot);
            using (var initial = EmbeddedXmlDatabase.Open(SourceRoot)) { using var read = initial.BeginRead(); using var tx = initial.BeginWrite(); tx.ReplaceNodeValue(Target(read), "new-0"); tx.Commit(); }
            Source = EmbeddedXmlDatabase.Open(SourceRoot); Snapshot = Source.BeginRead(); var admin = Guid.NewGuid(); Configuration = new(Guid.NewGuid(), admin, "pilot", "orders", "admin", "authority");
            Directory.CreateDirectory(Host); File.WriteAllBytes(Path.Combine(Host, "owner.lock"), []); File.WriteAllBytes(Path.Combine(Host, "host.meta"), HostJournalCodec.EncodeMetadata(admin, "pilot", "orders")); File.WriteAllBytes(Path.Combine(Host, "journal.bin"), []);
            SourceClose = new(Events); AuthorityClose = new(Events, fault?.StartsWith("authority.", StringComparison.Ordinal) == true ? fault : null, mode); ParentClose = new(Events, parentFault ?? (fault?.StartsWith("authority.", StringComparison.Ordinal) == false ? fault : null), mode);
            Parent = EmbeddedHostLifetime.OpenExistingCore(Host, "pilot", "orders", [SourceRoot, Capture, AuthorityRoot], DurabilityMode.ProcessCrash, ParentClose);
            Authority = ApplicationAuthorityLifetime.ProvisionCore(Parent, Parent.JournalStatus.KnownPosition, new(Parent.Context, true, true, true, true, true), AuthorityRoot, Configuration, new Dictionary<string, string> { ["admin"] = Host, ["authority"] = AuthorityRoot, ["source"] = SourceRoot, ["capture"] = Capture }, new(AuthorityRoot, true, true, true), new LocalTransactionStorage(), null, AuthorityClose);
            _actualRoles = [.. (FileStream[])Field(Authority, "_roles"), (FileStream)Field(Parent, "_journal"), (FileStream)Field(Parent, "_metadata"), (FileStream)Field(Parent, "_owner"), (FileStream)Field(Source, "_lease")];
            void Check() { Assert.False(Monitor.IsEntered(Field(Authority, "_readGate"))); Assert.False(Monitor.IsEntered(Field(Parent, "_appendGate"))); }
            SourceClose.Check = Check; AuthorityClose.Check = Check; ParentClose.Check = Check;
            Freeze = MigrationSourceFreeze.Acquire(Source, true); var capture = Freeze.Capture(Capture); Evidence = new(Parent.Context, Configuration.AuthorityId, "source", "source-admission", "capture", Guid.NewGuid(), new string('a', 64), true, true, true, true, true, true); Plan = Authority.PrepareRetainedFirstEnrollmentCore(Freeze, capture, Evidence, SourceClose);
        }
        internal void CloseWrappers() { Source.Dispose(); Freeze.Dispose(); Authority.Dispose(); Parent.Dispose(); }
        internal byte[] ReadLog() { using var stream = new FileStream(Path.Combine(AuthorityRoot, "authority.log"), FileMode.Open, FileAccess.Read, FileShare.ReadWrite); var bytes = new byte[(int)stream.Length]; stream.ReadExactly(bytes); return bytes; }
        internal Dictionary<string, byte[]> Bytes()
        {
            var result = new Dictionary<string, byte[]>();
            foreach (var path in Directory.GetFiles(_area, "*", SearchOption.AllDirectories).Where(p => Path.GetFileName(p) is not ("writer.lock" or "authority.lock" or "owner.lock")))
            { using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite); var bytes = new byte[(int)stream.Length]; stream.ReadExactly(bytes); result.Add(Path.GetRelativePath(_area, path), bytes); }
            return result;
        }
        internal void AssertBytes(Dictionary<string, byte[]> before) { var after = Bytes(); Assert.Equal(before.Keys.Order(), after.Keys.Order()); foreach (var pair in before) Assert.Equal(pair.Value, after[pair.Key]); }
        internal string[] Inventory() => Directory.GetFileSystemEntries(_area, "*", SearchOption.AllDirectories).Order().ToArray();
        /// <summary>Closes only fresh fixture handles without retrying adapters or changing logical release uncertainty.</summary>
        public void Dispose()
        {
            try { Plan.Dispose(); CloseWrappers(); }
            finally { Snapshot.Dispose(); foreach (var role in _actualRoles) role.Dispose(); }
        }
    }
    /// <summary>Removes only this fresh owned test tree after actual handles have been closed.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
