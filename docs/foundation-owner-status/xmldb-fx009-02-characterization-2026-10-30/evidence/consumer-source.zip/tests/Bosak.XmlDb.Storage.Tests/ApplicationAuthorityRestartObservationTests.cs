// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 30 October 2026
// PURPOSE              : Qualifies owned stopped restart observation and read-only source/capture correlation.
// SPECIAL NOTES        : Real reopened roots and sealed captures; no routing, recovery or handoff execution.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 30-10-2026     | Share reopened fixture with native identity and disposal qualification                     |
//                      | Charles Korthout | 0.1   | 30-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Text;
using Bosak.XmlDb.Core;
using Xunit;
using Xunit.Abstractions;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Qualifies owned stopped restart observation and read-only source/capture correlation.</summary>
/// <param name="output">Captures actual versus guarded qualification markers.</param>
public sealed partial class ApplicationAuthorityRestartObservationTests(ITestOutputHelper output) : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-sr2b-" + Guid.NewGuid().ToString("N"));

    /// <summary>Reopened real Enroll roots correlate a sealed capture without recreating its original freeze.</summary>
    /// <param name="commits">Source history length.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    public void Observe_RealEnrollment_StopsAndPreservesEverything(int commits)
    {
        using var f = new Fixture(_area, commits); var bytes = f.Bytes(); var inventory = f.Inventory();
        using var scope = f.Begin(); var result = scope.Observe();
        Assert.Equal(EnrollmentRestartDecision.ObservedEnrolledStopped, result.Assessment.Decision); Assert.True(result.WritersMustRemainStopped);
        Assert.Equal(result.Observations.EnrolledBaseline, result.Observations.ActualBaseline); Assert.NotEqual(Guid.Empty, result.ObservationId);
        Assert.Equal(EnrollmentRestartFact.Confirmed, result.Observations.Host!.OwnersReacquired); Assert.Equal(EnrollmentRestartFact.Confirmed, result.Observations.Host.SourceExcluded);
        Assert.Equal(commits == 0 ? "old" : "new-0", f.Snapshot.ReadValue(Target(f.Snapshot))); Assert.Null(f.Authority.ConfirmedEnrollment);
        Assert.Throws<InvalidOperationException>(() => scope.Observe()); Assert.Throws<InvalidOperationException>(() => f.Authority.Inspect());
        scope.Dispose(); Assert.Throws<InvalidOperationException>(() => f.Begin()); Assert.Throws<InvalidOperationException>(() => f.Source.BeginWrite());
        f.Preserved(bytes, inventory); Assert.NotEmpty(f.Probe.Paths); Assert.Equal(5, f.Probe.Stages.Count);
    }

    /// <summary>Empty and valid later histories are stopped observations without initializer or source claims.</summary>
    /// <param name="shape">Empty or valid transfer-containing history.</param>
    [Theory]
    [InlineData("empty")]
    [InlineData("later")]
    public void Observe_UnsupportedHistory_ReconcilesWithoutSourceAssociation(string shape)
    {
        using var f = new Fixture(_area, 0, shape); var bytes = f.Bytes(); var inventory = f.Inventory();
        using var scope = f.Begin(noSource: true); var result = scope.Observe();
        Assert.Equal(EnrollmentRestartDecision.ReconciliationRequired, result.Assessment.Decision);
        Assert.Equal(shape == "empty" ? EnrollmentRestartReason.EmptyReopen : EnrollmentRestartReason.UnsupportedHistory, result.Assessment.Reason);
        Assert.Equal(EnrollmentRestartFact.Unknown, result.Observations.Host!.SourceExcluded); Assert.False(f.Source.EnrollmentOwnershipStatus.StopLatched);
        Assert.Null(f.Authority.ConfirmedEnrollment); f.Preserved(bytes, inventory);
    }

    /// <summary>Known nonterminal administrative histories cannot be overridden by a confirmed caller flag.</summary>
    /// <param name="stage">Latest retained administrative stage.</param>
    [Theory]
    [InlineData("recorded")]
    [InlineData("dispatch")]
    [InlineData("uncertain")]
    [InlineData("observed")]
    [InlineData("absent")]
    public void Observe_AdministrativeHistory_DerivesReconciliationRequirement(string stage)
    {
        using var f = new Fixture(_area, adminStage: stage); var bytes = f.Bytes(); var inventory = f.Inventory();
        using var scope = f.Begin(); var result = scope.Observe();
        Assert.Equal(stage != "absent", result.AdministrativeReconciliationRequired);
        Assert.Equal(stage == "absent" ? EnrollmentRestartDecision.ObservedEnrolledStopped : EnrollmentRestartDecision.ReconciliationRequired, result.Assessment.Decision);
        Assert.Equal(stage == "absent" ? EnrollmentRestartFact.Confirmed : EnrollmentRestartFact.Unknown, result.Observations.Host!.PriorWorkReconciled);
        Assert.True(result.WritersMustRemainStopped); f.Preserved(bytes, inventory);
    }

    /// <summary>Missing source or capture cannot be upgraded by confirmed host assertions.</summary>
    /// <param name="sourceMissing">Whether source ownership is absent rather than capture mapping.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Observe_MissingBaselineEvidence_RequiresReconciliation(bool sourceMissing)
    {
        using var f = new Fixture(_area); using var scope = f.Begin(sourceMissing, sourceMissing ? f.Evidence : f.Evidence with { CaptureRootKey = null });
        var result = scope.Observe(); Assert.Equal(EnrollmentRestartDecision.ReconciliationRequired, result.Assessment.Decision);
        Assert.Equal(EnrollmentRestartReason.MissingObservation, result.Assessment.Reason); Assert.Null(result.Observations.ActualBaseline);
        Assert.Equal(EnrollmentRestartFact.Unknown, result.Observations.Host!.SourceExcluded);
    }

    /// <summary>Unknown prior work/release remains supplied uncertainty despite actual reacquired ownership.</summary>
    /// <param name="field">Operational fact not verified by filesystem proof.</param>
    /// <param name="contradictory">Whether evidence contradicts rather than lacks reconciliation.</param>
    [Theory]
    [InlineData("work", false)]
    [InlineData("work", true)]
    [InlineData("release", false)]
    [InlineData("release", true)]
    public void Observe_HostFacts_NeverBecomeVerifiedFromBytes(string field, bool contradictory)
    {
        using var f = new Fixture(_area); var fact = contradictory ? EnrollmentRestartFact.Contradictory : EnrollmentRestartFact.Unknown;
        using var scope = f.Begin(evidence: field == "work" ? f.Evidence with { PriorWorkReconciled = fact } : f.Evidence with { ReleaseReconciled = fact });
        var result = scope.Observe(); Assert.Equal(contradictory ? EnrollmentRestartDecision.Refused : EnrollmentRestartDecision.ReconciliationRequired, result.Assessment.Decision);
        Assert.Equal(EnrollmentRestartFact.Confirmed, result.Observations.Host!.OwnersReacquired); Assert.True(result.Assessment.WritersMustRemainStopped);
    }

    /// <summary>Valid newer source or independently published capture cannot replace the enrolled baseline.</summary>
    /// <param name="change">Source or capture differs coherently.</param>
    [Theory]
    [InlineData("source")]
    [InlineData("capture")]
    public void Observe_ChangedBaseline_ReconcilesWithoutAdoption(string change)
    {
        using var f = new Fixture(_area);
        if (change == "source") { using var tx = f.Source.BeginWrite(); tx.ReplaceNodeValue(Target(f.Snapshot), "newer"); tx.Commit(); }
        else f.Source.CreateBackup(f.OtherCapture);
        var bytes = f.Bytes(); var inventory = f.Inventory();
        using var scope = f.Begin(evidence: change == "capture" ? f.Evidence with { CaptureRootKey = "other-capture" } : f.Evidence);
        var result = scope.Observe(); Assert.Equal(EnrollmentRestartReason.BaselineMismatch, result.Assessment.Reason);
        Assert.Equal(EnrollmentRestartDecision.ReconciliationRequired, result.Assessment.Decision); Assert.Null(result.Observations.ActualBaseline);
        f.Preserved(bytes, inventory);
    }

    /// <summary>A configured but unavailable whole capture is missing evidence rather than a new publication.</summary>
    [Fact]
    public void Observe_ConfiguredCaptureUnavailable_ReconcilesWithoutCreatingIt()
    {
        using var f = new Fixture(_area); var bytes = f.Bytes(); var inventory = f.Inventory();
        using var scope = f.Begin(evidence: f.Evidence with { CaptureRootKey = "other-capture" });
        var result = scope.Observe(); Assert.Equal(EnrollmentRestartReason.MissingObservation, result.Assessment.Reason);
        Assert.Equal(EnrollmentRestartDecision.ReconciliationRequired, result.Assessment.Decision); Assert.False(Directory.Exists(f.OtherCapture)); f.Preserved(bytes, inventory);
    }

    /// <summary>A known host contradiction must not be hidden by a weaker baseline mismatch.</summary>
    [Fact]
    public void Observe_BaselineMismatchAndContradiction_PreservesRefusalPrecedence()
    {
        using var f = new Fixture(_area); using (var tx = f.Source.BeginWrite()) { tx.ReplaceNodeValue(Target(f.Snapshot), "newer"); tx.Commit(); }
        using var scope = f.Begin(evidence: f.Evidence with { ReleaseReconciled = EnrollmentRestartFact.Contradictory });
        var result = scope.Observe(); Assert.Equal(EnrollmentRestartDecision.Refused, result.Assessment.Decision);
        Assert.Equal(EnrollmentRestartReason.ContradictoryObservation, result.Assessment.Reason);
    }

    /// <summary>Corruption and unpublished state are rejected without recovery or content cleanup.</summary>
    /// <param name="damage">Actual protected bytes or role inventory changed after acquisition.</param>
    [Theory]
    [InlineData("capture")]
    [InlineData("source")]
    [InlineData("staging")]
    [InlineData("authority")]
    [InlineData("metadata")]
    [InlineData("parent")]
    [InlineData("extra-role")]
    public void Observe_DamagedInputs_FailsWithoutRepair(string damage)
    {
        using var f = new Fixture(_area);
        switch (damage)
        {
            case "capture": Corrupt(Path.Combine(f.Capture, "inventory.bin")); break;
            case "source": Corrupt(Directory.GetFiles(Path.Combine(f.Root, ".transactions", "wal")).Single()); break;
            case "staging": File.WriteAllText(Path.Combine(f.Root, ".transactions", "staging", "leftover"), "retain"); break;
            case "extra-role": File.WriteAllText(Path.Combine(f.AuthorityRoot, "extra"), "retain"); break;
            default: var stream = damage == "parent" ? (FileStream)Field(f.Parent, "_journal") : ((FileStream[])Field(f.Authority, "_roles"))[damage == "metadata" ? 1 : 2]; stream.Position = stream.Length; stream.WriteByte(1); stream.Flush(true); break;
        }
        var bytes = f.Bytes(); var inventory = f.Inventory();
        using var scope = f.Begin(); Assert.ThrowsAny<Exception>(() => scope.Observe()); Assert.True(f.Authority.IsFaulted);
        Assert.Throws<InvalidOperationException>(() => scope.Observe()); f.Preserved(bytes, inventory);
    }

    /// <summary>Changes at the last unlocked test boundary are found by complete second-pass validation.</summary>
    /// <param name="damage">Capture, live history or journal changes.</param>
    [Theory]
    [InlineData("capture")]
    [InlineData("source")]
    [InlineData("authority")]
    public void Observe_LastUnlockedMutation_RechecksExactEvidence(string damage)
    {
        using var f = new Fixture(_area); Dictionary<string, byte[]>? expected = null; string[]? inventory = null;
        f.Probe.Checkpoint = stage =>
        {
            if (stage != RestartObservationStage.BeforeFinalValidation) return;
            if (damage == "capture") Corrupt(Path.Combine(f.Capture, "inventory.bin"));
            else if (damage == "source") Corrupt(Directory.GetFiles(Path.Combine(f.Root, ".transactions", "wal")).Single());
            else { var stream = ((FileStream[])Field(f.Authority, "_roles"))[2]; stream.Position = stream.Length; stream.WriteByte(1); stream.Flush(true); }
            expected = f.Bytes(); inventory = f.Inventory();
        };
        using var scope = f.Begin(); Assert.ThrowsAny<Exception>(() => scope.Observe()); Assert.NotNull(expected); Assert.NotNull(inventory); f.Preserved(expected, inventory);
    }

    /// <summary>The final placement callback precedes complete source/capture revalidation.</summary>
    /// <param name="capture">Whether capture rather than source bytes change.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Observe_FinalPlacementMutation_IsCaughtBySecondFullProof(bool capture)
    {
        using var f = new Fixture(_area); var armed = false; var changed = false; Dictionary<string, byte[]>? bytes = null; string[]? inventory = null;
        f.Probe.Checkpoint = stage => { if (stage == RestartObservationStage.BeforeFinalValidation) armed = true; };
        f.Probe.PathCheckpoint = _ =>
        {
            if (!armed || changed) return; changed = true;
            Corrupt(capture ? Path.Combine(f.Capture, "inventory.bin") : Directory.GetFiles(Path.Combine(f.Root, ".transactions", "wal")).Single());
            bytes = f.Bytes(); inventory = f.Inventory();
        };
        using var scope = f.Begin(); Assert.ThrowsAny<Exception>(() => scope.Observe()); Assert.True(changed); Assert.NotNull(bytes); Assert.NotNull(inventory); f.Preserved(bytes, inventory);
    }

    /// <summary>Closing at any exposed phase retains actual operations until drain and produces no live observation.</summary>
    /// <param name="stage">Closing boundary.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(2)]
    [InlineData(3)]
    [InlineData(4)]
    public void Observe_ClosingAtBoundary_DrainsActualOwners(int stage)
    {
        using var f = new Fixture(_area); var bytes = f.Bytes(); var inventory = f.Inventory();
        f.Probe.Checkpoint = current => { if ((int)current == stage) f.CloseWrappers(); };
        ApplicationAuthorityLifetime.StoppedRestartObservation? scope = null;
        try { Assert.ThrowsAny<Exception>(() => { scope = f.Begin(); scope.Observe(); }); }
        finally { scope?.Dispose(); }
        Assert.True(f.Source.WhenEnrollmentOwnershipReleased.IsCompletedSuccessfully); Assert.True(f.Authority.WhenReleased.IsCompletedSuccessfully); Assert.True(f.Parent.WhenReleased.IsCompletedSuccessfully);
        Assert.Equal("new-0", f.Snapshot.ReadValue(Target(f.Snapshot))); f.Preserved(bytes, inventory);
    }

    /// <summary>Wrong caller context refuses before reserving or stopping the source.</summary>
    /// <param name="fault">Unbound or unsafe attestation.</param>
    [Theory]
    [InlineData("context")]
    [InlineData("authority")]
    [InlineData("capture-key")]
    [InlineData("fresh")]
    [InlineData("executors")]
    [InlineData("publishers")]
    public void Begin_InvalidEvidence_RefusesBeforeSourceAdmission(string fault)
    {
        using var f = new Fixture(_area); var e = fault switch
        {
            "context" => f.Evidence with { Context = f.Parent.Context with { SessionId = Guid.NewGuid() } },
            "authority" => f.Evidence with { AuthorityId = Guid.NewGuid() },
            "capture-key" => f.Evidence with { CaptureRootKey = "unmapped" },
            "fresh" => f.Evidence with { FreshScope = EnrollmentRestartFact.Unknown },
            "executors" => f.Evidence with { ExecutorsDrained = EnrollmentRestartFact.Unknown },
            _ => f.Evidence with { PublishersDrained = EnrollmentRestartFact.Unknown }
        };
        var bytes = f.Bytes(); var inventory = f.Inventory(); Assert.ThrowsAny<Exception>(() => f.Begin(evidence: e));
        Assert.False(f.Source.EnrollmentOwnershipStatus.StopLatched); Assert.Equal(0, f.Authority.ActiveInspections); f.Preserved(bytes, inventory);
    }

    /// <summary>Forged scope objects cannot consume or drain the real scope's registrations.</summary>
    [Fact]
    public void Observe_ForgedScope_RejectsBeforeIoOrRelease()
    {
        using var f = new Fixture(_area); using var real = f.Begin();
        var fake = new ApplicationAuthorityLifetime.StoppedRestartObservation(f.Authority, f.Source, f.Evidence, new Noop(), f.Parent.JournalStatus.KnownPosition, null);
        Assert.Throws<InvalidOperationException>(() => fake.Observe()); Assert.Throws<InvalidOperationException>(fake.Dispose);
        Assert.Equal(1, f.Authority.ActiveInspections); Assert.Equal(EnrollmentRestartDecision.ObservedEnrolledStopped, real.Observe().Assessment.Decision);
    }

    /// <summary>Acquisition instrumentation cannot reenter observation before resources are fully published.</summary>
    /// <param name="stage">Acquisition-only boundary.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    public void Begin_ReentrantObservation_RefusesWithoutConsumingScope(int stage)
    {
        using var f = new Fixture(_area); var attempted = false;
        f.Probe.Checkpoint = point =>
        {
            if ((int)point != stage) return;
            attempted = true; var acquiring = (ApplicationAuthorityLifetime.StoppedRestartObservation)Field(f.Authority, "_restartObservation");
            Assert.Throws<InvalidOperationException>(() => acquiring.Observe());
        };
        using var scope = f.Begin(); Assert.True(attempted); Assert.Equal(EnrollmentRestartDecision.ObservedEnrolledStopped, scope.Observe().Assessment.Decision);
    }

    /// <summary>Foreign threads cannot inspect or drain caller-thread ownership.</summary>
    /// <param name="dispose">Whether to attempt disposal instead of observation.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Scope_WrongThread_RejectsWithoutLosingOwnership(bool dispose)
    {
        using var f = new Fixture(_area); using var scope = f.Begin(); Exception? error = null;
        var thread = new Thread(() => error = Record.Exception(() => { if (dispose) scope.Dispose(); else scope.Observe(); }));
        thread.Start(); Assert.True(thread.Join(TimeSpan.FromSeconds(30))); Assert.IsType<InvalidOperationException>(error);
        Assert.Equal(EnrollmentRestartDecision.ObservedEnrolledStopped, scope.Observe().Assessment.Decision);
    }

    /// <summary>Required source/authority/parent close errors surface once without clearing logical uncertainty.</summary>
    /// <param name="role">Actual role that fails release.</param>
    /// <param name="mode">Before/after/no-op physical delegation.</param>
    [Theory]
    [InlineData("writer.lock", "before")]
    [InlineData("writer.lock", "after")]
    [InlineData("writer.lock", "noop")]
    [InlineData("authority.log", "before")]
    [InlineData("authority.log", "after")]
    [InlineData("authority.log", "noop")]
    [InlineData("host.meta", "before")]
    [InlineData("host.meta", "after")]
    [InlineData("host.meta", "noop")]
    public void Dispose_RequiredCloseFailure_RetainsUncertaintyWithoutRetry(string role, string mode)
    {
        using var f = new Fixture(_area, fault: role, mode: mode); var bytes = f.Bytes(); var inventory = f.Inventory();
        var scope = f.Begin(); var result = scope.Observe(); f.CloseWrappers();
        Assert.Throws<IOException>(scope.Dispose); Assert.True(scope.ReleaseUnknown); Assert.True(result.Assessment.WritersMustRemainStopped);
        Assert.Equal(1, f.Closer.Calls.Count(n => n == role)); scope.Dispose(); f.CloseWrappers(); Assert.Equal(1, f.Closer.Calls.Count(n => n == role));
        if (role == "writer.lock") { Assert.True(f.Source.WhenEnrollmentOwnershipReleased.IsFaulted); Assert.Equal(1, f.Authority.ActiveInspections); Assert.False(f.Authority.WhenReleased.IsCompleted); }
        else if (role == "authority.log") { Assert.True(f.Authority.WhenReleased.IsFaulted); Assert.False(f.Parent.WhenReleased.IsCompleted); }
        else { Assert.True(f.Authority.WhenReleased.IsCompletedSuccessfully); Assert.True(f.Parent.WhenReleased.IsFaulted); }
        Assert.Null(f.Authority.ConfirmedEnrollment); f.Preserved(bytes, inventory);
    }

    /// <summary>Source exclusion cannot be inferred from a scope whose source wrapper closed before observation.</summary>
    [Fact]
    public void Observe_AlreadyClosingSource_RejectsAtFinalOwnershipCheck()
    {
        using var f = new Fixture(_area); using var scope = f.Begin(); f.Source.Dispose();
        Assert.ThrowsAny<Exception>(() => scope.Observe()); Assert.False(f.Source.WhenEnrollmentOwnershipReleased.IsCompleted);
        scope.Dispose(); Assert.True(f.Source.WhenEnrollmentOwnershipReleased.IsCompletedSuccessfully);
    }

    /// <summary>The parent/source final-validation components refuse busy source gates without waiting under peers.</summary>
    [Fact]
    public void FinalOwnership_BusySource_UsesNonblockingCheck()
    {
        using var f = new Fixture(_area); using var scope = f.Begin(); var source = scope.Source!;
        var gate = Field(f.Source, "_gate"); using var held = new ManualResetEventSlim(); using var release = new ManualResetEventSlim();
        var thread = new Thread(() => { lock (gate) { held.Set(); release.Wait(TimeSpan.FromSeconds(30)); } }) { IsBackground = true };
        thread.Start(); Assert.True(held.Wait(TimeSpan.FromSeconds(30)));
        try { Assert.False(source.TryRequireCurrent(f.Source)); }
        finally { release.Set(); Assert.True(thread.Join(TimeSpan.FromSeconds(30))); }
        Assert.Equal(EnrollmentRestartDecision.ObservedEnrolledStopped, scope.Observe().Assessment.Decision);
    }

    private sealed class RoleCloser(string? target, string mode) : IRetainedRoleLeaseClose, IEnrollmentSourceLeaseClose
    {
        internal List<string> Calls { get; } = [];
        /// <inheritdoc/>
        public void Close(FileStream stream)
        {
            var name = Path.GetFileName(stream.Name); Calls.Add(name);
            if (name != target) { stream.Dispose(); return; }
            if (mode == "after") stream.Dispose();
            if (mode != "noop") throw new IOException("Injected " + mode + " role close: " + name);
        }
    }

    private static void Corrupt(string path) { var bytes = File.ReadAllBytes(path); bytes[^1] ^= 1; File.WriteAllBytes(path, bytes); }
    private static object Field(object owner, string name) => owner.GetType().GetField(name, System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic)!.GetValue(owner)!;
    private static ulong Target(ImmutableXmlSnapshot read) => Enumerable.Range(1, read.NodeCount).Select(i => read.GetNode((ulong)i)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();
    private sealed class Noop : IDisposable
    {
        /// <inheritdoc/>
        public void Dispose() { }
    }
    private sealed class Probe(Fixture fixture) : IRestartObservationProbe
    {
        internal List<string> Paths { get; } = [];
        internal List<RestartObservationStage> Stages { get; } = [];
        internal Action<RestartObservationStage>? Checkpoint { get; set; }
        internal Action<string>? PathCheckpoint { get; set; }
        private void Outside()
        {
            foreach (var (owner, name) in new[] { ((object)fixture.Authority, "_gate"), (fixture.Authority, "_readGate"), (fixture.Parent, "_gate"), (fixture.Parent, "_appendGate"), (fixture.Source, "_gate") }) Assert.False(Monitor.IsEntered(Field(owner, name)));
        }
        /// <inheritdoc/>
        public void BeforeProtectedPathRead(string path) { Outside(); Paths.Add(path); PathCheckpoint?.Invoke(path); }
        /// <inheritdoc/>
        public void AtStage(RestartObservationStage stage) { Outside(); Stages.Add(stage); Checkpoint?.Invoke(stage); }
    }
    private sealed class Fixture : IDisposable
    {
        private readonly string _area;
        internal string Root => Path.Combine(_area, "source");
        internal string Capture => Path.Combine(_area, "capture");
        internal string OtherCapture => Path.Combine(_area, "other-capture");
        private string Host => Path.Combine(_area, "host");
        internal string AuthorityRoot => Path.Combine(_area, "authority");
        internal EmbeddedXmlDatabase Source { get; }
        internal ImmutableXmlSnapshot Snapshot { get; }
        internal EmbeddedHostLifetime Parent { get; }
        internal ApplicationAuthorityLifetime Authority { get; }
        internal ApplicationRestartEvidence Evidence { get; }
        internal Probe Probe { get; }
        internal RoleCloser Closer { get; }
        private readonly FileStream[] _actualRoles;
        internal Fixture(string area, int commits = 1, string shape = "single", string? fault = null, string mode = "before", string? adminStage = null)
        {
            _area = area; Directory.CreateDirectory(area);
            using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, Root);
            var admin = Guid.NewGuid(); var configuration = new ApplicationAuthorityConfiguration(Guid.NewGuid(), admin, "pilot", "orders", "admin", "authority");
            var roots = new Dictionary<string, string> { ["admin"] = Host, ["authority"] = AuthorityRoot, ["source"] = Root, ["capture"] = Capture, ["other-capture"] = OtherCapture };
            Directory.CreateDirectory(Host); File.WriteAllBytes(Path.Combine(Host, "owner.lock"), []); File.WriteAllBytes(Path.Combine(Host, "host.meta"), HostJournalCodec.EncodeMetadata(admin, "pilot", "orders")); File.WriteAllBytes(Path.Combine(Host, "journal.bin"), []);
            using (var source = EmbeddedXmlDatabase.Open(Root))
            using (var parent = EmbeddedHostLifetime.OpenExisting(Host, "pilot", "orders", [Root, Capture, OtherCapture, AuthorityRoot]))
            using (var authority = ApplicationAuthorityLifetime.Provision(parent, parent.JournalStatus.KnownPosition, new(parent.Context, true, true, true, true, true), AuthorityRoot, configuration, roots, new(AuthorityRoot, true, true, true)))
            {
                for (var n = 0; n < commits; n++) { using var read = source.BeginRead(); using var tx = source.BeginWrite(); tx.ReplaceNodeValue(Target(read), "new-" + n); tx.Commit(); }
                if (shape != "empty")
                {
                    using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture);
                    var evidence = new ApplicationEnrollmentEvidence(parent.Context, configuration.AuthorityId, "source", "source-admission", "capture", Guid.NewGuid(), new string('a', 64), true, true, true, true, true, true);
                    using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence);
                    Assert.Equal(ApplicationEnrollmentAppendDisposition.AcknowledgedStopped, authority.AppendFirstEnrollment(plan, evidence).Disposition);
                }
            }
            if (shape == "later")
            {
                var path = Path.Combine(AuthorityRoot, "authority.log"); var bytes = File.ReadAllBytes(path);
                var metadata = ApplicationAuthorityCodec.DecodeMetadata(File.ReadAllBytes(Path.Combine(AuthorityRoot, "authority.meta")), configuration);
                var first = ApplicationAuthorityCodec.DecodeJournal(bytes, metadata).Frames.Single(); var entry = first.Entry;
                var transfer = entry with { OwnerSession = Guid.NewGuid(), OwnerGeneration = 2, Data = new ApplicationTransfer(entry.OwnerSession, 1) };
                File.WriteAllBytes(path, [.. bytes, .. ApplicationAuthorityCodec.EncodeFrame(metadata, 2, first.Digest, transfer)]);
            }
            if (adminStage is not null)
            {
                var descriptor = new EpochAdministrativeAttemptDescriptor(Guid.NewGuid(), EpochPublicationKind.LegacyMigration, Capture,
                    Path.Combine(_area, "bundle"), new string('a', 64), Guid.NewGuid(), 1, (ulong)commits, null, EpochProfile.ScalarWal, DurabilityMode.ProcessCrash);
                var snapshot = new HostLedgerSnapshot(new(Guid.NewGuid(), "pilot", "orders", descriptor, 1, Guid.NewGuid(), 1), HostLedgerStage.Recorded);
                var output = new List<byte>(); var digest = new string('0', 64); ulong sequence = 0;
                void Add(HostJournalEvent kind)
                {
                    var bytes = HostJournalCodec.EncodeFrame(admin, ++sequence, digest, kind, snapshot);
                    digest = HostJournalCodec.DecodeFrame(bytes).Digest; output.AddRange(bytes);
                }
                Add(HostJournalEvent.RecordIntent);
                if (adminStage != "recorded")
                {
                    snapshot = snapshot with { Context = snapshot.Context with { Revision = 2 }, Stage = HostLedgerStage.DispatchAuthorized }; Add(HostJournalEvent.AuthorizeDispatch);
                    if (adminStage is "uncertain" or "absent")
                    { snapshot = snapshot with { Context = snapshot.Context with { Revision = 3 }, Stage = HostLedgerStage.Uncertain }; Add(HostJournalEvent.MarkUncertain); }
                    if (adminStage == "absent")
                    { snapshot = snapshot with { Context = snapshot.Context with { Revision = 4 }, Stage = HostLedgerStage.ReconciledAbsent }; Add(HostJournalEvent.ReconcileAbsent); }
                    if (adminStage == "observed")
                    {
                        snapshot = snapshot with
                        {
                            Context = snapshot.Context with { Revision = 3 },
                            Stage = HostLedgerStage.ObservedKnown,
                            Observed = new(EpochPublicationKind.LegacyMigration, descriptor.AttemptId, descriptor.BackupId, null,
                                new(Guid.NewGuid(), Guid.NewGuid(), 1), (ulong)commits, Path.Combine(descriptor.BundleRoot, "store"))
                        };
                        Add(HostJournalEvent.ObserveKnown);
                    }
                }
                File.WriteAllBytes(Path.Combine(Host, "journal.bin"), [.. output]); // Pure valid fixture history, not real dispatch or reconciliation evidence.
            }
            Source = EmbeddedXmlDatabase.Open(Root); Snapshot = Source.BeginRead(); // Explicit caller recovery/reader initialization precedes preservation measurement.
            Closer = new(fault, mode);
            Parent = EmbeddedHostLifetime.OpenExistingCore(Host, "pilot", "orders", [Root, Capture, OtherCapture, AuthorityRoot], DurabilityMode.ProcessCrash, Closer);
            Authority = ApplicationAuthorityLifetime.OpenExistingCore(Parent, Parent.JournalStatus.KnownPosition, new(Parent.Context, true, true, true, true, true), AuthorityRoot, configuration, roots, null, Closer);
            _actualRoles = [.. (FileStream[])Field(Authority, "_roles"), (FileStream)Field(Parent, "_owner"), (FileStream)Field(Parent, "_metadata"), (FileStream)Field(Parent, "_journal"), (FileStream)Field(Source, "_lease")];
            Evidence = new(Parent.Context, configuration.AuthorityId, "capture", EnrollmentRestartFact.Confirmed, EnrollmentRestartFact.Confirmed,
                EnrollmentRestartFact.Confirmed, EnrollmentRestartFact.Confirmed, EnrollmentRestartFact.Confirmed);
            Probe = new(this);
        }
        internal ApplicationAuthorityLifetime.StoppedRestartObservation Begin(bool noSource = false, ApplicationRestartEvidence? evidence = null) =>
            Authority.BeginRestartObservationCore(noSource ? null : Source, evidence ?? Evidence, Probe, Closer);
        internal Dictionary<string, byte[]> Bytes()
        {
            var result = new Dictionary<string, byte[]>();
            foreach (var path in Directory.GetFiles(_area, "*", SearchOption.AllDirectories).Where(p => Path.GetFileName(p) is not ("writer.lock" or "owner.lock" or "authority.lock")))
            { using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite); var bytes = new byte[(int)stream.Length]; stream.ReadExactly(bytes); result.Add(Path.GetRelativePath(_area, path), bytes); }
            return result;
        }
        internal string[] Inventory() => Directory.GetFileSystemEntries(_area, "*", SearchOption.AllDirectories).Order().ToArray();
        internal void Preserved(Dictionary<string, byte[]> bytes, string[] inventory)
        { var after = Bytes(); Assert.Equal(inventory, Inventory()); Assert.Equal(bytes.Keys.Order(), after.Keys.Order()); foreach (var pair in bytes) Assert.Equal(pair.Value, after[pair.Key]); }
        internal void CloseWrappers() { Source.Dispose(); Authority.Dispose(); Parent.Dispose(); }
        /// <summary>Drains the fresh fixture owners and snapshot.</summary>
        public void Dispose()
        {
            try { Snapshot.Dispose(); CloseWrappers(); }
            finally { foreach (var stream in _actualRoles) stream.Dispose(); }
        }
    }
    /// <summary>Removes only this fresh test workspace after ownership drains.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
