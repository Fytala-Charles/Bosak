// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Verifies scalar commits, snapshot isolation and journal recovery.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Text;
using System.Xml;
using Bosak.XmlDb.Core;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Verifies scalar commits, snapshot isolation and journal recovery.</summary>
public sealed class TransactionTests : IDisposable
{
    private readonly string _root = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-m2-" + Guid.NewGuid().ToString("N"));

    /// <summary>Confirms old snapshots retain lazy values while reopened readers see stable IDs with new values.</summary>
    /// <param name="documentId">Logical document identity.</param>
    [Theory]
    [InlineData(1UL)]
    [InlineData(27UL)]
    public void Commit_Reopen_PreservesOldSnapshotAndNodeIdentity(ulong documentId)
    {
        Import(documentId);
        using var original = ImmutableXmlSnapshot.Open(_root, documentId);
        var target = Text(original, "old");
        using (var database = EmbeddedXmlDatabase.Open(_root, documentId))
        {
            Assert.Equal(0UL, database.CommitSequence);
            Assert.Throws<InvalidOperationException>(() => ImmutableXmlSnapshot.Open(_root, documentId));
            using var pinned = database.BeginRead(cacheBytes: 0);
            using var write = database.BeginWrite();
            write.ReplaceNodeValue(target, "new & Unicode \u03bb");
            Assert.Equal("old", pinned.ReadValue(target));
            Assert.Equal(1UL, write.Commit());
            Assert.Equal("old", original.ReadValue(target));
            Assert.Equal("old", pinned.ReadValue(target));
            using var latest = database.BeginRead();
            Assert.Equal(1UL, latest.CommitSequence);
            Assert.Equal("new & Unicode \u03bb", latest.ReadValue(target));
            for (ulong id = 1; id <= (ulong)latest.NodeCount; id++)
            {
                var before = original.GetNode(id);
                var after = latest.GetNode(id);
                Assert.Equal(before.Id, after.Id);
                Assert.Equal(before.ParentId, after.ParentId);
                Assert.Equal(before.Children, after.Children);
                Assert.Equal(before.Attributes, after.Attributes);
                Assert.Equal(before.Namespaces, after.Namespaces);
            }
        }
        using var recovered = EmbeddedXmlDatabase.Open(_root, documentId);
        using var snapshot = recovered.BeginRead();
        Assert.Equal(1UL, snapshot.CommitSequence);
        Assert.Equal("new & Unicode \u03bb", snapshot.ReadValue(target));
        Assert.Equal("old", original.ReadValue(target));
    }

    /// <summary>Confirms disposal and explicit rollback never append journal records.</summary>
    [Fact]
    public void Rollback_DisposedOrExplicit_LeavesBaseVisible()
    {
        Import();
        using var database = EmbeddedXmlDatabase.Open(_root);
        using var read = database.BeginRead();
        var id = Text(read, "old");
        using (var write = database.BeginWrite()) write.ReplaceNodeValue(id, "uncommitted");
        using (var write = database.BeginWrite())
        {
            write.ReplaceNodeValue(id, "discarded");
            write.Rollback();
            Assert.Throws<ObjectDisposedException>(() => write.Commit());
        }
        Assert.Equal(0UL, database.CommitSequence);
        Assert.Empty(Directory.GetFiles(Path.Combine(_root, ".transactions", "wal")));
        using var current = database.BeginRead();
        Assert.Equal("old", current.ReadValue(id));
    }

    /// <summary>Rejects stale transactions without poisoning the live coordinator.</summary>
    [Fact]
    public void Commit_StaleDocumentGeneration_ConflictsWithoutPartialWrite()
    {
        Import();
        using var database = EmbeddedXmlDatabase.Open(_root);
        using var read = database.BeginRead();
        var id = Text(read, "old");
        using var first = database.BeginWrite();
        using var stale = database.BeginWrite();
        first.ReplaceNodeValue(id, "first");
        stale.ReplaceNodeValue(id, "stale");
        first.Commit();
        Assert.Throws<TransactionConflictException>(() => stale.Commit());
        using var next = database.BeginWrite();
        next.ReplaceNodeValue(id, "second");
        Assert.Equal(2UL, next.Commit());
        using var latest = database.BeginRead();
        Assert.Equal("second", latest.ReadValue(id));
        Assert.Equal(2, Directory.GetFiles(Path.Combine(_root, ".transactions", "wal")).Length);
    }

    /// <summary>Exercises ordinary attribute restaging/empty values and rejects structural empty-text edits.</summary>
    [Fact]
    public void Replace_AttributeAndEmptyText_PreservesStructureAndRejectsTextRemoval()
    {
        Import();
        using var database = EmbeddedXmlDatabase.Open(_root);
        using var read = database.BeginRead();
        var attribute = Nodes(read).Single(node => node.Kind == StorageNodeKind.Attribute && node.LocalName == "number").Id;
        using (var transaction = database.BeginWrite())
        {
            transaction.ReplaceNodeValue(attribute, "discarded");
            transaction.ReplaceNodeValue(attribute, "\"<& \u03bb");
            transaction.Commit();
        }
        using var current = database.BeginRead();
        Assert.Equal("\"<& \u03bb", current.ReadValue(attribute));
        var id = Text(current, "old");
        using (var transaction = database.BeginWrite())
        {
            Assert.Throws<NotSupportedException>(() => transaction.ReplaceNodeValue(id, ""));
            transaction.ReplaceNodeValue(attribute, "");
            transaction.Commit();
        }
        using var latest = database.BeginRead();
        Assert.Equal("old", latest.ReadValue(id));
        Assert.Equal("", latest.ReadValue(attribute));
        Assert.Equal(current.NodeCount, latest.NodeCount);
    }

    /// <summary>Rejects unsupported and invalid edits before any journal write.</summary>
    [Fact]
    public void Replace_InvalidEdits_DoNotPersistOrPoisonTransaction()
    {
        Import();
        using var database = EmbeddedXmlDatabase.Open(_root);
        using var read = database.BeginRead();
        using var write = database.BeginWrite();
        Assert.Throws<NotSupportedException>(() => write.ReplaceNodeValue(1, "no"));
        var ns = Nodes(read).First(node => node.Kind == StorageNodeKind.Namespace).Id;
        Assert.Throws<NotSupportedException>(() => write.ReplaceNodeValue(ns, "no"));
        var xmlBase = Nodes(read).Single(node => node.Kind == StorageNodeKind.Attribute && node.LocalName == "base").Id;
        Assert.Throws<NotSupportedException>(() => write.ReplaceNodeValue(xmlBase, "no"));
        Assert.Throws<ArgumentOutOfRangeException>(() => write.ReplaceNodeValue(ulong.MaxValue, "no"));
        var target = Text(read, "old");
        Assert.Throws<XmlException>(() => write.ReplaceNodeValue(target, "bad\0value"));
        Assert.Throws<InvalidDataException>(() => write.ReplaceNodeValue(target, new string('x', BinaryEnvelope.MaximumStringBytes + 1)));
        Assert.Throws<InvalidOperationException>(() => write.Commit());
        write.ReplaceNodeValue(target, "valid");
        var other = Text(read, "line");
        Assert.Throws<NotSupportedException>(() => write.ReplaceNodeValue(other, "second node"));
        Assert.Equal(1UL, write.Commit());
        Assert.Throws<ObjectDisposedException>(() => write.Commit());
    }

    /// <summary>Enforces one coordinator while allowing snapshots to outlive its disposal.</summary>
    [Fact]
    public void Coordinator_LeaseAndDisposal_ProtectsWriterOwnership()
    {
        Import();
        var database = EmbeddedXmlDatabase.Open(_root);
        var snapshot = database.BeginRead();
        var transaction = database.BeginWrite();
        var target = Text(snapshot, "old");
        transaction.ReplaceNodeValue(target, "no");
        Assert.Throws<IOException>(() => EmbeddedXmlDatabase.Open(_root));
        database.Dispose();
        database.Dispose();
        Assert.Throws<ObjectDisposedException>(() => transaction.Commit());
        Assert.Throws<ObjectDisposedException>(() => database.BeginRead());
        Assert.Equal("old", snapshot.ReadValue(target));
        snapshot.Dispose();
        using var reopened = EmbeddedXmlDatabase.Open(_root);
        Assert.Equal(0UL, reopened.CommitSequence);
    }

    /// <summary>Rejects corruption in complete journal/control/generation files.</summary>
    /// <param name="relativePath">File to corrupt after an acknowledged commit.</param>
    [Theory]
    [InlineData(".transactions/CONTROL")]
    [InlineData(".transactions/CURRENT")]
    [InlineData(".transactions/wal/00000000000000000001.wal")]
    [InlineData(".transactions/generations/00000000000000000001/documents/1/manifest.bin")]
    [InlineData(".transactions/generations/00000000000000000001/documents/1/directory.bin")]
    [InlineData(".transactions/generations/00000000000000000001/fragments/1.bin")]
    public void Recovery_CorruptCommittedData_FailsClosed(string relativePath)
    {
        Import();
        Commit("new");
        var path = Path.Combine(_root, relativePath);
        var bytes = File.ReadAllBytes(path);
        bytes[^1] ^= 1;
        File.WriteAllBytes(path, bytes);
        Assert.Throws<InvalidDataException>(() => EmbeddedXmlDatabase.Open(_root));
    }

    /// <summary>Never truncates a damaged record already referenced by CURRENT.</summary>
    [Fact]
    public void Recovery_TruncatedAcknowledgedRecord_FailsClosed()
    {
        Import();
        Commit("new");
        var path = Path.Combine(_root, ".transactions", "wal", "00000000000000000001.wal");
        File.WriteAllBytes(path, File.ReadAllBytes(path)[..16]);
        Assert.Throws<InvalidDataException>(() => EmbeddedXmlDatabase.Open(_root));
        Assert.Equal(16, new FileInfo(path).Length);
    }

    /// <summary>Discards only an uncommitted incomplete final append and permits later commits.</summary>
    [Fact]
    public void Recovery_IncompleteFinalAppend_DiscardsTailAndCanCommit()
    {
        Import();
        Commit("first");
        var path = Path.Combine(_root, ".transactions", "wal", "00000000000000000002.wal");
        var bytes = TransactionCodec.EncodeWal(new(1, 2, Guid.NewGuid(), 4, "uncommitted", new byte[32], new byte[32]));
        File.WriteAllBytes(path, bytes[..16]);
        using var database = EmbeddedXmlDatabase.Open(_root);
        Assert.Equal(1UL, database.CommitSequence);
        Assert.False(File.Exists(path));
        using var read = database.BeginRead();
        var id = Text(read, "first");
        using var write = database.BeginWrite();
        write.ReplaceNodeValue(id, "second");
        Assert.Equal(2UL, write.Commit());
    }

    /// <summary>Fails on missing committed history even if generation files remain.</summary>
    [Fact]
    public void Recovery_MissingJournalRecord_DoesNotTrustPublishedGeneration()
    {
        Import();
        Commit("first");
        Commit("second");
        File.Delete(Path.Combine(_root, ".transactions", "wal", "00000000000000000001.wal"));
        Assert.Throws<InvalidDataException>(() => EmbeddedXmlDatabase.Open(_root));
    }

    /// <summary>Requires the full predecessor chain and rejects validly checksummed wrong hashes.</summary>
    [Fact]
    public void Recovery_WrongPredecessorHash_RejectsValidEnvelope()
    {
        Import();
        Commit("first");
        var path = Path.Combine(_root, ".transactions", "wal", "00000000000000000001.wal");
        var record = TransactionCodec.ReadWal(path)!;
        File.WriteAllBytes(path, TransactionCodec.EncodeWal(record with { PreviousManifestHash = new byte[32] }));
        Assert.Throws<InvalidDataException>(() => EmbeddedXmlDatabase.Open(_root));
    }

    /// <summary>Reconstructs an absent materialization deterministically from the journal.</summary>
    [Fact]
    public void Recovery_MissingGeneration_ReplaysAndRemainsIdempotent()
    {
        Import();
        Commit("first");
        Commit("second");
        Directory.Move(Path.Combine(_root, ".transactions", "generations", "00000000000000000002"),
            Path.Combine(_root, ".transactions", "staging", "removed-generation"));
        for (var i = 0; i < 2; i++)
        {
            using var database = EmbeddedXmlDatabase.Open(_root);
            using var read = database.BeginRead();
            Assert.Equal(2UL, read.CommitSequence);
            Assert.Equal("second", read.ReadValue(Text(read, "second")));
        }
    }

    /// <summary>Faults an uncertain coordinator and requires recovery before later use.</summary>
    [Fact]
    public void Commit_PersistenceFailure_FaultsCoordinatorUntilReopen()
    {
        Import();
        using (var database = EmbeddedXmlDatabase.OpenCore(_root, 1, stage =>
        {
            if (stage == CommitStage.WalFlushed) throw new IOException("Injected disk/publication fault.");
        }))
        {
            using var read = database.BeginRead();
            using var write = database.BeginWrite();
            write.ReplaceNodeValue(Text(read, "old"), "new");
            Assert.Throws<IOException>(() => write.Commit());
            Assert.Throws<InvalidOperationException>(() => database.BeginRead());
            Assert.Throws<InvalidOperationException>(() => database.BeginWrite());
        }
        using var recovered = EmbeddedXmlDatabase.Open(_root);
        using var snapshot = recovered.BeginRead();
        Assert.Equal(1UL, snapshot.CommitSequence);
        Assert.Equal("new", snapshot.ReadValue(Text(snapshot, "new")));
    }

    /// <summary>Matches the transaction byte contract against independently encoded golden files.</summary>
    [Fact]
    public void TransactionCodec_FixedRecords_MatchGoldenBytes()
    {
        var hash = Enumerable.Repeat((byte)0x11, 32).ToArray();
        var record = new WalRecord(1, 1, new Guid(Enumerable.Range(1, 16).Select(i => (byte)i).ToArray()), 7, "new", new byte[32], hash);
        AssertFixture("wal-v1.hex", TransactionCodec.EncodeWal(record));
        AssertFixture("control-v1.hex", TransactionCodec.EncodePointer(new(1, 0, hash), "BXTC"));
        AssertFixture("current-v1.hex", TransactionCodec.EncodePointer(new(1, 1, hash), "BXHD"));

        static void AssertFixture(string name, byte[] bytes) => Assert.Equal(
            File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "TestData", name)).Trim(), Convert.ToHexString(bytes));
    }
    /// <summary>Rejects semantic corruption even when a WAL record has a valid checksum and an existing generation.</summary>
    /// <param name="invalidNode">Whether to corrupt the target identity instead of the replacement value.</param>
    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public void Recovery_InvalidRedoWithValidChecksum_FailsClosed(bool invalidNode)
    {
        Import();
        Commit("first");
        var path = Path.Combine(_root, ".transactions", "wal", "00000000000000000001.wal");
        var record = TransactionCodec.ReadWal(path)!;
        var corrupt = invalidNode ? record with { NodeId = ulong.MaxValue } : record with { Value = "forged" };
        File.WriteAllBytes(path, TransactionCodec.EncodeWal(corrupt));
        Assert.Throws<InvalidDataException>(() => EmbeddedXmlDatabase.Open(_root));
    }

    /// <summary>Never discards an incomplete non-final record to skip a sequence gap.</summary>
    [Fact]
    public void Recovery_IncompleteNonFinalRecord_FailsClosed()
    {
        Import();
        using (EmbeddedXmlDatabase.Open(_root)) { }
        var wal = Path.Combine(_root, ".transactions", "wal");
        var bytes = TransactionCodec.EncodeWal(new(1, 1, Guid.NewGuid(), 4, "new", new byte[32], new byte[32]));
        File.WriteAllBytes(Path.Combine(wal, "00000000000000000001.wal"), bytes[..16]);
        File.WriteAllBytes(Path.Combine(wal, "00000000000000000002.wal"), bytes);
        Assert.Throws<InvalidDataException>(() => EmbeddedXmlDatabase.Open(_root));
        Assert.Equal(2, Directory.GetFiles(wal).Length);
    }

    /// <summary>Control identity prevents accidental adoption of another document or modified base.</summary>
    [Fact]
    public void Recovery_BaseIdentityChanged_FailsBeforeServingReads()
    {
        Import();
        using (EmbeddedXmlDatabase.Open(_root)) { }
        var path = Path.Combine(_root, ".transactions", "CONTROL");
        var pointer = TransactionCodec.ReadPointer(path, "BXTC");
        File.WriteAllBytes(path, TransactionCodec.EncodePointer(pointer with { DocumentId = 9 }, "BXTC"));
        Assert.Throws<InvalidDataException>(() => EmbeddedXmlDatabase.Open(_root));
    }
    private void Import(ulong documentId = 1)
    {
        using var xml = new MemoryStream(Encoding.UTF8.GetBytes("<SalesOrder xml:base='https://example.test/'><SalesOrderHeader><DocumentID>old</DocumentID></SalesOrderHeader><SalesOrderLine number='1'>line</SalesOrderLine></SalesOrder>"));
        XmlFragmentImporter.Import(xml, _root, documentId, linesPerFragment: 1);
    }

    private void Commit(string value)
    {
        using var database = EmbeddedXmlDatabase.Open(_root);
        using var read = database.BeginRead();
        var id = Nodes(read).Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();
        using var write = database.BeginWrite();
        write.ReplaceNodeValue(id, value);
        write.Commit();
    }

    private static IEnumerable<StorageNode> Nodes(ImmutableXmlSnapshot snapshot) =>
        Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id));

    private static ulong Text(ImmutableXmlSnapshot snapshot, string value) =>
        Nodes(snapshot).Single(node => node.Kind == StorageNodeKind.Text && snapshot.ReadValue(node.Id) == value).Id;

    /// <inheritdoc />
    public void Dispose()
    {
        if (Directory.Exists(_root)) Directory.Delete(_root, true);
    }
}



