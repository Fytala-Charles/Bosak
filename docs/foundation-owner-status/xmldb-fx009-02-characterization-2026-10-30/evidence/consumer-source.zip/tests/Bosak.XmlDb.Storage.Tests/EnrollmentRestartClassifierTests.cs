// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 30 October 2026
// PURPOSE              : Qualifies inert stopped enrollment assessments and refusal precedence.
// SPECIAL NOTES        : Pure supplied observations; no actual ownership, I/O or handoff capability.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 30-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Qualifies inert stopped enrollment assessments and refusal precedence.</summary>
public sealed class EnrollmentRestartClassifierTests
{
    private const EnrollmentRestartFact Yes = EnrollmentRestartFact.Confirmed;
    private static string Hash(char value) => new(value, 64);
    private static readonly Guid Owner = Guid.Parse("11111111-2222-3333-4444-555555555555");
    private static EnrollmentRestartObservations Good()
    {
        var p = new EnrollmentRestartPosition("pilot", "orders", "admin", "authority", Owner, Owner,
            Hash('a'), 0, Hash('0'), 1, Hash('b'), Owner, 1, Owner, 1, PilotBranch.Source);
        var b = new EnrollmentRestartBaseline("source", "source-admission", 7, 3, Hash('c'), Hash('d'));
        return new(p, p, EnrollmentRestartShape.SingleEnroll, new(Yes, Yes, Yes, Yes, Yes), b, b,
            new(Yes, Yes, Yes, Yes, Yes, Yes, Yes));
    }

    /// <summary>An exact Enroll observation remains inert even with a valid successor proposal.</summary>
    /// <param name="proposal">Whether a successor description is supplied.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Classify_ExactEnrollment_OnlyObservesStopped(bool proposal)
    {
        var input = Good();
        if (proposal) input = input with { Successor = new(Guid.Parse("22222222-3333-4444-5555-666666666666")) };
        Check(input, EnrollmentRestartDecision.ObservedEnrolledStopped, EnrollmentRestartReason.ExactEnrollmentObserved);
        Assert.Equal(Good().Expected, input.Expected);
    }

    /// <summary>Each independent structural or operational fact defaults conservatively.</summary>
    /// <returns>Every unknown and contradictory fact position.</returns>
    public static IEnumerable<object[]> FactCases()
    {
        for (var slot = 0; slot < 12; slot++)
            foreach (var state in new[] { 0, 2 }) yield return new object[] { slot, state };
    }

    /// <summary>Missing facts never become zero work or successful structural verification.</summary>
    /// <param name="slot">Independent supplied fact.</param>
    /// <param name="state">Unknown or contradictory.</param>
    [Theory]
    [MemberData(nameof(FactCases))]
    public void Classify_IndependentFact_StaysStopped(int slot, int state)
    {
        var input = Good(); var fact = (EnrollmentRestartFact)state; var s = input.Structure!; var h = input.Host!;
        input = slot switch
        {
            0 => input with { Structure = s with { Namespace = fact } },
            1 => input with { Structure = s with { Identities = fact } },
            2 => input with { Structure = s with { AdministrativeHistory = fact } },
            3 => input with { Structure = s with { AuthorityHistory = fact } },
            4 => input with { Structure = s with { HeadUnchanged = fact } },
            5 => input with { Host = h with { FreshScope = fact } },
            6 => input with { Host = h with { OwnersReacquired = fact } },
            7 => input with { Host = h with { SourceExcluded = fact } },
            8 => input with { Host = h with { PriorWorkReconciled = fact } },
            9 => input with { Host = h with { ExecutorsDrained = fact } },
            10 => input with { Host = h with { PublishersDrained = fact } },
            _ => input with { Host = h with { ReleaseReconciled = fact } }
        };
        var reason = state == 0 ? slot < 5 ? EnrollmentRestartReason.MissingObservation : EnrollmentRestartReason.HostReconciliationRequired :
            slot < 4 ? EnrollmentRestartReason.InvalidStructure : slot == 4 ? EnrollmentRestartReason.ChangedPosition : EnrollmentRestartReason.ContradictoryObservation;
        Check(input, state == 0 ? EnrollmentRestartDecision.ReconciliationRequired : EnrollmentRestartDecision.Refused, reason);
    }

    /// <summary>Absent, malformed, mismatched and unsupported observations have explicit reasons.</summary>
    /// <param name="scenario">Input mutation.</param>
    /// <param name="decision">Expected stopped decision.</param>
    /// <param name="reason">Expected diagnostic.</param>
    [Theory]
    [InlineData("null", 1, 4)]
    [InlineData("expected-missing", 1, 4)]
    [InlineData("observed-missing", 1, 4)]
    [InlineData("structure-missing", 1, 4)]
    [InlineData("enrolled-missing", 1, 4)]
    [InlineData("actual-missing", 1, 4)]
    [InlineData("host-missing", 1, 8)]
    [InlineData("shape-unknown", 1, 4)]
    [InlineData("empty", 1, 5)]
    [InlineData("later", 1, 6)]
    [InlineData("source-root", 1, 7)]
    [InlineData("source-admission", 1, 7)]
    [InlineData("source-document", 1, 7)]
    [InlineData("source-sequence", 1, 7)]
    [InlineData("source-history", 1, 7)]
    [InlineData("capture", 1, 7)]
    [InlineData("head", 0, 3)]
    [InlineData("admin-head", 0, 3)]
    [InlineData("owner", 0, 3)]
    [InlineData("baseline", 0, 3)]
    [InlineData("scope", 0, 3)]
    [InlineData("shape-invalid", 0, 0)]
    [InlineData("fact-invalid", 0, 0)]
    [InlineData("host-invalid", 0, 0)]
    [InlineData("hash-invalid", 0, 0)]
    [InlineData("id-empty", 0, 0)]
    [InlineData("key-alias", 0, 0)]
    [InlineData("sequence-bound", 0, 0)]
    [InlineData("document-zero", 0, 0)]
    [InlineData("source-bound", 0, 0)]
    [InlineData("shape-contradiction", 0, 1)]
    [InlineData("successor-reused", 0, 9)]
    [InlineData("successor-empty", 0, 9)]
    [InlineData("generation-max", 0, 10)]
    public void Classify_InputBoundary_ProducesExplicitStoppedReason(string scenario, int decision, int reason)
    {
        var i = Good(); var p = i.Expected!; var b = i.ActualBaseline!;
        EnrollmentRestartObservations? input = scenario switch
        {
            "null" => null,
            "expected-missing" => i with { Expected = null },
            "observed-missing" => i with { Observed = null },
            "structure-missing" => i with { Structure = null },
            "enrolled-missing" => i with { EnrolledBaseline = null },
            "actual-missing" => i with { ActualBaseline = null },
            "host-missing" => i with { Host = null },
            "shape-unknown" => i with { Shape = EnrollmentRestartShape.Unknown },
            "empty" => Empty(i),
            "later" => Later(i),
            "source-root" => i with { ActualBaseline = b with { RootKey = "other" } },
            "source-admission" => i with { ActualBaseline = b with { AdmissionKey = "other" } },
            "source-document" => i with { ActualBaseline = b with { DocumentId = 8 } },
            "source-sequence" => i with { ActualBaseline = b with { Sequence = 4 } },
            "source-history" => i with { ActualBaseline = b with { HistoryDigest = Hash('e') } },
            "capture" => i with { ActualBaseline = b with { CaptureDigest = Hash('e') } },
            "head" => i with { Observed = p with { Digest = Hash('e') } },
            "admin-head" => i with { Observed = p with { AdministrativeSequence = 1 } },
            "owner" => i with { Observed = p with { OwnerGeneration = 2 } },
            "baseline" => i with { Observed = p with { Baseline = Guid.NewGuid() } },
            "scope" => i with { Observed = p with { ResourceScope = "other" } },
            "shape-invalid" => i with { Shape = (EnrollmentRestartShape)99 },
            "fact-invalid" => i with { Structure = i.Structure! with { Namespace = (EnrollmentRestartFact)99 } },
            "host-invalid" => i with { Host = i.Host! with { FreshScope = (EnrollmentRestartFact)99 } },
            "hash-invalid" => i with { Observed = p with { Digest = "invalid" } },
            "id-empty" => i with { Observed = p with { AuthorityId = Guid.Empty } },
            "key-alias" => i with { Observed = p with { AuthorityRootKey = "ADMIN" } },
            "sequence-bound" => i with { Observed = p with { Sequence = 65537 } },
            "document-zero" => i with { ActualBaseline = b with { DocumentId = 0 } },
            "source-bound" => i with { ActualBaseline = b with { Sequence = 10001 } },
            "shape-contradiction" => i with { Shape = EnrollmentRestartShape.Empty },
            "successor-reused" => i with { Successor = new(Owner) },
            "successor-empty" => i with { Successor = new(Guid.Empty) },
            "generation-max" => Exhausted(i),
            _ => throw new InvalidOperationException(scenario)
        };
        Check(input, (EnrollmentRestartDecision)decision, (EnrollmentRestartReason)reason);
    }

    /// <summary>Known invalid history and contradictions cannot hide behind absent operational facts.</summary>
    /// <param name="scenario">Combined observations.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(2)]
    public void Classify_ConflictingEvidence_RefusalPrecedesMissingFacts(int scenario)
    {
        var i = Good() with { Host = null, ActualBaseline = null };
        i = scenario switch
        {
            0 => i with { Expected = null, Structure = i.Structure! with { AuthorityHistory = EnrollmentRestartFact.Contradictory } },
            1 => i with { Structure = i.Structure! with { Namespace = EnrollmentRestartFact.Unknown, HeadUnchanged = EnrollmentRestartFact.Contradictory } },
            _ => i with { Structure = null, Host = Good().Host! with { PriorWorkReconciled = EnrollmentRestartFact.Contradictory } }
        };
        Check(i, EnrollmentRestartDecision.Refused, scenario == 0 ? EnrollmentRestartReason.InvalidStructure :
            scenario == 1 ? EnrollmentRestartReason.ChangedPosition : EnrollmentRestartReason.ContradictoryObservation);
    }

    /// <summary>ACK loss and a physically available owner never create an acknowledgment or resolve release.</summary>
    [Fact]
    public void Classify_AckLossAndUnknownRelease_NoReceiptOrAuthority()
    {
        var i = Good();
        Check(i, EnrollmentRestartDecision.ObservedEnrolledStopped, EnrollmentRestartReason.ExactEnrollmentObserved);
        Check(i with { Host = i.Host! with { ReleaseReconciled = EnrollmentRestartFact.Unknown } },
            EnrollmentRestartDecision.ReconciliationRequired, EnrollmentRestartReason.HostReconciliationRequired);
        var properties = typeof(EnrollmentRestartAssessment).GetProperties(System.Reflection.BindingFlags.Instance |
            System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic).Select(p => p.Name).ToHashSet();
        Assert.Equal(new[] { "Decision", "EqualityContract", "Reason", "WritersMustRemainStopped" }.Order(), properties.Order());
    }

    /// <summary>Every exact scope, head and owner pin participates in comparison.</summary>
    /// <param name="field">Pinned field changed without changing its shape validity.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(2)]
    [InlineData(3)]
    [InlineData(4)]
    [InlineData(5)]
    [InlineData(6)]
    [InlineData(7)]
    [InlineData(8)]
    [InlineData(9)]
    [InlineData(10)]
    [InlineData(11)]
    [InlineData(12)]
    [InlineData(13)]
    [InlineData(14)]
    [InlineData(15)]
    [InlineData(16)]
    public void Classify_ChangedPin_RefusesWithoutAdoption(int field)
    {
        var i = Good(); var p = i.Observed!;
        var changed = field switch
        {
            0 => p with { Deployment = "other" },
            1 => p with { ResourceScope = "other" },
            2 => p with { AdministrativeRootKey = "other" },
            3 => p with { AuthorityRootKey = "other" },
            4 => p with { AdministrativeId = Guid.NewGuid() },
            5 => p with { AuthorityId = Guid.NewGuid() },
            6 => p with { MetadataDigest = Hash('e') },
            7 => p with { AdministrativeSequence = 1 },
            8 => p with { AdministrativeDigest = Hash('e') },
            9 => p with { Sequence = 2 },
            10 => p with { Digest = Hash('e') },
            11 => p with { Owner = Guid.NewGuid() },
            12 => p with { OwnerGeneration = 2 },
            13 => p with { Baseline = Guid.NewGuid() },
            14 => p with { SelectionRevision = 2 },
            15 => p with { Selected = PilotBranch.Candidate },
            _ => p with { Deployment = "PILOT" }
        };
        Check(i with { Observed = changed }, EnrollmentRestartDecision.Refused, EnrollmentRestartReason.ChangedPosition);
        Assert.Equal(p, i.Expected);
    }

    /// <summary>Malformed canonical text and absent members refuse without throwing.</summary>
    /// <param name="text">Invalid canonical key.</param>
    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData(" ")]
    [InlineData("nul\0key")]
    public void Classify_MalformedKey_Refuses(string? text)
    {
        var i = Good();
        Check(i with { Observed = i.Observed! with { Deployment = text! } }, EnrollmentRestartDecision.Refused, EnrollmentRestartReason.InvalidInput);
    }

    /// <summary>Constructs an unpaired surrogate at runtime because attribute encoding cannot preserve it.</summary>
    [Fact]
    public void Classify_UnpairedSurrogate_Refuses()
    {
        var i = Good();
        Check(i with { Observed = i.Observed! with { Deployment = new string((char)0xd800, 1) } },
            EnrollmentRestartDecision.Refused, EnrollmentRestartReason.InvalidInput);
    }

    /// <summary>UTF-8 bytes, rather than character count alone, bound supplied keys.</summary>
    [Fact]
    public void Classify_OversizedUtf8Key_Refuses()
    {
        var i = Good();
        Check(i with { Observed = i.Observed! with { Deployment = new string('界', 1366) } },
            EnrollmentRestartDecision.Refused, EnrollmentRestartReason.InvalidInput);
    }

    /// <summary>Both supported source sequence endpoints are descriptions rather than executable authority.</summary>
    /// <param name="sequence">Boundary source sequence.</param>
    [Theory]
    [InlineData(0ul)]
    [InlineData(10000ul)]
    public void Classify_SourceSequenceBoundary_ObservesStopped(ulong sequence)
    {
        var i = Good(); var b = i.ActualBaseline! with { Sequence = sequence };
        Check(i with { EnrolledBaseline = b, ActualBaseline = b }, EnrollmentRestartDecision.ObservedEnrolledStopped,
            EnrollmentRestartReason.ExactEnrollmentObserved);
    }

    private static EnrollmentRestartObservations Empty(EnrollmentRestartObservations i)
    {
        var p = i.Expected! with { Sequence = 0, Owner = Guid.Empty, OwnerGeneration = 0, Baseline = Guid.Empty, SelectionRevision = 0 };
        return i with { Expected = p, Observed = p, Shape = EnrollmentRestartShape.Empty, EnrolledBaseline = null, ActualBaseline = null };
    }
    private static EnrollmentRestartObservations Later(EnrollmentRestartObservations i)
    {
        var p = i.Expected! with { Sequence = 2 };
        return i with { Expected = p, Observed = p, Shape = EnrollmentRestartShape.LaterHistory };
    }
    private static EnrollmentRestartObservations Exhausted(EnrollmentRestartObservations i)
    {
        var p = i.Expected! with { Sequence = 2, OwnerGeneration = ulong.MaxValue };
        return i with { Expected = p, Observed = p, Shape = EnrollmentRestartShape.LaterHistory, Successor = new(Guid.NewGuid()) };
    }
    private static void Check(EnrollmentRestartObservations? input, EnrollmentRestartDecision decision, EnrollmentRestartReason reason)
    {
        var result = EnrollmentRestartClassifier.Classify(input);
        Assert.Equal(decision, result.Decision); Assert.Equal(reason, result.Reason); Assert.True(result.WritersMustRemainStopped);
        Assert.Equal(result, EnrollmentRestartClassifier.Classify(input));
    }
}
