// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Sweeps all observed legacy conversion persistence boundaries in isolated workspaces.
// SPECIAL NOTES        : Injected I/O failures; native Linux durability delegation is tested explicitly.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================


using System.Collections.Concurrent;
using System.Text;
using Bosak.XmlDb.Core;
using Xunit;
using Xunit.Abstractions;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Qualifies every observed conversion persistence boundary with real I/O and immutable inputs.</summary>
public sealed class EpochMigrationFaultTests(ITestOutputHelper output) : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-mg4-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "legacy");
    private string Backup => Path.Combine(_area, "backup");

    /// <summary>Each isolated attempt injects exactly one error and preserves inputs, handles and publication invariants.</summary>
    /// <param name="mode">Process, modeled strong, or actual native Linux delegation.</param>
    /// <param name="fault">Before, after or actual partial write.</param>
    [Theory]
    [InlineData(0, "before")]
    [InlineData(0, "after")]
    [InlineData(0, "partial")]
    [InlineData(1, "before")]
    [InlineData(1, "after")]
    [InlineData(1, "partial")]
    [InlineData(2, "before")]
    [InlineData(2, "after")]
    [InlineData(2, "partial")]
    public void Convert_EveryObservedPersistenceFault_PreservesInputsAndPublishedPrefix(int mode, string fault)
    {
        if (mode == 2 && !OperatingSystem.IsLinux()) { output.WriteLine("Native Linux matrix not executed on this host."); return; }
        using var pinned = Seed(); var source = Bytes(Root); var input = Bytes(Backup); var sourceDirs = Directories(Root); var inputDirs = Directories(Backup);
        var referenceArea = Path.Combine(_area, "reference"); Directory.CreateDirectory(referenceArea);
        var referenceDestination = Path.Combine(referenceArea, "published"); var recording = Storage(mode); recording.Arm();
        var reference = EpochLegacyMigration.Convert(Backup, referenceDestination, recording);
        VerifyPublished(referenceDestination);
        var positions = recording.Calls.Select((call, index) => (call, index))
            .Where(item => fault == "partial" ? item.call.Operation == "WriteFile" && item.call.Moment == "before" : item.call.Moment == fault)
            .Select(item => item.index).ToArray(); Assert.NotEmpty(positions);
        var stores = new ConcurrentDictionary<Guid, byte>(); var epochs = new ConcurrentDictionary<Guid, byte>(); var migrations = new ConcurrentDictionary<Guid, byte>();
        // Same-depth parents preserve trace cardinality. Each worker owns only its attempt directory.
        Parallel.ForEach(positions, new ParallelOptions { MaxDegreeOfParallelism = 4 }, index =>
        {
            var area = Path.Combine(_area, "attempt-" + index); Directory.CreateDirectory(area); var destination = Path.Combine(area, "published");
            var storage = Storage(mode); storage.Arm(index, fault == "partial");
            Assert.Throws<IOException>(() => EpochLegacyMigration.Convert(Backup, destination, storage));
            Assert.True(storage.Fired); Assert.Equal(recording.Calls[index].Operation, storage.Calls[index].Operation); Assert.Equal(recording.Calls[index].Moment, storage.Calls[index].Moment);
            AssertBytes(source, Root); AssertBytes(input, Backup); Assert.Equal(sourceDirs, Directories(Root)); Assert.Equal(inputDirs, Directories(Backup));
            if (Directory.Exists(destination))
            {
                var origin = VerifyPublished(destination);
                Assert.NotEqual(reference.Destination.StoreId, origin.Destination.StoreId); Assert.NotEqual(reference.Destination.EpochId, origin.Destination.EpochId);
                Assert.True(stores.TryAdd(origin.Destination.StoreId, 0)); Assert.True(epochs.TryAdd(origin.Destination.EpochId, 0)); Assert.True(migrations.TryAdd(origin.MigrationId, 0));
                var published = Bytes(destination);
                Assert.Throws<IOException>(() => EpochLegacyMigration.Convert(Backup, destination)); AssertBytes(published, destination);
            }
            // Inputs are intentionally shared/pinned. Exclusive opens cover only this worker's owned outputs.
            foreach (var file in Directory.GetFiles(area, "*", SearchOption.AllDirectories)) using (new FileStream(file, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) { }
            Assert.StartsWith(Path.GetFullPath(_area) + Path.DirectorySeparatorChar, Path.GetFullPath(area), StringComparison.Ordinal);
            Directory.Delete(area, true);
        });
        Assert.Equal("old", pinned.ReadValue(Target(pinned))); AssertBytes(source, Root); AssertBytes(input, Backup);
        output.WriteLine($"mg4-{mode}/{fault}: {positions.Length} fault positions verified.");
    }

    private EpochMigrationOrigin VerifyPublished(string bundle)
    {
        var root = Path.Combine(bundle, "store");
        Assert.Equal(new[] { "migration.bin", "store" }, Directory.GetFileSystemEntries(bundle).Select(Path.GetFileName).Order(StringComparer.Ordinal));
        var origin = EpochMigrationCodec.ValidateHeaders(File.ReadAllBytes(Path.Combine(bundle, "migration.bin")), File.ReadAllBytes(Path.Combine(Backup, "inventory.bin")),
            File.ReadAllBytes(Path.Combine(Backup, "COMPLETE")), File.ReadAllBytes(Path.Combine(Backup, "data", "FORMAT")), File.ReadAllBytes(Path.Combine(Backup, "data", ".transactions", "CONTROL")),
            File.ReadAllBytes(Path.Combine(Backup, "data", ".transactions", "CURRENT")), File.ReadAllBytes(Path.Combine(root, "FORMAT")), File.ReadAllBytes(Path.Combine(root, ".transactions", "CURRENT")));
        Assert.Equal(1UL, origin.CommitSequence);
        for (var repeat = 0; repeat < 2; repeat++)
        {
            using var owner = EpochScalarCoordinator.Open(root); using var read = owner.BeginRead(0);
            Assert.Equal(origin.Destination, owner.Identity); Assert.Equal(1UL, read.CommitSequence); Assert.Equal("new", read.ReadValue(Target(read)));
            using var admission = EpochAdmission.Acquire(root, origin.Destination, profile: EpochProfile.ScalarWal);
            var binding = EpochAuthorityBinding.Create(File.ReadAllBytes(Path.Combine(root, "FORMAT")), origin.BaseHash);
            using var old = EpochScalarHistory.Open(root, 0, admission, binding.BaseHash); Assert.Equal("old", old.ReadValue(Target(old)));
        }
        var names = EpochBackupStorage.FileSet(root, 1, 1); var format = File.ReadAllBytes(Path.Combine(root, "FORMAT"));
        var expected = new EpochBackupInventory(origin.BackupId, EpochAuthorityBinding.Create(format, origin.BaseHash), 1, origin.HeadManifestHash, origin.DestinationHeadWalHash,
            names.Select(name => { var bytes = File.ReadAllBytes(Path.Combine(root, name)); return new BackupEntry(name, bytes.Length, System.Security.Cryptography.SHA256.HashData(bytes)); }).ToArray());
        var storage = new LocalTransactionStorage(); var workspace = EpochBackupStorage.Workspace(Path.Combine(Path.GetDirectoryName(bundle)!, "oracle"), storage);
        var audit = Path.Combine(Path.GetDirectoryName(bundle)!, "audit-data");
        BackupStorage.Copy(root, audit, names, storage);
        EpochBackupStorage.VerifyCopies(audit, workspace, expected, storage); EpochBackupStorage.RemoveWorkspace(workspace, storage);
        return origin;
    }
    private ImmutableXmlSnapshot Seed()
    {
        Directory.CreateDirectory(_area); using var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>")); XmlFragmentImporter.Import(input, Root);
        using var owner = EmbeddedXmlDatabase.Open(Root); var pinned = owner.BeginRead(0);
        try
        {
            using var tx = owner.BeginWrite(); tx.ReplaceNodeValue(Target(pinned), "new"); tx.Commit(); owner.CreateBackup(Backup); return pinned;
        }
        catch { pinned.Dispose(); throw; }
    }
    private static FaultingTransactionStorage Storage(int mode)
    {
        var storage = new FaultingTransactionStorage(mode == 0 ? DurabilityMode.ProcessCrash : DurabilityMode.FileAndDirectoryFlush, mode == 2);
        Assert.Equal(mode == 2 ? DurabilityMode.FileAndDirectoryFlush : DurabilityMode.ProcessCrash, storage.EffectiveDurability); return storage;
    }
    private static ulong Target(ImmutableXmlSnapshot snapshot) => Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();
    private static Dictionary<string, byte[]> Bytes(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories).ToDictionary(p => Path.GetRelativePath(root, p), File.ReadAllBytes);
    private static string[] Directories(string root) => Directory.GetDirectories(root, "*", SearchOption.AllDirectories).Select(p => Path.GetRelativePath(root, p)).Order().ToArray();
    private static void AssertBytes(Dictionary<string, byte[]> expected, string root) { var actual = Bytes(root); Assert.Equal(expected.Keys.Order(), actual.Keys.Order()); foreach (var f in expected) Assert.Equal(f.Value, actual[f.Key]); }
    /// <summary>Deletes this fixture's isolated data once all workers and retained snapshots finish.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
