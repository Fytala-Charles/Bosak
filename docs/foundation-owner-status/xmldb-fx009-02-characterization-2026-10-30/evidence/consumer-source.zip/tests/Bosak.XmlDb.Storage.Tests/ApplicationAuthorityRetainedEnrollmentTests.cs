// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Qualifies retained preparation and no-output combined admission under real owners.
// SPECIAL NOTES        : EF2 real stores and live registrations only; no authority bytes or work admission.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Reflection;
using System.Text;
using Bosak.XmlDb.Core;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Qualifies retained preparation and no-output combined admission under real owners.</summary>
public sealed class ApplicationAuthorityRetainedEnrollmentTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ef2-" + Guid.NewGuid().ToString("N"));
    private string Source => Path.Combine(_area, "source");
    private string Capture => Path.Combine(_area, "capture");
    private string Host => Path.Combine(_area, "host");
    private string Authority => Path.Combine(_area, "authority");
    private readonly Guid _admin = Guid.NewGuid();
    private ApplicationAuthorityConfiguration Configuration => new(Guid.Parse("10213243-5465-7687-98a9-bacbdcedfe0f"), _admin, "pilot", "orders", "admin", "authority");
    private Dictionary<string, string> Roots => new() { ["admin"] = Host, ["authority"] = Authority, ["source"] = Source, ["capture"] = Capture };
    private static EmbeddedHostInspectionEvidence Inspection(EmbeddedHostLifetime parent) => new(parent.Context, true, true, true, true, true);
    private ApplicationEnrollmentEvidence Evidence(EmbeddedHostLifetime parent) => new(parent.Context, Configuration.AuthorityId, "source", "source-admission", "capture", Guid.NewGuid(), new string('a', 64), true, true, true, true, true, true);
    private EmbeddedHostLifetime Parent()
    {
        Directory.CreateDirectory(Host); File.WriteAllBytes(Path.Combine(Host, "owner.lock"), []);
        File.WriteAllBytes(Path.Combine(Host, "host.meta"), HostJournalCodec.EncodeMetadata(_admin, "pilot", "orders")); File.WriteAllBytes(Path.Combine(Host, "journal.bin"), []);
        return EmbeddedHostLifetime.OpenExisting(Host, "pilot", "orders", [Source, Capture, Authority]);
    }
    private ApplicationAuthorityLifetime Provision(EmbeddedHostLifetime parent) => ApplicationAuthorityLifetime.Provision(parent, parent.JournalStatus.KnownPosition, Inspection(parent), Authority, Configuration, Roots, new(Authority, true, true, true));
    private void Seed(int count = 1)
    {
        Directory.CreateDirectory(_area); using var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>")); XmlFragmentImporter.Import(input, Source);
        using var source = EmbeddedXmlDatabase.Open(Source);
        for (var i = 0; i < count; i++) { using var read = source.BeginRead(); using var tx = source.BeginWrite(); tx.ReplaceNodeValue(Target(read), "new-" + i); tx.Commit(); }
    }
    private static ulong Target(ImmutableXmlSnapshot snapshot) => Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();
    private Dictionary<string, byte[]> Bytes()
    {
        var result = new Dictionary<string, byte[]>();
        foreach (var path in Directory.GetFiles(_area, "*", SearchOption.AllDirectories).Where(p => Path.GetFileName(p) is not ("owner.lock" or "authority.lock" or "writer.lock")))
        {
            using var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            var bytes = new byte[(int)file.Length]; file.ReadExactly(bytes); result.Add(Path.GetRelativePath(_area, path), bytes);
        }
        return result;
    }
    private void AssertBytes(Dictionary<string, byte[]> before)
    {
        var after = Bytes(); Assert.Equal(before.Keys.Order(), after.Keys.Order()); foreach (var pair in before) Assert.Equal(pair.Value, after[pair.Key]);
    }


    /// <summary>Real baseline preparation transfers actual source/admin/authority retention and produces no output.</summary>
    /// <param name="sequence">Actual source commit sequence.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(3)]
    public void PrepareAndArm_RealBaseline_AllOwnersRetainedWithoutWrites(int sequence)
    {
        Seed(sequence); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); var before = Bytes();
        using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence); var description = plan.Describe();
        Assert.Throws<InvalidOperationException>(() => authority.Inspect()); Assert.Throws<InvalidOperationException>(() => authority.PrepareFirstEnrollment(freeze, capture, evidence));
        using var execution = authority.TryArmRetainedFirstEnrollment(plan, evidence with { }); Assert.NotNull(execution); Assert.True(execution.Armed); Assert.True(plan.Consumed);
        Assert.True(source.EnrollmentOwnershipStatus.StopLatched); plan.Dispose(); freeze.Dispose(); source.Dispose(); authority.Dispose(); parent.Dispose();
        Assert.False(authority.IsReleased); Assert.False(parent.IsReleased); Assert.Equal(EnrollmentSourceReleaseState.RetainedClosing, source.EnrollmentOwnershipStatus.ReleaseState);
        foreach (var path in new[] { Path.Combine(Source, ".transactions", "writer.lock"), Path.Combine(Host, "owner.lock"), Path.Combine(Authority, "authority.lock") })
            Assert.Throws<IOException>(() => { using var blocked = new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None); });
        Assert.Equal(description, execution.Inspect()); Assert.True(description.WritersMustRemainStopped); AssertBytes(before);
        execution.Dispose(); execution.Dispose(); Assert.True(authority.IsReleased); Assert.True(parent.IsReleased); Assert.Equal(EnrollmentSourceReleaseState.Released, source.EnrollmentOwnershipStatus.ReleaseState);
    }

    /// <summary>Closing any required owner before the atomic arm refuses without writing or admitting execution.</summary>
    /// <param name="which">Closed owner.</param>
    [Theory]
    [InlineData("source")]
    [InlineData("freeze")]
    [InlineData("parent")]
    [InlineData("authority")]
    public void Arm_ClosingWins_NoOutput(string which)
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent);
        using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence); var before = Bytes();
        Assert.Throws<ObjectDisposedException>(() => authority.TryArmRetainedFirstEnrollmentCore(plan, evidence, () =>
        { if (which == "source") source.Dispose(); if (which == "freeze") freeze.Dispose(); if (which == "parent") parent.Dispose(); if (which == "authority") authority.Dispose(); }));
        Assert.True(plan.Consumed); Assert.False(source.EnrollmentOwnershipStatus.StopLatched); Assert.True(authority.IsFaulted); AssertBytes(before);
    }

    /// <summary>Busy source/parent/authority gates refuse without holding other lifecycle gates during cleanup.</summary>
    /// <param name="which">Contended gate.</param>
    [Theory]
    [InlineData("source")]
    [InlineData("parent")]
    [InlineData("authority")]
    public void Arm_BusyGate_NoNestedIoWaitOrWrite(string which)
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence);
        var before = Bytes(); var sourceGate = Gate(source); var parentGate = Gate(parent); var authorityGate = Gate(authority);
        var held = which == "source" ? sourceGate : which == "parent" ? parentGate : authorityGate;
        using var entered = new ManualResetEventSlim(); using var observe = new ManualResetEventSlim(); var observed = false; Exception? error = null; Thread? thread = null;
        var result = authority.TryArmRetainedFirstEnrollmentCore(plan, evidence, () =>
        {
            thread = new Thread(() =>
            {
                try
                {
                    lock (held)
                    {
                        entered.Set(); if (!observe.Wait(TimeSpan.FromSeconds(30))) throw new TimeoutException();
                        // Caller is now entering/refusing admission. Repeated nonblocking probes test that
                        // cleanup never waits on this held gate while retaining either of the others.
                        var watch = System.Diagnostics.Stopwatch.StartNew();
                        while (watch.Elapsed < TimeSpan.FromSeconds(3))
                        {
                            var first = ReferenceEquals(held, authorityGate) || Monitor.TryEnter(authorityGate);
                            if (first)
                            {
                                var second = ReferenceEquals(held, parentGate) || Monitor.TryEnter(parentGate);
                                if (second) { if (!ReferenceEquals(held, parentGate)) Monitor.Exit(parentGate); observed = true; }
                                if (!ReferenceEquals(held, authorityGate)) Monitor.Exit(authorityGate);
                            }
                            if (observed) break; Thread.Yield();
                        }
                    }
                }
                catch (Exception caught) { error = caught; entered.Set(); }
            })
            { IsBackground = true };
            thread.Start(); Assert.True(entered.Wait(TimeSpan.FromSeconds(30)));
        }, armed => { Assert.False(armed); observe.Set(); Assert.True(thread!.Join(TimeSpan.FromSeconds(30))); });
        Assert.True(thread!.Join(TimeSpan.FromSeconds(30))); Assert.Null(error); Assert.True(observed); Assert.Null(result); Assert.True(plan.Consumed); Assert.False(source.EnrollmentOwnershipStatus.StopLatched); AssertBytes(before);
    }
    private static object Gate(object owner) => owner.GetType().GetField("_gate", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(owner)!;

    /// <summary>Caller plan disposal during claimed validation cannot release the executing operation early.</summary>
    [Fact]
    public void Arm_PlanDisposedBeforeAdmission_DrainsSafelyWithoutOutput()
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence);
        var before = Bytes(); Assert.Throws<InvalidOperationException>(() => authority.TryArmRetainedFirstEnrollmentCore(plan, evidence, () =>
        { plan.Dispose(); Assert.Equal(1, authority.ActiveInspections); Assert.True(source.EnrollmentOwnershipStatus.HasRetainer); }));
        Assert.Equal(0, authority.ActiveInspections); Assert.False(source.EnrollmentOwnershipStatus.HasRetainer); AssertBytes(before);
    }

    /// <summary>Changed baseline, evidence or authority state refuses before any output and preserves invalid bytes.</summary>
    /// <param name="which">Invalidated binding.</param>
    [Theory]
    [InlineData("capture")]
    [InlineData("wal")]
    [InlineData("staging")]
    [InlineData("evidence")]
    public void Arm_ChangedBinding_FaultsWithoutRepair(string which)
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence);
        if (which == "capture") File.AppendAllText(Path.Combine(Capture, "inventory.bin"), "changed");
        if (which == "wal") { var path = Path.Combine(Source, ".transactions", "wal", EpochAuthorityCodec.WalFileName(1)); var bytes = File.ReadAllBytes(path); bytes[^1] ^= 1; File.WriteAllBytes(path, bytes); }
        if (which == "staging") File.WriteAllText(Path.Combine(Source, ".transactions", "staging", "unknown"), "retain");
        var before = Bytes(); var error = Record.Exception(() => authority.TryArmRetainedFirstEnrollment(plan, which == "evidence" ? evidence with { ReconciliationId = Guid.NewGuid() } : evidence));
        Assert.IsType(which == "evidence" ? typeof(InvalidOperationException) : typeof(InvalidDataException), error); Assert.True(authority.IsFaulted); Assert.True(plan.Consumed); AssertBytes(before);
    }

    /// <summary>Copied preparation values cannot replace the actual owner registration or consume its plan.</summary>
    [Fact]
    public void Arm_ForgedPlan_RejectsWithoutConsumingActual()
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence);
        using var forged = new ApplicationAuthorityLifetime.RetainedEnrollmentPreparation(authority, capture, evidence, plan.Pin, plan.Describe() with { }, new(authority, new MemoryStream()));
        Assert.Throws<InvalidOperationException>(() => authority.TryArmRetainedFirstEnrollment(forged, evidence)); Assert.False(plan.Consumed);
        using var execution = authority.TryArmRetainedFirstEnrollment(plan, evidence); Assert.NotNull(execution); Assert.Throws<InvalidOperationException>(() => authority.TryArmRetainedFirstEnrollment(plan, evidence));
    }

    /// <summary>Foreign-thread dispatch rejects without consuming a valid actual preparation.</summary>
    [Fact]
    public void Arm_WrongThread_RejectsBeforeConsumption()
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence);
        Exception? error = null; var thread = new Thread(() => error = Record.Exception(() => authority.TryArmRetainedFirstEnrollment(plan, evidence))) { IsBackground = true };
        thread.Start(); Assert.True(thread.Join(TimeSpan.FromSeconds(30))); Assert.IsType<InvalidOperationException>(error); Assert.False(plan.Consumed); using var execution = authority.TryArmRetainedFirstEnrollment(plan, evidence); Assert.NotNull(execution);
    }

    /// <summary>Disposed unconsumed plans drain the source and authority operation, but cannot rearm the initializer.</summary>
    [Fact]
    public void PendingPlanDisposed_DrainsAllActualRegistrations()
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence);
        authority.Dispose(); parent.Dispose(); source.Dispose(); freeze.Dispose(); Assert.False(authority.IsReleased); plan.Dispose();
        Assert.True(authority.IsReleased); Assert.True(parent.IsReleased); Assert.Equal(EnrollmentSourceReleaseState.Released, source.EnrollmentOwnershipStatus.ReleaseState);
        Assert.Throws<InvalidOperationException>(() => authority.TryArmRetainedFirstEnrollment(plan, evidence));
    }

    /// <summary>Unconfirmed source close leaves actual authority/admin ownership held and is not silently acknowledged.</summary>
    /// <param name="afterClose">Whether source close fails after actual delegation.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Execution_SourceCloseUnknown_RetainsAuthorityAndParent(bool afterClose)
    {
        Seed(); using var closer = new FailingClose(afterClose); using var source = EmbeddedXmlDatabase.Open(Source); var parent = Parent(); var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent);
        using var plan = authority.PrepareRetainedFirstEnrollmentCore(freeze, capture, evidence, closer); var execution = authority.TryArmRetainedFirstEnrollment(plan, evidence); Assert.NotNull(execution);
        source.Dispose(); freeze.Dispose(); authority.Dispose(); parent.Dispose(); Assert.Throws<IOException>(execution.Dispose);
        Assert.Equal(EnrollmentSourceReleaseState.Unknown, source.EnrollmentOwnershipStatus.ReleaseState); Assert.True(authority.IsFaulted); Assert.False(authority.IsReleased); Assert.False(parent.IsReleased); Assert.Equal(1, authority.ActiveInspections);
        Assert.Throws<IOException>(() => new FileStream(Path.Combine(Host, "owner.lock"), FileMode.Open, FileAccess.ReadWrite, FileShare.None));
        // Fresh owned-fixture cleanup closes the actual test handles without marking unknown
        // production ownership confirmed or introducing an automatic retry path.
        closer.Dispose(); ((FileStream[])typeof(ApplicationAuthorityLifetime).GetField("_roles", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(authority)!).ToList().ForEach(f => f.Dispose());
        foreach (var field in new[] { "_journal", "_metadata", "_owner" }) ((FileStream)typeof(EmbeddedHostLifetime).GetField(field, BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(parent)!).Dispose();
    }
    /// <summary>Admission callbacks are outside every gate and closing after the arm keeps execution live.</summary>
    [Fact]
    public void Arm_WinsBeforeClosing_ActualExecutionCompletes()
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence); var before = Bytes();
        using var execution = authority.TryArmRetainedFirstEnrollmentCore(plan, evidence, null, armed =>
        {
            Assert.True(armed); Assert.False(Monitor.IsEntered(Gate(source))); Assert.False(Monitor.IsEntered(Gate(parent))); Assert.False(Monitor.IsEntered(Gate(authority)));
            plan.Dispose(); freeze.Dispose(); source.Dispose(); authority.Dispose(); parent.Dispose();
        });
        Assert.NotNull(execution); Assert.True(execution.Inspect().WritersMustRemainStopped); AssertBytes(before); execution.Dispose(); Assert.True(authority.IsReleased); Assert.True(parent.IsReleased);
    }

    /// <summary>Preexisting actual reads must drain before retained mode reserves its initializer.</summary>
    [Fact]
    public void Prepare_ExistingRead_RejectsThenAllowsAfterActualDrain()
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent);
        using var entered = new ManualResetEventSlim(); using var release = new ManualResetEventSlim(); Exception? error = null;
        var thread = new Thread(() => error = Record.Exception(() => authority.InspectCore(() => { entered.Set(); if (!release.Wait(TimeSpan.FromSeconds(30))) throw new TimeoutException(); }))) { IsBackground = true };
        thread.Start(); Assert.True(entered.Wait(TimeSpan.FromSeconds(30)));
        try { Assert.Throws<InvalidOperationException>(() => authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence)); Assert.False(source.EnrollmentOwnershipStatus.HasRetainer); }
        finally { release.Set(); Assert.True(thread.Join(TimeSpan.FromSeconds(30))); }
        Assert.Null(error); using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence); Assert.False(plan.Consumed);
    }

    /// <summary>Old borrowed plans remain read-only and cannot be upgraded into retained admission.</summary>
    [Fact]
    public void Prepare_BorrowedModeCannotUpgrade()
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent);
        using var borrowed = authority.PrepareFirstEnrollment(freeze, capture, evidence);
        Assert.Throws<InvalidOperationException>(() => authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence)); Assert.False(source.EnrollmentOwnershipStatus.HasRetainer);
        Assert.True(authority.CheckFirstEnrollment(borrowed, evidence).WritersMustRemainStopped);
    }

    /// <summary>Invalid supplied scope or actual capture cannot acquire a source child or be retried on the initializer.</summary>
    /// <param name="which">Invalid binding.</param>
    [Theory]
    [InlineData("fresh")]
    [InlineData("context")]
    [InlineData("capture")]
    public void Prepare_InvalidBinding_RejectsWithoutOutput(string which)
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); var before = Bytes();
        if (which == "fresh") evidence = evidence with { Fresh = false }; if (which == "context") evidence = evidence with { Context = parent.Context with { SessionId = Guid.NewGuid() } };
        Assert.Throws<InvalidOperationException>(() => authority.PrepareRetainedFirstEnrollment(freeze, which == "capture" ? new(Capture, capture.InventoryBytes) : capture, evidence));
        Assert.True(authority.IsFaulted); Assert.False(source.EnrollmentOwnershipStatus.HasRetainer); Assert.Equal(0, authority.ActiveInspections); AssertBytes(before);
    }

    /// <summary>Reentrant source callbacks cannot reverse lock order or consume actual retained preparation.</summary>
    [Fact]
    public void Protocol_CallerHeldSourceGate_RejectsBeforeAdmissionOrValidation()
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent);
        freeze.Inspect(state => { Assert.Throws<InvalidOperationException>(() => authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence)); return true; });
        using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence);
        freeze.Inspect(state => { Assert.Throws<InvalidOperationException>(() => authority.TryArmRetainedFirstEnrollment(plan, evidence)); Assert.Throws<InvalidOperationException>(plan.Dispose); return true; }); Assert.False(plan.Consumed);
        using var execution = authority.TryArmRetainedFirstEnrollment(plan, evidence); Assert.NotNull(execution);
        freeze.Inspect(state => { Assert.Throws<InvalidOperationException>(() => execution.Inspect()); Assert.Throws<InvalidOperationException>(execution.Dispose); Assert.Throws<InvalidOperationException>(plan.Dispose); return true; }); Assert.True(execution.Inspect().WritersMustRemainStopped);
    }

    private sealed class FailingClose(bool afterClose) : IEnrollmentSourceLeaseClose, IDisposable
    {
        private FileStream? _stream;
        /// <inheritdoc/>
        public void Close(FileStream stream) { _stream = stream; if (afterClose) stream.Dispose(); throw new IOException("Injected source close confirmation failure."); }
        /// <summary>Closes only the captured private test handle without rearming source state.</summary>
        public void Dispose() => _stream?.Dispose();
    }
    /// <summary>Removes only this test's fresh owned workspace after actual handles finish.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
