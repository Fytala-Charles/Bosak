// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies legacy preflight, independent redo, immutable inputs and owned-workspace cleanup.
// SPECIAL NOTES        : Internal legacy verification only; no conversion, source recovery, routing or retirement.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Security.Cryptography;
using System.Text;
using Bosak.XmlDb.Core;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Verifies strict legacy migration prerequisites without converting or routing a store.</summary>
public sealed class LegacyMigrationVerifierTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-mg2-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "source");
    private string Backup => Path.Combine(_area, "backup");
    private string Destination => Path.Combine(_area, "workspace-hint");
    private string Data => Path.Combine(Backup, "data");

    /// <summary>Both independent oracles verify all retained sequences without changing the source, artifact or old lazy readers.</summary>
    /// <param name="count">Captured sequence.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(3)]
    public void Verify_CompleteAndRedoHistory_PreservesInputsAndCleansOwnedCopies(int count)
    {
        Seed(count); using var owner = EmbeddedXmlDatabase.Open(Root); using var pinned = owner.BeginRead(0);
        var input = Bytes(Backup); var source = Bytes(Root, true); var stages = new List<LegacyMigrationStage>(); owner.Dispose();
        var result = LegacyMigrationVerifier.Verify(Backup, Destination, checkpoint: stages.Add);
        Assert.Equal((ulong)count, result.Identity.CommitSequence); Assert.Equal(Enum.GetValues<LegacyMigrationStage>(), stages);
        Assert.Equal(count == 0 ? "old" : "one", pinned.ReadValue(Target(pinned, "DocumentID")));
        AssertBytes(input, Backup); AssertBytes(source, Root, true); Assert.False(Directory.Exists(Destination));
        Assert.Empty(Directory.GetDirectories(_area, ".xmldb-epoch-backup-*"));
        LegacyMigrationVerifier.Verify(Backup, Destination); AssertBytes(input, Backup);
    }

    /// <summary>Known malformed artifact/history classes fail before any storage writes or workspace allocation.</summary>
    /// <param name="fault">Corruption class.</param>
    [Theory]
    [InlineData("wal-partial")]
    [InlineData("wal-gap")]
    [InlineData("generation-missing")]
    [InlineData("generation-format")]
    [InlineData("root-format")]
    [InlineData("stale-current")]
    [InlineData("wrong-control")]
    [InlineData("duplicate-transaction")]
    [InlineData("wrong-previous")]
    [InlineData("extra-file")]
    [InlineData("extra-directory")]
    [InlineData("corrupt-fragment")]
    [InlineData("unsupported-scalar")]
    public void Verify_InvalidHistory_FailsBeforeWrites(string fault)
    {
        Seed(3); var walPath = Wal(3); var wal = TransactionCodec.ReadWal(walPath)!;
        switch (fault)
        {
            case "wal-partial": File.WriteAllBytes(walPath, File.ReadAllBytes(walPath)[..100]); break;
            case "wal-gap": File.Delete(Wal(2)); break;
            case "generation-missing": Directory.Delete(Generation(2), true); break;
            case "root-format": File.WriteAllBytes(Path.Combine(Data, "FORMAT"), EpochCodec.EncodeProfile(new(Guid.NewGuid(), Guid.NewGuid(), 1), EpochProfile.ScalarWal)); break;
            case "generation-format": File.WriteAllBytes(Path.Combine(Generation(2), "FORMAT"), EpochCodec.EncodeFormat(new(Guid.NewGuid(), Guid.NewGuid(), 1))); break;
            case "stale-current": File.WriteAllBytes(Current, TransactionCodec.EncodePointer(new(1, 0, BackupStorage.ReadArtifact(Backup).BaseHash), "BXHD")); break;
            case "wrong-control": File.WriteAllBytes(Path.Combine(Data, ".transactions", "CONTROL"), TransactionCodec.EncodePointer(new(2, 0, new byte[32]), "BXTC")); break;
            case "duplicate-transaction": File.WriteAllBytes(walPath, TransactionCodec.EncodeWal(wal with { TransactionId = TransactionCodec.ReadWal(Wal(1))!.TransactionId })); break;
            case "wrong-previous": File.WriteAllBytes(walPath, TransactionCodec.EncodeWal(wal with { PreviousManifestHash = new byte[32] })); break;
            case "extra-file": File.WriteAllText(Path.Combine(Data, "extra"), "keep"); break;
            case "extra-directory": Directory.CreateDirectory(Path.Combine(Data, "extra")); break;
            case "corrupt-fragment": File.WriteAllBytes(Path.Combine(Generation(2), "fragments", "1.bin"), [1, 2, 3]); break;
            case "unsupported-scalar": File.WriteAllBytes(walPath, TransactionCodec.EncodeWal(wal with { NodeId = 1 })); break;
        }
        Reseal(); var input = Bytes(Backup); var directories = Directories(Backup); var storage = new FaultingTransactionStorage(); storage.Arm();
        Assert.Throws<InvalidDataException>(() => LegacyMigrationVerifier.Verify(Backup, Destination, storage));
        Assert.Empty(storage.Calls); AssertBytes(input, Backup); Assert.Equal(directories, Directories(Backup));
        Assert.Empty(Directory.GetDirectories(_area, ".xmldb-epoch-backup-*"));
    }

    /// <summary>A coherently resealed extra scalar change fails strict transition preflight even when the WAL target is correct.</summary>
    [Fact]
    public void Verify_ResealedUnchangedNodeMutation_FailsBeforeWorkspace()
    {
        Seed(1); using var read = ImmutableXmlSnapshot.OpenVersion(Data, 1, 0);
        var a = Path.Combine(_area, "first"); var b = Path.Combine(_area, "second"); var storage = new LocalTransactionStorage();
        ScalarGeneration.Build(Data, a, 1, Target(read, "DocumentID"), "one", null, storage);
        var hash = ScalarGeneration.Build(a, b, 1, Target(read, "line"), "smuggled", null, storage);
        Directory.Delete(Generation(1), true); Directory.Move(b, Generation(1)); RebindHead(hash);
        var input = Bytes(Backup); var faulting = new FaultingTransactionStorage(); faulting.Arm();
        Assert.Throws<InvalidDataException>(() => LegacyMigrationVerifier.Verify(Backup, Destination, faulting));
        Assert.Empty(faulting.Calls); AssertBytes(input, Backup);
    }

    /// <summary>Hash-consistent unused bytes pass complete logical checks but fail canonical deterministic full redo.</summary>
    [Fact]
    public void Verify_UnusedPayloadByte_PassesCompleteButRejectsRedo()
    {
        Seed(1); var fragmentPath = Path.Combine(Generation(1), "fragments", "1.bin");
        var payload = BinaryEnvelope.Decode(File.ReadAllBytes(fragmentPath), "BXFG", reader =>
        { reader.ReadUInt64(); reader.ReadUInt64(); reader.ReadByte(); return reader.ReadBytes(reader.ReadInt32()); });
        var fragment = BinaryEnvelope.Encode("BXFG", writer =>
        { writer.Write(1UL); writer.Write(1UL); writer.Write((byte)0); writer.Write(payload.Length + 1); writer.Write(payload); writer.Write((byte)0); });
        File.WriteAllBytes(fragmentPath, fragment);
        var manifestPath = Path.Combine(Generation(1), "documents", "1", "manifest.bin"); var manifest = StoreCodec.ReadManifest(File.ReadAllBytes(manifestPath));
        var changed = StoreCodec.WriteManifest(manifest with { Fragments = manifest.Fragments.Select(f => f.Id == 1 ? f with { Length = f.Length + 1, Hash = SHA256.HashData(fragment) } : f).ToArray() });
        File.WriteAllBytes(manifestPath, changed); RebindHead(SHA256.HashData(changed));
        var input = Bytes(Backup); var stages = new List<LegacyMigrationStage>();
        Assert.Throws<InvalidDataException>(() => LegacyMigrationVerifier.Verify(Backup, Destination, checkpoint: stages.Add));
        Assert.Contains(LegacyMigrationStage.CompleteVerified, stages); Assert.DoesNotContain(LegacyMigrationStage.RedoVerified, stages); AssertBytes(input, Backup);
    }

    /// <summary>Every high-level interruption leaves input unchanged, releases handles and permits a fresh verification.</summary>
    /// <param name="stage">Checkpoint ordinal.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(2)]
    [InlineData(3)]
    [InlineData(4)]
    public void Verify_InterruptedCheckpoint_ReleasesHandlesAndCanRetry(int stage)
    {
        Seed(1); var input = Bytes(Backup);
        Assert.Throws<IOException>(() => LegacyMigrationVerifier.Verify(Backup, Destination, checkpoint: actual => { if ((int)actual == stage) throw new IOException("injected"); }));
        AssertBytes(input, Backup); Assert.False(Directory.Exists(Destination));
        foreach (var path in Directory.GetFiles(_area, "*", SearchOption.AllDirectories)) using (new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) { }
        LegacyMigrationVerifier.Verify(Backup, Destination); AssertBytes(input, Backup);
    }

    /// <summary>Mutating verified source data or an owned copied clone cannot result in successful verification.</summary>
    /// <param name="source">Whether to corrupt the source rather than the private copy.</param>
    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public void Verify_ChangedDataAfterPreflight_Rejects(bool source)
    {
        Seed(1);
        Assert.Throws<InvalidDataException>(() => LegacyMigrationVerifier.Verify(Backup, Destination, checkpoint: stage =>
        {
            if (stage != LegacyMigrationStage.CompleteCopied) return;
            var data = source ? Data : Path.Combine(Directory.GetDirectories(_area, ".xmldb-epoch-backup-*").Single(), "verify-complete");
            File.WriteAllBytes(Path.Combine(data, "fragments", "1.bin"), [1]);
        }));
    }

    /// <summary>Destination overlap and existing paths never merge, overwrite or publish results.</summary>
    /// <param name="kind">Destination refusal class.</param>
    [Theory]
    [InlineData("overlap")]
    [InlineData("existing")]
    public void Verify_InvalidDestination_RejectsWithoutWrites(string kind)
    {
        Seed(0); var path = kind == "overlap" ? Path.Combine(Backup, "inside") : Destination;
        if (kind == "existing") Directory.CreateDirectory(path);
        var storage = new FaultingTransactionStorage(); storage.Arm(); var input = Bytes(Backup);
        var error = Record.Exception(() => LegacyMigrationVerifier.Verify(Backup, path, storage));
        Assert.True(error is ArgumentException or IOException); Assert.Empty(storage.Calls); AssertBytes(input, Backup);
    }

    /// <summary>Real before/after and partial-write errors inside redo release ownership and preserve sealed input.</summary>
    /// <param name="fault">Injected storage boundary.</param>
    [Theory]
    [InlineData("before")]
    [InlineData("after")]
    [InlineData("partial")]
    public void Verify_RedoStorageFault_PreservesInputAndPermitsFreshRetry(string fault)
    {
        Seed(1); var input = Bytes(Backup); var recording = new FaultingTransactionStorage();
        LegacyMigrationVerifier.Verify(Backup, Destination, recording, stage => { if (stage == LegacyMigrationStage.RedoCopied) recording.Arm(); });
        var moment = fault == "after" ? "after" : "before";
        var index = recording.Calls.FindIndex(call => call.Operation == "WriteFile" && call.Moment == moment && call.Path.Contains(Path.DirectorySeparatorChar + "staging" + Path.DirectorySeparatorChar, StringComparison.Ordinal));
        Assert.True(index >= 0); var storage = new FaultingTransactionStorage();
        Assert.Throws<IOException>(() => LegacyMigrationVerifier.Verify(Backup, Destination, storage,
            stage => { if (stage == LegacyMigrationStage.RedoCopied) storage.Arm(index, fault == "partial"); }));
        Assert.True(storage.Fired); AssertBytes(input, Backup); Assert.False(Directory.Exists(Destination));
        foreach (var path in Directory.GetFiles(_area, "*", SearchOption.AllDirectories)) using (new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) { }
        LegacyMigrationVerifier.Verify(Backup, Destination); AssertBytes(input, Backup);
    }

    /// <summary>Actual Linux barriers run both private oracles; unsupported hosts do not claim native execution.</summary>
    [Fact]
    public void Verify_NativeLinux_UsesActualStrongPolicy()
    {
        if (!OperatingSystem.IsLinux()) return;
        Seed(3); var storage = new FaultingTransactionStorage(DurabilityMode.FileAndDirectoryFlush, true);
        Assert.Equal(DurabilityMode.FileAndDirectoryFlush, storage.EffectiveDurability);
        LegacyMigrationVerifier.Verify(Backup, Destination, storage);
    }

    /// <summary>Linked source files or destination ancestors reject without touching external data.</summary>
    /// <param name="source">Whether to substitute a source payload rather than a destination ancestor.</param>
    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public void Verify_LinuxLinkedPaths_RejectsBeforeWrites(bool source)
    {
        if (!OperatingSystem.IsLinux()) return;
        Seed(1); var outside = Path.Combine(_area, "outside"); Directory.CreateDirectory(outside);
        var marker = Path.Combine(outside, "keep"); File.WriteAllText(marker, "keep"); var destination = Destination;
        if (source)
        {
            var fragment = Path.Combine(Data, "fragments", "1.bin"); File.Delete(fragment); File.CreateSymbolicLink(fragment, marker);
        }
        else
        {
            var link = Path.Combine(_area, "link"); Directory.CreateSymbolicLink(link, outside); destination = Path.Combine(link, "hint");
        }
        var storage = new FaultingTransactionStorage(); storage.Arm();
        Assert.Throws<InvalidDataException>(() => LegacyMigrationVerifier.Verify(Backup, destination, storage));
        Assert.Empty(storage.Calls); Assert.Equal("keep", File.ReadAllText(marker)); Assert.False(Directory.Exists(Path.Combine(outside, "hint")));
    }

    private void Seed(int count)
    {
        Directory.CreateDirectory(_area);
        using var input = new MemoryStream(Encoding.UTF8.GetBytes("<r xmlns='urn:mg2' xml:base='https://example.test/base/'><DocumentID>old</DocumentID><line code='A'>line</line></r>"));
        XmlFragmentImporter.Import(input, Root, documentUri: "https://example.test/mg2.xml");
        using var owner = EmbeddedXmlDatabase.Open(Root);
        for (var index = 0; index < count; index++)
        {
            using var read = owner.BeginRead(); using var tx = owner.BeginWrite();
            var target = index == 1 ? Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Attribute && n.LocalName == "code").Id : Target(read, index == 2 ? "line" : "DocumentID");
            tx.ReplaceNodeValue(target, index == 1 ? "" : index == 2 ? "three" : "one"); tx.Commit();
        }
        owner.CreateBackup(Backup);
    }
    private static ulong Target(ImmutableXmlSnapshot read, string name) => Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id))
        .Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == name).Children.Single();
    private string Current => Path.Combine(Data, ".transactions", "CURRENT");
    private string Generation(ulong sequence) => EpochScalarHistory.Generation(Data, sequence);
    private string Wal(ulong sequence) => Path.Combine(Data, ".transactions", "wal", EpochAuthorityCodec.WalFileName(sequence));
    private void RebindHead(byte[] hash)
    {
        var wal = TransactionCodec.ReadWal(Wal(1))!;
        File.WriteAllBytes(Wal(1), TransactionCodec.EncodeWal(wal with { ManifestHash = hash }));
        File.WriteAllBytes(Current, TransactionCodec.EncodePointer(new(1, 1, hash), "BXHD")); Reseal(hash);
    }
    private void Reseal(byte[]? head = null)
    {
        var inv = BackupCodec.Decode(File.ReadAllBytes(Path.Combine(Backup, "inventory.bin")));
        var files = inv.Files.Where(f => File.Exists(Path.Combine(Data, f.Path))).Select(f =>
        { var bytes = File.ReadAllBytes(Path.Combine(Data, f.Path)); return f with { Length = bytes.Length, Hash = SHA256.HashData(bytes) }; }).ToArray();
        var bytes = BackupCodec.Encode(inv with { Files = files, HeadHash = head ?? inv.HeadHash });
        File.WriteAllBytes(Path.Combine(Backup, "inventory.bin"), bytes); File.WriteAllBytes(Path.Combine(Backup, "COMPLETE"), BackupCodec.Complete(bytes));
    }
    private static Dictionary<string, byte[]> Bytes(string root, bool skipWriter = false) => Directory.GetFiles(root, "*", SearchOption.AllDirectories)
        .Where(p => !skipWriter || Path.GetFileName(p) != "writer.lock").ToDictionary(p => Path.GetRelativePath(root, p), File.ReadAllBytes);
    private static string[] Directories(string root) => Directory.GetDirectories(root, "*", SearchOption.AllDirectories).Select(p => Path.GetRelativePath(root, p)).Order().ToArray();
    private static void AssertBytes(Dictionary<string, byte[]> expected, string root, bool skipWriter = false)
    { var actual = Bytes(root, skipWriter); Assert.Equal(expected.Keys.Order(), actual.Keys.Order()); foreach (var f in expected) Assert.Equal(f.Value, actual[f.Key]); }
    /// <summary>Deletes only isolated test-owned fixture data after handles close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
