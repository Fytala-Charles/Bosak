// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Qualifies read-only first-enrollment preparation against a real frozen legacy store.
// SPECIAL NOTES        : Real legacy stores and sealed captures; preparation performs no enrollment append.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Security.Cryptography;
using System.Text;
using Bosak.XmlDb.Core;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Qualifies read-only first-enrollment preparation against a real frozen legacy store.</summary>
public sealed class ApplicationAuthorityEnrollmentTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-enrollment-" + Guid.NewGuid().ToString("N"));
    private string Source => Path.Combine(_area, "source");
    private string Capture => Path.Combine(_area, "capture");
    private string Host => Path.Combine(_area, "host");
    private string Authority => Path.Combine(_area, "authority");
    private readonly Guid _admin = Guid.NewGuid();
    private ApplicationAuthorityConfiguration Configuration => new(Guid.Parse("10213243-5465-7687-98a9-bacbdcedfe0f"), _admin, "pilot", "orders", "admin", "authority");
    private Dictionary<string, string> Roots => new() { ["admin"] = Host, ["authority"] = Authority, ["source"] = Source, ["capture"] = Capture };
    private static EmbeddedHostInspectionEvidence Inspection(EmbeddedHostLifetime parent) => new(parent.Context, true, true, true, true, true);
    private ApplicationEnrollmentEvidence Evidence(EmbeddedHostLifetime parent) => new(parent.Context, Configuration.AuthorityId, "source", "source-admission", "capture", Guid.NewGuid(), new string('a', 64), true, true, true, true, true, true);
    private EmbeddedHostLifetime Parent()
    {
        Directory.CreateDirectory(Host); File.WriteAllBytes(Path.Combine(Host, "owner.lock"), []);
        File.WriteAllBytes(Path.Combine(Host, "host.meta"), HostJournalCodec.EncodeMetadata(_admin, "pilot", "orders")); File.WriteAllBytes(Path.Combine(Host, "journal.bin"), []);
        return EmbeddedHostLifetime.OpenExisting(Host, "pilot", "orders", [Source, Capture, Authority]);
    }
    private ApplicationAuthorityLifetime Provision(EmbeddedHostLifetime parent) => ApplicationAuthorityLifetime.Provision(parent, parent.JournalStatus.KnownPosition, Inspection(parent), Authority, Configuration, Roots, new(Authority, true, true, true));
    private void Seed(int count = 1)
    {
        Directory.CreateDirectory(_area); using var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>")); XmlFragmentImporter.Import(input, Source);
        using var source = EmbeddedXmlDatabase.Open(Source);
        for (var i = 0; i < count; i++) { using var read = source.BeginRead(); using var tx = source.BeginWrite(); tx.ReplaceNodeValue(Target(read), "new-" + i); tx.Commit(); }
    }
    private static ulong Target(ImmutableXmlSnapshot snapshot) => Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();
    private Dictionary<string, byte[]> Bytes()
    {
        var result = new Dictionary<string, byte[]>();
        foreach (var path in Directory.GetFiles(_area, "*", SearchOption.AllDirectories).Where(p => Path.GetFileName(p) is not ("owner.lock" or "authority.lock" or "writer.lock")))
        {
            using var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            var bytes = new byte[(int)file.Length]; file.ReadExactly(bytes); result.Add(Path.GetRelativePath(_area, path), bytes);
        }
        return result;
    }
    private void AssertBytes(Dictionary<string, byte[]> before)
    {
        var after = Bytes(); Assert.Equal(before.Keys.Order(), after.Keys.Order()); foreach (var pair in before) Assert.Equal(pair.Value, after[pair.Key]);
    }

    /// <summary>Real H0 and positive histories bind a fresh baseline without changing any data or authority bytes.</summary>
    /// <param name="sequence">Actual captured commit sequence.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(3)]
    public void Prepare_RealFrozenBaseline_BindsExactReadOnlyEntry(int sequence)
    {
        Seed(sequence); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); var before = Bytes();
        using var plan = authority.PrepareFirstEnrollment(freeze, capture, evidence); var described = plan.Describe();
        Assert.True(described.WritersMustRemainStopped); Assert.Equal(parent.Context.SessionId, described.Entry.OwnerSession); Assert.NotEqual(Guid.Empty, described.Entry.BaselineId);
        Assert.Equal(1UL, described.Entry.OwnerGeneration); Assert.Equal(1UL, described.Entry.SelectionRevision); Assert.Equal(PilotBranch.Source, described.Entry.Selected);
        var binding = Assert.IsType<ApplicationEnroll>(described.Entry.Data).Source;
        Assert.Equal(PilotRootKind.Legacy, binding.Kind); Assert.Null(binding.Epoch); Assert.Equal((ulong)sequence, binding.InitialSequence);
        Assert.Equal(Convert.ToHexString(SHA256.HashData(capture.InventoryBytes)).ToLowerInvariant(), binding.InitialHistoryDigest);
        Assert.Equal(described, authority.CheckFirstEnrollment(plan, evidence with { }));
        Assert.True(plan.Consumed); Assert.Throws<InvalidOperationException>(() => authority.CheckFirstEnrollment(plan, evidence));
        Assert.Throws<InvalidOperationException>(() => source.BeginWrite()); Assert.Empty(authority.Inspect().Frames); AssertBytes(before);
    }

    /// <summary>Every missing operational assertion or foreign scope consumes initialization without filesystem changes.</summary>
    /// <param name="field">Invalid supplied assumption.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(2)]
    [InlineData(3)]
    [InlineData(4)]
    [InlineData(5)]
    [InlineData(6)]
    [InlineData(7)]
    [InlineData(8)]
    [InlineData(9)]
    [InlineData(10)]
    [InlineData(11)]
    public void Prepare_InvalidOperationalEvidence_FailsClosed(int field)
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent);
        evidence = field switch
        {
            0 => evidence with { Fresh = false },
            1 => evidence with { IngressClosed = false },
            2 => evidence with { PriorExecutorsExcluded = false },
            3 => evidence with { PublishersExcluded = false },
            4 => evidence with { PriorWorkReconciled = false },
            5 => evidence with { QueueFree = false },
            6 => evidence with { Context = parent.Context with { SessionId = Guid.NewGuid() } },
            7 => evidence with { AuthorityId = Guid.NewGuid() },
            8 => evidence with { ReconciliationId = Guid.Empty },
            9 => evidence with { ReconciledWorkDigest = "unknown" },
            10 => evidence with { SourceRootKey = "authority" },
            _ => evidence with { CaptureRootKey = "missing" }
        };
        var before = Bytes(); Assert.IsType(field >= 10 ? typeof(InvalidDataException) : typeof(InvalidOperationException), Record.Exception(() => authority.PrepareFirstEnrollment(freeze, capture, evidence)));
        Assert.True(authority.IsFaulted); Assert.Throws<InvalidOperationException>(() => authority.ReserveInitializer()); AssertBytes(before);
    }

    /// <summary>Borrowed source freezes and owners must still be actual live capabilities on consumption.</summary>
    /// <param name="loss">Lost dependency or changed reconciliation.</param>
    [Theory]
    [InlineData("freeze")]
    [InlineData("owner")]
    [InlineData("parent")]
    [InlineData("authority")]
    [InlineData("evidence")]
    public void Check_DependencyLossOrChangedEvidence_Rejects(string loss)
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent);
        using var plan = authority.PrepareFirstEnrollment(freeze, capture, evidence); var before = Bytes();
        if (loss == "freeze") freeze.Dispose(); if (loss == "owner") source.Dispose(); if (loss == "parent") parent.Dispose(); if (loss == "authority") authority.Dispose();
        var fresh = loss == "evidence" ? evidence with { ReconciliationId = Guid.NewGuid() } : evidence;
        Assert.IsType(loss == "evidence" ? typeof(InvalidOperationException) : typeof(ObjectDisposedException), Record.Exception(() => authority.CheckFirstEnrollment(plan, fresh))); Assert.True(plan.Consumed); Assert.True(authority.IsFaulted); AssertBytes(before);
    }

    /// <summary>Actual recorded bytes, live WAL, capture closure and staging are rechecked without recovery or cleanup.</summary>
    /// <param name="change">Changed dependency.</param>
    /// <param name="afterPrepare">Whether to change it after preparing the entry.</param>
    [Theory]
    [InlineData("wal", false)]
    [InlineData("wal", true)]
    [InlineData("capture", false)]
    [InlineData("capture", true)]
    [InlineData("staging", false)]
    [InlineData("staging", true)]
    [InlineData("temporary", false)]
    [InlineData("temporary", true)]
    public void Baseline_ChangedBytesOrUnpublishedState_RetainsInvalidState(string change, bool afterPrepare)
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent);
        using var plan = afterPrepare ? authority.PrepareFirstEnrollment(freeze, capture, evidence) : null;
        if (change == "wal")
        {
            var path = Path.Combine(Source, ".transactions", "wal", EpochAuthorityCodec.WalFileName(1)); var bytes = File.ReadAllBytes(path); bytes[^1] ^= 1; File.WriteAllBytes(path, bytes);
        }
        if (change == "capture") File.AppendAllText(Path.Combine(Capture, "inventory.bin"), "changed");
        if (change == "staging") File.WriteAllText(Path.Combine(Source, ".transactions", "staging", "unknown"), "retain");
        if (change == "temporary") File.WriteAllText(Path.Combine(Source, ".transactions", "unknown.tmp"), "retain");
        var before = Bytes();
        Assert.Throws<InvalidDataException>(() => { if (plan is null) authority.PrepareFirstEnrollment(freeze, capture, evidence); else authority.CheckFirstEnrollment(plan, evidence); });
        Assert.True(authority.IsFaulted); AssertBytes(before);
    }

    /// <summary>Only the exact registered capture can bind the source baseline.</summary>
    [Fact]
    public void Prepare_ForgedCapture_Rejects()
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var before = Bytes();
        Assert.Throws<InvalidOperationException>(() => authority.PrepareFirstEnrollment(freeze, new(Capture, capture.InventoryBytes), Evidence(parent))); AssertBytes(before);
    }

    /// <summary>Serialization/description equality cannot recreate the actual registered owner-bound preparation.</summary>
    [Fact]
    public void Check_ForgedPreparation_RejectsWithoutConsumingOriginal()
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent);
        using var plan = authority.PrepareFirstEnrollment(freeze, capture, evidence);
        using var forged = new ApplicationAuthorityLifetime.ApplicationEnrollmentPreparation(authority, freeze, capture, evidence, plan.Pin, plan.Describe() with { }, new MemoryStream());
        Assert.Throws<InvalidOperationException>(() => authority.CheckFirstEnrollment(forged, evidence)); Assert.False(plan.Consumed);
        Assert.Equal(plan.Describe(), authority.CheckFirstEnrollment(plan, evidence));
    }

    /// <summary>Real preparation operations keep both authority/admin owners through disposal until actual release.</summary>
    [Fact]
    public void Preparation_DisposedOwners_RetainsActualLeasesUntilPlanDisposal()
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); using var plan = authority.PrepareFirstEnrollment(freeze, capture, Evidence(parent));
        authority.Dispose(); parent.Dispose(); Assert.False(authority.IsReleased); Assert.False(parent.IsReleased);
        Assert.Throws<IOException>(() => new FileStream(Path.Combine(Authority, "authority.lock"), FileMode.Open, FileAccess.ReadWrite, FileShare.None));
        Assert.Throws<IOException>(() => new FileStream(Path.Combine(Host, "owner.lock"), FileMode.Open, FileAccess.ReadWrite, FileShare.None));
        plan.Dispose(); plan.Dispose(); Assert.True(authority.IsReleased); Assert.True(parent.IsReleased);
    }

    /// <summary>Caller-thread confinement rejects cross-thread consumption without burning the original plan.</summary>
    [Fact]
    public void Check_WrongThread_RejectsWithoutConsuming()
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); using var plan = authority.PrepareFirstEnrollment(freeze, capture, evidence);
        Exception? error = null;
        var thread = new Thread(() => error = Record.Exception(() => authority.CheckFirstEnrollment(plan, evidence))) { IsBackground = true };
        thread.Start(); Assert.True(thread.Join(TimeSpan.FromSeconds(30))); Assert.IsType<InvalidOperationException>(error);
        Assert.False(plan.Consumed); Assert.Equal(plan.Describe(), authority.CheckFirstEnrollment(plan, evidence));
    }

    /// <summary>Disposed preparations cannot be consumed, and descriptions cannot rearm initialization.</summary>
    [Fact]
    public void Check_DisposedPreparation_RejectsWithoutWrites()
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent);
        var plan = authority.PrepareFirstEnrollment(freeze, capture, evidence); var description = plan.Describe(); plan.Dispose(); var before = Bytes();
        Assert.True(description.WritersMustRemainStopped); Assert.Throws<InvalidOperationException>(() => authority.CheckFirstEnrollment(plan, evidence));
        Assert.Throws<InvalidOperationException>(() => authority.PrepareFirstEnrollment(freeze, capture, evidence)); AssertBytes(before);
    }

    /// <summary>The original single-use initializer cannot be borrowed after an empty-root reopen.</summary>
    [Fact]
    public void Prepare_ReopenedEmptyAuthority_Rejects()
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using (var authority = Provision(parent)) { }
        using var reopened = ApplicationAuthorityLifetime.OpenExisting(parent, parent.JournalStatus.KnownPosition, Inspection(parent), Authority, Configuration, Roots);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var before = Bytes();
        Assert.Throws<InvalidOperationException>(() => reopened.PrepareFirstEnrollment(freeze, capture, Evidence(parent))); AssertBytes(before);
    }

    /// <summary>Actual source admission is checked in addition to data hashes and caller assertions.</summary>
    [Fact]
    public void Prepare_NonemptyActualWriterRole_RejectsWithoutRepair()
    {
        Seed(); File.WriteAllBytes(Path.Combine(Source, ".transactions", "writer.lock"), [1]);
        using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var before = Bytes();
        Assert.Throws<InvalidDataException>(() => authority.PrepareFirstEnrollment(freeze, capture, Evidence(parent))); Assert.True(authority.IsFaulted); AssertBytes(before);
    }

    /// <summary>Deletes only the current test's fresh workspace after all real owners/scopes have closed.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
