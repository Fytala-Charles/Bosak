// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Tests canonical host journal bytes, bounded decoding and semantic history rejection.
// SPECIAL NOTES        : Internal pure codec; structural replay never proves durability, freshness or dispatch authority.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Buffers.Binary;
using System.Security.Cryptography;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Qualifies pure host-only codecs without filesystem ownership, persistence or dispatch.</summary>
public sealed class HostJournalCodecTests
{
    private static readonly Guid Journal = Guid.Parse("00112233-4455-6677-8899-aabbccddeeff");
    private static readonly string Zero = new('0', 64);

    /// <summary>Independent reference bytes remain pinned and decode without relying on a production round trip.</summary>
    /// <param name="name">Fixture name.</param>
    /// <param name="hash">Independent SHA-256.</param>
    [Theory]
    [InlineData("host-journal-meta-v1.hex", "73a36c8ca7c33d5f4c3e123a169c1411d76cf22b4ce9a2771a05cbdb4fb0772a")]
    [InlineData("host-journal-legacy-v1.hex", "8c8c3506c65d89444e08c23343184647ced9e679cf84b34963fb0f2dab5a8eb5")]
    [InlineData("host-journal-restore-v1.hex", "08ca28677a06a55d6b532e0fdbd70781d2d02d3e2371227869fd772b3f0e784a")]
    [InlineData("host-journal-chain-v1.hex", "fd746f9a67792cfb4d710a3c8578a67199c898744a512e0027d180ddcf9fa281")]
    public void IndependentVectors_MatchPinnedBytesAndMeaning(string name, string hash)
    {
        var bytes = Fixture(name); Assert.Equal(hash, Hex(SHA256.HashData(bytes)));
        if (name.Contains("meta", StringComparison.Ordinal))
        {
            var meta = HostJournalCodec.DecodeMetadata(bytes, "pilot", "scope"); Assert.Equal(Journal, meta.JournalId);
            Assert.Equal(bytes, HostJournalCodec.EncodeMetadata(Journal, "pilot", "scope")); return;
        }
        if (name.Contains("chain", StringComparison.Ordinal))
        {
            var result = Decode(bytes); Assert.Equal(4, result.Frames.Count); Assert.True(result.WritersMustRemainStopped);
            Assert.Equal(new[] { HostJournalEvent.RecordIntent, HostJournalEvent.AuthorizeDispatch, HostJournalEvent.MarkUncertain, HostJournalEvent.ReconcileAbsent }, result.Frames.Select(f => f.Event));
            Assert.Equal(HostLedgerStage.ReconciledAbsent, result.Frames[^1].Snapshot.Stage); return;
        }
        var restore = name.Contains("restore", StringComparison.Ordinal); var frame = HostJournalCodec.DecodeFrame(bytes);
        Assert.Equal(Initial(restore), frame.Snapshot); Assert.Equal(HostJournalEvent.RecordIntent, frame.Event); Assert.Equal(Journal, frame.JournalId);
        Assert.Equal(bytes, HostJournalCodec.EncodeFrame(Journal, 1, Zero, HostJournalEvent.RecordIntent, Initial(restore)));
        Assert.Equal(1, bytes[8]); Assert.Equal(1, bytes[78]); // Explicit version/event mapping, not runtime enum ordinal 0.
    }

    /// <summary>All bytes of each incomplete tail are rejected; no prefix is silently adopted.</summary>
    [Fact]
    public void EveryTruncatedFrameAndChainTail_RejectsWithoutMutatingInput()
    {
        var frame = Fixture("host-journal-legacy-v1.hex");
        for (var length = 0; length < frame.Length; length++) Assert.Throws<InvalidDataException>(() => HostJournalCodec.DecodeFrame(frame.AsSpan(0, length)));
        var chain = Fixture("host-journal-chain-v1.hex"); var copy = chain.ToArray();
        for (var length = 1; length < chain.Length; length++)
        {
            if (length % frame.Length == 0) continue; // Complete prefixes are structurally valid, never anti-rollback authority.
            Assert.Throws<InvalidDataException>(() => Decode(chain[..length]));
        }
        Assert.Equal(copy, chain); Assert.True(Decode(chain[..frame.Length]).WritersMustRemainStopped);
    }

    /// <summary>Non-seekable short reads decode exactly and leave the caller's stream open.</summary>
    /// <param name="chunk">Maximum read size.</param>
    [Theory]
    [InlineData(1)]
    [InlineData(2)]
    [InlineData(7)]
    [InlineData(71)]
    [InlineData(4096)]
    public void ShortReadStreams_ConsumeCompleteChainWithoutSeeking(int chunk)
    {
        using var input = new ChunkStream(Fixture("host-journal-chain-v1.hex"), chunk);
        var result = HostJournalCodec.ReadJournal(input, Metadata(), "pilot", "scope");
        Assert.Equal(4, result.Frames.Count); Assert.True(input.CanRead); Assert.True(result.WritersMustRemainStopped);
    }

    /// <summary>Framing corruptions and declared oversize reject before payload reads or allocation.</summary>
    /// <param name="fault">Invalid envelope field.</param>
    [Theory]
    [InlineData("magic")]
    [InlineData("version")]
    [InlineData("flags")]
    [InlineData("zero-length")]
    [InlineData("huge-length")]
    [InlineData("over-limit")]
    [InlineData("sequence-zero")]
    [InlineData("sequence-over-limit")]
    [InlineData("first-previous")]
    [InlineData("empty-journal")]
    [InlineData("digest")]
    [InlineData("seal")]
    [InlineData("trailing")]
    public void InvalidFrameEnvelope_Rejects(string fault)
    {
        var bytes = Fixture("host-journal-legacy-v1.hex");
        switch (fault)
        {
            case "magic": bytes[0] ^= 1; break;
            case "version": bytes[8] = 2; break;
            case "flags": bytes[10] = 1; break;
            case "zero-length": BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(12), 0); break;
            case "huge-length": BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(12), uint.MaxValue); break;
            case "over-limit": BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(12), HostJournalCodec.MaximumPayloadBytes + 1); break;
            case "sequence-zero": bytes.AsSpan(16, 8).Clear(); break;
            case "sequence-over-limit": BinaryPrimitives.WriteUInt64LittleEndian(bytes.AsSpan(16), HostJournalCodec.MaximumFrames + 1); break;
            case "first-previous": bytes[40] = 1; break;
            case "empty-journal": bytes.AsSpan(24, 16).Clear(); break;
            case "digest": bytes[^40] ^= 1; break;
            case "seal": bytes[^1] ^= 1; break;
            default: bytes = [.. bytes, 0]; break;
        }
        if (fault is not ("digest" or "seal" or "trailing")) Reseal(bytes);
        Assert.Throws<InvalidDataException>(() => HostJournalCodec.DecodeFrame(bytes));
    }

    /// <summary>Malformed TLVs are rejected even when their enclosing frame is well sealed.</summary>
    /// <param name="fault">Field corruption.</param>
    [Theory]
    [InlineData("duplicate")]
    [InlineData("reordered")]
    [InlineData("unknown")]
    [InlineData("missing")]
    [InlineData("empty")]
    [InlineData("huge-field-length")]
    [InlineData("utf8")]
    [InlineData("bom")]
    [InlineData("nul")]
    [InlineData("whitespace")]
    [InlineData("long-string")]
    [InlineData("short-guid")]
    [InlineData("empty-guid")]
    [InlineData("short-u64")]
    [InlineData("event")]
    [InlineData("stage")]
    [InlineData("profile")]
    [InlineData("policy")]
    [InlineData("missing-source")]
    [InlineData("unexpected-source")]
    [InlineData("short-hash")]
    [InlineData("head-limit")]
    [InlineData("revision-zero")]
    [InlineData("generation-zero")]
    public void WellSealedMalformedPayload_Rejects(string fault)
    {
        var restore = fault == "missing-source"; var snapshot = Initial(restore);
        var fields = Split(HostJournalCodec.EncodePayload(HostJournalEvent.RecordIntent, snapshot));
        switch (fault)
        {
            case "duplicate": fields.Add(fields[^1]); break;
            case "reordered": (fields[0], fields[1]) = (fields[1], fields[0]); break;
            case "unknown": fields.Add((12, [1])); break;
            case "missing": fields.RemoveAll(x => x.Tag == 7); break;
            case "empty": Set(fields, 3, []); break;
            case "utf8": Set(fields, 3, [0xc0, 0xaf]); break;
            case "bom": Set(fields, 3, [0xef, 0xbb, 0xbf, 0x61]); break;
            case "nul": Set(fields, 3, [0x61, 0]); break;
            case "whitespace": Set(fields, 3, [0x20]); break;
            case "long-string": Set(fields, 3, new byte[4097]); break;
            case "short-guid": Set(fields, 2, new byte[15]); break;
            case "empty-guid": Set(fields, 2, new byte[16]); break;
            case "short-u64": Set(fields, 6, [1]); break;
            case "event": Set(fields, 1, [0]); break;
            case "stage": Set(fields, 9, [0]); break;
            case "revision-zero": Set(fields, 6, new byte[8]); break;
            case "generation-zero": Set(fields, 8, new byte[8]); break;
            default:
                var descriptor = Split(fields.Single(x => x.Tag == 5).Value);
                switch (fault)
                {
                    case "profile": Set(descriptor, 10, [0]); break;
                    case "policy": Set(descriptor, 11, [2]); break;
                    case "missing-source": descriptor.RemoveAll(x => x.Tag == 9); break;
                    case "unexpected-source": descriptor.Insert(8, (9, new byte[1])); break;
                    case "short-hash": Set(descriptor, 5, new byte[31]); break;
                    case "head-limit": Set(descriptor, 8, U64(10001)); break;
                }
                Set(fields, 5, Raw(descriptor)); break;
        }
        var payload = Raw(fields);
        if (fault == "huge-field-length") BinaryPrimitives.WriteUInt32LittleEndian(payload.AsSpan(2), uint.MaxValue);
        Assert.Throws<InvalidDataException>(() => HostJournalCodec.DecodeFrame(RawFrame(payload)));
    }

    /// <summary>Every supported event and publication role has canonical payload bytes and valid complete-history semantics.</summary>
    /// <param name="restore">Publication role.</param>
    /// <param name="flow">History path.</param>
    [Theory]
    [InlineData(false, "ack")]
    [InlineData(false, "uncertain-ack")]
    [InlineData(false, "observe-ack")]
    [InlineData(false, "absent-retry")]
    [InlineData(false, "transfer-recorded")]
    [InlineData(false, "transfer-ack")]
    [InlineData(false, "transfer-observed")]
    [InlineData(false, "transfer-absent")]
    [InlineData(true, "ack")]
    [InlineData(true, "uncertain-ack")]
    [InlineData(true, "observe-ack")]
    [InlineData(true, "absent-retry")]
    [InlineData(true, "transfer-recorded")]
    [InlineData(true, "transfer-ack")]
    [InlineData(true, "transfer-observed")]
    [InlineData(true, "transfer-absent")]
    public void ValidHistoryFlows_RoundTripWithoutDispatchAuthority(bool restore, string flow)
    {
        var events = Flow(restore, flow); var result = Decode(JournalBytes(events)); Assert.Equal(events.Length, result.Frames.Count);
        Assert.Equal(events.Select(x => x.Snapshot), result.Frames.Select(x => x.Snapshot)); Assert.True(result.WritersMustRemainStopped);
        foreach (var item in events)
        {
            var payload = HostJournalCodec.EncodePayload(item.Event, item.Snapshot); var read = HostJournalCodec.DecodePayload(payload);
            Assert.Equal(item, read); Assert.Equal(payload, HostJournalCodec.EncodePayload(read.Event, read.Snapshot));
        }
    }

    /// <summary>Checksum-valid frames cannot conceal chain, binding or state-transition violations.</summary>
    /// <param name="fault">Semantic violation.</param>
    [Theory]
    [InlineData("duplicate-attempt")]
    [InlineData("unknown-attempt")]
    [InlineData("revision")]
    [InlineData("owner")]
    [InlineData("generation")]
    [InlineData("descriptor")]
    [InlineData("request")]
    [InlineData("deployment")]
    [InlineData("scope")]
    [InlineData("journal")]
    [InlineData("sequence")]
    [InlineData("previous")]
    [InlineData("ack-from-recorded")]
    [InlineData("uncertain-from-recorded")]
    [InlineData("observe-from-recorded")]
    [InlineData("absent-after-ack")]
    [InlineData("erase-observation")]
    [InlineData("change-receipt")]
    [InlineData("same-transfer-owner")]
    [InlineData("same-transfer-generation")]
    [InlineData("wrong-transfer-stage")]
    [InlineData("retry-before-absence")]
    [InlineData("retry-new-destination")]
    public void InvalidCompleteHistory_RejectsWithoutReturningPrefix(string fault)
    {
        var initial = Initial(); var next = initial with { Context = initial.Context with { Revision = 2 }, Stage = HostLedgerStage.DispatchAuthorized };
        var events = new List<(HostJournalEvent Event, HostLedgerSnapshot Snapshot)> { (HostJournalEvent.RecordIntent, initial) };
        var kind = HostJournalEvent.AuthorizeDispatch;
        switch (fault)
        {
            case "duplicate-attempt": next = initial; kind = HostJournalEvent.RecordIntent; break;
            case "unknown-attempt": next = next with { Context = next.Context with { Intent = next.Context.Intent with { AttemptId = Guid.NewGuid() } } }; break;
            case "revision": next = next with { Context = next.Context with { Revision = 3 } }; break;
            case "owner": next = next with { Context = next.Context with { OwnerSession = Guid.NewGuid() } }; break;
            case "generation": next = next with { Context = next.Context with { OwnerGeneration = 2 } }; break;
            case "descriptor": next = next with { Context = next.Context with { Intent = next.Context.Intent with { InventorySha256 = new string('a', 64) } } }; break;
            case "request": next = next with { Context = next.Context with { RequestId = Guid.NewGuid() } }; break;
            case "deployment": next = next with { Context = next.Context with { Deployment = "other" } }; break;
            case "scope": next = next with { Context = next.Context with { ResourceScope = "other" } }; break;
            case "ack-from-recorded": next = next with { Stage = HostLedgerStage.Acknowledged, Receipt = Receipt(initial) }; kind = HostJournalEvent.Acknowledge; break;
            case "uncertain-from-recorded": next = next with { Stage = HostLedgerStage.Uncertain }; kind = HostJournalEvent.MarkUncertain; break;
            case "observe-from-recorded": next = next with { Stage = HostLedgerStage.ObservedKnown, Observed = Observed(initial) }; kind = HostJournalEvent.ObserveKnown; break;
            case "absent-after-ack":
                events = Flow(false, "ack").ToList(); next = events[^1].Snapshot with { Context = initial.Context with { Revision = 4 }, Stage = HostLedgerStage.ReconciledAbsent, Receipt = null }; kind = HostJournalEvent.ReconcileAbsent; break;
            case "erase-observation":
                events = Flow(false, "observe-ack")[..3].ToList(); next = events[^1].Snapshot with { Context = initial.Context with { Revision = 4 }, Stage = HostLedgerStage.Acknowledged, Receipt = Receipt(initial), Observed = null }; kind = HostJournalEvent.Acknowledge; break;
            case "change-receipt":
                events = Flow(false, "ack").ToList(); var receipt = Receipt(initial) with { DestinationEpoch = new(Guid.NewGuid(), Guid.NewGuid(), 7) };
                next = Transfer(events[^1].Snapshot) with { Receipt = receipt }; kind = HostJournalEvent.TransferOwner; break;
            case "same-transfer-owner": next = Transfer(initial) with { Context = initial.Context with { Revision = 2, OwnerGeneration = 2 } }; kind = HostJournalEvent.TransferOwner; break;
            case "same-transfer-generation": next = Transfer(initial) with { Context = initial.Context with { Revision = 2, OwnerSession = Guid.NewGuid() } }; kind = HostJournalEvent.TransferOwner; break;
            case "wrong-transfer-stage": next = Transfer(initial) with { Stage = HostLedgerStage.ReconciledAbsent }; kind = HostJournalEvent.TransferOwner; break;
            case "retry-before-absence": next = initial with { Context = initial.Context with { Intent = initial.Context.Intent with { AttemptId = Guid.NewGuid() } } }; kind = HostJournalEvent.RecordIntent; break;
            case "retry-new-destination":
                events = Flow(false, "absent-retry")[..3].ToList(); next = initial with { Context = initial.Context with { Intent = initial.Context.Intent with { AttemptId = Guid.NewGuid(), BundleRoot = "elsewhere" } } }; kind = HostJournalEvent.RecordIntent; break;
        }
        events.Add((kind, next)); var bytes = JournalBytes(events.ToArray());
        if (fault is "journal" or "sequence" or "previous")
        {
            var offset = HostJournalCodec.EncodeFrame(Journal, 1, Zero, HostJournalEvent.RecordIntent, initial).Length;
            if (fault == "journal") bytes[offset + 24] ^= 1;
            if (fault == "sequence") BinaryPrimitives.WriteUInt64LittleEndian(bytes.AsSpan(offset + 16), 3);
            if (fault == "previous") bytes[offset + 40] ^= 1;
            Reseal(bytes.AsSpan(offset));
        }
        var copy = bytes.ToArray(); Assert.Throws<InvalidDataException>(() => Decode(bytes)); Assert.Equal(copy, bytes);
    }

    /// <summary>Input and aggregate bounds apply before oversized reads and unbounded attempt accumulation.</summary>
    [Fact]
    public void AggregateLimits_RejectBeforeOversizedReadOrTooManyAttempts()
    {
        var header = Fixture("host-journal-legacy-v1.hex")[..72]; BinaryPrimitives.WriteUInt32LittleEndian(header.AsSpan(12), uint.MaxValue);
        using var input = new MemoryStream(header); Assert.Throws<InvalidDataException>(() => HostJournalCodec.ReadJournal(input, Metadata(), "pilot", "scope")); Assert.Equal(72, input.Position);
        Assert.Throws<InvalidDataException>(() => Decode(new byte[HostJournalCodec.MaximumJournalBytes + 1]));
        var initial = Initial(); var records = Enumerable.Range(0, HostJournalCodec.MaximumAttempts + 1).Select(_ => (HostJournalEvent.RecordIntent,
            initial with { Context = initial.Context with { RequestId = Guid.NewGuid(), Intent = initial.Context.Intent with { AttemptId = Guid.NewGuid() } } })).ToArray();
        Assert.Equal(HostJournalCodec.MaximumAttempts, Decode(JournalBytes(records[..^1])).Frames.Count);
        Assert.Throws<InvalidDataException>(() => Decode(JournalBytes(records)));
        Assert.True(Decode([]).WritersMustRemainStopped);
    }

    /// <summary>Strict UTF-8 byte bounds, not character counts, govern encoding.</summary>
    /// <param name="fault">String edge case.</param>
    [Theory]
    [InlineData("ascii-limit")]
    [InlineData("utf8-limit")]
    [InlineData("utf8-over")]
    [InlineData("surrogate")]
    [InlineData("nul")]
    [InlineData("bom")]
    public void StringEncoding_UsesStrictBoundedUtf8(string fault)
    {
        var value = fault switch
        {
            "ascii-limit" => new string('x', 4096),
            "utf8-limit" => new string('é', 2048),
            "utf8-over" => new string('é', 2049),
            "surrogate" => new string((char)0xd800, 1),
            "nul" => "a" + (char)0,
            _ => "a" + (char)0xfeff
        };
        if (fault.EndsWith("limit", StringComparison.Ordinal)) Assert.Equal(Journal, HostJournalCodec.DecodeMetadata(HostJournalCodec.EncodeMetadata(Journal, value, "scope"), value, "scope").JournalId);
        else Assert.Throws<InvalidDataException>(() => HostJournalCodec.EncodeMetadata(Journal, value, "scope"));
    }

    /// <summary>Metadata never selects its own trusted scope and rejects corruption or trailing data.</summary>
    /// <param name="fault">Metadata invalidity.</param>
    [Theory]
    [InlineData("magic")]
    [InlineData("guid")]
    [InlineData("scope")]
    [InlineData("checksum")]
    [InlineData("short")]
    [InlineData("trailing")]
    [InlineData("configured-scope")]
    [InlineData("configured-deployment")]
    public void MetadataBindingAndIntegrity_Rejects(string fault)
    {
        var bytes = Fixture("host-journal-meta-v1.hex");
        switch (fault)
        {
            case "magic": bytes[0] ^= 1; break;
            case "guid": bytes.AsSpan(8, 16).Clear(); SHA256.HashData(bytes.AsSpan(0, 56), bytes.AsSpan(56)); break;
            case "scope": bytes[24] ^= 1; SHA256.HashData(bytes.AsSpan(0, 56), bytes.AsSpan(56)); break;
            case "checksum": bytes[^1] ^= 1; break;
            case "short": bytes = bytes[..87]; break;
            case "trailing": bytes = [.. bytes, 0]; break;
        }
        Assert.Throws<InvalidDataException>(() => HostJournalCodec.DecodeMetadata(bytes, fault == "configured-deployment" ? "other" : "pilot", fault == "configured-scope" ? "other" : "scope"));
    }

    /// <summary>Receipt and observation bindings are validated from bytes, independently of declared event/status.</summary>
    /// <param name="receipt">Acknowledgment rather than observation.</param>
    /// <param name="fault">Nested binding mismatch.</param>
    [Theory]
    [InlineData(false, "role")]
    [InlineData(false, "operation")]
    [InlineData(false, "backup")]
    [InlineData(false, "source")]
    [InlineData(false, "destination")]
    [InlineData(false, "head")]
    [InlineData(false, "path")]
    [InlineData(false, "missing")]
    [InlineData(true, "role")]
    [InlineData(true, "operation")]
    [InlineData(true, "backup")]
    [InlineData(true, "source")]
    [InlineData(true, "destination")]
    [InlineData(true, "head")]
    [InlineData(true, "path")]
    [InlineData(true, "missing")]
    public void WellSealedPublicationMismatch_Rejects(bool receipt, string fault)
    {
        var initial = Initial(true); var snapshot = initial with
        {
            Context = initial.Context with { Revision = 3 },
            Stage = receipt ? HostLedgerStage.Acknowledged : HostLedgerStage.ObservedKnown,
            Receipt = receipt ? Receipt(initial) : null,
            Observed = receipt ? null : Observed(initial)
        };
        var fields = Split(HostJournalCodec.EncodePayload(receipt ? HostJournalEvent.Acknowledge : HostJournalEvent.ObserveKnown, snapshot));
        ushort tag = receipt ? (ushort)10 : (ushort)11;
        if (fault == "missing") fields.RemoveAll(x => x.Tag == tag);
        else
        {
            var pub = Split(fields.Single(x => x.Tag == tag).Value);
            switch (fault)
            {
                case "role": Set(pub, 1, [1]); break;
                case "operation": Set(pub, 2, Guid.NewGuid().ToByteArray(bigEndian: true)); break;
                case "backup": Set(pub, 3, Guid.NewGuid().ToByteArray(bigEndian: true)); break;
                case "source": var source = Split(pub.Single(x => x.Tag == 4).Value); Set(source, 3, U64(8)); Set(pub, 4, Raw(source)); break;
                case "destination": var dest = Split(pub.Single(x => x.Tag == 5).Value); Set(dest, 1, initial.Context.Intent.SourceEpoch!.StoreId.ToByteArray(bigEndian: true)); Set(pub, 5, Raw(dest)); break;
                case "head": Set(pub, 6, U64(4)); break;
                case "path": Set(pub, 7, "wrong-store"u8.ToArray()); break;
            }
            Set(fields, tag, Raw(pub));
        }
        Assert.Throws<InvalidDataException>(() => HostJournalCodec.DecodeFrame(RawFrame(Raw(fields))));
    }

    private static HostLedgerSnapshot Initial(bool restore = false) => new(new(Guid.Parse("22222222-2222-2222-2222-222222222222"), "pilot", "scope",
        new(Guid.Parse("44444444-4444-4444-4444-444444444444"), restore ? EpochPublicationKind.IndependentEpochRestore : EpochPublicationKind.LegacyMigration,
            "artifact", "candidate", new string('1', 64), Guid.Parse("33333333-3333-3333-3333-333333333333"), 7, 3,
            restore ? new(Guid.Parse("55555555-5555-5555-5555-555555555555"), Guid.Parse("66666666-6666-6666-6666-666666666666"), 7) : null,
            EpochProfile.ScalarWal, DurabilityMode.ProcessCrash), 1, Guid.Parse("99887766-5544-3322-1100-aabbccddeeff"), 1), HostLedgerStage.Recorded);
    private static HostLedgerSnapshot Transfer(HostLedgerSnapshot old) => old with
    {
        Context = old.Context with { Revision = old.Context.Revision + 1, OwnerSession = Guid.NewGuid(), OwnerGeneration = old.Context.OwnerGeneration + 1 },
        Stage = old.Stage is HostLedgerStage.Recorded or HostLedgerStage.DispatchAuthorized ? HostLedgerStage.Uncertain : old.Stage
    };
    private static EpochPublishedReceipt Receipt(HostLedgerSnapshot s) => new(s.Context.Intent.Kind, s.Context.Intent.AttemptId, s.Context.Intent.BackupId,
        s.Context.Intent.SourceEpoch, new(Guid.Parse("77777777-7777-7777-7777-777777777777"), Guid.Parse("88888888-8888-8888-8888-888888888888"), 7), 3, Path.Combine(s.Context.Intent.BundleRoot, "store"));
    private static EpochObservedPublication Observed(HostLedgerSnapshot s) { var r = Receipt(s); return new(r.Kind, r.OperationId, r.BackupId, r.SourceEpoch, r.DestinationEpoch, r.CommitSequence, r.StorePath); }
    private static (HostJournalEvent Event, HostLedgerSnapshot Snapshot)[] Flow(bool restore, string flow)
    {
        var s = Initial(restore); var result = new List<(HostJournalEvent, HostLedgerSnapshot)> { (HostJournalEvent.RecordIntent, s) };
        void Add(HostJournalEvent kind, HostLedgerSnapshot next) { s = next with { Context = next.Context with { Revision = s.Context.Revision + 1 } }; result.Add((kind, s)); }
        if (flow == "transfer-recorded") { result.Add((HostJournalEvent.TransferOwner, Transfer(s))); return result.ToArray(); }
        Add(HostJournalEvent.AuthorizeDispatch, s with { Stage = HostLedgerStage.DispatchAuthorized });
        if (flow == "uncertain-ack") Add(HostJournalEvent.MarkUncertain, s with { Stage = HostLedgerStage.Uncertain });
        if (flow.Contains("observe", StringComparison.Ordinal)) Add(HostJournalEvent.ObserveKnown, s with { Stage = HostLedgerStage.ObservedKnown, Observed = Observed(s) });
        if (flow is "absent-retry" or "transfer-absent") Add(HostJournalEvent.ReconcileAbsent, s with { Stage = HostLedgerStage.ReconciledAbsent });
        else if (flow != "transfer-observed") Add(HostJournalEvent.Acknowledge, s with { Stage = HostLedgerStage.Acknowledged, Receipt = Receipt(s) });
        if (flow.StartsWith("transfer-", StringComparison.Ordinal)) result.Add((HostJournalEvent.TransferOwner, Transfer(s)));
        if (flow == "absent-retry") result.Add((HostJournalEvent.RecordIntent, Initial(restore) with { Context = Initial(restore).Context with { Intent = Initial(restore).Context.Intent with { AttemptId = Guid.NewGuid() } } }));
        return result.ToArray();
    }
    private static byte[] Fixture(string name) => Convert.FromHexString(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "TestData", name)).Trim());
    private static HostJournalMetadata Metadata() => HostJournalCodec.DecodeMetadata(Fixture("host-journal-meta-v1.hex"), "pilot", "scope");
    private static HostJournalReadResult Decode(byte[] bytes) => HostJournalCodec.DecodeJournal(bytes, Metadata(), "pilot", "scope");
    private static string Hex(byte[] bytes) => Convert.ToHexString(bytes).ToLowerInvariant();
    private static byte[] U64(ulong value) { var bytes = new byte[8]; BinaryPrimitives.WriteUInt64LittleEndian(bytes, value); return bytes; }
    private static void Reseal(Span<byte> bytes) { if (bytes.Length >= 112) SHA256.HashData(bytes[..^40], bytes.Slice(bytes.Length - 40, 32)); }
    private static byte[] RawFrame(byte[] payload)
    {
        var bytes = new byte[112 + payload.Length]; Fixture("host-journal-legacy-v1.hex").AsSpan(0, 72).CopyTo(bytes);
        BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(12), (uint)payload.Length); payload.CopyTo(bytes, 72); "HJEND001"u8.CopyTo(bytes.AsSpan(bytes.Length - 8)); Reseal(bytes); return bytes;
    }
    private static byte[] JournalBytes(params (HostJournalEvent Event, HostLedgerSnapshot Snapshot)[] events)
    {
        var output = new List<byte>(); var prior = Zero;
        for (var index = 0; index < events.Length; index++)
        {
            var bytes = HostJournalCodec.EncodeFrame(Journal, (ulong)index + 1, prior, events[index].Event, events[index].Snapshot);
            prior = Hex(bytes.AsSpan(bytes.Length - 40, 32).ToArray()); output.AddRange(bytes);
        }
        return output.ToArray();
    }
    private static List<(ushort Tag, byte[] Value)> Split(byte[] bytes)
    {
        var result = new List<(ushort, byte[])>(); var cursor = 0;
        while (cursor < bytes.Length) { var n = (int)BinaryPrimitives.ReadUInt32LittleEndian(bytes.AsSpan(cursor + 2)); result.Add((BinaryPrimitives.ReadUInt16LittleEndian(bytes.AsSpan(cursor)), bytes.AsSpan(cursor + 6, n).ToArray())); cursor += 6 + n; }
        return result;
    }
    private static byte[] Raw(List<(ushort Tag, byte[] Value)> fields)
    {
        using var output = new MemoryStream(); using var writer = new BinaryWriter(output);
        foreach (var (tag, value) in fields) { writer.Write(tag); writer.Write((uint)value.Length); writer.Write(value); }
        return output.ToArray();
    }
    private static void Set(List<(ushort Tag, byte[] Value)> fields, ushort tag, byte[] value) { var index = fields.FindIndex(x => x.Tag == tag); fields[index] = (tag, value); }
    private sealed class ChunkStream(byte[] bytes, int chunk) : MemoryStream(bytes, writable: false)
    {
        /// <inheritdoc/>
        public override bool CanSeek => false;
        /// <inheritdoc/>
        public override int Read(byte[] buffer, int offset, int count) => base.Read(buffer, offset, Math.Min(chunk, count));
        /// <inheritdoc/>
        public override int Read(Span<byte> buffer) => base.Read(buffer[..Math.Min(chunk, buffer.Length)]);
    }
}
