// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies epoch scalar commits, stale selection, retained readers and fail-closed histories.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 27-10-2026     | Expect intact WAL redo after interrupted generation publication
// ===========================================================================================================================================================

using System.Text;
using Bosak.XmlDb.Core;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Verifies scalar epoch transactions and complete-history reopening.</summary>
public sealed class EpochScalarTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-et5-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "epoch");

    /// <summary>Successive commits capture the selected manifest while readers retain old data and admission.</summary>
    [Fact]
    public void Commit_SuccessiveHeads_ReopenAndRetainOldSnapshots()
    {
        var identity = Seed(); var owner = EpochScalarCoordinator.Open(Root);
        var old = owner.BeginRead(0); var target = Target(old);
        var stale = owner.BeginTransaction();
        using (var transaction = owner.BeginTransaction())
        { transaction.ReplaceNodeValue(target, "first & Î»"); Assert.Equal(1UL, transaction.Commit()); }
        using (var transaction = owner.BeginTransaction())
        { Assert.Equal(1UL, transaction.BaseSequence); transaction.ReplaceNodeValue(target, "second"); Assert.Equal(2UL, transaction.Commit()); }
        var count = Directory.GetFiles(Path.Combine(Root, ".transactions", "wal")).Length;
        stale.ReplaceNodeValue(target, "stale"); Assert.Throws<TransactionConflictException>(() => stale.Commit());
        Assert.Equal(count, Directory.GetFiles(Path.Combine(Root, ".transactions", "wal")).Length);
        var latest = owner.BeginRead(0); owner.Dispose();
        Assert.Equal("old", old.ReadValue(target)); Assert.Equal("second", latest.ReadValue(target));
        using (var reopened = EpochScalarCoordinator.Open(Root))
        using (var read = reopened.BeginRead(0)) { Assert.Equal(2UL, read.CommitSequence); Assert.Equal("second", read.ReadValue(target)); }
        Assert.Throws<IOException>(() => EpochAdmission.Acquire(Root, identity, true, EpochProfile.ScalarWal));
        old.Dispose(); latest.Dispose(); stale.Dispose();
        using var exclusive = EpochAdmission.Acquire(Root, identity, true, EpochProfile.ScalarWal);
    }

    /// <summary>Scalar restrictions and rollback do not append history; ordinary attributes may become empty.</summary>
    [Fact]
    public void Transaction_RestrictionsRollbackAndEmptyAttribute_PreserveContract()
    {
        Seed(); using var owner = EpochScalarCoordinator.Open(Root); using var read = owner.BeginRead();
        var target = Target(read); var attribute = Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Attribute).Id;
        using (var transaction = owner.BeginTransaction())
        {
            Assert.Throws<InvalidOperationException>(() => transaction.Commit());
            Assert.Throws<NotSupportedException>(() => transaction.ReplaceNodeValue(target, ""));
            transaction.ReplaceNodeValue(target, "pending");
            Assert.Throws<NotSupportedException>(() => transaction.ReplaceNodeValue(attribute, "other"));
            transaction.Rollback(); Assert.Throws<ObjectDisposedException>(() => transaction.Commit());
        }
        Assert.Empty(Directory.GetFiles(Path.Combine(Root, ".transactions", "wal")));
        using (var transaction = owner.BeginTransaction()) { transaction.ReplaceNodeValue(attribute, ""); transaction.Commit(); }
        using var updated = owner.BeginRead(); Assert.Equal("", updated.ReadValue(attribute)); Assert.Equal("old", updated.ReadValue(target));
    }

    /// <summary>Complete WAL reopens through deterministic redo or existing materialization after publication interruption.</summary>
    /// <param name="stage">Injected interruption boundary.</param>
    [Theory]
    [InlineData((int)EpochScalarStage.BeforeWal)]
    [InlineData((int)EpochScalarStage.WalFlushed)]
    [InlineData((int)EpochScalarStage.GenerationPublished)]
    [InlineData((int)EpochScalarStage.BeforeCurrent)]
    [InlineData((int)EpochScalarStage.CurrentPublished)]
    public void Commit_InterruptedPublication_ReopensOnlyCompleteHistory(int stage)
    {
        Seed();
        using (var owner = EpochScalarCoordinator.Open(Root, checkpoint: actual => { if ((int)actual == stage) throw new IOException("injected"); }))
        {
            using var read = owner.BeginRead(); using var transaction = owner.BeginTransaction(); transaction.ReplaceNodeValue(Target(read), "new");
            Assert.Throws<IOException>(() => transaction.Commit()); Assert.Throws<InvalidOperationException>(() => owner.BeginRead());
        }
        using var reopened = EpochScalarCoordinator.Open(Root); using var snapshot = reopened.BeginRead();
        Assert.Equal(stage == (int)EpochScalarStage.BeforeWal ? "old" : "new", snapshot.ReadValue(Target(snapshot)));
    }

    /// <summary>Corrupt complete authorities and torn journals are retained and refused, never downgraded to base.</summary>
    /// <param name="artifact">History artifact to corrupt.</param>
    [Theory]
    [InlineData("wal")]
    [InlineData("CURRENT")]
    [InlineData("GENERATION")]
    public void Open_CorruptHistory_FailsClosedWithoutDiscardingEvidence(string artifact)
    {
        Seed(); using (var owner = EpochScalarCoordinator.Open(Root))
        { using var read = owner.BeginRead(); using var transaction = owner.BeginTransaction(); transaction.ReplaceNodeValue(Target(read), "new"); transaction.Commit(); }
        var path = artifact == "wal" ? Path.Combine(Root, ".transactions", "wal", EpochAuthorityCodec.WalFileName(1)) :
            artifact == "CURRENT" ? Path.Combine(Root, ".transactions", "CURRENT") : Path.Combine(EpochScalarHistory.Generation(Root, 1), "GENERATION");
        File.WriteAllBytes(path, [0]); Assert.Throws<InvalidDataException>(() => EpochScalarCoordinator.Open(Root)); Assert.Equal(new byte[] { 0 }, File.ReadAllBytes(path));
        Assert.Throws<InvalidDataException>(() => ReadOnlyEpochDatabase.Open(Root));
    }

    /// <summary>Native Linux directory barriers support complete commits and reopening.</summary>
    [Fact]
    public void Commit_NativeLinuxStrongPolicy_ReopensCompleteHead()
    {
        if (!OperatingSystem.IsLinux()) return;
        Seed(); var storage = new LocalTransactionStorage(DurabilityMode.FileAndDirectoryFlush);
        using (var owner = EpochScalarCoordinator.Open(Root, storage))
        { using var read = owner.BeginRead(); using var transaction = owner.BeginTransaction(); transaction.ReplaceNodeValue(Target(read), "strong"); transaction.Commit(); }
        using var reopened = EpochScalarCoordinator.Open(Root, storage); using var snapshot = reopened.BeginRead(); Assert.Equal("strong", snapshot.ReadValue(Target(snapshot)));
    }

    /// <summary>A transaction keeps its reader after owner disposal but cannot commit through a replacement owner.</summary>
    [Fact]
    public void Transaction_DisposedOwner_RejectsCommitAndReleasesIndependentHandles()
    {
        var identity = Seed(); var owner = EpochScalarCoordinator.Open(Root);
        using var read = owner.BeginRead(); var target = Target(read);
        var transaction = owner.BeginTransaction(); owner.Dispose();
        using (var replacement = EpochScalarCoordinator.Open(Root))
        {
            Assert.Equal("old", transaction.ReadValue(target)); transaction.ReplaceNodeValue(target, "pending");
            Assert.Throws<ObjectDisposedException>(() => transaction.Commit());
            Assert.Empty(Directory.GetFiles(Path.Combine(Root, ".transactions", "wal")));
        }
        read.Dispose(); transaction.Dispose();
        using var exclusive = EpochAdmission.Acquire(Root, identity, true, EpochProfile.ScalarWal);
    }

    private EpochIdentity Seed()
    {
        Directory.CreateDirectory(_area); var source = Path.Combine(_area, "source");
        using var input = new MemoryStream(Encoding.UTF8.GetBytes("<r code='value'><DocumentID>old</DocumentID><line>line</line></r>"));
        XmlFragmentImporter.Import(input, source); return EpochEmptyRoot.CreateFixture(source, Root, 1, new LocalTransactionStorage());
    }
    private static ulong Target(ImmutableXmlSnapshot snapshot) => Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id))
        .Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();
    /// <summary>Removes isolated test data after handles are closed.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
