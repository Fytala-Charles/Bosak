// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies migration provenance vectors, bounded parsing and pure header-context checks.
// SPECIAL NOTES        : Metadata-only tests; no runtime conversion, I/O capability or cutover authority.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Buffers.Binary;
using System.Security.Cryptography;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Verifies migration metadata independently of runtime conversion and admission.</summary>
public sealed class EpochMigrationCodecTests
{
    /// <summary>Independent fixed vectors match exact fields, bytes and all 700 truncated prefixes.</summary>
    /// <param name="zero">Whether the source has no commits.</param>
    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public void Origin_IndependentVectors_RoundTripsAndRejectsEveryTruncation(bool zero)
    {
        var bytes = Fixture(zero, "origin"); var value = EpochMigrationCodec.Decode(bytes);
        Assert.Equal(350, bytes.Length); Assert.Equal(zero ? 0UL : 2UL, value.CommitSequence);
        Assert.Equal(Guid.Parse("50617283-94a5-b6c7-d8e9-fa0b1c2d3e4f"), value.MigrationId);
        Assert.Equal(Guid.Parse("20314253-6475-8697-a8b9-cadbecfd0e1f"), value.BackupId);
        Assert.Equal(new EpochIdentity(Guid.Parse("30415263-7485-96a7-b8c9-daebfc0d1e2f"), Guid.Parse("40516273-8495-a6b7-c8d9-eafb0c1d2e3f"), 1), value.Destination);
        Assert.Equal(bytes, EpochMigrationCodec.Encode(value));
        Assert.Equal(zero ? "47a50b65cff93d12d5d5f635a2485d0cbfb5b102101ca14da8dd3ee6610ac7cb" : "eaaa3055bff82010f579fa567d8628626173a0e4151e187946610623492793dc",
            Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant());
        Assert.Equal(SHA256.HashData(Fixture(zero, "inventory")), value.InventoryHash);
        for (var length = 0; length < bytes.Length; length++) Assert.Throws<InvalidDataException>(() => EpochMigrationCodec.Decode(bytes[..length]));
        Assert.Throws<InvalidDataException>(() => EpochMigrationCodec.Decode(bytes.Concat(new byte[] { 0 }).ToArray()));
        var corrupt = bytes.ToArray(); corrupt[^1] ^= 1; Assert.Throws<InvalidDataException>(() => EpochMigrationCodec.Decode(corrupt));
        Assert.Equal(EpochMigrationCodec.Encode(value), EpochMigrationCodec.Encode(Context(zero)));
    }

    /// <summary>Resealed unsupported versions, roles and required fields fail independently of the checksum.</summary>
    /// <param name="offset">Absolute field offset.</param>
    /// <param name="length">Width to clear.</param>
    [Theory]
    [InlineData(12, 2)]
    [InlineData(14, 16)]
    [InlineData(30, 16)]
    [InlineData(110, 16)]
    [InlineData(126, 16)]
    [InlineData(142, 8)]
    [InlineData(150, 8)]
    [InlineData(254, 32)]
    [InlineData(286, 32)]
    public void Decode_ResealedInvalidFields_Rejects(int offset, int length)
    {
        var bytes = Fixture(false, "origin"); bytes.AsSpan(offset, length).Clear(); Seal(bytes);
        Assert.Throws<InvalidDataException>(() => EpochMigrationCodec.Decode(bytes));
    }

    /// <summary>Other roles/framing and extended bodies never decode as migration provenance.</summary>
    /// <param name="offset">Header or role offset.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(4)]
    [InlineData(6)]
    [InlineData(8)]
    [InlineData(12)]
    public void Decode_ResealedUnsupportedFraming_Rejects(int offset)
    {
        var bytes = Fixture(false, "origin"); bytes[offset] = 99; Seal(bytes);
        Assert.Throws<InvalidDataException>(() => EpochMigrationCodec.Decode(bytes));
    }

    /// <summary>Codec shapes reject invalid sizes and identities before writing; limits are inclusive.</summary>
    [Fact]
    public void Encode_ShapeAndSequenceBounds_RejectsInvalidAndAcceptsMaximum()
    {
        var value = EpochMigrationCodec.Decode(Fixture(false, "origin"));
        Assert.Throws<InvalidDataException>(() => EpochMigrationCodec.Encode(null!));
        Assert.Throws<InvalidDataException>(() => EpochMigrationCodec.Encode(value with { Destination = null! }));
        Assert.Throws<InvalidDataException>(() => EpochMigrationCodec.Encode(value with { MigrationId = Guid.Empty }));
        Assert.Throws<InvalidDataException>(() => EpochMigrationCodec.Encode(value with { InventoryHash = null! }));
        foreach (var length in new[] { 0, 31, 33 }) Assert.Throws<InvalidDataException>(() => EpochMigrationCodec.Encode(value with { BaseHash = new byte[length] }));
        Assert.Throws<InvalidDataException>(() => EpochMigrationCodec.Encode(value with { CommitSequence = 10001 }));
        Assert.Equal(10000UL, EpochMigrationCodec.Decode(EpochMigrationCodec.Encode(value with { CommitSequence = 10000 })).CommitSequence);
        var zero = EpochMigrationCodec.Decode(Fixture(true, "origin"));
        Assert.Throws<InvalidDataException>(() => EpochMigrationCodec.Encode(zero with { HeadManifestHash = value.HeadManifestHash }));
        Assert.Throws<InvalidDataException>(() => EpochMigrationCodec.Encode(zero with { SourceHeadWalHash = value.SourceHeadWalHash }));
        Assert.Throws<InvalidDataException>(() => EpochMigrationCodec.Encode(zero with { DestinationHeadWalHash = value.DestinationHeadWalHash }));
        Assert.Throws<InvalidDataException>(() => EpochBackupCodec.DecodeOrigin(Fixture(false, "origin")));
        Assert.Throws<InvalidDataException>(() => EpochMigrationCodec.Decode(Hex("epoch-restore-origin-v1.hex")));
    }

    /// <summary>Every well-framed substituted commitment is checked against source or destination headers.</summary>
    /// <param name="field">Absolute offset of an identity or digest field.</param>
    [Theory]
    [InlineData(30)]
    [InlineData(46)]
    [InlineData(78)]
    [InlineData(110)]
    [InlineData(126)]
    [InlineData(142)]
    [InlineData(150)]
    [InlineData(158)]
    [InlineData(190)]
    [InlineData(222)]
    [InlineData(254)]
    [InlineData(286)]
    public void Context_ResealedSubstitutedCommitment_Rejects(int field)
    {
        var bytes = Fixture(false, "origin"); bytes[field] ^= 1; Seal(bytes);
        Assert.Throws<InvalidDataException>(() => Context(false, origin: bytes));
    }

    /// <summary>Header consistency does not require complete document files and grants no history capability.</summary>
    [Fact]
    public void Context_MetadataOnlyAndZeroCurrentRules_AreExplicit()
    {
        Context(true); Context(false);
        Assert.Throws<InvalidDataException>(() => Context(true, sourceCurrent: Hex("migration-source-current-v1.hex")));
        Assert.Throws<InvalidDataException>(() => EpochMigrationCodec.ValidateHeaders(Fixture(false, "origin"), Fixture(false, "inventory"), Fixture(false, "completion"),
            Hex("migration-source-format-v1.hex"), Hex("migration-source-control-v1.hex"), null, Hex("migration-destination-format-v1.hex"), Fixture(false, "destination-current")));
        var format = Hex("migration-source-format-v1.hex"); format[12] = 1; Seal(format);
        Assert.Throws<InvalidDataException>(() => Context(false, sourceFormat: format));
        Assert.Throws<InvalidDataException>(() => Context(false, sourceFormat: Hex("migration-destination-format-v1.hex")));
        var current = Fixture(false, "destination-current"); current[^33] ^= 1; Seal(current);
        Assert.Throws<InvalidDataException>(() => Context(false, destinationCurrent: current));
        var complete = Fixture(false, "completion"); complete[12] ^= 1; Seal(complete);
        Assert.Throws<InvalidDataException>(() => Context(false, completion: complete));
    }

    /// <summary>Malicious source counts/lengths and noncanonical paths reject before allocation or capability checks.</summary>
    /// <param name="variant">Malformed field or entry list.</param>
    [Theory]
    [InlineData("count-negative")]
    [InlineData("count-limit")]
    [InlineData("count-remaining")]
    [InlineData("path-negative")]
    [InlineData("path-limit")]
    [InlineData("path-remaining")]
    [InlineData("traversal")]
    [InlineData("device")]
    [InlineData("duplicate")]
    [InlineData("order")]
    [InlineData("file-length")]
    [InlineData("missing-control")]
    [InlineData("missing-current")]
    [InlineData("missing-wal")]
    public void Context_MalformedLegacyInventory_Rejects(string variant)
    {
        var inventory = Fixture(false, "inventory");
        if (variant.StartsWith("count-", StringComparison.Ordinal))
            BinaryPrimitives.WriteInt32LittleEndian(inventory.AsSpan(108), variant == "count-negative" ? -1 : variant == "count-limit" ? 100001 : 100000);
        else if (variant.StartsWith("path-", StringComparison.Ordinal))
            BinaryPrimitives.WriteInt32LittleEndian(inventory.AsSpan(112), variant == "path-negative" ? -1 : variant == "path-limit" ? 513 : 512);
        else
        {
            var source = BackupCodec.Decode(inventory); var files = source.Files.ToArray();
            files = variant switch
            {
                "traversal" => [files[0] with { Path = "../FORMAT" }, .. files.Skip(1)],
                "device" => [files[0] with { Path = "CON.txt" }, .. files.Skip(1)],
                "duplicate" => [files[0], files[0], .. files.Skip(1)],
                "order" => files.Reverse().ToArray(),
                "file-length" => [files[0] with { Length = 43 }, .. files.Skip(1)],
                "missing-control" => files.Where(f => f.Path != ".transactions/CONTROL").ToArray(),
                "missing-current" => files.Where(f => f.Path != ".transactions/CURRENT").ToArray(),
                _ => files.Where(f => !f.Path.EndsWith("02.wal", StringComparison.Ordinal)).ToArray()
            };
            inventory = BackupCodec.Encode(source with { Files = files });
        }
        Seal(inventory);
        var value = EpochMigrationCodec.Decode(Fixture(false, "origin")) with { InventoryHash = SHA256.HashData(inventory) };
        Assert.Throws<InvalidDataException>(() => Context(false, origin: EpochMigrationCodec.Encode(value), inventory: inventory, completion: BackupCodec.Complete(inventory)));
    }

    /// <summary>Every supplied header and legacy inventory prefix rejects boundedly.</summary>
    /// <param name="role">Context input to truncate.</param>
    [Theory]
    [InlineData("inventory")]
    [InlineData("completion")]
    [InlineData("source-format")]
    [InlineData("source-control")]
    [InlineData("source-current")]
    [InlineData("destination-format")]
    [InlineData("destination-current")]
    public void Context_EveryTruncatedHeader_Rejects(string role)
    {
        var bytes = role is "inventory" or "completion" or "destination-current" ? Fixture(false, role) : Hex("migration-" + role + "-v1.hex");
        for (var length = 0; length < bytes.Length; length++)
        {
            var truncated = bytes[..length];
            Assert.Throws<InvalidDataException>(() => Context(false,
                inventory: role == "inventory" ? truncated : null, completion: role == "completion" ? truncated : null,
                sourceFormat: role == "source-format" ? truncated : null, sourceControl: role == "source-control" ? truncated : null,
                sourceCurrent: role == "source-current" ? truncated : null, destinationFormat: role == "destination-format" ? truncated : null,
                destinationCurrent: role == "destination-current" ? truncated : null));
        }
    }

    /// <summary>Coherent resealing cannot substitute control/current document, head, or destination profile.</summary>
    /// <param name="role">Altered source pointer or destination profile.</param>
    [Theory]
    [InlineData("control")]
    [InlineData("current")]
    [InlineData("profile")]
    public void Context_CoherentlyResealedWrongHeaders_Rejects(string role)
    {
        var origin = EpochMigrationCodec.Decode(Fixture(false, "origin"));
        if (role == "profile")
        {
            var format = EpochCodec.EncodeFormat(origin.Destination);
            origin = origin with { DestinationFormatHash = SHA256.HashData(format) };
            Assert.Throws<InvalidDataException>(() => Context(false, origin: EpochMigrationCodec.Encode(origin), destinationFormat: format));
            return;
        }
        var bad = TransactionCodec.EncodePointer(new(2, role == "control" ? 0UL : 2UL, role == "control" ? origin.BaseHash : origin.HeadManifestHash), role == "control" ? "BXTC" : "BXHD");
        var inventory = BackupCodec.Decode(Fixture(false, "inventory"));
        var path = role == "control" ? ".transactions/CONTROL" : ".transactions/CURRENT";
        var bytes = BackupCodec.Encode(inventory with { Files = inventory.Files.Select(f => f.Path == path ? f with { Hash = SHA256.HashData(bad), Length = bad.Length } : f).ToArray() });
        origin = origin with { InventoryHash = SHA256.HashData(bytes) };
        Assert.Throws<InvalidDataException>(() => Context(false, origin: EpochMigrationCodec.Encode(origin), inventory: bytes, completion: BackupCodec.Complete(bytes),
            sourceControl: role == "control" ? bad : null, sourceCurrent: role == "current" ? bad : null));
    }

    private static EpochMigrationOrigin Context(bool zero, byte[]? origin = null, byte[]? inventory = null, byte[]? completion = null,
        byte[]? sourceFormat = null, byte[]? sourceCurrent = null, byte[]? destinationCurrent = null, byte[]? sourceControl = null, byte[]? destinationFormat = null) =>
        EpochMigrationCodec.ValidateHeaders(origin ?? Fixture(zero, "origin"), inventory ?? Fixture(zero, "inventory"), completion ?? Fixture(zero, "completion"),
            sourceFormat ?? Hex("migration-source-format-v1.hex"), sourceControl ?? Hex("migration-source-control-v1.hex"), sourceCurrent ?? (zero ? null : Hex("migration-source-current-v1.hex")),
            destinationFormat ?? Hex("migration-destination-format-v1.hex"), destinationCurrent ?? Fixture(zero, "destination-current"));
    private static void Seal(byte[] bytes) => SHA256.HashData(bytes.AsSpan(0, bytes.Length - 32), bytes.AsSpan(bytes.Length - 32));
    private static byte[] Fixture(bool zero, string role) => Hex("migration-" + (zero ? "zero" : "positive") + "-" + role + "-v1.hex");
    private static byte[] Hex(string name) => Convert.FromHexString(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "TestData", name)).Trim());
}
