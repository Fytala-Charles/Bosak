// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Verifies stopped registration, restricted saves and actual ownership drain.
// SPECIAL NOTES        : Internal ProcessCrash append only; uncertain sessions remain faulted and all writers stopped.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Qualifies the stopped lifetime and restricted append boundary without dispatch.</summary>
public sealed class EmbeddedHostStoppedReconciliationTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ep6a-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "host");
    private string Data => Path.Combine(_area, "data");
    private EmbeddedHostLifetime Provision()
    {
        Directory.CreateDirectory(Data);
        return EmbeddedHostLifetime.Provision(Root, "pilot", "scope", [Data], new(Root, "pilot", "scope", true, true, true));
    }
    private EmbeddedHostLifetime Open() => EmbeddedHostLifetime.OpenExisting(Root, "pilot", "scope", [Data]);
    private static EmbeddedHostAdmissionEvidence Evidence(EmbeddedHostLifetime owner) => new(owner.Context, true, true, true, true, true, true);
    private static void Enable(EmbeddedHostLifetime owner)
    {
        owner.OpenAdministrativeAdmissions(Evidence(owner)); Assert.True(owner.EnableJournalAppend(owner.JournalStatus.KnownPosition, Evidence(owner)));
    }
    private HostLedgerSnapshot Initial(EmbeddedHostLifetime owner) => new(new(Guid.NewGuid(), "pilot", "scope",
        new(Guid.NewGuid(), EpochPublicationKind.LegacyMigration, Path.Combine(Data, "artifact"), Path.Combine(Data, "candidate"), new string('a', 64), Guid.NewGuid(), 7, 0, null,
            EpochProfile.ScalarWal, DurabilityMode.ProcessCrash), 1, owner.Context.SessionId, 1), HostLedgerStage.Recorded);
    private static HostLedgerSnapshot Authorized(HostLedgerSnapshot initial) => initial with { Context = initial.Context with { Revision = 2 }, Stage = HostLedgerStage.DispatchAuthorized };


    private static EmbeddedHostInspectionEvidence Inspection(EmbeddedHostLifetime host) => new(host.Context, true, true, true, true, true);
    private HostLedgerSnapshot Seed()
    {
        using var owner = Provision(); Enable(owner); var initial = Initial(owner);
        owner.AppendJournal(owner.JournalStatus.KnownPosition, HostJournalEvent.RecordIntent, initial); return initial;
    }
    private static HostLedgerSnapshot Transfer(EmbeddedHostLifetime host, HostLedgerSnapshot initial) => initial with
    { Context = initial.Context with { Revision = 2, OwnerSession = host.Context.SessionId, OwnerGeneration = 2 }, Stage = HostLedgerStage.Uncertain };

    /// <summary>Fresh stopped ownership can transfer and save absence without enabling admissions.</summary>
    [Fact]
    public void TransferAndAbsence_RemainStopped()
    {
        var initial = Seed(); using var host = Open(); using var session = host.BeginStoppedReconciliation(host.JournalStatus.KnownPosition, Inspection(host));
        var transferred = Transfer(host, initial);
        var result = host.AppendStopped(session, host.JournalStatus.KnownPosition, HostJournalEvent.TransferOwner, transferred);
        Assert.Equal(HostJournalAppendDisposition.Acknowledged, result.Disposition);
        var absent = transferred with { Context = transferred.Context with { Revision = 3 }, Stage = HostLedgerStage.ReconciledAbsent };
        host.AppendStopped(session, result.Position, HostJournalEvent.ReconcileAbsent, absent);
        Assert.Equal(3, host.ReadJournalForReconciliation().Frames.Count); Assert.False(host.AdmissionsOpen); Assert.False(host.JournalStatus.CanAttemptAppend);
        Assert.Throws<InvalidOperationException>(() => host.OpenAdministrativeAdmissions(Evidence(host)));
        Assert.Throws<InvalidOperationException>(() => host.BeginExclusiveExecutor(initial.Context.Intent.AttemptId));
        Assert.Throws<InvalidOperationException>(() => host.BeginStoppedReconciliation(host.JournalStatus.KnownPosition, Inspection(host)));
    }
    /// <summary>Stopped capabilities cannot append execution or receipt transitions.</summary>
    /// <param name="kind">Forbidden event.</param>
    [Theory]
    [InlineData("RecordIntent")]
    [InlineData("AuthorizeDispatch")]
    [InlineData("MarkUncertain")]
    [InlineData("Acknowledge")]
    public void ForbiddenEvents_WriteNothing(string kind)
    {
        var initial = Seed(); using var host = Open(); using var session = host.BeginStoppedReconciliation(host.JournalStatus.KnownPosition, Inspection(host));
        Assert.Throws<InvalidOperationException>(() => host.AppendStopped(session, host.JournalStatus.KnownPosition, Enum.Parse<HostJournalEvent>(kind), Transfer(host, initial)));
        Assert.Single(host.ReadJournalForReconciliation().Frames); Assert.False(host.JournalStatus.Faulted);
    }
    /// <summary>Evidence, head and admission must all bind the stopped session.</summary>
    /// <param name="invalid">Invalid acquisition fact.</param>
    [Theory]
    [InlineData("context")]
    [InlineData("fresh")]
    [InlineData("writers")]
    [InlineData("publishers")]
    [InlineData("prior")]
    [InlineData("queue")]
    [InlineData("position")]
    [InlineData("open")]
    [InlineData("operation")]
    public void AcquisitionRejectsInvalidFacts(string invalid)
    {
        Seed(); using var host = Open(); var e = Inspection(host); var position = host.JournalStatus.KnownPosition;
        e = invalid switch
        {
            "context" => e with { Context = e.Context with { SessionId = Guid.NewGuid() } },
            "fresh" => e with { Fresh = false },
            "writers" => e with { AllWritersControlled = false },
            "publishers" => e with { AllPublishersControlled = false },
            "prior" => e with { PriorExecutorsExcluded = false },
            "queue" => e with { QueueFree = false },
            _ => e
        };
        if (invalid == "position") position = position with { Length = position.Length + 1 };
        if (invalid == "open") host.OpenAdministrativeAdmissions(Evidence(host));
        using var operation = invalid == "operation" ? host.BeginReconciliationOperation() : null;
        Assert.Throws<InvalidOperationException>(() => host.BeginStoppedReconciliation(position, e)); Assert.Single(host.ReadJournalForReconciliation().Frames);
    }
    /// <summary>Empty reopened journals have no stopped first-write authority.</summary>
    [Fact]
    public void EmptyReopenRejects()
    {
        using (var created = Provision()) { }
        using var host = Open(); Assert.Throws<InvalidOperationException>(() => host.BeginStoppedReconciliation(host.JournalStatus.KnownPosition, Inspection(host)));
    }
    /// <summary>A disposed capability cannot be reused and stale heads produce conflicts without writes.</summary>
    [Fact]
    public void StaleAndDisposedRegistrationReject()
    {
        var initial = Seed(); using var host = Open(); var session = host.BeginStoppedReconciliation(host.JournalStatus.KnownPosition, Inspection(host));
        var stale = host.JournalStatus.KnownPosition with { Length = 1 };
        Assert.Equal(HostJournalAppendDisposition.Conflict, host.AppendStopped(session, stale, HostJournalEvent.TransferOwner, Transfer(host, initial)).Disposition);
        session.Dispose(); session.Dispose();
        Assert.Throws<InvalidOperationException>(() => host.AppendStopped(session, host.JournalStatus.KnownPosition, HostJournalEvent.TransferOwner, Transfer(host, initial)));
        Assert.Single(host.ReadJournalForReconciliation().Frames);
    }
    /// <summary>Post-flush uncertainty faults the lifetime and never rearms a stopped session.</summary>
    [Fact]
    public void LostAcknowledgmentFaults()
    {
        var initial = Seed(); using var host = Open(); using var session = host.BeginStoppedReconciliation(host.JournalStatus.KnownPosition, Inspection(host));
        Assert.Throws<IOException>(() => host.AppendStopped(session, host.JournalStatus.KnownPosition, HostJournalEvent.TransferOwner, Transfer(host, initial), stage => { if (stage == HostAppendStage.Flushed) throw new IOException(); }));
        Assert.True(host.JournalStatus.Faulted); Assert.Equal(2, host.ReadJournalForReconciliation().Frames.Count);
        Assert.Throws<InvalidOperationException>(() => host.AppendStopped(session, host.JournalStatus.KnownPosition, HostJournalEvent.TransferOwner, Transfer(host, initial)));
    }
    /// <summary>Shutdown retains ownership through the real append and session drain.</summary>
    [Fact]
    public async Task ShutdownWaitsForActualWork()
    {
        var initial = Seed(); using var host = Open(); var session = host.BeginStoppedReconciliation(host.JournalStatus.KnownPosition, Inspection(host));
        using var reached = new ManualResetEventSlim(); using var release = new ManualResetEventSlim();
        var work = Task.Run(() => host.AppendStopped(session, host.JournalStatus.KnownPosition, HostJournalEvent.TransferOwner, Transfer(host, initial), stage =>
        { if (stage != HostAppendStage.Written) return; reached.Set(); if (!release.Wait(TimeSpan.FromSeconds(30))) throw new TimeoutException(); }));
        try { Assert.True(reached.Wait(TimeSpan.FromSeconds(30))); host.Dispose(); Assert.False(host.WhenReleased.IsCompleted); Assert.Throws<IOException>(() => { using var other = Open(); }); }
        finally { release.Set(); await work; session.Dispose(); }
        await host.WhenReleased.WaitAsync(TimeSpan.FromSeconds(5)); using var reopened = Open(); Assert.Equal(2, reopened.History.Frames.Count); Assert.False(reopened.AdmissionsOpen);
    }
    /// <summary>A foreign token cannot append and callbacks cannot dispose the live session.</summary>
    [Fact]
    public void ForeignAndReentrantTokensReject()
    {
        var initial = Seed(); using var host = Open(); using var session = host.BeginStoppedReconciliation(host.JournalStatus.KnownPosition, Inspection(host));
        using var foreign = host.BeginReconciliationOperation();
        Assert.Throws<InvalidOperationException>(() => host.AppendStopped(foreign, host.JournalStatus.KnownPosition, HostJournalEvent.TransferOwner, Transfer(host, initial)));
        host.AppendStopped(session, host.JournalStatus.KnownPosition, HostJournalEvent.TransferOwner, Transfer(host, initial), stage =>
        {
            if (stage != HostAppendStage.Validated) return;
            Assert.Throws<InvalidOperationException>(() => session.Dispose());
            Assert.Throws<InvalidOperationException>(() => host.OpenAdministrativeAdmissions(Evidence(host)));
        });
        Assert.Equal(2, host.ReadJournalForReconciliation().Frames.Count); Assert.False(host.AdmissionsOpen);
    }
    /// <summary>Concurrent saves for one exact position have one acknowledged writer.</summary>
    [Fact]
    public async Task ConcurrentSameHeadHasOneWriter()
    {
        var initial = Seed(); using var host = Open(); using var session = host.BeginStoppedReconciliation(host.JournalStatus.KnownPosition, Inspection(host));
        var expected = host.JournalStatus.KnownPosition; var snapshot = Transfer(host, initial); using var start = new ManualResetEventSlim();
        var workers = Enumerable.Range(0, 8).Select(_ => Task.Run(() => { start.Wait(); return host.AppendStopped(session, expected, HostJournalEvent.TransferOwner, snapshot); })).ToArray();
        start.Set(); var results = await Task.WhenAll(workers);
        Assert.Single(results, result => result.Disposition == HostJournalAppendDisposition.Acknowledged);
        Assert.Equal(7, results.Count(result => result.Disposition == HostJournalAppendDisposition.Conflict)); Assert.Equal(2, host.ReadJournalForReconciliation().Frames.Count);
    }
    /// <summary>Every shared append checkpoint preserves the existing uncertainty boundary.</summary>
    /// <param name="checkpoint">Failure checkpoint.</param>
    [Theory]
    [InlineData("Validated")]
    [InlineData("BeforeWrite")]
    [InlineData("Written")]
    [InlineData("Flushed")]
    [InlineData("BeforeAcknowledge")]
    public void CheckpointFailuresRespectEntryBoundary(string checkpoint)
    {
        var initial = Seed(); using var host = Open(); using var session = host.BeginStoppedReconciliation(host.JournalStatus.KnownPosition, Inspection(host));
        Assert.Throws<IOException>(() => host.AppendStopped(session, host.JournalStatus.KnownPosition, HostJournalEvent.TransferOwner, Transfer(host, initial), stage =>
        { if (stage.ToString() == checkpoint) throw new IOException(); }));
        Assert.Equal(checkpoint != "Validated", host.JournalStatus.Faulted); Assert.False(host.AdmissionsOpen);
        Assert.Equal(checkpoint is "Validated" or "BeforeWrite" ? 1 : 2, host.ReadJournalForReconciliation().Frames.Count);
    }
    /// <summary>Deletes only the test-owned tree after handles drain.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
