// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Verifies self-contained checkpoints and recovery parity with full history.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.3   | 26-10-2026     | Verify redundant descriptors, retention and publication faults
// ===========================================================================================================================================================

using System.Security.Cryptography;
using System.Text;
using Bosak.XmlDb.Core;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Verifies self-contained checkpoints and recovery parity with full history.</summary>
public sealed class CheckpointTests : IDisposable
{
    private readonly string _root = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-checkpoint-" + Guid.NewGuid().ToString("N"));

    /// <summary>Verifies an anchor skips old materializations while retaining and validating all WAL records.</summary>
    [Fact]
    public void Recovery_VerifiedCheckpoint_MatchesFullJournalAndSkipsPrefixGenerations()
    {
        Seed();
        using (var database = EmbeddedXmlDatabase.Open(_root)) { Commit(database, "v1"); Commit(database, "v2"); Assert.Equal(2UL, database.CreateCheckpoint()); Commit(database, "v3"); }
        using (var full = EmbeddedXmlDatabase.Open(_root))
        {
            Assert.Equal(0UL, full.LastRecovery.CheckpointSequence);
            Assert.Equal(3, full.LastRecovery.GenerationsValidated);
            using var read = full.BeginRead();
            Assert.Equal("v3", read.ReadValue(Target(read)));
        }
        using (var fast = EmbeddedXmlDatabase.Open(_root, RecoveryMode.PreferCheckpoint))
        {
            Assert.Equal(2UL, fast.LastRecovery.CheckpointSequence);
            Assert.Equal(3, fast.LastRecovery.WalRecordsValidated);
            Assert.Equal(2, fast.LastRecovery.GenerationsValidated);
            Assert.False(fast.LastRecovery.CheckpointRejected);
            using var read = fast.BeginRead();
            Assert.Equal("v3", read.ReadValue(Target(read)));
            Commit(fast, "v4");
            Assert.Equal(4UL, fast.CreateCheckpoint());
            Assert.Equal(4UL, fast.CreateCheckpoint()); // Existing immutable anchor is reused, not overwritten.
        }
        using var latest = EmbeddedXmlDatabase.Open(_root, RecoveryMode.PreferCheckpoint);
        Assert.Equal(4UL, latest.LastRecovery.CheckpointSequence);
        Assert.Equal(1, latest.LastRecovery.GenerationsValidated);
        Assert.Equal(4, Directory.GetFiles(Path.Combine(_root, ".transactions", "wal")).Length);
        Assert.Equal(4, Directory.GetDirectories(Path.Combine(_root, ".transactions", "generations")).Length);
    }

    /// <summary>An independently copied checkpoint survives loss of original materializations and replays its suffix.</summary>
    [Fact]
    public void Recovery_MissingOriginalAndSuffixGenerations_ReplaysFromCheckpointCopy()
    {
        Seed();
        using (var database = EmbeddedXmlDatabase.Open(_root)) { Commit(database, "v1"); Commit(database, "v2"); database.CreateCheckpoint(); Commit(database, "v3"); }
        foreach (var sequence in new[] { "00000000000000000002", "00000000000000000003" })
            Directory.Move(Path.Combine(_root, ".transactions", "generations", sequence), Path.Combine(_root, ".transactions", "staging", "lost-" + sequence));
        using (var fast = EmbeddedXmlDatabase.Open(_root, RecoveryMode.PreferCheckpoint))
        {
            Assert.Equal(2UL, fast.LastRecovery.CheckpointSequence);
            Assert.Equal(1, fast.LastRecovery.GenerationsReplayed);
            using var read = fast.BeginRead();
            Assert.Equal("v3", read.ReadValue(Target(read)));
        }
        using var full = EmbeddedXmlDatabase.Open(_root);
        Assert.Equal(1, full.LastRecovery.GenerationsReplayed);
        using var current = full.BeginRead();
        Assert.Equal("v3", current.ReadValue(Target(current)));
    }

    /// <summary>Optional corrupt checkpoint artifacts fall back to independently validated full history.</summary>
    /// <param name="relativePath">Checkpoint artifact to corrupt.</param>
    [Theory]
    [InlineData(".transactions/CHECKPOINT")]
    [InlineData(".transactions/checkpoints/00000000000000000002/anchor.bin")]
    [InlineData(".transactions/checkpoints/00000000000000000002/FORMAT")]
    [InlineData(".transactions/checkpoints/00000000000000000002/documents/1/directory.bin")]
    [InlineData(".transactions/checkpoints/00000000000000000002/fragments/1.bin")]
    public void Recovery_CorruptOptionalCheckpoint_FallsBackWithoutLosingCommit(string relativePath)
    {
        Seed();
        using (var database = EmbeddedXmlDatabase.Open(_root)) { Commit(database, "v1"); Commit(database, "v2"); database.CreateCheckpoint(); Commit(database, "v3"); }
        var path = Path.Combine(_root, relativePath);
        var bytes = File.ReadAllBytes(path);
        bytes[^1] ^= 1;
        File.WriteAllBytes(path, bytes);
        using var recovered = EmbeddedXmlDatabase.Open(_root, RecoveryMode.PreferCheckpoint);
        Assert.True(recovered.LastRecovery.CheckpointRejected);
        Assert.Equal(0UL, recovered.LastRecovery.CheckpointSequence);
        using var read = recovered.BeginRead();
        Assert.Equal(3UL, read.CommitSequence);
        Assert.Equal("v3", read.ReadValue(Target(read)));
    }

    /// <summary>Rejects a validly framed checkpoint with a false WAL-prefix identity.</summary>
    [Fact]
    public void Recovery_ForgedPrefixDigest_FallsBackToFullValidation()
    {
        Seed();
        using (var database = EmbeddedXmlDatabase.Open(_root)) { Commit(database, "v1"); database.CreateCheckpoint(); }
        var anchorPath = Path.Combine(_root, ".transactions", "checkpoints", "00000000000000000001", "anchor.bin");
        var anchor = CheckpointCodec.Decode(File.ReadAllBytes(anchorPath));
        var bytes = CheckpointCodec.Encode(anchor with { PrefixHash = new byte[32] });
        File.WriteAllBytes(anchorPath, bytes);
        File.WriteAllBytes(Path.Combine(_root, ".transactions", "CHECKPOINT"), TransactionCodec.EncodePointer(new(1, 1, SHA256.HashData(bytes)), "BXCS"));
        using var recovered = EmbeddedXmlDatabase.Open(_root, RecoveryMode.PreferCheckpoint);
        Assert.True(recovered.LastRecovery.CheckpointRejected);
        Assert.Equal(0UL, recovered.LastRecovery.CheckpointSequence);
        using var read = recovered.BeginRead();
        Assert.Equal("v1", read.ReadValue(Target(read)));
    }

    /// <summary>A checkpoint never authorizes missing or corrupt retained WAL history.</summary>
    /// <param name="remove">Whether to remove the record instead of corrupting it.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Recovery_BrokenRequiredWal_FailsEvenWithValidCheckpoint(bool remove)
    {
        Seed();
        using (var database = EmbeddedXmlDatabase.Open(_root)) { Commit(database, "v1"); Commit(database, "v2"); database.CreateCheckpoint(); }
        var path = Path.Combine(_root, ".transactions", "wal", "00000000000000000001.wal");
        if (remove) File.Delete(path);
        else { var bytes = File.ReadAllBytes(path); bytes[^1] ^= 1; File.WriteAllBytes(path, bytes); }
        Assert.Throws<InvalidDataException>(() => EmbeddedXmlDatabase.Open(_root, RecoveryMode.PreferCheckpoint));
    }

    /// <summary>Unselected directories are not guessed as authoritative; idempotent publication can select them.</summary>
    [Fact]
    public void Recovery_MissingSelector_IgnoresUnselectedAnchorUntilPublished()
    {
        Seed();
        using (var database = EmbeddedXmlDatabase.Open(_root)) { Commit(database, "v1"); database.CreateCheckpoint(); }
        File.Move(Path.Combine(_root, ".transactions", "CHECKPOINT"), Path.Combine(_root, ".transactions", "staging", "saved-selector"));
        using (var database = EmbeddedXmlDatabase.Open(_root, RecoveryMode.PreferCheckpoint))
        {
            Assert.Equal(0UL, database.LastRecovery.CheckpointSequence);
            Assert.False(database.LastRecovery.CheckpointRejected);
            Assert.Equal(1UL, database.CreateCheckpoint());
        }
        using var fast = EmbeddedXmlDatabase.Open(_root, RecoveryMode.PreferCheckpoint);
        Assert.Equal(1UL, fast.LastRecovery.CheckpointSequence);
    }

    /// <summary>Zero-commit and invalid-mode operations fail before changing data or poisoning the owner.</summary>
    [Fact]
    public void Checkpoint_NoCommit_RejectsWhileOwnerRemainsUsable()
    {
        Seed();
        Assert.Throws<ArgumentOutOfRangeException>(() => EmbeddedXmlDatabase.Open(_root, (RecoveryMode)99));
        Assert.False(Directory.Exists(Path.Combine(_root, ".transactions")));
        using var database = EmbeddedXmlDatabase.Open(_root);
        Assert.Throws<InvalidOperationException>(() => database.CreateCheckpoint());
        Commit(database, "v1");
        Assert.Equal(1UL, database.CreateCheckpoint());
    }

    /// <summary>Matches independently encoded checkpoint, selector and reader-lease bytes.</summary>
    [Fact]
    public void CheckpointCodec_FixedFixture_MatchesGoldenBytesAndRejectsTruncation()
    {
        var manifest = Enumerable.Repeat((byte)0x11, 32).ToArray();
        var wal = Enumerable.Repeat((byte)0x22, 32).ToArray();
        var prefix = Enumerable.Repeat((byte)0x33, 32).ToArray();
        var bytes = CheckpointCodec.Encode(new(1, 2, manifest, wal, prefix));
        AssertFixture("checkpoint-v1.hex", bytes);
        AssertFixture("checkpoint-selector-v1.hex", TransactionCodec.EncodePointer(new(1, 2, SHA256.HashData(bytes)), "BXCS"));
        AssertFixture("reader-lease-v1.hex", GenerationLease.Encode(1, 2));
        Assert.Equal(2UL, CheckpointCodec.Decode(bytes).Sequence);
        for (var length = 0; length < bytes.Length; length++)
            Assert.Throws<InvalidDataException>(() => CheckpointCodec.Decode(bytes[..length]));

        static void AssertFixture(string name, byte[] bytes) => Assert.Equal(
            File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "TestData", name)).Trim(), Convert.ToHexString(bytes));
    }

    /// <summary>Exercises checkpoint publication/replay under native Linux directory barriers or the explicit Windows ordering model.</summary>
    [Fact]
    public void Checkpoint_DirectoryBarrierPolicy_ReplaysCommittedSuffix()
    {
        Seed();
        using (var database = OperatingSystem.IsLinux()
            ? EmbeddedXmlDatabase.Open(_root, DurabilityMode.FileAndDirectoryFlush)
            : EmbeddedXmlDatabase.OpenCore(_root, 1, null, new FaultingTransactionStorage(DurabilityMode.FileAndDirectoryFlush)))
        {
            Commit(database, "v1");
            database.CreateRecoveryAnchor();
            Commit(database, "v2");
        }
        File.Delete(Path.Combine(_root, ".transactions", "CHECKPOINT"));
        using var recovered = OperatingSystem.IsLinux()
            ? EmbeddedXmlDatabase.Open(_root, RecoveryMode.PreferCheckpoint, DurabilityMode.FileAndDirectoryFlush)
            : EmbeddedXmlDatabase.OpenCore(_root, 1, null, new FaultingTransactionStorage(DurabilityMode.FileAndDirectoryFlush), RecoveryMode.PreferCheckpoint);
        Assert.Equal(1UL, recovered.LastRecovery.CheckpointSequence);
        using var read = recovered.BeginRead();
        Assert.Equal("v2", read.ReadValue(Target(read)));
    }

    /// <summary>A rechecksummed but semantically altered prefix cannot be hidden by a checkpoint.</summary>
    [Fact]
    public void Recovery_RechecksummedWalMutation_DoesNotBypassFullSemanticValidation()
    {
        Seed();
        using (var database = EmbeddedXmlDatabase.Open(_root)) { Commit(database, "v1"); database.CreateCheckpoint(); }
        var path = Path.Combine(_root, ".transactions", "wal", "00000000000000000001.wal");
        var record = TransactionCodec.ReadWal(path)!;
        File.WriteAllBytes(path, TransactionCodec.EncodeWal(record with { Value = "forged" }));
        Assert.Throws<InvalidDataException>(() => EmbeddedXmlDatabase.Open(_root, RecoveryMode.PreferCheckpoint));
    }
    /// <summary>Independent descriptors recover an older copy when the latest checkpoint and selector are damaged.</summary>
    [Fact]
    public void Recovery_RedundantDescriptors_UsesIndependentOlderMaterialization()
    {
        Seed();
        using (var database = EmbeddedXmlDatabase.Open(_root))
        {
            Commit(database, "v1"); database.CreateRecoveryAnchor();
            Assert.Equal(1UL, database.CreateRecoveryAnchor());
            Commit(database, "v2"); database.CreateRecoveryAnchor();
        }
        File.WriteAllBytes(Path.Combine(_root, ".transactions", "CHECKPOINT"), [0]);
        File.WriteAllBytes(Path.Combine(_root, ".transactions", "checkpoints", "00000000000000000002", "anchor.bin"), [0]);
        using var recovered = EmbeddedXmlDatabase.Open(_root, RecoveryMode.PreferCheckpoint);
        Assert.Equal(1UL, recovered.LastRecovery.CheckpointSequence);
        Assert.True(recovered.LastRecovery.CheckpointRejected);
        using var read = recovered.BeginRead();
        Assert.Equal("v2", read.ReadValue(Target(read)));
    }

    /// <summary>Descriptors cannot conceal missing authoritative WAL records.</summary>
    [Fact]
    public void Recovery_IndependentDescriptor_StillRequiresWal()
    {
        Seed();
        using (var database = EmbeddedXmlDatabase.Open(_root)) { Commit(database, "v1"); database.CreateRecoveryAnchor(); }
        File.Delete(Path.Combine(_root, ".transactions", "CHECKPOINT"));
        File.Delete(Path.Combine(_root, ".transactions", "wal", "00000000000000000001.wal"));
        Assert.Throws<InvalidDataException>(() => EmbeddedXmlDatabase.Open(_root, RecoveryMode.PreferCheckpoint));
    }

    /// <summary>Invalid descriptors fall back to full independently validated history.</summary>
    [Fact]
    public void Recovery_CorruptDescriptor_FallsBackToFullHistory()
    {
        Seed();
        using (var database = EmbeddedXmlDatabase.Open(_root)) { Commit(database, "v1"); database.CreateRecoveryAnchor(); }
        File.Delete(Path.Combine(_root, ".transactions", "CHECKPOINT"));
        File.WriteAllBytes(Path.Combine(_root, ".transactions", "anchors", "00000000000000000001.anchor"), [0]);
        using var recovered = EmbeddedXmlDatabase.Open(_root, RecoveryMode.PreferCheckpoint);
        Assert.Equal(0UL, recovered.LastRecovery.CheckpointSequence);
        Assert.True(recovered.LastRecovery.CheckpointRejected);
        Assert.Equal(1UL, recovered.CommitSequence);
    }

    /// <summary>Reporting retains every dependency and does not mutate any bytes, even with old snapshots alive.</summary>
    [Fact]
    public void Retention_LiveOldReaderAndRedundantAnchors_RetainsEverythingWithoutMutation()
    {
        Seed();
        using var database = EmbeddedXmlDatabase.Open(_root);
        using var old = database.BeginRead();
        Commit(database, "v1"); database.CreateRecoveryAnchor();
        var before = Directory.GetFiles(_root, "*", SearchOption.AllDirectories)
            .Where(path => Path.GetFileName(path) != "writer.lock")
            .ToDictionary(path => Path.GetRelativePath(_root, path).Replace('\\', '/'), File.ReadAllBytes);
        var report = database.PlanRetention();
        Assert.False(report.CanReclaim);
        Assert.Equal(1UL, report.CommitSequence);
        Assert.Equal(before.Count + 1, report.Files.Count);
        foreach (var file in report.Files)
        {
            Assert.NotEmpty(file.Reason);
            if (file.RelativePath == ".transactions/writer.lock") continue;
            Assert.Equal(before[file.RelativePath], File.ReadAllBytes(Path.Combine(_root, file.RelativePath)));
        }
        Assert.Contains(report.Files, file => file.RelativePath.StartsWith(".transactions/anchors/", StringComparison.Ordinal));
        Assert.Contains(report.Files, file => file.Reason.Contains("older readers", StringComparison.Ordinal));
        Assert.Contains(report.Files, file => file.Reason.Contains("lease identity", StringComparison.Ordinal));
        Assert.Contains(report.Files, file => file.Reason.Contains("selected live root", StringComparison.Ordinal));
        Assert.Equal("old", old.ReadValue(Target(old)));
        database.Dispose();
        Assert.Throws<ObjectDisposedException>(() => database.PlanRetention());
    }

    private void Seed()
    {
        using var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID><line>unchanged</line></r>"));
        XmlFragmentImporter.Import(input, _root);
    }

    private static ulong Target(ImmutableXmlSnapshot snapshot) => Enumerable.Range(1, snapshot.NodeCount)
        .Select(id => snapshot.GetNode((ulong)id)).Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();

    private static void Commit(EmbeddedXmlDatabase database, string value)
    {
        using var read = database.BeginRead();
        using var write = database.BeginWrite();
        write.ReplaceNodeValue(Target(read), value);
        write.Commit();
    }

    /// <inheritdoc />
    public void Dispose() { if (Directory.Exists(_root)) Directory.Delete(_root, true); }
}

