// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies mandatory epoch metadata, stable admission lifetimes and bootstrap failures.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Security.Cryptography;
using System.Text;
using Xunit;
using Xunit.Abstractions;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Verifies mandatory epoch metadata, stable admission lifetimes and bootstrap failures.</summary>
public sealed class EpochAdmissionTests(ITestOutputHelper output) : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-epoch-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "epoch");
    private static EpochIdentity Golden => new(new Guid("00112233-4455-6677-8899-aabbccddeeff"), new Guid("10213243-5465-7687-98a9-bacbdcedfe0f"), 1);

    /// <summary>Major-2 descriptor and bound identities match independently encoded bytes and reject every truncation.</summary>
    [Fact]
    public void Codec_GoldenFormatsAndBindings_RejectTruncationAndZeroIdentity()
    {
        var bytes = EpochCodec.EncodeFormat(Golden);
        Assert.Equal(Hex("epoch-format-v2.hex"), bytes);
        Assert.Equal(Golden, EpochCodec.DecodeFormat(bytes));
        Assert.Equal(Hex("epoch-identity-v1.hex"), EpochCodec.EncodeBinding("BXEP", Golden, bytes));
        Assert.Equal(Hex("epoch-admission-v1.hex"), EpochCodec.EncodeBinding("BXEA", Golden, bytes));
        for (var length = 0; length < bytes.Length; length++) Assert.Throws<InvalidDataException>(() => EpochCodec.DecodeFormat(bytes[..length]));
        var bound = EpochCodec.EncodeBinding("BXEA", Golden, bytes);
        for (var length = 0; length < bound.Length; length++) Assert.Throws<InvalidDataException>(() => EpochCodec.ValidateBinding(bound[..length], "BXEA", Golden, bytes));
        Assert.Throws<InvalidDataException>(() => EpochCodec.EncodeFormat(Golden with { StoreId = Guid.Empty }));
        Assert.Throws<InvalidDataException>(() => EpochCodec.EncodeFormat(Golden with { EpochId = Guid.Empty }));
        Assert.Throws<InvalidDataException>(() => EpochCodec.EncodeFormat(Golden with { DocumentId = 0 }));
    }

    /// <summary>Rechecksummed unsupported major, minor, flags and required contracts fail closed.</summary>
    /// <param name="offset">Field byte to alter.</param>
    [Theory]
    [InlineData(4)]
    [InlineData(6)]
    [InlineData(12)]
    [InlineData(53)]
    [InlineData(55)]
    [InlineData(57)]
    [InlineData(59)]
    public void Codec_UnknownRequiredContract_RejectsEvenWithValidChecksum(int offset)
    {
        var bytes = EpochCodec.EncodeFormat(Golden);
        bytes[offset]++;
        SHA256.HashData(bytes.AsSpan(0, bytes.Length - 32), bytes.AsSpan(bytes.Length - 32));
        Assert.Throws<InvalidDataException>(() => EpochCodec.DecodeFormat(bytes));
    }

    /// <summary>Each shared child independently pins admission after owner disposal; maintenance cannot fork readers.</summary>
    [Fact]
    public void Admission_ChildrenOutliveOwner_BlockMaintenanceUntilLastDispose()
    {
        var identity = Create();
        var before = Bytes(Root);
        var owner = EpochAdmission.Acquire(Root, identity);
        var snapshot = owner.ForkShared();
        var transaction = owner.ForkShared();
        owner.Dispose();
        Assert.Throws<ObjectDisposedException>(() => owner.ForkShared());
        Assert.Throws<IOException>(() => EpochAdmission.Acquire(Root, identity, exclusive: true));
        snapshot.Dispose();
        Assert.Throws<IOException>(() => EpochAdmission.Acquire(Root, identity, exclusive: true));
        transaction.Dispose(); transaction.Dispose();
        using (var maintenance = EpochAdmission.Acquire(Root, identity, exclusive: true))
        {
            Assert.True(maintenance.IsExclusive);
            Assert.Throws<IOException>(() => EpochAdmission.Acquire(Root, identity));
            Assert.Throws<InvalidOperationException>(() => maintenance.ForkShared());
        }
        using var next = EpochAdmission.Acquire(Root, identity);
        Assert.Equal(identity, next.Identity);
        AssertBytes(before, Root);
    }

    /// <summary>All current public format-1 open overloads reject epoch metadata before transaction mutation.</summary>
    [Fact]
    public void PublicReaders_MandatoryMajor2_RejectBeforeAdoption()
    {
        Create();
        var before = Bytes(Root);
        Assert.Throws<InvalidDataException>(() => ImmutableXmlSnapshot.Open(Root));
        Assert.Throws<InvalidDataException>(() => EmbeddedXmlDatabase.Open(Root));
        Assert.Throws<InvalidDataException>(() => EmbeddedXmlDatabase.Open(Root, DurabilityMode.ProcessCrash));
        Assert.Throws<InvalidDataException>(() => EmbeddedXmlDatabase.Open(Root, RecoveryMode.PreferCheckpoint));
        using var xml = new MemoryStream(Encoding.UTF8.GetBytes("<r/>"));
        Assert.Throws<IOException>(() => XmlFragmentImporter.Import(xml, Root));
        Assert.False(Directory.Exists(Path.Combine(Root, ".transactions")));
        AssertBytes(before, Root);
    }

    /// <summary>New metadata is never installed into a legacy root; legacy admission is refused without writes.</summary>
    [Fact]
    public void LegacyRoot_BootstrapAndAdmission_RefuseWithoutChangingOriginal()
    {
        Directory.CreateDirectory(_area);
        using (var xml = new MemoryStream(Encoding.UTF8.GetBytes("<r>legacy</r>"))) XmlFragmentImporter.Import(xml, Root);
        var before = Bytes(Root);
        Assert.Throws<IOException>(() => EpochAdmission.CreateFixtureRoot(Root, 1, new LocalTransactionStorage()));
        Assert.Throws<InvalidDataException>(() => EpochAdmission.Acquire(Root, Golden));
        AssertBytes(before, Root);
    }

    /// <summary>Wrong store/epoch/document identities cannot acquire admission.</summary>
    [Fact]
    public void Admission_ExpectedIdentityMismatch_RefusesWithoutReplacingLease()
    {
        var identity = Create(); var before = Bytes(Root);
        foreach (var wrong in new[] { identity with { StoreId = Guid.NewGuid() }, identity with { EpochId = Guid.NewGuid() }, identity with { DocumentId = 2 } })
            Assert.Throws<InvalidDataException>(() => EpochAdmission.Acquire(Root, wrong));
        AssertBytes(before, Root);
    }

    /// <summary>Corrupt descriptors or a missing/corrupt stable admission identity are not recreated.</summary>
    /// <param name="artifact">Artifact to damage.</param>
    [Theory]
    [InlineData("FORMAT")]
    [InlineData("EPOCH")]
    [InlineData(".epoch/admission.lease")]
    public void Admission_CorruptIdentity_FailsClosedWithoutWriting(string artifact)
    {
        var identity = Create();
        var path = Path.Combine(Root, artifact);
        File.WriteAllBytes(path, [0]);
        Assert.Throws<InvalidDataException>(() => EpochAdmission.Acquire(Root, identity));
        Assert.Equal(new byte[] { 0 }, File.ReadAllBytes(path));
        File.Delete(path);
        Assert.ThrowsAny<Exception>(() => EpochAdmission.Acquire(Root, identity));
        Assert.False(File.Exists(path));
    }

    /// <summary>Fixture publication requests real Linux barriers or a modeled policy on Windows without changing legacy stores.</summary>
    [Fact]
    public void Bootstrap_DirectoryPolicy_PublishesBoundStableAdmission()
    {
        Directory.CreateDirectory(_area);
        var storage = OperatingSystem.IsLinux() ? (ITransactionStorage)new LocalTransactionStorage(DurabilityMode.FileAndDirectoryFlush)
            : new FaultingTransactionStorage(DurabilityMode.FileAndDirectoryFlush);
        var identity = EpochAdmission.CreateFixtureRoot(Root, 1, storage);
        Assert.Equal(identity, EpochAdmission.ReadIdentity(Root));
        using var shared = EpochAdmission.Acquire(Root, identity);
        Assert.Throws<IOException>(() => EpochAdmission.Acquire(Root, identity, exclusive: true));
    }

    /// <summary>Every bootstrap persistence boundary and real short write leaves either no root or a completely verifiable fixture.</summary>
    /// <param name="fault">Fault timing or partial write.</param>
    [Theory]
    [InlineData("before")]
    [InlineData("after")]
    [InlineData("partial")]
    public void Bootstrap_InjectedFailure_NeverPublishesPartialIdentity(string fault)
    {
        Directory.CreateDirectory(_area);
        var recording = new FaultingTransactionStorage(); recording.Arm();
        EpochAdmission.CreateFixtureRoot(Path.Combine(_area, "reference"), 1, recording);
        var calls = recording.Calls.Select((call, index) => (call, index)).Where(item => fault == "partial"
            ? item.call.Operation == "WriteFile" && item.call.Moment == "before" : item.call.Moment == fault).ToArray();
        Assert.NotEmpty(calls);
        foreach (var (_, index) in calls)
        {
            var target = Path.Combine(_area, "attempt-" + index);
            var storage = new FaultingTransactionStorage(); storage.Arm(index, fault == "partial");
            Assert.Throws<IOException>(() => EpochAdmission.CreateFixtureRoot(target, 1, storage));
            Assert.True(storage.Fired);
            if (Directory.Exists(target))
            {
                var identity = EpochAdmission.ReadIdentity(target);
                using var admission = EpochAdmission.Acquire(target, identity, exclusive: true);
            }
        }
        output.WriteLine($"epoch-bootstrap/{fault}: {calls.Length} fault positions verified.");
    }

    private EpochIdentity Create() { Directory.CreateDirectory(_area); return EpochAdmission.CreateFixtureRoot(Root, 1, new LocalTransactionStorage()); }
    private static byte[] Hex(string name) => Convert.FromHexString(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "TestData", name)).Trim());
    private static Dictionary<string, byte[]> Bytes(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories).ToDictionary(path => Path.GetRelativePath(root, path), File.ReadAllBytes);
    private static void AssertBytes(Dictionary<string, byte[]> before, string root)
    {
        var after = Bytes(root); Assert.Equal(before.Keys.Order(), after.Keys.Order());
        foreach (var pair in before) Assert.Equal(pair.Value, after[pair.Key]);
    }
    /// <inheritdoc />
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
