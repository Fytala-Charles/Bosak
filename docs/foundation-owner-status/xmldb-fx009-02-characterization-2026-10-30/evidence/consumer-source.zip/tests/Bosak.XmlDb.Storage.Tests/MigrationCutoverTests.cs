// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies bounded cutover freeze, freshness, evidence and conservative routing outcomes.
// SPECIAL NOTES        : Internal prototype acceptance only; no persistent fence, routing service or retirement.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Text;
using Bosak.XmlDb.Core;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Verifies internal prototype decisions without routing applications or replacing stores.</summary>
public sealed class MigrationCutoverTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-mg5-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "legacy");
    private string Backup => Path.Combine(_area, "backup");
    private string Destination => Path.Combine(_area, "candidate");
    private static CutoverWork Drained => new(true, true);

    /// <summary>Explicit observed switch and no-work return preserve exact disk bytes, readers and original paths.</summary>
    /// <param name="count">Captured sequence.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(3)]
    public void Session_ObservedSwitchAndVerifiedReturn_IsReadOnly(int count)
    {
        Seed(count); using var source = EmbeddedXmlDatabase.Open(Root); using var old = source.BeginRead(0);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Backup);
        var result = EpochLegacyMigration.Convert(Backup, Destination); using var candidate = EpochScalarCoordinator.Open(result.StorePath);
        using var read = candidate.BeginRead(0); using var session = MigrationCutoverSession.Attach(freeze, capture, candidate, result, true);
        var sourceBytes = Bytes(Root, true); var candidateBytes = Bytes(Destination, true); var input = Bytes(Backup);
        var sourceDirs = Directories(Root); var candidateDirs = Directories(Destination);
        Assert.Equal(CutoverDecision.CandidateProposed, session.Evaluate(session.Prepare(), CutoverAction.ProposeCandidate, CutoverRoute.Legacy, Drained));
        Assert.Equal(CutoverDecision.CandidateObserved, session.Evaluate(session.Prepare(), CutoverAction.ObserveCandidateOutcome, CutoverRoute.Candidate, Drained));
        Assert.Equal(CutoverDecision.LegacyReturnProposed, session.Evaluate(session.Prepare(), CutoverAction.ProposeLegacyReturn, CutoverRoute.Candidate, Drained));
        Assert.Equal(CutoverDecision.LegacyObserved, session.Evaluate(session.Prepare(), CutoverAction.ObserveLegacyOutcome, CutoverRoute.Legacy, Drained));
        Assert.Equal(old.ReadValue(Target(old)), read.ReadValue(Target(read)));
        AssertBytes(sourceBytes, Root, true); AssertBytes(candidateBytes, Destination, true); AssertBytes(input, Backup);
        Assert.Equal(sourceDirs, Directories(Root)); Assert.Equal(candidateDirs, Directories(Destination));
    }

    /// <summary>Frozen owners reject both new writes and transactions selected before freezing, plus source publication changes.</summary>
    [Fact]
    public void Freeze_PendingAndNewMutations_RejectBeforeWritesAndReleaseCleanly()
    {
        Seed(1); using var source = EmbeddedXmlDatabase.Open(Root); using var sourceTx = source.BeginWrite();
        using (var read = source.BeginRead()) sourceTx.ReplaceNodeValue(Target(read), "blocked");
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Backup);
        var result = EpochLegacyMigration.Convert(Backup, Destination); using var candidate = EpochScalarCoordinator.Open(result.StorePath);
        using var tx = candidate.BeginTransaction(); using (var read = candidate.BeginRead()) tx.ReplaceNodeValue(Target(read), "blocked");
        using var session = MigrationCutoverSession.Attach(freeze, capture, candidate, result, true);
        var input = Bytes(Backup); var a = Bytes(Root, true); var b = Bytes(result.StorePath, true);
        Assert.Throws<InvalidOperationException>(() => source.BeginWrite()); Assert.Throws<InvalidOperationException>(() => sourceTx.Commit());
        Assert.Throws<InvalidOperationException>(() => source.CreateCheckpoint()); Assert.Throws<InvalidOperationException>(() => source.CreateRecoveryAnchor());
        Assert.Throws<InvalidOperationException>(() => candidate.BeginTransaction()); Assert.Throws<InvalidOperationException>(() => tx.Commit());
        Assert.Throws<InvalidOperationException>(() => candidate.CreateBackup(Path.Combine(_area, "blocked-backup")));
        AssertBytes(a, Root, true); AssertBytes(b, result.StorePath, true); AssertBytes(input, Backup);
        session.Dispose(); freeze.Dispose();
        using (var write = source.BeginWrite()) { using var read = source.BeginRead(); write.ReplaceNodeValue(Target(read), "released-source"); Assert.Equal(2UL, write.Commit()); }
        using (var write = candidate.BeginTransaction()) { using var read = candidate.BeginRead(); write.ReplaceNodeValue(Target(read), "released-candidate"); Assert.Equal(2UL, write.Commit()); }
    }

    /// <summary>Operator/prototype attestations, one registered capture and one owner freeze cannot be silently bypassed.</summary>
    [Fact]
    public void Freeze_RequiredAttestationsAndCaptureRegistration_Rejects()
    {
        Seed(0); using var source = EmbeddedXmlDatabase.Open(Root);
        Assert.Throws<InvalidOperationException>(() => MigrationSourceFreeze.Acquire(source, false));
        using var freeze = MigrationSourceFreeze.Acquire(source, true);
        Assert.Throws<InvalidOperationException>(() => MigrationSourceFreeze.Acquire(source, true));
        var capture = freeze.Capture(Backup); Assert.Throws<InvalidOperationException>(() => freeze.Capture(Path.Combine(_area, "another")));
        var result = EpochLegacyMigration.Convert(Backup, Destination); using var candidate = EpochScalarCoordinator.Open(result.StorePath);
        Assert.Throws<InvalidOperationException>(() => MigrationCutoverSession.Attach(freeze, capture, candidate, result, false));
        var fake = new FrozenMigrationCapture(Backup, capture.InventoryBytes);
        Assert.Throws<InvalidOperationException>(() => MigrationCutoverSession.Attach(freeze, fake, candidate, result, true));
        using var session = MigrationCutoverSession.Attach(freeze, capture, candidate, result, true);
        Assert.Throws<InvalidOperationException>(() => MigrationCutoverSession.Attach(freeze, capture, candidate, result, true));
    }

    /// <summary>Superseded, consumed and foreign evidence are never reusable routing capabilities.</summary>
    [Fact]
    public void Evidence_StaleConsumedAndCrossSession_Rejects()
    {
        Seed(0); using var source = EmbeddedXmlDatabase.Open(Root); using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Backup);
        var result = EpochLegacyMigration.Convert(Backup, Destination); using var candidate = EpochScalarCoordinator.Open(result.StorePath);
        using var session = MigrationCutoverSession.Attach(freeze, capture, candidate, result, true);
        var stale = session.Prepare(); var current = session.Prepare();
        Assert.Throws<InvalidOperationException>(() => session.Evaluate(stale, CutoverAction.ProposeCandidate, CutoverRoute.Legacy, Drained));
        Assert.Equal(CutoverDecision.CandidateProposed, session.Evaluate(current, CutoverAction.ProposeCandidate, CutoverRoute.Legacy, Drained));
        Assert.Throws<InvalidOperationException>(() => session.Evaluate(current, CutoverAction.ProposeCandidate, CutoverRoute.Legacy, Drained));
        var other = EpochLegacyMigration.Convert(Backup, Path.Combine(_area, "second")); using var second = EpochScalarCoordinator.Open(other.StorePath);
        using var foreign = MigrationCutoverSession.Attach(freeze, capture, second, other, true);
        Assert.Throws<InvalidOperationException>(() => session.Evaluate(foreign.Prepare(), CutoverAction.ObserveCandidateOutcome, CutoverRoute.Candidate, Drained));
    }

    /// <summary>Failed and uncertain switch/return observations do not guess which application route is live.</summary>
    /// <param name="observedValue">Reported route enum value.</param>
    [Theory]
    [InlineData((int)CutoverRoute.Legacy)]
    [InlineData((int)CutoverRoute.Candidate)]
    [InlineData((int)CutoverRoute.Unknown)]
    [InlineData((int)CutoverRoute.Other)]
    public void Routing_ObservedFailureOrUncertainty_RequiresExplicitResolution(int observedValue)
    {
        var observed = (CutoverRoute)observedValue;
        Seed(0); using var source = EmbeddedXmlDatabase.Open(Root); using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Backup);
        var result = EpochLegacyMigration.Convert(Backup, Destination); using var candidate = EpochScalarCoordinator.Open(result.StorePath);
        using var session = MigrationCutoverSession.Attach(freeze, capture, candidate, result, true);
        session.Evaluate(session.Prepare(), CutoverAction.ProposeCandidate, CutoverRoute.Legacy, Drained);
        var decision = session.Evaluate(session.Prepare(), CutoverAction.ObserveCandidateOutcome, observed, Drained);
        Assert.Equal(observed == CutoverRoute.Legacy ? CutoverDecision.LegacyObserved : observed == CutoverRoute.Candidate ? CutoverDecision.CandidateObserved : CutoverDecision.RoutingUncertain, decision);
        if (decision == CutoverDecision.RoutingUncertain)
        {
            Assert.Equal(CutoverDecision.CandidateObserved, session.Evaluate(session.Prepare(), CutoverAction.ObserveCandidateOutcome, CutoverRoute.Candidate, Drained));
        }
        if (session.Decision != CutoverDecision.CandidateObserved) return;
        session.Evaluate(session.Prepare(), CutoverAction.ProposeLegacyReturn, CutoverRoute.Candidate, Drained);
        Assert.Equal(CutoverDecision.RoutingUncertain, session.Evaluate(session.Prepare(), CutoverAction.ObserveLegacyOutcome, CutoverRoute.Unknown, Drained));
        Assert.Equal(CutoverDecision.CandidateObserved, session.Evaluate(session.Prepare(), CutoverAction.ObserveLegacyOutcome, CutoverRoute.Candidate, Drained));
    }

    /// <summary>Accepted work or an undrained application requires reconciliation even without a changed commit number.</summary>
    /// <param name="drained">Whether work drained.</param>
    /// <param name="noAcceptedWork">Whether the operator can affirm no accepted work.</param>
    [Theory]
    [InlineData(false, true)]
    [InlineData(true, false)]
    [InlineData(false, false)]
    public void Routing_WorkCannotBeProvenAbsent_RefusesAutomaticRollback(bool drained, bool noAcceptedWork)
    {
        Seed(0); using var source = EmbeddedXmlDatabase.Open(Root); using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Backup);
        var result = EpochLegacyMigration.Convert(Backup, Destination); using var candidate = EpochScalarCoordinator.Open(result.StorePath);
        using var session = MigrationCutoverSession.Attach(freeze, capture, candidate, result, true);
        session.Evaluate(session.Prepare(), CutoverAction.ProposeCandidate, CutoverRoute.Legacy, Drained);
        session.Evaluate(session.Prepare(), CutoverAction.ObserveCandidateOutcome, CutoverRoute.Candidate, Drained);
        Assert.Equal(CutoverDecision.ReconciliationRequired, session.Evaluate(session.Prepare(), CutoverAction.ProposeLegacyReturn, CutoverRoute.Candidate, new(drained, noAcceptedWork)));
        Assert.Throws<InvalidOperationException>(() => session.Prepare());
    }

    /// <summary>Same-H tampering, advanced branches and substituted provenance reject stale observations and make reconciliation terminal.</summary>
    /// <param name="change">Changed commitment.</param>
    [Theory]
    [InlineData("source-wal")]
    [InlineData("source-fragment")]
    [InlineData("source-current")]
    [InlineData("source-extra-wal")]
    [InlineData("artifact-inventory")]
    [InlineData("candidate-wal")]
    [InlineData("candidate-current")]
    [InlineData("candidate-reader")]
    [InlineData("candidate-epoch")]
    [InlineData("origin")]
    public void Freshness_ChangedCommitmentDespiteSameCachedHead_Rejects(string change)
    {
        Seed(1); using var source = EmbeddedXmlDatabase.Open(Root); using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Backup);
        var result = EpochLegacyMigration.Convert(Backup, Destination); using var candidate = EpochScalarCoordinator.Open(result.StorePath);
        using var session = MigrationCutoverSession.Attach(freeze, capture, candidate, result, true); var evidence = session.Prepare();
        var path = change switch
        {
            "source-wal" => Wal(Root, 1),
            "source-fragment" => Path.Combine(Root, "fragments", "1.bin"),
            "source-current" => Path.Combine(Root, ".transactions", "CURRENT"),
            "source-extra-wal" => Wal(Root, 2),
            "artifact-inventory" => Path.Combine(Backup, "inventory.bin"),
            "candidate-wal" => Wal(result.StorePath, 1),
            "candidate-current" => Path.Combine(result.StorePath, ".transactions", "CURRENT"),
            "candidate-reader" => Path.Combine(result.StorePath, ".transactions", "readers", EpochAuthorityCodec.ReaderFileName(0)),
            "candidate-epoch" => Path.Combine(result.StorePath, "EPOCH"),
            _ => Path.Combine(Destination, "migration.bin")
        };
        if (change == "source-wal")
        { var wal = TransactionCodec.ReadWal(path)!; File.WriteAllBytes(path, TransactionCodec.EncodeWal(wal with { TransactionId = Guid.NewGuid() })); }
        else if (change == "candidate-wal")
        { var binding = EpochAuthorityBinding.Create(File.ReadAllBytes(Path.Combine(result.StorePath, "FORMAT")), capture.Inventory.BaseHash); var wal = EpochAuthorityCodec.DecodeWal(File.ReadAllBytes(path), binding); File.WriteAllBytes(path, EpochAuthorityCodec.EncodeWal(wal with { TransactionId = Guid.NewGuid() })); }
        else if (change == "origin")
        { var origin = EpochMigrationCodec.Decode(File.ReadAllBytes(path)); File.WriteAllBytes(path, EpochMigrationCodec.Encode(origin with { MigrationId = Guid.NewGuid() })); }
        else File.WriteAllBytes(path, [1, 2, 3]);
        var sourceBefore = Bytes(Root, true); var candidateBefore = Bytes(Destination, true); var input = Bytes(Backup);
        Assert.Equal(CutoverDecision.ReconciliationRequired, session.Evaluate(evidence, CutoverAction.ProposeCandidate, CutoverRoute.Legacy, Drained));
        AssertBytes(sourceBefore, Root, true); AssertBytes(candidateBefore, Destination, true); AssertBytes(input, Backup);
    }

    /// <summary>Advanced candidate, wrong migration result, and disposed owners are not eligible for initial routing.</summary>
    /// <param name="invalid">Refusal class.</param>
    [Theory]
    [InlineData("advanced-candidate")]
    [InlineData("wrong-result")]
    [InlineData("source-disposed")]
    [InlineData("candidate-disposed")]
    public void Attach_ChangedOrUnavailableOwner_Rejects(string invalid)
    {
        Seed(1); using var source = EmbeddedXmlDatabase.Open(Root); using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Backup);
        var result = EpochLegacyMigration.Convert(Backup, Destination); using var candidate = EpochScalarCoordinator.Open(result.StorePath);
        if (invalid == "advanced-candidate") { using var read = candidate.BeginRead(); using var tx = candidate.BeginTransaction(); tx.ReplaceNodeValue(Target(read), "advanced"); tx.Commit(); }
        if (invalid == "wrong-result") result = result with { MigrationId = Guid.NewGuid() };
        if (invalid == "source-disposed") source.Dispose(); if (invalid == "candidate-disposed") candidate.Dispose();
        var error = Record.Exception(() => MigrationCutoverSession.Attach(freeze, capture, candidate, result, true));
        Assert.True(error is InvalidDataException or InvalidOperationException or ObjectDisposedException);
    }

    /// <summary>Freshness is checked at Prepare too; zero-head live CURRENT may be valid without changing sealed closure.</summary>
    [Fact]
    public void Prepare_FreshnessAndLegacyZeroCurrent_AreExplicit()
    {
        Seed(0); using var source = EmbeddedXmlDatabase.Open(Root); using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Backup);
        File.WriteAllBytes(Path.Combine(Root, ".transactions", "CURRENT"), TransactionCodec.EncodePointer(new(1, 0, capture.Inventory.BaseHash), "BXHD"));
        var result = EpochLegacyMigration.Convert(Backup, Destination); using var candidate = EpochScalarCoordinator.Open(result.StorePath);
        using var session = MigrationCutoverSession.Attach(freeze, capture, candidate, result, true); session.Prepare();
        File.WriteAllBytes(Path.Combine(Root, ".transactions", "CURRENT"), [1]);
        Assert.Throws<InvalidDataException>(() => session.Prepare()); Assert.Equal(CutoverDecision.ReconciliationRequired, session.Decision);
    }

    /// <summary>Other-thread mutation is rejected without admission/gate deadlock; evidence remains caller-thread confined.</summary>
    [Fact]
    public void Freeze_ConcurrentWritesAndForeignThreadAccess_DoNotDeadlock()
    {
        // Scope ownership stays on this method's original thread; the Task body accesses only owner APIs.
        Seed(0); using var source = EmbeddedXmlDatabase.Open(Root); using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Backup);
        var result = EpochLegacyMigration.Convert(Backup, Destination); using var candidate = EpochScalarCoordinator.Open(result.StorePath);
        using var session = MigrationCutoverSession.Attach(freeze, capture, candidate, result, true);
        using var done = new ManualResetEventSlim(); Exception? failure = null;
        ThreadPool.QueueUserWorkItem(_ =>
        {
            try
            {
                Assert.Throws<InvalidOperationException>(() => source.BeginWrite()); Assert.Throws<InvalidOperationException>(() => candidate.BeginTransaction());
                Assert.Throws<InvalidOperationException>(() => candidate.CreateBackup(Path.Combine(_area, "blocked-thread-backup")));
                Assert.Throws<InvalidOperationException>(() => session.Prepare()); Assert.Throws<InvalidOperationException>(() => freeze.Capture(Path.Combine(_area, "foreign")));
            }
            catch (Exception exception) { failure = exception; }
            finally { done.Set(); }
        });
        Assert.True(done.Wait(TimeSpan.FromSeconds(10))); Assert.Null(failure);
    }

    /// <summary>A newly advanced source/capture cannot be matched to an older candidate, even after a new freeze.</summary>
    [Fact]
    public void Source_AdvancedAfterFreezeRelease_RejectsOldCandidate()
    {
        Seed(1); using var source = EmbeddedXmlDatabase.Open(Root);
        using var first = MigrationSourceFreeze.Acquire(source, true); var original = first.Capture(Backup);
        var result = EpochLegacyMigration.Convert(Backup, Destination); first.Dispose();
        using (var read = source.BeginRead()) using (var tx = source.BeginWrite()) { tx.ReplaceNodeValue(Target(read), "advanced"); tx.Commit(); }
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Path.Combine(_area, "later-backup"));
        using var candidate = EpochScalarCoordinator.Open(result.StorePath);
        Assert.Throws<InvalidDataException>(() => MigrationCutoverSession.Attach(freeze, capture, candidate, result, true));
        Assert.Throws<InvalidOperationException>(() => MigrationCutoverSession.Attach(freeze, original, candidate, result, true));
    }

    /// <summary>Old evidence and unresolved route intent cannot survive session restart.</summary>
    [Fact]
    public void Session_RestartRejectsEvidenceAndCannotGuessPriorRouting()
    {
        Seed(0); using var source = EmbeddedXmlDatabase.Open(Root); using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Backup);
        var result = EpochLegacyMigration.Convert(Backup, Destination); using var candidate = EpochScalarCoordinator.Open(result.StorePath);
        using var old = MigrationCutoverSession.Attach(freeze, capture, candidate, result, true); var stale = old.Prepare(); old.Dispose();
        using var session = MigrationCutoverSession.Attach(freeze, capture, candidate, result, true);
        Assert.Throws<InvalidOperationException>(() => session.Evaluate(stale, CutoverAction.ProposeCandidate, CutoverRoute.Legacy, Drained));
        Assert.Equal(CutoverDecision.RoutingUncertain, session.Evaluate(session.Prepare(), CutoverAction.ProposeCandidate, CutoverRoute.Unknown, Drained));
        Assert.Throws<InvalidOperationException>(() => session.Evaluate(session.Prepare(), CutoverAction.ObserveCandidateOutcome, CutoverRoute.Candidate, Drained));
    }

    /// <summary>Owner disposal invalidates readiness; the session's child admission remains independent until disposal.</summary>
    [Fact]
    public void Candidate_DisposalInvalidatesEvidenceAndRetainsIndependentAdmission()
    {
        Seed(0); using var source = EmbeddedXmlDatabase.Open(Root); using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Backup);
        var result = EpochLegacyMigration.Convert(Backup, Destination); using var candidate = EpochScalarCoordinator.Open(result.StorePath);
        using var session = MigrationCutoverSession.Attach(freeze, capture, candidate, result, true); var evidence = session.Prepare(); candidate.Dispose();
        Assert.Throws<IOException>(() => EpochAdmission.Acquire(result.StorePath, result.Destination, true, EpochProfile.ScalarWal));
        Assert.Equal(CutoverDecision.ReconciliationRequired, session.Evaluate(evidence, CutoverAction.ProposeCandidate, CutoverRoute.Legacy, Drained));
        session.Dispose(); using var exclusive = EpochAdmission.Acquire(result.StorePath, result.Destination, true, EpochProfile.ScalarWal);
    }

    private void Seed(int count)
    {
        Directory.CreateDirectory(_area); using var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>")); XmlFragmentImporter.Import(input, Root);
        using var source = EmbeddedXmlDatabase.Open(Root);
        for (var i = 0; i < count; i++) { using var read = source.BeginRead(); using var tx = source.BeginWrite(); tx.ReplaceNodeValue(Target(read), "new-" + i); tx.Commit(); }
    }
    private static ulong Target(ImmutableXmlSnapshot snapshot) => Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();
    private static string Wal(string root, ulong n) => Path.Combine(root, ".transactions", "wal", EpochAuthorityCodec.WalFileName(n));
    private static Dictionary<string, byte[]> Bytes(string root, bool skipWriter = false) => Directory.GetFiles(root, "*", SearchOption.AllDirectories).Where(p => !skipWriter || Path.GetFileName(p) != "writer.lock").ToDictionary(p => Path.GetRelativePath(root, p), File.ReadAllBytes);
    private static string[] Directories(string root) => Directory.GetDirectories(root, "*", SearchOption.AllDirectories).Select(p => Path.GetRelativePath(root, p)).Order().ToArray();
    private static void AssertBytes(Dictionary<string, byte[]> expected, string root, bool skipWriter = false) { var actual = Bytes(root, skipWriter); Assert.Equal(expected.Keys.Order(), actual.Keys.Order()); foreach (var file in expected) Assert.Equal(file.Value, actual[file.Key]); }
    /// <summary>Removes only the isolated test fixture after all caller-owned scopes close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
