// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Verifies conditional journal writes, readback and irreversibly faulted sessions.
// SPECIAL NOTES        : Internal ProcessCrash append only; uncertain sessions remain faulted and all writers stopped.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Tests actual file appends under the existing lifetime owner; no dispatch or routing authority.</summary>
public sealed class EmbeddedHostJournalAppendTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ep4-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "host");
    private string Data => Path.Combine(_area, "data");
    private EmbeddedHostLifetime Provision()
    {
        Directory.CreateDirectory(Data);
        return EmbeddedHostLifetime.Provision(Root, "pilot", "scope", [Data], new(Root, "pilot", "scope", true, true, true));
    }
    private EmbeddedHostLifetime Open() => EmbeddedHostLifetime.OpenExisting(Root, "pilot", "scope", [Data]);
    private static EmbeddedHostAdmissionEvidence Evidence(EmbeddedHostLifetime owner) => new(owner.Context, true, true, true, true, true, true);
    private static void Enable(EmbeddedHostLifetime owner)
    {
        owner.OpenAdministrativeAdmissions(Evidence(owner)); Assert.True(owner.EnableJournalAppend(owner.JournalStatus.KnownPosition, Evidence(owner)));
    }
    private HostLedgerSnapshot Initial(EmbeddedHostLifetime owner) => new(new(Guid.NewGuid(), "pilot", "scope",
        new(Guid.NewGuid(), EpochPublicationKind.LegacyMigration, Path.Combine(Data, "artifact"), Path.Combine(Data, "candidate"), new string('a', 64), Guid.NewGuid(), 7, 0, null,
            EpochProfile.ScalarWal, DurabilityMode.ProcessCrash), 1, owner.Context.SessionId, 1), HostLedgerStage.Recorded);
    private static HostLedgerSnapshot Authorized(HostLedgerSnapshot initial) => initial with { Context = initial.Context with { Revision = 2 }, Stage = HostLedgerStage.DispatchAuthorized };

    /// <summary>Actual flush/readback acknowledgments advance the exact head; only explicit reconciliation enables reopened history.</summary>
    [Fact]
    public async Task Append_ConditionalHistoryAndExplicitOwnerTransfer()
    {
        using var owner = Provision(); Assert.False(owner.JournalStatus.CanAttemptAppend); Enable(owner);
        var start = owner.JournalStatus.KnownPosition; var initial = Initial(owner);
        var first = owner.AppendJournal(start, HostJournalEvent.RecordIntent, initial);
        Assert.Equal(HostJournalAppendDisposition.Acknowledged, first.Disposition); Assert.Equal(1UL, first.Position.Sequence); Assert.True(first.WritersMustRemainStopped);
        var stale = owner.AppendJournal(start, HostJournalEvent.AuthorizeDispatch, Authorized(initial));
        Assert.Equal(HostJournalAppendDisposition.Conflict, stale.Disposition); Assert.Null(stale.Frame); Assert.False(owner.JournalStatus.Faulted);
        var second = owner.AppendJournal(first.Position, HostJournalEvent.AuthorizeDispatch, Authorized(initial)); Assert.Equal(2UL, second.Position.Sequence);
        Assert.Equal(second.Position, owner.JournalStatus.KnownPosition); Assert.Equal(2, owner.ReadJournalForReconciliation().Frames.Count);
        owner.Dispose(); await owner.WhenReleased;
        using var reopened = Open(); Assert.False(reopened.WasProvisionedHere); Assert.False(reopened.JournalStatus.CanAttemptAppend);
        Enable(reopened);
        var transfer = Authorized(initial) with { Context = initial.Context with { Revision = 3, OwnerSession = reopened.Context.SessionId, OwnerGeneration = 2 }, Stage = HostLedgerStage.Uncertain };
        var result = reopened.AppendJournal(reopened.JournalStatus.KnownPosition, HostJournalEvent.TransferOwner, transfer);
        Assert.Equal(HostJournalAppendDisposition.Acknowledged, result.Disposition); Assert.Equal(3, reopened.ReadJournalForReconciliation().Frames.Count);
    }

    /// <summary>A valid reopened empty journal cannot acquire the live initializer's first-write eligibility.</summary>
    [Fact]
    public async Task EmptyReopen_DoesNotEnableFirstWrite()
    {
        using var original = Provision(); original.Dispose(); await original.WhenReleased;
        using var reopened = Open(); reopened.OpenAdministrativeAdmissions(Evidence(reopened));
        Assert.Throws<InvalidOperationException>(() => reopened.EnableJournalAppend(reopened.JournalStatus.KnownPosition, Evidence(reopened)));
        Assert.False(reopened.JournalStatus.CanAttemptAppend); Assert.False(reopened.JournalStatus.Faulted); Assert.Empty(reopened.ReadJournalForReconciliation().Frames);
    }

    /// <summary>Stale/mismatched expected positions are conflicts rather than writes or session faults.</summary>
    /// <param name="field">Mismatched position component.</param>
    [Theory]
    [InlineData("journal")]
    [InlineData("sequence")]
    [InlineData("digest")]
    [InlineData("length")]
    public void ExpectedPositionMismatch_ConflictsWithoutMutation(string field)
    {
        using var owner = Provision(); Enable(owner); var known = owner.JournalStatus.KnownPosition;
        var stale = field switch
        {
            "journal" => known with { JournalId = Guid.NewGuid() },
            "sequence" => known with { Sequence = 1 },
            "digest" => known with { Digest = new string('1', 64) },
            _ => known with { Length = 1 }
        };
        var io = new FaultIo("reject"); var result = owner.AppendJournalCore(stale, HostJournalEvent.RecordIntent, Initial(owner), io);
        Assert.Equal(HostJournalAppendDisposition.Conflict, result.Disposition); Assert.Equal(0, io.Calls); Assert.False(owner.JournalStatus.Faulted); Assert.Empty(owner.ReadJournalForReconciliation().Frames);
    }

    /// <summary>Invalid owner/scope/path/transition proposals never enter output and leave the live valid session usable.</summary>
    /// <param name="fault">Invalid proposal.</param>
    [Theory]
    [InlineData("owner")]
    [InlineData("deployment")]
    [InlineData("scope")]
    [InlineData("relative-path")]
    [InlineData("host-overlap")]
    [InlineData("revision")]
    [InlineData("event")]
    [InlineData("unknown-attempt")]
    [InlineData("bad-hash")]
    [InlineData("native-policy")]
    public void InvalidProposal_RejectsBeforeOutput(string fault)
    {
        using var owner = Provision(); Enable(owner); var known = owner.JournalStatus.KnownPosition; var s = Initial(owner); var kind = HostJournalEvent.RecordIntent;
        s = fault switch
        {
            "owner" => s with { Context = s.Context with { OwnerSession = Guid.NewGuid() } },
            "deployment" => s with { Context = s.Context with { Deployment = "other" } },
            "scope" => s with { Context = s.Context with { ResourceScope = "other" } },
            "relative-path" => s with { Context = s.Context with { Intent = s.Context.Intent with { ArtifactRoot = "relative" } } },
            "host-overlap" => s with { Context = s.Context with { Intent = s.Context.Intent with { BundleRoot = Path.Combine(Root, "candidate") } } },
            "revision" => s with { Context = s.Context with { Revision = 2 } },
            "bad-hash" => s with { Context = s.Context with { Intent = s.Context.Intent with { InventorySha256 = "bad" } } },
            "native-policy" => s with { Context = s.Context with { Intent = s.Context.Intent with { Durability = DurabilityMode.FileAndDirectoryFlush } } },
            _ => s
        };
        if (fault == "event") kind = (HostJournalEvent)999;
        if (fault == "unknown-attempt") { kind = HostJournalEvent.AuthorizeDispatch; s = Authorized(s); }
        var io = new FaultIo("reject"); Assert.NotNull(Record.Exception(() => owner.AppendJournalCore(known, kind, s, io)));
        Assert.Equal(0, io.Calls); Assert.False(owner.JournalStatus.Faulted); Assert.Empty(owner.ReadJournalForReconciliation().Frames);
        Assert.Equal(HostJournalAppendDisposition.Acknowledged, owner.AppendJournal(known, HostJournalEvent.RecordIntent, Initial(owner)).Disposition);
    }

    /// <summary>Write, flush, readback and callback uncertainty permanently faults this session while retaining every byte.</summary>
    /// <param name="fault">Failure phase.</param>
    [Theory]
    [InlineData("write-before")]
    [InlineData("partial")]
    [InlineData("silent-short")]
    [InlineData("silent-corrupt")]
    [InlineData("extra")]
    [InlineData("prefix-corrupt")]
    [InlineData("flush-before")]
    [InlineData("flush-after")]
    [InlineData("before-write")]
    [InlineData("written")]
    [InlineData("flushed")]
    [InlineData("before-ack")]
    public async Task UncertainAppend_FaultsIrreversiblyAndRetainsObservedBytes(string fault)
    {
        using var owner = Provision(); Enable(owner); var initial = Initial(owner);
        var first = owner.AppendJournal(owner.JournalStatus.KnownPosition, HostJournalEvent.RecordIntent, initial); var known = first.Position;
        var io = new FaultIo(fault); HostJournalAppendResult? result = null;
        var error = Record.Exception(() => result = owner.AppendJournalCore(known, HostJournalEvent.AuthorizeDispatch, Authorized(initial), io, stage =>
        {
            if (fault == "before-write" && stage == HostAppendStage.BeforeWrite || fault == "written" && stage == HostAppendStage.Written ||
                fault == "flushed" && stage == HostAppendStage.Flushed || fault == "before-ack" && stage == HostAppendStage.BeforeAcknowledge) throw new IOException("Uncertain callback.");
        }));
        Assert.NotNull(error); Assert.Null(result); Assert.True(owner.JournalStatus.Faulted); Assert.False(owner.AdmissionsOpen); Assert.Equal(known, owner.JournalStatus.KnownPosition);
        Assert.Throws<InvalidOperationException>(() => owner.OpenAdministrativeAdmissions(Evidence(owner)));
        Assert.Throws<InvalidOperationException>(() => owner.EnableJournalAppend(known, Evidence(owner)));
        Assert.Throws<InvalidOperationException>(() => owner.AppendJournal(known, HostJournalEvent.AuthorizeDispatch, Authorized(initial)));
        var malformed = fault is "partial" or "silent-short" or "silent-corrupt" or "extra" or "prefix-corrupt";
        if (malformed) Assert.Throws<InvalidDataException>(() => owner.ReadJournalForReconciliation());
        else Assert.True(owner.ReadJournalForReconciliation().WritersMustRemainStopped);
        Assert.True(owner.JournalStatus.Faulted); owner.Dispose(); await owner.WhenReleased;
        var bytes = File.ReadAllBytes(Path.Combine(Root, "journal.bin"));
        if (malformed) Assert.Throws<InvalidDataException>(() => { using var rejected = Open(); });
        else { using var observed = Open(); Assert.False(observed.JournalStatus.CanAttemptAppend); Assert.False(observed.AdmissionsOpen); }
        Assert.Equal(bytes, File.ReadAllBytes(Path.Combine(Root, "journal.bin")));
    }

    /// <summary>A validation-phase exception precedes append entry and may be explicitly retried without poisoning a valid session.</summary>
    [Fact]
    public void BeforeEntryFailure_DoesNotPoisonOrWrite()
    {
        using var owner = Provision(); Enable(owner); var known = owner.JournalStatus.KnownPosition; var initial = Initial(owner);
        Assert.Throws<IOException>(() => owner.AppendJournal(known, HostJournalEvent.RecordIntent, initial, stage => { if (stage == HostAppendStage.Validated) throw new IOException(); }));
        Assert.False(owner.JournalStatus.Faulted); Assert.True(owner.JournalStatus.CanAttemptAppend); Assert.Empty(owner.ReadJournalForReconciliation().Frames);
        Assert.Equal(HostJournalAppendDisposition.Acknowledged, owner.AppendJournal(known, HostJournalEvent.RecordIntent, initial).Disposition);
    }

    /// <summary>Concurrent proposals for one exact head have one acknowledged writer and no duplicate frame.</summary>
    [Fact]
    public async Task ConcurrentSameHead_OneAcknowledgment()
    {
        using var owner = Provision(); Enable(owner); var known = owner.JournalStatus.KnownPosition; using var start = new ManualResetEventSlim();
        var workers = Enumerable.Range(0, 8).Select(_ => Task.Run(() => { start.Wait(); return owner.AppendJournal(known, HostJournalEvent.RecordIntent, Initial(owner)); })).ToArray();
        start.Set(); var results = await Task.WhenAll(workers); Assert.Single(results, r => r.Disposition == HostJournalAppendDisposition.Acknowledged);
        Assert.Equal(7, results.Count(r => r.Disposition == HostJournalAppendDisposition.Conflict)); Assert.Single(owner.ReadJournalForReconciliation().Frames); Assert.False(owner.JournalStatus.Faulted);
    }

    /// <summary>Shutdown waits for an actual in-flight flush/acknowledgment before releasing the owner lease.</summary>
    [Fact]
    public async Task ShutdownDuringAppend_RetainsOwnershipUntilCompletion()
    {
        using var owner = Provision(); Enable(owner); var known = owner.JournalStatus.KnownPosition; var initial = Initial(owner);
        using var reached = new ManualResetEventSlim(); using var release = new ManualResetEventSlim();
        var append = Task.Run(() => owner.AppendJournal(known, HostJournalEvent.RecordIntent, initial, stage =>
        {
            if (stage != HostAppendStage.Written) return; reached.Set(); if (!release.Wait(TimeSpan.FromSeconds(30))) throw new TimeoutException();
        }));
        try { Assert.True(reached.Wait(TimeSpan.FromSeconds(30))); owner.Dispose(); Assert.False(owner.WhenReleased.IsCompleted); Assert.Throws<IOException>(() => { using var contender = Open(); }); }
        finally { release.Set(); await append; }
        await owner.WhenReleased.WaitAsync(TimeSpan.FromSeconds(5)); Assert.True(owner.IsReleased); Assert.False(owner.JournalStatus.CanAttemptAppend);
        using var observed = Open(); Assert.Single(observed.History.Frames); Assert.False(observed.AdmissionsOpen);
    }

    /// <summary>Callbacks cannot recursively append or alter the shared read cursor through reconciliation reads.</summary>
    [Fact]
    public void Reentrancy_RejectsWithoutDuplicateFrame()
    {
        using var owner = Provision(); Enable(owner); var known = owner.JournalStatus.KnownPosition; var initial = Initial(owner);
        var result = owner.AppendJournal(known, HostJournalEvent.RecordIntent, initial, stage =>
        {
            if (stage != HostAppendStage.Validated) return;
            Assert.Throws<InvalidOperationException>(() => owner.AppendJournal(known, HostJournalEvent.RecordIntent, initial));
            Assert.Throws<InvalidOperationException>(() => owner.ReadJournalForReconciliation());
        });
        Assert.Equal(HostJournalAppendDisposition.Acknowledged, result.Disposition); Assert.Single(owner.ReadJournalForReconciliation().Frames);
    }
    /// <summary>Opening administrative admissions alone does not enable journal output; enablement is conditional on the observed head.</summary>
    [Fact]
    public void JournalEnablement_IsExplicitAndConditional()
    {
        using var owner = Provision(); var known = owner.JournalStatus.KnownPosition; var initial = Initial(owner);
        Assert.Throws<InvalidOperationException>(() => owner.AppendJournal(known, HostJournalEvent.RecordIntent, initial));
        owner.OpenAdministrativeAdmissions(Evidence(owner)); Assert.Throws<InvalidOperationException>(() => owner.AppendJournal(known, HostJournalEvent.RecordIntent, initial));
        Assert.False(owner.EnableJournalAppend(known with { Length = 1 }, Evidence(owner))); Assert.False(owner.JournalStatus.CanAttemptAppend);
        Assert.True(owner.EnableJournalAppend(known, Evidence(owner))); Assert.True(owner.JournalStatus.CanAttemptAppend);
    }

    /// <summary>Unexpected owned namespace changes fault the session before output and remain retained.</summary>
    [Fact]
    public async Task OwnedNamespaceChange_FaultsWithoutCleanup()
    {
        using var owner = Provision(); Enable(owner); var known = owner.JournalStatus.KnownPosition;
        File.WriteAllText(Path.Combine(Root, "foreign"), "retain"); var io = new FaultIo("reject");
        Assert.Throws<InvalidDataException>(() => owner.AppendJournalCore(known, HostJournalEvent.RecordIntent, Initial(owner), io));
        Assert.Equal(0, io.Calls); Assert.True(owner.JournalStatus.Faulted); Assert.False(owner.AdmissionsOpen);
        owner.Dispose(); await owner.WhenReleased; Assert.Equal("retain", File.ReadAllText(Path.Combine(Root, "foreign")));
        Assert.Empty(File.ReadAllBytes(Path.Combine(Root, "journal.bin")));
    }

    private sealed class FaultIo(string fault) : IHostJournalAppendIo
    {
        internal int Calls { get; private set; }
        /// <inheritdoc/>
        public void Write(FileStream stream, ReadOnlySpan<byte> bytes)
        {
            Calls++; if (fault is "reject" or "write-before") throw new IOException("Before write.");
            if (fault is "partial" or "silent-short") { stream.Write(bytes[..(bytes.Length / 2)]); if (fault == "partial") throw new IOException("Partial frame."); return; }
            if (fault == "silent-corrupt") { var corrupted = bytes.ToArray(); corrupted[^20] ^= 1; stream.Write(corrupted); return; }
            var start = stream.Position; stream.Write(bytes);
            if (fault == "extra") stream.WriteByte(0);
            if (fault == "prefix-corrupt") { stream.Position = 0; stream.WriteByte(0); stream.Position = start + bytes.Length; }
        }
        /// <inheritdoc/>
        public void Flush(FileStream stream)
        { Calls++; if (fault == "flush-before") throw new IOException("Before flush."); stream.Flush(true); if (fault == "flush-after") throw new IOException("After flush."); }
    }
    /// <summary>Deletes only the test-owned tree after every owner, I/O task and token closes.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
