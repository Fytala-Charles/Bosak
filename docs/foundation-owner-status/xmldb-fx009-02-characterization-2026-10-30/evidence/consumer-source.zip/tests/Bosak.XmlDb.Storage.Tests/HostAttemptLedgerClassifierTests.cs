// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Verifies pure host ledger decisions for restart, ownership and retry uncertainty.
// SPECIAL NOTES        : Pure internal HA1 model; supplied host facts are not authenticated or independently verified.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Tests host ledger assumptions without persistence, execution, recovery or routing.</summary>
public sealed class HostAttemptLedgerClassifierTests
{
    /// <summary>Every contract scenario has a conservative supplied-evidence decision.</summary>
    /// <param name="scenario">Contract scenario ID.</param>
    /// <param name="expected">Required decision name.</param>
    [Theory]
    [InlineData("intent-save-failed", "DoNotDispatch")]
    [InlineData("intent-save-unknown", "ReconcileLedger")]
    [InlineData("intent-save-confirmed-live", "EligibleToAuthorize")]
    [InlineData("dispatch-cas-conflict", "DoNotDispatch")]
    [InlineData("dispatch-save-unknown", "ReconcileLedger")]
    [InlineData("authorized-before-invoke-crash", "ReconcileExecutorAndPublication")]
    [InlineData("redelivered-job", "DoNotReplay")]
    [InlineData("lease-expired-old-worker", "NoTakeoverOrRetry")]
    [InlineData("stale-owner-publishes", "ReconcileRetainedCandidate")]
    [InlineData("receipt-save-unknown", "ReconcileLedgerAndPublication")]
    [InlineData("known-match", "RecordObservedKnownOnly")]
    [InlineData("artifact-only", "ReconciliationRequired")]
    [InlineData("absent-live-executor", "NoRetry")]
    [InlineData("absent-excluded", "EligibleForFreshAttempt")]
    [InlineData("foreign-publication", "ReconciliationRequired")]
    [InlineData("advanced-candidate", "ReconciliationRequired")]
    [InlineData("observation-revision-race", "ReobserveUnderCurrentOwnership")]
    [InlineData("rollback-or-corrupt-record", "ReconciliationRequired")]
    [InlineData("same-path-different-host", "ReconciliationRequired")]
    [InlineData("route-ack-lost", "ObserveAuthoritativeRoute")]
    [InlineData("work-accounting-unknown", "KeepWritersStopped")]
    [InlineData("recorded-plan-lost", "NoReconstructionReconcileFirst")]
    [InlineData("conflicting-prior-match", "ReconciliationRequired")]
    [InlineData("new-destination-retry", "NoRetry")]
    public void ContractScenarios_ClassifyWithoutGrantingAuthority(string scenario, string expected)
    {
        var input = Scenario(scenario); var before = input;
        var result = HostAttemptLedgerClassifier.Classify(input);
        Assert.Equal(expected, result.Decision.ToString()); Assert.True(result.WritersMustRemainStopped);
        Assert.Equal(before, input); Assert.Equal(result, HostAttemptLedgerClassifier.Classify(input));
    }

    /// <summary>Each record independently binds all request, deployment, attempt and ownership fields.</summary>
    public static IEnumerable<object[]> BindingCases =>
        from slot in Enumerable.Range(0, 4)
        from binding in new[] { "request", "deployment", "scope", "revision", "session", "generation", "attempt", "role", "artifact", "bundle", "hash", "backup", "document", "sequence", "source", "profile", "durability" }
        select new object[] { slot, binding };

    /// <summary>Splicing evidence from another request, attempt or revision never yields eligibility.</summary>
    /// <param name="slot">Evidence component.</param>
    /// <param name="field">Mismatched binding field.</param>
    [Theory]
    [MemberData(nameof(BindingCases))]
    public void BindingMismatch_EveryComponent_Rejects(int slot, string field)
    {
        var input = Good(); var changed = Change(input.Expected!, field);
        input = slot switch
        {
            0 => input with { Record = input.Record! with { Context = changed } },
            1 => input with { Ownership = input.Ownership! with { Context = changed } },
            2 => input with { Publication = input.Publication! with { Context = changed } },
            _ => input with { Flow = input.Flow! with { Context = changed } }
        };
        var result = HostAttemptLedgerClassifier.Classify(input);
        Assert.Equal(field is "revision" or "session" or "generation" ? HostLedgerDecision.ReobserveUnderCurrentOwnership : HostLedgerDecision.ReconciliationRequired, result.Decision);
        Assert.True(result.WritersMustRemainStopped);
    }

    /// <summary>Malformed contexts reconcile rather than crash or infer an authority.</summary>
    /// <param name="field">Malformed field.</param>
    [Theory]
    [InlineData("request")]
    [InlineData("deployment")]
    [InlineData("scope")]
    [InlineData("revision")]
    [InlineData("session")]
    [InlineData("generation")]
    [InlineData("intent")]
    [InlineData("attempt")]
    [InlineData("role")]
    [InlineData("artifact")]
    [InlineData("bundle")]
    [InlineData("hash")]
    [InlineData("backup")]
    [InlineData("document")]
    [InlineData("sequence")]
    [InlineData("source")]
    [InlineData("profile")]
    [InlineData("durability")]
    public void MalformedContext_Rejects(string field)
    {
        var input = Good(); var context = Change(input.Expected!, field, true); input = Rebind(input, context);
        var result = HostAttemptLedgerClassifier.Classify(input);
        Assert.Equal(HostLedgerDecision.ReconciliationRequired, result.Decision); Assert.Equal(HostLedgerReason.InvalidContext, result.Reason);
    }

    /// <summary>Missing components and stale or untrusted facts cannot authorize or qualify retry.</summary>
    /// <param name="fault">Missing or invalid evidence.</param>
    [Theory]
    [InlineData("null")]
    [InlineData("expected")]
    [InlineData("record")]
    [InlineData("owner")]
    [InlineData("publication")]
    [InlineData("flow")]
    [InlineData("record-context")]
    [InlineData("owner-context")]
    [InlineData("publication-context")]
    [InlineData("flow-context")]
    [InlineData("record-stale")]
    [InlineData("owner-stale")]
    [InlineData("publication-stale")]
    [InlineData("flow-stale")]
    [InlineData("rollback")]
    [InlineData("authority")]
    [InlineData("owner-lost")]
    [InlineData("writers-active")]
    [InlineData("queue-live")]
    [InlineData("publisher-live")]
    [InlineData("input-changed")]
    [InlineData("phase")]
    [InlineData("save")]
    [InlineData("observation")]
    [InlineData("receipt-missing")]
    [InlineData("receipt-extra")]
    [InlineData("receipt-uncertain")]
    [InlineData("known-missing")]
    [InlineData("unknown-extra")]
    public void MissingOrUntrustedEvidence_StaysConservative(string fault)
    {
        HostLedgerEvidence? input = Good();
        input = fault switch
        {
            "null" => null,
            "expected" => input with { Expected = null },
            "record" => input with { Record = null },
            "owner" => input with { Ownership = null },
            "publication" => input with { Publication = null },
            "flow" => input with { Flow = null },
            "record-context" => input with { Record = input.Record! with { Context = null! } },
            "owner-context" => input with { Ownership = input.Ownership! with { Context = null! } },
            "publication-context" => input with { Publication = input.Publication! with { Context = null! } },
            "flow-context" => input with { Flow = input.Flow! with { Context = null! } },
            "record-stale" => input with { Record = input.Record! with { Fresh = false } },
            "owner-stale" => input with { Ownership = input.Ownership! with { Fresh = false } },
            "publication-stale" => input with { Publication = input.Publication! with { Fresh = false } },
            "flow-stale" => input with { Flow = input.Flow! with { Fresh = false } },
            "rollback" => input with { Record = input.Record! with { IntegrityAndRollbackChecked = false } },
            "authority" => input with { Record = input.Record! with { Authoritative = false } },
            "owner-lost" => input with { Ownership = input.Ownership! with { CurrentOwner = false } },
            "writers-active" => input with { Ownership = input.Ownership! with { DatabaseWritersExcluded = false } },
            "queue-live" => input with { Ownership = input.Ownership! with { QueuesDrained = false } },
            "publisher-live" => input with { Ownership = input.Ownership! with { AllPriorPublishersExcluded = false } },
            "input-changed" => input with { Flow = input.Flow! with { InputStillPinned = false } },
            "phase" => input with { Record = input.Record! with { Phase = (HostLedgerPhase)999 } },
            "save" => input with { Record = input.Record! with { Save = (HostLedgerSave)999 } },
            "observation" => input with { Publication = input.Publication! with { State = (HostPublicationState)999 } },
            "receipt-missing" => input with { Record = input.Record! with { Phase = HostLedgerPhase.Acknowledged } },
            "receipt-extra" => input with { Record = input.Record! with { Receipt = Receipt(input) } },
            "receipt-uncertain" => input with { Record = input.Record! with { Phase = HostLedgerPhase.Acknowledged, Receipt = Receipt(input), ReceiptPersistenceUnknown = true } },
            "known-missing" => input with { Publication = input.Publication! with { State = HostPublicationState.KnownAttempt } },
            _ => input with { Publication = input.Publication! with { Observed = Observed(input) } }
        };
        var result = HostAttemptLedgerClassifier.Classify(input);
        Assert.DoesNotContain(result.Decision, new[] { HostLedgerDecision.EligibleToAuthorize, HostLedgerDecision.EligibleForFreshAttempt, HostLedgerDecision.RecordObservedKnownOnly, HostLedgerDecision.RetainAcknowledged });
        Assert.True(result.WritersMustRemainStopped);
    }

    /// <summary>Publication and receipt bindings are checked separately from declared match status.</summary>
    /// <param name="receipt">Corrupt receipt rather than observation.</param>
    /// <param name="field">Mismatched publication field.</param>
    [Theory]
    [InlineData(false, "role")]
    [InlineData(false, "operation")]
    [InlineData(false, "backup")]
    [InlineData(false, "source")]
    [InlineData(false, "destination")]
    [InlineData(false, "sequence")]
    [InlineData(false, "path")]
    [InlineData(true, "role")]
    [InlineData(true, "operation")]
    [InlineData(true, "backup")]
    [InlineData(true, "source")]
    [InlineData(true, "destination")]
    [InlineData(true, "sequence")]
    [InlineData(true, "path")]
    public void DeclaredMatch_WithWrongIdentity_Reconciles(bool receipt, string field)
    {
        var input = Known(); var value = input.Publication!.Observed!;
        value = field switch
        {
            "role" => value with { Kind = EpochPublicationKind.IndependentEpochRestore },
            "operation" => value with { OperationId = Guid.NewGuid() },
            "backup" => value with { BackupId = Guid.NewGuid() },
            "source" => value with { SourceEpoch = new(Guid.NewGuid(), Guid.NewGuid(), 7) },
            "destination" => value with { DestinationEpoch = null! },
            "sequence" => value with { CommitSequence = 4 },
            _ => value with { StorePath = "other-store" }
        };
        input = receipt ? input with
        {
            Record = input.Record! with
            {
                Phase = HostLedgerPhase.Acknowledged,
                Receipt = new(value.Kind, value.OperationId, value.BackupId, value.SourceEpoch, value.DestinationEpoch, value.CommitSequence, value.StorePath)
            }
        } :
            input with { Publication = input.Publication with { Observed = value } };
        Assert.Equal(HostLedgerDecision.ReconciliationRequired, HostAttemptLedgerClassifier.Classify(input).Decision);
    }

    /// <summary>A retained receipt remains distinct from observation, and contradictions never become absence eligibility.</summary>
    /// <param name="state">Fresh observation state.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(2)]
    public void AcknowledgedReceipt_IsNotRecreatedFromObservation(int state)
    {
        var input = Known(); input = input with { Record = input.Record! with { Phase = HostLedgerPhase.Acknowledged, Receipt = Receipt(input) } };
        if (state != 2) input = input with { Publication = input.Publication! with { State = (HostPublicationState)state, Observed = null } };
        var result = HostAttemptLedgerClassifier.Classify(input);
        Assert.Equal(state == 2 ? HostLedgerDecision.RetainAcknowledged : HostLedgerDecision.ReconciliationRequired, result.Decision);
        Assert.True(result.WritersMustRemainStopped);
    }

    /// <summary>Prior publication knowledge cannot be erased by an absent or unknown later observation.</summary>
    /// <param name="state">Current publication observation.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    public void PriorPublicationEvidence_UnknownOrAbsent_NeverAuthorizes(int state)
    {
        var input = Good(); input = input with
        {
            Flow = input.Flow! with { PriorPublicationKnown = true },
            Publication = input.Publication! with { State = (HostPublicationState)state }
        };
        Assert.Equal(HostLedgerReason.ConflictingPublication, HostAttemptLedgerClassifier.Classify(input).Reason);
    }

    /// <summary>Absence does not permit fresh attempts while an original executor or executable plan remains.</summary>
    /// <param name="originalExecutor">Whether the original executor remains.</param>
    /// <param name="originalPlan">Whether the original plan remains.</param>
    [Theory]
    [InlineData(false, false)]
    [InlineData(false, true)]
    [InlineData(true, false)]
    [InlineData(true, true)]
    public void FreshAbsence_OriginalExecutorOrPlan_PreventsRetry(bool originalExecutor, bool originalPlan)
    {
        var input = Absent(); input = input with { Record = input.Record! with { OriginalExecutor = originalExecutor, OriginalPlanAvailable = originalPlan } };
        Assert.Equal(originalExecutor || originalPlan ? HostLedgerDecision.NoRetry : HostLedgerDecision.EligibleForFreshAttempt,
            HostAttemptLedgerClassifier.Classify(input).Decision);
    }

    /// <summary>Restore input requires real source identity and independent destination store and epoch IDs.</summary>
    /// <param name="fault">Identity mismatch or valid restore.</param>
    [Theory]
    [InlineData("valid")]
    [InlineData("missing-source")]
    [InlineData("empty-store")]
    [InlineData("empty-epoch")]
    [InlineData("source-document")]
    [InlineData("destination-document")]
    [InlineData("reused-store")]
    [InlineData("reused-epoch")]
    [InlineData("receipt-destination")]
    public void Restore_RequiresBoundSourceAndIndependentDestination(string fault)
    {
        var input = Known(); var source = new EpochIdentity(Guid.NewGuid(), Guid.NewGuid(), 7);
        var intent = input.Expected!.Intent with { Kind = EpochPublicationKind.IndependentEpochRestore, SourceEpoch = source };
        if (fault == "missing-source") intent = intent with { SourceEpoch = null };
        if (fault == "empty-store") intent = intent with { SourceEpoch = source with { StoreId = Guid.Empty } };
        if (fault == "empty-epoch") intent = intent with { SourceEpoch = source with { EpochId = Guid.Empty } };
        if (fault == "source-document") intent = intent with { SourceEpoch = source with { DocumentId = 8 } };
        input = Rebind(input, input.Expected with { Intent = intent });
        var observed = Observed(input);
        if (fault == "destination-document") observed = observed with { DestinationEpoch = observed.DestinationEpoch with { DocumentId = 8 } };
        if (fault == "reused-store") observed = observed with { DestinationEpoch = observed.DestinationEpoch with { StoreId = source.StoreId } };
        if (fault == "reused-epoch") observed = observed with { DestinationEpoch = observed.DestinationEpoch with { EpochId = source.EpochId } };
        input = input with { Publication = input.Publication! with { Observed = observed } };
        if (fault == "receipt-destination") input = input with
        {
            Record = input.Record! with
            {
                Phase = HostLedgerPhase.Acknowledged,
                Receipt = Receipt(input) with { DestinationEpoch = new(Guid.NewGuid(), Guid.NewGuid(), 7) }
            }
        };
        Assert.Equal(fault == "valid" ? HostLedgerDecision.RecordObservedKnownOnly : HostLedgerDecision.ReconciliationRequired,
            HostAttemptLedgerClassifier.Classify(input).Decision);
    }

    /// <summary>Authorization eligibility requires the live original executor, original plan and an unstarted invocation.</summary>
    /// <param name="executor">Original executor.</param>
    /// <param name="plan">Original plan.</param>
    /// <param name="unstarted">Invocation not yet started.</param>
    [Theory]
    [InlineData(false, false, false)]
    [InlineData(false, false, true)]
    [InlineData(false, true, false)]
    [InlineData(false, true, true)]
    [InlineData(true, false, false)]
    [InlineData(true, false, true)]
    [InlineData(true, true, false)]
    [InlineData(true, true, true)]
    public void FirstAuthorization_RequiresAllLocalPrerequisites(bool executor, bool plan, bool unstarted)
    {
        var input = Good(); input = input with { Record = input.Record! with { OriginalExecutor = executor, OriginalPlanAvailable = plan, InvocationNotStarted = unstarted } };
        Assert.Equal(executor && plan && unstarted ? HostLedgerDecision.EligibleToAuthorize : HostLedgerDecision.NoReconstructionReconcileFirst,
            HostAttemptLedgerClassifier.Classify(input).Decision);
    }

    /// <summary>Observed absence does not turn the original unstarted authorization into a retry.</summary>
    [Fact]
    public void RecordedOriginalPlan_WithAbsentDestination_EligibleForFirstAuthorization()
    {
        var input = Good(); input = input with { Publication = input.Publication! with { State = HostPublicationState.Absent } };
        Assert.Equal(HostLedgerDecision.EligibleToAuthorize, HostAttemptLedgerClassifier.Classify(input).Decision);
    }

    private static HostLedgerEvidence Good()
    {
        var intent = new EpochAdministrativeAttemptDescriptor(Guid.NewGuid(), EpochPublicationKind.LegacyMigration,
            "artifact", "candidate", new string('a', 64), Guid.NewGuid(), 7, 3, null, EpochProfile.ScalarWal, DurabilityMode.ProcessCrash);
        var context = new HostLedgerContext(Guid.NewGuid(), "deployment-A", "resource-A", intent, 5, Guid.NewGuid(), 2);
        return new(context, new(context, true, true, true, HostLedgerPhase.Recorded, HostLedgerSave.ConfirmedDurable, true, true, true, false, null),
            new(context, true, true, true, true, true), new(context, true, HostPublicationState.Unknown, null), new(context, true, false, false, true, true, false));
    }
    private static EpochObservedPublication Observed(HostLedgerEvidence input)
    {
        var intent = input.Expected!.Intent;
        return new(intent.Kind, intent.AttemptId, intent.BackupId, intent.SourceEpoch, new(Guid.NewGuid(), Guid.NewGuid(), intent.DocumentId), intent.CommitSequence, Path.Combine(intent.BundleRoot, "store"));
    }
    private static EpochPublishedReceipt Receipt(HostLedgerEvidence input)
    {
        var v = input.Publication!.Observed ?? Observed(input); return new(v.Kind, v.OperationId, v.BackupId, v.SourceEpoch, v.DestinationEpoch, v.CommitSequence, v.StorePath);
    }
    private static HostLedgerEvidence Known()
    {
        var input = Good(); return input with
        {
            Record = input.Record! with { Phase = HostLedgerPhase.DispatchAuthorized },
            Publication = input.Publication! with { State = HostPublicationState.KnownAttempt, Observed = Observed(input) }
        };
    }
    private static HostLedgerEvidence Absent()
    {
        var input = Good(); return input with
        {
            Record = input.Record! with { Phase = HostLedgerPhase.Uncertain, OriginalPlanAvailable = false, OriginalExecutor = false },
            Publication = input.Publication! with { State = HostPublicationState.Absent }
        };
    }
    private static HostLedgerEvidence Scenario(string id)
    {
        var input = Good(); var known = Known(); var absent = Absent();
        return id switch
        {
            "intent-save-failed" => input with { Record = input.Record! with { Save = HostLedgerSave.Rejected } },
            "intent-save-unknown" or "dispatch-save-unknown" => input with { Record = input.Record! with { Save = HostLedgerSave.Unknown, Authoritative = false } },
            "intent-save-confirmed-live" => input,
            "dispatch-cas-conflict" => input with { Record = input.Record! with { Save = HostLedgerSave.Rejected }, Ownership = input.Ownership! with { CurrentOwner = false } },
            "authorized-before-invoke-crash" => input with { Record = input.Record! with { Phase = HostLedgerPhase.DispatchAuthorized, OriginalPlanAvailable = false, OriginalExecutor = false } },
            "redelivered-job" => input with { Flow = input.Flow! with { Redelivery = true }, Record = input.Record! with { Phase = HostLedgerPhase.DispatchAuthorized } },
            "lease-expired-old-worker" => input with { Ownership = input.Ownership! with { AllPriorPublishersExcluded = false } },
            "stale-owner-publishes" => known with { Ownership = known.Ownership! with { CurrentOwner = false } },
            "receipt-save-unknown" => input with { Record = input.Record! with { Phase = HostLedgerPhase.Uncertain, ReceiptPersistenceUnknown = true } },
            "known-match" => Known(),
            "artifact-only" => input with { Publication = input.Publication! with { State = HostPublicationState.ArtifactOnly } },
            "absent-live-executor" or "new-destination-retry" => absent with { Ownership = absent.Ownership! with { AllPriorPublishersExcluded = false } },
            "absent-excluded" => Absent(),
            "foreign-publication" => input with { Publication = input.Publication! with { State = HostPublicationState.Foreign } },
            "advanced-candidate" => input with { Publication = input.Publication! with { State = HostPublicationState.Advanced } },
            "observation-revision-race" => input with { Publication = input.Publication! with { Context = input.Expected! with { Revision = 4 } } },
            "rollback-or-corrupt-record" => input with { Record = input.Record! with { IntegrityAndRollbackChecked = false } },
            "same-path-different-host" => input with { Publication = input.Publication! with { Context = input.Expected! with { Deployment = "other-deployment" } } },
            "route-ack-lost" => input with { Flow = input.Flow! with { RouteAcknowledgmentLost = true } },
            "work-accounting-unknown" => input with { Flow = input.Flow! with { WorkAccountingComplete = false } },
            "recorded-plan-lost" => input with { Record = input.Record! with { OriginalPlanAvailable = false, OriginalExecutor = false } },
            "conflicting-prior-match" => absent with { Flow = absent.Flow! with { PriorPublicationKnown = true } },
            _ => throw new ArgumentException("Unknown contract scenario.", nameof(id))
        };
    }
    private static HostLedgerEvidence Rebind(HostLedgerEvidence input, HostLedgerContext context) => input with
    {
        Expected = context,
        Record = input.Record! with { Context = context },
        Ownership = input.Ownership! with { Context = context },
        Publication = input.Publication! with { Context = context },
        Flow = input.Flow! with { Context = context }
    };
    private static HostLedgerContext Change(HostLedgerContext c, string field, bool malformed = false)
    {
        var d = c.Intent;
        return field switch
        {
            "request" => c with { RequestId = malformed ? Guid.Empty : Guid.NewGuid() },
            "deployment" => c with { Deployment = malformed ? null! : "other-deployment" },
            "scope" => c with { ResourceScope = malformed ? " " : "other-scope" },
            "revision" => c with { Revision = malformed ? 0UL : 4UL },
            "session" => c with { OwnerSession = malformed ? Guid.Empty : Guid.NewGuid() },
            "generation" => c with { OwnerGeneration = malformed ? 0UL : 3UL },
            "intent" => c with { Intent = null! },
            "attempt" => c with { Intent = d with { AttemptId = malformed ? Guid.Empty : Guid.NewGuid() } },
            "role" => c with { Intent = d with { Kind = malformed ? (EpochPublicationKind)999 : EpochPublicationKind.IndependentEpochRestore } },
            "artifact" => c with { Intent = d with { ArtifactRoot = malformed ? "" : "other-artifact" } },
            "bundle" => c with { Intent = d with { BundleRoot = malformed ? d.ArtifactRoot : "other-bundle" } },
            "hash" => c with { Intent = d with { InventorySha256 = malformed ? new string('Z', 64) : new string('b', 64) } },
            "backup" => c with { Intent = d with { BackupId = malformed ? Guid.Empty : Guid.NewGuid() } },
            "document" => c with { Intent = d with { DocumentId = malformed ? 0UL : 8UL } },
            "sequence" => c with { Intent = d with { CommitSequence = malformed ? 10_001UL : 4UL } },
            "source" => c with { Intent = d with { SourceEpoch = new(Guid.NewGuid(), Guid.NewGuid(), d.DocumentId) } },
            "profile" => c with { Intent = d with { DestinationProfile = (EpochProfile)999 } },
            _ => c with { Intent = d with { Durability = malformed ? (DurabilityMode)999 : DurabilityMode.FileAndDirectoryFlush } }
        };
    }
}
