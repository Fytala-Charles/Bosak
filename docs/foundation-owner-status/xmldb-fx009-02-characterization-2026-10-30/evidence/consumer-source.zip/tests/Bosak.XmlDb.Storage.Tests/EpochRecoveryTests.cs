// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies scalar epoch publication faults, deterministic redo and incomplete-tail witnesses.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 27-10-2026     | Reuse fault sweeps with actual native Linux durability and explicit platform checks
// ===========================================================================================================================================================

using System.Text;
using Bosak.XmlDb.Core;
using Xunit;
using Xunit.Abstractions;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Verifies epoch publication and recovery at every injected persistence operation.</summary>
public sealed class EpochRecoveryTests(ITestOutputHelper output) : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-et6-" + Guid.NewGuid().ToString("N"));
    private string Source => Path.Combine(_area, "source");

    /// <summary>Every before/after persistence error and partial write faults the writer and reopens exact old/new state.</summary>
    /// <param name="strong">Whether stronger barrier ordering is modeled.</param>
    /// <param name="fault">Injected boundary.</param>
    /// <param name="positiveBase">Whether to commit from a positive selected head.</param>
    [Theory]
    [InlineData(false, "before", false)]
    [InlineData(false, "after", false)]
    [InlineData(false, "partial", false)]
    [InlineData(true, "before", false)]
    [InlineData(true, "after", false)]
    [InlineData(true, "partial", false)]
    [InlineData(false, "before", true)]
    [InlineData(false, "after", true)]
    [InlineData(false, "partial", true)]
    [InlineData(true, "before", true)]
    [InlineData(true, "after", true)]
    [InlineData(true, "partial", true)]
    public void Commit_AllPersistenceFaults_ReopensExactOldOrNewHead(bool strong, string fault, bool positiveBase) =>
        RunCommit(strong, fault, positiveBase, false);

    private void RunCommit(bool strong, string fault, bool positiveBase, bool native)
    {
        SeedSource(); var mode = strong ? DurabilityMode.FileAndDirectoryFlush : DurabilityMode.ProcessCrash;
        var reference = Seed("reference", positiveBase); var recording = new FaultingTransactionStorage(mode, native);
        using (var owner = EpochScalarCoordinator.Open(reference, recording))
        using (var read = owner.BeginRead())
        using (var transaction = owner.BeginTransaction())
        { transaction.ReplaceNodeValue(Target(read), "new"); recording.Arm(); transaction.Commit(); }
        VerifyDelegate(recording, mode, native); var calls = Positions(recording, fault); Assert.NotEmpty(calls);
        foreach (var index in calls)
        {
            var root = Seed("attempt-" + index, positiveBase); var storage = new FaultingTransactionStorage(mode, native);
            var owner = EpochScalarCoordinator.Open(root, storage); using var old = owner.BeginRead(0);
            using var transaction = owner.BeginTransaction(); var target = Target(old); transaction.ReplaceNodeValue(target, "new");
            storage.Arm(index, fault == "partial");
            Assert.Throws<IOException>(() => transaction.Commit()); Assert.True(storage.Fired);
            Assert.Throws<InvalidOperationException>(() => owner.BeginRead()); owner.Dispose();
            var next = positiveBase ? 2UL : 1UL;
            var wal = Path.Combine(root, ".transactions", "wal", EpochAuthorityCodec.WalFileName(next));
            var complete = File.Exists(wal) && EpochScalarRecovery.ReadWal(wal) is not null;
            var expected = complete ? "new" : positiveBase ? "prior" : "old";
            for (var repeat = 0; repeat < 2; repeat++)
            {
                using var reopened = EpochScalarCoordinator.Open(root, NativeStorage(mode)); using var read = reopened.BeginRead(0);
                Assert.Equal(expected, read.ReadValue(target)); Assert.Equal(complete ? next : next - 1, read.CommitSequence);
            }
            Assert.Equal(positiveBase ? "prior" : "old", old.ReadValue(target));
        }
        output.WriteLine($"{(native ? "et8-native" : "et6")}-commit-{(positiveBase ? "positive" : "zero")}-{(strong ? "strong" : "process")}/{fault}: {calls.Length} fault positions verified.");
    }

    /// <summary>Interrupted recovery can be repeated after every I/O failure without altering its required WAL or old readers.</summary>
    /// <param name="strong">Whether stronger barrier ordering is modeled.</param>
    /// <param name="fault">Injected boundary.</param>
    [Theory]
    [InlineData(false, "before")]
    [InlineData(false, "after")]
    [InlineData(false, "partial")]
    [InlineData(true, "before")]
    [InlineData(true, "after")]
    [InlineData(true, "partial")]
    public void Redo_AllPersistenceFaults_RepeatedOpenReproducesRecordedHead(bool strong, string fault) =>
        RunRedo(strong, fault, false);

    private void RunRedo(bool strong, string fault, bool native)
    {
        SeedSource(); var mode = strong ? DurabilityMode.FileAndDirectoryFlush : DurabilityMode.ProcessCrash;
        var reference = Missing("reference"); var recording = new FaultingTransactionStorage(mode, native); recording.Arm();
        using (EpochScalarCoordinator.Open(reference, recording)) { }
        VerifyDelegate(recording, mode, native); var calls = Positions(recording, fault); Assert.NotEmpty(calls);
        foreach (var index in calls)
        {
            var root = Missing("attempt-" + index); var identity = EpochAdmission.ReadIdentity(root, EpochProfile.ScalarWal);
            var walPath = Path.Combine(root, ".transactions", "wal", EpochAuthorityCodec.WalFileName(1)); var wal = File.ReadAllBytes(walPath);
            var storage = new FaultingTransactionStorage(mode, native); storage.Arm(index, fault == "partial");
            Assert.Throws<IOException>(() => EpochScalarCoordinator.Open(root, storage)); Assert.True(storage.Fired);
            using (EpochAdmission.Acquire(root, identity, true, EpochProfile.ScalarWal)) { }
            for (var repeat = 0; repeat < 2; repeat++)
            {
                using var reopened = EpochScalarCoordinator.Open(root, NativeStorage(mode)); using var read = reopened.BeginRead(0);
                Assert.Equal("new", read.ReadValue(Target(read))); Assert.Equal(1UL, read.CommitSequence);
            }
            Assert.Equal(wal, File.ReadAllBytes(walPath));
        }
        output.WriteLine($"{(native ? "et8-native" : "et6")}-redo-{(strong ? "strong" : "process")}/{fault}: {calls.Length} fault positions verified.");
    }

    /// <summary>Only supported physically incomplete final framing without publication witnesses may be removed.</summary>
    [Fact]
    public void Recovery_AllWalTruncations_DiscardOnlyUnwitnessedSupportedPrefixes()
    {
        SeedSource(); var complete = Missing("complete"); var path = Path.Combine(complete, ".transactions", "wal", EpochAuthorityCodec.WalFileName(1));
        var bytes = File.ReadAllBytes(path);
        for (var length = 0; length < bytes.Length; length++)
        {
            var root = Missing("prefix-" + length); var tail = Path.Combine(root, ".transactions", "wal", EpochAuthorityCodec.WalFileName(1));
            var ownBytes = File.ReadAllBytes(tail); File.WriteAllBytes(tail, ownBytes[..length]); using var owner = EpochScalarCoordinator.Open(root); using var read = owner.BeginRead();
            Assert.Equal(0UL, read.CommitSequence); Assert.False(File.Exists(tail)); Assert.Equal("old", read.ReadValue(Target(read)));
        }
    }

    /// <summary>A published generation/current/reader or later record prevents incomplete-tail removal.</summary>
    /// <param name="witness">Publication witness or corruption.</param>
    [Theory]
    [InlineData("generation")]
    [InlineData("CURRENT")]
    [InlineData("reader")]
    [InlineData("later")]
    [InlineData("checksum")]
    [InlineData("version")]
    [InlineData("magic")]
    [InlineData("length")]
    public void Recovery_WitnessedTailOrCorruption_FailsClosedAndPreservesWal(string witness)
    {
        SeedSource(); var root = Seed("case", false);
        if (witness is "generation" or "CURRENT" or "reader")
        { using var owner = EpochScalarCoordinator.Open(root); using var read = owner.BeginRead(); using var tx = owner.BeginTransaction(); tx.ReplaceNodeValue(Target(read), "new"); tx.Commit(); }
        else { root = Missing("missing"); }
        var wal = Path.Combine(root, ".transactions", "wal", EpochAuthorityCodec.WalFileName(1)); var bytes = File.ReadAllBytes(wal);
        if (witness == "generation")
        { File.Delete(Path.Combine(root, ".transactions", "CURRENT")); File.Delete(EpochGenerationReader.PathFor(root, 1)); }
        if (witness is "CURRENT" or "reader") Directory.Delete(EpochScalarHistory.Generation(root, 1), true);
        if (witness == "reader") File.Delete(Path.Combine(root, ".transactions", "CURRENT"));
        if (witness == "later") File.WriteAllBytes(Path.Combine(root, ".transactions", "wal", EpochAuthorityCodec.WalFileName(2)), bytes);
        if (witness is "generation" or "CURRENT" or "reader" or "later") bytes = bytes[..(bytes.Length / 2)];
        if (witness == "checksum") bytes[^1] ^= 1;
        if (witness == "version") bytes[4] = 2;
        if (witness == "magic") bytes[0] = 0;
        if (witness == "length") bytes[8] = 0;
        File.WriteAllBytes(wal, bytes);
        Assert.Throws<InvalidDataException>(() => EpochScalarCoordinator.Open(root)); Assert.Equal(bytes, File.ReadAllBytes(wal));
    }

    /// <summary>Removing an unwitnessed incomplete append remains safe after deletion and directory-sync failures.</summary>
    /// <param name="strong">Whether stronger barriers are modeled.</param>
    /// <param name="fault">Failure boundary.</param>
    [Theory]
    [InlineData(false, "before")]
    [InlineData(false, "after")]
    [InlineData(false, "partial")]
    [InlineData(true, "before")]
    [InlineData(true, "after")]
    [InlineData(true, "partial")]
    public void TailDiscard_AllPersistenceFaults_ReopensBaseWithoutTouchingCommittedHistory(bool strong, string fault) =>
        RunTail(strong, fault, false);

    private void RunTail(bool strong, string fault, bool native)
    {
        SeedSource(); var mode = strong ? DurabilityMode.FileAndDirectoryFlush : DurabilityMode.ProcessCrash;
        string Torn(string name)
        {
            var root = Seed(name, true); File.WriteAllBytes(Path.Combine(root, ".transactions", "wal", EpochAuthorityCodec.WalFileName(2)), "BXE"u8.ToArray()); return root;
        }
        var reference = Torn("reference"); var recording = new FaultingTransactionStorage(mode, native); recording.Arm();
        using (EpochScalarCoordinator.Open(reference, recording)) { }
        VerifyDelegate(recording, mode, native); var calls = Positions(recording, fault);
        foreach (var index in calls)
        {
            var root = Torn("attempt-" + index); var wal = Path.Combine(root, ".transactions", "wal", EpochAuthorityCodec.WalFileName(1)); var bytes = File.ReadAllBytes(wal);
            var storage = new FaultingTransactionStorage(mode, native); storage.Arm(index, fault == "partial");
            Assert.Throws<IOException>(() => EpochScalarCoordinator.Open(root, storage)); Assert.True(storage.Fired);
            for (var repeat = 0; repeat < 2; repeat++)
            { using var owner = EpochScalarCoordinator.Open(root, NativeStorage(mode)); using var read = owner.BeginRead(0); Assert.Equal(1UL, read.CommitSequence); Assert.Equal("prior", read.ReadValue(Target(read))); }
            Assert.Equal(bytes, File.ReadAllBytes(wal));
        }
        output.WriteLine($"{(native ? "et8-native" : "et6")}-tail-{(strong ? "strong" : "process")}/{fault}: {calls.Length} fault positions verified.");
    }

    /// <summary>A resealed WAL result digest must reproduce exactly before missing materialization publication.</summary>
    [Fact]
    public void Redo_WrongRecordedResult_NeverPublishesSubstituteGeneration()
    {
        SeedSource(); var root = Missing("missing"); var identity = EpochAdmission.ReadIdentity(root, EpochProfile.ScalarWal);
        var binding = EpochEmptyCoordinator.ReadAuthority(root, identity, true);
        var wal = Path.Combine(root, ".transactions", "wal", EpochAuthorityCodec.WalFileName(1));
        var record = EpochAuthorityCodec.DecodeWal(File.ReadAllBytes(wal), binding);
        var bytes = EpochAuthorityCodec.EncodeWal(record with { ManifestHash = new byte[32] }); File.WriteAllBytes(wal, bytes);
        Assert.Throws<InvalidDataException>(() => EpochScalarCoordinator.Open(root));
        Assert.False(Directory.Exists(EpochScalarHistory.Generation(root, 1))); Assert.Equal(bytes, File.ReadAllBytes(wal));
    }

    /// <summary>Injects before/after calls and partial writes around actual native Linux commit barriers.</summary>
    /// <param name="fault">Injected boundary.</param>
    /// <param name="positiveBase">Whether the initial selected head is positive.</param>
    [Theory]
    [InlineData("before", false)]
    [InlineData("after", false)]
    [InlineData("partial", false)]
    [InlineData("before", true)]
    [InlineData("after", true)]
    [InlineData("partial", true)]
    public void Commit_NativeLinuxFaults_ReopensExactOldOrNewHead(string fault, bool positiveBase)
    {
        if (!OperatingSystem.IsLinux()) { output.WriteLine("ET8 native Linux branch not executed on this host."); return; }
        RunCommit(true, fault, positiveBase, true);
    }

    /// <summary>Injects recovery faults while actual native Linux directory barriers execute.</summary>
    /// <param name="fault">Injected boundary.</param>
    [Theory]
    [InlineData("before")]
    [InlineData("after")]
    [InlineData("partial")]
    public void Redo_NativeLinuxFaults_RepeatsExactRecovery(string fault)
    {
        if (!OperatingSystem.IsLinux()) { output.WriteLine("ET8 native Linux branch not executed on this host."); return; }
        RunRedo(true, fault, true);
    }

    /// <summary>Injects deletion and directory-barrier faults without reclaiming committed history.</summary>
    /// <param name="fault">Injected boundary.</param>
    [Theory]
    [InlineData("before")]
    [InlineData("after")]
    [InlineData("partial")]
    public void TailDiscard_NativeLinuxFaults_PreservesCommittedPrefix(string fault)
    {
        if (!OperatingSystem.IsLinux()) { output.WriteLine("ET8 native Linux branch not executed on this host."); return; }
        RunTail(true, fault, true);
    }

    /// <summary>Native policy selection either binds the exact delegate or rejects an unsupported host without mutation.</summary>
    [Fact]
    public void StorageAdapter_NativePolicy_RejectsUnsupportedHostWithoutFallback()
    {
        var modeled = new FaultingTransactionStorage(DurabilityMode.FileAndDirectoryFlush);
        Assert.Equal(DurabilityMode.ProcessCrash, modeled.EffectiveDurability);
        if (OperatingSystem.IsLinux())
        {
            var native = new FaultingTransactionStorage(DurabilityMode.FileAndDirectoryFlush, true);
            Assert.Equal(DurabilityMode.FileAndDirectoryFlush, native.EffectiveDurability); return;
        }
        SeedSource(); var root = Seed("unsupported", false);
        var before = Directory.GetFiles(root, "*", SearchOption.AllDirectories).ToDictionary(path => Path.GetRelativePath(root, path), File.ReadAllBytes);
        Assert.Throws<PlatformNotSupportedException>(() => EpochScalarCoordinator.Open(root, new FaultingTransactionStorage(DurabilityMode.FileAndDirectoryFlush, true)));
        Assert.Equal(before.Keys.Order(), Directory.GetFiles(root, "*", SearchOption.AllDirectories).Select(path => Path.GetRelativePath(root, path)).Order());
        foreach (var item in before) Assert.Equal(item.Value, File.ReadAllBytes(Path.Combine(root, item.Key)));
        Assert.False(File.Exists(Path.Combine(root, ".transactions", "writer.lock")));
    }

    /// <summary>A real Linux fsync failure propagates through the fault adapter without an after-event or weaker retry.</summary>
    [Fact]
    public void StorageAdapter_NativeDirectoryFsyncError_PropagatesWithoutFallback()
    {
        if (!OperatingSystem.IsLinux()) { output.WriteLine("ET8 native Linux branch not executed on this host."); return; }
        var native = new FaultingTransactionStorage(DurabilityMode.FileAndDirectoryFlush, true); native.Arm();
        // procfs rejects directory fsync; this is a native kernel error, not injected disk-full or power loss.
        var error = Assert.Throws<IOException>(() => native.SyncDirectory("/proc"));
        Assert.Contains("fsync directory", error.Message); Assert.Contains("errno", error.Message);
        Assert.Equal(DurabilityMode.FileAndDirectoryFlush, native.EffectiveDurability);
        Assert.Single(native.Calls); Assert.Equal("before", native.Calls[0].Moment); Assert.False(native.Fired);
        output.WriteLine("ET8 native directory error propagated: " + error.Message);
    }

    private static void VerifyDelegate(FaultingTransactionStorage storage, DurabilityMode mode, bool native)
    {
        Assert.Equal(native ? mode : DurabilityMode.ProcessCrash, storage.EffectiveDurability);
        Assert.Contains(storage.Calls, call => call.Operation == "SyncDirectory" && call.Moment == "after");
    }

    private static int[] Positions(FaultingTransactionStorage storage, string fault) => storage.Calls.Select((call, index) => (call, index)).Where(item => fault == "partial"
        ? item.call.Operation == "WriteFile" && item.call.Moment == "before" : item.call.Moment == fault).Select(item => item.index).ToArray();
    private static LocalTransactionStorage NativeStorage(DurabilityMode mode) => new(OperatingSystem.IsLinux() ? mode : DurabilityMode.ProcessCrash);
    private string Missing(string name)
    {
        var root = Seed(name, false);
        using var owner = EpochScalarCoordinator.Open(root, checkpoint: stage => { if (stage == EpochScalarStage.WalFlushed) throw new IOException("stop before generation"); });
        using var read = owner.BeginRead(); using var transaction = owner.BeginTransaction(); transaction.ReplaceNodeValue(Target(read), "new");
        Assert.Throws<IOException>(() => transaction.Commit()); return root;
    }
    private string Seed(string name, bool positive)
    {
        var root = Path.Combine(_area, name); EpochEmptyRoot.CreateFixture(Source, root, 1, new LocalTransactionStorage());
        if (positive)
        { using var owner = EpochScalarCoordinator.Open(root); using var read = owner.BeginRead(); using var tx = owner.BeginTransaction(); tx.ReplaceNodeValue(Target(read), "prior"); tx.Commit(); }
        return root;
    }
    private void SeedSource()
    { Directory.CreateDirectory(_area); using var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID><line>line</line></r>")); XmlFragmentImporter.Import(input, Source); }
    private static ulong Target(ImmutableXmlSnapshot snapshot) => Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id))
        .Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();
    /// <summary>Removes isolated fixture data after all handles close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
