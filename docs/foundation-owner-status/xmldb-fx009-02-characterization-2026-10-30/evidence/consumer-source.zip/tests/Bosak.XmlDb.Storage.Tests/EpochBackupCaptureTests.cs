// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies admitted fixed-head epoch capture and independent full-history verification.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================


using System.Security.Cryptography;
using System.Text;
using Bosak.XmlDb.Core;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Verifies internal epoch capture without source mutation or public restore.</summary>
public sealed class EpochBackupCaptureTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-et9b-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "epoch");
    private string Backup => Path.Combine(_area, "backup");

    /// <summary>Captures H=0/1/multiple operations with exact closure and both independent verification oracles.</summary>
    /// <param name="sequence">Captured sequence.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(3)]
    public void Capture_ExactHistory_PreservesSourceAndOldSnapshots(int sequence)
    {
        Seed(); using var owner = EpochScalarCoordinator.Open(Root); using var old = owner.BeginRead(0); Commit(owner, sequence);
        var before = Bytes(Root); var stages = new List<EpochBackupStage>();
        var result = owner.CreateBackup(Backup, stages.Add);
        Assert.Equal((ulong)sequence, result.CommitSequence); Assert.Equal(owner.Identity, result.Source);
        var inventory = EpochBackupStorage.ReadArtifact(Backup); Assert.Equal(result.BackupId, inventory.BackupId);
        Assert.Equal(EpochBackupStorage.FileSet(Root, 1, (ulong)sequence), inventory.Files.Select(file => file.Path));
        Assert.Equal(Enum.GetValues<EpochBackupStage>(), stages);
        foreach (var entry in inventory.Files) Assert.Equal(File.ReadAllBytes(Path.Combine(Root, entry.Path)), File.ReadAllBytes(Path.Combine(Backup, "data", entry.Path)));
        Assert.DoesNotContain(inventory.Files, file => file.Path.Contains("admission", StringComparison.Ordinal) || file.Path.Contains("readers", StringComparison.Ordinal) || file.Path.Contains("writer.lock", StringComparison.Ordinal));
        Assert.Equal("old", old.ReadValue(Target(old))); AssertBytes(before, Root);
        Assert.Empty(Directory.GetDirectories(_area, ".xmldb-epoch-backup-*"));
        var sealedBytes = Bytes(Backup); Commit(owner, 1); AssertBytes(sealedBytes, Backup);
        var openError = Record.Exception(() => EpochScalarCoordinator.Open(Path.Combine(Backup, "data")));
        Assert.True(openError is InvalidDataException or IOException, openError?.ToString());
        Assert.Throws<InvalidDataException>(() => ReadOnlyEpochDatabase.Open(Path.Combine(Backup, "data")));
        AssertBytes(sealedBytes, Backup);
    }

    /// <summary>Private staging and publication temporaries are omitted without being adopted or deleted.</summary>
    [Fact]
    public void Capture_RecognizedPrivateDebris_RetainsSourceAndOmitsRuntimeState()
    {
        Seed(); using var owner = EpochScalarCoordinator.Open(Root);
        var stage = Path.Combine(Root, ".transactions", "staging", Guid.NewGuid().ToString("N")); Directory.CreateDirectory(stage); File.WriteAllText(Path.Combine(stage, "partial"), "keep");
        File.WriteAllBytes(Path.Combine(Root, ".transactions", "current-" + Guid.NewGuid().ToString("N") + ".tmp"), [0]);
        File.WriteAllBytes(EpochGenerationReader.PathFor(Root, 0) + ".tmp-" + Guid.NewGuid().ToString("N"), [0]);
        var before = Bytes(Root); owner.CreateBackup(Backup); AssertBytes(before, Root);
        Assert.DoesNotContain(EpochBackupStorage.ReadArtifact(Backup).Files, entry => entry.Path.Contains("staging", StringComparison.Ordinal) || entry.Path.EndsWith(".tmp", StringComparison.Ordinal));
    }

    /// <summary>Unknown dependencies, required corruption and stale/missing publication fail without repairing the source.</summary>
    /// <param name="artifact">Source damage.</param>
    [Theory]
    [InlineData("unknown-root")]
    [InlineData("unknown-epoch")]
    [InlineData("unknown-generation")]
    [InlineData("unknown-empty-directory")]
    [InlineData("fragment")]
    [InlineData("missing-current")]
    [InlineData("stale-current")]
    [InlineData("missing-generation")]
    [InlineData("tail")]
    public void Capture_InvalidSource_FaultsOwnerAndPreservesAllEvidence(string artifact)
    {
        Seed(); using var owner = EpochScalarCoordinator.Open(Root); Commit(owner, 1);
        if (artifact == "unknown-root") File.WriteAllText(Path.Combine(Root, "future"), "keep");
        if (artifact == "unknown-epoch") File.WriteAllText(Path.Combine(Root, ".epoch", "future"), "keep");
        if (artifact == "unknown-generation") File.WriteAllText(Path.Combine(EpochScalarHistory.Generation(Root, 1), "future"), "keep");
        if (artifact == "unknown-empty-directory") Directory.CreateDirectory(Path.Combine(Root, "future"));
        if (artifact == "fragment") File.WriteAllBytes(Path.Combine(EpochScalarHistory.Generation(Root, 1), "fragments", "1.bin"), [0]);
        if (artifact == "missing-current") File.Delete(Path.Combine(Root, ".transactions", "CURRENT"));
        if (artifact == "stale-current")
        { var binding = EpochEmptyCoordinator.ReadAuthority(Root, owner.Identity, true); File.WriteAllBytes(Path.Combine(Root, ".transactions", "CURRENT"), EpochAuthorityCodec.EncodeCurrent(new(binding, 0, binding.BaseHash, new byte[32]))); }
        if (artifact == "missing-generation") Directory.Delete(EpochScalarHistory.Generation(Root, 1), true);
        if (artifact == "tail") File.WriteAllBytes(Path.Combine(Root, ".transactions", "wal", EpochAuthorityCodec.WalFileName(2)), "BXE"u8.ToArray());
        var before = Bytes(Root); var directories = Directories(Root);
        var error = Record.Exception(() => owner.CreateBackup(Backup));
        Assert.True(error is IOException or InvalidDataException or NotSupportedException, error?.ToString() ?? "Capture unexpectedly succeeded.");
        Assert.Throws<InvalidOperationException>(() => owner.BeginRead()); Assert.False(Directory.Exists(Backup));
        AssertBytes(before, Root); Assert.Equal(directories, Directories(Root)); Assert.Empty(Directory.GetDirectories(_area, ".xmldb-epoch-backup-*"));
    }

    /// <summary>Argument/path failures preserve a live owner's usability and existing destinations.</summary>
    /// <param name="target">Invalid destination.</param>
    [Theory]
    [InlineData("root")]
    [InlineData("child")]
    [InlineData("parent")]
    [InlineData("existing")]
    public void Capture_InvalidDestination_DoesNotFaultOrOverwrite(string target)
    {
        Seed(); using var owner = EpochScalarCoordinator.Open(Root);
        if (target == "existing") { Directory.CreateDirectory(Backup); File.WriteAllText(Path.Combine(Backup, "keep"), "keep"); }
        var path = target switch { "root" => Root, "child" => Path.Combine(Root, "backup"), "parent" => _area, _ => Backup };
        var error = Record.Exception(() => owner.CreateBackup(path)); Assert.True(error is ArgumentException or IOException, error?.ToString());
        using var read = owner.BeginRead(); Assert.Equal("old", read.ReadValue(Target(read)));
        if (target == "existing") Assert.Equal("keep", File.ReadAllText(Path.Combine(Backup, "keep")));
    }

    /// <summary>All selected capture checkpoints fail uncertainly without mutating source history or breaking old readers.</summary>
    /// <param name="stage">Failure boundary.</param>
    [Theory]
    [InlineData((int)EpochBackupStage.Captured)]
    [InlineData((int)EpochBackupStage.Copied)]
    [InlineData((int)EpochBackupStage.CompleteVerified)]
    [InlineData((int)EpochBackupStage.RedoVerified)]
    [InlineData((int)EpochBackupStage.InventoryFlushed)]
    [InlineData((int)EpochBackupStage.Completed)]
    [InlineData((int)EpochBackupStage.Published)]
    public void Capture_SelectedFailure_FaultsOwnerAndRetainsOldReader(int stage)
    {
        Seed(); var owner = EpochScalarCoordinator.Open(Root); using var old = owner.BeginRead(0); Commit(owner, 1); var before = Bytes(Root);
        try
        {
            Assert.Throws<IOException>(() => owner.CreateBackup(Backup, actual => { if ((int)actual == stage) throw new IOException("injected"); }));
            Assert.Throws<InvalidOperationException>(() => owner.BeginRead()); AssertBytes(before, Root);
        }
        finally { owner.Dispose(); }
        Assert.Equal("old", old.ReadValue(Target(old)));
        if (stage == (int)EpochBackupStage.Published) Assert.Equal(1UL, EpochBackupStorage.ReadArtifact(Backup).CommitSequence);
        else Assert.False(Directory.Exists(Backup));
    }

    /// <summary>Missing/extra/corrupt sealed data is rejected before any clone/runtime file can be created.</summary>
    /// <param name="artifact">Artifact damage.</param>
    [Theory]
    [InlineData("wal")]
    [InlineData("generation")]
    [InlineData("current")]
    [InlineData("extra")]
    [InlineData("empty-directory")]
    [InlineData("case")]
    [InlineData("completion")]
    [InlineData("fragment")]
    public void ReadArtifact_DamagedClosure_FailsReadOnlyWithoutRepair(string artifact)
    {
        Seed(); using (var owner = EpochScalarCoordinator.Open(Root)) { Commit(owner, 1); owner.CreateBackup(Backup); }
        var data = Path.Combine(Backup, "data");
        if (artifact == "wal") File.Delete(Path.Combine(data, ".transactions", "wal", EpochAuthorityCodec.WalFileName(1)));
        if (artifact == "generation") Directory.Delete(EpochScalarHistory.Generation(data, 1), true);
        if (artifact == "current") File.Delete(Path.Combine(data, ".transactions", "CURRENT"));
        if (artifact == "extra") File.WriteAllText(Path.Combine(Backup, "future"), "keep");
        if (artifact == "empty-directory") Directory.CreateDirectory(Path.Combine(data, "extra"));
        if (artifact == "case") File.Move(Path.Combine(data, "BASE"), Path.Combine(data, "base"));
        if (artifact == "completion") File.WriteAllBytes(Path.Combine(Backup, "COMPLETE"), [0]);
        if (artifact == "fragment") File.WriteAllBytes(Path.Combine(data, "fragments", "1.bin"), [0]);
        var before = Bytes(Backup); var directories = Directories(Backup);
        Assert.Throws<InvalidDataException>(() => EpochBackupStorage.ReadArtifact(Backup)); AssertBytes(before, Backup); Assert.Equal(directories, Directories(Backup));
        Assert.False(Directory.Exists(Path.Combine(data, ".epoch"))); Assert.False(Directory.Exists(Path.Combine(data, ".transactions", "readers")));
    }

    /// <summary>A validly resealed incomplete inventory is metadata, not an acceptable backup closure.</summary>
    [Fact]
    public void ReadArtifact_ResealedIncompleteInventory_Rejects()
    {
        Seed(); using (var owner = EpochScalarCoordinator.Open(Root)) { Commit(owner, 1); owner.CreateBackup(Backup); }
        var inventory = EpochBackupStorage.ReadArtifact(Backup); var path = ".transactions/wal/" + EpochAuthorityCodec.WalFileName(1);
        File.Delete(Path.Combine(Backup, "data", path));
        var bytes = EpochBackupCodec.EncodeInventory(inventory with { Files = inventory.Files.Where(file => file.Path != path).ToArray() });
        File.WriteAllBytes(Path.Combine(Backup, "inventory.bin"), bytes); File.WriteAllBytes(Path.Combine(Backup, "COMPLETE"), EpochBackupCodec.Complete(bytes));
        Assert.Throws<InvalidDataException>(() => EpochBackupStorage.ReadArtifact(Backup));
    }

    /// <summary>Native Linux capture validates both oracles while old admission/generation handles remain open.</summary>
    [Fact]
    public void Capture_NativeLinuxStrongPolicy_VerifiesCompleteAndReplayCopies()
    {
        if (!OperatingSystem.IsLinux()) return;
        Seed(); using var owner = EpochScalarCoordinator.Open(Root, new LocalTransactionStorage(DurabilityMode.FileAndDirectoryFlush));
        using var old = owner.BeginRead(0); Commit(owner, 3); owner.CreateBackup(Backup);
        Assert.Equal(3UL, EpochBackupStorage.ReadArtifact(Backup).CommitSequence); Assert.Equal("old", old.ReadValue(Target(old)));
    }

    /// <summary>A capture losing disposal after child admission releases only its operation-owned handles.</summary>
    [Fact]
    public async Task Capture_DisposalAfterAdmission_FailsWithoutOutputOrLeakedHandles()
    {
        var identity = Seed(); var owner = EpochScalarCoordinator.Open(Root); using var admitted = new ManualResetEventSlim(); using var proceed = new ManualResetEventSlim();
        var operation = Task.Run(() => Assert.Throws<ObjectDisposedException>(() => owner.CreateBackup(Backup, admitted: () =>
        { admitted.Set(); if (!proceed.Wait(TimeSpan.FromSeconds(20))) throw new TimeoutException(); })));
        try
        {
            Assert.True(admitted.Wait(TimeSpan.FromSeconds(20))); owner.Dispose();
            Assert.Throws<IOException>(() => EpochAdmission.Acquire(Root, identity, true, EpochProfile.ScalarWal));
            proceed.Set(); await operation; Assert.False(Directory.Exists(Backup));
            using var exclusive = EpochAdmission.Acquire(Root, identity, true, EpochProfile.ScalarWal);
        }
        finally { proceed.Set(); await operation; owner.Dispose(); }
    }

    /// <summary>Commit waits until capture completes, so the sealed H cannot mix old and new data.</summary>
    [Fact]
    public async Task Capture_CommitContends_PublishesPinnedHistoryBeforeAdvancingSource()
    {
        Seed(); using var owner = EpochScalarCoordinator.Open(Root); using var read = owner.BeginRead(); using var transaction = owner.BeginTransaction();
        transaction.ReplaceNodeValue(Target(read), "later"); using var copied = new ManualResetEventSlim(); using var proceed = new ManualResetEventSlim(); using var attempting = new ManualResetEventSlim();
        var capture = Task.Run(() => owner.CreateBackup(Backup, stage => { if (stage == EpochBackupStage.Copied) { copied.Set(); if (!proceed.Wait(TimeSpan.FromSeconds(20))) throw new TimeoutException(); } }));
        Task<ulong>? commit = null;
        try
        {
            Assert.True(copied.Wait(TimeSpan.FromSeconds(20))); commit = Task.Run(() => { attempting.Set(); return transaction.Commit(); });
            Assert.True(attempting.Wait(TimeSpan.FromSeconds(20))); Assert.NotSame(commit, await Task.WhenAny(commit, Task.Delay(100)));
            proceed.Set(); var result = await capture; Assert.Equal(0UL, result.CommitSequence); Assert.Equal(1UL, await commit);
            Assert.Equal(0UL, EpochBackupStorage.ReadArtifact(Backup).CommitSequence); using var current = owner.BeginRead(); Assert.Equal("later", current.ReadValue(Target(current)));
        }
        finally { proceed.Set(); await capture; if (commit is not null) await commit; }
    }

    /// <summary>Validly resealed logical corruption still fails the complete-history oracle without repairing the artifact.</summary>
    [Fact]
    public void VerifyCopies_ResealedWrongLogicalValue_FailsFullHistoryOracle()
    {
        Seed(); using (var owner = EpochScalarCoordinator.Open(Root)) { Commit(owner, 1); owner.CreateBackup(Backup); }
        var inventory = EpochBackupStorage.ReadArtifact(Backup); var data = Path.Combine(Backup, "data");
        var walPath = Path.Combine(data, ".transactions", "wal", EpochAuthorityCodec.WalFileName(1));
        var wal = EpochAuthorityCodec.DecodeWal(File.ReadAllBytes(walPath), inventory.Source);
        File.WriteAllBytes(walPath, EpochAuthorityCodec.EncodeWal(wal with { Value = "forged" })); var digest = SHA256.HashData(File.ReadAllBytes(walPath));
        var witnessPath = Path.Combine(EpochScalarHistory.Generation(data, 1), "GENERATION");
        var witness = EpochAuthorityCodec.DecodeGeneration(File.ReadAllBytes(witnessPath), inventory.Source);
        File.WriteAllBytes(witnessPath, EpochAuthorityCodec.EncodeGeneration(witness with { WalHash = digest }));
        File.WriteAllBytes(Path.Combine(data, ".transactions", "CURRENT"), EpochAuthorityCodec.EncodeCurrent(new(inventory.Source, 1, inventory.HeadManifestHash, digest)));
        var entries = inventory.Files.Select(file => { var bytes = File.ReadAllBytes(Path.Combine(data, file.Path)); return new BackupEntry(file.Path, bytes.Length, SHA256.HashData(bytes)); }).ToArray();
        var bytes = EpochBackupCodec.EncodeInventory(inventory with { Files = entries, HeadWalHash = digest });
        File.WriteAllBytes(Path.Combine(Backup, "inventory.bin"), bytes); File.WriteAllBytes(Path.Combine(Backup, "COMPLETE"), EpochBackupCodec.Complete(bytes));
        var read = EpochBackupStorage.ReadArtifact(Backup); var before = Bytes(Backup); var sourceBefore = Bytes(Root);
        var workspace = EpochBackupStorage.Workspace(Path.Combine(_area, "probe"), new LocalTransactionStorage());
        Assert.Throws<InvalidDataException>(() => EpochBackupStorage.VerifyCopies(data, workspace, read, new LocalTransactionStorage()));
        AssertBytes(before, Backup); AssertBytes(sourceBefore, Root); Assert.False(Directory.Exists(Path.Combine(workspace, "verify-redo")));
    }

    /// <summary>Linked data or output ancestors are refused without crossing the owned source/destination boundary.</summary>
    /// <param name="source">Whether the link is in the source rather than the destination parent.</param>
    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public void Capture_LinkedPaths_Rejects(bool source)
    {
        if (!OperatingSystem.IsLinux()) return;
        Seed(); using var owner = EpochScalarCoordinator.Open(Root);
        var external = Path.Combine(_area, "outside"); Directory.CreateDirectory(external); File.WriteAllText(Path.Combine(external, "keep"), "keep");
        var link = source ? Path.Combine(Root, "linked") : Path.Combine(_area, "linked"); Directory.CreateSymbolicLink(link, external);
        var destination = source ? Backup : Path.Combine(link, "backup");
        Assert.Throws<InvalidDataException>(() => owner.CreateBackup(destination)); Assert.False(Directory.Exists(Path.Combine(external, "backup")));
        Assert.Equal("keep", File.ReadAllText(Path.Combine(external, "keep")));
    }

    /// <summary>Unused but hash-consistent payload bytes pass logical materialization checks yet fail exact deterministic redo.</summary>
    [Fact]
    public void VerifyCopies_NonreproducibleMaterialization_FailsIndependentRedoOracle()
    {
        Seed(); using (var owner = EpochScalarCoordinator.Open(Root)) { Commit(owner, 1); owner.CreateBackup(Backup); }
        var inventory = EpochBackupStorage.ReadArtifact(Backup); var data = Path.Combine(Backup, "data"); var generation = EpochScalarHistory.Generation(data, 1);
        var fragmentPath = Path.Combine(generation, "fragments", "1.bin");
        var payload = BinaryEnvelope.Decode(File.ReadAllBytes(fragmentPath), "BXFG", reader =>
        { reader.ReadUInt64(); reader.ReadUInt64(); reader.ReadByte(); return reader.ReadBytes(reader.ReadInt32()); });
        var fragment = BinaryEnvelope.Encode("BXFG", writer =>
        { writer.Write(1UL); writer.Write(1UL); writer.Write((byte)0); writer.Write(payload.Length + 1); writer.Write(payload); writer.Write((byte)0); });
        File.WriteAllBytes(fragmentPath, fragment);
        var manifestPath = Path.Combine(generation, "documents", "1", "manifest.bin"); var manifest = StoreCodec.ReadManifest(File.ReadAllBytes(manifestPath));
        var changed = StoreCodec.WriteManifest(manifest with { Fragments = manifest.Fragments.Select(entry => entry.Id == 1 ? entry with { Length = entry.Length + 1, Hash = SHA256.HashData(fragment) } : entry).ToArray() });
        File.WriteAllBytes(manifestPath, changed); var head = SHA256.HashData(changed);
        var walPath = Path.Combine(data, ".transactions", "wal", EpochAuthorityCodec.WalFileName(1)); var wal = EpochAuthorityCodec.DecodeWal(File.ReadAllBytes(walPath), inventory.Source);
        File.WriteAllBytes(walPath, EpochAuthorityCodec.EncodeWal(wal with { ManifestHash = head })); var walHash = SHA256.HashData(File.ReadAllBytes(walPath));
        var witnessPath = Path.Combine(generation, "GENERATION"); var witness = EpochAuthorityCodec.DecodeGeneration(File.ReadAllBytes(witnessPath), inventory.Source);
        File.WriteAllBytes(witnessPath, EpochAuthorityCodec.EncodeGeneration(witness with { ManifestHash = head, WalHash = walHash }));
        File.WriteAllBytes(Path.Combine(data, ".transactions", "CURRENT"), EpochAuthorityCodec.EncodeCurrent(new(inventory.Source, 1, head, walHash)));
        var entries = inventory.Files.Select(entry => { var content = File.ReadAllBytes(Path.Combine(data, entry.Path)); return new BackupEntry(entry.Path, content.Length, SHA256.HashData(content)); }).ToArray();
        var bytes = EpochBackupCodec.EncodeInventory(inventory with { Files = entries, HeadManifestHash = head, HeadWalHash = walHash });
        File.WriteAllBytes(Path.Combine(Backup, "inventory.bin"), bytes); File.WriteAllBytes(Path.Combine(Backup, "COMPLETE"), EpochBackupCodec.Complete(bytes));
        var verifiedHeaders = EpochBackupStorage.ReadArtifact(Backup); var before = Bytes(Backup); var source = Bytes(Root);
        var workspace = EpochBackupStorage.Workspace(Path.Combine(_area, "probe"), new LocalTransactionStorage()); var stages = new List<EpochBackupStage>();
        Assert.Throws<InvalidDataException>(() => EpochBackupStorage.VerifyCopies(data, workspace, verifiedHeaders, new LocalTransactionStorage(), stages.Add));
        Assert.Contains(EpochBackupStage.CompleteVerified, stages); Assert.DoesNotContain(EpochBackupStage.RedoVerified, stages);
        AssertBytes(before, Backup); AssertBytes(source, Root);
    }

    private EpochIdentity Seed()
    {
        Directory.CreateDirectory(_area); var source = Path.Combine(_area, "source");
        using var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID><line>line</line></r>"));
        XmlFragmentImporter.Import(input, source, documentUri: "https://example.test/et9b.xml");
        return EpochEmptyRoot.CreateFixture(source, Root, 1, new LocalTransactionStorage());
    }
    private static void Commit(EpochScalarCoordinator owner, int count)
    { for (var index = 0; index < count; index++) { using var read = owner.BeginRead(); using var tx = owner.BeginTransaction(); tx.ReplaceNodeValue(Target(read), "new-" + owner.CommitSequence); tx.Commit(); } }
    private static ulong Target(ImmutableXmlSnapshot snapshot) => Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id))
        .Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();
    private static Dictionary<string, byte[]> Bytes(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories)
        .Where(path => Path.GetFileName(path) != "writer.lock").ToDictionary(path => Path.GetRelativePath(root, path), File.ReadAllBytes);
    private static string[] Directories(string root) => Directory.GetDirectories(root, "*", SearchOption.AllDirectories).Select(path => Path.GetRelativePath(root, path)).Order().ToArray();
    private static void AssertBytes(Dictionary<string, byte[]> expected, string root)
    { var actual = Bytes(root); Assert.Equal(expected.Keys.Order(), actual.Keys.Order()); foreach (var file in expected) Assert.Equal(file.Value, actual[file.Key]); }
    /// <summary>Removes isolated fixture data after handles are released.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
