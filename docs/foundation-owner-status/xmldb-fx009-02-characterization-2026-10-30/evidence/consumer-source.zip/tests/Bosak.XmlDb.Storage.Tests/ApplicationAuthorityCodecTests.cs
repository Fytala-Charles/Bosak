// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Qualifies independent application-authority vectors and bounded canonical decoding.
// SPECIAL NOTES        : Read-only fixture input and in-memory mutations; no host/store roots are opened or repaired.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Buffers.Binary;
using System.Security.Cryptography;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Qualifies independent application-authority vectors and bounded canonical decoding.</summary>
public sealed partial class ApplicationAuthorityCodecTests
{
    private static readonly Guid Owner = Guid.Parse("50617283-94a5-b6c7-d8e9-fa0b1c2d3e4f");
    private static readonly Guid Owner2 = Guid.Parse("60718293-a4b5-c6d7-e8f9-0a1b2c3d4e5f");
    private static readonly Guid Baseline = Guid.Parse("708192a3-b4c5-d6e7-f809-1a2b3c4d5e6f");
    private static readonly Guid WorkId = Guid.Parse("8091a2b3-c4d5-e6f7-0819-2a3b4c5d6e7f");
    private static readonly string Zero = new('0', 64);
    private static string Digest(char value) => new(value, 64);

    /// <summary>Independent metadata uses exact configured IDs, scope, UTF-8 and network-order GUIDs.</summary>
    /// <param name="restore">Whether to use the non-ASCII restore configuration.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Metadata_IndependentVectors_ExactBytes(bool restore)
    {
        var config = Configuration(restore); var bytes = Fixture(restore ? "pilot-authority-meta-utf8-v1.hex" : "pilot-authority-meta-ascii-v1.hex");
        var metadata = ApplicationAuthorityCodec.DecodeMetadata(bytes, config);
        Assert.Equal(bytes, ApplicationAuthorityCodec.EncodeMetadata(config));
        Assert.Equal(config, metadata.Configuration); Assert.True(metadata.WritersMustRemainStopped);
    }

    /// <summary>Independent full histories validate and re-encode exactly while preserving all acceptance obligations.</summary>
    /// <param name="file">Pinned independent vector.</param>
    /// <param name="hash">Pinned SHA-256 of decoded bytes.</param>
    /// <param name="count">Number of frames.</param>
    /// <param name="source">Retained source acceptances.</param>
    /// <param name="candidate">Retained candidate acceptances.</param>
    [Theory]
    [InlineData("enroll", "40fc1d71c82ef75dd4f3b623ba3440aba9eef32e5fa15bfe5f0d37a4fc106d38", 1, 0, 0)]
    [InlineData("legacy-chain", "769fb7f5a9458d94cd89080e5a31ad438355fca372eb061c7cb7ebe110c95e8c", 11, 0, 2)]
    [InlineData("restore-chain", "50a240a487ae0e14ec2d84da152380853ec88dfc7e7179e9dd81b80b383597e5", 9, 2, 0)]
    [InlineData("zero-chain", "1905a3fc11319f89de0c3eab5ec0d33998c81bb486105fdd2836de60a7b96b90", 7, 0, 0)]
    public void DecodeJournal_IndependentHistories_ExactStateAndEncoding(string file, string hash, int count, int source, int candidate)
    {
        var bytes = Fixture("application-authority-" + file + "-v1.hex"); var metadata = Metadata(file == "restore-chain");
        Assert.Equal(hash, Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant());
        var history = ApplicationAuthorityCodec.DecodeJournal(bytes, metadata);
        Assert.Equal(count, history.Frames.Length); Assert.Equal((ulong)source, history.SourceAccepted); Assert.Equal((ulong)candidate, history.CandidateAccepted);
        Assert.True(history.WritersMustRemainStopped); Assert.Equal(7ul, history.Source!.DocumentId);
        Assert.Equal(file == "restore-chain" ? 0ul : file == "zero-chain" ? 10000ul : 3ul, history.Source.InitialSequence);
        Assert.Equal(file == "restore-chain" ? PilotRootKind.ScalarEpoch : PilotRootKind.Legacy, history.Source.Kind);
        if (count > 1)
        {
            Assert.Equal(Root(true, file == "restore-chain", history.Source.InitialSequence), history.Candidate);
            Assert.Equal(Publication(file == "restore-chain"), history.Publication);
        }
        if (history.Work.Length > 0)
        {
            Assert.Equal(WorkId, history.Work[0].Reference.WorkId);
            Assert.Equal(Owner, history.Work[0].AcceptingOwner); Assert.Equal(Owner2, history.Work[1].AcceptingOwner);
            Assert.Equal(file == "restore-chain" ? PilotWorkOutcome.NoEffect : PilotWorkOutcome.Committed, history.Work[0].Outcome);
            Assert.Equal(file == "restore-chain" ? PilotWorkOutcome.Committed : PilotWorkOutcome.NoEffect, history.Work[1].Outcome);
            Assert.Equal(file == "restore-chain" ? PilotBranch.Source : PilotBranch.Candidate, history.Work[0].Branch);
        }
        using var output = new MemoryStream();
        foreach (var frame in history.Frames)
        {
            Assert.True(frame.WritersMustRemainStopped);
            output.Write(ApplicationAuthorityCodec.EncodeFrame(metadata, frame.Sequence, frame.PreviousDigest, frame.Entry));
        }
        Assert.Equal(bytes, output.ToArray());
    }

    /// <summary>Complete valid prefixes and empty logs remain stopped structural observations.</summary>
    [Fact]
    public void DecodeJournal_EmptyOrWholePrefix_NeverGrantsAuthority()
    {
        var empty = ApplicationAuthorityCodec.DecodeJournal([], Metadata());
        Assert.Empty(empty.Frames); Assert.Null(empty.Source); Assert.Equal(0ul, empty.SourceAccepted); Assert.True(empty.WritersMustRemainStopped);
        var enrollment = ApplicationAuthorityCodec.DecodeJournal(Fixture("application-authority-enroll-v1.hex"), Metadata());
        Assert.Single(enrollment.Frames); Assert.Null(enrollment.Candidate); Assert.True(enrollment.WritersMustRemainStopped);
    }

    /// <summary>Metadata rejects foreign configuration and every malformed reserved field.</summary>
    /// <param name="fault">Shape or configuration fault.</param>
    [Theory]
    [InlineData("short")]
    [InlineData("extra")]
    [InlineData("magic")]
    [InlineData("checksum")]
    [InlineData("policy")]
    [InlineData("flags")]
    [InlineData("reserved")]
    [InlineData("empty-authority")]
    [InlineData("empty-admin")]
    [InlineData("foreign-authority")]
    [InlineData("foreign-admin")]
    [InlineData("deployment")]
    [InlineData("resource")]
    [InlineData("admin-root")]
    [InlineData("authority-root")]
    [InlineData("mixed-guid")]
    public void DecodeMetadata_InvalidOrForeign_Rejects(string fault)
    {
        var config = Configuration(); var bytes = ApplicationAuthorityCodec.EncodeMetadata(config);
        switch (fault)
        {
            case "short": bytes = bytes[..111]; break;
            case "extra": bytes = [.. bytes, 0]; break;
            case "magic": bytes[0] ^= 1; break;
            case "checksum": bytes[111] ^= 1; break;
            case "policy": bytes[72] = 2; break;
            case "flags": bytes[74] = 1; break;
            case "reserved": bytes[79] = 1; break;
            case "empty-authority": Array.Clear(bytes, 8, 16); break;
            case "empty-admin": Array.Clear(bytes, 24, 16); break;
            case "foreign-authority": config = config with { AuthorityId = Owner }; break;
            case "foreign-admin": config = config with { AdministrativeJournalId = Owner }; break;
            case "deployment": config = config with { Deployment = "other" }; break;
            case "resource": config = config with { ResourceScope = "other" }; break;
            case "admin-root": config = config with { AdministrativeRootKey = "other" }; break;
            case "authority-root": config = config with { AuthorityRootKey = "other" }; break;
            case "mixed-guid": config.AuthorityId.ToByteArray().CopyTo(bytes, 8); break;
        }
        if (bytes.Length == 112 && fault != "checksum") SHA256.HashData(bytes.AsSpan(0, 80), bytes.AsSpan(80));
        Assert.Throws<InvalidDataException>(() => ApplicationAuthorityCodec.DecodeMetadata(bytes, config));
    }

    /// <summary>Even malformed typed encoder inputs cannot bypass strict canonical shapes.</summary>
    /// <param name="fault">Invalid typed input.</param>
    [Theory]
    [InlineData("null-config")]
    [InlineData("empty-id")]
    [InlineData("strong-policy")]
    [InlineData("nul")]
    [InlineData("bom")]
    [InlineData("surrogate")]
    [InlineData("whitespace")]
    [InlineData("utf8-limit")]
    [InlineData("forged-scope")]
    [InlineData("forged-digest")]
    [InlineData("epoch-document")]
    [InlineData("fake-legacy-epoch")]
    [InlineData("unknown-event")]
    public void Encode_InvalidTypedInput_Rejects(string fault)
    {
        var config = Configuration(); var metadata = Metadata();
        Assert.Throws<InvalidDataException>(() =>
        {
            switch (fault)
            {
                case "null-config": ApplicationAuthorityCodec.EncodeMetadata(null!); break;
                case "empty-id": ApplicationAuthorityCodec.EncodeMetadata(config with { AuthorityId = Guid.Empty }); break;
                case "strong-policy": ApplicationAuthorityCodec.EncodeMetadata(config with { Durability = DurabilityMode.FileAndDirectoryFlush }); break;
                case "nul": ApplicationAuthorityCodec.EncodeMetadata(config with { Deployment = "a\0b" }); break;
                case "bom": ApplicationAuthorityCodec.EncodeMetadata(config with { Deployment = "\uFEFFa" }); break;
                case "surrogate": ApplicationAuthorityCodec.EncodeMetadata(config with { Deployment = "\uD800" }); break;
                case "whitespace": ApplicationAuthorityCodec.EncodeMetadata(config with { Deployment = " " }); break;
                case "utf8-limit": ApplicationAuthorityCodec.EncodeMetadata(config with { Deployment = new string('\u00E9', 2049) }); break;
                case "forged-scope": ApplicationAuthorityCodec.DecodeJournal([], metadata with { ScopeDigest = Zero }); break;
                case "forged-digest": ApplicationAuthorityCodec.DecodeJournal([], metadata with { Digest = Zero }); break;
                case "epoch-document": ApplicationAuthorityCodec.RootDigest(Root(true) with { Epoch = Root(true).Epoch! with { DocumentId = 9 } }); break;
                case "fake-legacy-epoch": ApplicationAuthorityCodec.RootDigest(Root(false) with { Epoch = Root(true).Epoch }); break;
                case "unknown-event": ApplicationAuthorityCodec.EncodeFrame(metadata, 1, Zero, Entry(null!)); break;
            }
        });
    }

    /// <summary>Exact UTF-8 byte bounds accept multi-byte keys without character-count substitution.</summary>
    [Fact]
    public void Metadata_Utf8ByteBoundary_ExactRoundTrip()
    {
        var config = Configuration() with { ResourceScope = new string('\u00E9', 2048) };
        var bytes = ApplicationAuthorityCodec.EncodeMetadata(config);
        Assert.Equal(config, ApplicationAuthorityCodec.DecodeMetadata(bytes, config).Configuration);
    }

    /// <summary>Every incomplete tail position fails rather than returning an adopted enrollment prefix.</summary>
    [Fact]
    public void DecodeJournal_EveryTruncatedFrame_RejectsWithoutPrefix()
    {
        var bytes = Fixture("application-authority-enroll-v1.hex");
        for (var length = 1; length < bytes.Length; length++)
            Assert.Throws<InvalidDataException>(() => ApplicationAuthorityCodec.DecodeJournal(bytes[..length], Metadata()));
        var history = Fixture("application-authority-legacy-chain-v1.hex");
        Assert.Throws<InvalidDataException>(() => ApplicationAuthorityCodec.DecodeJournal(history[..^1], Metadata()));
        Assert.Throws<InvalidDataException>(() => ApplicationAuthorityCodec.DecodeJournal([.. bytes, 1], Metadata()));
    }

    /// <summary>Non-seekable short reads leave the caller's stream open and preserve complete state.</summary>
    /// <param name="chunk">Maximum bytes returned by each read.</param>
    [Theory]
    [InlineData(1)]
    [InlineData(3)]
    [InlineData(64)]
    public void ReadJournal_ShortNonseekableInput_CallerRetainsStream(int chunk)
    {
        var bytes = Fixture("application-authority-legacy-chain-v1.hex"); using var input = new ShortInput(bytes, chunk);
        var history = ApplicationAuthorityCodec.ReadJournal(input, Metadata());
        Assert.Equal(11, history.Frames.Length); Assert.Equal(2ul, history.CandidateAccepted);
        Assert.False(input.Disposed); Assert.Equal(bytes.Length, input.BytesRead); Assert.True(history.WritersMustRemainStopped);
    }

    /// <summary>Oversized declarations reject after the header, before reading or allocating declared payloads.</summary>
    /// <param name="declared">Unsupported payload size.</param>
    [Theory]
    [InlineData(0u)]
    [InlineData(65537u)]
    [InlineData(uint.MaxValue)]
    public void ReadJournal_UnsupportedDeclaredPayload_StopsAtHeader(uint declared)
    {
        var bytes = Fixture("application-authority-enroll-v1.hex")[..104];
        BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(12), declared);
        using var input = new ShortInput(bytes, 1);
        Assert.Throws<InvalidDataException>(() => ApplicationAuthorityCodec.ReadJournal(input, Metadata()));
        Assert.Equal(104, input.BytesRead); Assert.False(input.Disposed);
    }

    private static ApplicationAuthorityConfiguration Configuration(bool restore = false) => restore
        ? new(Guid.Parse("30415263-7485-96a7-b8c9-daebfc0d1e2f"), Guid.Parse("40516273-8495-a6b7-c8d9-eafb0c1d2e3f"), "pilote", "r\u00E9serve", "administration", "application")
        : new(Guid.Parse("10213243-5465-7687-98a9-bacbdcedfe0f"), Guid.Parse("20314253-6475-8697-a8b9-cadbecfd0e1f"), "embedded-pilot", "orders", "admin-root", "application-root");
    private static ApplicationAuthorityMetadata Metadata(bool restore = false)
    {
        var config = Configuration(restore); return ApplicationAuthorityCodec.DecodeMetadata(ApplicationAuthorityCodec.EncodeMetadata(config), config);
    }
    private static byte[] Fixture(string name) => Convert.FromHexString(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "TestData", name)).Trim());
    private static PilotRootBinding Root(bool candidate, bool restore = false, ulong head = 3) => new(candidate || restore ? PilotRootKind.ScalarEpoch : PilotRootKind.Legacy,
        candidate ? "candidate-root" : "source-root", candidate ? "candidate-admission" : "source-admission", 7,
        candidate ? new(Guid.Parse("e0f10213-2435-4657-6879-8a9b0c1d2e3f"), Guid.Parse("f0011223-3445-5667-7889-9a0b1c2d3e4f"), 7) :
        restore ? new(Guid.Parse("c0d1e2f3-0415-2637-4859-6a7b8c9d0e1f"), Guid.Parse("d0e1f203-1425-3647-5869-7a8b9c0d1e2f"), 7) : null,
        head, Digest(candidate ? 'b' : 'a'));
    private static ApplicationAuthorityPublication Publication(bool restore = false) => new(restore ? EpochPublicationKind.IndependentEpochRestore : EpochPublicationKind.LegacyMigration,
        Guid.Parse("a0b1c2d3-e4f5-0617-2839-4a5b6c7d8e9f"), Digest('d'), 4, Digest('f'), "artifact-root", "bundle-root", Guid.Parse("b0c1d2e3-f405-1627-3849-5a6b7c8d9e0f"));
    private static ApplicationAuthorityEntry Entry(ApplicationAuthorityData data) => new(Owner, 1, Baseline, 1, PilotBranch.Source, Digest('e'), data);
    private static List<ApplicationAuthorityEntry> Basic(bool restore = false) => [Entry(new ApplicationEnroll(Root(false, restore))), Entry(new ApplicationRegister(Root(true, restore), Publication(restore)))];
    private static ApplicationAccept Accept(Guid? id = null) => new(id ?? WorkId, Digest('c'), ApplicationAuthorityCodec.RootDigest(Root(false)));
    private static ApplicationWorkReference Reference(ulong sequence = 3) => new(WorkId, Digest('c'), sequence);
    private static byte[] Journal(IEnumerable<ApplicationAuthorityEntry> entries, ApplicationAuthorityMetadata? metadata = null)
    {
        metadata ??= Metadata(); using var output = new MemoryStream(); ulong sequence = 0; var previous = Zero;
        foreach (var entry in entries)
        {
            var bytes = ApplicationAuthorityCodec.EncodeFrame(metadata, ++sequence, previous, entry); output.Write(bytes);
            previous = Convert.ToHexString(bytes.AsSpan(bytes.Length - 40, 32)).ToLowerInvariant();
        }
        return output.ToArray();
    }

    private sealed class ShortInput(byte[] bytes, int chunk) : Stream
    {
        internal int BytesRead { get; private set; }
        internal bool Disposed { get; private set; }
        public override bool CanRead => !Disposed;
        public override bool CanSeek => false;
        public override bool CanWrite => false;
        public override long Length => throw new NotSupportedException();
        public override long Position { get => throw new NotSupportedException(); set => throw new NotSupportedException(); }
        public override int Read(byte[] buffer, int offset, int count) => Read(buffer.AsSpan(offset, count));
        public override int Read(Span<byte> buffer)
        {
            var n = Math.Min(Math.Min(buffer.Length, chunk), bytes.Length - BytesRead);
            bytes.AsSpan(BytesRead, n).CopyTo(buffer); BytesRead += n; return n;
        }
        public override void Flush() => throw new NotSupportedException();
        public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException();
        public override void SetLength(long value) => throw new NotSupportedException();
        public override void Write(byte[] buffer, int offset, int count) => throw new NotSupportedException();
        protected override void Dispose(bool disposing) { Disposed = true; base.Dispose(disposing); }
    }
}
