// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies exact epoch profiles and bounded authority bytes with independent fixtures.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 27-10-2026     | Parse explicit profiles without widening immutable entry points
// ===========================================================================================================================================================

using System.Buffers.Binary;
using System.Security.Cryptography;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Verifies exact epoch profiles and bounded authority bytes with independent fixtures.</summary>
public sealed class EpochAuthorityTests
{
    private static EpochIdentity Identity => new(new Guid("00112233-4455-6677-8899-aabbccddeeff"), new Guid("10213243-5465-7687-98a9-bacbdcedfe0f"), 1);
    private static byte[] BaseHash => Enumerable.Range(1, 32).Select(value => (byte)value).ToArray();
    private static byte[] HeadHash => Enumerable.Range(33, 32).Select(value => (byte)value).ToArray();
    private static EpochAuthorityBinding Binding => EpochAuthorityBinding.Create(EpochCodec.EncodeProfile(Identity, EpochProfile.ScalarWal), BaseHash);
    private static EpochWalRecord Wal(EpochAuthorityBinding binding) => new(binding, 1, new Guid("20314253-6475-8697-a8b9-cadbecfd0e1f"), 3, "new", BaseHash, HeadHash, new byte[32]);

    /// <summary>Parsing both profiles does not widen default immutable entry-point admission; all existing bytes remain exact.</summary>
    [Fact]
    public void Profile_ExplicitTuple_SeparatesParsingFromCapability()
    {
        var mutable = EpochCodec.EncodeProfile(Identity, EpochProfile.ScalarWal);
        Assert.Equal(Hex("epoch-mutable-format-v2.hex"), mutable);
        Assert.Equal(Hex("epoch-format-v2.hex"), EpochCodec.EncodeFormat(Identity));
        Assert.Equal(EpochProfile.ScalarWal, EpochCodec.DecodeProfile(mutable).Profile);
        Assert.Equal(Identity, EpochCodec.RequireProfile(mutable, EpochProfile.ScalarWal).Identity);
        Assert.Throws<InvalidDataException>(() => EpochCodec.DecodeFormat(mutable));
        Assert.Throws<InvalidDataException>(() => EpochCodec.RequireProfile(EpochCodec.EncodeFormat(Identity), EpochProfile.ScalarWal));
        Assert.Throws<InvalidDataException>(() => EpochAuthorityBinding.Create(EpochCodec.EncodeFormat(Identity), BaseHash));
        for (var length = 0; length < mutable.Length; length++) Assert.Throws<InvalidDataException>(() => EpochCodec.DecodeProfile(mutable[..length]));
    }

    /// <summary>Unsupported or mixed tuples fail even with correct checksums.</summary>
    /// <param name="offset">Descriptor field to alter.</param>
    [Theory]
    [InlineData(4)]
    [InlineData(6)]
    [InlineData(12)]
    [InlineData(53)]
    [InlineData(55)]
    [InlineData(57)]
    [InlineData(59)]
    public void Profile_ResealedUnknownFields_Rejects(int offset)
    {
        var bytes = EpochCodec.EncodeProfile(Identity, EpochProfile.ScalarWal); bytes[offset]++;
        Seal(bytes); Assert.Throws<InvalidDataException>(() => EpochCodec.DecodeProfile(bytes));
    }

    /// <summary>Each record matches independent Python bytes, roundtrips all fields, rejects all truncations and role/version substitutions.</summary>
    /// <param name="role">Authority role.</param>
    [Theory]
    [InlineData("base")]
    [InlineData("control")]
    [InlineData("current")]
    [InlineData("wal")]
    [InlineData("generation")]
    [InlineData("reader")]
    public void Authority_GoldenBytes_RejectsFramingAndRoleCorruption(string role)
    {
        var expected = Hex("epoch-" + role + "-v1.hex"); var bytes = Encode(Role(role, Binding));
        Assert.Equal(expected, bytes); Assert.Equal(expected, Encode(Decode(role, bytes, Binding)));
        for (var length = 0; length < bytes.Length; length++) Assert.Throws<InvalidDataException>(() => Decode(role, bytes[..length], Binding));
        var wrongRole = (byte[])bytes.Clone(); wrongRole[116] = 255; Seal(wrongRole);
        Assert.Throws<InvalidDataException>(() => Decode(role, wrongRole, Binding));
        var wrongVersion = (byte[])bytes.Clone(); wrongVersion[4] = 2; Seal(wrongVersion);
        Assert.Throws<InvalidDataException>(() => Decode(role, wrongVersion, Binding));
        var bad = (byte[])bytes.Clone(); bad[^1] ^= 1;
        Assert.Throws<InvalidDataException>(() => Decode(role, bad, Binding));
        Assert.Throws<InvalidDataException>(() => Decode(role, bytes.Concat(new byte[] { 0 }).ToArray(), Binding));
        foreach (var other in new[] { "base", "control", "current", "wal", "generation", "reader" }.Where(other => other != role))
            Assert.Throws<InvalidDataException>(() => Decode(other, bytes, Binding));
    }

    /// <summary>Expected root bindings reject foreign store, epoch, document, profile and base without reading an authority as another root.</summary>
    /// <param name="role">Authority role.</param>
    [Theory]
    [InlineData("base")]
    [InlineData("control")]
    [InlineData("current")]
    [InlineData("wal")]
    [InlineData("generation")]
    [InlineData("reader")]
    public void Authority_ForeignBinding_Rejects(string role)
    {
        var binding = Binding; var bytes = Encode(Role(role, binding));
        foreach (var wrong in new[]
        {
            binding with { Identity = Identity with { StoreId = Guid.NewGuid() } },
            binding with { Identity = Identity with { EpochId = Guid.NewGuid() } },
            binding with { Identity = Identity with { DocumentId = 2 } },
            binding with { FormatHash = new byte[32] }, binding with { BaseHash = new byte[32] },
        }) Assert.Throws<InvalidDataException>(() => Decode(role, bytes, wrong));
    }

    /// <summary>Scalar/body bounds are checked on encoding and on rechecksummed decoding, without treating records as mutable authority.</summary>
    [Fact]
    public void Authority_InvalidBodiesAndXml_RejectsBoundedly()
    {
        var binding = Binding; var wal = Wal(binding);
        foreach (var invalid in new[] { wal with { Sequence = 0 }, wal with { Sequence = 10_001 }, wal with { TransactionId = Guid.Empty },
            wal with { NodeId = 0 }, wal with { NodeId = 1_000_001 }, wal with { PreviousManifestHash = new byte[32] }, wal with { PreviousWalHash = HeadHash },
            wal with { ManifestHash = new byte[31] }, wal with { Value = "\0" }, wal with { Value = "\ud800" }, wal with { Value = new string('x', 1_048_577) } })
            Assert.Throws<InvalidDataException>(() => EpochAuthorityCodec.EncodeWal(invalid));
        var empty = EpochAuthorityCodec.DecodeWal(EpochAuthorityCodec.EncodeWal(wal with { Value = "" }), binding);
        Assert.Equal("", empty.Value); // Empty attributes are possible; node-kind semantics belong to future materialization validation.
        Assert.Throws<InvalidDataException>(() => EpochAuthorityCodec.EncodeControl(new(binding, new byte[32])));
        Assert.Throws<InvalidDataException>(() => EpochAuthorityCodec.EncodeCurrent(new(binding, 0, HeadHash, new byte[32])));
        Assert.Throws<InvalidDataException>(() => EpochAuthorityCodec.EncodeCurrent(new(binding, 1, HeadHash, new byte[32])));
        Assert.Throws<InvalidDataException>(() => EpochAuthorityCodec.EncodeGeneration(new(binding, 1, BaseHash, HeadHash, new byte[32])));
        Assert.Throws<InvalidDataException>(() => EpochAuthorityCodec.EncodeReader(new(binding, 0, HeadHash)));
        var root = new EpochCurrentRecord(binding, 0, BaseHash, new byte[32]);
        Assert.Equal(0UL, EpochAuthorityCodec.DecodeCurrent(EpochAuthorityCodec.EncodeCurrent(root), binding).Sequence);
        Assert.Equal(0UL, EpochAuthorityCodec.DecodeReader(EpochAuthorityCodec.EncodeReader(new(binding, 0, BaseHash)), binding).Sequence);
        foreach (var item in new[] { (Role: "base", Offset: 117), (Role: "control", Offset: 157), (Role: "wal", Offset: 153), (Role: "generation", Offset: 117), (Role: "reader", Offset: 117) })
        {
            var bytes = Encode(Role(item.Role, binding));
            if (item.Offset == 117) BinaryPrimitives.WriteUInt64LittleEndian(bytes.AsSpan(117), 10_001);
            else bytes[item.Offset] = 255;
            Seal(bytes);
            Assert.Throws<InvalidDataException>(() => Decode(item.Role, bytes, binding));
        }
        var badLength = EpochAuthorityCodec.EncodeWal(wal); BinaryPrimitives.WriteInt32LittleEndian(badLength.AsSpan(149), int.MaxValue); Seal(badLength);
        Assert.Throws<InvalidDataException>(() => EpochAuthorityCodec.DecodeWal(badLength, binding));
        var badTx = EpochAuthorityCodec.EncodeWal(wal); badTx.AsSpan(125, 16).Clear(); Seal(badTx);
        Assert.Throws<InvalidDataException>(() => EpochAuthorityCodec.DecodeWal(badTx, binding));
    }

    /// <summary>Only exact bounded numeric names are accepted, preventing paths, case aliases and ambiguous zero generations.</summary>
    /// <param name="name">Invalid WAL file name.</param>
    [Theory]
    [InlineData("../00000000000000000001.wal")]
    [InlineData("00000000000000000001.WAL")]
    [InlineData("1.wal")]
    [InlineData("00000000000000000000.wal")]
    [InlineData("00000000000000010001.wal")]
    [InlineData("+0000000000000000001.wal")]
    [InlineData("00000000000000000001.wal/extra")]
    public void Paths_NoncanonicalOrOutOfBounds_Rejects(string name) => Assert.Throws<InvalidDataException>(() => EpochAuthorityCodec.ParseWalName(name));

    /// <summary>Canonical names roundtrip, reader zero is distinct, and out-of-range names cannot be emitted.</summary>
    [Fact]
    public void Paths_CanonicalBounds_Roundtrip()
    {
        Assert.Equal(1UL, EpochAuthorityCodec.ParseWalName(EpochAuthorityCodec.WalFileName(1)));
        Assert.Equal(10_000UL, EpochAuthorityCodec.ParseGenerationName(EpochAuthorityCodec.GenerationName(10_000)));
        Assert.Equal(0UL, EpochAuthorityCodec.ParseReaderName(EpochAuthorityCodec.ReaderFileName(0)));
        Assert.Throws<InvalidDataException>(() => EpochAuthorityCodec.WalFileName(0));
        Assert.Throws<InvalidDataException>(() => EpochAuthorityCodec.ReaderFileName(10_001));
        Assert.Throws<InvalidDataException>(() => EpochAuthorityCodec.ParseGenerationName("00000000000000000001/.."));
        Assert.Throws<InvalidDataException>(() => EpochAuthorityCodec.ParseReaderName("00000000000000000000.LEASE"));
    }

    private static object Role(string role, EpochAuthorityBinding binding)
    {
        var walHash = SHA256.HashData(EpochAuthorityCodec.EncodeWal(Wal(binding)));
        return role switch
        {
            "base" => new EpochBaseRecord(binding),
            "control" => EpochAuthorityCodec.CreateControl(binding),
            "current" => new EpochCurrentRecord(binding, 1, HeadHash, walHash),
            "wal" => Wal(binding),
            "generation" => new EpochGenerationRecord(binding, 1, BaseHash, HeadHash, walHash),
            "reader" => new EpochReaderRecord(binding, 1, HeadHash),
            _ => throw new ArgumentException("Unknown role.", nameof(role)),
        };
    }
    private static byte[] Encode(object value) => value switch
    {
        EpochBaseRecord record => EpochAuthorityCodec.EncodeBase(record),
        EpochControlRecord record => EpochAuthorityCodec.EncodeControl(record),
        EpochCurrentRecord record => EpochAuthorityCodec.EncodeCurrent(record),
        EpochWalRecord record => EpochAuthorityCodec.EncodeWal(record),
        EpochGenerationRecord record => EpochAuthorityCodec.EncodeGeneration(record),
        EpochReaderRecord record => EpochAuthorityCodec.EncodeReader(record),
        _ => throw new ArgumentException("Unknown record.", nameof(value)),
    };
    private static object Decode(string role, byte[] bytes, EpochAuthorityBinding expected) => role switch
    {
        "base" => EpochAuthorityCodec.DecodeBase(bytes, expected),
        "control" => EpochAuthorityCodec.DecodeControl(bytes, expected),
        "current" => EpochAuthorityCodec.DecodeCurrent(bytes, expected),
        "wal" => EpochAuthorityCodec.DecodeWal(bytes, expected),
        "generation" => EpochAuthorityCodec.DecodeGeneration(bytes, expected),
        "reader" => EpochAuthorityCodec.DecodeReader(bytes, expected),
        _ => throw new ArgumentException("Unknown role.", nameof(role)),
    };
    private static void Seal(byte[] bytes) => SHA256.HashData(bytes.AsSpan(0, bytes.Length - 32), bytes.AsSpan(bytes.Length - 32));
    private static byte[] Hex(string name) => Convert.FromHexString(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "TestData", name)).Trim());
}
