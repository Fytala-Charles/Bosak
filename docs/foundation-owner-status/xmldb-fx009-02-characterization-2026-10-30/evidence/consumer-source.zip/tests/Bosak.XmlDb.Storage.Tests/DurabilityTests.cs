// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Verifies explicit durability selection and ordered directory barriers.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Text;
using Bosak.XmlDb.Core;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Verifies explicit durability selection and ordered directory barriers.</summary>
public sealed class DurabilityTests : IDisposable
{
    private readonly string _root = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-durability-" + Guid.NewGuid().ToString("N"));

    /// <summary>Reports the default process-crash mode explicitly.</summary>
    [Fact]
    public void Open_DefaultPolicy_ReportsProcessCrash()
    {
        Import();
        using var database = EmbeddedXmlDatabase.Open(_root);
        Assert.Equal(DurabilityMode.ProcessCrash, database.Durability);
    }

    /// <summary>Rejects unknown modes before any adoption files are created.</summary>
    [Fact]
    public void Open_InvalidPolicy_RejectsWithoutMutation()
    {
        Import();
        Assert.Throws<ArgumentOutOfRangeException>(() => EmbeddedXmlDatabase.Open(_root, durability: (DurabilityMode)99));
        Assert.False(Directory.Exists(Path.Combine(_root, ".transactions")));
        using var snapshot = ImmutableXmlSnapshot.Open(_root);
        Assert.Equal(0UL, snapshot.CommitSequence);
    }

    /// <summary>Never silently falls back when explicit directory barriers are unavailable.</summary>
    [Fact]
    public void Open_DirectoryPolicy_IsExplicitOrRejectedBeforeAdoption()
    {
        Import();
        if (!OperatingSystem.IsLinux())
        {
            Assert.Throws<PlatformNotSupportedException>(() => EmbeddedXmlDatabase.Open(_root, durability: DurabilityMode.FileAndDirectoryFlush));
            Assert.False(Directory.Exists(Path.Combine(_root, ".transactions")));
            using var snapshot = ImmutableXmlSnapshot.Open(_root);
            Assert.Equal(0UL, snapshot.CommitSequence);
            return;
        }
        // Runs against actual directory fsync only when this test is executed on Linux.
        using (var database = EmbeddedXmlDatabase.Open(_root, durability: DurabilityMode.FileAndDirectoryFlush))
        {
            Assert.Equal(DurabilityMode.FileAndDirectoryFlush, database.Durability);
            Commit(database);
        }
        using var reopened = EmbeddedXmlDatabase.Open(_root, durability: DurabilityMode.FileAndDirectoryFlush);
        using var read = reopened.BeginRead();
        Assert.Equal(1UL, read.CommitSequence);
        Assert.Equal("new", read.ReadValue(Target(read)));
    }

    /// <summary>Requires a directory capability probe before sidecar creation.</summary>
    [Fact]
    public void Open_DirectoryPreflightFailure_DoesNotAdoptOrFallBack()
    {
        Import();
        var storage = new FaultingTransactionStorage(DurabilityMode.FileAndDirectoryFlush);
        storage.Arm(0);
        Assert.Throws<IOException>(() => EmbeddedXmlDatabase.OpenCore(_root, 1, null, storage));
        Assert.True(storage.Fired);
        Assert.False(Directory.Exists(Path.Combine(_root, ".transactions")));
        using var database = EmbeddedXmlDatabase.Open(_root);
        Assert.Equal(DurabilityMode.ProcessCrash, database.Durability);
    }

    /// <summary>Checks that all persistence dependencies precede acknowledgment without changing binary encoding.</summary>
    [Fact]
    public void Commit_BarrierOrdering_FlushesContentAndNamespaceBeforePublication()
    {
        Import();
        var storage = new FaultingTransactionStorage(DurabilityMode.FileAndDirectoryFlush);
        storage.Arm();
        using var database = EmbeddedXmlDatabase.OpenCore(_root, 1, null, storage);
        var controlMove = Find("MoveFile", path => Path.GetFileName(path) == "CONTROL");
        var format = Path.Combine(_root, "FORMAT");
        Assert.True(Find("SyncFile", path => path == format) < controlMove);
        var rootSync = storage.Calls.FindLastIndex(controlMove, call => call.Operation == "SyncDirectory" && call.Path == _root && call.Moment == "after");
        Assert.True(rootSync >= 0);
        storage.Arm();
        Commit(database);
        var walPath = Path.Combine(_root, ".transactions", "wal", "00000000000000000001.wal");
        var walFlush = Find("FlushFile", path => path == walPath);
        var walClose = Find("CloseFile", path => path == walPath);
        var walDirectory = Path.GetDirectoryName(walPath)!;
        var walBarrier = FindAfter("SyncDirectory", path => path == walDirectory, walClose);
        var generationMove = Find("MoveDirectory", _ => true);
        Assert.True(walFlush < walClose && walClose < walBarrier && walBarrier < generationMove);
        Assert.True(storage.Calls.Where(call => call.Operation == "FlushFile" && call.Moment == "after" &&
            call.Path.Contains(Path.DirectorySeparatorChar + "staging" + Path.DirectorySeparatorChar, StringComparison.Ordinal))
            .All(call => storage.Calls.IndexOf(call) < walFlush));
        var generations = Path.Combine(_root, ".transactions", "generations");
        var generationBarrier = FindAfter("SyncDirectory", path => path == generations, generationMove);
        var rootMove = Find("MoveFile", path => Path.GetFileName(path) == "CURRENT");
        Assert.True(generationBarrier < rootMove);
        var sidecar = Path.Combine(_root, ".transactions");
        var finalBarrier = FindAfter("SyncDirectory", path => path == sidecar, rootMove);
        Assert.True(finalBarrier == storage.Calls.Count - 1);
        Assert.Equal(1UL, database.CommitSequence);

        int Find(string operation, Func<string, bool> path) => FindAfter(operation, path, -1);
        int FindAfter(string operation, Func<string, bool> path, int after)
        {
            var index = storage.Calls.FindIndex(after + 1, call => call.Operation == operation && call.Moment == "after" && path(call.Path));
            Assert.True(index > after, $"Missing ordered {operation}");
            return index;
        }
    }

    private void Import()
    {
        using var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"));
        XmlFragmentImporter.Import(input, _root);
    }

    private static ulong Target(ImmutableXmlSnapshot snapshot) => Enumerable.Range(1, snapshot.NodeCount)
        .Select(id => snapshot.GetNode((ulong)id)).Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();

    private static void Commit(EmbeddedXmlDatabase database)
    {
        using var read = database.BeginRead();
        using var transaction = database.BeginWrite();
        transaction.ReplaceNodeValue(Target(read), "new");
        Assert.Equal(1UL, transaction.Commit());
    }

    /// <inheritdoc />
    public void Dispose()
    {
        if (Directory.Exists(_root)) Directory.Delete(_root, true);
    }
}
