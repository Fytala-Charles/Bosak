// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Verifies generation leases survive coordinator disposal and preserve lazy readers.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Text;
using Bosak.XmlDb.Core;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Verifies generation leases survive coordinator disposal and preserve lazy readers.</summary>
public sealed class GenerationLeaseTests : IDisposable
{
    private readonly string _root = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-reader-" + Guid.NewGuid().ToString("N"));

    /// <summary>Shared reader and transaction leases block exclusive ownership until their own disposal.</summary>
    [Fact]
    public void Snapshot_OwnerDisposed_StaysPinnedAcrossLaterCoordinatorAndCommit()
    {
        Seed();
        var database = EmbeddedXmlDatabase.Open(_root);
        using (var read = database.BeginRead())
        using (var write = database.BeginWrite()) { write.ReplaceNodeValue(Target(read), "v1"); write.Commit(); }
        var first = database.BeginRead(cacheBytes: 0);
        var second = database.BeginRead(cacheBytes: 0);
        var pending = database.BeginWrite();
        var id = Target(first);
        var sidecar = Path.Combine(_root, ".transactions");
        Assert.Throws<IOException>(() => GenerationLease.OpenExclusive(sidecar, 1, 1));
        database.Dispose();
        using (var next = EmbeddedXmlDatabase.Open(_root))
        {
            using var read = next.BeginRead();
            using var write = next.BeginWrite();
            write.ReplaceNodeValue(Target(read), "v2");
            write.Commit();
            next.CreateCheckpoint();
        }
        Assert.Equal("v1", first.ReadValue(id));
        Assert.Equal("v1", second.ReadValue(id));
        first.Dispose();
        Assert.Throws<IOException>(() => GenerationLease.OpenExclusive(sidecar, 1, 1));
        second.Dispose();
        Assert.Throws<IOException>(() => GenerationLease.OpenExclusive(sidecar, 1, 1));
        pending.Dispose();
        using var exclusive = GenerationLease.OpenExclusive(sidecar, 1, 1);
        Assert.True(exclusive.CanWrite);
    }

    /// <summary>Invalid cache arguments do not create leases or fault the coordinator.</summary>
    [Fact]
    public void BeginRead_InvalidCache_DoesNotAdoptLeaseOrPoisonOwner()
    {
        Seed();
        using var database = EmbeddedXmlDatabase.Open(_root);
        Assert.Throws<ArgumentOutOfRangeException>(() => database.BeginRead(-1));
        Assert.False(Directory.Exists(Path.Combine(_root, ".transactions", "readers")));
        using var read = database.BeginRead();
        Assert.Equal("old", read.ReadValue(Target(read)));
    }

    /// <summary>Corrupt stable lock identities fail closed and are never replaced while readers may exist.</summary>
    [Fact]
    public void Lease_CorruptIdentity_IsNotReplaced()
    {
        Seed();
        using var database = EmbeddedXmlDatabase.Open(_root);
        using (database.BeginRead()) { }
        var path = GenerationLease.PathFor(Path.Combine(_root, ".transactions"), 0);
        var bytes = File.ReadAllBytes(path);
        bytes[^1] ^= 1;
        File.WriteAllBytes(path, bytes);
        Assert.Throws<InvalidDataException>(() => database.BeginRead());
        Assert.Throws<InvalidOperationException>(() => database.BeginWrite());
        Assert.Equal(bytes, File.ReadAllBytes(path));
    }

    /// <summary>Native stronger-mode synchronization skips live stable lock files while preserving their handles.</summary>
    [Fact]
    public void StrongerAdoption_LiveReaders_DoesNotOpenLeaseFilesForWriting()
    {
        Seed();
        ImmutableXmlSnapshot snapshot;
        using (var database = EmbeddedXmlDatabase.Open(_root)) snapshot = database.BeginRead(cacheBytes: 0);
        using (snapshot)
        {
            // Windows models directory barriers; on Linux use the real stronger policy as well.
            using var database = OperatingSystem.IsLinux()
                ? EmbeddedXmlDatabase.Open(_root, DurabilityMode.FileAndDirectoryFlush)
                : EmbeddedXmlDatabase.OpenCore(_root, 1, null, new FaultingTransactionStorage(DurabilityMode.FileAndDirectoryFlush));
            Assert.Equal("old", snapshot.ReadValue(Target(snapshot)));
            Assert.Throws<IOException>(() => GenerationLease.OpenExclusive(Path.Combine(_root, ".transactions"), 1, 0));
        }
    }

    private void Seed()
    {
        using var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"));
        XmlFragmentImporter.Import(input, _root);
    }

    private static ulong Target(ImmutableXmlSnapshot snapshot) => Enumerable.Range(1, snapshot.NodeCount)
        .Select(id => snapshot.GetNode((ulong)id)).Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();

    /// <inheritdoc />
    public void Dispose() { if (Directory.Exists(_root)) Directory.Delete(_root, true); }
}
