// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Tests persisted format integrity and immutable store reopening.
// SPECIAL NOTES        : Immutable M1 format; no transaction or crash recovery guarantee.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Text;
using Bosak.XmlDb.Core;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Tests persisted format integrity and immutable store reopening.</summary>
public sealed class FragmentStoreTests : IDisposable
{
    private readonly string _root = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-tests-" + Guid.NewGuid().ToString("N"));

    /// <summary>Verifies explicit envelope encoding against a fixed hexadecimal fixture.</summary>
    [Fact]
    public void Envelope_FixedBody_MatchesGoldenBytes()
    {
        var expected = File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "TestData", "envelope-v1.hex")).Trim();
        var bytes = BinaryEnvelope.Encode("BXDB", writer => writer.Write((byte)0));
        Assert.Equal(expected, Convert.ToHexString(bytes));
        Assert.Equal(0, BinaryEnvelope.Decode(bytes, "BXDB", reader => reader.ReadByte()));
    }

    /// <summary>Checks both immutable reopen and payload isolation.</summary>
    [Fact]
    public void Import_Reopen_ReadsOnlyRequestedPayloadAndUsesCache()
    {
        Import("<SalesOrder><SalesOrderHeader><DocumentID>SO-1</DocumentID></SalesOrderHeader><SalesOrderLine>one</SalesOrderLine><SalesOrderLine>two</SalesOrderLine></SalesOrder>");
        using var snapshot = ImmutableXmlSnapshot.Open(_root);
        Assert.Equal(0, snapshot.Metrics.PhysicalFragmentReads);
        var header = Find(snapshot, StorageNodeKind.Text, 1);
        Assert.Equal("SO-1", snapshot.ReadValue(header));
        Assert.Equal("SO-1", snapshot.ReadValue(header));
        Assert.Equal(1, snapshot.Metrics.HeaderFragmentReads);
        Assert.Equal(0, snapshot.Metrics.LineFragmentReads);
        Assert.Equal(1, snapshot.Metrics.CacheHits);
        var line = Find(snapshot, StorageNodeKind.Text, 2);
        Assert.Equal("one", snapshot.ReadValue(line));
        Assert.Equal(1, snapshot.Metrics.LineFragmentReads);
        Assert.Throws<IOException>(() => Import("<SalesOrder/>"));
    }

    /// <summary>Verifies that no-cache reads do not retain payloads.</summary>
    [Fact]
    public void Snapshot_CacheDisabled_RepeatsPhysicalReads()
    {
        Import("<SalesOrder>value</SalesOrder>");
        using var snapshot = ImmutableXmlSnapshot.Open(_root, cacheBytes: 0);
        var id = Find(snapshot, StorageNodeKind.Text, 1);
        Assert.Equal("value", snapshot.ReadValue(id));
        Assert.Equal("value", snapshot.ReadValue(id));
        Assert.Equal(2, snapshot.Metrics.PhysicalFragmentReads);
        Assert.Equal(0, snapshot.Metrics.CacheHits);
    }

    /// <summary>Tests truncation, version, length and checksum corruption of all envelope kinds.</summary>
    [Theory]
    [InlineData("BXDB")]
    [InlineData("BXMF")]
    [InlineData("BXND")]
    [InlineData("BXFG")]
    public void Envelope_CorruptedInput_RejectsBeforeDecoding(string magic)
    {
        var valid = BinaryEnvelope.Encode(magic, writer => writer.Write(42UL));
        for (var length = 0; length < valid.Length; length++)
        {
            var truncated = valid[..length];
            Assert.Throws<InvalidDataException>(() => BinaryEnvelope.Decode(truncated, magic, reader => reader.ReadUInt64()));
        }
        foreach (var offset in new[] { 0, 4, 6, 8, 12, valid.Length - 1 })
        {
            var corrupt = (byte[])valid.Clone();
            corrupt[offset] ^= 0x7f;
            Assert.Throws<InvalidDataException>(() => BinaryEnvelope.Decode(corrupt, magic, reader => reader.ReadUInt64()));
        }
        var unsupported = (byte[])valid.Clone();
        BinaryPrimitives.WriteUInt16LittleEndian(unsupported.AsSpan(4), 2);
        SHA256.HashData(unsupported.AsSpan(0, unsupported.Length - 32), unsupported.AsSpan(unsupported.Length - 32));
        Assert.Throws<InvalidDataException>(() => BinaryEnvelope.Decode(unsupported, magic, reader => reader.ReadUInt64()));
    }

    /// <summary>Checks allocation guards even when checksum is valid.</summary>
    [Theory]
    [InlineData(-1)]
    [InlineData(int.MaxValue)]
    public void Directory_InvalidCount_RejectsBeforeAllocation(int count)
    {
        var bytes = BinaryEnvelope.Encode("BXND", writer => writer.Write(count));
        Assert.Throws<InvalidDataException>(() => StoreCodec.ReadDirectory(bytes));
    }

    /// <summary>Detects checksummed but structurally invalid parent relationships.</summary>
    [Fact]
    public void Directory_InvalidGraph_RejectsAtOpen()
    {
        Import("<SalesOrder>value</SalesOrder>");
        var directoryPath = Path.Combine(_root, "documents", "1", "directory.bin");
        var manifestPath = Path.Combine(_root, "documents", "1", "manifest.bin");
        var nodes = StoreCodec.ReadDirectory(File.ReadAllBytes(directoryPath));
        nodes[1] = nodes[1] with { ParentId = nodes[1].Id };
        var bytes = StoreCodec.WriteDirectory(nodes);
        File.WriteAllBytes(directoryPath, bytes);
        var manifest = StoreCodec.ReadManifest(File.ReadAllBytes(manifestPath));
        File.WriteAllBytes(manifestPath, StoreCodec.WriteManifest(manifest with { DirectoryHash = SHA256.HashData(bytes) }));
        Assert.Throws<InvalidDataException>(() => ImmutableXmlSnapshot.Open(_root));
    }

    /// <summary>Payload corruption remains lazy and is detected at first access.</summary>
    [Fact]
    public void Fragment_CorruptedPayload_RejectsAtFirstRead()
    {
        Import("<SalesOrder>value</SalesOrder>");
        var path = Path.Combine(_root, "fragments", "1.bin");
        var bytes = File.ReadAllBytes(path);
        bytes[^1] ^= 1;
        File.WriteAllBytes(path, bytes);
        using var snapshot = ImmutableXmlSnapshot.Open(_root);
        Assert.Equal(0, snapshot.Metrics.PhysicalFragmentReads);
        Assert.Throws<InvalidDataException>(() => snapshot.ReadValue(Find(snapshot, StorageNodeKind.Text, 1)));
    }

    /// <summary>DTD and external entities are rejected by the importer.</summary>
    [Fact]
    public void Import_Dtd_RejectsWithoutPublishingStore()
    {
        Assert.Throws<System.Xml.XmlException>(() => Import("<!DOCTYPE r [<!ENTITY x SYSTEM 'file:///never-read'>]><r>&x;</r>"));
        Assert.False(Directory.Exists(_root));
    }

    /// <summary>All snapshot fetch paths reject use after disposal.</summary>
    [Fact]
    public void Snapshot_Disposed_RejectsMetadataAndValues()
    {
        Import("<SalesOrder/>");
        var snapshot = ImmutableXmlSnapshot.Open(_root);
        snapshot.Dispose();
        snapshot.Dispose();
        Assert.Throws<ObjectDisposedException>(() => snapshot.GetNode(1));
        Assert.Throws<ObjectDisposedException>(() => snapshot.ReadValue(1));
    }

    /// <summary>Matches every persisted file against an independently encoded minimal XML fixture.</summary>
    [Fact]
    public void Import_MinimalDocument_MatchesGoldenFormatFiles()
    {
        Import("<r/>");
        foreach (var pair in new[]
        {
            ("envelope-v1.hex", "FORMAT"),
            ("directory-v1.hex", Path.Combine("documents", "1", "directory.bin")),
            ("manifest-v1.hex", Path.Combine("documents", "1", "manifest.bin")),
            ("fragment-v1.hex", Path.Combine("fragments", "1.bin")),
        })
        {
            var expected = File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "TestData", pair.Item1)).Trim();
            Assert.Equal(expected, Convert.ToHexString(File.ReadAllBytes(Path.Combine(_root, pair.Item2))));
        }
    }

    /// <summary>Checks eviction after the retained payload budget is exhausted.</summary>
    [Fact]
    public void Cache_OneFragmentBudget_EvictsLeastRecentlyUsedPayload()
    {
        Import("<SalesOrder><SalesOrderLine>a</SalesOrderLine><SalesOrderLine>b</SalesOrderLine></SalesOrder>");
        // Each line holds the implicit xml namespace plus one character (37 bytes).
        using var snapshot = ImmutableXmlSnapshot.Open(_root, cacheBytes: 37);
        var first = Find(snapshot, StorageNodeKind.Text, 2);
        var second = Find(snapshot, StorageNodeKind.Text, 3);
        Assert.Equal("a", snapshot.ReadValue(first));
        Assert.Equal("b", snapshot.ReadValue(second));
        Assert.Equal("a", snapshot.ReadValue(first));
        Assert.Equal(3, snapshot.Metrics.LineFragmentReads);
    }

    /// <summary>Rejects excessive nesting before recursive provider navigation.</summary>
    [Fact]
    public void Import_ExcessiveNesting_RejectsBoundedDepth()
    {
        var xml = string.Concat(Enumerable.Repeat("<r>", 258)) + string.Concat(Enumerable.Repeat("</r>", 258));
        Assert.Throws<InvalidDataException>(() => Import(xml));
        Assert.False(Directory.Exists(_root));
    }
    private void Import(string xml)
    {
        using var input = new MemoryStream(Encoding.UTF8.GetBytes(xml));
        XmlFragmentImporter.Import(input, _root, linesPerFragment: 1);
    }

    private static ulong Find(ImmutableXmlSnapshot snapshot, StorageNodeKind kind, ulong fragment) =>
        Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id))
            .First(node => node.Kind == kind && node.FragmentId == fragment).Id;

    /// <inheritdoc />
    public void Dispose()
    {
        if (Directory.Exists(_root)) Directory.Delete(_root, true);
    }
}

