// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Verifies explicit provisioning, preserved failures and no-overwrite handoff.
// SPECIAL NOTES        : Internal ProcessCrash pilot; retained partial roots are not resumable provisioning plans.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Tests controlled provisioning without automatic repair or durable journal append.</summary>
public sealed class EmbeddedHostProvisioningTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-provision-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "host");
    private string Data => Path.Combine(_area, "data");
    private void Setup() { Directory.CreateDirectory(Data); File.WriteAllText(Path.Combine(Data, "sentinel"), "retain"); }
    private EmbeddedHostProvisioningEvidence Evidence() => new(Root, "pilot", "scope", true, true, true);
    private EmbeddedHostLifetime Provision(Action<HostProvisionStage>? checkpoint = null) => EmbeddedHostLifetime.Provision(Root, "pilot", "scope", [Data], Evidence(), checkpoint: checkpoint);
    private EmbeddedHostLifetime Open() => EmbeddedHostLifetime.OpenExisting(Root, "pilot", "scope", [Data]);

    /// <summary>The CreateNew owner handle stays exclusive through final handoff; both fresh and reopened admissions remain closed.</summary>
    [Fact]
    public async Task Provision_TransfersContinuousOwnershipAndFlushedCanonicalRoles()
    {
        Setup(); var beforeReturn = false;
        using var owner = Provision(stage =>
        {
            if (stage != HostProvisionStage.BeforeReturn) return;
            beforeReturn = true; Assert.Throws<IOException>(() => { using var contender = Open(); });
        });
        Assert.True(beforeReturn); Assert.True(owner.WasProvisionedHere); Assert.False(owner.AdmissionsOpen); Assert.Empty(owner.History.Frames); Assert.True(owner.WritersMustRemainStopped);
        Assert.Equal(0, new FileInfo(Path.Combine(Root, "owner.lock")).Length);
        Assert.Equal(88, new FileInfo(Path.Combine(Root, "host.meta")).Length);
        Assert.Equal(0, new FileInfo(Path.Combine(Root, "journal.bin")).Length);
        Assert.Throws<IOException>(() => { using var duplicate = Provision(); });
        Assert.Throws<InvalidOperationException>(() => owner.BeginOperation()); var session = owner.Context.SessionId; var journal = owner.Context.JournalId;
        owner.Dispose(); await owner.WhenReleased;
        var metadata = HostJournalCodec.DecodeMetadata(File.ReadAllBytes(Path.Combine(Root, "host.meta")), "pilot", "scope"); Assert.Equal(journal, metadata.JournalId);
        using var reopened = Open(); Assert.NotEqual(session, reopened.Context.SessionId); Assert.Equal(journal, reopened.Context.JournalId); Assert.False(reopened.AdmissionsOpen); Assert.False(reopened.WasProvisionedHere);
        Assert.Equal("retain", File.ReadAllText(Path.Combine(Data, "sentinel")));
    }

    /// <summary>Each checkpoint failure retains exactly the observed partial/complete root and refuses any provisioning replay.</summary>
    /// <param name="stage">Provisioning boundary.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(2)]
    [InlineData(3)]
    [InlineData(4)]
    [InlineData(5)]
    [InlineData(6)]
    [InlineData(7)]
    [InlineData(8)]
    [InlineData(9)]
    [InlineData(10)]
    public void CheckpointFailure_PreservesStateAndNeverRepairs(int stage)
    {
        Setup(); var selected = (HostProvisionStage)stage;
        Assert.Throws<IOException>(() => { using var owner = Provision(at => { if (at == selected) throw new IOException("Injected boundary."); }); });
        if (stage == 0)
        {
            Assert.False(Directory.Exists(Root)); Assert.NotNull(Record.Exception(() => { using var missing = Open(); }));
            using var explicitFresh = Provision(); Assert.False(explicitFresh.AdmissionsOpen); return;
        }
        Assert.True(Directory.Exists(Root)); var before = Tree(); Assert.Throws<IOException>(() => { using var replay = Provision(); }); AssertTree(before);
        if (stage >= (int)HostProvisionStage.JournalCreated) { using var observed = Open(); Assert.False(observed.AdmissionsOpen); Assert.False(observed.WasProvisionedHere); }
        else Assert.NotNull(Record.Exception(() => { using var incomplete = Open(); }));
        Assert.Equal("retain", File.ReadAllText(Path.Combine(Data, "sentinel")));
    }

    /// <summary>Metadata partial writes and file/flush/barrier failures preserve bytes and never leak a live owner.</summary>
    /// <param name="fault">Injected storage error.</param>
    [Theory]
    [InlineData("directory-before")]
    [InlineData("directory-after")]
    [InlineData("meta-create-after")]
    [InlineData("meta-partial")]
    [InlineData("meta-flush-before")]
    [InlineData("meta-flush-after")]
    [InlineData("meta-dispose-after")]
    [InlineData("journal-create-after")]
    [InlineData("journal-flush-before")]
    [InlineData("journal-flush-after")]
    [InlineData("journal-dispose-after")]
    [InlineData("root-sync")]
    [InlineData("parent-sync")]
    public void StorageFailure_PreservesPartialStateAndReleasesHandles(string fault)
    {
        Setup(); var storage = new FaultStorage(Root, fault);
        Assert.Throws<IOException>(() => { using var owner = EmbeddedHostLifetime.ProvisionCore(Root, "pilot", "scope", [Data], Evidence(), storage); });
        var before = Tree();
        if (Directory.Exists(Root)) Assert.Throws<IOException>(() => { using var retry = Provision(); });
        AssertTree(before);
        if (fault == "meta-partial") Assert.Equal(44, new FileInfo(Path.Combine(Root, "host.meta")).Length);
        if (File.Exists(Path.Combine(Root, "journal.bin"))) { using var observed = Open(); Assert.False(observed.AdmissionsOpen); Assert.False(observed.WasProvisionedHere); }
        else Assert.NotNull(Record.Exception(() => { using var incomplete = Open(); }));
        Assert.Equal("retain", File.ReadAllText(Path.Combine(Data, "sentinel")));
    }

    /// <summary>All pre-existing namespaces, including empty or apparently healthy roots, reject without storage mutation.</summary>
    /// <param name="existing">Existing role shape.</param>
    [Theory]
    [InlineData("empty")]
    [InlineData("file")]
    [InlineData("partial")]
    [InlineData("complete")]
    [InlineData("foreign")]
    public void ExistingPath_IsNeverAdoptedOrOverwritten(string existing)
    {
        Setup();
        if (existing == "complete") { using var created = Provision(); }
        else if (existing == "file") File.WriteAllText(Root, "foreign-file");
        else
        {
            Directory.CreateDirectory(Root);
            if (existing == "partial") File.WriteAllBytes(Path.Combine(Root, "owner.lock"), []);
            if (existing == "foreign") File.WriteAllText(Path.Combine(Root, "foreign"), "retain");
        }
        var before = Tree(); var storage = new FaultStorage(Root, "none");
        Assert.Throws<IOException>(() => { using var owner = EmbeddedHostLifetime.ProvisionCore(Root, "pilot", "scope", [Data], Evidence(), storage); });
        Assert.Equal(0, storage.Calls); AssertTree(before);
    }

    /// <summary>Missing fresh-scope assertions, scope bindings and unsafe placement/policy reject before any mutation.</summary>
    /// <param name="fault">Invalid precondition.</param>
    [Theory]
    [InlineData("null")]
    [InlineData("stale")]
    [InlineData("uncontrolled")]
    [InlineData("prior-host")]
    [InlineData("root-binding")]
    [InlineData("deployment")]
    [InlineData("scope")]
    [InlineData("relative")]
    [InlineData("overlap")]
    [InlineData("missing-parent")]
    [InlineData("strong-policy")]
    [InlineData("null-storage")]
    public void InvalidPreflight_DoesNotCreateRootOrCallStorage(string fault)
    {
        Setup(); var storage = new FaultStorage(Root, "none"); var e = Evidence();
        e = fault switch
        {
            "stale" => e with { Fresh = false },
            "uncontrolled" => e with { ControlledProvisionersOnly = false },
            "prior-host" => e with { NoPriorHost = false },
            "root-binding" => e with { Root = Data },
            "deployment" => e with { Deployment = "other" },
            "scope" => e with { ResourceScope = "other" },
            _ => e
        };
        var target = fault == "relative" ? "host" : fault == "missing-parent" ? Path.Combine(_area, "absent", "host") : Root;
        if (fault == "missing-parent") e = e with { Root = target };
        if (fault == "strong-policy") storage.Policy = DurabilityMode.FileAndDirectoryFlush;
        var before = Tree(); Assert.NotNull(Record.Exception(() =>
        {
            using var owner = EmbeddedHostLifetime.ProvisionCore(target, "pilot", "scope", fault == "overlap" ? [Root] : [Data],
                fault == "null" ? null! : e, fault == "null-storage" ? null! : storage);
        }));
        Assert.Equal(0, storage.Calls); AssertTree(before); Assert.False(Directory.Exists(Root));
    }

    /// <summary>An occupied root appearing after preflight remains retained rather than receiving any host file.</summary>
    [Fact]
    public void OccupiedRootAfterPreflight_IsRetained()
    {
        Setup(); Assert.Throws<IOException>(() =>
        {
            using var owner = Provision(stage =>
            {
                if (stage == HostProvisionStage.PreflightValidated) { Directory.CreateDirectory(Root); File.WriteAllText(Path.Combine(Root, "foreign"), "retain"); }
            });
        });
        Assert.Equal(new[] { "foreign" }, Directory.GetFiles(Root).Select(Path.GetFileName)); Assert.Equal("retain", File.ReadAllText(Path.Combine(Root, "foreign")));
    }

    /// <summary>Two controlled provisioners that both observed absence have one CreateNew owner winner.</summary>
    [Fact]
    public async Task ConcurrentProvisioners_ExactlyOneWinnerRetainsHandle()
    {
        Setup(); using var ready = new Barrier(2);
        var workers = Enumerable.Range(0, 2).Select(_ => Task.Run(() =>
        {
            try
            {
                return (Owner: Provision(stage => { if (stage == HostProvisionStage.PreflightValidated && !ready.SignalAndWait(TimeSpan.FromSeconds(20))) throw new TimeoutException(); }), Error: (Exception?)null);
            }
            catch (Exception error) { return (Owner: (EmbeddedHostLifetime?)null, Error: error); }
        })).ToArray();
        var results = await Task.WhenAll(workers);
        try
        {
            var winner = Assert.Single(results, x => x.Owner is not null); Assert.Single(results, x => x.Error is IOException);
            Assert.False(winner.Owner!.AdmissionsOpen); Assert.Throws<IOException>(() => { using var contender = Open(); });
        }
        finally { foreach (var result in results) result.Owner?.Dispose(); }
        using var observed = Open(); Assert.False(observed.AdmissionsOpen); Assert.False(observed.WasProvisionedHere);
    }

    /// <summary>Full-length corrupt metadata is rejected at readback and retained without a false successful handoff.</summary>
    [Fact]
    public void CorruptMetadataReadback_RejectsWithoutRepair()
    {
        Setup(); var storage = new FaultStorage(Root, "meta-corrupt");
        Assert.Throws<InvalidDataException>(() => { using var owner = EmbeddedHostLifetime.ProvisionCore(Root, "pilot", "scope", [Data], Evidence(), storage); });
        var before = Tree(); Assert.Equal(88, new FileInfo(Path.Combine(Root, "host.meta")).Length);
        Assert.Throws<InvalidDataException>(() => { using var owner = Open(); }); Assert.Throws<IOException>(() => { using var repair = Provision(); }); AssertTree(before);
    }

    /// <summary>Namespace changes at the final callback remain retained and cannot bypass final handoff validation.</summary>
    [Fact]
    public void FinalNamespaceRecheck_RejectsExtraRole()
    {
        Setup(); Assert.Throws<InvalidDataException>(() =>
        {
            using var owner = Provision(stage => { if (stage == HostProvisionStage.BeforeReturn) File.WriteAllText(Path.Combine(Root, "foreign"), "retain"); });
        });
        var before = Tree(); Assert.Throws<InvalidDataException>(() => { using var owner = Open(); });
        Assert.Throws<IOException>(() => { using var repair = Provision(); }); AssertTree(before); Assert.Equal("retain", File.ReadAllText(Path.Combine(Root, "foreign")));
    }

    private sealed record Snapshot(string[] Directories, Dictionary<string, byte[]> Files);
    private Snapshot Tree() => new(Directory.GetDirectories(_area, "*", SearchOption.AllDirectories).Order().ToArray(), Directory.GetFiles(_area, "*", SearchOption.AllDirectories).ToDictionary(path => path, File.ReadAllBytes));
    private void AssertTree(Snapshot before) { var after = Tree(); Assert.Equal(before.Directories, after.Directories); Assert.Equal(before.Files.Keys.Order(), after.Files.Keys.Order()); foreach (var pair in before.Files) Assert.Equal(pair.Value, after.Files[pair.Key]); }
    private sealed class FaultStorage(string root, string fault) : ITransactionStorage
    {
        private readonly LocalTransactionStorage _inner = new();
        internal int Calls { get; private set; }
        internal DurabilityMode Policy { get; set; } = DurabilityMode.ProcessCrash;
        /// <inheritdoc/>
        public DurabilityMode Durability => Policy;
        /// <inheritdoc/>
        public ITransactionFile CreateFile(string path)
        {
            Calls++; var inner = _inner.CreateFile(path); var role = Path.GetFileName(path) == "host.meta" ? "meta" : "journal";
            if (fault == role + "-create-after") { inner.Dispose(); throw new IOException("Created without return."); }
            return new File(inner, role, fault);
        }
        /// <inheritdoc/>
        public void CreateDirectory(string path) { Calls++; if (fault == "directory-before") throw new IOException(); _inner.CreateDirectory(path); if (fault == "directory-after") throw new IOException(); }
        /// <inheritdoc/>
        public void SyncDirectory(string path) { Calls++; _inner.SyncDirectory(path); if (fault == (path == root ? "root-sync" : "parent-sync")) throw new IOException("Barrier result lost."); }
        /// <inheritdoc/>
        public void MoveFile(string source, string destination, bool overwrite) => throw new InvalidOperationException("Unexpected move.");
        /// <inheritdoc/>
        public void MoveDirectory(string source, string destination) => throw new InvalidOperationException("Unexpected move.");
        /// <inheritdoc/>
        public void DeleteFile(string path) => throw new InvalidOperationException("Unexpected delete.");
        /// <inheritdoc/>
        public void DeleteDirectory(string path) => throw new InvalidOperationException("Unexpected delete.");
        /// <inheritdoc/>
        public void SyncFile(string path) => throw new InvalidOperationException("Unexpected external file flush.");
        private sealed class File(ITransactionFile inner, string role, string fault) : ITransactionFile
        {
            /// <inheritdoc/>
            public void Write(ReadOnlySpan<byte> bytes) { if (fault == role + "-corrupt") { var corrupt = bytes.ToArray(); corrupt[^1] ^= 1; inner.Write(corrupt); return; } if (fault == role + "-partial") { inner.Write(bytes[..44]); throw new IOException("Partial metadata."); } inner.Write(bytes); }
            /// <inheritdoc/>
            public void FlushToDisk() { if (fault == role + "-flush-before") throw new IOException(); inner.FlushToDisk(); if (fault == role + "-flush-after") throw new IOException(); }
            /// <inheritdoc/>
            public void Dispose() { inner.Dispose(); if (fault == role + "-dispose-after") throw new IOException(); }
        }
    }
    /// <summary>Deletes only this GUID-owned test tree after every real owner/file handle closes.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
