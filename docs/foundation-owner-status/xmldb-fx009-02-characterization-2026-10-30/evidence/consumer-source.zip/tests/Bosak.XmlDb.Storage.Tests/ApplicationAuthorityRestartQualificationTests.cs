// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 30 October 2026
// PURPOSE              : Qualifies native restart identity replacement and concurrent stopped-owner disposal.
// SPECIAL NOTES        : SR2-C Linux native bodies are separate from Windows sharing guards; no routing or reclamation.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 30-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

public sealed partial class ApplicationAuthorityRestartObservationTests
{
    /// <summary>Provides every native role/root and both unlocked substitution boundaries.</summary>
    /// <returns>Native replacement cases, guarded explicitly outside Linux.</returns>
    public static IEnumerable<object[]> NativeRestartCases()
    {
        foreach (var role in new[] { "source-writer", "authority-lock", "authority-meta", "authority-log", "parent-owner", "parent-meta", "parent-journal", "source-root", "capture-root", "authority-root", "parent-root" })
            foreach (var stage in new[] { 3, 4 }) yield return new object[] { role, stage };
    }

    /// <summary>Identical replacement bytes never substitute for actual held identities or become adopted history.</summary>
    /// <param name="role">Actual source, parent, authority or capture role/root.</param>
    /// <param name="stage">Unlocked boundary after initial full proof.</param>
    [Theory]
    [MemberData(nameof(NativeRestartCases))]
    public void Observe_NativeSameBytesReplacement_RefusesWithoutRepair(string role, int stage)
    {
        if (!OperatingSystem.IsLinux()) { output.WriteLine("SR2C_NATIVE_GUARD role=" + role + " stage=" + stage); return; }
        using var f = new Fixture(_area); Dictionary<string, byte[]>? bytes = null; string[]? inventory = null; var changed = false;
        f.Probe.Checkpoint = point =>
        {
            if ((int)point != stage) return;
            var root = role.StartsWith("parent-", StringComparison.Ordinal) ? f.Parent.Root : role.StartsWith("authority-", StringComparison.Ordinal) ? f.AuthorityRoot : role == "capture-root" ? f.Capture : f.Root;
            if (role.EndsWith("-root", StringComparison.Ordinal))
            {
                var original = ApplicationAuthorityFileIdentity.PathIdentity(root, true);
                var retained = Path.Combine(_area, "retained-" + role); Directory.Move(root, retained); CopyNativeTree(retained, root);
                Assert.NotEqual(original, ApplicationAuthorityFileIdentity.PathIdentity(root, true));
            }
            else
            {
                var name = role switch { "source-writer" => "writer.lock", "authority-lock" => "authority.lock", "authority-meta" => "authority.meta", "authority-log" => "authority.log", "parent-owner" => "owner.lock", "parent-meta" => "host.meta", _ => "journal.bin" };
                var path = role == "source-writer" ? Path.Combine(root, ".transactions", name) : Path.Combine(root, name);
                var original = ApplicationAuthorityFileIdentity.PathIdentity(path, false); var content = name.EndsWith(".lock", StringComparison.Ordinal) ? [] : SharedBytes(path);
                var retained = Path.Combine(_area, "retained-" + role); Directory.CreateDirectory(retained); File.Move(path, Path.Combine(retained, name)); File.WriteAllBytes(path, content);
                Assert.NotEqual(original, ApplicationAuthorityFileIdentity.PathIdentity(path, false));
            }
            changed = true; bytes = f.Bytes(); inventory = f.Inventory();
        };
        using var scope = f.Begin(); Assert.Throws<InvalidDataException>(() => scope.Observe()); Assert.True(changed); Assert.NotNull(bytes); Assert.NotNull(inventory);
        Assert.True(f.Authority.IsFaulted); Assert.Null(f.Authority.ConfirmedEnrollment); Assert.True(f.Source.EnrollmentOwnershipStatus.StopLatched);
        f.Preserved(bytes, inventory); Assert.Equal("new-0", f.Snapshot.ReadValue(Target(f.Snapshot)));
        scope.Dispose(); f.Preserved(bytes, inventory); output.WriteLine("SR2C_NATIVE_EXECUTED role=" + role + " stage=" + stage + " preserved=true");
    }

    /// <summary>Closing on another thread at each proof phase rejects observation but retains all original roles through actual drain.</summary>
    /// <param name="stage">Unlocked phase where the closer runs.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(2)]
    [InlineData(3)]
    [InlineData(4)]
    public void Observe_ConcurrentClosing_OrderedEndpointsRetainActualChildren(int stage)
    {
        using var f = new Fixture(_area); var bytes = f.Bytes(); var inventory = f.Inventory(); Exception? closeError = null;
        f.Probe.Checkpoint = point =>
        {
            if ((int)point != stage) return;
            var thread = new Thread(() => closeError = Record.Exception(f.CloseWrappers)) { IsBackground = true };
            thread.Start(); Assert.True(thread.Join(TimeSpan.FromSeconds(30))); Assert.Null(closeError);
            if (stage != 0)
            {
                foreach (var path in new[] { Path.Combine(f.Root, ".transactions", "writer.lock"), Path.Combine(f.AuthorityRoot, "authority.lock"), Path.Combine(f.Parent.Root, "owner.lock") })
                    Assert.Throws<IOException>(() => { using var blocked = new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None); });
            }
        };
        ApplicationAuthorityLifetime.StoppedRestartObservation? scope = null;
        try { Assert.ThrowsAny<Exception>(() => { scope = f.Begin(); scope.Observe(); }); }
        finally { scope?.Dispose(); }
        Assert.True(f.Source.WhenEnrollmentOwnershipReleased.IsCompletedSuccessfully); Assert.True(f.Authority.WhenReleased.IsCompletedSuccessfully); Assert.True(f.Parent.WhenReleased.IsCompletedSuccessfully);
        f.Preserved(bytes, inventory); Assert.Equal("new-0", f.Snapshot.ReadValue(Target(f.Snapshot)));
        output.WriteLine("SR2C_ORDERED stage=" + stage + " released=true preserved=true");
    }

    /// <summary>Repeated simultaneous final-phase close schedules allow only a point-in-time stopped description or refusal, never write authority.</summary>
    [Fact]
    public void Observe_CompetesWithClosing_RepeatedSchedulesStayStopped()
    {
        var observed = 0; var refused = 0;
        for (var iteration = 0; iteration < 12; iteration++)
        {
            using var f = new Fixture(Path.Combine(_area, "race-" + iteration)); var bytes = f.Bytes(); var inventory = f.Inventory();
            using var start = new ManualResetEventSlim(); Exception? closeError = null;
            var closer = new Thread(() => { if (start.Wait(TimeSpan.FromSeconds(30))) closeError = Record.Exception(f.CloseWrappers); }) { IsBackground = true };
            closer.Start(); f.Probe.Checkpoint = point => { if (point == RestartObservationStage.BeforeFinalValidation) start.Set(); };
            using var scope = f.Begin(); ApplicationRestartDescription? description = null; var error = Record.Exception(() => description = scope.Observe());
            Assert.True(closer.Join(TimeSpan.FromSeconds(30))); Assert.Null(closeError);
            if (error is null) { Assert.NotNull(description); Assert.True(description.WritersMustRemainStopped); Assert.Equal(EnrollmentRestartDecision.ObservedEnrolledStopped, description.Assessment.Decision); observed++; }
            else { Assert.True(error is InvalidOperationException or ObjectDisposedException); refused++; }
            scope.Dispose(); Assert.True(f.Source.WhenEnrollmentOwnershipReleased.IsCompletedSuccessfully); Assert.True(f.Authority.WhenReleased.IsCompletedSuccessfully); Assert.True(f.Parent.WhenReleased.IsCompletedSuccessfully);
            f.Preserved(bytes, inventory); Assert.Equal("new-0", f.Snapshot.ReadValue(Target(f.Snapshot)));
        }
        Assert.Equal(12, observed + refused); output.WriteLine("SR2C_RACES attempts=12 observed=" + observed + " refused=" + refused + " allStopped=true");
    }

    private static byte[] SharedBytes(string path)
    { using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite); var bytes = new byte[(int)stream.Length]; stream.ReadExactly(bytes); return bytes; }
    private static void CopyNativeTree(string source, string destination)
    {
        Directory.CreateDirectory(destination);
        foreach (var directory in Directory.GetDirectories(source, "*", SearchOption.AllDirectories)) Directory.CreateDirectory(Path.Combine(destination, Path.GetRelativePath(source, directory)));
        foreach (var file in Directory.GetFiles(source, "*", SearchOption.AllDirectories))
            File.WriteAllBytes(Path.Combine(destination, Path.GetRelativePath(source, file)), Path.GetFileName(file) is "writer.lock" or "owner.lock" or "authority.lock" ? [] : SharedBytes(file));
    }
}
