// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Qualifies retained source ownership, freeze drain and the original-owner stop latch.
// SPECIAL NOTES        : EF1 source lifetime only; no authority root, append or application admission.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Text;
using Bosak.XmlDb.Core;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Qualifies retained source ownership, freeze drain and the original-owner stop latch.</summary>
public sealed class EnrollmentSourceRetentionTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ef1-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "source");
    private string Capture => Path.Combine(_area, "capture");
    private string Writer => Path.Combine(Root, ".transactions", "writer.lock");
    private void Seed(int count = 1)
    {
        Directory.CreateDirectory(_area); using var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>")); XmlFragmentImporter.Import(input, Root);
        using var owner = EmbeddedXmlDatabase.Open(Root);
        for (var i = 0; i < count; i++) { using var read = owner.BeginRead(); using var tx = owner.BeginWrite(); tx.ReplaceNodeValue(Target(read), "new-" + i); tx.Commit(); }
    }
    private static ulong Target(ImmutableXmlSnapshot snapshot) => Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();
    private Dictionary<string, byte[]> Bytes() => Directory.GetFiles(_area, "*", SearchOption.AllDirectories).Where(p => Path.GetFileName(p) != "writer.lock").ToDictionary(p => p, File.ReadAllBytes);
    private string[] Inventory() => Directory.GetFileSystemEntries(_area, "*", SearchOption.AllDirectories).Order().ToArray();
    private void AssertBytes(Dictionary<string, byte[]> before, string[] inventory)
    { var after = Bytes(); Assert.Equal(before.Keys.Order(), after.Keys.Order()); foreach (var pair in before) Assert.Equal(pair.Value, after[pair.Key]); Assert.Equal(inventory, Inventory()); }
    private void Blocked() => Assert.Throws<IOException>(() => { using var blocked = new FileStream(Writer, FileMode.Open, FileAccess.ReadWrite, FileShare.None); });

    /// <summary>Original native identity survives actual owner/freeze disposal until the child drains.</summary>
    /// <param name="armed">Whether source-local arming precedes closing.</param>
    /// <param name="sourceFirst">Whether source owner closes before its freeze.</param>
    [Theory]
    [InlineData(false, false)]
    [InlineData(false, true)]
    [InlineData(true, false)]
    [InlineData(true, true)]
    public void Closing_RetainedChild_KeepsOriginalHandle(bool armed, bool sourceFirst)
    {
        Seed(); using var owner = EmbeddedXmlDatabase.Open(Root); using var read = owner.BeginRead();
        using var freeze = MigrationSourceFreeze.Acquire(owner, true); var capture = freeze.Capture(Capture); using var child = freeze.RetainForEnrollment(capture);
        var initial = child.InspectState(); if (armed) child.Arm(); var bytes = Bytes(); var inventory = Inventory(); var released = owner.WhenEnrollmentOwnershipReleased;
        if (sourceFirst) { owner.Dispose(); freeze.Dispose(); } else { freeze.Dispose(); owner.Dispose(); }
        Assert.True(owner.EnrollmentOwnershipStatus.Closing); Assert.True(owner.EnrollmentOwnershipStatus.HasRetainer);
        Assert.Equal(EnrollmentSourceReleaseState.RetainedClosing, owner.EnrollmentOwnershipStatus.ReleaseState); Assert.False(released.IsCompleted); Blocked();
        Assert.Throws<ObjectDisposedException>(() => owner.BeginRead()); Assert.Throws<ObjectDisposedException>(() => freeze.InspectAdmission());
        if (armed) { var state = child.InspectState(); Assert.Equal(initial.AdmissionIdentity, state.AdmissionIdentity); Assert.Equal(initial.RootIdentity, state.RootIdentity); Assert.Equal(initial.Source.ManifestHash, state.Source.ManifestHash); }
        else { Assert.Throws<ObjectDisposedException>(() => child.InspectState()); Assert.Throws<ObjectDisposedException>(() => child.Arm()); }
        child.Dispose(); child.Dispose(); Assert.True(released.IsCompletedSuccessfully); Assert.Equal(EnrollmentSourceRetentionState.Released, child.State);
        Assert.Equal(EnrollmentSourceReleaseState.Released, owner.EnrollmentOwnershipStatus.ReleaseState); Assert.Equal("new-0", read.ReadValue(Target(read)));
        using var available = new FileStream(Writer, FileMode.Open, FileAccess.ReadWrite, FileShare.None); AssertBytes(bytes, inventory);
    }

    /// <summary>Unarmed drain honors explicit freeze release but cannot register another child under that freeze.</summary>
    [Fact]
    public void PendingFreezeDisposed_ActualDrain_ReleasesOnlyUnarmedExclusion()
    {
        Seed(); using var owner = EmbeddedXmlDatabase.Open(Root); using var freeze = MigrationSourceFreeze.Acquire(owner, true); var capture = freeze.Capture(Capture);
        var child = freeze.RetainForEnrollment(capture); freeze.Dispose();
        Assert.Throws<InvalidOperationException>(() => owner.BeginWrite()); Assert.Throws<InvalidOperationException>(() => owner.CreateBackup(Path.Combine(_area, "blocked")));
        Assert.Throws<ObjectDisposedException>(() => child.Arm()); child.Dispose();
        using var tx = owner.BeginWrite(); Assert.False(owner.EnrollmentOwnershipStatus.StopLatched); Assert.False(Directory.Exists(Path.Combine(_area, "blocked")));
    }

    /// <summary>Armed drain never resumes mutation or publication on the original live source owner.</summary>
    /// <param name="operation">Mutation/publisher entry point.</param>
    [Theory]
    [InlineData("new-transaction")]
    [InlineData("pending-commit")]
    [InlineData("checkpoint")]
    [InlineData("anchor")]
    [InlineData("backup")]
    [InlineData("freeze")]
    public void ArmedThenDisposed_StopLatch_BlocksEveryPublisher(string operation)
    {
        Seed(); using var owner = EmbeddedXmlDatabase.Open(Root); using var pending = owner.BeginWrite(); using (var read = owner.BeginRead()) pending.ReplaceNodeValue(Target(read), "blocked");
        using var freeze = MigrationSourceFreeze.Acquire(owner, true); var capture = freeze.Capture(Capture); var child = freeze.RetainForEnrollment(capture);
        _ = child.InspectState(); child.Arm(); freeze.Dispose(); child.Dispose(); var bytes = Bytes(); var inventory = Inventory();
        Assert.True(owner.EnrollmentOwnershipStatus.StopLatched); Assert.False(owner.EnrollmentOwnershipStatus.HasRetainer);
        Assert.Throws<InvalidOperationException>(() =>
        {
            switch (operation)
            {
                case "new-transaction": using (owner.BeginWrite()) { } break;
                case "pending-commit": pending.Commit(); break;
                case "checkpoint": owner.CreateCheckpoint(); break;
                case "anchor": owner.CreateRecoveryAnchor(); break;
                case "backup": owner.CreateBackup(Path.Combine(_area, "blocked")); break;
                default: using (MigrationSourceFreeze.Acquire(owner, true)) { } break;
            }
        });
        using var current = owner.BeginRead(); Assert.Equal("new-0", current.ReadValue(Target(current))); AssertBytes(bytes, inventory);
    }

    /// <summary>Guard registration blocks backups before destination creation, even before arming.</summary>
    [Fact]
    public void PendingChild_NewBackup_RejectsWithoutOutput()
    {
        Seed(); using var owner = EmbeddedXmlDatabase.Open(Root); using var freeze = MigrationSourceFreeze.Acquire(owner, true); var capture = freeze.Capture(Capture);
        using var child = freeze.RetainForEnrollment(capture); var bytes = Bytes(); var inventory = Inventory();
        Assert.Throws<InvalidOperationException>(() => owner.CreateBackup(Path.Combine(_area, "blocked"))); AssertBytes(bytes, inventory);
    }

    /// <summary>Registered object, one-child-per-freeze and exact capture identity cannot be recreated from values.</summary>
    [Fact]
    public void Acquire_ForeignCaptureAndDuplicate_RejectWithoutReplacingChild()
    {
        Seed(); using var owner = EmbeddedXmlDatabase.Open(Root); using var freeze = MigrationSourceFreeze.Acquire(owner, true); var capture = freeze.Capture(Capture);
        Assert.Throws<InvalidOperationException>(() => freeze.RetainForEnrollment(new(Capture, capture.InventoryBytes)));
        var child = freeze.RetainForEnrollment(capture); _ = child.InspectState(); Assert.Throws<InvalidOperationException>(() => freeze.RetainForEnrollment(capture));
        child.Dispose(); Assert.Throws<InvalidOperationException>(() => freeze.RetainForEnrollment(capture)); Assert.False(owner.EnrollmentOwnershipStatus.HasRetainer);
    }

    /// <summary>Missing capture cannot satisfy reference equality or consume a later valid registration.</summary>
    [Fact]
    public void Acquire_NoRegisteredCapture_RejectsWithoutClaiming()
    {
        Seed(); using var owner = EmbeddedXmlDatabase.Open(Root); using var freeze = MigrationSourceFreeze.Acquire(owner, true);
        Assert.Throws<ArgumentNullException>(() => freeze.RetainForEnrollment(null!)); Assert.False(owner.EnrollmentOwnershipStatus.HasRetainer);
        var capture = freeze.Capture(Capture); using var child = freeze.RetainForEnrollment(capture); Assert.Equal(EnrollmentSourceRetentionState.Pending, child.State);
    }

    /// <summary>Arming is memory-only, single-use, and requires a successful native identity inspection.</summary>
    [Fact]
    public void Arm_UnvalidatedOrRepeated_Rejects()
    {
        Seed(); using var owner = EmbeddedXmlDatabase.Open(Root); using var freeze = MigrationSourceFreeze.Acquire(owner, true); var capture = freeze.Capture(Capture);
        using var child = freeze.RetainForEnrollment(capture); Assert.Throws<InvalidOperationException>(() => child.Arm());
        _ = child.InspectState(); var bytes = Bytes(); var inventory = Inventory(); child.Arm(); Assert.Throws<InvalidOperationException>(() => child.Arm()); AssertBytes(bytes, inventory);
    }

    /// <summary>Normal borrowed freeze and immediate owner close retain existing behavior without opt-in retention.</summary>
    [Fact]
    public void NoRetainer_ExistingFreezeAndClose_Unchanged()
    {
        Seed(); using var owner = EmbeddedXmlDatabase.Open(Root); using var read = owner.BeginRead();
        using var freeze = MigrationSourceFreeze.Acquire(owner, true); freeze.Capture(Capture); owner.CreateBackup(Path.Combine(_area, "second-backup"));
        freeze.Dispose(); using (owner.BeginWrite()) { }
        owner.Dispose();
        Assert.Equal(EnrollmentSourceReleaseState.Released, owner.EnrollmentOwnershipStatus.ReleaseState); Assert.False(owner.EnrollmentOwnershipStatus.StopLatched);
        using var available = new FileStream(Writer, FileMode.Open, FileAccess.ReadWrite, FileShare.None); Assert.Equal("new-0", read.ReadValue(Target(read)));
    }

    /// <summary>Stop latch belongs to the original owner and does not claim a durable fence on explicitly reopened owners.</summary>
    [Fact]
    public void ArmedOwnerClosed_ExplicitNewOwner_DoesNotInheritLatch()
    {
        Seed(); using (var owner = EmbeddedXmlDatabase.Open(Root))
        using (var freeze = MigrationSourceFreeze.Acquire(owner, true))
        { var capture = freeze.Capture(Capture); using var child = freeze.RetainForEnrollment(capture); _ = child.InspectState(); child.Arm(); }
        using var reopened = EmbeddedXmlDatabase.Open(Root); Assert.False(reopened.EnrollmentOwnershipStatus.StopLatched); using var tx = reopened.BeginWrite();
    }

    /// <summary>Cross-thread use cannot arm, inspect or release the caller-thread child.</summary>
    /// <param name="operation">Foreign-thread operation.</param>
    [Theory]
    [InlineData("arm")]
    [InlineData("inspect")]
    [InlineData("dispose")]
    public void Child_WrongThread_RejectsWithoutLosingLease(string operation)
    {
        Seed(); using var owner = EmbeddedXmlDatabase.Open(Root); using var freeze = MigrationSourceFreeze.Acquire(owner, true); var capture = freeze.Capture(Capture);
        using var child = freeze.RetainForEnrollment(capture); _ = child.InspectState(); Exception? error = null;
        var thread = new Thread(() => error = Record.Exception(() => { if (operation == "arm") child.Arm(); else if (operation == "inspect") child.InspectState(); else child.Dispose(); })) { IsBackground = true };
        thread.Start(); Assert.True(thread.Join(TimeSpan.FromSeconds(30))); Assert.IsType<InvalidOperationException>(error); Assert.Equal(EnrollmentSourceRetentionState.Pending, child.State); Blocked(); child.Arm();
    }

    /// <summary>Simultaneous close/arm has one ordered outcome and always preserves real ownership until drain.</summary>
    [Fact]
    public void Arm_RacesOwnerClose_AlwaysRetainsOriginalLease()
    {
        for (var repeat = 0; repeat < 12; repeat++)
        {
            using var fixture = new EnrollmentSourceRetentionTests(); fixture.Seed(); using var owner = EmbeddedXmlDatabase.Open(fixture.Root);
            using var freeze = MigrationSourceFreeze.Acquire(owner, true); var capture = freeze.Capture(fixture.Capture); using var child = freeze.RetainForEnrollment(capture); _ = child.InspectState();
            using var start = new ManualResetEventSlim(); Exception? closeError = null;
            var thread = new Thread(() => { if (!start.Wait(TimeSpan.FromSeconds(30))) return; closeError = Record.Exception(owner.Dispose); }) { IsBackground = true };
            thread.Start(); start.Set(); var armError = Record.Exception(child.Arm); Assert.True(thread.Join(TimeSpan.FromSeconds(30))); Assert.Null(closeError);
            if (armError is null) { Assert.True(owner.EnrollmentOwnershipStatus.StopLatched); _ = child.InspectState(); }
            else Assert.IsType<ObjectDisposedException>(armError);
            fixture.Blocked(); freeze.Dispose(); child.Dispose(); Assert.Equal(EnrollmentSourceReleaseState.Released, owner.EnrollmentOwnershipStatus.ReleaseState);
        }
    }

    /// <summary>Native admission mismatch faults the child and leaves the original source stopped after drain.</summary>
    [Fact]
    public void Inspect_NonemptyOriginalAdmission_RejectsAndLatchesStop()
    {
        Seed(); File.WriteAllBytes(Writer, [1]); using var owner = EmbeddedXmlDatabase.Open(Root);
        using var freeze = MigrationSourceFreeze.Acquire(owner, true); var capture = freeze.Capture(Capture); using var child = freeze.RetainForEnrollment(capture);
        Assert.Throws<InvalidDataException>(() => child.InspectState()); Assert.Equal(EnrollmentSourceRetentionState.Faulted, child.State);
        Assert.Throws<InvalidOperationException>(() => child.Arm()); freeze.Dispose(); child.Dispose(); Assert.Throws<InvalidOperationException>(() => owner.BeginWrite());
    }

    /// <summary>Failure before or after actual close is reported unknown, never assumed held/released or retried.</summary>
    /// <param name="afterClose">Whether the injected failure follows the real close.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Release_CloseError_RemainsUnknownWithoutRetry(bool afterClose)
    {
        Seed(); using var closer = new FailingClose(afterClose); using var owner = EmbeddedXmlDatabase.Open(Root);
        using var freeze = MigrationSourceFreeze.Acquire(owner, true); var capture = freeze.Capture(Capture); var child = freeze.RetainForEnrollmentCore(capture, closer);
        _ = child.InspectState(); child.Arm(); var completion = owner.WhenEnrollmentOwnershipReleased; owner.Dispose(); freeze.Dispose();
        Assert.Throws<IOException>(child.Dispose); Assert.True(completion.IsFaulted); Assert.IsType<IOException>(completion.Exception!.InnerException);
        Assert.Equal(EnrollmentSourceRetentionState.ReleaseUnknown, child.State); Assert.Equal(EnrollmentSourceReleaseState.Unknown, owner.EnrollmentOwnershipStatus.ReleaseState);
        Assert.True(owner.EnrollmentOwnershipStatus.HasRetainer); Assert.True(owner.EnrollmentOwnershipStatus.StopLatched); child.Dispose(); owner.Dispose(); Assert.Equal(1, closer.Calls);
        Assert.Throws<InvalidOperationException>(() => child.InspectState()); if (!afterClose) Blocked();
    }
    /// <summary>A close adapter returning without closing cannot falsely confirm release.</summary>
    [Fact]
    public void Release_CloseNotDelegated_ReportsUnknown()
    {
        Seed(); using var closer = new MissingClose(); using var owner = EmbeddedXmlDatabase.Open(Root); using var freeze = MigrationSourceFreeze.Acquire(owner, true);
        var capture = freeze.Capture(Capture); var child = freeze.RetainForEnrollmentCore(capture, closer); owner.Dispose(); freeze.Dispose();
        Assert.Throws<IOException>(child.Dispose); Assert.Equal(EnrollmentSourceReleaseState.Unknown, owner.EnrollmentOwnershipStatus.ReleaseState); Blocked(); child.Dispose(); Assert.Equal(1, closer.Calls);
    }
    private sealed class MissingClose : IEnrollmentSourceLeaseClose, IDisposable
    {
        private FileStream? _original;
        internal int Calls { get; private set; }
        /// <inheritdoc/>
        public void Close(FileStream stream) { _original = stream; Calls++; }
        /// <summary>Closes only the injected test fixture handle; it does not change production release diagnostics.</summary>
        public void Dispose() => _original?.Dispose();
    }
    private sealed class FailingClose(bool afterClose) : IEnrollmentSourceLeaseClose, IDisposable
    {
        private FileStream? _original;
        internal int Calls { get; private set; }
        /// <inheritdoc/>
        public void Close(FileStream stream) { _original = stream; Calls++; if (afterClose) stream.Dispose(); throw new IOException("Injected close confirmation failure."); }
        /// <summary>Closes only the captured original handle of this private test fixture, without rearming production state.</summary>
        public void Dispose() => _original?.Dispose();
    }
    /// <summary>Removes only the test's fresh private workspace after all actual owners have closed.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
