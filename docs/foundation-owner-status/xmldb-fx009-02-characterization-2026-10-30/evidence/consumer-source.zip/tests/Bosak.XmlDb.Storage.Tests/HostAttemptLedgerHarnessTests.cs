// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Tests conditional in-memory ledger commits, races and uncertain acknowledgments.
// SPECIAL NOTES        : Internal protocol harness only; no durable persistence, executable permits or effective fence.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Qualifies an in-memory protocol without durability, dispatch, filesystem or routing claims.</summary>
public sealed class HostAttemptLedgerHarnessTests
{
    /// <summary>Simulated failures before and after each commit are resolved by reading exact retained state.</summary>
    /// <param name="operation">Conditional operation.</param>
    /// <param name="fault">Commit boundary.</param>
    [Theory]
    [InlineData("record", 0)]
    [InlineData("record", 1)]
    [InlineData("record", 2)]
    [InlineData("authorize", 0)]
    [InlineData("authorize", 1)]
    [InlineData("authorize", 2)]
    [InlineData("uncertain", 0)]
    [InlineData("uncertain", 1)]
    [InlineData("uncertain", 2)]
    [InlineData("acknowledge", 0)]
    [InlineData("acknowledge", 1)]
    [InlineData("acknowledge", 2)]
    [InlineData("observe", 0)]
    [InlineData("observe", 1)]
    [InlineData("observe", 2)]
    [InlineData("absent", 0)]
    [InlineData("absent", 1)]
    [InlineData("absent", 2)]
    [InlineData("takeover", 0)]
    [InlineData("takeover", 1)]
    [InlineData("takeover", 2)]
    public void CommitBoundaries_ReadDistinguishesAppliedFromUnapplied(string operation, int fault)
    {
        var harness = Prepare(operation); var before = harness.Read(); var history = harness.History(); var context = before?.Context ?? Context();
        HostLedgerTransition Apply(HostLedgerCommitFault injection) => operation switch
        {
            "record" => harness.Record(Evidence(new(context, HostLedgerStage.Recorded)), injection),
            "authorize" => harness.Authorize(before, Evidence(before!), injection),
            "uncertain" => harness.MarkUncertain(before, injection),
            "acknowledge" => harness.Acknowledge(before, Receipt(before!), injection),
            "observe" => harness.ObserveKnown(before, Evidence(before!, known: true), injection),
            "absent" => harness.ReconcileAbsent(before, Evidence(before!, absent: true), injection),
            _ => harness.TakeOver(before, Transfer(before!), Guid.Parse("11111111-1111-1111-1111-111111111111"), 2, injection)
        };
        if (fault == 0) Assert.Equal(HostLedgerTransition.Applied, Apply(HostLedgerCommitFault.None));
        else Assert.Throws<InvalidOperationException>(() => Apply((HostLedgerCommitFault)fault));
        if (fault == 1)
        {
            Assert.Equal(before, harness.Read()); Assert.Equal(history, harness.History());
            Assert.Equal(HostLedgerTransition.Applied, Apply(HostLedgerCommitFault.None));
        }
        var after = harness.Read()!;
        Assert.Equal(operation switch
        {
            "record" => HostLedgerStage.Recorded,
            "authorize" => HostLedgerStage.DispatchAuthorized,
            "acknowledge" => HostLedgerStage.Acknowledged,
            "observe" => HostLedgerStage.ObservedKnown,
            "absent" => HostLedgerStage.ReconciledAbsent,
            _ => HostLedgerStage.Uncertain
        }, after.Stage);
        Assert.Equal((before?.Context.Revision ?? 0) + 1, after.Context.Revision);
        Assert.Equal(history.Length + 1, harness.History().Length);
        Assert.Equal(HostLedgerTransition.Conflict, Apply(HostLedgerCommitFault.None));
        Assert.Equal(after, harness.Read()); Assert.True(harness.WritersMustRemainStopped);
        Assert.Equal(operation == "acknowledge", after.Receipt is not null);
        Assert.Equal(operation == "observe", after.Observed is not null);
    }

    /// <summary>One exact revision permits one authorization even with concurrent workers.</summary>
    [Fact]
    public async Task ConcurrentAuthorization_OneWinnerAndNoSecondPermit()
    {
        var harness = Prepare("authorize"); var original = harness.Read()!; var evidence = Evidence(original); using var start = new ManualResetEventSlim();
        var workers = Enumerable.Range(0, 8).Select(_ => Task.Run(() => { start.Wait(); return harness.Authorize(original, evidence); })).ToArray();
        start.Set(); var results = await Task.WhenAll(workers);
        Assert.Single(results, value => value == HostLedgerTransition.Applied); Assert.Equal(7, results.Count(value => value == HostLedgerTransition.Conflict));
        var now = harness.Read()!; Assert.Equal(HostLedgerStage.DispatchAuthorized, now.Stage); Assert.Equal(2UL, now.Context.Revision);
        Assert.Equal(HostLedgerTransition.Rejected, harness.Authorize(now, Evidence(now))); Assert.Equal(2, harness.History().Length);
    }

    /// <summary>Concurrent intent commits cannot replace the first descriptor, including equal request IDs with changed intent.</summary>
    [Fact]
    public async Task ConcurrentIntent_OneImmutableBinding()
    {
        var harness = new HostAttemptLedgerHarness(); var context = Context(); using var start = new ManualResetEventSlim();
        var workers = Enumerable.Range(0, 8).Select(index => Task.Run(() =>
        {
            var candidate = context with { Intent = context.Intent with { AttemptId = Guid.NewGuid(), BundleRoot = "candidate-" + index } };
            start.Wait(); return (candidate, result: harness.Record(Evidence(new(candidate, HostLedgerStage.Recorded))));
        })).ToArray();
        start.Set(); var results = await Task.WhenAll(workers); var winner = Assert.Single(results, value => value.result == HostLedgerTransition.Applied);
        Assert.Equal(winner.candidate, harness.Read()!.Context); Assert.Single(harness.History());
    }

    /// <summary>Acknowledgment and observation races preserve their distinctions and require fresh revisions.</summary>
    [Fact]
    public async Task ReceiptAndObservationRace_RetainsActualReceiptWithoutFabrication()
    {
        var harness = Prepare("acknowledge"); var before = harness.Read()!; using var start = new ManualResetEventSlim();
        var a = Task.Run(() => { start.Wait(); return harness.Acknowledge(before, Receipt(before)); });
        var b = Task.Run(() => { start.Wait(); return harness.ObserveKnown(before, Evidence(before, known: true)); });
        start.Set(); var results = await Task.WhenAll(a, b); Assert.Single(results, r => r == HostLedgerTransition.Applied); Assert.Single(results, r => r == HostLedgerTransition.Conflict);
        var current = harness.Read()!;
        if (current.Stage == HostLedgerStage.ObservedKnown)
        {
            Assert.Null(current.Receipt); Assert.Equal(HostLedgerTransition.Applied, harness.Acknowledge(current, Receipt(current)));
            Assert.NotNull(harness.Read()!.Observed);
        }
        Assert.Equal(HostLedgerStage.Acknowledged, harness.Read()!.Stage); Assert.Equal(Receipt(before), harness.Read()!.Receipt);
    }

    /// <summary>Takeover requires all fresh supplied exclusion facts and strictly increasing owner generation.</summary>
    /// <param name="fault">Missing or conflicting transfer evidence.</param>
    [Theory]
    [InlineData("null")]
    [InlineData("context")]
    [InlineData("stale")]
    [InlineData("authority")]
    [InlineData("publisher")]
    [InlineData("queue")]
    [InlineData("writers")]
    [InlineData("empty-session")]
    [InlineData("same-session")]
    [InlineData("same-generation")]
    [InlineData("old-generation")]
    public void UnsafeTakeover_LeavesHistoryUntouched(string fault)
    {
        var harness = Prepare("takeover"); var before = harness.Read()!; HostLedgerTakeoverEvidence? transfer = Transfer(before);
        var session = Guid.NewGuid(); ulong generation = 2;
        switch (fault)
        {
            case "null": transfer = null; break;
            case "context": transfer = transfer with { Context = before.Context with { ResourceScope = "other" } }; break;
            case "stale": transfer = transfer with { Fresh = false }; break;
            case "authority": transfer = transfer with { AuthoritativeTransfer = false }; break;
            case "publisher": transfer = transfer with { AllPriorPublishersExcluded = false }; break;
            case "queue": transfer = transfer with { QueuesDrained = false }; break;
            case "writers": transfer = transfer with { DatabaseWritersExcluded = false }; break;
            case "empty-session": session = Guid.Empty; break;
            case "same-session": session = before.Context.OwnerSession; break;
            case "same-generation": generation = 1; break;
            case "old-generation": generation = 0; break;
        }
        Assert.Equal(HostLedgerTransition.Rejected, harness.TakeOver(before, transfer, session, generation));
        Assert.Equal(before, harness.Read()); Assert.Equal(2, harness.History().Length);
    }

    /// <summary>A replacement owner rejects stale updates while retaining any prior publication evidence.</summary>
    /// <param name="publication">Retain acknowledged or observed metadata, or uncertain dispatch.</param>
    [Theory]
    [InlineData("acknowledged")]
    [InlineData("observed")]
    [InlineData("authorized")]
    public void Takeover_RejectsOldOwnerAndRetainsPublication(string publication)
    {
        var harness = Prepare("takeover"); var old = harness.Read()!;
        if (publication == "acknowledged") harness.Acknowledge(old, Receipt(old));
        if (publication == "observed") harness.ObserveKnown(old, Evidence(old, known: true));
        var before = harness.Read()!;
        Assert.Equal(HostLedgerTransition.Applied, harness.TakeOver(before, Transfer(before), Guid.NewGuid(), 2)); var current = harness.Read()!;
        Assert.Equal(before.Receipt, current.Receipt); Assert.Equal(before.Observed, current.Observed);
        Assert.Equal(HostLedgerTransition.Conflict, harness.Acknowledge(before, Receipt(before)));
        Assert.Equal(HostLedgerTransition.Rejected, harness.Authorize(current, Evidence(current)));
        Assert.Equal(publication == "authorized" ? HostLedgerTransition.Applied : HostLedgerTransition.Rejected, harness.ReconcileAbsent(current, Evidence(current, absent: true)));
    }

    /// <summary>Known publication and reconciled absence cannot rearm the original attempt.</summary>
    /// <param name="stage">Terminal/reconciliation state.</param>
    [Theory]
    [InlineData("acknowledged")]
    [InlineData("observed")]
    [InlineData("absent")]
    public void ReconciledStates_NeverRearmOrEraseEvidence(string stage)
    {
        var harness = Prepare("acknowledge"); var before = harness.Read()!;
        if (stage == "acknowledged") harness.Acknowledge(before, Receipt(before));
        else if (stage == "observed") harness.ObserveKnown(before, Evidence(before, known: true));
        else harness.ReconcileAbsent(before, Evidence(before, absent: true));
        var current = harness.Read()!;
        Assert.Equal(HostLedgerTransition.Rejected, harness.Authorize(current, Evidence(current)));
        Assert.Equal(HostLedgerTransition.Rejected, harness.ReconcileAbsent(current, Evidence(current, absent: true)));
        Assert.Equal(HostLedgerTransition.Rejected, harness.MarkUncertain(current)); Assert.Equal(current, harness.Read());
    }

    /// <summary>Missing, stale and mismatched authorization facts cannot consume a ledger revision.</summary>
    /// <param name="fault">Invalid evidence.</param>
    [Theory]
    [InlineData("null")]
    [InlineData("context")]
    [InlineData("phase")]
    [InlineData("save")]
    [InlineData("owner")]
    [InlineData("queue")]
    [InlineData("publisher")]
    [InlineData("plan")]
    [InlineData("invocation")]
    [InlineData("prior-publication")]
    [InlineData("stale")]
    [InlineData("invalid-fault")]
    public void InvalidAuthorization_DoesNotCommit(string fault)
    {
        var harness = Prepare("authorize"); var before = harness.Read()!; HostLedgerEvidence? evidence = Evidence(before);
        evidence = fault switch
        {
            "null" => null,
            "context" => evidence with { Expected = before.Context with { RequestId = Guid.NewGuid() } },
            "phase" => evidence with { Record = evidence.Record! with { Phase = HostLedgerPhase.DispatchAuthorized } },
            "save" => evidence with { Record = evidence.Record! with { Save = HostLedgerSave.Unknown } },
            "owner" => evidence with { Ownership = evidence.Ownership! with { CurrentOwner = false } },
            "queue" => evidence with { Ownership = evidence.Ownership! with { QueuesDrained = false } },
            "publisher" => evidence with { Ownership = evidence.Ownership! with { AllPriorPublishersExcluded = false } },
            "plan" => evidence with { Record = evidence.Record! with { OriginalPlanAvailable = false } },
            "invocation" => evidence with { Record = evidence.Record! with { InvocationNotStarted = false } },
            "prior-publication" => evidence with { Flow = evidence.Flow! with { PriorPublicationKnown = true } },
            "stale" => evidence with { Publication = evidence.Publication! with { Fresh = false } },
            _ => evidence
        };
        Assert.Equal(HostLedgerTransition.Rejected, harness.Authorize(before, evidence, fault == "invalid-fault" ? (HostLedgerCommitFault)999 : HostLedgerCommitFault.None));
        Assert.Equal(before, harness.Read()); Assert.Single(harness.History());
    }

    /// <summary>A receipt must independently match the intent and any previously observed destination.</summary>
    /// <param name="fault">Receipt mismatch.</param>
    [Theory]
    [InlineData("null")]
    [InlineData("operation")]
    [InlineData("backup")]
    [InlineData("path")]
    [InlineData("destination")]
    [InlineData("sequence")]
    [InlineData("observed-destination")]
    public void WrongReceipt_DoesNotFabricateAcknowledgment(string fault)
    {
        var harness = Prepare("acknowledge"); var before = harness.Read()!;
        if (fault == "observed-destination") { harness.ObserveKnown(before, Evidence(before, known: true)); before = harness.Read()!; }
        EpochPublishedReceipt? receipt = Receipt(before);
        receipt = fault switch
        {
            "null" => null,
            "operation" => receipt with { OperationId = Guid.NewGuid() },
            "backup" => receipt with { BackupId = Guid.NewGuid() },
            "path" => receipt with { StorePath = "elsewhere" },
            "destination" => receipt with { DestinationEpoch = null! },
            "sequence" => receipt with { CommitSequence = 9 },
            _ => receipt with { DestinationEpoch = new(Guid.NewGuid(), Guid.NewGuid(), 7) }
        };
        Assert.Equal(HostLedgerTransition.Rejected, harness.Acknowledge(before, receipt)); Assert.Equal(before, harness.Read()); Assert.Null(harness.Read()!.Receipt);
    }

    /// <summary>Snapshot copies and a new empty harness supply no execution or restart authority.</summary>
    [Fact]
    public void ImmutableSnapshots_AreDescriptionsNotExecutionPlans()
    {
        var harness = Prepare("authorize"); var before = harness.Read()!; var copy = before with { Context = before.Context with { Revision = 9 } };
        Assert.Equal(HostLedgerTransition.Conflict, harness.Authorize(copy, Evidence(copy))); Assert.Equal(before, harness.Read());
        var history = harness.History(); history[0] = copy; Assert.Equal(before, Assert.Single(harness.History()));
        var restarted = new HostAttemptLedgerHarness(); Assert.Null(restarted.Read()); Assert.Empty(restarted.History());
        Assert.Equal(HostLedgerTransition.Conflict, restarted.Authorize(before, Evidence(before)));
        Assert.True(restarted.WritersMustRemainStopped);
    }

    /// <summary>Fresh absence still requires complete exclusion and no surviving plan or conflicting publication evidence.</summary>
    /// <param name="fault">Missing reconciliation precondition.</param>
    [Theory]
    [InlineData("publisher")]
    [InlineData("queue")]
    [InlineData("executor")]
    [InlineData("plan")]
    [InlineData("prior-publication")]
    [InlineData("stale")]
    [InlineData("input")]
    [InlineData("work")]
    [InlineData("route")]
    public void UnsafeAbsence_CannotReconcile(string fault)
    {
        var harness = Prepare("absent"); var before = harness.Read()!; var evidence = Evidence(before, absent: true);
        evidence = fault switch
        {
            "publisher" => evidence with { Ownership = evidence.Ownership! with { AllPriorPublishersExcluded = false } },
            "queue" => evidence with { Ownership = evidence.Ownership! with { QueuesDrained = false } },
            "executor" => evidence with { Record = evidence.Record! with { OriginalExecutor = true } },
            "plan" => evidence with { Record = evidence.Record! with { OriginalPlanAvailable = true } },
            "prior-publication" => evidence with { Flow = evidence.Flow! with { PriorPublicationKnown = true } },
            "stale" => evidence with { Publication = evidence.Publication! with { Fresh = false } },
            "input" => evidence with { Flow = evidence.Flow! with { InputStillPinned = false } },
            "work" => evidence with { Flow = evidence.Flow! with { WorkAccountingComplete = false } },
            _ => evidence with { Flow = evidence.Flow! with { RouteAcknowledgmentLost = true } }
        };
        Assert.Equal(HostLedgerTransition.Rejected, harness.ReconcileAbsent(before, evidence)); Assert.Equal(before, harness.Read());
    }

    /// <summary>An observation saves only a bound known match, never an artifact-only match or a receipt.</summary>
    /// <param name="fault">Missing or contradictory inspection fact.</param>
    [Theory]
    [InlineData("artifact")]
    [InlineData("foreign")]
    [InlineData("missing")]
    [InlineData("operation")]
    [InlineData("stale")]
    [InlineData("context")]
    public void InvalidKnownObservation_CannotBeSavedAsMatch(string fault)
    {
        var harness = Prepare("observe"); var before = harness.Read()!; var evidence = Evidence(before, known: true);
        evidence = fault switch
        {
            "artifact" => evidence with { Publication = evidence.Publication! with { State = HostPublicationState.ArtifactOnly, Observed = null } },
            "foreign" => evidence with { Publication = evidence.Publication! with { State = HostPublicationState.Foreign, Observed = null } },
            "missing" => evidence with { Publication = evidence.Publication! with { Observed = null } },
            "operation" => evidence with { Publication = evidence.Publication! with { Observed = evidence.Publication.Observed! with { OperationId = Guid.NewGuid() } } },
            "stale" => evidence with { Publication = evidence.Publication! with { Fresh = false } },
            _ => evidence with { Publication = evidence.Publication! with { Context = before.Context with { Deployment = "other" } } }
        };
        Assert.Equal(HostLedgerTransition.Rejected, harness.ObserveKnown(before, evidence)); Assert.Equal(before, harness.Read()); Assert.Null(harness.Read()!.Receipt);
    }

    /// <summary>Bootstrap intent requires a valid revision-one bound descriptor and current supplied evidence.</summary>
    /// <param name="fault">Invalid initial record.</param>
    [Theory]
    [InlineData("null")]
    [InlineData("revision")]
    [InlineData("intent")]
    [InlineData("save")]
    [InlineData("owner")]
    [InlineData("phase")]
    public void InvalidInitialIntent_DoesNotCreateRecord(string fault)
    {
        var harness = new HostAttemptLedgerHarness(); var context = Context(); HostLedgerEvidence? evidence = Evidence(new(context, HostLedgerStage.Recorded));
        evidence = fault switch
        {
            "null" => null,
            "revision" => Evidence(new(context with { Revision = 2 }, HostLedgerStage.Recorded)),
            "intent" => Evidence(new(context with { Intent = context.Intent with { AttemptId = Guid.Empty } }, HostLedgerStage.Recorded)),
            "save" => evidence with { Record = evidence.Record! with { Save = HostLedgerSave.Unknown } },
            "owner" => evidence with { Ownership = evidence.Ownership! with { CurrentOwner = false } },
            _ => evidence with { Record = evidence.Record! with { Phase = HostLedgerPhase.DispatchAuthorized } }
        };
        Assert.Equal(HostLedgerTransition.Rejected, harness.Record(evidence)); Assert.Null(harness.Read()); Assert.Empty(harness.History());
    }

    /// <summary>Concurrent owner replacements require one exact revision winner and do not confer dispatch authority.</summary>
    [Fact]
    public async Task ConcurrentTakeovers_RejectStaleOwners()
    {
        var harness = Prepare("takeover"); var before = harness.Read()!; using var start = new ManualResetEventSlim();
        var workers = Enumerable.Range(0, 8).Select(_ => Task.Run(() => { start.Wait(); return harness.TakeOver(before, Transfer(before), Guid.NewGuid(), 2); })).ToArray();
        start.Set(); var results = await Task.WhenAll(workers);
        Assert.Single(results, r => r == HostLedgerTransition.Applied); Assert.Equal(7, results.Count(r => r == HostLedgerTransition.Conflict));
        Assert.Equal(HostLedgerStage.Uncertain, harness.Read()!.Stage); Assert.Equal(2UL, harness.Read()!.Context.OwnerGeneration);
        Assert.Equal(HostLedgerTransition.Conflict, harness.MarkUncertain(before)); Assert.Equal(3, harness.History().Length);
    }

    private static HostAttemptLedgerHarness Prepare(string operation)
    {
        var harness = new HostAttemptLedgerHarness(); if (operation == "record") return harness;
        Assert.Equal(HostLedgerTransition.Applied, harness.Record(Evidence(new(Context(), HostLedgerStage.Recorded))));
        if (operation != "authorize") { var current = harness.Read()!; Assert.Equal(HostLedgerTransition.Applied, harness.Authorize(current, Evidence(current))); }
        return harness;
    }
    private static HostLedgerContext Context() => new(Guid.NewGuid(), "deployment", "resource",
        new(Guid.NewGuid(), EpochPublicationKind.LegacyMigration, "artifact", "candidate", new string('a', 64), Guid.NewGuid(), 7, 3, null, EpochProfile.ScalarWal, DurabilityMode.ProcessCrash),
        1, Guid.NewGuid(), 1);
    private static EpochPublishedReceipt Receipt(HostLedgerSnapshot snapshot)
    {
        var i = snapshot.Context.Intent; return new(i.Kind, i.AttemptId, i.BackupId, i.SourceEpoch,
            new(Guid.Parse("22222222-2222-2222-2222-222222222222"), Guid.Parse("33333333-3333-3333-3333-333333333333"), i.DocumentId), i.CommitSequence, Path.Combine(i.BundleRoot, "store"));
    }
    private static HostLedgerTakeoverEvidence Transfer(HostLedgerSnapshot snapshot) => new(snapshot.Context, true, true, true, true, true);
    private static HostLedgerEvidence Evidence(HostLedgerSnapshot snapshot, bool known = false, bool absent = false)
    {
        var c = snapshot.Context; var phase = snapshot.Stage switch
        {
            HostLedgerStage.Recorded => HostLedgerPhase.Recorded,
            HostLedgerStage.DispatchAuthorized => HostLedgerPhase.DispatchAuthorized,
            HostLedgerStage.Acknowledged => HostLedgerPhase.Acknowledged,
            _ => HostLedgerPhase.Uncertain
        };
        var original = snapshot.Stage == HostLedgerStage.Recorded && !absent;
        var r = Receipt(snapshot);
        return new(c, new(c, true, true, true, phase, HostLedgerSave.ConfirmedDurable, original, original, original, false, snapshot.Receipt),
            new(c, true, true, true, true, true), new(c, true, known ? HostPublicationState.KnownAttempt : absent ? HostPublicationState.Absent : HostPublicationState.Unknown,
                known ? new(r.Kind, r.OperationId, r.BackupId, r.SourceEpoch, r.DestinationEpoch, r.CommitSequence, r.StorePath) : null),
            new(c, true, false, false, true, true, snapshot.Observed is not null || snapshot.Receipt is not null));
    }
}
