// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies epoch data identity, lazy reads, snapshot admission and publication faults.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.4   | 27-10-2026     | Integrate admission-owned read-only epoch snapshots
// ===========================================================================================================================================================

using System.Security.Cryptography;
using System.Text;
using Bosak.XmlDb.Core;
using Xunit;
using Xunit.Abstractions;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Verifies epoch data identity, lazy reads, snapshot admission and publication faults.</summary>
public sealed class ReadOnlyEpochTests(ITestOutputHelper output) : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-epoch-read-" + Guid.NewGuid().ToString("N"));
    private string Source => Path.Combine(_area, "source");
    private string Root => Path.Combine(_area, "epoch");

    /// <summary>All IDs/order/values are preserved and an uncached child survives owner disposal without changing root bytes.</summary>
    [Fact]
    public void Snapshot_IndependentAdmission_PreservesSourceAndLazyValuesAfterOwnerDispose()
    {
        Seed(); var sourceBefore = Bytes(Source);
        var identity = EpochReadOnlyRoot.CreateFixture(Source, Root, 1, new LocalTransactionStorage());
        var before = Bytes(Root);
        using var original = ImmutableXmlSnapshot.Open(Source);
        var owner = ReadOnlyEpochDatabase.Open(Root);
        Assert.Equal(identity.StoreId, owner.StoreId); Assert.Equal(identity.EpochId, owner.EpochId); Assert.Equal(1UL, owner.DocumentId);
        var snapshot = owner.BeginRead(cacheBytes: 0);
        var second = owner.BeginRead(cacheBytes: 0);
        owner.Dispose();
        Assert.Throws<ObjectDisposedException>(() => owner.BeginRead());
        Assert.Equal(0L, snapshot.Metrics.PhysicalFragmentReads);
        Assert.Equal(0UL, snapshot.CommitSequence);
        Assert.Equal(original.NodeCount, snapshot.NodeCount);
        for (ulong id = 1; id <= (ulong)snapshot.NodeCount; id++)
        {
            var a = original.GetNode(id); var b = snapshot.GetNode(id);
            Assert.Equal(a with { Children = b.Children, Attributes = b.Attributes, Namespaces = b.Namespaces }, b);
            Assert.Equal(a.Children, b.Children); Assert.Equal(a.Attributes, b.Attributes); Assert.Equal(a.Namespaces, b.Namespaces);
            Assert.Equal(original.ReadValue(id), snapshot.ReadValue(id));
        }
        Assert.Throws<IOException>(() => EpochAdmission.Acquire(Root, identity, exclusive: true));
        snapshot.Dispose(); Assert.Throws<IOException>(() => EpochAdmission.Acquire(Root, identity, exclusive: true));
        Assert.Equal("old", second.ReadValue(Target(second)));
        second.Dispose();
        using (var maintenance = EpochAdmission.Acquire(Root, identity, exclusive: true))
            Assert.Throws<IOException>(() => ReadOnlyEpochDatabase.Open(Root));
        AssertBytes(before, Root); AssertBytes(sourceBefore, Source);
        Assert.Single(Directory.GetFiles(Root, "FORMAT", SearchOption.AllDirectories));
        Assert.False(Directory.Exists(Path.Combine(Root, ".transactions")));
    }

    /// <summary>Corrupt identity or metadata refuses opening and releases all partially acquired handles.</summary>
    /// <param name="artifact">Artifact to corrupt.</param>
    [Theory]
    [InlineData("FORMAT")]
    [InlineData("EPOCH")]
    [InlineData("SNAPSHOT")]
    [InlineData("documents/1/manifest.bin")]
    [InlineData("documents/1/directory.bin")]
    public void Open_CorruptMetadata_FailsWithoutLeakingAdmission(string artifact)
    {
        Seed(); var identity = EpochReadOnlyRoot.CreateFixture(Source, Root, 1, new LocalTransactionStorage());
        var path = Path.Combine(Root, artifact); var original = File.ReadAllBytes(path);
        File.WriteAllBytes(path, [0]);
        Assert.Throws<InvalidDataException>(() => ReadOnlyEpochDatabase.Open(Root));
        File.WriteAllBytes(path, original);
        using var exclusive = EpochAdmission.Acquire(Root, identity, exclusive: true);
    }

    /// <summary>Payload corruption is detected at lazy access, preserving admission until snapshot disposal.</summary>
    [Fact]
    public void Snapshot_CorruptLazyFragment_FailsAtReadWithoutReleasingProtection()
    {
        Seed(); var identity = EpochReadOnlyRoot.CreateFixture(Source, Root, 1, new LocalTransactionStorage());
        File.WriteAllBytes(Path.Combine(Root, "fragments", "1.bin"), [0]);
        using (var owner = ReadOnlyEpochDatabase.Open(Root))
        using (var snapshot = owner.BeginRead(cacheBytes: 0))
        {
            Assert.Equal(0L, snapshot.Metrics.PhysicalFragmentReads);
            Assert.Throws<InvalidDataException>(() => snapshot.ReadValue(Target(snapshot)));
            Assert.Throws<IOException>(() => EpochAdmission.Acquire(Root, identity, exclusive: true));
        }
        using var exclusive = EpochAdmission.Acquire(Root, identity, exclusive: true);
    }

    /// <summary>Golden snapshot bytes reject every truncation, changed epoch and rechecksummed nonzero sequence.</summary>
    [Fact]
    public void Codec_ExactGoldenDescriptor_RejectsWrongIdentityAndSequence()
    {
        Directory.CreateDirectory(Root);
        var identity = new EpochIdentity(new Guid("00112233-4455-6677-8899-aabbccddeeff"), new Guid("10213243-5465-7687-98a9-bacbdcedfe0f"), 1);
        var format = EpochCodec.EncodeFormat(identity);
        var bytes = EpochSnapshotCodec.Encode(identity, format, new byte[32]);
        Assert.Equal(Convert.FromHexString(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "TestData", "epoch-snapshot-v1.hex")).Trim()), bytes);
        File.WriteAllBytes(Path.Combine(Root, "FORMAT"), format);
        var path = Path.Combine(Root, "SNAPSHOT");
        for (var length = 0; length < bytes.Length; length++)
        {
            File.WriteAllBytes(path, bytes[..length]);
            Assert.Throws<InvalidDataException>(() => EpochSnapshotCodec.Read(Root, identity));
        }
        File.WriteAllBytes(path, bytes);
        Assert.Throws<InvalidDataException>(() => EpochSnapshotCodec.Read(Root, identity with { EpochId = Guid.NewGuid() }));
        bytes[52] = 1; SHA256.HashData(bytes.AsSpan(0, bytes.Length - 32), bytes.AsSpan(bytes.Length - 32));
        File.WriteAllBytes(path, bytes);
        Assert.Throws<InvalidDataException>(() => EpochSnapshotCodec.Read(Root, identity));
    }

    /// <summary>Metadata-only roots are not guessed into data roots and unsupported input never gains admission artifacts.</summary>
    [Fact]
    public void Open_IncompleteOrLegacyRoot_RefusesWithoutAdoptionOrLeaks()
    {
        Seed(); var before = Bytes(Source);
        Assert.Throws<InvalidDataException>(() => ReadOnlyEpochDatabase.Open(Source));
        AssertBytes(before, Source);
        var identity = EpochAdmission.CreateFixtureRoot(Root, 1, new LocalTransactionStorage());
        Assert.Throws<InvalidDataException>(() => ReadOnlyEpochDatabase.Open(Root));
        using var exclusive = EpochAdmission.Acquire(Root, identity, exclusive: true);
    }

    /// <summary>Bad cache arguments do not allocate extra child handles; bound root ownership cannot be reused elsewhere.</summary>
    [Fact]
    public void Snapshot_InvalidArgumentsOrDifferentRoot_ReleaseChildButPreserveParent()
    {
        Seed(); var identity = EpochReadOnlyRoot.CreateFixture(Source, Root, 1, new LocalTransactionStorage());
        using (var owner = ReadOnlyEpochDatabase.Open(Root))
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => owner.BeginRead(-1));
            using var snapshot = owner.BeginRead(); Assert.Equal("old", snapshot.ReadValue(Target(snapshot)));
        }
        using (var parent = EpochAdmission.Acquire(Root, identity))
        {
            Assert.Throws<InvalidDataException>(() => ImmutableXmlSnapshot.OpenEpoch(Source, parent.ForkShared(), new byte[32], 0));
        }
        using var exclusive = EpochAdmission.Acquire(Root, identity, exclusive: true);
    }

    /// <summary>The fixture producer does not silently select a head from transactional source roots.</summary>
    [Fact]
    public void Producer_TransactionalSource_RefusesAndRetainsOriginal()
    {
        Seed(); using (EmbeddedXmlDatabase.Open(Source)) { }
        var before = Bytes(Source);
        Assert.Throws<InvalidOperationException>(() => EpochReadOnlyRoot.CreateFixture(Source, Root, 1, new LocalTransactionStorage()));
        Assert.False(Directory.Exists(Root)); AssertBytes(before, Source);
    }

    /// <summary>Read-only data publication runs native directory barriers on Linux and modeled stronger policy on Windows.</summary>
    [Fact]
    public void Producer_DirectoryPolicy_PublishesVerifiedReadableRoot()
    {
        Seed(); var storage = OperatingSystem.IsLinux() ? (ITransactionStorage)new LocalTransactionStorage(DurabilityMode.FileAndDirectoryFlush)
            : new FaultingTransactionStorage(DurabilityMode.FileAndDirectoryFlush);
        EpochReadOnlyRoot.CreateFixture(Source, Root, 1, storage);
        using var owner = ReadOnlyEpochDatabase.Open(Root); using var read = owner.BeginRead();
        Assert.Equal("old", read.ReadValue(Target(read)));
    }

    /// <summary>Every observed persistence boundary and short write publishes only fully readable data or no final root.</summary>
    /// <param name="fault">Fault timing or partial write.</param>
    [Theory]
    [InlineData("before")]
    [InlineData("after")]
    [InlineData("partial")]
    public void Producer_InjectedFailure_NeverPublishesIncompleteSnapshot(string fault)
    {
        Seed(); var before = Bytes(Source);
        var recording = new FaultingTransactionStorage(); recording.Arm();
        EpochReadOnlyRoot.CreateFixture(Source, Path.Combine(_area, "reference"), 1, recording);
        var calls = recording.Calls.Select((call, index) => (call, index)).Where(item => fault == "partial"
            ? item.call.Operation == "WriteFile" && item.call.Moment == "before" : item.call.Moment == fault).ToArray();
        foreach (var (_, index) in calls)
        {
            var target = Path.Combine(_area, "attempt-" + index); var storage = new FaultingTransactionStorage(); storage.Arm(index, fault == "partial");
            Assert.Throws<IOException>(() => EpochReadOnlyRoot.CreateFixture(Source, target, 1, storage)); Assert.True(storage.Fired);
            if (Directory.Exists(target))
            {
                using var owner = ReadOnlyEpochDatabase.Open(target); using var snapshot = owner.BeginRead(cacheBytes: 0);
                Assert.Equal("old", snapshot.ReadValue(Target(snapshot)));
            }
            AssertBytes(before, Source);
        }
        Assert.NotEmpty(calls);
        output.WriteLine($"epoch-readonly/{fault}: {calls.Length} fault positions verified.");
    }

    /// <summary>Read-only selection never ignores an unsupported mutable transaction tree or marker.</summary>
    /// <param name="directory">Whether transaction state is a directory instead of a file.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Open_UnexpectedTransactionState_RefusesWithoutAdmissionLeak(bool directory)
    {
        Seed(); var identity = EpochReadOnlyRoot.CreateFixture(Source, Root, 1, new LocalTransactionStorage());
        var path = Path.Combine(Root, ".transactions");
        if (directory) Directory.CreateDirectory(path); else File.WriteAllText(path, "unsupported");
        Assert.Throws<InvalidDataException>(() => ReadOnlyEpochDatabase.Open(Root));
        using var exclusive = EpochAdmission.Acquire(Root, identity, exclusive: true);
    }

    private void Seed()
    {
        Directory.CreateDirectory(_area);
        using var xml = new MemoryStream(Encoding.UTF8.GetBytes("<SalesOrder><SalesOrderHeader><DocumentID>old</DocumentID></SalesOrderHeader><SalesOrderLine>line</SalesOrderLine></SalesOrder>"));
        XmlFragmentImporter.Import(xml, Source, linesPerFragment: 1);
    }
    private static ulong Target(ImmutableXmlSnapshot snapshot) => Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id))
        .Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();
    private static Dictionary<string, byte[]> Bytes(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories).ToDictionary(path => Path.GetRelativePath(root, path), File.ReadAllBytes);
    private static void AssertBytes(Dictionary<string, byte[]> before, string root)
    { var after = Bytes(root); Assert.Equal(before.Keys.Order(), after.Keys.Order()); foreach (var pair in before) Assert.Equal(pair.Value, after[pair.Key]); }
    /// <inheritdoc />
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
