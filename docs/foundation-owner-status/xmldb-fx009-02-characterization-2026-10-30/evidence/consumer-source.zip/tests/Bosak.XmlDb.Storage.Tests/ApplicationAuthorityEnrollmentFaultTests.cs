// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 30 October 2026
// PURPOSE              : Qualifies observed first-enrollment I/O faults, native identities and closing schedules.
// SPECIAL NOTES        : EF4 actual ProcessCrash file delegation; no physical power-loss or reclamation claim.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 30-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Bosak.XmlDb.Core;
using Xunit;
using Xunit.Abstractions;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Qualifies observed first-enrollment I/O faults, native identities and closing schedules.</summary>
/// <param name="output">Captures machine-readable qualification evidence.</param>
public sealed class ApplicationAuthorityEnrollmentFaultTests(ITestOutputHelper output) : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ef4-" + Guid.NewGuid().ToString("N"));
    private int _ordinal;
    private Fixture NewFixture() => new(Path.Combine(_area, (++_ordinal).ToString("D6", System.Globalization.CultureInfo.InvariantCulture)));
    /// <summary>Every observed call edge and every physically incomplete frame prefix preserves exact surviving bytes.</summary>
    [Fact]
    public void Append_ObservedTraceAndEveryPartialWrite_RetainsExactStoppedOutcome()
    {
        var watch = Stopwatch.StartNew(); string[] trace; int frameLength;
        using (var baseline = NewFixture())
        {
            var io = new TraceIo(); var result = baseline.AuthorityOwner.AppendFirstEnrollmentCore(baseline.Plan, baseline.EvidenceValue, io);
            Assert.Equal(ApplicationEnrollmentAppendDisposition.AcknowledgedStopped, result.Disposition);
            trace = io.Trace.ToArray(); frameLength = io.Request.Length; Assert.Equal(new[] { "Write:before", "Write:after", "Flush:before", "Flush:after", "ReadBack:before", "ReadBack:after" }, trace);
        }
        foreach (var point in trace) RunFault(point, null);
        for (var position = 1; position < frameLength; position++) RunFault(null, position);
        output.WriteLine("EF4_TRACE " + JsonSerializer.Serialize(new { Platform = OperatingSystem.IsWindows() ? "Windows" : "Linux", FrameBytes = frameLength, Trace = trace, CallEdgeFaults = trace.Length, PartialWriteFaults = frameLength - 1, AttemptsIncludingBaseline = frameLength + trace.Length, ElapsedMilliseconds = watch.ElapsedMilliseconds }));

        void RunFault(string? edge, int? prefix)
        {
            using var fixture = NewFixture(); var before = fixture.Bytes(); var io = new TraceIo(edge, prefix);
            var result = fixture.AuthorityOwner.AppendFirstEnrollmentCore(fixture.Plan, fixture.EvidenceValue, io);
            Assert.Equal(frameLength, io.Request.Length);
            var metadata = ApplicationAuthorityCodec.DecodeMetadata(ApplicationAuthorityCodec.EncodeMetadata(fixture.Configuration), fixture.Configuration);
            Assert.Equal(ApplicationAuthorityCodec.EncodeFrame(metadata, 1, new string('0', 64), fixture.Plan.Description.Entry), io.Request);
            Assert.Equal(prefix.HasValue ? trace.Take(1) : trace.Take(Array.IndexOf(trace, edge!) + 1), io.Trace);
            Assert.IsType<IOException>(result.Error);
            Assert.Equal(ApplicationEnrollmentAppendDisposition.Uncertain, result.Disposition); Assert.True(result.PossibleOutput); Assert.False(result.ReleaseUnknown); Assert.Null(result.Receipt); Assert.Null(fixture.AuthorityOwner.ConfirmedEnrollment); Assert.True(fixture.AuthorityOwner.IsFaulted); Assert.True(fixture.SourceOwner.EnrollmentOwnershipStatus.StopLatched);
            var expected = prefix is { } n ? io.Request[..n] : edge == "Write:before" ? [] : io.Request;
            Assert.Equal(expected, fixture.ReadLog()); before[Path.Combine("authority", "authority.log")] = expected; fixture.AssertBytes(before);
            Assert.Throws<InvalidOperationException>(() => fixture.AuthorityOwner.AppendFirstEnrollment(fixture.Plan, fixture.EvidenceValue));
            fixture.CloseOwners(); fixture.AssertBytes(before); Assert.True(fixture.AuthorityOwner.IsReleased); Assert.True(fixture.ParentOwner.IsReleased);
            using var parent = EmbeddedHostLifetime.OpenExisting(fixture.Host, "pilot", "orders", [fixture.Source, fixture.Capture, fixture.Authority]);
            if (prefix.HasValue)
            {
                for (var repeat = 0; repeat < 2; repeat++) Assert.Throws<InvalidDataException>(() => ApplicationAuthorityLifetime.OpenExisting(parent, parent.JournalStatus.KnownPosition, new(parent.Context, true, true, true, true, true), fixture.Authority, fixture.Configuration, fixture.Roots));
            }
            else
            {
                using var observed = ApplicationAuthorityLifetime.OpenExisting(parent, parent.JournalStatus.KnownPosition, new(parent.Context, true, true, true, true, true), fixture.Authority, fixture.Configuration, fixture.Roots);
                Assert.Equal(expected.Length == 0 ? 0 : 1, observed.Inspect().Frames.Length); Assert.True(observed.WritersMustRemainStopped); Assert.Throws<InvalidOperationException>(() => observed.ReserveInitializer());
            }
            fixture.AssertBytes(before); Assert.Equal("new-0", fixture.Snapshot.ReadValue(Target(fixture.Snapshot)));
        }
    }
    /// <summary>Closing from another thread during actual I/O cannot release any retained owner prematurely.</summary>
    /// <param name="point">I/O delegation to overlap with owner closing.</param>
    [Theory]
    [InlineData("Write:before")]
    [InlineData("Flush:before")]
    [InlineData("ReadBack:before")]
    public void Append_OwnersCloseDuringIo_ActualOperationDrainsAfterIo(string point)
    {
        using var fixture = NewFixture(); using var entered = new ManualResetEventSlim(); using var closed = new ManualResetEventSlim(); Exception? error = null;
        var worker = new Thread(() =>
        {
            try
            {
                if (!entered.Wait(TimeSpan.FromSeconds(30))) throw new TimeoutException();
                fixture.SourceOwner.Dispose(); fixture.AuthorityOwner.Dispose(); fixture.ParentOwner.Dispose();
                Assert.False(fixture.AuthorityOwner.IsReleased); Assert.False(fixture.ParentOwner.IsReleased); Assert.Equal(EnrollmentSourceReleaseState.RetainedClosing, fixture.SourceOwner.EnrollmentOwnershipStatus.ReleaseState);
            }
            catch (Exception caught) { error = caught; }
            finally { closed.Set(); }
        })
        { IsBackground = true };
        worker.Start();
        var io = new TraceIo(checkpoint: edge => { if (edge != point) return; entered.Set(); if (!closed.Wait(TimeSpan.FromSeconds(30))) throw new TimeoutException(); });
        var result = fixture.AuthorityOwner.AppendFirstEnrollmentCore(fixture.Plan, fixture.EvidenceValue, io);
        Assert.True(worker.Join(TimeSpan.FromSeconds(30))); Assert.Null(error); Assert.Equal(ApplicationEnrollmentAppendDisposition.AcknowledgedStopped, result.Disposition); Assert.True(fixture.AuthorityOwner.IsReleased); Assert.True(fixture.ParentOwner.IsReleased); Assert.Equal(EnrollmentSourceReleaseState.Released, fixture.SourceOwner.EnrollmentOwnershipStatus.ReleaseState);
        Assert.Equal("new-0", fixture.Snapshot.ReadValue(Target(fixture.Snapshot)));
    }
    /// <summary>Actual Linux inode substitutions fail without repairing or adopting an otherwise valid replacement.</summary>
    /// <param name="role">Native identity to substitute.</param>
    /// <param name="afterOutput">Whether output already occurred.</param>
    [Theory]
    [InlineData("authority.lock", false)]
    [InlineData("authority.meta", false)]
    [InlineData("authority.log", false)]
    [InlineData("root", false)]
    [InlineData("authority.lock", true)]
    [InlineData("authority.meta", true)]
    [InlineData("authority.log", true)]
    [InlineData("root", true)]
    public void Append_NativeIdentitySubstitution_StopsWithoutRepair(string role, bool afterOutput)
    {
        if (!OperatingSystem.IsLinux()) { output.WriteLine("EF4_NATIVE_GUARD Windows sharing prevents this Linux inode-substitution body."); return; }
        using var fixture = NewFixture(); Dictionary<string, byte[]>? invalid = null; string[]? inventory = null;
        var io = new TraceIo(); var result = fixture.AuthorityOwner.AppendFirstEnrollmentCore(fixture.Plan, fixture.EvidenceValue, io, stage =>
        {
            if (stage != (afterOutput ? ApplicationEnrollmentAppendStage.BeforeAcknowledge : ApplicationEnrollmentAppendStage.Validated)) return;
            if (role == "root")
            {
                var retained = fixture.Authority + "-retained"; Directory.Move(fixture.Authority, retained); Directory.CreateDirectory(fixture.Authority);
                File.WriteAllBytes(Path.Combine(fixture.Authority, "authority.lock"), []); File.WriteAllBytes(Path.Combine(fixture.Authority, "authority.meta"), ApplicationAuthorityCodec.EncodeMetadata(fixture.Configuration)); File.WriteAllBytes(Path.Combine(fixture.Authority, "authority.log"), []);
            }
            else
            {
                var path = Path.Combine(fixture.Authority, role); var bytes = role == "authority.lock" ? [] : ReadShared(path);
                File.Move(path, Path.Combine(Path.GetDirectoryName(fixture.Authority)!, "retained-" + role)); File.WriteAllBytes(path, bytes);
            }
            invalid = fixture.Bytes(); inventory = Directory.GetFileSystemEntries(Path.GetDirectoryName(fixture.Authority)!, "*", SearchOption.AllDirectories).Order().ToArray();
        });
        Assert.Equal(afterOutput ? ApplicationEnrollmentAppendDisposition.Uncertain : ApplicationEnrollmentAppendDisposition.RefusedBeforeWrite, result.Disposition); Assert.Equal(afterOutput, result.PossibleOutput); Assert.Null(result.Receipt); Assert.True(fixture.AuthorityOwner.IsFaulted); Assert.NotNull(invalid); fixture.AssertBytes(invalid); Assert.Equal(inventory, Directory.GetFileSystemEntries(Path.GetDirectoryName(fixture.Authority)!, "*", SearchOption.AllDirectories).Order().ToArray());
        Assert.Equal(afterOutput ? 1 : 0, io.Trace.Count(e => e == "Write:before")); output.WriteLine("EF4_NATIVE_EXECUTED " + role + " afterOutput=" + afterOutput);
    }
    private static byte[] ReadShared(string path) { using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite); var bytes = new byte[(int)stream.Length]; stream.ReadExactly(bytes); return bytes; }
    private static ulong Target(ImmutableXmlSnapshot snapshot) => Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();
    private sealed class TraceIo(string? fail = null, int? partial = null, Action<string>? checkpoint = null) : IApplicationAuthorityAppendIo
    {
        internal List<string> Trace { get; } = [];
        internal byte[] Request { get; private set; } = [];
        private void At(string edge) { Trace.Add(edge); checkpoint?.Invoke(edge); if (edge == fail) throw new IOException("Observed fault " + edge); }
        /// <inheritdoc/>
        public void Write(FileStream stream, ReadOnlySpan<byte> bytes)
        {
            Request = bytes.ToArray(); At("Write:before");
            if (partial is { } n) { stream.Write(bytes[..n]); stream.Flush(); throw new IOException("Actual partial output " + n); }
            stream.Write(bytes); At("Write:after");
        }
        /// <inheritdoc/>
        public void Flush(FileStream stream) { At("Flush:before"); stream.Flush(true); At("Flush:after"); }
        /// <inheritdoc/>
        public void ReadBack(FileStream stream, Span<byte> bytes) { At("ReadBack:before"); stream.ReadExactly(bytes); At("ReadBack:after"); }
    }
    private sealed class Fixture : IDisposable
    {
        private readonly string _area;
        internal Fixture(string area) { _area = area; Seed(); SourceOwner = EmbeddedXmlDatabase.Open(Source); Snapshot = SourceOwner.BeginRead(); ParentOwner = Parent(); AuthorityOwner = Provision(ParentOwner); Freeze = MigrationSourceFreeze.Acquire(SourceOwner, true); CaptureEvidence = Freeze.Capture(Capture); EvidenceValue = Evidence(ParentOwner); Plan = AuthorityOwner.PrepareRetainedFirstEnrollment(Freeze, CaptureEvidence, EvidenceValue); }
        internal EmbeddedXmlDatabase SourceOwner { get; }
        internal ImmutableXmlSnapshot Snapshot { get; }
        internal EmbeddedHostLifetime ParentOwner { get; }
        internal ApplicationAuthorityLifetime AuthorityOwner { get; }
        internal MigrationSourceFreeze Freeze { get; }
        internal FrozenMigrationCapture CaptureEvidence { get; }
        internal ApplicationEnrollmentEvidence EvidenceValue { get; }
        internal ApplicationAuthorityLifetime.RetainedEnrollmentPreparation Plan { get; }
        internal string Source => Path.Combine(_area, "source");
        internal string Capture => Path.Combine(_area, "capture");
        internal string Host => Path.Combine(_area, "host");
        internal string Authority => Path.Combine(_area, "authority");
        private readonly Guid _admin = Guid.NewGuid();
        internal ApplicationAuthorityConfiguration Configuration => new(Guid.Parse("10213243-5465-7687-98a9-bacbdcedfe0f"), _admin, "pilot", "orders", "admin", "authority");
        internal Dictionary<string, string> Roots => new() { ["admin"] = Host, ["authority"] = Authority, ["source"] = Source, ["capture"] = Capture };
        private static EmbeddedHostInspectionEvidence Inspection(EmbeddedHostLifetime parent) => new(parent.Context, true, true, true, true, true);
        private ApplicationEnrollmentEvidence Evidence(EmbeddedHostLifetime parent) => new(parent.Context, Configuration.AuthorityId, "source", "source-admission", "capture", Guid.NewGuid(), new string('a', 64), true, true, true, true, true, true);
        private EmbeddedHostLifetime Parent()
        {
            Directory.CreateDirectory(Host); File.WriteAllBytes(Path.Combine(Host, "owner.lock"), []);
            File.WriteAllBytes(Path.Combine(Host, "host.meta"), HostJournalCodec.EncodeMetadata(_admin, "pilot", "orders")); File.WriteAllBytes(Path.Combine(Host, "journal.bin"), []);
            return EmbeddedHostLifetime.OpenExisting(Host, "pilot", "orders", [Source, Capture, Authority]);
        }
        private ApplicationAuthorityLifetime Provision(EmbeddedHostLifetime parent) => ApplicationAuthorityLifetime.Provision(parent, parent.JournalStatus.KnownPosition, Inspection(parent), Authority, Configuration, Roots, new(Authority, true, true, true));
        private void Seed(int count = 1)
        {
            Directory.CreateDirectory(_area); using var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>")); XmlFragmentImporter.Import(input, Source);
            using var source = EmbeddedXmlDatabase.Open(Source);
            for (var i = 0; i < count; i++) { using var read = source.BeginRead(); using var tx = source.BeginWrite(); tx.ReplaceNodeValue(Target(read), "new-" + i); tx.Commit(); }
        }
        private static byte[] ReadShared(string path) { using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite); var bytes = new byte[(int)stream.Length]; stream.ReadExactly(bytes); return bytes; }
        private static ulong Target(ImmutableXmlSnapshot snapshot) => Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();
        internal Dictionary<string, byte[]> Bytes()
        {
            var result = new Dictionary<string, byte[]>();
            foreach (var path in Directory.GetFiles(_area, "*", SearchOption.AllDirectories).Where(p => Path.GetFileName(p) is not ("owner.lock" or "authority.lock" or "writer.lock" or "retained-authority.lock")))
            {
                using var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                var bytes = new byte[(int)file.Length]; file.ReadExactly(bytes); result.Add(Path.GetRelativePath(_area, path), bytes);
            }
            return result;
        }
        internal void AssertBytes(Dictionary<string, byte[]> before)
        {
            var after = Bytes(); Assert.Equal(before.Keys.Order(), after.Keys.Order()); foreach (var pair in before) Assert.Equal(pair.Value, after[pair.Key]);
        }



        internal byte[] ReadLog()
        { using var stream = new FileStream(Path.Combine(Authority, "authority.log"), FileMode.Open, FileAccess.Read, FileShare.ReadWrite); var bytes = new byte[(int)stream.Length]; stream.ReadExactly(bytes); return bytes; }
        internal void CloseOwners() { Plan.Dispose(); Freeze.Dispose(); SourceOwner.Dispose(); AuthorityOwner.Dispose(); ParentOwner.Dispose(); }
        /// <summary>Drains only this fixture's actual handles; no store history is removed.</summary>
        public void Dispose() { CloseOwners(); Snapshot.Dispose(); }
    }
    /// <summary>Deletes only the fresh owned fixture tree after every real handle has drained.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
