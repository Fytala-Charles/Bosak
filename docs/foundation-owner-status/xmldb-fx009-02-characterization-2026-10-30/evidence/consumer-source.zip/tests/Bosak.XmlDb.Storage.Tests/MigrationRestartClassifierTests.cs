// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Verifies pure restart classification across routing, missing evidence and stale commitments.
// SPECIAL NOTES        : HC1 supplied-observation model only; no real host or write-resume qualification.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 28-10-2026     | Cover malformed null identity with a conservative reconciliation result
// ===========================================================================================================================================================

using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Qualifies restart classification without a host, filesystem, recovery or routing service.</summary>
public sealed class MigrationRestartClassifierTests
{
    /// <summary>Every intent/outcome/route combination stays stopped and yields only the specified new-workflow eligibility.</summary>
    /// <param name="intent">Candidate switch or legacy return.</param>
    /// <param name="outcome">Recorded request outcome.</param>
    /// <param name="route">Fresh authoritative observed target.</param>
    /// <param name="expected">Expected classification.</param>
    [Theory]
    [InlineData(0, 0, 0, 0)]
    [InlineData(0, 0, 1, 1)]
    [InlineData(0, 0, 2, 0)]
    [InlineData(0, 0, 3, 0)]
    [InlineData(0, 1, 0, 0)]
    [InlineData(0, 1, 1, 2)]
    [InlineData(0, 1, 2, 0)]
    [InlineData(0, 1, 3, 0)]
    [InlineData(0, 2, 0, 0)]
    [InlineData(0, 2, 1, 0)]
    [InlineData(0, 2, 2, 3)]
    [InlineData(0, 2, 3, 0)]
    [InlineData(0, 3, 0, 0)]
    [InlineData(0, 3, 1, 2)]
    [InlineData(0, 3, 2, 3)]
    [InlineData(0, 3, 3, 0)]
    [InlineData(1, 0, 0, 0)]
    [InlineData(1, 0, 1, 0)]
    [InlineData(1, 0, 2, 0)]
    [InlineData(1, 0, 3, 0)]
    [InlineData(1, 1, 0, 0)]
    [InlineData(1, 1, 1, 0)]
    [InlineData(1, 1, 2, 3)]
    [InlineData(1, 1, 3, 0)]
    [InlineData(1, 2, 0, 0)]
    [InlineData(1, 2, 1, 2)]
    [InlineData(1, 2, 2, 0)]
    [InlineData(1, 2, 3, 0)]
    [InlineData(1, 3, 0, 0)]
    [InlineData(1, 3, 1, 2)]
    [InlineData(1, 3, 2, 3)]
    [InlineData(1, 3, 3, 0)]
    public void RoutingMatrix_AllCombinations_NeverResumeWriters(int intent, int outcome, int route, int expected)
    {
        var input = Good(); var target = (RestartRoute)route;
        input = input with
        {
            Routing = input.Routing! with
            {
                Intent = (RestartIntent)intent,
                Outcome = (RestartOutcome)outcome,
                Target = target,
                TargetRoot = target == RestartRoute.Candidate ? input.Expected!.CandidateRoot : input.Expected!.SourceRoot,
                TargetEpoch = target == RestartRoute.Candidate ? input.Expected.CandidateIdentity : null
            }
        };
        var result = MigrationRestartClassifier.Classify(input);
        Assert.Equal((RestartDecision)expected, result.Decision); Assert.True(result.WritersMustRemainStopped);
    }

    /// <summary>Missing, stale, contradictory and unbound observations cannot become readiness evidence.</summary>
    /// <param name="fault">Fault injected into otherwise eligible observations.</param>
    /// <param name="reason">Expected conservative diagnostic.</param>
    [Theory]
    [InlineData("missing-expected", 2)]
    [InlineData("missing-owner", 2)]
    [InlineData("missing-history", 2)]
    [InlineData("missing-work", 2)]
    [InlineData("missing-route", 2)]
    [InlineData("stale-owner", 5)]
    [InlineData("stale-history", 5)]
    [InlineData("stale-work", 5)]
    [InlineData("stale-route", 5)]
    [InlineData("no-exclusion", 6)]
    [InlineData("possible-overlap", 6)]
    [InlineData("lost-owners", 6)]
    [InlineData("source-unknown", 7)]
    [InlineData("source-changed", 7)]
    [InlineData("candidate-unknown", 7)]
    [InlineData("candidate-changed", 7)]
    [InlineData("work-unknown", 8)]
    [InlineData("work-accepted", 8)]
    [InlineData("work-contradictory", 8)]
    [InlineData("not-authoritative", 9)]
    [InlineData("blank-revision", 10)]
    [InlineData("wrong-revision", 10)]
    [InlineData("blank-confirmation", 10)]
    [InlineData("wrong-root", 11)]
    [InlineData("wrong-epoch", 11)]
    [InlineData("legacy-fake-epoch", 11)]
    [InlineData("invalid-intent", 12)]
    [InlineData("invalid-outcome", 12)]
    [InlineData("unbound-owner", 4)]
    [InlineData("unbound-history", 4)]
    [InlineData("unbound-work", 4)]
    [InlineData("unbound-route", 4)]
    [InlineData("empty-operation", 3)]
    [InlineData("empty-migration", 3)]
    [InlineData("empty-backup", 3)]
    [InlineData("empty-store", 3)]
    [InlineData("empty-epoch", 3)]
    [InlineData("zero-document", 3)]
    [InlineData("oversized-history", 3)]
    [InlineData("empty-source-root", 3)]
    [InlineData("empty-candidate-root", 3)]
    [InlineData("aliased-roots", 3)]
    [InlineData("bad-source-hash", 3)]
    [InlineData("bad-candidate-hash", 3)]
    [InlineData("same-H-different-source", 4)]
    [InlineData("same-H-different-candidate", 4)]
    public void EvidenceFaults_RequireReconciliation(string fault, int reason)
    {
        var input = Good(); var context = input.Expected!;
        var changed = context with { OperationId = Guid.Parse("99999999-1111-2222-3333-444444444444") };
        input = fault switch
        {
            "missing-expected" => input with { Expected = null },
            "missing-owner" => input with { Ownership = null },
            "missing-history" => input with { Histories = null },
            "missing-work" => input with { Work = null },
            "missing-route" => input with { Routing = null },
            "stale-owner" => input with { Ownership = input.Ownership! with { Fresh = false } },
            "stale-history" => input with { Histories = input.Histories! with { Fresh = false } },
            "stale-work" => input with { Work = input.Work! with { Fresh = false } },
            "stale-route" => input with { Routing = input.Routing! with { Fresh = false } },
            "no-exclusion" => input with { Ownership = input.Ownership! with { ExternalExclusionEstablished = false } },
            "possible-overlap" => input with { Ownership = input.Ownership! with { NoPossibleWriterOverlap = false } },
            "lost-owners" => input with { Ownership = input.Ownership! with { OwnersReacquired = false } },
            "source-unknown" => input with { Histories = input.Histories! with { Source = RestartHistory.Unknown } },
            "source-changed" => input with { Histories = input.Histories! with { Source = RestartHistory.Changed } },
            "candidate-unknown" => input with { Histories = input.Histories! with { Candidate = RestartHistory.Unknown } },
            "candidate-changed" => input with { Histories = input.Histories! with { Candidate = RestartHistory.Changed } },
            "work-unknown" => input with { Work = input.Work! with { State = RestartWork.Unknown } },
            "work-accepted" => input with { Work = input.Work! with { State = RestartWork.Accepted } },
            "work-contradictory" => input with { Work = input.Work! with { State = RestartWork.Contradictory } },
            "not-authoritative" => input with { Routing = input.Routing! with { Authoritative = false } },
            "blank-revision" => input with { Routing = input.Routing! with { Revision = " " } },
            "wrong-revision" => input with { Routing = input.Routing! with { Revision = "older" } },
            "blank-confirmation" => input with { Routing = input.Routing! with { ConfirmedRevision = "" } },
            "wrong-root" => input with { Routing = input.Routing! with { TargetRoot = "different-root" } },
            "wrong-epoch" => input with { Routing = input.Routing! with { TargetEpoch = context.CandidateIdentity with { EpochId = changed.OperationId } } },
            "legacy-fake-epoch" => input with { Routing = input.Routing! with { Target = RestartRoute.Legacy, TargetRoot = context.SourceRoot, Outcome = RestartOutcome.KnownNotApplied } },
            "invalid-intent" => input with { Routing = input.Routing! with { Intent = (RestartIntent)99 } },
            "invalid-outcome" => input with { Routing = input.Routing! with { Outcome = (RestartOutcome)99 } },
            "unbound-owner" => input with { Ownership = input.Ownership! with { Context = changed } },
            "unbound-history" => input with { Histories = input.Histories! with { Context = changed } },
            "unbound-work" => input with { Work = input.Work! with { Context = changed } },
            "unbound-route" => input with { Routing = input.Routing! with { Context = changed } },
            "empty-operation" => input with { Expected = context with { OperationId = Guid.Empty } },
            "empty-migration" => input with { Expected = context with { MigrationId = Guid.Empty } },
            "empty-backup" => input with { Expected = context with { BackupId = Guid.Empty } },
            "empty-store" => input with { Expected = context with { CandidateIdentity = context.CandidateIdentity with { StoreId = Guid.Empty } } },
            "empty-epoch" => input with { Expected = context with { CandidateIdentity = context.CandidateIdentity with { EpochId = Guid.Empty } } },
            "zero-document" => input with { Expected = context with { CandidateIdentity = context.CandidateIdentity with { DocumentId = 0 } } },
            "oversized-history" => input with { Expected = context with { Sequence = 10_001 } },
            "empty-source-root" => input with { Expected = context with { SourceRoot = " " } },
            "empty-candidate-root" => input with { Expected = context with { CandidateRoot = "" } },
            "aliased-roots" => input with { Expected = context with { CandidateRoot = context.SourceRoot.ToUpperInvariant() } },
            "bad-source-hash" => input with { Expected = context with { SourceCommitment = new string('g', 64) } },
            "bad-candidate-hash" => input with { Expected = context with { CandidateCommitment = "00" } },
            "same-H-different-source" => input with { Histories = input.Histories! with { Context = context with { SourceCommitment = new string('c', 64) } } },
            "same-H-different-candidate" => input with { Histories = input.Histories! with { Context = context with { CandidateCommitment = new string('d', 64) } } },
            _ => throw new ArgumentException("Unknown fault.", nameof(fault)),
        };
        var result = MigrationRestartClassifier.Classify(input);
        Assert.Equal(RestartDecision.ReconciliationRequired, result.Decision); Assert.Equal((RestartReason)reason, result.Reason);
        Assert.True(result.WritersMustRemainStopped);
    }

    /// <summary>Null input fails closed; immutable supplied records can be classified concurrently without mutation.</summary>
    [Fact]
    public void Classification_NullAndConcurrentCalls_ArePureAndKeepWritersStopped()
    {
        Assert.Equal(new(RestartDecision.ReconciliationRequired, RestartReason.MissingEvidence), MigrationRestartClassifier.Classify(null));
        var input = Good(); var before = input with { };
        Parallel.For(0, 1000, _ => Assert.Equal(new(RestartDecision.NewCandidateReadinessEligible, RestartReason.ReadyForNewWorkflow), MigrationRestartClassifier.Classify(input)));
        Assert.Equal(before, input); Assert.True(MigrationRestartClassifier.Classify(input).WritersMustRemainStopped);
    }

    /// <summary>A malformed nonnullable candidate identity is invalid evidence, not an unhandled classifier failure.</summary>
    [Fact]
    public void Classification_NullCandidateIdentity_ReconcilesWithoutDereference()
    {
        var input = Good(); var context = input.Expected! with { CandidateIdentity = null! };
        input = input with
        {
            Expected = context,
            Ownership = input.Ownership! with { Context = context },
            Histories = input.Histories! with { Context = context },
            Work = input.Work! with { Context = context },
            Routing = input.Routing! with { Context = context, TargetEpoch = null }
        };
        var result = MigrationRestartClassifier.Classify(input);
        Assert.Equal(RestartDecision.ReconciliationRequired, result.Decision); Assert.Equal(RestartReason.InvalidContext, result.Reason);
        Assert.True(result.WritersMustRemainStopped);
    }

    private static RestartObservations Good()
    {
        var context = new RestartContext(Guid.Parse("11111111-1111-2222-3333-444444444444"), Guid.Parse("22222222-1111-2222-3333-444444444444"),
            Guid.Parse("33333333-1111-2222-3333-444444444444"), new(Guid.Parse("44444444-1111-2222-3333-444444444444"), Guid.Parse("55555555-1111-2222-3333-444444444444"), 1),
            "canonical-source-key", "canonical-candidate-key", 3, new string('a', 64), new string('b', 64));
        return new(context, new(context, true, true, true, true), new(context, true, RestartHistory.ExactInitial, RestartHistory.ExactInitial),
            new(context, true, RestartWork.ZeroAcceptedAndDrained), new(context, true, true, "revision-8", "revision-8", RestartRoute.Candidate,
                context.CandidateRoot, context.CandidateIdentity, RestartIntent.Candidate, RestartOutcome.KnownApplied));
    }
}
