// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies epoch backup metadata bytes, bounded parsing and pure context rejection.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Buffers.Binary;
using System.Security.Cryptography;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Verifies pure epoch backup metadata codecs without creating stores or granting admission.</summary>
public sealed class EpochBackupCodecTests
{
    private static readonly Guid BackupId = new("20314253-6475-8697-a8b9-cadbecfd0e1f");
    private static EpochIdentity Source => new(new("00112233-4455-6677-8899-aabbccddeeff"), new("10213243-5465-7687-98a9-bacbdcedfe0f"), 1);
    private static EpochIdentity Destination => new(new("30415263-7485-96a7-b8c9-daebfc0d1e2f"), new("40516273-8495-a6b7-c8d9-eafb0c1d2e3f"), 1);
    private static byte[] SourceFormat => Hex("epoch-mutable-format-v2.hex");
    private static byte[] DestinationFormat => EpochCodec.EncodeProfile(Destination, EpochProfile.ScalarWal);
    private static byte[] Range(int first) => Enumerable.Range(first, 32).Select(value => (byte)value).ToArray();
    private static EpochBackupInventory Inventory() => new(BackupId, EpochAuthorityBinding.Create(SourceFormat, Range(1)), 2, Range(33), Range(65),
        [new("BASE", 157, Range(129)), new("FORMAT", 99, SHA256.HashData(SourceFormat))]);
    private static EpochRestoreOrigin Origin()
    {
        var value = Inventory(); return new(new("50617283-94a5-b6c7-d8e9-fa0b1c2d3e4f"), BackupId, SHA256.HashData(Fixture("inventory")),
            value.Source, Destination, 2, SHA256.HashData(DestinationFormat), value.HeadManifestHash, value.HeadWalHash, Range(97));
    }

    /// <summary>Independent golden bytes roundtrip and every truncation, role substitution or malformed envelope fails.</summary>
    /// <param name="role">Metadata role.</param>
    [Theory]
    [InlineData("inventory")]
    [InlineData("completion")]
    [InlineData("origin")]
    public void Codec_GoldenBytes_RejectsEveryTruncationAndFramingOrRoleSubstitution(string role)
    {
        var expected = Fixture(role); Assert.Equal(expected, Encode(role)); Assert.Equal(expected, Reencode(role, expected));
        var digest = role switch
        {
            "inventory" => "5847abe5c14bcbe2fe7df72b40f8a40493baea77445e1c38aa94532f904049c3",
            "completion" => "7106e4f2081fc347942f39d97e481ed9a7a0faf68fb08970c05e7a7f21befd00",
            _ => "3690253d1fcbce489f2fd5b29d733d2c4e333bfdfa4b04816fd348336bbcadb4"
        };
        Assert.Equal(digest, Convert.ToHexString(SHA256.HashData(expected)).ToLowerInvariant());
        for (var length = 0; length < expected.Length; length++) Assert.Throws<InvalidDataException>(() => Reencode(role, expected[..length]));
        foreach (var offset in new[] { 0, 4, 6, 8 })
        { var bad = (byte[])expected.Clone(); bad[offset] ^= 127; Seal(bad); Assert.Throws<InvalidDataException>(() => Reencode(role, bad)); }
        var checksum = (byte[])expected.Clone(); checksum[^1] ^= 1; Assert.Throws<InvalidDataException>(() => Reencode(role, checksum));
        Assert.Throws<InvalidDataException>(() => Reencode(role, expected.Concat(new byte[] { 0 }).ToArray()));
        var extraBody = new byte[expected.Length + 1]; expected.AsSpan(0, expected.Length - 32).CopyTo(extraBody);
        BinaryPrimitives.WriteInt32LittleEndian(extraBody.AsSpan(8), expected.Length - 43); Seal(extraBody);
        Assert.Throws<InvalidDataException>(() => Reencode(role, extraBody));
        foreach (var other in new[] { "inventory", "completion", "origin" }.Where(other => other != role))
            Assert.Throws<InvalidDataException>(() => Reencode(role, Fixture(other)));
        foreach (var legacy in new[] { "backup-inventory-v1.hex", "backup-completion-v1.hex", "epoch-base-v1.hex", "epoch-current-v1.hex" })
            Assert.Throws<InvalidDataException>(() => Reencode(role, Hex(legacy)));
        Assert.Throws<InvalidDataException>(() => BackupCodec.Decode(expected));
    }

    /// <summary>Required identities, zero-head relations and entry bounds reject even with correctly resealed checksums.</summary>
    /// <param name="role">Record role.</param>
    /// <param name="offset">Absolute field offset.</param>
    /// <param name="length">Field width.</param>
    [Theory]
    [InlineData("inventory", 14, 16)]
    [InlineData("inventory", 30, 16)]
    [InlineData("inventory", 46, 16)]
    [InlineData("inventory", 62, 8)]
    [InlineData("inventory", 134, 8)]
    [InlineData("inventory", 174, 32)]
    [InlineData("inventory", 206, 4)]
    [InlineData("inventory", 210, 4)]
    [InlineData("inventory", 218, 4)]
    [InlineData("completion", 12, 16)]
    [InlineData("origin", 12, 16)]
    [InlineData("origin", 28, 16)]
    [InlineData("origin", 76, 16)]
    [InlineData("origin", 92, 16)]
    [InlineData("origin", 108, 16)]
    [InlineData("origin", 124, 16)]
    [InlineData("origin", 140, 8)]
    [InlineData("origin", 148, 8)]
    [InlineData("origin", 284, 32)]
    [InlineData("origin", 316, 32)]
    public void Decode_ResealedZeroFields_Rejects(string role, int offset, int length)
    { var bytes = Fixture(role); bytes.AsSpan(offset, length).Clear(); Seal(bytes); Assert.Throws<InvalidDataException>(() => Reencode(role, bytes)); }

    /// <summary>Portable-path rules apply symmetrically before encoding and after bounded decoding.</summary>
    /// <param name="path">Unsafe path or overlong marker.</param>
    [Theory]
    [InlineData("")]
    [InlineData("/")]
    [InlineData("../x")]
    [InlineData("a/../b")]
    [InlineData("./FORMAT")]
    [InlineData("a//b")]
    [InlineData("a/")]
    [InlineData("C:/x")]
    [InlineData(@"a\b")]
    [InlineData("CON")]
    [InlineData("con.txt")]
    [InlineData("PRN")]
    [InlineData("AUX")]
    [InlineData("NUL")]
    [InlineData("COM0")]
    [InlineData("COM9.txt")]
    [InlineData("LPT1")]
    [InlineData("LPT9.ext")]
    [InlineData("a.")]
    [InlineData("a~/b")]
    [InlineData("space name")]
    [InlineData("é")]
    [InlineData("overlong")]
    public void Inventory_UnsafePortablePath_RejectsOnEncodeAndDecode(string path)
    {
        if (path == "overlong") path = new string('a', 513);
        var value = Inventory() with { Files = [new(path, 44, new byte[32])] };
        Assert.Throws<InvalidDataException>(() => EpochBackupCodec.EncodeInventory(value));
        Assert.Throws<InvalidDataException>(() => EpochBackupCodec.DecodeInventory(Raw(value)));
    }

    /// <summary>Unordered, duplicate and portable case-alias file names cannot enter an inventory.</summary>
    /// <param name="second">Second entry path.</param>
    [Theory]
    [InlineData("BASE")]
    [InlineData("base")]
    [InlineData("AAA")]
    public void Inventory_UnorderedOrCollidingPaths_Rejects(string second)
    {
        var value = Inventory() with { Files = [new("BASE", 44, new byte[32]), new(second, 44, new byte[32])] };
        Assert.Throws<InvalidDataException>(() => EpochBackupCodec.EncodeInventory(value)); Assert.Throws<InvalidDataException>(() => EpochBackupCodec.DecodeInventory(Raw(value)));
    }

    /// <summary>Hostile declared counts/string lengths and malformed UTF-8 fail before unbounded allocation.</summary>
    [Fact]
    public void Decode_HostileBoundsAndUtf8_Rejects()
    {
        foreach (var (offset, number) in new[] { (206, -1), (206, 100001), (206, 100000), (210, -1), (210, 513), (210, int.MaxValue), (218, 43), (218, BinaryEnvelope.MaximumFileBytes + 1) })
        { var bytes = Fixture("inventory"); BinaryPrimitives.WriteInt32LittleEndian(bytes.AsSpan(offset), number); Seal(bytes); Assert.Throws<InvalidDataException>(() => EpochBackupCodec.DecodeInventory(bytes)); }
        var closure = Fixture("inventory"); closure[12] = 2; Seal(closure); Assert.Throws<InvalidDataException>(() => EpochBackupCodec.DecodeInventory(closure));
        var utf8 = Fixture("inventory"); utf8[214] = 255; Seal(utf8); Assert.Throws<InvalidDataException>(() => EpochBackupCodec.DecodeInventory(utf8));
        foreach (var role in new[] { "inventory", "origin" })
        { var bytes = Fixture(role); BinaryPrimitives.WriteUInt64LittleEndian(bytes.AsSpan(role == "inventory" ? 134 : 148), 10001); Seal(bytes); Assert.Throws<InvalidDataException>(() => Reencode(role, bytes)); }
        var reused = Fixture("origin"); reused.AsSpan(76, 16).CopyTo(reused.AsSpan(108)); Seal(reused); Assert.Throws<InvalidDataException>(() => EpochBackupCodec.DecodeOrigin(reused));
        reused = Fixture("origin"); reused.AsSpan(92, 16).CopyTo(reused.AsSpan(124)); Seal(reused); Assert.Throws<InvalidDataException>(() => EpochBackupCodec.DecodeOrigin(reused));
        Assert.Throws<InvalidDataException>(() => EpochBackupCodec.DecodeInventory(new byte[BinaryEnvelope.MaximumFileBytes + 1]));
    }

    /// <summary>Valid zero/max heads and count/path/file limits roundtrip without opening files.</summary>
    [Fact]
    public void Codec_ValidBoundaryValues_RoundtripAsMetadataOnly()
    {
        var zero = Inventory() with { CommitSequence = 0, HeadManifestHash = Range(1), HeadWalHash = new byte[32] };
        Assert.Equal(0UL, EpochBackupCodec.DecodeInventory(EpochBackupCodec.EncodeInventory(zero)).CommitSequence);
        var origin = Origin() with { CommitSequence = 0, HeadManifestHash = Range(1), SourceHeadWalHash = new byte[32], DestinationHeadWalHash = new byte[32] };
        Assert.Equal(0UL, EpochBackupCodec.DecodeOrigin(EpochBackupCodec.EncodeOrigin(origin)).CommitSequence);
        var zeroBytes = EpochBackupCodec.EncodeInventory(zero);
        Assert.Equal(0UL, EpochBackupCodec.ValidateSourceHeaders(zeroBytes, SourceFormat, Current(zero.Source, 0, Range(1), new byte[32])).CommitSequence);
        origin = origin with { InventoryHash = SHA256.HashData(zeroBytes) };
        Assert.Equal(0UL, EpochBackupCodec.ValidateOriginHeaders(EpochBackupCodec.EncodeOrigin(origin), zeroBytes, DestinationFormat,
            Current(EpochAuthorityBinding.Create(DestinationFormat, Range(1)), 0, Range(1), new byte[32])).CommitSequence);
        var maximum = Inventory() with { CommitSequence = 10000, Files = [new(new string('a', 512), BinaryEnvelope.MaximumFileBytes, new byte[32])] };
        Assert.Equal(EpochBackupCodec.EncodeInventory(maximum), EpochBackupCodec.EncodeInventory(EpochBackupCodec.DecodeInventory(EpochBackupCodec.EncodeInventory(maximum))));
        maximum = maximum with { Files = Enumerable.Range(0, 100000).Select(id => new BackupEntry("f/" + id.ToString("D6", System.Globalization.CultureInfo.InvariantCulture), 44, new byte[32])).ToArray() };
        Assert.Equal(100000, EpochBackupCodec.DecodeInventory(EpochBackupCodec.EncodeInventory(maximum)).Files.Length);
        Assert.Equal(10000UL, EpochBackupCodec.DecodeOrigin(EpochBackupCodec.EncodeOrigin(Origin() with { CommitSequence = 10000 })).CommitSequence);
    }

    /// <summary>Encoding also validates identities, digests, sequence relations and collection shape.</summary>
    /// <param name="role">Metadata role.</param>
    [Theory]
    [InlineData("inventory")]
    [InlineData("completion")]
    [InlineData("origin")]
    public void Encode_InvalidRecordShapes_Rejects(string role)
    {
        if (role == "completion")
        {
            Assert.Throws<InvalidDataException>(() => EpochBackupCodec.EncodeCompletion(new(Guid.Empty, new byte[32])));
            Assert.Throws<InvalidDataException>(() => EpochBackupCodec.EncodeCompletion(new(BackupId, new byte[31]))); return;
        }
        if (role == "inventory")
        {
            var v = Inventory();
            foreach (var bad in new[] { v with { BackupId = Guid.Empty }, v with { Source = v.Source with { Identity = Source with { DocumentId = 0 } } },
                v with { Source = v.Source with { FormatHash = new byte[31] } }, v with { Source = v.Source with { BaseHash = new byte[31] } },
                v with { CommitSequence = 10001 }, v with { CommitSequence = 0 }, v with { HeadManifestHash = new byte[31] }, v with { HeadWalHash = new byte[32] },
                v with { Files = [] }, v with { Files = new BackupEntry[100001] }, v with { Files = [new("BASE", 43, new byte[32])] },
                v with { Files = [new("BASE", 44, new byte[31])] }, v with { Files = [null!] } })
                Assert.Throws<InvalidDataException>(() => EpochBackupCodec.EncodeInventory(bad)); return;
        }
        var o = Origin();
        foreach (var bad in new[] { o with { RestoreId = Guid.Empty }, o with { BackupId = Guid.Empty }, o with { InventoryHash = new byte[31] },
            o with { Destination = Destination with { StoreId = Source.StoreId } }, o with { Destination = Destination with { EpochId = Source.EpochId } },
            o with { Destination = Destination with { DocumentId = 2 } }, o with { CommitSequence = 10001 }, o with { CommitSequence = 0 },
            o with { SourceHeadWalHash = new byte[32] }, o with { DestinationHeadWalHash = new byte[32] }, o with { DestinationFormatHash = new byte[31] } })
            Assert.Throws<InvalidDataException>(() => EpochBackupCodec.EncodeOrigin(bad));
    }

    /// <summary>Completion binds both backup identity and complete inventory bytes, not just a decoded DTO.</summary>
    [Fact]
    public void Completion_ExpectedInventory_RejectsForeignIdentityOrDigest()
    {
        var inventory = Fixture("inventory"); var complete = Fixture("completion"); Assert.Equal(BackupId, EpochBackupCodec.ValidateCompletion(complete, inventory).BackupId);
        var c = EpochBackupCodec.DecodeCompletion(complete);
        foreach (var wrong in new[] { c with { BackupId = Guid.NewGuid() }, c with { InventoryHash = new byte[32] } })
            Assert.Throws<InvalidDataException>(() => EpochBackupCodec.ValidateCompletion(EpochBackupCodec.EncodeCompletion(wrong), inventory));
        var changed = EpochBackupCodec.EncodeInventory(Inventory() with { Files = [new("FORMAT", 99, new byte[32])] });
        Assert.Throws<InvalidDataException>(() => EpochBackupCodec.ValidateCompletion(complete, changed));
    }

    /// <summary>Inventory source bindings and head must match the explicitly supplied source FORMAT/CURRENT.</summary>
    /// <param name="field">Mismatched context component.</param>
    [Theory]
    [InlineData("store")]
    [InlineData("epoch")]
    [InlineData("document")]
    [InlineData("format")]
    [InlineData("base")]
    [InlineData("sequence")]
    [InlineData("head")]
    [InlineData("wal")]
    public void SourceHeaders_ForeignOrStaleContext_Rejects(string field)
    {
        var original = Inventory(); var current = Current(original.Source, original.CommitSequence, original.HeadManifestHash, original.HeadWalHash);
        Assert.Equal(BackupId, EpochBackupCodec.ValidateSourceHeaders(Fixture("inventory"), SourceFormat, current).BackupId);
        var wrong = field switch
        {
            "store" => original with { Source = original.Source with { Identity = Source with { StoreId = Guid.NewGuid() } } },
            "epoch" => original with { Source = original.Source with { Identity = Source with { EpochId = Guid.NewGuid() } } },
            "document" => original with { Source = original.Source with { Identity = Source with { DocumentId = 2 } } },
            "format" => original with { Source = original.Source with { FormatHash = new byte[32] } },
            "base" => original with { Source = original.Source with { BaseHash = new byte[32] } },
            "sequence" => original with { CommitSequence = 1 },
            "head" => original with { HeadManifestHash = new byte[32] },
            _ => original with { HeadWalHash = Range(97) },
        };
        Assert.Throws<InvalidDataException>(() => EpochBackupCodec.ValidateSourceHeaders(EpochBackupCodec.EncodeInventory(wrong), SourceFormat, current));
    }

    /// <summary>Restore metadata cannot substitute its expected inventory or fresh destination context.</summary>
    /// <param name="field">Origin field to substitute.</param>
    [Theory]
    [InlineData("backup")]
    [InlineData("inventory")]
    [InlineData("store")]
    [InlineData("epoch")]
    [InlineData("document")]
    [InlineData("source-format")]
    [InlineData("base")]
    [InlineData("sequence")]
    [InlineData("head")]
    [InlineData("source-wal")]
    [InlineData("destination-store")]
    [InlineData("destination-epoch")]
    [InlineData("destination-format")]
    [InlineData("destination-wal")]
    public void OriginHeaders_ForeignOrStaleContext_Rejects(string field)
    {
        var o = Origin(); var current = Current(EpochAuthorityBinding.Create(DestinationFormat, Range(1)), 2, Range(33), Range(97));
        Assert.Equal(o.RestoreId, EpochBackupCodec.ValidateOriginHeaders(Fixture("origin"), Fixture("inventory"), DestinationFormat, current).RestoreId);
        var wrong = field switch
        {
            "backup" => o with { BackupId = Guid.NewGuid() },
            "inventory" => o with { InventoryHash = new byte[32] },
            "store" => o with { Source = o.Source with { Identity = Source with { StoreId = Guid.NewGuid() } } },
            "epoch" => o with { Source = o.Source with { Identity = Source with { EpochId = Guid.NewGuid() } } },
            "document" => o with { Source = o.Source with { Identity = Source with { DocumentId = 2 } }, Destination = Destination with { DocumentId = 2 } },
            "source-format" => o with { Source = o.Source with { FormatHash = new byte[32] } },
            "base" => o with { Source = o.Source with { BaseHash = new byte[32] } },
            "sequence" => o with { CommitSequence = 1 },
            "head" => o with { HeadManifestHash = new byte[32] },
            "source-wal" => o with { SourceHeadWalHash = Range(97) },
            "destination-store" => o with { Destination = Destination with { StoreId = Guid.NewGuid() } },
            "destination-epoch" => o with { Destination = Destination with { EpochId = Guid.NewGuid() } },
            "destination-format" => o with { DestinationFormatHash = new byte[32] },
            _ => o with { DestinationHeadWalHash = Range(65) },
        };
        Assert.Throws<InvalidDataException>(() => EpochBackupCodec.ValidateOriginHeaders(EpochBackupCodec.EncodeOrigin(wrong), Fixture("inventory"), DestinationFormat, current));
    }

    /// <summary>Source/destination profile gates remain strict and malformed selectors never become backup permission.</summary>
    [Fact]
    public void HeaderContexts_UnsupportedFormatsOrCorruptSelectors_Rejects()
    {
        var inv = Inventory(); var sourceCurrent = Current(inv.Source, 2, Range(33), Range(65));
        var destinationCurrent = Current(EpochAuthorityBinding.Create(DestinationFormat, Range(1)), 2, Range(33), Range(97));
        foreach (var format in new[] { EpochCodec.EncodeFormat(Source), EpochCodec.EncodeFormat(Destination), new byte[] { 0 } })
        {
            Assert.Throws<InvalidDataException>(() => EpochBackupCodec.ValidateSourceHeaders(Fixture("inventory"), format, sourceCurrent));
            Assert.Throws<InvalidDataException>(() => EpochBackupCodec.ValidateOriginHeaders(Fixture("origin"), Fixture("inventory"), format, destinationCurrent));
        }
        var unknown = (byte[])SourceFormat.Clone(); unknown[59] = 255; Seal(unknown);
        Assert.Throws<InvalidDataException>(() => EpochBackupCodec.ValidateSourceHeaders(Fixture("inventory"), unknown, sourceCurrent));
        var origin = Origin();
        foreach (var current in new[] { new byte[] { 0 }, sourceCurrent, Current(EpochAuthorityBinding.Create(DestinationFormat, Range(1)), 1, Range(33), Range(97)),
            Current(EpochAuthorityBinding.Create(DestinationFormat, Range(1)), 2, new byte[32], Range(97)) })
            Assert.Throws<InvalidDataException>(() => EpochBackupCodec.ValidateOriginHeaders(EpochBackupCodec.EncodeOrigin(origin), Fixture("inventory"), DestinationFormat, current));
        Assert.Throws<InvalidDataException>(() => EpochBackupCodec.ValidateSourceHeaders(Fixture("inventory"), SourceFormat, destinationCurrent));
    }

    private static byte[] Raw(EpochBackupInventory value) => BinaryEnvelope.Encode("BXEI", writer =>
    {
        writer.Write((ushort)1); writer.Write(value.BackupId.ToByteArray()); writer.Write(value.Source.Identity.StoreId.ToByteArray()); writer.Write(value.Source.Identity.EpochId.ToByteArray());
        writer.Write(value.Source.Identity.DocumentId); writer.Write(value.Source.FormatHash); writer.Write(value.Source.BaseHash); writer.Write(value.CommitSequence);
        writer.Write(value.HeadManifestHash); writer.Write(value.HeadWalHash); writer.Write(value.Files.Length);
        foreach (var file in value.Files) { BinaryEnvelope.WriteString(writer, file.Path); writer.Write(file.Length); writer.Write(file.Hash); }
    });
    private static byte[] Current(EpochAuthorityBinding binding, ulong sequence, byte[] head, byte[] wal) => EpochAuthorityCodec.EncodeCurrent(new(binding, sequence, head, wal));
    private static byte[] Encode(string role) => role switch
    { "inventory" => EpochBackupCodec.EncodeInventory(Inventory()), "completion" => EpochBackupCodec.Complete(Fixture("inventory")), _ => EpochBackupCodec.EncodeOrigin(Origin()) };
    private static byte[] Reencode(string role, byte[] bytes) => role switch
    { "inventory" => EpochBackupCodec.EncodeInventory(EpochBackupCodec.DecodeInventory(bytes)), "completion" => EpochBackupCodec.EncodeCompletion(EpochBackupCodec.DecodeCompletion(bytes)), _ => EpochBackupCodec.EncodeOrigin(EpochBackupCodec.DecodeOrigin(bytes)) };
    private static void Seal(byte[] bytes) => SHA256.HashData(bytes.AsSpan(0, bytes.Length - 32), bytes.AsSpan(bytes.Length - 32));
    private static byte[] Fixture(string role) => Hex(role == "origin" ? "epoch-restore-origin-v1.hex" : "epoch-backup-" + role + "-v1.hex");
    private static byte[] Hex(string name) => Convert.FromHexString(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "TestData", name)).Trim());
}
