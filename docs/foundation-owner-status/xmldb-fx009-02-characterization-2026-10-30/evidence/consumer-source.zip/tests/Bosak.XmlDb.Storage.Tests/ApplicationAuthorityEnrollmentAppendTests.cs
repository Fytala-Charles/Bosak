// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 30 October 2026
// PURPOSE              : Qualifies conditional first enrollment and terminal stopped append outcomes.
// SPECIAL NOTES        : EF3 real stores, exact frozen-v1 output and faults; all application admissions stopped.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 30-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Reflection;
using System.Text;
using Bosak.XmlDb.Core;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Qualifies conditional first enrollment and terminal stopped append outcomes.</summary>
public sealed class ApplicationAuthorityEnrollmentAppendTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ef3-" + Guid.NewGuid().ToString("N"));
    private string Source => Path.Combine(_area, "source");
    private string Capture => Path.Combine(_area, "capture");
    private string Host => Path.Combine(_area, "host");
    private string Authority => Path.Combine(_area, "authority");
    private readonly Guid _admin = Guid.NewGuid();
    private ApplicationAuthorityConfiguration Configuration => new(Guid.Parse("10213243-5465-7687-98a9-bacbdcedfe0f"), _admin, "pilot", "orders", "admin", "authority");
    private Dictionary<string, string> Roots => new() { ["admin"] = Host, ["authority"] = Authority, ["source"] = Source, ["capture"] = Capture };
    private static EmbeddedHostInspectionEvidence Inspection(EmbeddedHostLifetime parent) => new(parent.Context, true, true, true, true, true);
    private ApplicationEnrollmentEvidence Evidence(EmbeddedHostLifetime parent) => new(parent.Context, Configuration.AuthorityId, "source", "source-admission", "capture", Guid.NewGuid(), new string('a', 64), true, true, true, true, true, true);
    private EmbeddedHostLifetime Parent()
    {
        Directory.CreateDirectory(Host); File.WriteAllBytes(Path.Combine(Host, "owner.lock"), []);
        File.WriteAllBytes(Path.Combine(Host, "host.meta"), HostJournalCodec.EncodeMetadata(_admin, "pilot", "orders")); File.WriteAllBytes(Path.Combine(Host, "journal.bin"), []);
        return EmbeddedHostLifetime.OpenExisting(Host, "pilot", "orders", [Source, Capture, Authority]);
    }
    private ApplicationAuthorityLifetime Provision(EmbeddedHostLifetime parent) => ApplicationAuthorityLifetime.Provision(parent, parent.JournalStatus.KnownPosition, Inspection(parent), Authority, Configuration, Roots, new(Authority, true, true, true));
    private void Seed(int count = 1)
    {
        Directory.CreateDirectory(_area); using var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>")); XmlFragmentImporter.Import(input, Source);
        using var source = EmbeddedXmlDatabase.Open(Source);
        for (var i = 0; i < count; i++) { using var read = source.BeginRead(); using var tx = source.BeginWrite(); tx.ReplaceNodeValue(Target(read), "new-" + i); tx.Commit(); }
    }
    private static ulong Target(ImmutableXmlSnapshot snapshot) => Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();
    private Dictionary<string, byte[]> Bytes()
    {
        var result = new Dictionary<string, byte[]>();
        foreach (var path in Directory.GetFiles(_area, "*", SearchOption.AllDirectories).Where(p => Path.GetFileName(p) is not ("owner.lock" or "authority.lock" or "writer.lock")))
        {
            using var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            var bytes = new byte[(int)file.Length]; file.ReadExactly(bytes); result.Add(Path.GetRelativePath(_area, path), bytes);
        }
        return result;
    }
    private void AssertBytes(Dictionary<string, byte[]> before)
    {
        var after = Bytes(); Assert.Equal(before.Keys.Order(), after.Keys.Order()); foreach (var pair in before) Assert.Equal(pair.Value, after[pair.Key]);
    }


    /// <summary>Real source histories publish one exact frame, preserve all other bytes and reopen read-only.</summary>
    /// <param name="sequence">Real source commit count.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(3)]
    public void Append_RealHistory_AcknowledgesExactStoppedFrame(int sequence)
    {
        Seed(sequence); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent);
        using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence); var description = plan.Describe(); var before = Bytes();
        var result = authority.AppendFirstEnrollment(plan, evidence with { });
        Assert.Equal(ApplicationEnrollmentAppendDisposition.AcknowledgedStopped, result.Disposition); Assert.True(result.PossibleOutput); Assert.False(result.ReleaseUnknown); Assert.Null(result.Error);
        var receipt = Assert.IsType<ApplicationEnrollmentReceipt>(result.Receipt); Assert.Equal(receipt, authority.ConfirmedEnrollment); Assert.True(receipt.WritersMustRemainStopped);
        Assert.Equal(description.Entry, receipt.Frame.Entry); Assert.Equal(description.AdministrativePosition, receipt.AdministrativePosition);
        Assert.Equal(1UL, receipt.Frame.Sequence); Assert.Equal(new string('0', 64), receipt.Frame.PreviousDigest);
        Assert.Empty(authority.History.Frames); Assert.False(authority.IsFaulted); Assert.Equal(0, authority.ActiveInspections);
        Assert.Throws<InvalidOperationException>(() => authority.Inspect()); Assert.Throws<InvalidOperationException>(() => authority.AppendFirstEnrollment(plan, evidence));
        freeze.Dispose(); Assert.True(source.EnrollmentOwnershipStatus.StopLatched); Assert.Throws<InvalidOperationException>(() => source.BeginWrite());
        before[Path.Combine("authority", "authority.log")] = ReadRole(2); AssertBytes(before);
        authority.Dispose(); parent.Dispose();
        using var reopenedParent = EmbeddedHostLifetime.OpenExisting(Host, "pilot", "orders", [Source, Capture, Authority]);
        using var reopened = ApplicationAuthorityLifetime.OpenExisting(reopenedParent, reopenedParent.JournalStatus.KnownPosition, Inspection(reopenedParent), Authority, Configuration, Roots);
        Assert.Single(reopened.Inspect().Frames); Assert.True(reopened.WritersMustRemainStopped); Assert.Throws<InvalidOperationException>(() => reopened.ReserveInitializer());
    }

    /// <summary>Output hooks run only under authority serialization, with no source or lifecycle gates.</summary>
    [Fact]
    public void Append_ArmedBeforeAllWrappersClose_RetainsActualExecutionAndConfirmsDrain()
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence);
        var io = new TestIo(() => { Assert.True(Monitor.IsEntered(Field(authority, "_readGate"))); Assert.False(Monitor.IsEntered(Field(authority, "_gate"))); Assert.False(Monitor.IsEntered(Field(parent, "_gate"))); Assert.False(Monitor.IsEntered(Field(parent, "_appendGate"))); Assert.False(Monitor.IsEntered(Field(source, "_gate"))); });
        var result = authority.AppendFirstEnrollmentCore(plan, evidence, io, stage =>
        {
            if (stage != ApplicationEnrollmentAppendStage.Armed) return;
            Assert.False(Monitor.IsEntered(Field(authority, "_readGate"))); plan.Dispose(); freeze.Dispose(); source.Dispose(); authority.Dispose(); parent.Dispose();
            Assert.False(authority.IsReleased); Assert.False(parent.IsReleased);
        });
        Assert.Equal(ApplicationEnrollmentAppendDisposition.AcknowledgedStopped, result.Disposition); Assert.Equal(1, io.Writes); Assert.True(authority.IsReleased); Assert.True(parent.IsReleased);
        Assert.Equal(EnrollmentSourceReleaseState.Released, source.EnrollmentOwnershipStatus.ReleaseState);
    }

    /// <summary>Exceptions at observed phase boundaries preserve bytes and never fabricate acknowledgment.</summary>
    /// <param name="phase">Actual instrumented phase.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(2)]
    [InlineData(3)]
    [InlineData(4)]
    [InlineData(5)]
    [InlineData(6)]
    [InlineData(7)]
    public void Append_PhaseFailure_TerminalStoppedWithoutRetry(int phase)
    {
        var stage = (ApplicationEnrollmentAppendStage)phase;
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence);
        var before = Bytes(); var io = new TestIo(); var result = authority.AppendFirstEnrollmentCore(plan, evidence, io, s => { if (s == stage) throw new IOException("Injected phase failure."); });
        var possible = stage is not (ApplicationEnrollmentAppendStage.Armed or ApplicationEnrollmentAppendStage.Validated or ApplicationEnrollmentAppendStage.BeforeArm);
        Assert.Equal(possible ? ApplicationEnrollmentAppendDisposition.Uncertain : ApplicationEnrollmentAppendDisposition.RefusedBeforeWrite, result.Disposition);
        Assert.Equal(possible, result.PossibleOutput); Assert.Null(result.Receipt); Assert.Null(authority.ConfirmedEnrollment); Assert.True(authority.IsFaulted); Assert.Equal(stage != ApplicationEnrollmentAppendStage.BeforeArm, source.EnrollmentOwnershipStatus.StopLatched);
        Assert.Throws<InvalidOperationException>(() => authority.AppendFirstEnrollment(plan, evidence)); before[Path.Combine("authority", "authority.log")] = ReadRole(2); AssertBytes(before);
        if (!possible) Assert.Equal(0, io.Writes);
    }

    /// <summary>Actual partial output, flush/read failures and mismatched readback are uncertain and retained.</summary>
    /// <param name="fault">Injected output fault.</param>
    [Theory]
    [InlineData("write-before")]
    [InlineData("partial")]
    [InlineData("write-after")]
    [InlineData("flush-before")]
    [InlineData("flush-after")]
    [InlineData("read-before")]
    [InlineData("read-after")]
    [InlineData("read-corrupt")]
    [InlineData("extra")]
    [InlineData("short")]
    [InlineData("zero")]
    public void Append_IoFault_UncertainRetainsExactSurvivors(string fault)
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence);
        var before = Bytes(); var io = new TestIo(fault: fault); var result = authority.AppendFirstEnrollmentCore(plan, evidence, io);
        Assert.Equal(ApplicationEnrollmentAppendDisposition.Uncertain, result.Disposition); Assert.True(result.PossibleOutput); Assert.Null(result.Receipt); Assert.Null(authority.ConfirmedEnrollment); Assert.True(authority.IsFaulted);
        var surviving = ReadRole(2); Assert.Equal(io.Surviving, surviving); before[Path.Combine("authority", "authority.log")] = surviving; AssertBytes(before);
        Assert.Throws<InvalidOperationException>(() => authority.AppendFirstEnrollment(plan, evidence)); Assert.Equal(surviving, ReadRole(2));
        authority.Dispose(); parent.Dispose();
        using var reopenedParent = EmbeddedHostLifetime.OpenExisting(Host, "pilot", "orders", [Source, Capture, Authority]);
        if (fault is "partial" or "short" or "extra")
        {
            Assert.Throws<InvalidDataException>(() => ApplicationAuthorityLifetime.OpenExisting(reopenedParent, reopenedParent.JournalStatus.KnownPosition, Inspection(reopenedParent), Authority, Configuration, Roots));
            Assert.Equal(surviving, File.ReadAllBytes(Path.Combine(Authority, "authority.log")));
        }
        else
        {
            using var reopened = ApplicationAuthorityLifetime.OpenExisting(reopenedParent, reopenedParent.JournalStatus.KnownPosition, Inspection(reopenedParent), Authority, Configuration, Roots);
            Assert.Equal(surviving.Length == 0 ? 0 : 1, reopened.Inspect().Frames.Length); Assert.Throws<InvalidOperationException>(() => reopened.ReserveInitializer());
        }
    }

    /// <summary>Changes after conditional validation cause no write, no repair or head adoption.</summary>
    /// <param name="change">Invalidated authority state.</param>
    [Theory]
    [InlineData("valid-head")]
    [InlineData("torn-head")]
    [InlineData("metadata")]
    [InlineData("owner-length")]
    [InlineData("namespace")]
    public void Append_StaleOrCorruptAuthority_RefusesWithoutTouchingInvalidBytes(string change)
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent);
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence);
        Dictionary<string, byte[]>? invalid = null; var io = new TestIo(); var result = authority.AppendFirstEnrollmentCore(plan, evidence, io, stage =>
        {
            if (stage != ApplicationEnrollmentAppendStage.Validated) return;
            var roles = (FileStream[])Field(authority, "_roles");
            if (change == "namespace") File.WriteAllText(Path.Combine(Authority, "extra"), "retain");
            else if (change == "owner-length") roles[0].WriteByte(1);
            else if (change == "metadata") { roles[1].Position = 0; roles[1].WriteByte(0); roles[1].Flush(); }
            else
            {
                var meta = ApplicationAuthorityCodec.DecodeMetadata(ApplicationAuthorityCodec.EncodeMetadata(Configuration), Configuration);
                var bytes = ApplicationAuthorityCodec.EncodeFrame(meta, 1, new string('0', 64), plan.Description.Entry);
                roles[2].Position = 0; roles[2].Write(change == "torn-head" ? bytes[..13] : bytes); roles[2].Flush();
            }
            invalid = Bytes();
        });
        Assert.Equal(ApplicationEnrollmentAppendDisposition.RefusedBeforeWrite, result.Disposition); Assert.False(result.PossibleOutput); Assert.Equal(0, io.Writes); Assert.Null(result.Receipt); Assert.True(authority.IsFaulted); Assert.NotNull(invalid); AssertBytes(invalid);
        Assert.Empty(authority.History.Frames); Assert.True(source.EnrollmentOwnershipStatus.StopLatched);
    }

    /// <summary>Unsupported durability rejects before consuming the actual valid plan.</summary>
    [Fact]
    public void Append_StrongDurability_RejectsWithoutFallbackOrConsumption()
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent); using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence);
        Assert.Throws<NotSupportedException>(() => authority.AppendFirstEnrollmentCore(plan, evidence, new TestIo(), durability: DurabilityMode.FileAndDirectoryFlush)); Assert.False(plan.Consumed);
        Assert.Equal(ApplicationEnrollmentAppendDisposition.AcknowledgedStopped, authority.AppendFirstEnrollment(plan, evidence).Disposition);
    }

    /// <summary>Source close uncertainty prevents acknowledgment even after exact frame verification.</summary>
    /// <param name="afterClose">Whether the actual source stream was closed.</param>
    /// <param name="beforeArm">Whether closing wins before arming and any output.</param>
    [Theory]
    [InlineData(false, false)]
    [InlineData(true, false)]
    [InlineData(false, true)]
    [InlineData(true, true)]
    public void Append_ReleaseUnknown_ReportsUncertainAndKeepsParentOperation(bool afterClose, bool beforeArm)
    {
        Seed(); using var close = new FailingClose(afterClose); using var source = EmbeddedXmlDatabase.Open(Source); var parent = Parent(); var authority = Provision(parent); using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent);
        using var plan = authority.PrepareRetainedFirstEnrollmentCore(freeze, capture, evidence, close);
        var result = authority.AppendFirstEnrollmentCore(plan, evidence, new TestIo(), stage => { if (stage == (beforeArm ? ApplicationEnrollmentAppendStage.BeforeArm : ApplicationEnrollmentAppendStage.Armed)) { source.Dispose(); freeze.Dispose(); authority.Dispose(); parent.Dispose(); } });
        Assert.Equal(ApplicationEnrollmentAppendDisposition.Uncertain, result.Disposition); Assert.True(result.ReleaseUnknown); Assert.Equal(!beforeArm, result.PossibleOutput); Assert.Null(result.Receipt); Assert.Null(authority.ConfirmedEnrollment); Assert.Equal(1, authority.ActiveInspections); Assert.False(authority.IsReleased); Assert.False(parent.IsReleased); Assert.Equal(EnrollmentSourceReleaseState.Unknown, source.EnrollmentOwnershipStatus.ReleaseState);
        Assert.Equal(beforeArm, ReadRole(2).Length == 0); close.Dispose(); foreach (var role in (FileStream[])Field(authority, "_roles")) role.Dispose(); foreach (var field in new[] { "_journal", "_metadata", "_owner" }) ((FileStream)Field(parent, field)).Dispose();
    }

    /// <summary>Closing any wrapper before arm consumes the authentic dispatch without entering the write seam.</summary>
    /// <param name="which">Closing wrapper.</param>
    [Theory]
    [InlineData("source")]
    [InlineData("freeze")]
    [InlineData("authority")]
    [InlineData("parent")]
    public void Append_ClosingBeforeArm_RefusesWithoutOutput(string which)
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent); using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence); var before = Bytes(); var io = new TestIo();
        var result = authority.AppendFirstEnrollmentCore(plan, evidence, io, stage =>
        {
            if (stage != ApplicationEnrollmentAppendStage.BeforeArm) return;
            if (which == "source") source.Dispose(); if (which == "freeze") freeze.Dispose(); if (which == "authority") authority.Dispose(); if (which == "parent") parent.Dispose();
        });
        Assert.Equal(ApplicationEnrollmentAppendDisposition.RefusedBeforeWrite, result.Disposition); Assert.False(result.PossibleOutput); Assert.False(result.ReleaseUnknown); Assert.True(plan.Consumed); Assert.Equal(0, io.Writes); AssertBytes(before); Assert.False(source.EnrollmentOwnershipStatus.StopLatched);
    }
    /// <summary>Foreign/thread misuse cannot consume the original plan or synthesize an outcome for it.</summary>
    [Fact]
    public void Append_ForgedOrWrongThread_RejectsBeforeActualConsumption()
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent); using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence);
        using var forged = new ApplicationAuthorityLifetime.RetainedEnrollmentPreparation(authority, capture, evidence, plan.Pin, plan.Description with { }, new(authority, new MemoryStream()));
        Assert.Throws<InvalidOperationException>(() => authority.AppendFirstEnrollment(forged, evidence)); Assert.False(plan.Consumed);
        Exception? error = null; var thread = new Thread(() => error = Record.Exception(() => authority.AppendFirstEnrollment(plan, evidence))) { IsBackground = true }; thread.Start(); Assert.True(thread.Join(TimeSpan.FromSeconds(30))); Assert.IsType<InvalidOperationException>(error); Assert.False(plan.Consumed);
        Assert.Equal(ApplicationEnrollmentAppendDisposition.AcknowledgedStopped, authority.AppendFirstEnrollment(plan, evidence).Disposition);
    }
    /// <summary>Previously armed read-only execution cannot be upgraded to append authority.</summary>
    [Fact]
    public void Append_AlreadyArmedExecution_RejectsUpgrade()
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent); using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence); using var execution = authority.TryArmRetainedFirstEnrollment(plan, evidence); Assert.NotNull(execution);
        Assert.Throws<InvalidOperationException>(() => authority.AppendFirstEnrollment(plan, evidence)); Assert.True(execution.Inspect().WritersMustRemainStopped); Assert.Empty(ReadRole(2));
    }
    /// <summary>Invalid source after arming is refused before output without repair or clearing the source stop latch.</summary>
    [Fact]
    public void Append_SourceChangedAfterArm_RefusesBeforeOutput()
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent); using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence); Dictionary<string, byte[]>? invalid = null; var io = new TestIo();
        var result = authority.AppendFirstEnrollmentCore(plan, evidence, io, stage => { if (stage != ApplicationEnrollmentAppendStage.Armed) return; File.AppendAllText(Path.Combine(Capture, "inventory.bin"), "bad"); invalid = Bytes(); });
        Assert.Equal(ApplicationEnrollmentAppendDisposition.RefusedBeforeWrite, result.Disposition); Assert.False(result.PossibleOutput); Assert.True(source.EnrollmentOwnershipStatus.StopLatched); Assert.Equal(0, io.Writes); Assert.NotNull(invalid); AssertBytes(invalid);
    }
    /// <summary>Post-flush authority corruption cannot be acknowledged or repaired even when the frame was written.</summary>
    /// <param name="change">Injected final authority change.</param>
    [Theory]
    [InlineData("metadata")]
    [InlineData("namespace")]
    [InlineData("log")]
    public void Append_PostFlushChange_UncertainWithoutAcknowledgment(string change)
    {
        Seed(); using var source = EmbeddedXmlDatabase.Open(Source); using var parent = Parent(); using var authority = Provision(parent); using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture); var evidence = Evidence(parent); using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence); Dictionary<string, byte[]>? invalid = null;
        var result = authority.AppendFirstEnrollmentCore(plan, evidence, new TestIo(), stage =>
        {
            if (stage != ApplicationEnrollmentAppendStage.BeforeAcknowledge) return;
            var roles = (FileStream[])Field(authority, "_roles");
            if (change == "namespace") File.WriteAllText(Path.Combine(Authority, "extra"), "retain");
            else if (change == "metadata") { roles[1].Position = 0; roles[1].WriteByte(0); roles[1].Flush(); }
            else { roles[2].SetLength(17); roles[2].Flush(); }
            invalid = Bytes();
        });
        Assert.Equal(ApplicationEnrollmentAppendDisposition.Uncertain, result.Disposition); Assert.True(result.PossibleOutput); Assert.Null(result.Receipt); Assert.Null(authority.ConfirmedEnrollment); Assert.NotNull(invalid); AssertBytes(invalid);
    }

    private static object Field(object owner, string name) => owner.GetType().GetField(name, BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(owner)!;
    private byte[] ReadRole(int index)
    {
        using var stream = new FileStream(Path.Combine(Authority, index == 2 ? "authority.log" : "authority.meta"), FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        var bytes = new byte[(int)stream.Length]; stream.ReadExactly(bytes); return bytes;
    }
    private sealed class TestIo(Action? check = null, string? fault = null) : IApplicationAuthorityAppendIo
    {
        internal int Writes { get; private set; }
        internal byte[] Surviving { get; private set; } = [];
        /// <inheritdoc/>
        public void Write(FileStream stream, ReadOnlySpan<byte> bytes)
        {
            check?.Invoke(); Writes++; if (fault == "write-before") throw new IOException("Before delegation");
            var count = fault == "partial" ? 17 : fault == "short" ? bytes.Length - 1 : fault == "zero" ? 0 : bytes.Length;
            stream.Write(bytes[..count]); if (fault == "extra") stream.WriteByte(42); stream.Flush(); Surviving = fault == "extra" ? [.. bytes.ToArray(), 42] : bytes[..count].ToArray();
            if (fault is "partial" or "write-after") throw new IOException("After actual output");
        }
        /// <inheritdoc/>
        public void Flush(FileStream stream)
        { check?.Invoke(); if (fault == "flush-before") throw new IOException("Before flush"); stream.Flush(true); if (fault == "flush-after") throw new IOException("After flush"); }
        /// <inheritdoc/>
        public void ReadBack(FileStream stream, Span<byte> bytes)
        { check?.Invoke(); if (fault == "read-before") throw new IOException("Before readback"); stream.ReadExactly(bytes); if (fault == "read-corrupt") bytes[0] ^= 1; if (fault == "read-after") throw new IOException("After readback"); }
    }
    private sealed class FailingClose(bool afterClose) : IEnrollmentSourceLeaseClose, IDisposable
    {
        private FileStream? _stream;
        /// <inheritdoc/>
        public void Close(FileStream stream) { _stream = stream; if (afterClose) stream.Dispose(); throw new IOException("Injected close uncertainty"); }
        /// <summary>Closes only the fresh fixture's captured handle without changing production release status.</summary>
        public void Dispose() => _stream?.Dispose();
    }
    /// <summary>Removes only this fixture's fresh owned workspace after handles close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
