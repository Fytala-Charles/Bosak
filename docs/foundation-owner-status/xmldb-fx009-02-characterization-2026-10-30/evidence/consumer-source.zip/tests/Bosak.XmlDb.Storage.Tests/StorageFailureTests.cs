// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Verifies recovery after injected disk-full and publication failures.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      | Charles Korthout | 0.2   | 26-10-2026     | Sweep checkpoint/reader failures and checkpoint/full recovery
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.3   | 26-10-2026     | Verify redundant descriptors, retention and publication faults
// ===========================================================================================================================================================

using System.Text;
using Bosak.XmlDb.Core;
using Xunit;
using Xunit.Abstractions;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Verifies recovery after injected disk-full and publication failures.</summary>
public sealed class StorageFailureTests(ITestOutputHelper output)
{
    /// <summary>Exercises every observed boundary around initialization, commit, replay and incomplete-tail cleanup.</summary>
    /// <param name="scenario">Operation sequence to exercise.</param>
    /// <param name="fault">Failure timing or a partial real write followed by disk-full error.</param>
    [Theory]
    [InlineData("initialize", "before")]
    [InlineData("initialize", "after")]
    [InlineData("initialize", "partial")]
    [InlineData("commit", "before")]
    [InlineData("commit", "after")]
    [InlineData("commit", "partial")]
    [InlineData("redo", "before")]
    [InlineData("redo", "after")]
    [InlineData("redo", "partial")]
    [InlineData("tail", "before")]
    [InlineData("tail", "after")]
    [InlineData("tail", "partial")]
    [InlineData("barrier-adoption", "before")]
    [InlineData("barrier-adoption", "after")]
    [InlineData("barrier-adoption", "partial")]
    [InlineData("checkpoint", "before")]
    [InlineData("checkpoint", "after")]
    [InlineData("checkpoint", "partial")]
    [InlineData("anchor", "before")]
    [InlineData("anchor", "after")]
    [InlineData("anchor", "partial")]
    [InlineData("reader", "before")]
    [InlineData("reader", "after")]
    [InlineData("reader", "partial")]
    public void Persistence_InjectedFault_RecoversWithoutMixedState(string scenario, string fault)
    {
        var referenceRoot = NewRoot();
        List<StorageCall> reference;
        try
        {
            Prepare(referenceRoot, scenario);
            var recording = NewStorage(scenario);
            Exercise(referenceRoot, scenario, recording);
            reference = recording.Calls.ToList();
        }
        finally { Remove(referenceRoot); }
        var targets = reference.Select((call, index) => (call, index))
            .Where(item => fault == "partial"
                ? item.call.Operation == "WriteFile" && item.call.Moment == "before"
                : item.call.Moment == fault).ToArray();
        Assert.NotEmpty(targets);
        foreach (var (call, index) in targets)
        {
            var root = NewRoot();
            try
            {
                Prepare(root, scenario);
                var storage = NewStorage(scenario);
                storage.FailureIndex = index;
                storage.PartialWrite = fault == "partial";
                var exception = Record.Exception(() => Exercise(root, scenario, storage, index, fault == "partial"));
                Assert.True(exception is IOException, $"{scenario}/{fault}/{index}/{call}: {exception}");
                Assert.True(storage.Fired, $"Missing injection: {scenario}/{fault}/{index}/{call}");
                Assert.Equal(call.Operation, storage.Calls[index].Operation);
                Assert.Equal(call.Moment, storage.Calls[index].Moment);
                var wal = Path.Combine(root, ".transactions", "wal", "00000000000000000001.wal");
                var expected = System.IO.File.Exists(wal) && TransactionCodec.ReadWal(wal) is not null ? 1UL : 0UL;
                for (var attempt = 0; attempt < 2; attempt++)
                {
                    using var database = EmbeddedXmlDatabase.Open(root, attempt == 0 ? RecoveryMode.FullJournal : RecoveryMode.PreferCheckpoint);
                    using var snapshot = database.BeginRead();
                    Assert.Equal(expected, snapshot.CommitSequence);
                    Assert.Equal(expected == 0 ? "old" : "new", snapshot.ReadValue(Target(snapshot)));
                    Assert.Equal("line", snapshot.ReadValue(Nodes(snapshot).Single(node => node.Kind == StorageNodeKind.Text && node.FragmentId == 2).Id));
                }
                // Recovery must release ownership and allow the next sequence after every injected failure.
                using var writable = EmbeddedXmlDatabase.Open(root);
                if (scenario == "checkpoint") Assert.Equal(expected, writable.CreateCheckpoint());
                if (scenario == "anchor") Assert.Equal(expected, writable.CreateRecoveryAnchor());
                using var read = writable.BeginRead();
                using var transaction = writable.BeginWrite();
                transaction.ReplaceNodeValue(Target(read), "later");
                Assert.Equal(expected + 1, transaction.Commit());
            }
            finally { Remove(root); }
        }
        output.WriteLine($"{scenario}/{fault}: {targets.Length} fault positions verified; {reference.Count} reference boundary events.");
    }

    private static FaultingTransactionStorage NewStorage(string scenario) => new(scenario == "barrier-adoption"
        ? DurabilityMode.FileAndDirectoryFlush : DurabilityMode.ProcessCrash);

    private static void Exercise(string root, string scenario, FaultingTransactionStorage storage, int? failure = null, bool partial = false)
    {
        if (scenario == "commit")
        {
            using var database = EmbeddedXmlDatabase.OpenCore(root, 1, null, storage);
            using var original = database.BeginRead();
            using var transaction = database.BeginWrite();
            transaction.ReplaceNodeValue(Target(original), "new");
            storage.Arm(failure, partial);
            try { transaction.Commit(); }
            catch (IOException)
            {
                Assert.Throws<InvalidOperationException>(() => database.BeginRead());
                Assert.Throws<InvalidOperationException>(() => database.BeginWrite());
                Assert.Equal("old", original.ReadValue(Target(original)));
                throw;
            }
        }
        else if (scenario is "checkpoint" or "reader" or "anchor")
        {
            using var database = EmbeddedXmlDatabase.OpenCore(root, 1, null, storage);
            storage.Arm(failure, partial);
            try
            {
                if (scenario == "anchor") database.CreateRecoveryAnchor();
                else if (scenario == "checkpoint") database.CreateCheckpoint();
                else { using var reader = database.BeginRead(); }
            }
            catch (IOException)
            {
                Assert.Throws<InvalidOperationException>(() => database.BeginRead());
                Assert.Throws<InvalidOperationException>(() => database.BeginWrite());
                throw;
            }
        }
        else
        {
            storage.Arm(failure, partial);
            using var database = EmbeddedXmlDatabase.OpenCore(root, 1, null, storage);
        }
    }

    private static void Prepare(string root, string scenario)
    {
        using (var xml = new MemoryStream(Encoding.UTF8.GetBytes("<SalesOrder><SalesOrderHeader><DocumentID>old</DocumentID></SalesOrderHeader><SalesOrderLine>line</SalesOrderLine></SalesOrder>")))
            XmlFragmentImporter.Import(xml, root, linesPerFragment: 1);
        if (scenario is "initialize" or "commit") return;
        if (scenario == "redo")
        {
            using var database = EmbeddedXmlDatabase.OpenCore(root, 1, stage =>
            {
                if (stage == CommitStage.WalFlushed) throw new IOException("Seed a committed but unpublished generation.");
            });
            using var read = database.BeginRead();
            using var write = database.BeginWrite();
            write.ReplaceNodeValue(Target(read), "new");
            Assert.Throws<IOException>(() => write.Commit());
            return;
        }
        using (var database = EmbeddedXmlDatabase.Open(root))
        {
            using var read = database.BeginRead();
            using var write = database.BeginWrite();
            write.ReplaceNodeValue(Target(read), "new");
            write.Commit();
        }
        if (scenario == "tail")
        {
            var bytes = TransactionCodec.EncodeWal(new(1, 2, Guid.NewGuid(), 1, "partial", new byte[32], new byte[32]));
            System.IO.File.WriteAllBytes(Path.Combine(root, ".transactions", "wal", "00000000000000000002.wal"), bytes[..16]);
        }
    }

    private static string NewRoot() => Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-iofault-" + Guid.NewGuid().ToString("N"));
    private static IEnumerable<StorageNode> Nodes(ImmutableXmlSnapshot snapshot) =>
        Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id));
    private static ulong Target(ImmutableXmlSnapshot snapshot) => Nodes(snapshot)
        .Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();
    private static void Remove(string root) { if (Directory.Exists(root)) Directory.Delete(root, true); }
}
