// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Injects storage errors around real transaction I/O operations.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.4   | 27-10-2026     | Add backup publication stages and owned-workspace cleanup seam
//                      | Charles Korthout | 0.5   | 27-10-2026     | Add explicit native durability delegation without changing modeled defaults
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage.Tests;

internal sealed record StorageCall(string Operation, string Path, string Moment);

internal sealed class FaultingTransactionStorage(DurabilityMode durability = DurabilityMode.ProcessCrash, bool useNativeDurability = false) : ITransactionStorage
{
    private readonly LocalTransactionStorage _local = new(useNativeDurability ? durability : DurabilityMode.ProcessCrash);
    internal DurabilityMode EffectiveDurability => _local.Durability;
    internal List<StorageCall> Calls { get; } = [];
    internal int? FailureIndex { get; set; }
    internal bool PartialWrite { get; set; }
    internal bool Fired { get; private set; }
    internal bool Armed { get; set; }
    public DurabilityMode Durability => durability;

    internal void Arm(int? failureIndex = null, bool partialWrite = false)
    {
        Calls.Clear();
        FailureIndex = failureIndex;
        PartialWrite = partialWrite;
        Fired = false;
        Armed = true;
    }

    private bool Hit(string operation, string path, string moment, bool mayDefer = false)
    {
        if (!Armed) return false;
        var index = Calls.Count;
        Calls.Add(new(operation, path, moment));
        if (Fired || index != FailureIndex) return false;
        Fired = true;
        if (mayDefer && PartialWrite) return true;
        throw DiskFull(operation, path);
    }

    private static IOException DiskFull(string operation, string path) =>
        new($"Injected disk-full/I/O error: {operation} {path}", unchecked((int)0x80070070));

    public ITransactionFile CreateFile(string path)
    {
        Hit("CreateFile", path, "before");
        var file = _local.CreateFile(path);
        try { Hit("CreateFile", path, "after"); }
        catch { file.Dispose(); throw; }
        return new File(this, path, file);
    }

    public void CreateDirectory(string path)
    {
        Hit("CreateDirectory", path, "before");
        _local.CreateDirectory(path);
        Hit("CreateDirectory", path, "after");
    }

    public void MoveFile(string source, string destination, bool overwrite)
    {
        Hit("MoveFile", destination, "before");
        _local.MoveFile(source, destination, overwrite);
        Hit("MoveFile", destination, "after");
    }

    public void MoveDirectory(string source, string destination)
    {
        Hit("MoveDirectory", destination, "before");
        _local.MoveDirectory(source, destination);
        Hit("MoveDirectory", destination, "after");
    }

    public void DeleteDirectory(string path)
    {
        Hit("DeleteDirectory", path, "before");
        _local.DeleteDirectory(path);
        Hit("DeleteDirectory", path, "after");
    }

    public void DeleteFile(string path)
    {
        Hit("DeleteFile", path, "before");
        _local.DeleteFile(path);
        Hit("DeleteFile", path, "after");
    }

    public void SyncDirectory(string path)
    {
        Hit("SyncDirectory", path, "before");
        _local.SyncDirectory(path); // Native mode delegates real Linux directory fsync; the default retains modeled ordering.
        Hit("SyncDirectory", path, "after");
    }

    public void SyncFile(string path)
    {
        Hit("SyncFile", path, "before");
        _local.SyncFile(path);
        Hit("SyncFile", path, "after");
    }

    private sealed class File(FaultingTransactionStorage owner, string path, ITransactionFile inner) : ITransactionFile
    {
        public void Write(ReadOnlySpan<byte> bytes)
        {
            if (owner.Hit("WriteFile", path, "before", mayDefer: true))
            {
                inner.Write(bytes[..Math.Max(1, bytes.Length / 2)]);
                throw DiskFull("partial WriteFile", path);
            }
            inner.Write(bytes);
            owner.Hit("WriteFile", path, "after");
        }

        public void FlushToDisk()
        {
            owner.Hit("FlushFile", path, "before");
            inner.FlushToDisk();
            owner.Hit("FlushFile", path, "after");
        }

        public void Dispose()
        {
            try { owner.Hit("CloseFile", path, "before"); }
            finally { inner.Dispose(); }
            owner.Hit("CloseFile", path, "after");
        }
    }
}
