// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Rejects resealed malformed authority frames and illegal retained-history transitions.
// SPECIAL NOTES        : Read-only fixture input and in-memory mutations; no host/store roots are opened or repaired.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Text;
using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Rejects resealed malformed authority frames and illegal retained-history transitions.</summary>
public sealed partial class ApplicationAuthorityCodecTests
{
    /// <summary>Well-sealed malformed headers and TLVs reject without relying on checksum failure.</summary>
    /// <param name="fault">Envelope or nested field corruption.</param>
    [Theory]
    [InlineData("magic")]
    [InlineData("version")]
    [InlineData("flags")]
    [InlineData("length-zero")]
    [InlineData("length-overflow")]
    [InlineData("sequence-zero")]
    [InlineData("sequence-bound")]
    [InlineData("authority")]
    [InlineData("predecessor")]
    [InlineData("metadata")]
    [InlineData("seal")]
    [InlineData("checksum")]
    [InlineData("event")]
    [InlineData("duplicate")]
    [InlineData("unknown")]
    [InlineData("missing")]
    [InlineData("reordered")]
    [InlineData("empty")]
    [InlineData("declared-overflow")]
    [InlineData("owner-empty")]
    [InlineData("generation-zero")]
    [InlineData("revision-zero")]
    [InlineData("branch")]
    [InlineData("proof-length")]
    [InlineData("nested-unknown")]
    [InlineData("root-kind")]
    [InlineData("root-doc")]
    [InlineData("root-head")]
    [InlineData("root-digest")]
    [InlineData("root-utf8")]
    [InlineData("root-nul")]
    [InlineData("root-bom")]
    [InlineData("root-long")]
    [InlineData("legacy-epoch")]
    [InlineData("epoch-missing")]
    [InlineData("epoch-extra")]
    public void DecodeFrame_ResealedMalformedBytes_Rejects(string fault)
    {
        var bytes = Fixture("application-authority-enroll-v1.hex");
        switch (fault)
        {
            case "magic": bytes[0] ^= 1; break;
            case "version": bytes[8] = 2; break;
            case "flags": bytes[10] = 1; break;
            case "length-zero": BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(12), 0); break;
            case "length-overflow": BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(12), uint.MaxValue); break;
            case "sequence-zero": BinaryPrimitives.WriteUInt64LittleEndian(bytes.AsSpan(16), 0); break;
            case "sequence-bound": BinaryPrimitives.WriteUInt64LittleEndian(bytes.AsSpan(16), 65537); break;
            case "authority": bytes[24] ^= 1; break;
            case "predecessor": bytes[40] = 1; break;
            case "metadata": bytes[72] ^= 1; break;
            case "seal": bytes[^1] ^= 1; break;
            case "checksum": break;
            default: bytes = PatchPayload(bytes, payload => MalformedPayload(payload, fault)); break;
        }
        if (fault == "checksum") bytes[^40] ^= 1; else Reseal(bytes);
        Assert.Throws<InvalidDataException>(() => ApplicationAuthorityCodec.DecodeFrame(bytes, Metadata()));
        Assert.Throws<InvalidDataException>(() => ApplicationAuthorityCodec.DecodeJournal(bytes, Metadata()));
    }

    private static byte[] MalformedPayload(byte[] payload, string fault)
    {
        if (fault == "declared-overflow") { BinaryPrimitives.WriteUInt32LittleEndian(payload.AsSpan(2), uint.MaxValue); return payload; }
        var fields = ReadFields(payload);
        switch (fault)
        {
            case "event": fields[0] = (1, [255]); break;
            case "duplicate": fields.Insert(1, fields[0]); break;
            case "unknown": fields.Add((9, [1])); break;
            case "missing": fields.RemoveAt(1); break;
            case "reordered": (fields[0], fields[1]) = (fields[1], fields[0]); break;
            case "empty": fields[0] = (1, []); break;
            case "owner-empty": fields[1] = (2, new byte[16]); break;
            case "generation-zero": fields[2] = (3, Number(0)); break;
            case "revision-zero": fields[4] = (5, Number(0)); break;
            case "branch": fields[5] = (6, [0]); break;
            case "proof-length": fields[6] = (7, new byte[31]); break;
            case "nested-unknown": fields[7] = (8, [.. fields[7].Value, .. RawTlv([(2, [1])])]); break;
            default:
                var data = ReadFields(fields[7].Value); var root = ReadFields(data[0].Value);
                switch (fault)
                {
                    case "root-kind": root[0] = (1, [3]); break;
                    case "root-doc": root[3] = (4, Number(0)); break;
                    case "root-head": root[4] = (5, Number(10001)); break;
                    case "root-digest": root[5] = (6, new byte[31]); break;
                    case "root-utf8": root[1] = (2, [0xc3, 0xff]); break;
                    case "root-nul": root[1] = (2, [97, 0, 98]); break;
                    case "root-bom": root[1] = (2, [0xef, 0xbb, 0xbf, 97]); break;
                    case "root-long": root[1] = (2, Encoding.UTF8.GetBytes(new string('a', 4097))); break;
                    case "legacy-epoch": root.Add((7, EpochFields())); break;
                    case "epoch-missing": root[0] = (1, [2]); break;
                    case "epoch-extra": root[0] = (1, [2]); root.Add((7, [.. EpochFields(), .. RawTlv([(3, [1])])])); break;
                    default: throw new ArgumentOutOfRangeException(nameof(fault));
                }
                data[0] = (1, RawTlv(root)); fields[7] = (8, RawTlv(data)); break;
        }
        return RawTlv(fields);
    }

    /// <summary>Resealed chain discontinuity rejects even when every individual frame is valid.</summary>
    /// <param name="fault">Chain field changed in the second frame.</param>
    [Theory]
    [InlineData("sequence")]
    [InlineData("predecessor")]
    [InlineData("metadata")]
    public void DecodeJournal_ResealedDiscontinuousChain_Rejects(string fault)
    {
        var entries = Basic(); var first = Journal(entries.Take(1)); var combined = Journal(entries);
        var second = combined[first.Length..];
        if (fault == "sequence") BinaryPrimitives.WriteUInt64LittleEndian(second.AsSpan(16), 3);
        if (fault == "predecessor") second[40] ^= 1;
        if (fault == "metadata") second[72] ^= 1;
        Reseal(second);
        Assert.Throws<InvalidDataException>(() => ApplicationAuthorityCodec.DecodeJournal([.. first, .. second], Metadata()));
    }

    /// <summary>Illegal history transitions reject as a whole despite valid field shapes and frame hashes.</summary>
    /// <param name="fault">Illegal transition or binding substitution.</param>
    [Theory]
    [InlineData("first-register")]
    [InlineData("second-enrollment")]
    [InlineData("second-registration")]
    [InlineData("select-unregistered")]
    [InlineData("accept-unregistered")]
    [InlineData("enroll-generation")]
    [InlineData("enroll-revision")]
    [InlineData("enroll-candidate")]
    [InlineData("owner")]
    [InlineData("generation")]
    [InlineData("baseline")]
    [InlineData("selection")]
    [InlineData("candidate-legacy")]
    [InlineData("candidate-document")]
    [InlineData("candidate-head")]
    [InlineData("same-root")]
    [InlineData("same-admission")]
    [InlineData("publication-role")]
    [InlineData("same-store")]
    [InlineData("same-epoch")]
    [InlineData("select-old-revision")]
    [InlineData("select-old-branch")]
    [InlineData("select-same-target")]
    [InlineData("select-skipped-revision")]
    [InlineData("select-overflow")]
    [InlineData("transfer-old-owner")]
    [InlineData("transfer-old-generation")]
    [InlineData("transfer-same-owner")]
    [InlineData("transfer-skipped-generation")]
    [InlineData("transfer-overflow")]
    [InlineData("after-transfer-old-owner")]
    [InlineData("transfer-first")]
    [InlineData("unknown-work")]
    [InlineData("wrong-intent")]
    [InlineData("wrong-acceptance-sequence")]
    [InlineData("wrong-root-digest")]
    [InlineData("outcome-new-owner")]
    [InlineData("duplicate-outcome")]
    [InlineData("unknown-then-outcome")]
    [InlineData("unknown-observation-then-outcome")]
    [InlineData("conflicting-terminal")]
    [InlineData("terminal-downgrade")]
    [InlineData("accept-pending")]
    [InlineData("reused-work")]
    [InlineData("select-after-commit")]
    [InlineData("select-after-noeffect")]
    [InlineData("observation-revision")]
    [InlineData("observation-branch")]
    [InlineData("observation-work-sequence")]
    public void DecodeJournal_IllegalTransition_Rejects(string fault)
    {
        var entries = Basic();
        var select = Entry(new ApplicationSelect(1, PilotBranch.Source)) with { SelectionRevision = 2, Selected = PilotBranch.Candidate };
        var transfer = Entry(new ApplicationTransfer(Owner, 1)) with { OwnerSession = Owner2, OwnerGeneration = 2 };
        var outcome = Entry(new ApplicationOutcome(Reference(), PilotWorkOutcome.Committed));
        var observe = Entry(new ApplicationObserve(ApplicationObservationKind.WorkCommitted, Reference(), 1, PilotBranch.Source));
        switch (fault)
        {
            case "first-register": entries.RemoveAt(0); break;
            case "second-enrollment": entries.Add(entries[0]); break;
            case "second-registration": entries.Add(entries[1]); break;
            case "select-unregistered": entries.RemoveAt(1); entries.Add(select); break;
            case "accept-unregistered": entries.RemoveAt(1); entries.Add(Entry(Accept())); break;
            case "enroll-generation": entries[0] = entries[0] with { OwnerGeneration = 2 }; break;
            case "enroll-revision": entries[0] = entries[0] with { SelectionRevision = 2 }; break;
            case "enroll-candidate": entries[0] = entries[0] with { Selected = PilotBranch.Candidate }; break;
            case "owner": entries[1] = entries[1] with { OwnerSession = Owner2 }; break;
            case "generation": entries[1] = entries[1] with { OwnerGeneration = 2 }; break;
            case "baseline": entries[1] = entries[1] with { BaselineId = Owner2 }; break;
            case "selection": entries[1] = entries[1] with { SelectionRevision = 2, Selected = PilotBranch.Candidate }; break;
            case "candidate-legacy": entries[1] = Entry(new ApplicationRegister(Root(true) with { Kind = PilotRootKind.Legacy, Epoch = null }, Publication())); break;
            case "candidate-document": entries[1] = Entry(new ApplicationRegister(Root(true) with { DocumentId = 8, Epoch = Root(true).Epoch! with { DocumentId = 8 } }, Publication())); break;
            case "candidate-head": entries[1] = Entry(new ApplicationRegister(Root(true) with { InitialSequence = 2 }, Publication())); break;
            case "same-root": entries[1] = Entry(new ApplicationRegister(Root(true) with { RootKey = "SOURCE-ROOT" }, Publication())); break;
            case "same-admission": entries[1] = Entry(new ApplicationRegister(Root(true) with { AdmissionKey = "SOURCE-ADMISSION" }, Publication())); break;
            case "publication-role": entries[1] = Entry(new ApplicationRegister(Root(true), Publication(true))); break;
            case "same-store":
            case "same-epoch":
                entries = Basic(true); var epoch = Root(true).Epoch!;
                epoch = fault == "same-store" ? epoch with { StoreId = Root(false, true).Epoch!.StoreId } : epoch with { EpochId = Root(false, true).Epoch!.EpochId };
                entries[1] = Entry(new ApplicationRegister(Root(true) with { Epoch = epoch }, Publication(true))); break;
            case "select-old-revision": entries.Add(select with { Data = new ApplicationSelect(2, PilotBranch.Source) }); break;
            case "select-old-branch": entries.Add(select with { Data = new ApplicationSelect(1, PilotBranch.Candidate) }); break;
            case "select-same-target": entries.Add(select with { Selected = PilotBranch.Source }); break;
            case "select-skipped-revision": entries.Add(select with { SelectionRevision = 3 }); break;
            case "select-overflow": entries.Add(select with { SelectionRevision = ulong.MaxValue }); break;
            case "transfer-old-owner": entries.Add(transfer with { Data = new ApplicationTransfer(Owner2, 1) }); break;
            case "transfer-old-generation": entries.Add(transfer with { Data = new ApplicationTransfer(Owner, 2) }); break;
            case "transfer-same-owner": entries.Add(transfer with { OwnerSession = Owner }); break;
            case "transfer-skipped-generation": entries.Add(transfer with { OwnerGeneration = 3 }); break;
            case "transfer-overflow": entries.Add(transfer with { OwnerGeneration = ulong.MaxValue }); break;
            case "after-transfer-old-owner": entries.Add(transfer); entries.Add(Entry(new ApplicationObserve(ApplicationObservationKind.Selection, null, 1, PilotBranch.Source))); break;
            case "transfer-first": entries = [transfer]; break;
            case "unknown-work": entries.Add(outcome); break;
            case "wrong-root-digest": entries.Add(Entry(Accept() with { RootDigest = Digest('f') })); break;
            case "observation-revision": entries.Add(Entry(new ApplicationObserve(ApplicationObservationKind.Selection, null, 2, PilotBranch.Source))); break;
            case "observation-branch": entries.Add(Entry(new ApplicationObserve(ApplicationObservationKind.Selection, null, 1, PilotBranch.Candidate))); break;
            default:
                entries.Add(Entry(Accept()));
                switch (fault)
                {
                    case "wrong-intent": entries.Add(outcome with { Data = new ApplicationOutcome(Reference() with { IntentDigest = Digest('a') }, PilotWorkOutcome.Committed) }); break;
                    case "wrong-acceptance-sequence": entries.Add(outcome with { Data = new ApplicationOutcome(Reference(4), PilotWorkOutcome.Committed) }); break;
                    case "outcome-new-owner": entries.Add(transfer); entries.Add(outcome with { OwnerSession = Owner2, OwnerGeneration = 2 }); break;
                    case "duplicate-outcome": entries.Add(outcome); entries.Add(outcome); break;
                    case "unknown-then-outcome": entries.Add(outcome with { Data = new ApplicationOutcome(Reference(), PilotWorkOutcome.Unknown) }); entries.Add(outcome); break;
                    case "unknown-observation-then-outcome": entries.Add(Entry(new ApplicationObserve(ApplicationObservationKind.WorkUnknown, Reference(), 1, PilotBranch.Source))); entries.Add(outcome); break;
                    case "conflicting-terminal": entries.Add(outcome); entries.Add(observe with { Data = new ApplicationObserve(ApplicationObservationKind.WorkNoEffect, Reference(), 1, PilotBranch.Source) }); break;
                    case "terminal-downgrade": entries.Add(outcome); entries.Add(observe with { Data = new ApplicationObserve(ApplicationObservationKind.WorkUnknown, Reference(), 1, PilotBranch.Source) }); break;
                    case "accept-pending": entries.Add(Entry(Accept(Owner2))); break;
                    case "reused-work": entries.Add(outcome); entries.Add(Entry(Accept())); break;
                    case "select-after-commit": entries.Add(outcome); entries.Add(select); break;
                    case "select-after-noeffect": entries.Add(outcome with { Data = new ApplicationOutcome(Reference(), PilotWorkOutcome.NoEffect) }); entries.Add(select); break;
                    case "observation-work-sequence": entries.Add(observe with { Data = new ApplicationObserve(ApplicationObservationKind.WorkCommitted, Reference(4), 1, PilotBranch.Source) }); break;
                    default: throw new ArgumentOutOfRangeException(nameof(fault));
                }
                break;
        }
        var bytes = Journal(entries);
        Assert.Throws<InvalidDataException>(() => ApplicationAuthorityCodec.DecodeJournal(bytes, Metadata()));
    }

    /// <summary>Every source profile, selected branch and outcome retains work across a valid owner transfer.</summary>
    /// <param name="restore">Whether source is ScalarWal.</param>
    /// <param name="candidate">Whether candidate was explicitly selected before acceptance.</param>
    /// <param name="outcome">Actual or unknown work outcome.</param>
    [Theory]
    [InlineData(false, false, 0)]
    [InlineData(false, false, 1)]
    [InlineData(false, false, 2)]
    [InlineData(false, true, 0)]
    [InlineData(false, true, 1)]
    [InlineData(false, true, 2)]
    [InlineData(true, false, 0)]
    [InlineData(true, false, 1)]
    [InlineData(true, false, 2)]
    [InlineData(true, true, 0)]
    [InlineData(true, true, 1)]
    [InlineData(true, true, 2)]
    public void DecodeJournal_ValidOutcomeTransfer_PreservesObligations(bool restore, bool candidate, int outcome)
    {
        var entries = Basic(restore); var branch = candidate ? PilotBranch.Candidate : PilotBranch.Source; ulong revision = candidate ? 2ul : 1ul;
        if (candidate) entries.Add(Entry(new ApplicationSelect(1, PilotBranch.Source)) with { SelectionRevision = revision, Selected = branch });
        var acceptedSequence = (ulong)entries.Count + 1;
        var accept = Entry(new ApplicationAccept(WorkId, Digest('c'), ApplicationAuthorityCodec.RootDigest(Root(candidate, restore)))) with { SelectionRevision = revision, Selected = branch };
        entries.Add(accept); var reference = Reference(acceptedSequence); var result = (PilotWorkOutcome)outcome;
        entries.Add(accept with { Data = new ApplicationOutcome(reference, result) });
        entries.Add(accept with { Data = new ApplicationTransfer(Owner, 1), OwnerSession = Owner2, OwnerGeneration = 2 });
        var kind = result switch { PilotWorkOutcome.Committed => ApplicationObservationKind.WorkCommitted, PilotWorkOutcome.NoEffect => ApplicationObservationKind.WorkNoEffect, _ => ApplicationObservationKind.WorkUnknown };
        entries.Add(accept with { Data = new ApplicationObserve(kind, reference, revision, branch), OwnerSession = Owner2, OwnerGeneration = 2 });
        var history = ApplicationAuthorityCodec.DecodeJournal(Journal(entries), Metadata());
        var work = Assert.Single(history.Work); Assert.Equal(result, work.Outcome); Assert.Equal(Owner, work.AcceptingOwner);
        Assert.Equal(1ul, work.AcceptingGeneration); Assert.Equal(branch, work.Branch); Assert.Equal(revision, work.SelectionRevision);
        Assert.Equal(candidate ? 0ul : 1ul, history.SourceAccepted); Assert.Equal(candidate ? 1ul : 0ul, history.CandidateAccepted);
        Assert.True(history.WritersMustRemainStopped);
    }

    /// <summary>All 1,024 unique acceptances remain counted; one more refuses without truncating obligations.</summary>
    [Fact]
    public void DecodeJournal_WorkCapacity_AcceptsExactBoundRejectsNext()
    {
        var entries = Basic();
        for (var index = 0; index < ApplicationAuthorityCodec.MaximumWork; index++)
        {
            var id = new Guid(index + 1, 0, 0, new byte[8]); var sequence = (ulong)entries.Count + 1;
            entries.Add(Entry(Accept(id))); entries.Add(Entry(new ApplicationOutcome(new(id, Digest('c'), sequence), PilotWorkOutcome.NoEffect)));
        }
        var bytes = Journal(entries); var history = ApplicationAuthorityCodec.DecodeJournal(bytes, Metadata());
        Assert.Equal(1024ul, history.SourceAccepted); Assert.Equal(1024, history.Work.Length); Assert.True(history.WritersMustRemainStopped);
        entries.Add(Entry(Accept()));
        Assert.Throws<InvalidDataException>(() => ApplicationAuthorityCodec.DecodeJournal(Journal(entries), Metadata()));
        Assert.Equal(1024, history.Work.Length);
    }

    /// <summary>The complete frame bound succeeds and any additional byte rejects before another header read.</summary>
    [Fact]
    public void ReadJournal_FrameCapacity_AcceptsExactBoundRejectsNextByte()
    {
        var enrollment = Entry(new ApplicationEnroll(Root(false)));
        var observation = Entry(new ApplicationObserve(ApplicationObservationKind.Selection, null, 1, PilotBranch.Source));
        var entries = Enumerable.Repeat(observation, ApplicationAuthorityCodec.MaximumFrames - 1).Prepend(enrollment);
        var bytes = Journal(entries); var history = ApplicationAuthorityCodec.DecodeJournal(bytes, Metadata());
        Assert.Equal(65536, history.Frames.Length); Assert.True(history.WritersMustRemainStopped);
        using var input = new ShortInput([.. bytes, 1], int.MaxValue);
        Assert.Throws<InvalidDataException>(() => ApplicationAuthorityCodec.ReadJournal(input, Metadata()));
        Assert.Equal(bytes.Length + 1, input.BytesRead); Assert.False(input.Disposed);
    }

    /// <summary>An oversized byte-array log is rejected before its bytes can be interpreted as a valid prefix.</summary>
    [Fact]
    public void DecodeJournal_ByteCapacity_RejectsOversizedInput()
    {
        var bytes = new byte[ApplicationAuthorityCodec.MaximumJournalBytes + 1];
        Assert.Throws<InvalidDataException>(() => ApplicationAuthorityCodec.DecodeJournal(bytes, Metadata()));
    }

    /// <summary>Typed records cannot smuggle forbidden optional fields or unsupported enum values into canonical frames.</summary>
    /// <param name="fault">Invalid typed record field.</param>
    [Theory]
    [InlineData("outcome-enum")]
    [InlineData("observation-enum")]
    [InlineData("selection-with-work")]
    [InlineData("work-without-reference")]
    [InlineData("zero-acceptance-sequence")]
    [InlineData("zero-transfer-generation")]
    [InlineData("zero-prior-selection")]
    [InlineData("unknown-root")]
    [InlineData("unknown-branch")]
    [InlineData("zero-generation")]
    [InlineData("zero-revision")]
    [InlineData("empty-owner")]
    [InlineData("empty-baseline")]
    [InlineData("empty-work")]
    [InlineData("uppercase-proof")]
    [InlineData("zero-document")]
    [InlineData("missing-epoch")]
    [InlineData("publication-sequence")]
    [InlineData("publication-enum")]
    public void EncodeFrame_InvalidEventShapes_Rejects(string fault)
    {
        var e = Entry(new ApplicationEnroll(Root(false)));
        e = fault switch
        {
            "outcome-enum" => e with { Data = new ApplicationOutcome(Reference(), (PilotWorkOutcome)99) },
            "observation-enum" => e with { Data = new ApplicationObserve((ApplicationObservationKind)99, null, 1, PilotBranch.Source) },
            "selection-with-work" => e with { Data = new ApplicationObserve(ApplicationObservationKind.Selection, Reference(), 1, PilotBranch.Source) },
            "work-without-reference" => e with { Data = new ApplicationObserve(ApplicationObservationKind.WorkCommitted, null, 1, PilotBranch.Source) },
            "zero-acceptance-sequence" => e with { Data = new ApplicationOutcome(Reference(0), PilotWorkOutcome.Committed) },
            "zero-transfer-generation" => e with { Data = new ApplicationTransfer(Owner, 0) },
            "zero-prior-selection" => e with { Data = new ApplicationSelect(0, PilotBranch.Source) },
            "unknown-root" => e with { Data = new ApplicationEnroll(Root(false) with { Kind = (PilotRootKind)99 }) },
            "unknown-branch" => e with { Selected = (PilotBranch)99 },
            "zero-generation" => e with { OwnerGeneration = 0 },
            "zero-revision" => e with { SelectionRevision = 0 },
            "empty-owner" => e with { OwnerSession = Guid.Empty },
            "empty-baseline" => e with { BaselineId = Guid.Empty },
            "empty-work" => e with { Data = Accept(Guid.Empty) },
            "uppercase-proof" => e with { EvidenceDigest = Digest('F') },
            "zero-document" => e with { Data = new ApplicationEnroll(Root(false) with { DocumentId = 0 }) },
            "missing-epoch" => e with { Data = new ApplicationEnroll(Root(true) with { Epoch = null }) },
            "publication-sequence" => e with { Data = new ApplicationRegister(Root(true), Publication() with { AdministrativeSequence = 0 }) },
            "publication-enum" => e with { Data = new ApplicationRegister(Root(true), Publication() with { Kind = (EpochPublicationKind)99 }) },
            _ => throw new ArgumentOutOfRangeException(nameof(fault))
        };
        Assert.Throws<InvalidDataException>(() => ApplicationAuthorityCodec.EncodeFrame(Metadata(), 1, Zero, e));
    }
    private static byte[] Number(ulong value) { var result = new byte[8]; BinaryPrimitives.WriteUInt64LittleEndian(result, value); return result; }
    private static byte[] EpochFields()
    {
        var a = new byte[16]; var b = new byte[16]; Owner.TryWriteBytes(a, true, out _); Owner2.TryWriteBytes(b, true, out _);
        return RawTlv([(1, a), (2, b)]);
    }
    private static List<(ushort Tag, byte[] Value)> ReadFields(byte[] bytes)
    {
        var fields = new List<(ushort, byte[])>(); var offset = 0;
        while (offset < bytes.Length)
        {
            var tag = BinaryPrimitives.ReadUInt16LittleEndian(bytes.AsSpan(offset)); var length = (int)BinaryPrimitives.ReadUInt32LittleEndian(bytes.AsSpan(offset + 2));
            fields.Add((tag, bytes.AsSpan(offset + 6, length).ToArray())); offset += 6 + length;
        }
        return fields;
    }
    private static byte[] RawTlv(IEnumerable<(ushort Tag, byte[] Value)> fields)
    {
        using var output = new MemoryStream();
        foreach (var field in fields)
        {
            var header = new byte[6]; BinaryPrimitives.WriteUInt16LittleEndian(header, field.Tag);
            BinaryPrimitives.WriteUInt32LittleEndian(header.AsSpan(2), (uint)field.Value.Length); output.Write(header); output.Write(field.Value);
        }
        return output.ToArray();
    }
    private static byte[] PatchPayload(byte[] frame, Func<byte[], byte[]> change)
    {
        var payload = change(frame.AsSpan(104, frame.Length - 144).ToArray()); var result = new byte[144 + payload.Length];
        frame.AsSpan(0, 104).CopyTo(result); BinaryPrimitives.WriteUInt32LittleEndian(result.AsSpan(12), (uint)payload.Length);
        payload.CopyTo(result, 104); "AJEND001"u8.CopyTo(result.AsSpan(result.Length - 8)); Reseal(result); return result;
    }
    private static void Reseal(byte[] frame) => SHA256.HashData(frame.AsSpan(0, frame.Length - 40), frame.AsSpan(frame.Length - 40, 32));
}
