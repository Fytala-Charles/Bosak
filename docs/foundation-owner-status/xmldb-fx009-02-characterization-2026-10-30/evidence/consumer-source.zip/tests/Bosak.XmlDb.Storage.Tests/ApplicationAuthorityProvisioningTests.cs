// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Qualifies no-overwrite provisioning and live-only initializer reservations.
// SPECIAL NOTES        : Private metadata-only roots; no application write or enrollment append is exercised.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using Xunit;

namespace Bosak.XmlDb.Storage.Tests;

/// <summary>Qualifies no-overwrite provisioning and live-only initializer reservations.</summary>
public sealed class ApplicationAuthorityProvisioningTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-authority-provision-" + Guid.NewGuid().ToString("N"));
    private string Host => Path.Combine(_area, "host");
    private string Root => Path.Combine(_area, "authority");
    private string Source => Path.Combine(_area, "source");
    private readonly Guid _admin = Guid.NewGuid();
    private ApplicationAuthorityConfiguration Configuration => new(Guid.Parse("10213243-5465-7687-98a9-bacbdcedfe0f"), _admin, "pilot", "orders", "admin", "authority");
    private Dictionary<string, string> Roots => new() { ["admin"] = Host, ["authority"] = Root, ["source"] = Source };
    private EmbeddedHostLifetime Parent()
    {
        Directory.CreateDirectory(Host); Directory.CreateDirectory(Source);
        File.WriteAllBytes(Path.Combine(Host, "owner.lock"), []);
        File.WriteAllBytes(Path.Combine(Host, "host.meta"), HostJournalCodec.EncodeMetadata(_admin, "pilot", "orders"));
        File.WriteAllBytes(Path.Combine(Host, "journal.bin"), []);
        return EmbeddedHostLifetime.OpenExisting(Host, "pilot", "orders", [Source, Root]);
    }
    private static byte[] ReadShared(string path)
    {
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        var bytes = new byte[(int)stream.Length]; stream.ReadExactly(bytes); return bytes;
    }
    private static EmbeddedHostInspectionEvidence Inspection(EmbeddedHostLifetime parent) => new(parent.Context, true, true, true, true, true);
    private ApplicationAuthorityLifetime Provision(EmbeddedHostLifetime parent, Action<ApplicationProvisionStage>? checkpoint = null,
        ApplicationProvisionEvidence? evidence = null, Dictionary<string, string>? roots = null) =>
        ApplicationAuthorityLifetime.ProvisionCore(parent, parent.JournalStatus.KnownPosition, Inspection(parent), Root, Configuration,
            roots ?? Roots, evidence ?? new(Root, true, true, true), new LocalTransactionStorage(), checkpoint);

    /// <summary>Original ownership and both parent/child leases survive disposal while the reservation is live.</summary>
    [Fact]
    public void Provision_LiveReservation_HoldsBothOwnersUntilActualDrain()
    {
        using var parent = Parent();
        var before = HostJournalCodec.EncodeMetadata(_admin, "pilot", "orders");
        var authority = Provision(parent, stage =>
        {
            if (stage >= ApplicationProvisionStage.OwnerCreated)
                Assert.Throws<IOException>(() => new FileStream(Path.Combine(Root, "authority.lock"), FileMode.Open, FileAccess.ReadWrite, FileShare.None));
        });
        Assert.True(authority.WritersMustRemainStopped); Assert.Empty(authority.History.Frames);
        Assert.Equal(ApplicationAuthorityCodec.EncodeMetadata(Configuration), ReadShared(Path.Combine(Root, "authority.meta")));
        Assert.Empty(ReadShared(Path.Combine(Root, "authority.log")));
        var reservation = authority.ReserveInitializer();
        Assert.Throws<InvalidOperationException>(() => authority.ReserveInitializer());
        authority.Dispose(); parent.Dispose(); Assert.False(authority.IsReleased);
        Assert.Throws<IOException>(() => new FileStream(Path.Combine(Host, "owner.lock"), FileMode.Open, FileAccess.ReadWrite, FileShare.None));
        reservation.Dispose(); reservation.Dispose(); Assert.True(authority.IsReleased); Assert.True(parent.IsReleased);
        Assert.Equal(before, File.ReadAllBytes(Path.Combine(Host, "host.meta")));
    }

    /// <summary>An unchanged empty reopen does not recreate the live initialization privilege.</summary>
    [Fact]
    public void OpenExisting_EmptyProvisionedRoot_CannotReserveInitializer()
    {
        using var parent = Parent(); using (var created = Provision(parent)) { }
        using var reopened = ApplicationAuthorityLifetime.OpenExisting(parent, parent.JournalStatus.KnownPosition, Inspection(parent), Root, Configuration, Roots);
        Assert.Throws<InvalidOperationException>(() => reopened.ReserveInitializer());
        Assert.Empty(reopened.Inspect().Frames);
        reopened.Dispose(); Assert.Throws<IOException>(() => Provision(parent));
    }

    /// <summary>Every exposed interruption retains bytes and forbids completing the same root.</summary>
    /// <param name="boundary">Interrupted boundary.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(2)]
    [InlineData(3)]
    [InlineData(4)]
    [InlineData(5)]
    [InlineData(6)]
    [InlineData(7)]
    [InlineData(8)]
    [InlineData(9)]
    public void Provision_Interrupted_RetainsPartialState(int boundary)
    {
        var stage = (ApplicationProvisionStage)boundary;
        using var parent = Parent();
        Assert.Throws<IOException>(() => Provision(parent, current => { if (current == stage) throw new IOException("Injected boundary failure."); }));
        Assert.Equal(0, parent.ActiveOperations);
        if (stage == ApplicationProvisionStage.PreflightValidated) { Assert.False(Directory.Exists(Root)); return; }
        var before = Directory.GetFiles(Root).ToDictionary(p => p, File.ReadAllBytes);
        Assert.Throws<IOException>(() => Provision(parent));
        Assert.Equal(before.Keys.Order(), Directory.GetFiles(Root).Order());
        foreach (var pair in before) Assert.Equal(pair.Value, File.ReadAllBytes(pair.Key));
    }

    /// <summary>Untrusted provisioning assertions are rejected before root creation.</summary>
    /// <param name="flag">Missing assertion.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(2)]
    [InlineData(3)]
    public void Provision_UnqualifiedEvidence_DoesNotCreateRoot(int flag)
    {
        using var parent = Parent();
        Assert.Throws<InvalidOperationException>(() => Provision(parent, evidence: new(flag == 3 ? Source : Root, flag != 0, flag != 1, flag != 2)));
        Assert.False(Directory.Exists(Root)); Assert.Equal(0, parent.ActiveOperations);
    }

    /// <summary>Existing roots of every partial shape remain untouched.</summary>
    /// <param name="shape">Existing root shape.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(2)]
    public void Provision_ExistingPath_DoesNotResumeOrOverwrite(int shape)
    {
        using var parent = Parent();
        if (shape == 0) File.WriteAllText(Root, "retain");
        else { Directory.CreateDirectory(Root); if (shape == 2) File.WriteAllText(Path.Combine(Root, "authority.meta"), "partial"); }
        Assert.Throws<IOException>(() => Provision(parent)); Assert.Equal(0, parent.ActiveOperations);
        if (shape == 0) Assert.Equal("retain", File.ReadAllText(Root));
        if (shape == 2) Assert.Equal("partial", File.ReadAllText(Path.Combine(Root, "authority.meta")));
    }

    /// <summary>Disposal during provisioning prevents handoff and releases the retained parent mode.</summary>
    /// <param name="stage">Disposal boundary.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    public void Provision_ParentDisposed_FailsClosed(int stage)
    {
        using var parent = Parent();
        Assert.Throws<ObjectDisposedException>(() => Provision(parent, current =>
        {
            if (current == (stage == 0 ? ApplicationProvisionStage.PreflightValidated : ApplicationProvisionStage.BeforeReturn)) parent.Dispose();
        }));
        Assert.True(parent.IsReleased);
    }

    /// <summary>Two callers can claim at most one actual live reservation.</summary>
    [Fact]
    public void ReserveInitializer_ConcurrentClaims_ExactlyOneWins()
    {
        using var parent = Parent(); using var authority = Provision(parent);
        var results = new System.Collections.Concurrent.ConcurrentBag<IDisposable>();
        Parallel.For(0, 8, _ => { try { results.Add(authority.ReserveInitializer()); } catch (InvalidOperationException) { } });
        Assert.Single(results); foreach (var result in results) result.Dispose(); Assert.Equal(0, authority.ActiveInspections);
    }

    /// <summary>Protected planned descendants are rejected before filesystem creation.</summary>
    [Fact]
    public void Provision_PlannedOverlap_DoesNotCreateRoot()
    {
        using var parent = Parent(); var roots = Roots; roots["source"] = Path.Combine(Root, "future");
        Assert.Throws<InvalidDataException>(() => Provision(parent, roots: roots)); Assert.False(Directory.Exists(Root));
    }

    /// <summary>All observed storage boundaries and real partial metadata writes retain their interrupted state.</summary>
    /// <param name="partial">Whether to inject actual partial bytes at the metadata write.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Provision_StorageFaults_RetainsEveryObservedOutcome(bool partial)
    {
        var trace = new FaultingTransactionStorage(); trace.Arm();
        using (var baseline = new ApplicationAuthorityProvisioningTests())
        using (var parent = baseline.Parent())
        using (var authority = ApplicationAuthorityLifetime.ProvisionCore(parent, parent.JournalStatus.KnownPosition, Inspection(parent),
            baseline.Root, baseline.Configuration, baseline.Roots, new(baseline.Root, true, true, true), trace, null)) { }
        Assert.Equal(24, trace.Calls.Count);
        var indices = Enumerable.Range(0, trace.Calls.Count).Where(i => !partial || trace.Calls[i].Operation == "WriteFile" && trace.Calls[i].Moment == "before").ToArray();
        Assert.NotEmpty(indices);
        foreach (var index in indices)
        {
            using var fixture = new ApplicationAuthorityProvisioningTests(); using var parent = fixture.Parent();
            var storage = new FaultingTransactionStorage(); storage.Arm(index, partial);
            Assert.Throws<IOException>(() => ApplicationAuthorityLifetime.ProvisionCore(parent, parent.JournalStatus.KnownPosition, Inspection(parent),
                fixture.Root, fixture.Configuration, fixture.Roots, new(fixture.Root, true, true, true), storage, null));
            Assert.True(storage.Fired); Assert.Equal(0, parent.ActiveOperations);
            Assert.DoesNotContain(storage.Calls, call => call.Operation.StartsWith("Delete", StringComparison.Ordinal));
            if (!Directory.Exists(fixture.Root)) continue;
            var before = Directory.GetFiles(fixture.Root).ToDictionary(path => path, File.ReadAllBytes);
            Assert.Throws<IOException>(() => fixture.Provision(parent));
            Assert.Equal(before.Keys.Order(), Directory.GetFiles(fixture.Root).Order());
            foreach (var pair in before) Assert.Equal(pair.Value, File.ReadAllBytes(pair.Key));
            if (partial) Assert.InRange(new FileInfo(Path.Combine(fixture.Root, "authority.meta")).Length, 1, 111);
        }
    }

    /// <summary>Unknown entries introduced before claim are retained without completing roles.</summary>
    [Fact]
    public void Provision_OccupiedAfterCreation_RetainsUnknownEntry()
    {
        using var parent = Parent();
        Assert.Throws<IOException>(() => Provision(parent, stage =>
        {
            if (stage == ApplicationProvisionStage.RootCreated) File.WriteAllText(Path.Combine(Root, "unknown"), "retain");
        }));
        Assert.Equal("retain", File.ReadAllText(Path.Combine(Root, "unknown"))); Assert.Single(Directory.GetFiles(Root));
        Assert.Equal(0, parent.ActiveOperations);
    }

    /// <summary>Parent mode exclusion prevents a second provisioning invocation from dispatching.</summary>
    [Fact]
    public void Provision_CompetingParentMode_RejectsBeforeCreation()
    {
        using var parent = Parent();
        using var authority = Provision(parent, stage =>
        {
            if (stage == ApplicationProvisionStage.PreflightValidated)
                Assert.Throws<InvalidOperationException>(() => Provision(parent));
        });
        Assert.Empty(authority.Inspect().Frames);
    }

    /// <summary>Closed live initializers cannot reacquire any reservation.</summary>
    [Fact]
    public void ReserveInitializer_DisposedOwner_Rejects()
    {
        using var parent = Parent(); var authority = Provision(parent); authority.Dispose();
        Assert.Throws<ObjectDisposedException>(() => authority.ReserveInitializer()); Assert.Equal(0, parent.ActiveOperations);
    }

    /// <summary>Unqualified durability never silently falls back to the process-crash provisioner.</summary>
    [Fact]
    public void Provision_StrongStoragePolicy_RejectsBeforeCreation()
    {
        using var parent = Parent();
        Assert.Throws<NotSupportedException>(() => ApplicationAuthorityLifetime.ProvisionCore(parent, parent.JournalStatus.KnownPosition, Inspection(parent),
            Root, Configuration, Roots, new(Root, true, true, true), new FaultingTransactionStorage(DurabilityMode.FileAndDirectoryFlush), null));
        Assert.False(Directory.Exists(Root)); Assert.Equal(0, parent.ActiveOperations);
    }

    /// <summary>Releases only this test's private metadata-only workspace.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
