// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Runs a subprocess probe for transaction process-kill testing.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      | Charles Korthout | 0.2   | 26-10-2026     | Probe checkpoint publication and readers after owner disposal
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.4   | 27-10-2026     | Add verified full-history backup and restore commands
//                      | Charles Korthout | 0.5   | 27-10-2026     | Probe epoch publication, independent admission and frozen readers
//                      | Charles Korthout | 0.6   | 27-10-2026     | Probe readable epoch publication and actual snapshot lifetimes
//                      | Charles Korthout | 0.7   | 27-10-2026     | Add frozen immutable epoch profile rejection probe
//                      | Charles Korthout | 0.8   | 27-10-2026     | Probe empty-chain owner, actual snapshot locks and initialization kills
//                      | Charles Korthout | 0.9   | 27-10-2026     | Probe scalar epoch commits and complete-history reopen
//                      | Charles Korthout | 1.0   | 27-10-2026     | Add native stronger-policy multi-generation redo process probe
//                      | Charles Korthout | 1.1   | 27-10-2026     | Probe admitted epoch backup capture and publication kills
//                      | Charles Korthout | 1.2   | 27-10-2026     | Probe fresh-identity epoch restore and provenance-bundle publication kills
//                      | Charles Korthout | 1.3   | 27-10-2026     | Probe legacy-to-epoch migration bundle publication and acknowledgment loss
//                      | Charles Korthout | 1.4   | 27-10-2026     | Add native-policy migration copy/redo interruption probes
//                      | Charles Korthout | 1.5   | 27-10-2026     | Probe cutover freeze ownership and process-exit invalidation
//                      | Charles Korthout | 1.6   | 28-10-2026     | Hold migrated snapshot or transaction across owner disposal
//                      | Charles Korthout | 1.7   | 28-10-2026     | Preannounce planned attempts before process interruption
//                      | Charles Korthout | 1.8   | 28-10-2026     | Probe existing host-root contention, exit release and operation drain
//                      | Charles Korthout | 1.9   | 28-10-2026     | Probe no-overwrite provisioning interruption and process contenders
//                      | Charles Korthout | 2.0   | 28-10-2026     | Probe owned journal append kills and partial-frame retention
//                      | Charles Korthout | 2.1   | 28-10-2026     | Probe live orchestration restart gaps without ticket replay
//                      | Charles Korthout | 2.2   | 29-10-2026     | Kill stopped reconciliation and explicit retry at real persistence boundaries
//                      | Charles Korthout | 2.3   | 29-10-2026     | Hold paired authority/parent inspection leases through process exit and drain
//                      | Charles Korthout | 2.4   | 29-10-2026     | Probe authority provisioning kills, acknowledgment loss and independent creators
//                      | Charles Korthout | 2.5   | 29-10-2026     | Probe original source handle retention after owner and freeze closing
//                      | Charles Korthout | 2.6   | 29-10-2026     | Hold combined retained enrollment execution across all owner closures
//                      | Charles Korthout | 2.7   | 30-10-2026     | Publish stopped first enrollment and hold acknowledged ownership for independent inspection
//                      | Charles Korthout | 2.8   | 30-10-2026     | Probe first-enrollment I/O interruption, lost acknowledgment and independent contenders
//                      | Charles Korthout | 2.9   | 30-10-2026     | Probe stopped restart observation holders, interruption and independent contenders         |
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text.Json;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Bosak.XmlDb.Xdm;
using Bosak.XPath.Api;

namespace Bosak.XmlDb.IntegrationTests;

internal static partial class CrashProbe
{
    private sealed class ProvisionPartialStorage(Action pause) : ITransactionStorage
    {
        private readonly LocalTransactionStorage _local = new();
        /// <inheritdoc/>
        public DurabilityMode Durability => DurabilityMode.ProcessCrash;
        /// <inheritdoc/>
        public ITransactionFile CreateFile(string path) => new PartialFile(_local.CreateFile(path), Path.GetFileName(path) == "authority.meta" ? pause : null);
        /// <inheritdoc/>
        public void CreateDirectory(string path) => _local.CreateDirectory(path);
        /// <inheritdoc/>
        public void SyncDirectory(string path) => _local.SyncDirectory(path);
        /// <inheritdoc/>
        public void SyncFile(string path) => _local.SyncFile(path);
        /// <inheritdoc/>
        public void MoveFile(string source, string destination, bool overwrite) => throw new NotSupportedException();
        /// <inheritdoc/>
        public void MoveDirectory(string source, string destination) => throw new NotSupportedException();
        /// <inheritdoc/>
        public void DeleteFile(string path) => throw new NotSupportedException();
        /// <inheritdoc/>
        public void DeleteDirectory(string path) => throw new NotSupportedException();
        private sealed class PartialFile(ITransactionFile inner, Action? pause) : ITransactionFile
        {
            /// <inheritdoc/>
            public void Write(ReadOnlySpan<byte> bytes)
            {
                if (pause is null) { inner.Write(bytes); return; }
                inner.Write(bytes[..(bytes.Length / 2)]); pause(); throw new IOException("Partial metadata probe resumed unexpectedly.");
            }
            /// <inheritdoc/>
            public void FlushToDisk() => inner.FlushToDisk();
            /// <inheritdoc/>
            public void Dispose() => inner.Dispose();
        }
    }

    private sealed class AppendInterruptionIo(bool partial) : IHostJournalAppendIo
    {
        /// <inheritdoc/>
        public void Write(FileStream stream, ReadOnlySpan<byte> bytes)
        {
            if (partial) { stream.Write(bytes[..(bytes.Length / 2)]); Kill("EP4:partial"); }
            stream.Write(bytes);
        }
        /// <inheritdoc/>
        public void Flush(FileStream stream) => stream.Flush(true);
    }

    private sealed class EnrollmentInterruptionIo(Action<string> pause, bool partial) : IApplicationAuthorityAppendIo
    {
        /// <inheritdoc/>
        public void Write(FileStream stream, ReadOnlySpan<byte> bytes)
        {
            pause("IoWriteBefore");
            if (partial) { stream.Write(bytes[..17]); stream.Flush(); pause("Partial"); stream.Write(bytes[17..]); }
            else stream.Write(bytes);
            pause("IoWriteAfter");
        }
        /// <inheritdoc/>
        public void Flush(FileStream stream) { pause("IoFlushBefore"); stream.Flush(true); pause("IoFlushAfter"); }
        /// <inheritdoc/>
        public void ReadBack(FileStream stream, Span<byte> bytes) { pause("IoReadBefore"); stream.ReadExactly(bytes); pause("IoReadAfter"); }
    }

    private static int Main(string[] args)
    {
        if (args.Length < 2) return 2;
        var action = args[0];
        var root = args[1];
        if (action is "sr2c-observe" or "sr2c-race") return RunRestartObservation(args);
        Action<CommitStage>? checkpoint = args.Length > 2 ? stage =>
        {
            if (stage.ToString() == args[2]) Kill("FAULT:" + stage);
        }
        : null;
        if (action is "ef4-publish" or "ef4-race")
        {
            if (args.Length != 9) return 2;
            var racing = action == "ef4-race"; var sourceAcquired = false; var point = args[7]; var closeAfterArm = bool.Parse(args[8]);
            if (racing) { Console.WriteLine("READY"); Console.Out.Flush(); if (Console.ReadLine() != "go") return 3; }
            try
            {
                using var source = EmbeddedXmlDatabase.Open(args[3]); sourceAcquired = true; using var read = source.BeginRead();
                using var host = EmbeddedHostLifetime.OpenExisting(root, "embedded-pilot", "orders", [args[2], args[3], args[4]]);
                var configuration = new ApplicationAuthorityConfiguration(Guid.Parse(args[5]), Guid.Parse(args[6]), "embedded-pilot", "orders", "admin", "authority");
                var roots = new Dictionary<string, string> { ["admin"] = root, ["authority"] = args[2], ["source"] = args[3], ["capture"] = args[4] };
                using var authority = ApplicationAuthorityLifetime.Provision(host, host.JournalStatus.KnownPosition, new(host.Context, true, true, true, true, true), args[2], configuration, roots, new(args[2], true, true, true));
                using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(args[4]);
                var evidence = new ApplicationEnrollmentEvidence(host.Context, configuration.AuthorityId, "source", "source-admission", "capture", Guid.NewGuid(), new string('a', 64), true, true, true, true, true, true);
                using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence);
                var metadata = ApplicationAuthorityCodec.DecodeMetadata(ApplicationAuthorityCodec.EncodeMetadata(configuration), configuration);
                var expected = ApplicationAuthorityCodec.EncodeFrame(metadata, 1, new string('0', 64), plan.Description.Entry);
                if (!racing) { Console.WriteLine("PLAN:" + Convert.ToHexString(expected)); Console.Out.Flush(); }
                void Pause(string at)
                {
                    if (racing || point != at) return;
                    Console.WriteLine("AT:" + at); Console.Out.Flush(); if (Console.ReadLine() != "continue") throw new InvalidOperationException("Expected process gate release.");
                }
                var result = authority.AppendFirstEnrollmentCore(plan, evidence, new EnrollmentInterruptionIo(Pause, point == "Partial"), stage =>
                {
                    if (closeAfterArm && stage == ApplicationEnrollmentAppendStage.Armed) { plan.Dispose(); freeze.Dispose(); source.Dispose(); authority.Dispose(); host.Dispose(); }
                    Pause(stage.ToString());
                });
                if (result.Disposition != ApplicationEnrollmentAppendDisposition.AcknowledgedStopped || result.Receipt is null) throw new InvalidOperationException("Unexpected append result: " + result.Error);
                Pause("Returned");
                for (ulong id = 1; id <= (ulong)read.NodeCount; id++) _ = read.ReadValue(id);
                Console.WriteLine((racing ? "WON:" : "ACK:") + Convert.ToHexString(expected)); Console.Out.Flush(); Pause("ACK");
                if (racing && Console.ReadLine() != "release") return 3;
                return 0;
            }
            catch (IOException) when (racing && !sourceAcquired) { Console.WriteLine("LOST"); Console.Out.Flush(); return 0; }
        }
        if (action == "ef3-append")
        {
            if (args.Length != 7) return 2;
            using var source = EmbeddedXmlDatabase.Open(args[3]); using var read = source.BeginRead();
            using var host = EmbeddedHostLifetime.OpenExisting(root, "embedded-pilot", "orders", [args[2], args[3], args[4]]);
            var configuration = new ApplicationAuthorityConfiguration(Guid.Parse(args[5]), Guid.Parse(args[6]), "embedded-pilot", "orders", "admin", "authority");
            var roots = new Dictionary<string, string> { ["admin"] = root, ["authority"] = args[2], ["source"] = args[3], ["capture"] = args[4] };
            using var authority = ApplicationAuthorityLifetime.Provision(host, host.JournalStatus.KnownPosition, new(host.Context, true, true, true, true, true), args[2], configuration, roots, new(args[2], true, true, true));
            using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(args[4]);
            var evidence = new ApplicationEnrollmentEvidence(host.Context, configuration.AuthorityId, "source", "source-admission", "capture", Guid.NewGuid(), new string('a', 64), true, true, true, true, true, true);
            using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence);
            var result = authority.AppendFirstEnrollment(plan, evidence);
            if (result.Disposition != ApplicationEnrollmentAppendDisposition.AcknowledgedStopped || result.Receipt is null || !result.WritersMustRemainStopped) return 4;
            Console.WriteLine("ACK:" + result.Receipt.Frame.Digest); Console.Out.Flush(); if (Console.ReadLine() != "release") return 3;
            plan.Dispose(); freeze.Dispose(); source.Dispose(); authority.Dispose(); host.Dispose();
            source.WhenEnrollmentOwnershipReleased.GetAwaiter().GetResult(); authority.WhenReleased.GetAwaiter().GetResult(); host.WhenReleased.GetAwaiter().GetResult();
            for (ulong id = 1; id <= (ulong)read.NodeCount; id++) _ = read.ReadValue(id);
            Console.WriteLine("RELEASED"); Console.Out.Flush(); if (Console.ReadLine() != "exit") return 3; return 0;
        }
        if (action == "ef2-hold")
        {
            if (args.Length != 7) return 2;
            using var source = EmbeddedXmlDatabase.Open(args[3]); using var read = source.BeginRead();
            using var host = EmbeddedHostLifetime.OpenExisting(root, "embedded-pilot", "orders", [args[2], args[3], args[4]]);
            var configuration = new ApplicationAuthorityConfiguration(Guid.Parse(args[5]), Guid.Parse(args[6]), "embedded-pilot", "orders", "admin", "authority");
            var roots = new Dictionary<string, string> { ["admin"] = root, ["authority"] = args[2], ["source"] = args[3], ["capture"] = args[4] };
            using var authority = ApplicationAuthorityLifetime.Provision(host, host.JournalStatus.KnownPosition, new(host.Context, true, true, true, true, true), args[2], configuration, roots, new(args[2], true, true, true));
            using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(args[4]);
            var evidence = new ApplicationEnrollmentEvidence(host.Context, configuration.AuthorityId, "source", "source-admission", "capture", Guid.NewGuid(), new string('a', 64), true, true, true, true, true, true);
            using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence);
            using var execution = authority.TryArmRetainedFirstEnrollment(plan, evidence) ?? throw new InvalidOperationException("Unexpected busy admission.");
            plan.Dispose(); freeze.Dispose(); source.Dispose(); authority.Dispose(); host.Dispose();
            if (!execution.Inspect().WritersMustRemainStopped) return 4;
            Console.WriteLine("HELD"); Console.Out.Flush(); if (Console.ReadLine() != "release") return 3;
            execution.Dispose(); source.WhenEnrollmentOwnershipReleased.GetAwaiter().GetResult(); authority.WhenReleased.GetAwaiter().GetResult(); host.WhenReleased.GetAwaiter().GetResult();
            for (ulong id = 1; id <= (ulong)read.NodeCount; id++) _ = read.ReadValue(id);
            Console.WriteLine("RELEASED"); Console.Out.Flush(); if (Console.ReadLine() != "exit") return 3; return 0;
        }
        if (action == "ef1-retain")
        {
            if (args.Length != 4) return 2;
            using var source = EmbeddedXmlDatabase.Open(root); using var pinned = source.BeginRead();
            using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(args[2]);
            using var child = freeze.RetainForEnrollment(capture); var initial = child.InspectState();
            if (args[3] == "armed") child.Arm(); else if (args[3] != "pending") return 2;
            source.Dispose(); freeze.Dispose();
            if (source.EnrollmentOwnershipStatus.ReleaseState != EnrollmentSourceReleaseState.RetainedClosing) return 4;
            if (args[3] == "armed" && child.InspectState().AdmissionIdentity != initial.AdmissionIdentity) return 4;
            Console.WriteLine("HELD"); Console.Out.Flush(); if (Console.ReadLine() != "release") return 3;
            child.Dispose(); source.WhenEnrollmentOwnershipReleased.GetAwaiter().GetResult();
            if (source.EnrollmentOwnershipStatus.ReleaseState != EnrollmentSourceReleaseState.Released) return 4;
            for (ulong id = 1; id <= (ulong)pinned.NodeCount; id++) _ = pinned.ReadValue(id);
            Console.WriteLine("RELEASED"); Console.Out.Flush(); if (Console.ReadLine() != "exit") return 3;
            return 0;
        }
        if (action == "ep7c-provision")
        {
            if (args.Length != 7) return 2;
            using var host = EmbeddedHostLifetime.OpenExisting(root, "embedded-pilot", "orders", [args[2], args[3]]);
            var config = new ApplicationAuthorityConfiguration(Guid.Parse(args[4]), Guid.Parse(args[5]), "embedded-pilot", "orders", "admin-root", "application-root");
            var map = new Dictionary<string, string> { ["admin-root"] = root, ["application-root"] = args[2], ["source-root"] = args[3] };
            void Pause(string point) { Console.WriteLine(point); Console.Out.Flush(); if (Console.ReadLine() != "continue") throw new IOException("Probe input ended."); }
            ITransactionStorage storage = args[6] == "PartialMetadata" ? new ProvisionPartialStorage(() => Pause("AT:PartialMetadata")) : new LocalTransactionStorage();
            try
            {
                using var authority = ApplicationAuthorityLifetime.ProvisionCore(host, host.JournalStatus.KnownPosition,
                    new(host.Context, true, true, true, true, true), args[2], config, map, new(args[2], true, true, true), storage,
                    stage =>
                    {
                        if (args[6] == "RACE" && stage == ApplicationProvisionStage.PreflightValidated) Pause("READY");
                        else if (args[6] == stage.ToString()) Pause("AT:" + stage);
                    });
                if (args[6] == "RACE") { Pause("ACQUIRED"); return 0; }
                if (args[6] == "ACK") Pause("AT:ACK");
                using var reservation = authority.ReserveInitializer();
                if (args[6] == "DRAIN") { authority.Dispose(); host.Dispose(); }
                Pause("AT:" + args[6]); return 0;
            }
            catch (IOException) when (args[6] == "RACE") { Console.WriteLine("REJECTED"); Console.Out.Flush(); return 0; }
        }
        if (action == "ep7c-hold")
        {
            if (args.Length != 7) return 2;
            using var host = EmbeddedHostLifetime.OpenExisting(root, "embedded-pilot", "orders", [args[2], args[3]]);
            var config = new ApplicationAuthorityConfiguration(Guid.Parse(args[4]), Guid.Parse(args[5]), "embedded-pilot", "orders", "admin-root", "application-root");
            var map = new Dictionary<string, string> { ["admin-root"] = root, ["application-root"] = args[2], ["source-root"] = args[3] };
            using var authority = ApplicationAuthorityLifetime.OpenExisting(host, host.JournalStatus.KnownPosition,
                new(host.Context, true, true, true, true, true), args[2], config, map);
            Console.WriteLine("ACQUIRED"); Console.Out.Flush();
            using var entered = new ManualResetEventSlim(); using var release = new ManualResetEventSlim(); Task? read = null;
            if (args[6] is "drain" or "kill-drain")
            {
                read = Task.Run(() => authority.InspectCore(() => { entered.Set(); if (!release.Wait(TimeSpan.FromSeconds(45))) throw new TimeoutException(); }));
                if (!entered.Wait(TimeSpan.FromSeconds(30))) return 4;
                authority.Dispose(); host.Dispose(); Console.WriteLine("DRAINING"); Console.Out.Flush();
            }
            if (Console.ReadLine() != "continue") return 3;
            release.Set(); read?.GetAwaiter().GetResult(); authority.Dispose(); host.Dispose();
            authority.WhenReleased.GetAwaiter().GetResult(); host.WhenReleased.GetAwaiter().GetResult();
            Console.WriteLine("RELEASED"); Console.Out.Flush(); if (Console.ReadLine() != "exit") return 3;
            return 0;
        }
        if (action == "ep6-restart")
        {
            if (args.Length != 6) return 2;
            var area = Path.GetDirectoryName(args[2])!; var mode = args[4]; var point = args[5];
            using var host = EmbeddedHostLifetime.OpenExisting(root, "pilot", "scope", [args[2], args[3], Path.Combine(area, "source"), Path.Combine(area, "legacy"), Path.Combine(area, "initial")]);
            var saved = host.History.Frames[^1].Snapshot; var index = 0;
            Console.WriteLine("READY"); Console.Out.Flush(); if (Console.ReadLine() != "continue") return 3;
            var result = EmbeddedHostRestartReconciler.Reconcile(host, host.JournalStatus.KnownPosition, saved,
                new(host.Context, true, true, true, true, true), new(host.Context, saved, true, true, true), stage =>
                {
                    if (stage == HostAppendStage.Validated) index++;
                    if (point == "transfer:ACK" && index == 2 && stage == HostAppendStage.Validated) Kill("EP6:" + point);
                    if (point == (index == 1 ? "transfer:" : "outcome:") + stage) Kill("EP6:" + point);
                });
            if (point == "outcome:ACK") Kill("EP6:" + point);
            if (mode != "retry") return 4;
            var admission = new EmbeddedHostAdmissionEvidence(host.Context, true, true, true, true, true, true);
            host.OpenAdministrativeAdmissions(admission); host.EnableJournalAppend(host.JournalStatus.KnownPosition, admission);
            var flow = EmbeddedHostOrchestrator.CreateCore(host, ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash)),
                checkpoint: stage => { if (point == "execute:" + stage) Kill("EP6:" + point); },
                appendCheckpoint: stage => { if (point == "retry:" + stage) Kill("EP6:" + point); });
            var ticket = flow.PrepareRetry(new(host.Context, result.Snapshot, true, true, true, true, true, true, true)); var descriptor = ticket.Describe();
            Console.WriteLine(JsonSerializer.Serialize(new { descriptor.AttemptId, descriptor.InventorySha256 })); Console.Out.Flush(); if (Console.ReadLine() != "record") return 3;
            flow.Record(ticket); if (point == "retry:ACK") Kill("EP6:" + point);
            var execution = flow.Execute(ticket); if (point == "execute:ACK" && execution.Disposition == EmbeddedHostExecutionDisposition.Succeeded) Kill("EP6:" + point);
            return 4;
        }
        if (action == "ep5-execute")
        {
            if (args.Length != 6) return 2;
            var area = Path.GetDirectoryName(args[2])!;
            using var host = EmbeddedHostLifetime.Provision(root, "pilot", "scope", [args[2], args[3], Path.Combine(area, "source"), Path.Combine(area, "legacy"), Path.Combine(area, "initial")],
                new(root, "pilot", "scope", true, true, true));
            var evidence = new EmbeddedHostAdmissionEvidence(host.Context, true, true, true, true, true, true);
            host.OpenAdministrativeAdmissions(evidence); host.EnableJournalAppend(host.JournalStatus.KnownPosition, evidence);
            var flow = EmbeddedHostOrchestrator.CreateCore(host, ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash)),
                checkpoint: stage => { if (stage.ToString() == args[5]) Kill("EP5:" + stage); });
            var ticket = flow.Prepare(Guid.NewGuid(), Enum.Parse<EpochPublicationKind>(args[4]), args[2], args[3]); var intent = ticket.Describe();
            Console.WriteLine(JsonSerializer.Serialize(new { intent.AttemptId, intent.InventorySha256 })); Console.Out.Flush();
            if (Console.ReadLine() != "dispatch") return 3;
            flow.Record(ticket); var result = flow.Execute(ticket);
            if (args[5] == "ACK") Kill("EP5:ACK");
            Console.WriteLine(result.Disposition); return result.Disposition == EmbeddedHostExecutionDisposition.Succeeded ? 0 : 4;
        }
        if (action == "ep4-append")
        {
            if (args.Length != 6) return 2;
            using var host = EmbeddedHostLifetime.Provision(root, args[2], args[3], [args[4]], new(root, args[2], args[3], true, true, true));
            var evidence = new EmbeddedHostAdmissionEvidence(host.Context, true, true, true, true, true, true);
            host.OpenAdministrativeAdmissions(evidence); host.EnableJournalAppend(host.JournalStatus.KnownPosition, evidence);
            var snapshot = new HostLedgerSnapshot(new(Guid.NewGuid(), args[2], args[3],
                new(Guid.NewGuid(), EpochPublicationKind.LegacyMigration, Path.Combine(args[4], "artifact"), Path.Combine(args[4], "candidate"),
                    new string('a', 64), Guid.NewGuid(), 7, 0, null, EpochProfile.ScalarWal, DurabilityMode.ProcessCrash),
                1, host.Context.SessionId, 1), HostLedgerStage.Recorded);
            _ = host.AppendJournalCore(host.JournalStatus.KnownPosition, HostJournalEvent.RecordIntent, snapshot,
                new AppendInterruptionIo(args[5] == "partial"), stage => { if (stage.ToString() == args[5]) Kill("EP4:" + stage); });
            if (args[5] == "ACK") Kill("EP4:ACK"); return 0;
        }
        if (action == "ep3-provision")
        {
            if (args.Length != 6) return 2;
            var mode = args[5];
            try
            {
                using var host = EmbeddedHostLifetime.Provision(root, args[2], args[3], [args[4]], new(root, args[2], args[3], true, true, true), checkpoint: stage =>
                {
                    if (mode == "race" && stage == HostProvisionStage.PreflightValidated)
                    { Console.WriteLine("READY"); Console.Out.Flush(); _ = Console.ReadLine(); }
                    if (mode == "hold" && stage == HostProvisionStage.BeforeReturn)
                    { Console.WriteLine("BLOCKED"); Console.Out.Flush(); _ = Console.ReadLine(); }
                    if (stage.ToString() == mode) Kill("EP3-PROVISION:" + stage);
                });
                if (mode == "ACK") Kill("EP3-PROVISION:ACK");
                Console.WriteLine("WIN:" + host.Context.JournalId); Console.Out.Flush(); _ = Console.ReadLine(); return 0;
            }
            catch (Exception error) when (mode == "race" && error is IOException or InvalidDataException)
            { Console.WriteLine("CONFLICT"); Console.Out.Flush(); return 3; }
        }
        if (action == "ep3-hold")
        {
            if (args.Length != 6) return 2;
            using var host = EmbeddedHostLifetime.OpenExisting(root, args[2], args[3], [args[4]]);
            Console.WriteLine("ACQUIRED"); Console.Out.Flush();
            if (args[5] is "drain" or "kill-drain")
            {
                host.OpenAdministrativeAdmissions(new(host.Context, true, true, true, true, true, true));
                using var operation = host.BeginOperation(); host.Dispose();
                Console.WriteLine("DRAINING"); Console.Out.Flush(); _ = Console.ReadLine();
                operation.Dispose(); host.WhenReleased.GetAwaiter().GetResult();
                Console.WriteLine("RELEASED"); Console.Out.Flush();
            }
            _ = Console.ReadLine(); return 0;
        }
        if (action == "rc3-execute")
        {
            if (args.Length != 5) return 2;
            var admin = ScalarEpochAdministration.CreateCore(new(DurabilityMode.ProcessCrash), new LocalTransactionStorage(), stage =>
            {
                if (stage.ToString() == args[4]) Kill("RC3:" + stage);
            });
            var plan = admin.PrepareAttempt(Enum.Parse<EpochPublicationKind>(args[3]), root, args[2]);
            var intent = plan.Describe();
            Console.WriteLine(JsonSerializer.Serialize(new { intent.AttemptId, intent.InventorySha256 })); Console.Out.Flush();
            if (Console.ReadLine() != "dispatch") return 3;
            var receipt = admin.ExecuteAttempt(plan);
            if (args[4] == "ACK") Kill("RC3:ACK");
            Console.WriteLine(JsonSerializer.Serialize(receipt)); return 0;
        }
        if (action == "ca2-hold")
        {
            using var owner = EpochScalarCoordinator.Open(root);
            using var snapshot = args[2] == "snapshot" ? owner.BeginRead(0) : null;
            using var transaction = args[2] == "transaction" ? owner.BeginTransaction() : null;
            owner.Dispose();
            Console.WriteLine("PINNED"); Console.Out.Flush();
            _ = Console.ReadLine();
            var value = snapshot is not null ? snapshot.ReadValue(ulong.Parse(args[3], System.Globalization.CultureInfo.InvariantCulture)) :
                transaction!.ReadValue(ulong.Parse(args[3], System.Globalization.CultureInfo.InvariantCulture));
            Console.WriteLine(value); return 0;
        }
        if (action == "mg5-hold")
        {
            if (args.Length < 4) return 2;
            using var source = EmbeddedXmlDatabase.Open(root);
            using var freeze = MigrationSourceFreeze.Acquire(source, true);
            var capture = freeze.Capture(args[2]); var result = EpochLegacyMigration.Convert(args[2], args[3]);
            using var candidate = EpochScalarCoordinator.Open(result.StorePath);
            using var session = MigrationCutoverSession.Attach(freeze, capture, candidate, result, true);
            session.Evaluate(session.Prepare(), CutoverAction.ProposeCandidate, CutoverRoute.Legacy, new(true, true));
            session.Evaluate(session.Prepare(), CutoverAction.ObserveCandidateOutcome, CutoverRoute.Unknown, new(true, true));
            Console.WriteLine(JsonSerializer.Serialize(new { State = session.Decision.ToString(), result.StorePath })); Console.Out.Flush();
            _ = Console.ReadLine(); return 0;
        }
        if (action == "mg4-convert")
        {
            if (args.Length < 5) return 2;
            var stageName = args[3]; var policy = args[4] == "native" ? DurabilityMode.FileAndDirectoryFlush : DurabilityMode.ProcessCrash;
            var storage = new MigrationInterruptionStorage(policy, stageName, () => Kill("MG4-FAULT:" + stageName));
            var result = EpochLegacyMigration.Convert(root, args[2], storage, stage =>
            {
                if (stage == EpochMigrationStage.SourceVerified) storage.SourceVerified = true;
                if (stage.ToString() == stageName) Kill("MG4-FAULT:" + stageName);
            });
            if (stageName == "ACK") Kill("MG4-ACK");
            Console.WriteLine(JsonSerializer.Serialize(result)); return 0;
        }
        if (action == "mg3-convert")
        {
            if (args.Length < 3) return 2;
            var result = EpochLegacyMigration.Convert(root, args[2], checkpoint: stage => { if (args.Length > 3 && stage.ToString() == args[3]) Kill("MG3-FAULT:" + stage); });
            if (args.Length > 3 && args[3] == "ACK") Kill("MG3-ACK");
            Console.WriteLine(JsonSerializer.Serialize(result)); return 0;
        }
        if (action == "et9c-restore")
        {
            if (args.Length < 3) return 2;
            var result = EpochBackupRestore.Restore(root, args[2], checkpoint: stage => { if (args.Length > 3 && stage.ToString() == args[3]) Kill("ET9C-FAULT:" + stage); });
            if (args.Length > 3 && args[3] == "ACK") Kill("ET9C-ACK");
            Console.WriteLine(JsonSerializer.Serialize(result)); return 0;
        }
        if (action == "et9b-capture")
        {
            if (args.Length < 3) return 2;
            using var owner = EpochScalarCoordinator.Open(root);
            var result = owner.CreateBackup(args[2], stage => { if (args.Length > 3 && stage.ToString() == args[3]) Kill("ET9B-FAULT:" + stage); });
            if (args.Length > 3 && args[3] == "ACK") Kill("ET9B-ACK");
            Console.WriteLine(JsonSerializer.Serialize(result)); return 0;
        }
        if (action is "et5-write" or "et5-write-ack" or "et5-read" or "et7-read-strong")
        {
            using var owner = EpochScalarCoordinator.Open(root, action == "et7-read-strong" ? new LocalTransactionStorage(DurabilityMode.FileAndDirectoryFlush) : null, checkpoint: stage =>
            {
                if (args.Length > 2 && stage.ToString() == args[2]) Kill("ET5-FAULT:" + stage);
            });
            if (action is not ("et5-read" or "et7-read-strong"))
            {
                using var metadata = owner.BeginRead(0);
                var target = Enumerable.Range(1, metadata.NodeCount).Select(id => metadata.GetNode((ulong)id))
                    .Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();
                using var transaction = owner.BeginTransaction(); transaction.ReplaceNodeValue(target, "ET5-new"); transaction.Commit();
                if (action == "et5-write-ack") Kill("ET5-ACK");
            }
            using var read = owner.BeginRead(0);
            var value = XPath31Expression.Compile("string(/SalesOrder/SalesOrderHeader/DocumentID)").Evaluate(new PersistentXdmNode(read)).StringValue;
            Console.WriteLine(JsonSerializer.Serialize(new { Value = value, read.CommitSequence })); return 0;
        }
        if (action is "et4-open" or "et4-open-ack" or "et4-hold" or "et4-try-open")
        {
            try
            {
                using var owner = EpochEmptyCoordinator.Open(root, checkpoint: stage =>
                {
                    if (args.Length > 2 && stage.ToString() == args[2]) Kill("ET4-FAULT:" + stage);
                });
                if (action == "et4-open-ack") Kill("ET4-ACK");
                if (action == "et4-hold") { Console.WriteLine("OWNED"); Console.Out.Flush(); _ = Console.ReadLine(); }
                using var read = owner.BeginRead(0);
                var value = XPath31Expression.Compile("string(/SalesOrder/SalesOrderHeader/DocumentID)").Evaluate(new PersistentXdmNode(read)).StringValue;
                Console.WriteLine(JsonSerializer.Serialize(new { Value = value, read.CommitSequence }));
                return 0;
            }
            catch (IOException) when (action == "et4-try-open") { Console.WriteLine("BLOCKED"); return 3; }
        }
        if (action == "et4-pin-transaction")
        {
            EpochTransactionContext transaction; ulong target;
            using (var owner = EpochEmptyCoordinator.Open(root))
            {
                using var metadata = owner.BeginRead(0);
                target = Enumerable.Range(1, metadata.NodeCount).Select(id => metadata.GetNode((ulong)id))
                    .Last(node => node.Kind == StorageNodeKind.Element && node.LocalName == "ItemID").Children.Single();
                transaction = owner.BeginTransaction();
            }
            using (transaction)
            {
                Console.WriteLine("PINNED"); Console.Out.Flush(); _ = Console.ReadLine();
                Console.WriteLine(JsonSerializer.Serialize(new { Value = transaction.ReadValue(target), transaction.Metrics }));
            }
            return 0;
        }
        if (action == "et4-pin")
        {
            ImmutableXmlSnapshot snapshot;
            using (var owner = EpochEmptyCoordinator.Open(root)) snapshot = owner.BeginRead(0);
            using (snapshot)
            {
                Console.WriteLine("PINNED"); Console.Out.Flush(); _ = Console.ReadLine();
                var value = XPath31Expression.Compile("string(/SalesOrder/SalesOrderLine[last()]/Item/ItemID)")
                    .Evaluate(new PersistentXdmNode(snapshot)).StringValue;
                Console.WriteLine(JsonSerializer.Serialize(new { Value = value, snapshot.Metrics }));
            }
            return 0;
        }
        if (action is "et4-try-exclusive" or "et4-try-base-exclusive")
        {
            try
            {
                if (action == "et4-try-exclusive")
                {
                    using var admission = EpochAdmission.Acquire(root, EpochAdmission.ReadIdentity(root, EpochProfile.ScalarWal), exclusive: true, profile: EpochProfile.ScalarWal);
                }
                else { using var generation = new FileStream(EpochBaseReader.PathFor(root), FileMode.Open, FileAccess.ReadWrite, FileShare.None); }
                Console.WriteLine("AVAILABLE"); return 0;
            }
            catch (IOException) { Console.WriteLine("BLOCKED"); return 3; }
        }
        if (action == "legacy-immutable-epoch") return LegacyReaderProbe.RunImmutableEpoch(root);
        if (action == "legacy-format") return LegacyReaderProbe.Run(root, args[2]);
        if (action is "epoch-data-create" or "epoch-data-ack")
        {
            EpochReadOnlyRoot.CreateFixture(root + "-source", root, 1, new LocalTransactionStorage(), stage =>
            {
                if (args.Length > 2 && stage.ToString() == args[2]) Kill("EPOCH-DATA-FAULT:" + stage);
            });
            if (action == "epoch-data-ack") Kill("EPOCH-DATA-ACK");
            return 0;
        }
        if (action == "epoch-data-pin")
        {
            ImmutableXmlSnapshot snapshot;
            using (var owner = ReadOnlyEpochDatabase.Open(root)) snapshot = owner.BeginRead(cacheBytes: 0);
            using (snapshot)
            {
                Console.WriteLine("PINNED"); Console.Out.Flush();
                _ = Console.ReadLine();
                var value = XPath31Expression.Compile("string(/SalesOrder/SalesOrderLine[last()]/Item/ItemID)")
                    .Evaluate(new PersistentXdmNode(snapshot)).StringValue;
                Console.WriteLine(JsonSerializer.Serialize(new { Value = value, snapshot.Metrics }));
            }
            return 0;
        }
        if (action is "epoch-create" or "epoch-create-ack")
        {
            EpochAdmission.CreateFixtureRoot(root, 1, new LocalTransactionStorage(), stage =>
            {
                if (args.Length > 2 && stage.ToString() == args[2]) Kill("EPOCH-FAULT:" + stage);
            });
            if (action == "epoch-create-ack") Kill("EPOCH-ACK");
            return 0;
        }
        if (action.StartsWith("epoch-hold-", StringComparison.Ordinal))
        {
            var identity = EpochAdmission.ReadIdentity(root);
            using var owner = EpochAdmission.Acquire(root, identity, exclusive: action == "epoch-hold-exclusive");
            using var child = owner.IsExclusive ? null : owner.ForkShared();
            if (child is not null) owner.Dispose();
            Console.WriteLine("ADMITTED"); Console.Out.Flush();
            _ = Console.ReadLine();
            return 0;
        }
        if (action is "epoch-try-shared" or "epoch-try-exclusive")
        {
            try
            {
                using var admission = EpochAdmission.Acquire(root, EpochAdmission.ReadIdentity(root), exclusive: action == "epoch-try-exclusive");
                Console.WriteLine("AVAILABLE"); return 0;
            }
            catch (IOException) { Console.WriteLine("BLOCKED"); return 3; }
        }
        if (action is "backup" or "ack-backup" or "restore" or "ack-restore")
        {
            BackupResult result;
            if (action is "restore" or "ack-restore")
                result = EmbeddedXmlDatabase.RestoreBackupCore(root + "-backup", root + "-restored", new LocalTransactionStorage(), checkpoint);
            else
            {
                using var owner = EmbeddedXmlDatabase.OpenCore(root, 1, checkpoint);
                result = owner.CreateBackup(root + "-backup");
            }
            if (action.StartsWith("ack-", StringComparison.Ordinal)) Kill("BACKUP-ACK:" + result.CommitSequence);
            return 0;
        }
        if (action == "pin-reader")
        {
            ImmutableXmlSnapshot pinned;
            using (var owner = EmbeddedXmlDatabase.Open(root)) pinned = owner.BeginRead(cacheBytes: 0);
            using (pinned)
            {
                Console.WriteLine("PINNED:" + pinned.CommitSequence);
                Console.Out.Flush();
                _ = Console.ReadLine();
                var value = XPath31Expression.Compile("string(/SalesOrder/SalesOrderHeader/DocumentID)")
                    .Evaluate(new PersistentXdmNode(pinned)).StringValue;
                Console.WriteLine(JsonSerializer.Serialize(new { Value = value, pinned.CommitSequence }));
            }
            return 0;
        }
        if (action == "probe-reader")
        {
            try
            {
                using var exclusive = GenerationLease.OpenExclusive(Path.Combine(root, ".transactions"), 1,
                    ulong.Parse(args[2], System.Globalization.CultureInfo.InvariantCulture));
                Console.WriteLine("AVAILABLE");
                return 0;
            }
            catch (IOException) { Console.WriteLine("BLOCKED"); return 3; }
        }
        if (action == "recover")
        {
            using var recovered = EmbeddedXmlDatabase.OpenCore(root, 1, checkpoint);
            Console.WriteLine("RECOVERED:" + recovered.CommitSequence);
            return 0;
        }
        if (action == "hold")
        {
            using var held = EmbeddedXmlDatabase.Open(root);
            Console.WriteLine("LEASED");
            Console.Out.Flush();
            Thread.Sleep(Timeout.Infinite);
            return 0;
        }
        using var database = EmbeddedXmlDatabase.OpenCore(root, 1, action is "write" or "checkpoint" ? checkpoint : null,
            recovery: action == "inspect-fast" ? RecoveryMode.PreferCheckpoint : RecoveryMode.FullJournal);
        if (action is "checkpoint" or "ack-checkpoint")
        {
            var sequence = database.CreateCheckpoint();
            if (action == "ack-checkpoint") Kill("CHECKPOINT-ACK:" + sequence);
            return 0;
        }
        if (action is "write" or "ack-write")
        {
            using var snapshot = database.BeginRead();
            var element = Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id))
                .Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID");
            using var transaction = database.BeginWrite();
            transaction.ReplaceNodeValue(element.Children.Single(), "SO-2");
            var sequence = transaction.Commit();
            if (action == "ack-write") Kill("ACK:" + sequence);
            return 0;
        }
        if (action is not ("inspect" or "inspect-fast")) return 2;
        using var current = database.BeginRead();
        var document = new PersistentXdmNode(current);
        var header = XPath31Expression.Compile("string(/SalesOrder/SalesOrderHeader/DocumentID)").Evaluate(document).StringValue;
        var count = XPath31Expression.Compile("count(/SalesOrder/SalesOrderLine)").Evaluate(document).IntegerValue;
        Console.WriteLine(JsonSerializer.Serialize(new { Header = header, Lines = count, current.CommitSequence, current.Metrics, database.LastRecovery }));
        return 0;
    }

    private static void Kill(string marker)
    {
        Console.WriteLine(marker);
        Console.Out.Flush();
        Process.GetCurrentProcess().Kill();
        // No Dispose/finally block is allowed to run in this crash probe.
        Thread.Sleep(Timeout.Infinite);
    }
}
