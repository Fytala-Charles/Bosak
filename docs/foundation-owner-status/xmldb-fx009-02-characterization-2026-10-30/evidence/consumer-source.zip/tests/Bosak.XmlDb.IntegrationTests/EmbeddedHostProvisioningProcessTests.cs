// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Qualifies provisioning process interruption, contender exclusion and handoff.
// SPECIAL NOTES        : Internal ProcessCrash pilot; retained partial roots are not resumable provisioning plans.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Uses actual provisioning processes; no physical-loss or journal-append guarantee.</summary>
public sealed class EmbeddedHostProvisioningProcessTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-provision-process-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "host");
    private string Data => Path.Combine(_area, "data");
    private void Setup() { Directory.CreateDirectory(Data); File.WriteAllText(Path.Combine(Data, "sentinel"), "retain"); }
    private EmbeddedHostLifetime Open() => EmbeddedHostLifetime.OpenExisting(Root, "pilot", "scope", [Data]);
    private EmbeddedHostLifetime Provision() => EmbeddedHostLifetime.Provision(Root, "pilot", "scope", [Data], new(Root, "pilot", "scope", true, true, true));
    private Process Start(string mode)
    {
        var info = new ProcessStartInfo("dotnet") { UseShellExecute = false, RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true, CreateNoWindow = true };
        foreach (var arg in new[] { typeof(EmbeddedHostProvisioningProcessTests).Assembly.Location, "ep3-provision", Root, "pilot", "scope", Data, mode }) info.ArgumentList.Add(arg);
        return Process.Start(info) ?? throw new InvalidOperationException("No provisioning probe.");
    }
    private static async Task Stop(Process child) { if (!child.HasExited) { child.Kill(true); await child.WaitForExitAsync(); } }
    private static async Task<string?> Line(Process child) => await child.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(30));
    private static async Task Send(Process child) { await child.StandardInput.WriteLineAsync("continue"); await child.StandardInput.FlushAsync(); }

    /// <summary>Every process-kill/return-loss boundary retains the observed absent, partial or valid-stopped root without repair.</summary>
    /// <param name="stage">Actual interruption boundary.</param>
    [Theory]
    [InlineData("PreflightValidated")]
    [InlineData("RootCreated")]
    [InlineData("OwnerCreated")]
    [InlineData("OwnerFlushed")]
    [InlineData("MetadataCreated")]
    [InlineData("MetadataWritten")]
    [InlineData("MetadataFlushed")]
    [InlineData("JournalCreated")]
    [InlineData("JournalFlushed")]
    [InlineData("NamespaceVerified")]
    [InlineData("BeforeReturn")]
    [InlineData("ACK")]
    public async Task Provision_ProcessDies_RetainsUnacknowledgedState(string stage)
    {
        Setup();
        using var child = Start(stage); var output = child.StandardOutput.ReadToEndAsync(); var errors = child.StandardError.ReadToEndAsync();
        try
        {
            await child.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); Assert.NotEqual(0, child.ExitCode);
            Assert.Contains("EP3-PROVISION:" + stage, await output); _ = await errors;
            var before = Snapshot();
            if (stage == "PreflightValidated")
            {
                Assert.False(Directory.Exists(Root)); Assert.NotNull(Record.Exception(() => { using var missing = Open(); }));
            }
            else
            {
                Assert.True(Directory.Exists(Root)); Assert.Throws<IOException>(() => { using var replay = Provision(); });
                if (stage is "JournalCreated" or "JournalFlushed" or "NamespaceVerified" or "BeforeReturn" or "ACK")
                { using var observed = Open(); Assert.False(observed.AdmissionsOpen); Assert.False(observed.WasProvisionedHere); Assert.Empty(observed.History.Frames); Assert.True(observed.WritersMustRemainStopped); }
                else Assert.NotNull(Record.Exception(() => { using var partial = Open(); }));
            }
            AssertSnapshot(before); Assert.Equal("retain", File.ReadAllText(Path.Combine(Data, "sentinel")));
        }
        finally { await Stop(child); _ = await errors; }
    }

    /// <summary>Two processes both passing absent-root preflight yield one exclusive owner and an unchanged winning identity.</summary>
    [Fact]
    public async Task ConcurrentProcesses_OneCreateNewWinner()
    {
        Setup(); using var a = Start("race"); using var b = Start("race"); var ea = a.StandardError.ReadToEndAsync(); var eb = b.StandardError.ReadToEndAsync();
        try
        {
            Assert.Equal("READY", await Line(a)); Assert.Equal("READY", await Line(b)); await Send(a); await Send(b);
            var statuses = await Task.WhenAll(Line(a), Line(b)); Assert.Single(statuses, s => s?.StartsWith("WIN:", StringComparison.Ordinal) == true); Assert.Single(statuses, s => s == "CONFLICT");
            var winner = statuses[0]!.StartsWith("WIN:", StringComparison.Ordinal) ? a : b; var loser = winner == a ? b : a;
            var id = Guid.Parse(statuses.Single(s => s!.StartsWith("WIN:", StringComparison.Ordinal))![4..]);
            await loser.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); Assert.Equal(3, loser.ExitCode);
            Assert.Throws<IOException>(() => { using var contender = Open(); }); Assert.Throws<IOException>(() => { using var overwrite = Provision(); });
            await Send(winner); await winner.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); Assert.Equal(0, winner.ExitCode);
            using (var observed = Open()) { Assert.Equal(id, observed.Context.JournalId); Assert.False(observed.AdmissionsOpen); Assert.False(observed.WasProvisionedHere); }
            var before = Snapshot(); Assert.Throws<IOException>(() => { using var duplicate = Provision(); }); AssertSnapshot(before);
        }
        finally { await Stop(a); await Stop(b); _ = await ea; _ = await eb; }
    }

    /// <summary>Before and after return, the same owner excludes other processes and no failed initializer modifies its files.</summary>
    [Fact]
    public async Task ProvisioningHandoff_HasNoOwnershipGap()
    {
        Setup(); using var child = Start("hold"); var errors = child.StandardError.ReadToEndAsync();
        try
        {
            Assert.Equal("BLOCKED", await Line(child)); Assert.Throws<IOException>(() => { using var contender = Open(); });
            Assert.Throws<IOException>(() => { using var duplicate = Provision(); }); await Send(child);
            var status = await Line(child); Assert.StartsWith("WIN:", status); var id = Guid.Parse(status![4..]);
            Assert.Throws<IOException>(() => { using var contender = Open(); }); await Send(child);
            await child.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); Assert.Equal(0, child.ExitCode);
            using var observed = Open(); Assert.Equal(id, observed.Context.JournalId); Assert.False(observed.AdmissionsOpen); Assert.False(observed.WasProvisionedHere);
        }
        finally { await Stop(child); _ = await errors; }
    }
    private sealed record Tree(string[] Directories, Dictionary<string, byte[]> Files);
    private Tree Snapshot() => new(Directory.GetDirectories(_area, "*", SearchOption.AllDirectories).Order().ToArray(), Directory.GetFiles(_area, "*", SearchOption.AllDirectories).ToDictionary(path => path, File.ReadAllBytes));
    private void AssertSnapshot(Tree before) { var after = Snapshot(); Assert.Equal(before.Directories, after.Directories); Assert.Equal(before.Files.Keys.Order(), after.Files.Keys.Order()); foreach (var pair in before.Files) Assert.Equal(pair.Value, after.Files[pair.Key]); }
    /// <summary>Deletes only this test's GUID-owned tree after child exit and all host handles close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
