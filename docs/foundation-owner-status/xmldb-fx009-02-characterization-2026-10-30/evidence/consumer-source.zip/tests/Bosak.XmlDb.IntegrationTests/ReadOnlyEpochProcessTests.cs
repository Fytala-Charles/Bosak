// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies epoch XPath parity, lazy snapshot lifetime and data publication crashes.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Bosak.XmlDb.Storage;
using Bosak.XmlDb.Xdm;
using Bosak.XPath.Api;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Verifies epoch XPath parity, lazy snapshot lifetime and data publication crashes.</summary>
public sealed class ReadOnlyEpochProcessTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-epoch-data-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "epoch");
    private string Source => Root + "-source";

    /// <summary>The unchanged XDM adapter preserves XPath axes, namespace/value semantics and avoids line reads for header/count queries.</summary>
    [Fact]
    public void Snapshot_XPathParityAndLazyMetrics_PreservesResultsAndDisposal()
    {
        Seed(); EpochReadOnlyRoot.CreateFixture(Source, Root, 1, new LocalTransactionStorage());
        using var original = ImmutableXmlSnapshot.Open(Source);
        var owner = ReadOnlyEpochDatabase.Open(Root); var snapshot = owner.BeginRead(cacheBytes: 0); owner.Dispose();
        var node = new PersistentXdmNode(snapshot); var expected = new PersistentXdmNode(original);
        Assert.Equal(0L, snapshot.Metrics.PhysicalFragmentReads);
        Assert.Equal("SO-1", XPath31Expression.Compile("string(/SalesOrder/SalesOrderHeader/DocumentID)").Evaluate(node).StringValue);
        Assert.Equal(20, XPath31Expression.Compile("count(/SalesOrder/SalesOrderLine)").Evaluate(node).IntegerValue);
        Assert.Equal(0L, snapshot.Metrics.LineFragmentReads);
        foreach (var query in new[]
        {
            "string(/SalesOrder/SalesOrderLine[last()]/Item/ItemID)",
            "string(/SalesOrder/SalesOrderLine[3]/preceding-sibling::SalesOrderLine[1]/Item/ItemID)",
            "string(/SalesOrder/SalesOrderLine[3]/@number)",
            "string(/SalesOrder/SalesOrderLine[3]/ancestor::SalesOrder/SalesOrderHeader/DocumentID)",
            "string(/SalesOrder/namespace::p)",
            "string(/SalesOrder/SalesOrderHeader/comment())",
        })
            Assert.Equal(XPath31Expression.Compile(query).Evaluate(expected).StringValue, XPath31Expression.Compile(query).Evaluate(node).StringValue);
        Assert.True(snapshot.Metrics.LineFragmentReads > 0);
        snapshot.Dispose(); Assert.Throws<ObjectDisposedException>(() => _ = node.StringValue);
    }

    /// <summary>Frozen format-1 public readers reject fully populated epoch roots without adding transaction files.</summary>
    /// <param name="operation">Frozen public Open overload.</param>
    [Theory]
    [InlineData("raw")]
    [InlineData("coordinator")]
    [InlineData("durability")]
    [InlineData("recovery")]
    public async Task FrozenReader_PopulatedEpoch_StillRejectsBeforeMutation(string operation)
    {
        Seed(); EpochReadOnlyRoot.CreateFixture(Source, Root, 1, new LocalTransactionStorage());
        var before = Bytes(Root); var probe = await Run("legacy-format", operation);
        Assert.Equal(23, probe.Code); Assert.Contains("FROZEN-FORMAT1-REJECTED", probe.Output);
        AssertBytes(before, Root); Assert.False(Directory.Exists(Path.Combine(Root, ".transactions")));
    }

    /// <summary>Every publication boundary exposes either no root or complete verified epoch data, including lost acknowledgment.</summary>
    /// <param name="stage">Publication boundary.</param>
    /// <param name="published">Whether the final root should exist.</param>
    [Theory]
    [InlineData("FormatFlushed", false)]
    [InlineData("IdentityFlushed", false)]
    [InlineData("AdmissionFlushed", false)]
    [InlineData("DataCopied", false)]
    [InlineData("SnapshotFlushed", false)]
    [InlineData("SnapshotVerified", false)]
    [InlineData("Published", true)]
    [InlineData("ACK", true)]
    public async Task Producer_ProcessKilled_PublishesOnlyReadableData(string stage, bool published)
    {
        Seed(); var sourceBefore = Bytes(Source);
        var result = await Run(stage == "ACK" ? "epoch-data-ack" : "epoch-data-create", stage);
        Assert.NotEqual(0, result.Code); Assert.Contains(stage == "ACK" ? "EPOCH-DATA-ACK" : "EPOCH-DATA-FAULT:" + stage, result.Output);
        Assert.Equal(published, Directory.Exists(Root));
        if (published)
        {
            for (var attempt = 0; attempt < 2; attempt++)
            {
                using var owner = ReadOnlyEpochDatabase.Open(Root); using var snapshot = owner.BeginRead(cacheBytes: 0);
                Assert.Equal("SO-1", XPath31Expression.Compile("string(/SalesOrder/SalesOrderHeader/DocumentID)").Evaluate(new PersistentXdmNode(snapshot)).StringValue);
            }
        }
        AssertBytes(sourceBefore, Source);
    }

    /// <summary>An actual uncached snapshot survives store disposal, blocks external maintenance, and releases on close or process death.</summary>
    /// <param name="kill">Whether to terminate the reader instead of releasing it.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Snapshot_OwnerDisposed_BlocksMaintenanceUntilReaderEnds(bool kill)
    {
        Seed(); EpochReadOnlyRoot.CreateFixture(Source, Root, 1, new LocalTransactionStorage());
        using var holder = Start("epoch-data-pin");
        try
        {
            Assert.Equal("PINNED", await holder.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(20)));
            Assert.Equal(3, (await Run("epoch-try-exclusive")).Code);
            if (kill) holder.Kill(true);
            else
            {
                await holder.StandardInput.WriteLineAsync(); await holder.StandardInput.FlushAsync();
                var response = await holder.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(20));
                using var json = JsonDocument.Parse(response!); Assert.Equal("20", json.RootElement.GetProperty("Value").GetString());
                Assert.True(json.RootElement.GetProperty("Metrics").GetProperty("LineFragmentReads").GetInt64() > 0);
            }
            await holder.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(20));
            Assert.Equal(0, (await Run("epoch-try-exclusive")).Code);
        }
        finally { if (!holder.HasExited) { holder.Kill(true); await holder.WaitForExitAsync(); } }
    }

    private void Seed()
    {
        Directory.CreateDirectory(_area);
        var xml = "<SalesOrder xmlns:p='urn:epoch'><SalesOrderHeader><!--note--><DocumentID>SO-1</DocumentID></SalesOrderHeader>" +
            string.Concat(Enumerable.Range(1, 20).Select(id => $"<SalesOrderLine number='{id}'><Item><ItemID>{id}</ItemID></Item></SalesOrderLine>")) + "</SalesOrder>";
        using var input = new MemoryStream(Encoding.UTF8.GetBytes(xml)); XmlFragmentImporter.Import(input, Source, linesPerFragment: 4, documentUri: "https://example.test/epoch.xml");
    }
    private static Dictionary<string, byte[]> Bytes(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories).ToDictionary(path => Path.GetRelativePath(root, path), File.ReadAllBytes);
    private static void AssertBytes(Dictionary<string, byte[]> before, string root)
    { var after = Bytes(root); Assert.Equal(before.Keys.Order(), after.Keys.Order()); foreach (var pair in before) Assert.Equal(pair.Value, after[pair.Key]); }
    private Process Start(string action, string? argument = null)
    {
        var start = new ProcessStartInfo("dotnet") { RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false };
        start.ArgumentList.Add(typeof(ReadOnlyEpochProcessTests).Assembly.Location); start.ArgumentList.Add(action); start.ArgumentList.Add(Root);
        if (argument is not null) start.ArgumentList.Add(argument);
        return Process.Start(start) ?? throw new InvalidOperationException("Cannot start read-only epoch probe.");
    }
    private async Task<(int Code, string Output, string Error)> Run(string action, string? argument = null)
    {
        using var process = Start(action, argument); var output = process.StandardOutput.ReadToEndAsync(); var error = process.StandardError.ReadToEndAsync();
        try { await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); }
        catch { if (!process.HasExited) process.Kill(true); throw; }
        return (process.ExitCode, await output, await error);
    }
    /// <inheritdoc />
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
