// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies legacy migration publication and immutable inputs across process termination.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 27-10-2026     | Repeat process/native copy, redo, publication and ACK interruption windows
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Verifies fresh-process conversion, private kill windows, publication and acknowledgment loss.</summary>
public sealed class EpochLegacyMigrationProcessTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-mg3-process-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "legacy");
    private string Backup => Path.Combine(_area, "backup");

    /// <summary>Process exit/kill exposes only an absent destination or a complete usable migration bundle.</summary>
    /// <param name="stage">Conversion boundary.</param>
    /// <param name="native">Whether actual native Linux directory barriers are selected.</param>
    [Theory]
    [InlineData("normal", false)]
    [InlineData("LegacyCompleteCopy", false)]
    [InlineData("LegacyRedoWrite", false)]
    [InlineData("SourceVerified", false)]
    [InlineData("Rebound", false)]
    [InlineData("EpochRedoWrite", false)]
    [InlineData("DestinationVerified", false)]
    [InlineData("RuntimeReady", false)]
    [InlineData("OriginFlushed", false)]
    [InlineData("BundleVerified", false)]
    [InlineData("Published", false)]
    [InlineData("ACK", false)]
    [InlineData("normal", true)]
    [InlineData("LegacyCompleteCopy", true)]
    [InlineData("LegacyRedoWrite", true)]
    [InlineData("SourceVerified", true)]
    [InlineData("Rebound", true)]
    [InlineData("EpochRedoWrite", true)]
    [InlineData("DestinationVerified", true)]
    [InlineData("RuntimeReady", true)]
    [InlineData("OriginFlushed", true)]
    [InlineData("BundleVerified", true)]
    [InlineData("Published", true)]
    [InlineData("ACK", true)]
    public async Task Convert_FreshProcessOrKill_PublishesOnlyVerifiedBundle(string stage, bool native)
    {
        if (native && !OperatingSystem.IsLinux()) return;
        Seed();
        for (var attempt = 0; attempt < 3; attempt++)
        {
            var source = Bytes(Root); var input = Bytes(Backup); var destination = Path.Combine(_area, "migrated-" + attempt);
            var info = new ProcessStartInfo("dotnet") { RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false };
            foreach (var arg in new[] { typeof(EpochLegacyMigrationProcessTests).Assembly.Location, "mg4-convert", Backup, destination, stage, native ? "native" : "process" }) info.ArgumentList.Add(arg);
            using var process = Process.Start(info) ?? throw new InvalidOperationException("Cannot start conversion probe.");
            var stdout = process.StandardOutput.ReadToEndAsync(); var stderr = process.StandardError.ReadToEndAsync();
            try { await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(50)); }
            catch { if (!process.HasExited) process.Kill(true); throw; }
            var output = await stdout; var error = await stderr;
            if (stage == "normal")
            { Assert.True(process.ExitCode == 0, error); using var json = JsonDocument.Parse(output); Assert.Equal(Path.Combine(destination, "store"), json.RootElement.GetProperty("StorePath").GetString()); }
            else { Assert.NotEqual(0, process.ExitCode); Assert.Contains(stage == "ACK" ? "MG4-ACK" : "MG4-FAULT:" + stage, output); }
            AssertBytes(source, Root); AssertBytes(input, Backup);
            if (stage is "normal" or "Published" or "ACK")
            {
                var originBytes = File.ReadAllBytes(Path.Combine(destination, "migration.bin")); var origin = EpochMigrationCodec.Decode(originBytes);
                var store = Path.Combine(destination, "store");
                for (var repeat = 0; repeat < 2; repeat++)
                {
                    using var owner = EpochScalarCoordinator.Open(store, Storage(native)); using var read = owner.BeginRead(0);
                    Assert.Equal(origin.Destination, owner.Identity); Assert.Equal(3UL, read.CommitSequence); Assert.Equal("new-3", read.ReadValue(Target(read)));
                }
                using (var owner = EpochScalarCoordinator.Open(store, Storage(native)))
                { using var read = owner.BeginRead(); using var tx = owner.BeginTransaction(); tx.ReplaceNodeValue(Target(read), "branch"); Assert.Equal(4UL, tx.Commit()); }
                Assert.Equal(originBytes, File.ReadAllBytes(Path.Combine(destination, "migration.bin")));
                var bytes = Bytes(destination); Assert.Throws<IOException>(() => EpochLegacyMigration.Convert(Backup, destination, Storage(native))); AssertBytes(bytes, destination);
            }
            else
            {
                Assert.False(Directory.Exists(destination)); var retry = EpochLegacyMigration.Convert(Backup, destination, Storage(native));
                using var owner = EpochScalarCoordinator.Open(retry.StorePath, Storage(native)); using var read = owner.BeginRead(); Assert.Equal(3UL, read.CommitSequence);
            }
            AssertBytes(source, Root); AssertBytes(input, Backup);
        }
    }

    private static LocalTransactionStorage Storage(bool native) => new(native ? DurabilityMode.FileAndDirectoryFlush : DurabilityMode.ProcessCrash);

    private void Seed()
    {
        Directory.CreateDirectory(_area); using var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"));
        XmlFragmentImporter.Import(input, Root); using var owner = EmbeddedXmlDatabase.Open(Root);
        for (var index = 1; index <= 3; index++)
        { using var read = owner.BeginRead(); using var tx = owner.BeginWrite(); tx.ReplaceNodeValue(Target(read), "new-" + index); tx.Commit(); }
        owner.CreateBackup(Backup);
    }
    private static ulong Target(ImmutableXmlSnapshot read) => Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();
    private static Dictionary<string, byte[]> Bytes(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories).ToDictionary(p => Path.GetRelativePath(root, p), File.ReadAllBytes);
    private static void AssertBytes(Dictionary<string, byte[]> expected, string root) { var actual = Bytes(root); Assert.Equal(expected.Keys.Order(), actual.Keys.Order()); foreach (var pair in expected) Assert.Equal(pair.Value, actual[pair.Key]); }
    /// <summary>Deletes isolated test-owned data after child processes and handles have closed.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
