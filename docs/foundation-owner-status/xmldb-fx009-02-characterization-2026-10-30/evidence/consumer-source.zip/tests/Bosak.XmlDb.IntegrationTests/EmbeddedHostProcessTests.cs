// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Qualifies cooperative host ownership across process exit, aliases and drain.
// SPECIAL NOTES        : Controlled cooperative namespace only; no provisioning, durable writer or global fence.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Exercises actual OS lifetime leases without provisioning or durable append claims.</summary>
public sealed class EmbeddedHostProcessTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ep3-process-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "host");
    private string Data => Path.Combine(_area, "data");
    private void Seed()
    {
        Directory.CreateDirectory(Root); Directory.CreateDirectory(Data);
        File.WriteAllBytes(Path.Combine(Root, "owner.lock"), []);
        File.WriteAllBytes(Path.Combine(Root, "host.meta"), HostJournalCodec.EncodeMetadata(Guid.NewGuid(), "pilot", "scope"));
        File.WriteAllBytes(Path.Combine(Root, "journal.bin"), []);
    }
    private EmbeddedHostLifetime Open(string? root = null, string? data = null) => EmbeddedHostLifetime.OpenExisting(root ?? Root, "pilot", "scope", [data ?? Data]);
    private Process Start(string mode)
    {
        var info = new ProcessStartInfo("dotnet") { RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false, CreateNoWindow = true };
        foreach (var arg in new[] { typeof(EmbeddedHostProcessTests).Assembly.Location, "ep3-hold", Root, "pilot", "scope", Data, mode }) info.ArgumentList.Add(arg);
        return Process.Start(info) ?? throw new InvalidOperationException("No host probe process.");
    }
    private static async Task Line(Process child, string expected) => Assert.Equal(expected, await child.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(30)));
    private static async Task Stop(Process child)
    {
        if (!child.HasExited) { child.Kill(true); await child.WaitForExitAsync(); }
    }

    /// <summary>Another process cannot own a live/draining host, and graceful exit or awaited kill releases the unchanged stable files.</summary>
    /// <param name="mode">Graceful release, crash kill or token drain.</param>
    [Theory]
    [InlineData("exit")]
    [InlineData("kill")]
    [InlineData("drain")]
    [InlineData("kill-drain")]
    public async Task Ownership_ProcessExitOrDrain_ReleasesOnlyAfterCompletion(string mode)
    {
        Seed(); var before = Bytes();
        for (var repeat = 0; repeat < 3; repeat++)
        {
            using var child = Start(mode); var errors = child.StandardError.ReadToEndAsync();
            try
            {
                await Line(child, "ACQUIRED");
                if (mode is "drain" or "kill-drain") await Line(child, "DRAINING");
                Assert.Throws<IOException>(() => { using var contender = Open(); });
                Assert.Throws<IOException>(() => { using var alias = Open(Path.Combine(Root, ".")); });
                if (mode.StartsWith("kill", StringComparison.Ordinal)) child.Kill(true);
                else
                {
                    await child.StandardInput.WriteLineAsync("continue"); await child.StandardInput.FlushAsync();
                    if (mode == "drain")
                    {
                        await Line(child, "RELEASED"); Assert.False(child.HasExited);
                        using (var afterDrain = Open()) Assert.False(afterDrain.AdmissionsOpen);
                        await child.StandardInput.WriteLineAsync("exit"); await child.StandardInput.FlushAsync();
                    }
                }
                await child.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30));
                if (!mode.StartsWith("kill", StringComparison.Ordinal)) Assert.True(child.ExitCode == 0, await errors);
                using (var reopened = Open()) { Assert.False(reopened.AdmissionsOpen); Assert.True(reopened.WritersMustRemainStopped); }
                AssertBytes(before);
            }
            finally { await Stop(child); _ = await errors; }
        }
    }

    /// <summary>Actual symlink/junction roots and protected paths reject before lease/state adoption.</summary>
    /// <param name="placement">Link role.</param>
    [Theory]
    [InlineData("root")]
    [InlineData("ancestor")]
    [InlineData("protected")]
    [InlineData("journal")]
    public async Task LinkedNamespace_Rejects(string placement)
    {
        Seed(); var link = Path.Combine(_area, "link"); var target = placement == "ancestor" ? _area : placement == "journal" ? Data : Root;
        if (placement == "journal") { link = Path.Combine(Root, "journal.bin"); File.Delete(link); }
        await CreateLink(link, target, hard: false);
        try
        {
            var root = placement == "root" ? link : placement == "ancestor" ? Path.Combine(link, "host") : Root;
            Assert.Throws<InvalidDataException>(() => { using var host = Open(root, placement == "protected" ? link : null); });
        }
        finally { Directory.Delete(link); }
        if (placement == "journal") File.WriteAllBytes(Path.Combine(Root, "journal.bin"), []);
        using var valid = Open(); Assert.False(valid.AdmissionsOpen);
    }

    /// <summary>An owner-file hard-link alias contends on the same actual lock inode across processes.</summary>
    [Fact]
    public async Task OwnerHardLinkAlias_ContendsAcrossProcesses()
    {
        Seed(); var alias = Path.Combine(_area, "alias"); Directory.CreateDirectory(alias);
        File.Copy(Path.Combine(Root, "host.meta"), Path.Combine(alias, "host.meta")); File.Copy(Path.Combine(Root, "journal.bin"), Path.Combine(alias, "journal.bin"));
        await CreateLink(Path.Combine(alias, "owner.lock"), Path.Combine(Root, "owner.lock"), hard: true);
        using var child = Start("exit"); var errors = child.StandardError.ReadToEndAsync();
        try { await Line(child, "ACQUIRED"); Assert.Throws<IOException>(() => { using var contender = Open(alias); }); }
        finally { await Stop(child); _ = await errors; }
        using var afterExit = Open(alias); Assert.False(afterExit.AdmissionsOpen);
    }

    /// <summary>Linux FIFO roles fail closed without a blocking read-only pipe open.</summary>
    /// <param name="role">Non-seekable role.</param>
    [Theory]
    [InlineData("owner.lock")]
    [InlineData("host.meta")]
    [InlineData("journal.bin")]
    public async Task LinuxFifoRole_RejectsWithoutBlocking(string role)
    {
        if (!OperatingSystem.IsLinux()) return;
        Seed(); var path = Path.Combine(Root, role); File.Delete(path); await Utility("mkfifo", [path]);
        Assert.Throws<InvalidDataException>(() => { using var owner = Open(); });
    }

    /// <summary>Persisted artifact/destination roots cannot overlap host state, even when configured roots are disjoint.</summary>
    [Fact]
    public void JournalPaths_AreCheckedUnderOwnership()
    {
        Seed(); var intent = new EpochAdministrativeAttemptDescriptor(Guid.NewGuid(), EpochPublicationKind.LegacyMigration,
            Path.Combine(Root, "artifact"), Path.Combine(Data, "candidate"), new string('a', 64), Guid.NewGuid(), 7, 0, null, EpochProfile.ScalarWal, DurabilityMode.ProcessCrash);
        var snapshot = new HostLedgerSnapshot(new(Guid.NewGuid(), "pilot", "scope", intent, 1, Guid.NewGuid(), 1), HostLedgerStage.Recorded);
        var meta = HostJournalCodec.DecodeMetadata(File.ReadAllBytes(Path.Combine(Root, "host.meta")), "pilot", "scope");
        File.WriteAllBytes(Path.Combine(Root, "journal.bin"), HostJournalCodec.EncodeFrame(meta.JournalId, 1, new string('0', 64), HostJournalEvent.RecordIntent, snapshot));
        var before = Bytes(); Assert.Throws<InvalidDataException>(() => { using var owner = Open(); }); AssertBytes(before);
        snapshot = snapshot with { Context = snapshot.Context with { Intent = intent with { ArtifactRoot = Path.Combine(Data, "artifact") } } };
        File.WriteAllBytes(Path.Combine(Root, "journal.bin"), HostJournalCodec.EncodeFrame(meta.JournalId, 1, new string('0', 64), HostJournalEvent.RecordIntent, snapshot));
        using var valid = Open(); Assert.Single(valid.History.Frames); Assert.False(valid.AdmissionsOpen);
    }
    private static async Task CreateLink(string link, string target, bool hard)
    {
        if (OperatingSystem.IsWindows()) await Utility("cmd.exe", ["/c", "mklink", hard ? "/H" : "/J", link, target]);
        else if (hard) await Utility("ln", [target, link]);
        else Directory.CreateSymbolicLink(link, target);
    }
    private static async Task Utility(string name, string[] args)
    {
        var info = new ProcessStartInfo(name) { UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true, CreateNoWindow = true };
        foreach (var arg in args) info.ArgumentList.Add(arg);
        using var process = Process.Start(info) ?? throw new InvalidOperationException("No native test utility.");
        var output = process.StandardOutput.ReadToEndAsync(); var errors = process.StandardError.ReadToEndAsync();
        await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(10)); Assert.True(process.ExitCode == 0, await output + await errors);
    }
    private Dictionary<string, byte[]> Bytes() => Directory.GetFiles(Root).ToDictionary(path => Path.GetFileName(path)!, File.ReadAllBytes);
    private void AssertBytes(Dictionary<string, byte[]> before) { var after = Bytes(); Assert.Equal(before.Keys.Order(), after.Keys.Order()); foreach (var pair in before) Assert.Equal(pair.Value, after[pair.Key]); }
    /// <summary>Deletes only this test's GUID tree after every child and ownership handle closes.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
