// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Inspects physical runtime file identities for local migration compatibility tests.
// SPECIAL NOTES        : Local baseline compatibility only; no archived release or actual routing claim.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

internal static class MigrationRuntimeIdentities
{
    internal static Dictionary<string, string> Read(string store)
    {
        var paths = Directory.GetFiles(store, "*", SearchOption.AllDirectories)
            .Where(path => path.Contains(Path.DirectorySeparatorChar + ".epoch" + Path.DirectorySeparatorChar, StringComparison.Ordinal) ||
                path.Contains(Path.DirectorySeparatorChar + "readers" + Path.DirectorySeparatorChar, StringComparison.Ordinal) ||
                path.EndsWith("writer.lock", StringComparison.Ordinal)).Order().ToArray();
        if (OperatingSystem.IsWindows())
        {
            return paths.ToDictionary(path => path, path =>
            {
                using var handle = File.OpenHandle(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
                if (!GetFileInformationByHandleEx(handle, 18, out var info, (uint)Marshal.SizeOf<FileIdentity>()))
                    throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
                return $"{info.Volume}:{info.Low}:{info.High}";
            });
        }
        if (!OperatingSystem.IsLinux()) throw new PlatformNotSupportedException("Physical identity checks require Windows or Linux.");
        var start = new ProcessStartInfo("stat") { RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false };
        start.ArgumentList.Add("-Lc"); start.ArgumentList.Add("%d:%i"); start.ArgumentList.Add("--");
        foreach (var path in paths) start.ArgumentList.Add(path);
        using var process = Process.Start(start) ?? throw new InvalidOperationException("Cannot inspect runtime inode identities.");
        var output = process.StandardOutput.ReadToEnd(); var error = process.StandardError.ReadToEnd();
        if (!process.WaitForExit(30_000)) { process.Kill(true); throw new TimeoutException("stat did not exit."); }
        Assert.True(process.ExitCode == 0, error);
        var identities = output.Split('\n', StringSplitOptions.RemoveEmptyEntries); Assert.Equal(paths.Length, identities.Length);
        return paths.Zip(identities).ToDictionary(pair => pair.First, pair => pair.Second);
    }
    [StructLayout(LayoutKind.Sequential)]
    private struct FileIdentity { internal ulong Volume; internal ulong Low; internal ulong High; }
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetFileInformationByHandleEx(SafeFileHandle handle, int informationClass, out FileIdentity information, uint size);

}
