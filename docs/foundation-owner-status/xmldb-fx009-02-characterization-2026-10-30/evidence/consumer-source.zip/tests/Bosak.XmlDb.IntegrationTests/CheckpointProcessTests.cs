// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Verifies checkpoint crash safety and reader leases across processes.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Verifies checkpoint crash safety and reader leases across processes.</summary>
public sealed class CheckpointProcessTests : IDisposable
{
    private readonly string _root = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-cp-process-" + Guid.NewGuid().ToString("N"));

    /// <summary>Termination during a replacement checkpoint preserves complete committed state and the prior selector.</summary>
    /// <param name="stage">Publication checkpoint.</param>
    /// <param name="selected">Expected selected anchor after recovery.</param>
    [Theory]
    [InlineData("CheckpointStageCreated", 1)]
    [InlineData("CheckpointFilesFlushed", 1)]
    [InlineData("CheckpointAnchorFlushed", 1)]
    [InlineData("CheckpointDirectoryPublished", 1)]
    [InlineData("CheckpointSelectorTemporaryFlushed", 1)]
    [InlineData("CheckpointSelectorPublished", 2)]
    public async Task Checkpoint_ProcessKilled_PreservesStateAndVerifiableSelector(string stage, int selected)
    {
        Seed();
        using (var database = EmbeddedXmlDatabase.Open(_root)) { Commit(database, "SO-2"); database.CreateCheckpoint(); Commit(database, "SO-3"); }
        var crash = await Run("checkpoint", stage);
        Assert.NotEqual(0, crash.Code);
        Assert.Contains("FAULT:" + stage, crash.Output);
        for (var attempt = 0; attempt < 2; attempt++)
        {
            var result = await Run("inspect-fast");
            Assert.True(result.Code == 0, result.Error);
            using var json = JsonDocument.Parse(result.Output);
            Assert.Equal("SO-3", json.RootElement.GetProperty("Header").GetString());
            Assert.Equal(2, json.RootElement.GetProperty("CommitSequence").GetInt32());
            Assert.Equal(selected, json.RootElement.GetProperty("LastRecovery").GetProperty("CheckpointSequence").GetInt32());
        }
        using var full = EmbeddedXmlDatabase.Open(_root);
        Assert.Equal(2UL, full.CommitSequence);
        Assert.Equal(2, Directory.GetFiles(Path.Combine(_root, ".transactions", "wal")).Length);
    }

    /// <summary>An acknowledged checkpoint remains selectable after immediate termination.</summary>
    [Fact]
    public async Task Checkpoint_AcknowledgedThenKilled_ReopensSelectedAnchor()
    {
        Seed();
        using (var database = EmbeddedXmlDatabase.Open(_root)) Commit(database, "SO-2");
        var crash = await Run("ack-checkpoint");
        Assert.NotEqual(0, crash.Code);
        Assert.Contains("CHECKPOINT-ACK:1", crash.Output);
        var result = await Run("inspect-fast");
        Assert.True(result.Code == 0, result.Error);
        using var json = JsonDocument.Parse(result.Output);
        Assert.Equal(1, json.RootElement.GetProperty("LastRecovery").GetProperty("CheckpointSequence").GetInt32());
    }

    /// <summary>A reader's lease survives its coordinator and blocks another process until disposal or process exit.</summary>
    /// <param name="kill">Whether to kill the holder instead of requesting a final uncached read.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Reader_OwnerDisposed_StaysPinnedAcrossProcesses(bool kill)
    {
        Seed();
        using (var database = EmbeddedXmlDatabase.Open(_root)) Commit(database, "SO-2");
        using var holder = Start("pin-reader");
        try
        {
            Assert.Equal("PINNED:1", await holder.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(20)));
            using (var database = EmbeddedXmlDatabase.Open(_root)) { Commit(database, "SO-3"); database.CreateCheckpoint(); }
            var blocked = await Run("probe-reader", "1");
            Assert.Equal(3, blocked.Code);
            Assert.Contains("BLOCKED", blocked.Output);
            if (kill) holder.Kill(true);
            else
            {
                await holder.StandardInput.WriteLineAsync("read");
                await holder.StandardInput.FlushAsync();
                var line = await holder.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(20));
                Assert.NotNull(line);
                using var value = JsonDocument.Parse(line);
                Assert.Equal("SO-2", value.RootElement.GetProperty("Value").GetString());
                Assert.Equal(1, value.RootElement.GetProperty("CommitSequence").GetInt32());
            }
            await holder.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(20));
            if (!kill) Assert.Equal(0, holder.ExitCode);
        }
        finally
        {
            if (!holder.HasExited) holder.Kill(true);
            await holder.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(20));
        }
        var available = await Run("probe-reader", "1");
        Assert.True(available.Code == 0, available.Error);
        Assert.Contains("AVAILABLE", available.Output);
    }

    private void Seed()
    {
        using var input = new MemoryStream(Encoding.UTF8.GetBytes("<SalesOrder><SalesOrderHeader><DocumentID>SO-1</DocumentID></SalesOrderHeader><SalesOrderLine>line</SalesOrderLine></SalesOrder>"));
        XmlFragmentImporter.Import(input, _root);
    }

    private static void Commit(EmbeddedXmlDatabase database, string value)
    {
        using var read = database.BeginRead();
        var target = Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id))
            .Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();
        using var transaction = database.BeginWrite();
        transaction.ReplaceNodeValue(target, value);
        transaction.Commit();
    }

    private Process Start(string action, string? argument = null)
    {
        var start = new ProcessStartInfo("dotnet")
        {
            RedirectStandardInput = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
        };
        start.ArgumentList.Add(typeof(CheckpointProcessTests).Assembly.Location);
        start.ArgumentList.Add(action);
        start.ArgumentList.Add(_root);
        if (argument is not null) start.ArgumentList.Add(argument);
        return Process.Start(start) ?? throw new InvalidOperationException("Cannot start checkpoint process probe.");
    }

    private async Task<(int Code, string Output, string Error)> Run(string action, string? argument = null)
    {
        using var process = Start(action, argument);
        var output = process.StandardOutput.ReadToEndAsync();
        var error = process.StandardError.ReadToEndAsync();
        try { await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); }
        catch { if (!process.HasExited) process.Kill(true); throw; }
        return (process.ExitCode, await output, await error);
    }

    /// <inheritdoc />
    public void Dispose() { if (Directory.Exists(_root)) Directory.Delete(_root, true); }
}
