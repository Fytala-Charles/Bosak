// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Qualifies explicit fresh-plan retries after acknowledged stopped absence.
// SPECIAL NOTES        : Internal pilot qualification; no routing, plan replay or global/adversarial fencing.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Text;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Tests explicit fresh plans, evidence rechecks and duplicate retry exclusion.</summary>
public sealed class EmbeddedHostRetryTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ep6c-" + Guid.NewGuid().ToString("N"));
    private string Artifact => Path.Combine(_area, "artifact");
    private string Destination => Path.Combine(_area, "destination");
    private string HostRoot => Path.Combine(_area, "host");
    private static EpochPublicationKind Kind(bool epoch) => epoch ? EpochPublicationKind.IndependentEpochRestore : EpochPublicationKind.LegacyMigration;
    private EmbeddedHostLifetime Host()
    {
        var host = EmbeddedHostLifetime.Provision(HostRoot, "pilot", "scope", [Path.Combine(_area, "source"), Artifact, Destination, Path.Combine(_area, "legacy"), Path.Combine(_area, "initial")],
            new(HostRoot, "pilot", "scope", true, true, true));
        host.OpenAdministrativeAdmissions(Evidence(host)); Assert.True(host.EnableJournalAppend(host.JournalStatus.KnownPosition, Evidence(host))); return host;
    }
    private static EmbeddedHostAdmissionEvidence Evidence(EmbeddedHostLifetime host) => new(host.Context, true, true, true, true, true, true);
    private static EmbeddedHostInspectionEvidence InspectionEvidence(EmbeddedHostLifetime host) => new(host.Context, true, true, true, true, true);


    private EmbeddedHostLifetime Reopen() => EmbeddedHostLifetime.OpenExisting(HostRoot, "pilot", "scope", [Path.Combine(_area, "source"), Artifact, Destination, Path.Combine(_area, "legacy"), Path.Combine(_area, "initial")]);
    private HostLedgerSnapshot Saved(bool epoch, bool publish, bool acknowledge)
    {
        using var host = Host(); var flow = EmbeddedHostOrchestrator.Create(host); var ticket = flow.Prepare(Guid.NewGuid(), Kind(epoch), Artifact, Destination); flow.Record(ticket);
        if (publish)
        {
            if (acknowledge) Assert.Equal(EmbeddedHostExecutionDisposition.Succeeded, flow.Execute(ticket).Disposition);
            else
            {
                var uncertain = EmbeddedHostOrchestrator.CreateCore(host, ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash)), checkpoint: stage =>
                { if (stage == HostOrchestrationStage.BeforeReceiptSave) throw new IOException("Lost receipt save."); });
                var own = uncertain.Prepare(Guid.NewGuid(), Kind(epoch), Artifact, Destination); uncertain.Record(own);
                Assert.Equal(EmbeddedHostExecutionDisposition.ReconciliationRequired, uncertain.Execute(own).Disposition);
            }
        }
        return host.ReadJournalForReconciliation().Frames[^1].Snapshot;
    }
    private static EmbeddedHostAbsenceEvidence Absence(EmbeddedHostLifetime host, HostLedgerSnapshot snapshot) => new(host.Context, snapshot, true, true, true);


    private static EmbeddedHostRetryEvidence RetryEvidence(EmbeddedHostLifetime host, HostLedgerSnapshot absent) => new(host.Context, absent, true, true, true, true, true, true, true);
    private (EmbeddedHostLifetime Host, HostLedgerSnapshot Absent) Ready(bool epoch, int head)
    {
        Seed(epoch, head); var prior = Saved(epoch, false, false); var host = Reopen();
        var absent = EmbeddedHostRestartReconciler.Reconcile(host, host.JournalStatus.KnownPosition, prior, InspectionEvidence(host), Absence(host, prior)).Snapshot;
        // This is a separate explicit administrative readiness decision, never a reconciler side effect.
        host.OpenAdministrativeAdmissions(Evidence(host)); Assert.True(host.EnableJournalAppend(host.JournalStatus.KnownPosition, Evidence(host)));
        return (host, absent);
    }
    /// <summary>Both roles and heads preserve request/pin while allocating a fresh actual executable plan.</summary>
    /// <param name="epoch">Role.</param><param name="head">Source head.</param>
    [Theory]
    [InlineData(false, 0)]
    [InlineData(false, 3)]
    [InlineData(true, 0)]
    [InlineData(true, 3)]
    public void FreshRetryPublishesOnce(bool epoch, int head)
    {
        var ready = Ready(epoch, head); using var host = ready.Host; var flow = EmbeddedHostOrchestrator.Create(host); var prior = ready.Absent;
        var ticket = flow.PrepareRetry(RetryEvidence(host, prior)); var next = ticket.Describe();
        Assert.NotEqual(prior.Context.Intent.AttemptId, next.AttemptId); Assert.Equal(prior.Context.Intent, next with { AttemptId = prior.Context.Intent.AttemptId });
        Assert.Equal(prior.Context.RequestId, ticket.Snapshot.Context.RequestId); Assert.Equal(EpochAttemptState.Prepared, ticket.PlanState);
        flow.Record(ticket); var result = flow.Execute(ticket); Assert.Equal(EmbeddedHostExecutionDisposition.Succeeded, result.Disposition);
        Assert.Equal(next.AttemptId, result.PipelineReceipt!.OperationId); Assert.Throws<InvalidOperationException>(() => flow.Execute(ticket));
        Assert.Contains(host.ReadJournalForReconciliation().Frames, f => f.Snapshot == prior); Assert.Equal(6, host.ReadJournalForReconciliation().Frames.Count);
    }
    /// <summary>Every fresh exclusion and binding fact remains mandatory.</summary>
    /// <param name="invalid">Invalid fact.</param>
    [Theory]
    [InlineData("context")]
    [InlineData("snapshot")]
    [InlineData("fresh")]
    [InlineData("writers")]
    [InlineData("publishers")]
    [InlineData("prior")]
    [InlineData("queue")]
    [InlineData("namespace")]
    [InlineData("retained")]
    public void InvalidRetryEvidenceRejects(string invalid)
    {
        var ready = Ready(false, 0); using var host = ready.Host; var flow = EmbeddedHostOrchestrator.Create(host); var e = RetryEvidence(host, ready.Absent);
        e = invalid switch { "context" => e with { Context = e.Context with { SessionId = Guid.NewGuid() } }, "snapshot" => e with { Absent = e.Absent with { Context = e.Absent.Context with { Revision = 99 } } }, "fresh" => e with { Fresh = false }, "writers" => e with { AllWritersControlled = false }, "publishers" => e with { AllPublishersControlled = false }, "prior" => e with { PriorExecutorsExcluded = false }, "queue" => e with { QueueFree = false }, "namespace" => e with { StableDestinationNamespace = false }, "retained" => e with { NoRetainedPublicationEvidence = false }, _ => e };
        var before = host.JournalStatus.KnownPosition; Assert.Throws<InvalidOperationException>(() => flow.PrepareRetry(e)); Assert.Equal(before, host.JournalStatus.KnownPosition); Assert.False(Directory.Exists(Destination));
    }
    /// <summary>Artifact or destination changes after preparation are rejected again before recording.</summary>
    /// <param name="artifact">Whether input or destination changes.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void ChangedFactsBeforeRecordReject(bool artifact)
    {
        var ready = Ready(false, 0); using var host = ready.Host; var flow = EmbeddedHostOrchestrator.Create(host); var ticket = flow.PrepareRetry(RetryEvidence(host, ready.Absent)); var before = host.JournalStatus.KnownPosition;
        if (artifact) File.WriteAllBytes(Path.Combine(Artifact, "COMPLETE"), [0]); else Directory.CreateDirectory(Destination);
        Assert.Throws<InvalidOperationException>(() => flow.Record(ticket)); Assert.Equal(before, host.JournalStatus.KnownPosition); Assert.Equal(EpochAttemptState.Prepared, ticket.PlanState); Assert.True(flow.ReconciliationRequired); Assert.False(host.AdmissionsOpen);
    }
    /// <summary>Only one prepared retry can supersede the prior absent request, even across fronts.</summary>
    [Fact]
    public void CompetingPreparedRetriesHaveOneRecord()
    {
        var ready = Ready(false, 0); using var host = ready.Host; var one = EmbeddedHostOrchestrator.Create(host); var two = EmbeddedHostOrchestrator.Create(host); var e = RetryEvidence(host, ready.Absent);
        var first = one.PrepareRetry(e); var second = two.PrepareRetry(e); one.Record(first); var position = host.JournalStatus.KnownPosition;
        Assert.Throws<InvalidOperationException>(() => two.Record(second)); Assert.Equal(position, host.JournalStatus.KnownPosition); Assert.Equal(EpochAttemptState.Prepared, second.PlanState); Assert.False(Directory.Exists(Destination));
    }
    /// <summary>A stopped/faulted front is not rearmed by providing new evidence.</summary>
    [Fact]
    public void ShutdownPreventsRetryPreparation()
    {
        var ready = Ready(false, 0); using var host = ready.Host; var flow = EmbeddedHostOrchestrator.Create(host); host.CloseAdmissions();
        Assert.Throws<InvalidOperationException>(() => flow.PrepareRetry(RetryEvidence(host, ready.Absent))); Assert.False(Directory.Exists(Destination));
    }
    /// <summary>Changes already present at retry preparation cannot create an eligible ticket.</summary>
    /// <param name="artifact">Whether input or destination changes.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void ChangedFactsBeforePrepareReject(bool artifact)
    {
        var ready = Ready(false, 0); using var host = ready.Host; var flow = EmbeddedHostOrchestrator.Create(host); var before = host.JournalStatus.KnownPosition;
        if (artifact) File.WriteAllBytes(Path.Combine(Artifact, "COMPLETE"), [0]); else Directory.CreateDirectory(Destination);
        Assert.Throws<InvalidOperationException>(() => flow.PrepareRetry(RetryEvidence(host, ready.Absent))); Assert.Equal(before, host.JournalStatus.KnownPosition);
    }
    /// <summary>Concurrent fronts can record only one new intent for an absent request.</summary>
    [Fact]
    public async Task ConcurrentRetryRecordsHaveOneWinner()
    {
        var ready = Ready(false, 0); using var host = ready.Host; var e = RetryEvidence(host, ready.Absent);
        var one = EmbeddedHostOrchestrator.Create(host); var two = EmbeddedHostOrchestrator.Create(host); var first = one.PrepareRetry(e); var second = two.PrepareRetry(e);
        using var start = new ManualResetEventSlim();
        Task<bool> Record(EmbeddedHostOrchestrator flow, EmbeddedHostAttempt ticket) => Task.Run(() => { start.Wait(); try { flow.Record(ticket); return true; } catch (InvalidOperationException) { return false; } });
        var tasks = new[] { Record(one, first), Record(two, second) }; start.Set(); var results = await Task.WhenAll(tasks);
        Assert.Single(results, r => r); Assert.Equal(4, host.ReadJournalForReconciliation().Frames.Count); Assert.False(Directory.Exists(Destination));
    }
    /// <summary>A lost retry-intent acknowledgment retains bytes without enabling dispatch or resetting a plan.</summary>
    [Fact]
    public void LostRetryRecordAcknowledgmentStaysStopped()
    {
        var ready = Ready(false, 0); using var host = ready.Host;
        var flow = EmbeddedHostOrchestrator.CreateCore(host, ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash)), appendCheckpoint: stage => { if (stage == HostAppendStage.Flushed) throw new IOException(); });
        var ticket = flow.PrepareRetry(RetryEvidence(host, ready.Absent));
        Assert.Throws<IOException>(() => flow.Record(ticket)); Assert.True(host.JournalStatus.Faulted); Assert.False(host.AdmissionsOpen); Assert.Equal(EpochAttemptState.Prepared, ticket.PlanState);
        Assert.Throws<InvalidOperationException>(() => flow.Execute(ticket)); Assert.Equal(4, host.ReadJournalForReconciliation().Frames.Count); Assert.False(Directory.Exists(Destination));
    }
    /// <summary>Ordinary preparation cannot bypass explicit retry evidence for an existing request.</summary>
    [Fact]
    public void OrdinaryRecordCannotBypassRetryBoundary()
    {
        var ready = Ready(false, 0); using var host = ready.Host; var flow = EmbeddedHostOrchestrator.Create(host); var prior = ready.Absent;
        var ticket = flow.Prepare(prior.Context.RequestId, prior.Context.Intent.Kind, Artifact, Destination); var before = host.JournalStatus.KnownPosition;
        Assert.Throws<InvalidOperationException>(() => flow.Record(ticket)); Assert.Equal(before, host.JournalStatus.KnownPosition); Assert.Equal(EpochAttemptState.Prepared, ticket.PlanState); Assert.False(Directory.Exists(Destination));
    }
    private void Seed(bool epoch, int count)
    {
        Directory.CreateDirectory(_area); var source = Path.Combine(_area, "source"); var legacy = epoch ? Path.Combine(_area, "legacy") : Artifact;
        using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, source);
        using (var owner = EmbeddedXmlDatabase.Open(source))
        { using var read = owner.BeginRead(); for (var index = 1; index <= count; index++) { using var tx = owner.BeginWrite(); tx.ReplaceNodeValue(Target(read), "new-" + index); tx.Commit(); } owner.CreateBackup(legacy); }
        if (!epoch) return;
        var result = EpochLegacyMigration.Convert(legacy, Path.Combine(_area, "initial"));
        using var candidate = ScalarEpochDatabase.Open(result.StorePath, new(DurabilityMode.ProcessCrash, ScalarEpochRecovery.FullHistory)); candidate.CreateBackup(Artifact);
    }
    private static ulong Target(ImmutableXmlSnapshot read) => Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id)).Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();


    /// <summary>Deletes only the test-owned tree after all handles close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
