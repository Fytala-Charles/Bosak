// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Verifies WAL recovery after abrupt process termination.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Verifies WAL recovery after abrupt process termination.</summary>
public sealed class CrashRecoveryTests : IDisposable
{
    private readonly string _root = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-crash-" + Guid.NewGuid().ToString("N"));

    /// <summary>Kills the writer at each publication boundary, then checks complete old/new XPath state.</summary>
    /// <param name="stage">Internal durability/publication checkpoint.</param>
    /// <param name="expectedSequence">Expected sequence; minus one permits either side of an unflushed append.</param>
    [Theory]
    [InlineData("StageCreated", 0)]
    [InlineData("FragmentsFlushed", 0)]
    [InlineData("DirectoryFlushed", 0)]
    [InlineData("ManifestFlushed", 0)]
    [InlineData("BeforeWal", 0)]
    [InlineData("WalPrefixWritten", 0)]
    [InlineData("WalWritten", -1)]
    [InlineData("WalFlushed", 1)]
    [InlineData("GenerationPublished", 1)]
    [InlineData("RootTemporaryFlushed", 1)]
    [InlineData("RootPublished", 1)]
    public async Task Commit_ProcessKilled_RecoversCompleteGeneration(string stage, int expectedSequence)
    {
        Import();
        var crash = await Run("write", stage);
        Assert.NotEqual(0, crash.ExitCode);
        Assert.Contains("FAULT:" + stage, crash.Output);
        await AssertRecovered(expectedSequence);
    }

    /// <summary>Kills redo itself and verifies a second recovery completes idempotently.</summary>
    /// <param name="stage">Recovery publication checkpoint.</param>
    [Theory]
    [InlineData("StageCreated")]
    [InlineData("FragmentsFlushed")]
    [InlineData("DirectoryFlushed")]
    [InlineData("ManifestFlushed")]
    [InlineData("GenerationPublished")]
    [InlineData("RootTemporaryFlushed")]
    [InlineData("RootPublished")]
    public async Task Recovery_ProcessKilled_CanReplayAgain(string stage)
    {
        Import();
        var writer = await Run("write", "WalFlushed");
        Assert.Contains("FAULT:WalFlushed", writer.Output);
        var recovery = await Run("recover", stage);
        Assert.NotEqual(0, recovery.ExitCode);
        Assert.Contains("FAULT:" + stage, recovery.Output);
        await AssertRecovered(1);
    }

    /// <summary>An acknowledged commit survives immediate process termination.</summary>
    [Fact]
    public async Task Commit_AcknowledgedThenKilled_RemainsCommitted()
    {
        Import();
        var result = await Run("ack-write");
        Assert.NotEqual(0, result.ExitCode);
        Assert.Contains("ACK:1", result.Output);
        await AssertRecovered(1);
    }

    /// <summary>OS writer ownership is exclusive across processes and released after termination.</summary>
    [Fact]
    public async Task WriterLease_ProcessKilled_ReleasesOwnershipForRecovery()
    {
        Import();
        using var holder = Start("hold");
        try
        {
            Assert.Equal("LEASED", await holder.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(20)));
            Assert.Throws<IOException>(() => EmbeddedXmlDatabase.Open(_root));
        }
        finally
        {
            if (!holder.HasExited) holder.Kill(true);
            await holder.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(20));
        }
        await AssertRecovered(0);
    }

    private async Task AssertRecovered(int expectedSequence)
    {
        for (var retry = 0; retry < 2; retry++)
        {
            var result = await Run("inspect");
            Assert.True(result.ExitCode == 0, result.Error);
            using var json = JsonDocument.Parse(result.Output);
            var sequence = json.RootElement.GetProperty("CommitSequence").GetInt32();
            if (expectedSequence >= 0) Assert.Equal(expectedSequence, sequence);
            else Assert.InRange(sequence, 0, 1);
            Assert.Equal(sequence == 0 ? "SO-1" : "SO-2", json.RootElement.GetProperty("Header").GetString());
            Assert.Equal(20, json.RootElement.GetProperty("Lines").GetInt32());
            Assert.Equal(0, json.RootElement.GetProperty("Metrics").GetProperty("LineFragmentReads").GetInt32());
            expectedSequence = sequence;
        }
    }

    private void Import()
    {
        var xml = "<SalesOrder><SalesOrderHeader><DocumentID>SO-1</DocumentID></SalesOrderHeader>" +
            string.Concat(Enumerable.Range(1, 20).Select(i => $"<SalesOrderLine><Item><ItemID>{i}</ItemID></Item></SalesOrderLine>")) + "</SalesOrder>";
        using var input = new MemoryStream(Encoding.UTF8.GetBytes(xml));
        XmlFragmentImporter.Import(input, _root, linesPerFragment: 4);
    }

    private Process Start(string action, string? stage = null)
    {
        var start = new ProcessStartInfo("dotnet") { RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false };
        start.ArgumentList.Add(typeof(CrashRecoveryTests).Assembly.Location);
        start.ArgumentList.Add(action);
        start.ArgumentList.Add(_root);
        if (stage is not null) start.ArgumentList.Add(stage);
        return Process.Start(start) ?? throw new InvalidOperationException("Cannot start crash probe.");
    }

    private async Task<(int ExitCode, string Output, string Error)> Run(string action, string? stage = null)
    {
        using var process = Start(action, stage);
        var output = process.StandardOutput.ReadToEndAsync();
        var error = process.StandardError.ReadToEndAsync();
        try { await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); }
        catch { if (!process.HasExited) process.Kill(true); throw; }
        return (process.ExitCode, await output, await error);
    }

    /// <inheritdoc />
    public void Dispose()
    {
        if (Directory.Exists(_root)) Directory.Delete(_root, true);
    }
}
