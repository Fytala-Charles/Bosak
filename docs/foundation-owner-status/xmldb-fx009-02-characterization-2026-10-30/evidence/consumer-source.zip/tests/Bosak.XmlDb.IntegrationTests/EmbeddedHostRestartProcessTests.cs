// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Tests process death across stopped reconciliation and fresh-plan retry boundaries.
// SPECIAL NOTES        : Stopped restart inspection only; no ticket reconstruction, retry, routing or global fence.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Qualifies actual process interruption without inferring dispatch from retained frames.</summary>
public sealed class EmbeddedHostRestartProcessTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ep6d-" + Guid.NewGuid().ToString("N"));
    private string Artifact => Path.Combine(_area, "artifact");
    private string Destination => Path.Combine(_area, "destination");
    private string HostRoot => Path.Combine(_area, "host");
    private string[] Protected => [Artifact, Destination, Path.Combine(_area, "source"), Path.Combine(_area, "legacy"), Path.Combine(_area, "initial")];
    private EmbeddedHostLifetime Open() => EmbeddedHostLifetime.OpenExisting(HostRoot, "pilot", "scope", Protected);
    private HostLedgerSnapshot Prior(bool epoch, bool published)
    {
        using var host = EmbeddedHostLifetime.Provision(HostRoot, "pilot", "scope", Protected, new(HostRoot, "pilot", "scope", true, true, true));
        var evidence = new EmbeddedHostAdmissionEvidence(host.Context, true, true, true, true, true, true); host.OpenAdministrativeAdmissions(evidence); host.EnableJournalAppend(host.JournalStatus.KnownPosition, evidence);
        var flow = EmbeddedHostOrchestrator.CreateCore(host, ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash)), checkpoint: stage => { if (stage == HostOrchestrationStage.BeforeReceiptSave) throw new IOException("Uncertain prior publication."); });
        var ticket = flow.Prepare(Guid.NewGuid(), epoch ? EpochPublicationKind.IndependentEpochRestore : EpochPublicationKind.LegacyMigration, Artifact, Destination); flow.Record(ticket);
        if (published) Assert.Equal(EmbeddedHostExecutionDisposition.ReconciliationRequired, flow.Execute(ticket).Disposition);
        return host.ReadJournalForReconciliation().Frames[^1].Snapshot;
    }
    /// <summary>Complete frames remain descriptive and fresh stopped reconciliation never recreates old execution authority.</summary>
    /// <param name="epoch">Publication role.</param><param name="mode">Prior outcome and retry choice.</param><param name="point">Actual child termination point.</param>
    [Theory]
    [InlineData(false, "absent", "transfer:Validated")]
    [InlineData(false, "absent", "transfer:BeforeWrite")]
    [InlineData(false, "absent", "transfer:Written")]
    [InlineData(false, "absent", "transfer:Flushed")]
    [InlineData(false, "absent", "transfer:BeforeAcknowledge")]
    [InlineData(false, "absent", "transfer:ACK")]
    [InlineData(false, "absent", "outcome:Validated")]
    [InlineData(false, "absent", "outcome:BeforeWrite")]
    [InlineData(false, "absent", "outcome:Written")]
    [InlineData(false, "absent", "outcome:Flushed")]
    [InlineData(false, "absent", "outcome:BeforeAcknowledge")]
    [InlineData(false, "absent", "outcome:ACK")]
    [InlineData(false, "known", "transfer:Validated")]
    [InlineData(false, "known", "transfer:BeforeWrite")]
    [InlineData(false, "known", "transfer:Written")]
    [InlineData(false, "known", "transfer:Flushed")]
    [InlineData(false, "known", "transfer:BeforeAcknowledge")]
    [InlineData(false, "known", "transfer:ACK")]
    [InlineData(false, "known", "outcome:Validated")]
    [InlineData(false, "known", "outcome:BeforeWrite")]
    [InlineData(false, "known", "outcome:Written")]
    [InlineData(false, "known", "outcome:Flushed")]
    [InlineData(false, "known", "outcome:BeforeAcknowledge")]
    [InlineData(false, "known", "outcome:ACK")]
    [InlineData(false, "retry", "retry:Validated")]
    [InlineData(false, "retry", "retry:BeforeWrite")]
    [InlineData(false, "retry", "retry:Written")]
    [InlineData(false, "retry", "retry:Flushed")]
    [InlineData(false, "retry", "retry:BeforeAcknowledge")]
    [InlineData(false, "retry", "retry:ACK")]
    [InlineData(false, "retry", "execute:AuthorizationAcknowledged")]
    [InlineData(false, "retry", "execute:BeforeInvoke")]
    [InlineData(false, "retry", "execute:PipelineReturned")]
    [InlineData(false, "retry", "execute:BeforeReceiptSave")]
    [InlineData(false, "retry", "execute:BeforeReturn")]
    [InlineData(false, "retry", "execute:ACK")]
    [InlineData(true, "absent", "transfer:Validated")]
    [InlineData(true, "absent", "transfer:BeforeWrite")]
    [InlineData(true, "absent", "transfer:Written")]
    [InlineData(true, "absent", "transfer:Flushed")]
    [InlineData(true, "absent", "transfer:BeforeAcknowledge")]
    [InlineData(true, "absent", "transfer:ACK")]
    [InlineData(true, "absent", "outcome:Validated")]
    [InlineData(true, "absent", "outcome:BeforeWrite")]
    [InlineData(true, "absent", "outcome:Written")]
    [InlineData(true, "absent", "outcome:Flushed")]
    [InlineData(true, "absent", "outcome:BeforeAcknowledge")]
    [InlineData(true, "absent", "outcome:ACK")]
    [InlineData(true, "known", "transfer:Validated")]
    [InlineData(true, "known", "transfer:BeforeWrite")]
    [InlineData(true, "known", "transfer:Written")]
    [InlineData(true, "known", "transfer:Flushed")]
    [InlineData(true, "known", "transfer:BeforeAcknowledge")]
    [InlineData(true, "known", "transfer:ACK")]
    [InlineData(true, "known", "outcome:Validated")]
    [InlineData(true, "known", "outcome:BeforeWrite")]
    [InlineData(true, "known", "outcome:Written")]
    [InlineData(true, "known", "outcome:Flushed")]
    [InlineData(true, "known", "outcome:BeforeAcknowledge")]
    [InlineData(true, "known", "outcome:ACK")]
    [InlineData(true, "retry", "retry:Validated")]
    [InlineData(true, "retry", "retry:BeforeWrite")]
    [InlineData(true, "retry", "retry:Written")]
    [InlineData(true, "retry", "retry:Flushed")]
    [InlineData(true, "retry", "retry:BeforeAcknowledge")]
    [InlineData(true, "retry", "retry:ACK")]
    [InlineData(true, "retry", "execute:AuthorizationAcknowledged")]
    [InlineData(true, "retry", "execute:BeforeInvoke")]
    [InlineData(true, "retry", "execute:PipelineReturned")]
    [InlineData(true, "retry", "execute:BeforeReceiptSave")]
    [InlineData(true, "retry", "execute:BeforeReturn")]
    [InlineData(true, "retry", "execute:ACK")]
    public async Task ProcessDeathRetainsEvidenceAndStoppedOwnership(bool epoch, string mode, string point)
    {
        Seed(epoch, 1); var prior = Prior(epoch, mode == "known"); var artifactBefore = Capture(Artifact);
        var info = new ProcessStartInfo("dotnet") { UseShellExecute = false, RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true, CreateNoWindow = true };
        foreach (var arg in new[] { typeof(EmbeddedHostRestartProcessTests).Assembly.Location, "ep6-restart", HostRoot, Artifact, Destination, mode, point }) info.ArgumentList.Add(arg);
        using var child = Process.Start(info) ?? throw new InvalidOperationException("No restart probe."); var errors = child.StandardError.ReadToEndAsync(); Guid? retryId = null;
        try
        {
            Assert.Equal("READY", await child.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(30)));
            await child.StandardInput.WriteLineAsync("continue"); await child.StandardInput.FlushAsync();
            if (mode == "retry")
            {
                var line = await child.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(30)); using var json = JsonDocument.Parse(line!); retryId = json.RootElement.GetProperty("AttemptId").GetGuid();
                Assert.NotEqual(prior.Context.Intent.AttemptId, retryId); Assert.Equal(prior.Context.Intent.InventorySha256, json.RootElement.GetProperty("InventorySha256").GetString());
                await child.StandardInput.WriteLineAsync("record"); await child.StandardInput.FlushAsync();
            }
            var output = child.StandardOutput.ReadToEndAsync(); await child.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(60)); Assert.NotEqual(0, child.ExitCode); Assert.Contains("EP6:" + point, await output); _ = await errors;
            var before = Capture(_area); var sourceBefore = Capture(Path.Combine(_area, "source")); var candidateBefore = Directory.Exists(Destination) ? Capture(Destination) : null; var published = mode == "known" || point is "execute:PipelineReturned" or "execute:BeforeReceiptSave" or "execute:BeforeReturn" or "execute:ACK";
            using (var host = Open())
            {
                Assert.False(host.AdmissionsOpen); Assert.False(host.JournalStatus.CanAttemptAppend); Assert.False(host.WasProvisionedHere); Assert.Throws<InvalidOperationException>(() => EmbeddedHostOrchestrator.Create(host));
                var early = point.EndsWith(":Validated", StringComparison.Ordinal) || point.EndsWith(":BeforeWrite", StringComparison.Ordinal);
                var initial = mode == "known" ? 2 : 1;
                var count = point.StartsWith("transfer:", StringComparison.Ordinal) ? initial + (early ? 0 : 1) : point.StartsWith("outcome:", StringComparison.Ordinal) ? initial + 1 + (early ? 0 : 1) : point.StartsWith("retry:", StringComparison.Ordinal) ? 3 + (early ? 0 : 1) : point is "execute:BeforeReturn" or "execute:ACK" ? 6 : 5;
                Assert.Equal(count, host.History.Frames.Count); Assert.Contains(host.History.Frames, f => f.Snapshot == prior);
                var latest = host.History.Frames[^1].Snapshot;
                if (mode == "retry" && count >= 4) { Assert.Equal(retryId, latest.Context.Intent.AttemptId); Assert.Equal(prior.Context.RequestId, latest.Context.RequestId); Assert.Equal(prior.Context.Intent, latest.Context.Intent with { AttemptId = prior.Context.Intent.AttemptId }); }
                var descriptor = published && mode == "retry" ? latest.Context.Intent : prior.Context.Intent;
                var observed = EpochPublicationInspector.Inspect(descriptor.ToInspectionRequest()); Assert.Equal(published ? EpochInspectionStatus.KnownOperationMatched : EpochInspectionStatus.NotObserved, observed.Status);
                if (published) Assert.Equal(descriptor.AttemptId, observed.Observed!.OperationId);
                Assert.Equal(point is "execute:BeforeReturn" or "execute:ACK", latest.Receipt is not null);
                if (mode == "known" && point.StartsWith("outcome:", StringComparison.Ordinal) && !early) { Assert.Equal(HostLedgerStage.ObservedKnown, latest.Stage); Assert.NotNull(latest.Observed); Assert.Null(latest.Receipt); }
            }
            AssertTree(before, _area); AssertTree(artifactBefore, Artifact);
            // A separately authorized reconciliation may correlate the retained outcome; it still cannot dispatch.
            using (var host = Open())
            {
                var saved = host.History.Frames[^1].Snapshot;
                var result = EmbeddedHostRestartReconciler.Reconcile(host, host.JournalStatus.KnownPosition, saved, new(host.Context, true, true, true, true, true), new(host.Context, saved, true, true, true));
                Assert.Equal(published ? EmbeddedHostReconciliationDisposition.KnownPublication : EmbeddedHostReconciliationDisposition.QualifiedAbsent, result.Disposition);
                Assert.False(host.AdmissionsOpen); Assert.False(host.JournalStatus.CanAttemptAppend);
            }
            AssertTree(artifactBefore, Artifact); AssertTree(sourceBefore, Path.Combine(_area, "source")); if (candidateBefore is not null) AssertTree(candidateBefore, Destination); Assert.Equal(published, Directory.Exists(Destination));
        }
        finally { if (!child.HasExited) { child.Kill(true); await child.WaitForExitAsync(); } _ = await errors; }
    }
    private static Dictionary<string, byte[]> Capture(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories).ToDictionary(path => path, File.ReadAllBytes);
    private static void AssertTree(Dictionary<string, byte[]> before, string root) { var after = Capture(root); Assert.Equal(before.Keys.Order(), after.Keys.Order()); foreach (var pair in before) Assert.Equal(pair.Value, after[pair.Key]); }
    private void Seed(bool epoch, int count)
    {
        Directory.CreateDirectory(_area); var source = Path.Combine(_area, "source"); var legacy = epoch ? Path.Combine(_area, "legacy") : Artifact;
        using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, source);
        using (var owner = EmbeddedXmlDatabase.Open(source))
        { using var read = owner.BeginRead(); for (var index = 1; index <= count; index++) { using var tx = owner.BeginWrite(); tx.ReplaceNodeValue(Target(read), "new-" + index); tx.Commit(); } owner.CreateBackup(legacy); }
        if (!epoch) return;
        var result = EpochLegacyMigration.Convert(legacy, Path.Combine(_area, "initial"));
        using var candidate = ScalarEpochDatabase.Open(result.StorePath, new(DurabilityMode.ProcessCrash, ScalarEpochRecovery.FullHistory)); candidate.CreateBackup(Artifact);
    }
    private static ulong Target(ImmutableXmlSnapshot read) => Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();

    /// <summary>Deletes only the GUID-owned tree after actual process exit and handle release.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
