// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Binds actual journal flush acknowledgments to planned publication in tests.
// SPECIAL NOTES        : Test-only composition; no production orchestration, global fence or route authority.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Text;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Tests actual host-file acknowledgments with real publication, including unknown authorization/receipt saves.</summary>
public sealed class EmbeddedHostJournalPublicationTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ep4-publication-" + Guid.NewGuid().ToString("N"));
    private string Artifact => Path.Combine(_area, "artifact");
    private string Destination => Path.Combine(_area, "destination");

    /// <summary>Only acknowledged authorization drives test dispatch; unknown receipt persistence never replays the pipeline.</summary>
    /// <param name="epoch">Restore rather than migrate.</param>
    /// <param name="failure">Lost host acknowledgment boundary.</param>
    [Theory]
    [InlineData(false, "none")]
    [InlineData(false, "authorization")]
    [InlineData(false, "receipt")]
    [InlineData(true, "none")]
    [InlineData(true, "authorization")]
    [InlineData(true, "receipt")]
    public async Task ActualJournalAndPublication_KeepAcknowledgmentsSeparate(bool epoch, string failure)
    {
        Seed(epoch, 1); var root = Path.Combine(_area, "host");
        using var owner = EmbeddedHostLifetime.Provision(root, "pilot", "scope", [Path.Combine(_area, "source"), Artifact, Destination, Path.Combine(_area, "legacy"), Path.Combine(_area, "initial")],
            new(root, "pilot", "scope", true, true, true));
        var evidence = new EmbeddedHostAdmissionEvidence(owner.Context, true, true, true, true, true, true);
        owner.OpenAdministrativeAdmissions(evidence); Assert.True(owner.EnableJournalAppend(owner.JournalStatus.KnownPosition, evidence));
        var admin = ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash));
        var plan = admin.PrepareAttempt(epoch ? EpochPublicationKind.IndependentEpochRestore : EpochPublicationKind.LegacyMigration, Artifact, Destination);
        var recorded = new HostLedgerSnapshot(new(Guid.NewGuid(), "pilot", "scope", plan.Describe(), 1, owner.Context.SessionId, 1), HostLedgerStage.Recorded);
        var intentSave = owner.AppendJournal(owner.JournalStatus.KnownPosition, HostJournalEvent.RecordIntent, recorded);
        Assert.Equal(HostJournalAppendDisposition.Acknowledged, intentSave.Disposition);
        var authorized = recorded with { Context = recorded.Context with { Revision = 2 }, Stage = HostLedgerStage.DispatchAuthorized };
        if (failure == "authorization")
        {
            HostJournalAppendResult? unknown = null;
            Assert.Throws<IOException>(() => unknown = owner.AppendJournalCore(intentSave.Position, HostJournalEvent.AuthorizeDispatch, authorized, new LostFlushIo()));
            Assert.Null(unknown); Assert.True(owner.JournalStatus.Faulted); Assert.False(Directory.Exists(Destination)); Assert.Equal(EpochAttemptState.Prepared, plan.State);
            Assert.Equal(2, owner.ReadJournalForReconciliation().Frames.Count); // Observed bytes are not a host append acknowledgment or execution permit.
            owner.Dispose(); await owner.WhenReleased;
            using var reopened = EmbeddedHostLifetime.OpenExisting(root, "pilot", "scope", [Artifact, Destination]);
            Assert.False(reopened.AdmissionsOpen); Assert.False(reopened.JournalStatus.CanAttemptAppend); return;
        }
        var authSave = owner.AppendJournal(intentSave.Position, HostJournalEvent.AuthorizeDispatch, authorized);
        Assert.Equal(HostJournalAppendDisposition.Acknowledged, authSave.Disposition);
        EpochPublishedReceipt receipt;
        using (owner.BeginOperation()) receipt = admin.ExecuteAttempt(plan);
        Assert.Equal(plan.Describe().AttemptId, receipt.OperationId); var before = Capture(Destination);
        var acknowledged = authorized with { Context = authorized.Context with { Revision = 3 }, Stage = HostLedgerStage.Acknowledged, Receipt = receipt };
        if (failure == "receipt")
        {
            HostJournalAppendResult? unknown = null;
            Assert.Throws<IOException>(() => unknown = owner.AppendJournalCore(authSave.Position, HostJournalEvent.Acknowledge, acknowledged, new LostFlushIo()));
            Assert.Null(unknown); Assert.True(owner.JournalStatus.Faulted);
        }
        else Assert.Equal(HostJournalAppendDisposition.Acknowledged, owner.AppendJournal(authSave.Position, HostJournalEvent.Acknowledge, acknowledged).Disposition);
        var history = owner.ReadJournalForReconciliation(); Assert.Equal(3, history.Frames.Count); Assert.Equal(receipt, history.Frames[^1].Snapshot.Receipt);
        Assert.True(history.WritersMustRemainStopped); Assert.Throws<InvalidOperationException>(() => admin.ExecuteAttempt(plan));
        Assert.Equal(EpochInspectionStatus.KnownOperationMatched, admin.InspectPublication(plan.Describe().ToInspectionRequest()).Status);
        var after = Capture(Destination); Assert.Equal(before.Keys.Order(), after.Keys.Order()); foreach (var pair in before) Assert.Equal(pair.Value, after[pair.Key]);
        owner.Dispose(); await owner.WhenReleased;
        using var observer = EmbeddedHostLifetime.OpenExisting(root, "pilot", "scope", [Artifact, Destination]);
        Assert.False(observer.AdmissionsOpen); Assert.False(observer.JournalStatus.CanAttemptAppend);
    }
    private sealed class LostFlushIo : IHostJournalAppendIo
    {
        /// <inheritdoc/>
        public void Write(FileStream stream, ReadOnlySpan<byte> bytes) => stream.Write(bytes);
        /// <inheritdoc/>
        public void Flush(FileStream stream) { stream.Flush(true); throw new IOException("Actual flush completed; result lost."); }
    }
    private static Dictionary<string, byte[]> Capture(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories).ToDictionary(path => path, File.ReadAllBytes);
    private void Seed(bool epoch, int count)
    {
        Directory.CreateDirectory(_area); var source = Path.Combine(_area, "source"); var legacy = epoch ? Path.Combine(_area, "legacy") : Artifact;
        using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, source);
        using (var owner = EmbeddedXmlDatabase.Open(source))
        { using var read = owner.BeginRead(); for (var index = 1; index <= count; index++) { using var tx = owner.BeginWrite(); tx.ReplaceNodeValue(Target(read), "new-" + index); tx.Commit(); } owner.CreateBackup(legacy); }
        if (!epoch) return;
        var result = EpochLegacyMigration.Convert(legacy, Path.Combine(_area, "initial"));
        using var candidate = ScalarEpochDatabase.Open(result.StorePath, new(DurabilityMode.ProcessCrash, ScalarEpochRecovery.FullHistory)); candidate.CreateBackup(Artifact);
    }
    private static ulong Target(ImmutableXmlSnapshot read) => Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();
    /// <summary>Deletes only the GUID-owned tree after all publication, observation and owner handles close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
