// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies epoch bootstrap crashes, cross-process admission and frozen-reader rejection.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Verifies epoch bootstrap crashes, cross-process admission and frozen-reader rejection.</summary>
public sealed class EpochProcessTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-epoch-process-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "epoch");

    /// <summary>Frozen format-1 binaries reject all public open paths without writing adoption artifacts.</summary>
    /// <param name="operation">Frozen public Open overload.</param>
    [Theory]
    [InlineData("raw")]
    [InlineData("coordinator")]
    [InlineData("durability")]
    [InlineData("recovery")]
    public async Task LegacyReader_FrozenFormat1Binary_RejectsMajor2BeforeMutation(string operation)
    {
        Create();
        var before = Bytes();
        var result = await Run("legacy-format", operation);
        Assert.Equal(23, result.Code);
        Assert.Contains("FROZEN-FORMAT1-REJECTED:" + operation, result.Output);
        Assert.Equal("", result.Error);
        Assert.False(Directory.Exists(Path.Combine(Root, ".transactions")));
        AssertBytes(before);
    }

    /// <summary>Bootstrap termination exposes either no final root or all verifiable identity files.</summary>
    /// <param name="stage">Publication stage or acknowledgment.</param>
    /// <param name="published">Whether a complete fixture has been published.</param>
    [Theory]
    [InlineData("FormatFlushed", false)]
    [InlineData("IdentityFlushed", false)]
    [InlineData("AdmissionFlushed", false)]
    [InlineData("Published", true)]
    [InlineData("ACK", true)]
    public async Task Bootstrap_ProcessKilled_ExposesOnlyCompleteMetadata(string stage, bool published)
    {
        Directory.CreateDirectory(_area);
        var result = await Run(stage == "ACK" ? "epoch-create-ack" : "epoch-create", stage);
        Assert.NotEqual(0, result.Code);
        Assert.Contains(stage == "ACK" ? "EPOCH-ACK" : "EPOCH-FAULT:" + stage, result.Output);
        Assert.Equal(published, Directory.Exists(Root));
        if (published)
        {
            for (var attempt = 0; attempt < 2; attempt++)
            {
                var identity = EpochAdmission.ReadIdentity(Root);
                using var token = EpochAdmission.Acquire(Root, identity, exclusive: true);
            }
        }
    }

    /// <summary>Independent shared children and exclusive admission block other processes until release or termination.</summary>
    /// <param name="exclusive">Whether the held admission is exclusive.</param>
    /// <param name="kill">Whether to terminate instead of disposing the holder.</param>
    [Theory]
    [InlineData(false, false)]
    [InlineData(false, true)]
    [InlineData(true, false)]
    [InlineData(true, true)]
    public async Task Admission_CrossProcess_RespectsLiveHandlesAndReleasesOnExit(bool exclusive, bool kill)
    {
        Create(); var before = Bytes();
        using var holder = Start(exclusive ? "epoch-hold-exclusive" : "epoch-hold-shared");
        try
        {
            Assert.Equal("ADMITTED", await holder.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(20)));
            var probe = await Run("epoch-try-exclusive");
            Assert.Equal(3, probe.Code); Assert.Contains("BLOCKED", probe.Output);
            var reader = await Run("epoch-try-shared");
            Assert.Equal(exclusive ? 3 : 0, reader.Code);
            if (kill) holder.Kill(true); else { await holder.StandardInput.WriteLineAsync(); await holder.StandardInput.FlushAsync(); }
            await holder.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(20));
            Assert.Equal(0, (await Run("epoch-try-exclusive")).Code);
            AssertBytes(before);
        }
        finally
        {
            if (!holder.HasExited) { holder.Kill(true); await holder.WaitForExitAsync(); }
        }
    }

    private void Create() { Directory.CreateDirectory(_area); EpochAdmission.CreateFixtureRoot(Root, 1, new LocalTransactionStorage()); }
    private Dictionary<string, byte[]> Bytes() => Directory.GetFiles(Root, "*", SearchOption.AllDirectories).ToDictionary(path => Path.GetRelativePath(Root, path), File.ReadAllBytes);
    private void AssertBytes(Dictionary<string, byte[]> before)
    {
        var after = Bytes(); Assert.Equal(before.Keys.Order(), after.Keys.Order());
        foreach (var pair in before) Assert.Equal(pair.Value, after[pair.Key]);
    }
    private Process Start(string action, string? argument = null)
    {
        var start = new ProcessStartInfo("dotnet") { RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false };
        start.ArgumentList.Add(typeof(EpochProcessTests).Assembly.Location); start.ArgumentList.Add(action); start.ArgumentList.Add(Root);
        if (argument is not null) start.ArgumentList.Add(argument);
        return Process.Start(start) ?? throw new InvalidOperationException("Cannot start epoch process probe.");
    }
    private async Task<(int Code, string Output, string Error)> Run(string action, string? argument = null)
    {
        using var process = Start(action, argument);
        var output = process.StandardOutput.ReadToEndAsync(); var error = process.StandardError.ReadToEndAsync();
        try { await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); }
        catch { if (!process.HasExited) process.Kill(true); throw; }
        return (process.ExitCode, await output, await error);
    }
    /// <inheritdoc />
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
