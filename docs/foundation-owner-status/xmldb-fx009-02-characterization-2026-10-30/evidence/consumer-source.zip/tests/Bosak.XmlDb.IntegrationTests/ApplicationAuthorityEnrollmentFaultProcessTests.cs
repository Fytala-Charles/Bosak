// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 30 October 2026
// PURPOSE              : Qualifies interrupted first enrollment, lost acknowledgment and competing processes.
// SPECIAL NOTES        : EF4 real process boundaries with ProcessCrash file I/O; no replay or work admission.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 30-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;
using Xunit.Abstractions;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Qualifies interrupted first enrollment, lost acknowledgment and competing processes.</summary>
/// <param name="output">Captures machine-readable qualification evidence.</param>
public sealed class ApplicationAuthorityEnrollmentFaultProcessTests(ITestOutputHelper output) : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ef4-process-" + Guid.NewGuid().ToString("N"));
    private static readonly Guid AuthorityId = Guid.Parse("10213243-5465-7687-98a9-bacbdcedfe0f");
    private static ApplicationAuthorityConfiguration Configuration(Guid admin) => new(AuthorityId, admin, "embedded-pilot", "orders", "admin", "authority");
    private static void Seed(string source, string host, Guid admin)
    {
        using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, source);
        using (var owner = EmbeddedXmlDatabase.Open(source))
        {
            using var read = owner.BeginRead(); var target = Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();
            using var tx = owner.BeginWrite(); tx.ReplaceNodeValue(target, "new-0"); tx.Commit(); using var final = owner.BeginRead();
        }
        Directory.CreateDirectory(host); File.WriteAllBytes(Path.Combine(host, "owner.lock"), []); File.WriteAllBytes(Path.Combine(host, "host.meta"), HostJournalCodec.EncodeMetadata(admin, "embedded-pilot", "orders")); File.WriteAllBytes(Path.Combine(host, "journal.bin"), []);
    }
    private static Process Start(string action, string host, string authority, string source, string capture, Guid admin, string point, bool closing)
    {
        var info = new ProcessStartInfo("dotnet") { RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false, CreateNoWindow = true };
        foreach (var arg in new[] { typeof(ApplicationAuthorityEnrollmentFaultProcessTests).Assembly.Location, action, host, authority, source, capture, AuthorityId.ToString(), admin.ToString(), point, closing.ToString() }) info.ArgumentList.Add(arg);
        return Process.Start(info) ?? throw new InvalidOperationException("Cannot start EF4 process.");
    }
    private static async Task<string?> Line(Process process) => await process.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(45));
    private static async Task Send(Process process, string line) { await process.StandardInput.WriteLineAsync(line); await process.StandardInput.FlushAsync(); }
    private static async Task Stop(Process process) { if (!process.HasExited) { process.Kill(true); await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); } }
    private static Dictionary<string, byte[]> Bytes(params string[] roots) => roots.SelectMany(r => Directory.GetFiles(r, "*", SearchOption.AllDirectories)).ToDictionary(p => p, File.ReadAllBytes);
    private static void AssertBytes(Dictionary<string, byte[]> expected, params string[] roots)
    { var after = Bytes(roots); Assert.Equal(expected.Keys.Order(), after.Keys.Order()); foreach (var pair in expected) Assert.Equal(pair.Value, after[pair.Key]); }
    private static string[] Inventory(params string[] roots) => roots.SelectMany(r => Directory.GetFileSystemEntries(r, "*", SearchOption.AllDirectories)).Order().ToArray();
    /// <summary>Repeated actual process kills preserve exact empty, partial or complete bytes without executable replay.</summary>
    /// <param name="point">Actual process pause boundary.</param>
    /// <param name="closing">Whether all caller wrappers close immediately after arm.</param>
    /// <returns>A task that checks two independent killed publisher attempts and read-only restarts.</returns>
    [Theory]
    [InlineData("BeforeArm", false)]
    [InlineData("Armed", false)]
    [InlineData("Validated", false)]
    [InlineData("BeforeWrite", false)]
    [InlineData("IoWriteBefore", false)]
    [InlineData("IoWriteAfter", false)]
    [InlineData("Written", false)]
    [InlineData("IoFlushBefore", false)]
    [InlineData("IoFlushAfter", false)]
    [InlineData("Flushed", false)]
    [InlineData("IoReadBefore", false)]
    [InlineData("IoReadAfter", false)]
    [InlineData("BeforeAcknowledge", false)]
    [InlineData("BeforeRelease", false)]
    [InlineData("Partial", false)]
    [InlineData("Returned", false)]
    [InlineData("ACK", false)]
    [InlineData("Written", true)]
    [InlineData("BeforeRelease", true)]
    [InlineData("Returned", true)]
    [InlineData("ACK", true)]
    public async Task Append_ProcessDeath_ExactBytesRemainStopped(string point, bool closing)
    {
        for (var repeat = 0; repeat < 2; repeat++)
        {
            var area = Path.Combine(_area, repeat.ToString(System.Globalization.CultureInfo.InvariantCulture)); var source = Path.Combine(area, "source"); var host = Path.Combine(area, "host"); var authority = Path.Combine(area, "authority"); var capture = Path.Combine(area, "capture"); var admin = Guid.NewGuid(); Seed(source, host, admin); var original = Bytes(source, host); var originalInventory = Inventory(source, host);
            using var child = Start("ef4-publish", host, authority, source, capture, admin, point, closing); var errors = child.StandardError.ReadToEndAsync();
            try
            {
                var announced = await Line(child); Assert.NotNull(announced); Assert.StartsWith("PLAN:", announced); var frame = Convert.FromHexString(announced[5..]);
                if (point == "ACK") Assert.Equal("ACK:" + Convert.ToHexString(frame), await Line(child));
                Assert.Equal("AT:" + point, await Line(child));
                var released = closing && point is "Returned" or "ACK";
                foreach (var path in new[] { Path.Combine(source, ".transactions", "writer.lock"), Path.Combine(host, "owner.lock"), Path.Combine(authority, "authority.lock") })
                {
                    if (released) { using var available = new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None); }
                    else Assert.Throws<IOException>(() => { using var blocked = new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None); });
                }
                var sealedBytes = Bytes(capture); var sealedInventory = Inventory(capture);
                await Stop(child); _ = await errors; AssertBytes(original, source, host); Assert.Equal(originalInventory, Inventory(source, host)); AssertBytes(sealedBytes, capture); Assert.Equal(sealedInventory, Inventory(capture));
                var beforeWrite = point is "BeforeArm" or "Armed" or "Validated" or "BeforeWrite" or "IoWriteBefore";
                var expected = beforeWrite ? [] : point == "Partial" ? frame[..17] : frame; var actual = File.ReadAllBytes(Path.Combine(authority, "authority.log")); Assert.Equal(expected, actual);
                var retained = Bytes(authority); var retainedInventory = Inventory(authority); Assert.Equal(3, Directory.GetFiles(authority).Length); Assert.Equal(ApplicationAuthorityCodec.EncodeMetadata(Configuration(admin)), File.ReadAllBytes(Path.Combine(authority, "authority.meta")));
                for (var restart = 0; restart < 2; restart++)
                {
                    using var parent = EmbeddedHostLifetime.OpenExisting(host, "embedded-pilot", "orders", [source, capture, authority]); var mappings = new Dictionary<string, string> { ["admin"] = host, ["authority"] = authority, ["source"] = source, ["capture"] = capture };
                    if (point == "Partial") Assert.Throws<InvalidDataException>(() => ApplicationAuthorityLifetime.OpenExisting(parent, parent.JournalStatus.KnownPosition, new(parent.Context, true, true, true, true, true), authority, Configuration(admin), mappings));
                    else
                    {
                        using var observed = ApplicationAuthorityLifetime.OpenExisting(parent, parent.JournalStatus.KnownPosition, new(parent.Context, true, true, true, true, true), authority, Configuration(admin), mappings);
                        Assert.Equal(beforeWrite ? 0 : 1, observed.Inspect().Frames.Length); Assert.Null(observed.ConfirmedEnrollment); Assert.True(observed.WritersMustRemainStopped); Assert.Throws<InvalidOperationException>(() => observed.ReserveInitializer());
                    }
                }
                AssertBytes(retained, authority); Assert.Equal(retainedInventory, Inventory(authority)); AssertBytes(original, source, host); AssertBytes(sealedBytes, capture);
                using var reopenedSource = EmbeddedXmlDatabase.Open(source); using var snapshot = reopenedSource.BeginRead(); Assert.Equal("new-0", snapshot.ReadValue(Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single()));
            }
            finally { await Stop(child); _ = await errors; }
        }
        output.WriteLine("EF4_PROCESS " + point + " closing=" + closing + " attempts=2 actualPolicy=ProcessCrash");
    }
    /// <summary>Two independent simultaneous publishers cannot share the original source or create two enrollments.</summary>
    /// <returns>A task that checks three independent two-process ownership races.</returns>
    [Fact]
    public async Task Append_IndependentPublishers_OneOwnerAndOneExactFrame()
    {
        for (var repeat = 0; repeat < 3; repeat++)
        {
            var area = Path.Combine(_area, repeat.ToString(System.Globalization.CultureInfo.InvariantCulture)); var source = Path.Combine(area, "source"); var host = Path.Combine(area, "host"); var authority = Path.Combine(area, "authority"); var capture = Path.Combine(area, "capture"); var admin = Guid.NewGuid(); Seed(source, host, admin); var original = Bytes(source, host);
            using var first = Start("ef4-race", host, authority, source, capture, admin, "Race", false); using var second = Start("ef4-race", host, authority, source, capture, admin, "Race", false); var firstErrors = first.StandardError.ReadToEndAsync(); var secondErrors = second.StandardError.ReadToEndAsync();
            try
            {
                Assert.Equal("READY", await Line(first)); Assert.Equal("READY", await Line(second)); await Task.WhenAll(Send(first, "go"), Send(second, "go"));
                var outcomes = await Task.WhenAll(Line(first), Line(second)); Assert.Single(outcomes, o => o == "LOST"); var winning = Assert.Single(outcomes, o => o?.StartsWith("WON:", StringComparison.Ordinal) == true); Assert.NotNull(winning); var bytes = Convert.FromHexString(winning[4..]); var winner = outcomes[0] == "LOST" ? second : first; var loser = ReferenceEquals(winner, first) ? second : first;
                await loser.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); Assert.Equal(0, loser.ExitCode); Assert.Throws<IOException>(() => { using var blocked = EmbeddedXmlDatabase.Open(source); });
                await Send(winner, "release"); await winner.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); Assert.Equal(0, winner.ExitCode);
                Assert.Equal(bytes, File.ReadAllBytes(Path.Combine(authority, "authority.log"))); AssertBytes(original, source, host);
                using var parent = EmbeddedHostLifetime.OpenExisting(host, "embedded-pilot", "orders", [source, capture, authority]); using var observed = ApplicationAuthorityLifetime.OpenExisting(parent, parent.JournalStatus.KnownPosition, new(parent.Context, true, true, true, true, true), authority, Configuration(admin), new Dictionary<string, string> { ["admin"] = host, ["authority"] = authority, ["source"] = source, ["capture"] = capture }); Assert.Single(observed.Inspect().Frames); Assert.Null(observed.ConfirmedEnrollment); Assert.Throws<InvalidOperationException>(() => observed.ReserveInitializer());
            }
            finally { await Stop(first); await Stop(second); _ = await firstErrors; _ = await secondErrors; }
        }
        output.WriteLine("EF4_RACE repetitions=3 processes=6 singleOwner=true");
    }
    /// <summary>Deletes only the fresh owned GUID tree after all independent processes exit.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
