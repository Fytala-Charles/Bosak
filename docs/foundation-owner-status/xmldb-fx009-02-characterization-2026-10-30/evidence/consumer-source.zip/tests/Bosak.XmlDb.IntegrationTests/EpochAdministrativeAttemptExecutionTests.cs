// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Verifies planned publication identity, pinned input, consumed state and uncertain outcomes.
// SPECIAL NOTES        : Local baseline compatibility only; no archived release or actual routing claim.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Text;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Qualifies explicit planned migration/restore while retaining unplanned behavior and frozen formats.</summary>
public sealed class EpochAdministrativeAttemptExecutionTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-rc2-" + Guid.NewGuid().ToString("N"));
    private string Artifact => Path.Combine(_area, "artifact");
    private string Destination => Path.Combine(_area, "destination");
    private static EpochPublicationKind Kind(bool epoch) => epoch ? EpochPublicationKind.IndependentEpochRestore : EpochPublicationKind.LegacyMigration;
    private static ScalarEpochAdministration Admin() => ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash));

    /// <summary>Both roles publish every retained sequence with the caller's preknown attempt ID and fresh destination epoch.</summary>
    /// <param name="epoch">Restore instead of migrate.</param>
    /// <param name="count">Initial head.</param>
    [Theory]
    [InlineData(false, 0)]
    [InlineData(false, 3)]
    [InlineData(true, 0)]
    [InlineData(true, 3)]
    public void Execute_ValidPlan_PublishesExactKnownIdAndHistory(bool epoch, int count)
    {
        Seed(epoch, count); var admin = Admin(); var plan = admin.PrepareAttempt(Kind(epoch), Artifact, Destination); var intent = plan.Describe(); var before = Inputs();
        var result = admin.ExecuteAttempt(plan);
        Assert.Equal(intent.AttemptId, result.OperationId); Assert.Equal(intent.BackupId, result.BackupId); Assert.Equal(intent.Kind, result.Kind);
        Assert.Equal(intent.SourceEpoch, result.SourceEpoch); Assert.NotEqual(intent.SourceEpoch, result.DestinationEpoch); Assert.Equal((ulong)count, result.CommitSequence);
        Assert.Equal(Path.Combine(Destination, "store"), result.StorePath); Assert.Equal(EpochAttemptState.Dispatched, plan.State);
        Assert.Equal(EpochInspectionStatus.KnownOperationMatched, admin.InspectPublication(intent.ToInspectionRequest()).Status);
        ReadAll(result, count); AssertInputs(before);
        var published = CaptureTree(Destination); Assert.Throws<InvalidOperationException>(() => admin.ExecuteAttempt(plan)); AssertTree(published, Destination);
    }

    /// <summary>Null/foreign/preclaimed plans cannot enter a pipeline or consume another owner's prepared plan.</summary>
    /// <param name="fault">Preclaim failure.</param>
    [Theory]
    [InlineData("null")]
    [InlineData("foreign")]
    [InlineData("preclaimed")]
    public void Execute_InvalidClaim_RejectsBeforeFilesystemEffects(string fault)
    {
        Seed(false, 0); var storage = new TrackingStorage(Destination) { RejectAnyCall = true }; var admin = ScalarEpochAdministration.CreateCore(new(DurabilityMode.ProcessCrash), storage);
        var plan = admin.PrepareAttempt(Kind(false), Artifact, Destination); var before = CaptureTree(_area);
        if (fault == "null") Assert.Throws<ArgumentNullException>(() => admin.ExecuteAttempt(null!));
        else if (fault == "foreign") { Assert.Throws<ArgumentException>(() => Admin().ExecuteAttempt(plan)); Assert.Equal(EpochAttemptState.Prepared, plan.State); }
        else { admin.ClaimAttempt(plan); Assert.Throws<InvalidOperationException>(() => admin.ExecuteAttempt(plan)); }
        Assert.Equal(0, storage.Calls); AssertTree(before, _area);
    }

    /// <summary>Resealed changed input, existing output and missing input fail after consuming the plan but before output/barrier calls.</summary>
    /// <param name="epoch">Publication role.</param>
    /// <param name="fault">Changed mutable execution precondition.</param>
    [Theory]
    [InlineData(false, "inventory")]
    [InlineData(false, "target")]
    [InlineData(false, "missing-input")]
    [InlineData(true, "inventory")]
    [InlineData(true, "target")]
    [InlineData(true, "missing-input")]
    public void Execute_ChangedIntent_ConsumesWithoutOutput(bool epoch, string fault)
    {
        Seed(epoch, 1); var storage = new TrackingStorage(Destination) { RejectAnyCall = true }; var admin = ScalarEpochAdministration.CreateCore(new(DurabilityMode.ProcessCrash), storage);
        var plan = admin.PrepareAttempt(Kind(epoch), Artifact, Destination);
        if (fault == "inventory") ResealBackupId(epoch);
        else if (fault == "target") { Directory.CreateDirectory(Destination); File.WriteAllText(Path.Combine(Destination, "sentinel"), "retain"); }
        else Directory.Delete(Artifact, true);
        var before = CaptureTree(_area); var error = Record.Exception(() => admin.ExecuteAttempt(plan));
        Assert.True(error is InvalidDataException or IOException, error?.ToString() ?? "Unexpected acceptance.");
        Assert.Equal(EpochAttemptState.Dispatched, plan.State); Assert.Throws<InvalidOperationException>(() => admin.ExecuteAttempt(plan));
        Assert.Equal(0, storage.Calls); AssertTree(before, _area);
    }

    /// <summary>Before/after-publication and cleanup failures leave a consumed attempt and never fabricate an acknowledgment or automatic retry.</summary>
    /// <param name="epoch">Publication role.</param>
    /// <param name="fault">Injected pipeline callback or actual namespace/cleanup failure.</param>
    [Theory]
    [InlineData(false, "proof")]
    [InlineData(false, "ready")]
    [InlineData(false, "published")]
    [InlineData(false, "move-after")]
    [InlineData(false, "cleanup-after")]
    [InlineData(true, "proof")]
    [InlineData(true, "ready")]
    [InlineData(true, "published")]
    [InlineData(true, "move-after")]
    [InlineData(true, "cleanup-after")]
    public void Execute_UnacknowledgedFailure_RequiresObservationAndFreshAttempt(bool epoch, string fault)
    {
        Seed(epoch, 1); var storage = new TrackingStorage(Destination) { Fault = fault }; var stages = new List<EpochAdministrativeStage>();
        var admin = ScalarEpochAdministration.CreateCore(new(DurabilityMode.ProcessCrash), storage, stage =>
        {
            stages.Add(stage);
            if (fault == "proof" && stage == EpochAdministrativeStage.ProofVerified || fault == "ready" && stage == EpochAdministrativeStage.ReadyToPublish || fault == "published" && stage == EpochAdministrativeStage.Published)
                throw new IOException("injected-unknown");
        });
        var plan = admin.PrepareAttempt(Kind(epoch), Artifact, Destination); var intent = plan.Describe(); var before = Inputs(); EpochPublishedReceipt? receipt = null;
        Assert.Throws<IOException>(() => receipt = admin.ExecuteAttempt(plan)); Assert.Null(receipt); Assert.Equal(EpochAttemptState.Dispatched, plan.State); AssertInputs(before);
        var calls = storage.Calls; Assert.Throws<InvalidOperationException>(() => admin.ExecuteAttempt(plan)); Assert.Equal(calls, storage.Calls);
        var observed = admin.InspectPublication(intent.ToInspectionRequest()); Assert.True(observed.WritersMustRemainStopped);
        if (fault is "published" or "move-after" or "cleanup-after")
        {
            Assert.Equal(EpochInspectionStatus.KnownOperationMatched, observed.Status); Assert.Equal(intent.AttemptId, observed.Observed!.OperationId);
            var published = CaptureTree(Destination); Assert.Throws<IOException>(() => Admin().PrepareAttempt(Kind(epoch), Artifact, Destination)); AssertTree(published, Destination);
            if (fault == "move-after") Assert.DoesNotContain(EpochAdministrativeStage.Published, stages);
        }
        else
        {
            Assert.Equal(EpochInspectionStatus.NotObserved, observed.Status);
            // The old synchronous executor returned and no target was observed. This local test
            // explicitly prepares a new attempt; absence alone is not a general retry permit.
            var next = Admin(); var retry = next.PrepareAttempt(Kind(epoch), Artifact, Destination); Assert.NotEqual(intent.AttemptId, retry.Describe().AttemptId);
            var acknowledged = next.ExecuteAttempt(retry); Assert.Equal(retry.Describe().AttemptId, acknowledged.OperationId); ReadAll(acknowledged, 1);
        }
        AssertInputs(before);
    }

    /// <summary>Changing sealed inventory after source proof prevents planned publication even if its replacement remains independently well-sealed.</summary>
    /// <param name="epoch">Publication role.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Execute_InputChangedAfterProof_RejectsWithoutCandidate(bool epoch)
    {
        Seed(epoch, 1); var changed = false;
        var admin = ScalarEpochAdministration.CreateCore(new(DurabilityMode.ProcessCrash), new LocalTransactionStorage(), stage =>
        { if (stage == EpochAdministrativeStage.ProofVerified) { ResealBackupId(epoch); changed = true; } });
        var plan = admin.PrepareAttempt(Kind(epoch), Artifact, Destination);
        Assert.Throws<InvalidDataException>(() => admin.ExecuteAttempt(plan)); Assert.True(changed); Assert.Equal(EpochAttemptState.Dispatched, plan.State);
        Assert.False(Directory.Exists(Destination)); Assert.Throws<InvalidOperationException>(() => admin.ExecuteAttempt(plan));
    }

    /// <summary>The one-entry pipeline context rejects role/path/policy repurposing and cannot be reused even after a pure preflight rejection.</summary>
    /// <param name="fault">Wrong pipeline binding.</param>
    [Theory]
    [InlineData("role")]
    [InlineData("path")]
    [InlineData("policy")]
    public void PipelineContext_CannotBeRepurposedOrReplayed(string fault)
    {
        Seed(false, 0); var owner = new object(); var storage = new TrackingStorage(Destination) { RejectAnyCall = true };
        var plan = EpochAdministrativeAttemptPlan.Prepare(owner, Kind(false), Artifact, Destination, DurabilityMode.ProcessCrash);
        var context = EpochAttemptExecution.Claim(plan, owner, DurabilityMode.ProcessCrash); var before = CaptureTree(_area);
        if (fault == "role") Assert.Throws<ArgumentException>(() => EpochBackupRestore.Restore(Artifact, Destination, storage, execution: context));
        else if (fault == "path") Assert.Throws<ArgumentException>(() => EpochLegacyMigration.Convert(Artifact, Path.Combine(_area, "different"), storage, execution: context));
        else { storage.RequestedPolicy = DurabilityMode.FileAndDirectoryFlush; Assert.Throws<ArgumentException>(() => EpochLegacyMigration.Convert(Artifact, Destination, storage, execution: context)); storage.RequestedPolicy = DurabilityMode.ProcessCrash; }
        Assert.Throws<InvalidOperationException>(() => EpochLegacyMigration.Convert(Artifact, Destination, storage, execution: context)); Assert.Equal(0, storage.Calls); AssertTree(before, _area);
    }

    /// <summary>Expected legacy inventory pin is checked by the private verifier before it can create output or issue barriers.</summary>
    [Fact]
    public void LegacyVerifier_PinnedInventoryMismatch_RejectsBeforeOutput()
    {
        Seed(false, 0); var storage = new TrackingStorage(Destination) { RejectAnyCall = true }; var before = CaptureTree(_area);
        Assert.Throws<InvalidDataException>(() => LegacyMigrationVerifier.Verify(Artifact, Destination, storage, expectedInventorySha256: new string('0', 64)));
        Assert.Equal(0, storage.Calls); AssertTree(before, _area);
    }

    /// <summary>Native planned execution is exercised on Linux; Windows proves explicit unsupported-policy rejection only.</summary>
    /// <param name="epoch">Publication role.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Execute_NativePolicy_HasNoFallback(bool epoch)
    {
        if (!OperatingSystem.IsLinux()) { Assert.Throws<PlatformNotSupportedException>(() => ScalarEpochAdministration.Create(new(DurabilityMode.FileAndDirectoryFlush))); return; }
        Seed(epoch, 1); var admin = ScalarEpochAdministration.Create(new(DurabilityMode.FileAndDirectoryFlush)); var plan = admin.PrepareAttempt(Kind(epoch), Artifact, Destination);
        var result = admin.ExecuteAttempt(plan); Assert.Equal(plan.Describe().AttemptId, result.OperationId); ReadAll(result, 1);
    }

    private void ResealBackupId(bool epoch)
    {
        byte[] encoded;
        if (epoch) { var value = EpochBackupStorage.ReadArtifact(Artifact); encoded = EpochBackupCodec.EncodeInventory(value with { BackupId = Guid.NewGuid() }); }
        else { var value = LegacyMigrationVerifier.ReadArtifact(Artifact); encoded = BackupCodec.Encode(value with { Identity = value.Identity with { BackupId = Guid.NewGuid() } }); }
        File.WriteAllBytes(Path.Combine(Artifact, "inventory.bin"), encoded); File.WriteAllBytes(Path.Combine(Artifact, "COMPLETE"), epoch ? EpochBackupCodec.Complete(encoded) : BackupCodec.Complete(encoded));
    }
    private void Seed(bool epoch, int count)
    {
        Directory.CreateDirectory(_area); var source = Path.Combine(_area, "source"); var legacy = epoch ? Path.Combine(_area, "legacy") : Artifact;
        using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, source);
        using (var owner = EmbeddedXmlDatabase.Open(source))
        { using var read = owner.BeginRead(); for (var index = 1; index <= count; index++) { using var tx = owner.BeginWrite(); tx.ReplaceNodeValue(Target(read), "new-" + index); tx.Commit(); } owner.CreateBackup(legacy); }
        if (!epoch) return;
        var result = EpochLegacyMigration.Convert(legacy, Path.Combine(_area, "initial"));
        using var candidate = ScalarEpochDatabase.Open(result.StorePath, new(DurabilityMode.ProcessCrash, ScalarEpochRecovery.FullHistory)); candidate.CreateBackup(Artifact);
    }
    private static void ReadAll(EpochPublishedReceipt result, int count)
    {
        using var admission = EpochAdmission.Acquire(result.StorePath, result.DestinationEpoch, profile: EpochProfile.ScalarWal);
        var binding = EpochEmptyCoordinator.ReadAuthority(result.StorePath, result.DestinationEpoch, true);
        for (ulong sequence = 0; sequence <= (ulong)count; sequence++)
        {
            var hash = sequence == 0 ? binding.BaseHash : EpochAuthorityCodec.DecodeWal(File.ReadAllBytes(Path.Combine(result.StorePath, ".transactions", "wal", EpochAuthorityCodec.WalFileName(sequence))), binding).ManifestHash;
            using var read = EpochScalarHistory.Open(result.StorePath, sequence, admission, hash); Assert.Equal(sequence == 0 ? "old" : "new-" + sequence, read.ReadValue(Target(read)));
        }
    }
    private static ulong Target(ImmutableXmlSnapshot read) => Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id)).Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();
    private sealed record Tree(string[] Directories, Dictionary<string, byte[]> Files);
    private static Tree CaptureTree(string root) => new(Directory.GetDirectories(root, "*", SearchOption.AllDirectories).Order().ToArray(), Directory.GetFiles(root, "*", SearchOption.AllDirectories).ToDictionary(path => path, File.ReadAllBytes));
    private static void AssertTree(Tree before, string root) { var after = CaptureTree(root); Assert.Equal(before.Directories, after.Directories); Assert.Equal(before.Files.Keys.Order(), after.Files.Keys.Order()); foreach (var pair in before.Files) Assert.Equal(pair.Value, after.Files[pair.Key]); }
    private Dictionary<string, Tree> Inputs() => Directory.GetDirectories(_area).Where(path => path != Destination && !Path.GetFileName(path).StartsWith(".xmldb-", StringComparison.Ordinal)).ToDictionary(path => path, CaptureTree);
    private static void AssertInputs(Dictionary<string, Tree> before) { foreach (var pair in before) AssertTree(pair.Value, pair.Key); }
    private sealed class TrackingStorage(string destination) : ITransactionStorage
    {
        private readonly LocalTransactionStorage _inner = new(); private int _calls; private bool _published;
        internal int Calls => Volatile.Read(ref _calls);
        internal bool RejectAnyCall { get; init; }
        internal string? Fault { get; init; }
        internal DurabilityMode RequestedPolicy { get; set; } = DurabilityMode.ProcessCrash;
        public DurabilityMode Durability => RequestedPolicy;
        private void Hit() { Interlocked.Increment(ref _calls); if (RejectAnyCall) throw new InvalidOperationException("Unexpected storage mutation/barrier."); }
        public ITransactionFile CreateFile(string path) { Hit(); return _inner.CreateFile(path); }
        public void CreateDirectory(string path) { Hit(); _inner.CreateDirectory(path); }
        public void MoveFile(string source, string target, bool overwrite) { Hit(); _inner.MoveFile(source, target, overwrite); }
        public void MoveDirectory(string source, string target) { Hit(); _inner.MoveDirectory(source, target); if (target == destination) { _published = true; if (Fault == "move-after") throw new IOException("move-applied-unacknowledged"); } }
        public void DeleteFile(string path) { Hit(); _inner.DeleteFile(path); }
        public void DeleteDirectory(string path) { Hit(); _inner.DeleteDirectory(path); if (_published && Fault == "cleanup-after" && Path.GetFileName(path).StartsWith(".xmldb-epoch-backup-", StringComparison.Ordinal)) throw new IOException("cleanup-applied-unacknowledged"); }
        public void SyncDirectory(string path) { Hit(); _inner.SyncDirectory(path); }
        public void SyncFile(string path) { Hit(); _inner.SyncFile(path); }
    }
    /// <summary>Deletes only this test's GUID-owned data after every execution, observer and proof handle closes.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
