// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies backup and restore publication under real process termination.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Verifies backup and restore publication under real process termination.</summary>
public sealed class BackupProcessTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-backup-process-" + Guid.NewGuid().ToString("N"));
    private string _root => Path.Combine(_area, "source");

    /// <summary>Only completely published backups/restores survive a killed publisher as routable destinations.</summary>
    /// <param name="action">Probe action.</param>
    /// <param name="stage">Publication boundary.</param>
    /// <param name="published">Whether the final destination should exist.</param>
    [Theory]
    [InlineData("backup", "BackupCopied", false)]
    [InlineData("backup", "BackupVerificationOpened", false)]
    [InlineData("backup", "BackupVerified", false)]
    [InlineData("backup", "BackupInventoryFlushed", false)]
    [InlineData("backup", "BackupCompleted", false)]
    [InlineData("backup", "BackupPublished", true)]
    [InlineData("restore", "RestoreCopied", false)]
    [InlineData("restore", "RestoreVerificationOpened", false)]
    [InlineData("restore", "RestoreVerified", false)]
    [InlineData("restore", "RestorePublished", true)]
    [InlineData("ack-backup", "ACK", true)]
    [InlineData("ack-restore", "ACK", true)]
    public async Task Publication_KilledBeforeOrAfterAcknowledgment_PreservesExactHistory(string action, string stage, bool published)
    {
        Directory.CreateDirectory(_area);
        Seed();
        using (var source = EmbeddedXmlDatabase.Open(_root))
        {
            Commit(source, "SO-2");
            if (action.Contains("restore", StringComparison.Ordinal)) source.CreateBackup(_root + "-backup");
        }
        var crash = await Run(action, stage);
        Assert.NotEqual(0, crash.Code);
        Assert.Contains(stage == "ACK" ? "BACKUP-ACK:1" : "FAULT:" + stage, crash.Output);
        var destination = _root + (action.Contains("restore", StringComparison.Ordinal) ? "-restored" : "-backup");
        Assert.Equal(published, Directory.Exists(destination));
        if (published)
        {
            var restored = action.Contains("restore", StringComparison.Ordinal) ? destination : _root + "-verified";
            if (!action.Contains("restore", StringComparison.Ordinal)) EmbeddedXmlDatabase.RestoreBackup(destination, restored);
            for (var attempt = 0; attempt < 2; attempt++)
            {
                using var owner = EmbeddedXmlDatabase.Open(restored);
                Assert.Equal(1UL, owner.CommitSequence);
                using var read = owner.BeginRead();
                var target = Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id))
                    .Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();
                Assert.Equal("SO-2", read.ReadValue(target));
            }
        }
        using var original = EmbeddedXmlDatabase.Open(_root);
        Assert.Equal(1UL, original.CommitSequence);
    }

    private void Seed()
    {
        using var input = new MemoryStream(Encoding.UTF8.GetBytes("<SalesOrder><SalesOrderHeader><DocumentID>SO-1</DocumentID></SalesOrderHeader><SalesOrderLine>line</SalesOrderLine></SalesOrder>"));
        XmlFragmentImporter.Import(input, _root);
    }

    private static void Commit(EmbeddedXmlDatabase database, string value)
    {
        using var read = database.BeginRead();
        var target = Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id))
            .Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();
        using var transaction = database.BeginWrite();
        transaction.ReplaceNodeValue(target, value);
        transaction.Commit();
    }

    private Process Start(string action, string? argument = null)
    {
        var start = new ProcessStartInfo("dotnet")
        {
            RedirectStandardInput = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
        };
        start.ArgumentList.Add(typeof(BackupProcessTests).Assembly.Location);
        start.ArgumentList.Add(action);
        start.ArgumentList.Add(_root);
        if (argument is not null) start.ArgumentList.Add(argument);
        return Process.Start(start) ?? throw new InvalidOperationException("Cannot start checkpoint process probe.");
    }

    private async Task<(int Code, string Output, string Error)> Run(string action, string? argument = null)
    {
        using var process = Start(action, argument);
        var output = process.StandardOutput.ReadToEndAsync();
        var error = process.StandardError.ReadToEndAsync();
        try { await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); }
        catch { if (!process.HasExited) process.Kill(true); throw; }
        return (process.ExitCode, await output, await error);
    }

    /// <inheritdoc />
    public void Dispose()
    {
        // All operation workspaces and sibling artifacts live below this fixture's private area.
        if (Directory.Exists(_area)) Directory.Delete(_area, true);
    }
}
