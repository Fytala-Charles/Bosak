// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Exercises administrative verification, publication outcomes and sealed input preservation.
// SPECIAL NOTES        : Local baseline compatibility only; no archived release or actual routing claim.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Security.Cryptography;
using System.Text;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Exercises separate internal administrative contracts without real routing or public exposure.</summary>
public sealed class ScalarEpochAdministrationTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-pa2-" + Guid.NewGuid().ToString("N"));
    private string Source => Path.Combine(_area, "source");
    private string Legacy => Path.Combine(_area, "legacy-backup");
    private string Epoch => Path.Combine(_area, "epoch-backup");
    private static EpochAdministrativeOptions Options => new(DurabilityMode.ProcessCrash);
    private static ScalarEpochAdministration Admin() => ScalarEpochAdministration.Create(Options);

    /// <summary>Both full-history proof oracles return bound receipts and remove only their fresh private workspace.</summary>
    /// <param name="epoch">Artifact profile.</param>
    /// <param name="count">History length.</param>
    [Theory]
    [InlineData(false, 0)]
    [InlineData(false, 3)]
    [InlineData(true, 0)]
    [InlineData(true, 3)]
    public void Verify_CompleteAndRedo_ReturnsBoundReceiptWithoutPublication(bool epoch, int count)
    {
        var original = Seed(count); var before = CaptureInputs(); var hint = Path.Combine(_area, "verify-hint");
        var old = Path.Combine(_area, ".xmldb-epoch-backup-" + Guid.NewGuid().ToString("N")); Directory.CreateDirectory(old); File.WriteAllText(Path.Combine(old, "sentinel"), "retained");
        var stages = new List<EpochAdministrativeStage>();
        var admin = ScalarEpochAdministration.CreateCore(Options, new LocalTransactionStorage(), stages.Add);
        var result = epoch ? admin.VerifyEpochBackup(Epoch, hint) : admin.VerifyLegacyBackup(Legacy, hint);
        Assert.Equal(new[] { EpochAdministrativeStage.PreflightVerified, EpochAdministrativeStage.ProofVerified }, stages);
        Assert.Equal(epoch ? EpochArtifactProfile.ScalarEpochFullHistory : EpochArtifactProfile.LegacyFullHistory, result.Profile);
        Assert.Equal((ulong)count, result.CommitSequence); Assert.Equal(1UL, result.DocumentId); Assert.NotEqual(Guid.Empty, result.BackupId);
        Assert.Equal(epoch ? original.Destination : null, result.SourceEpoch);
        Assert.Equal(Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(Path.Combine(epoch ? Epoch : Legacy, "inventory.bin")))).ToLowerInvariant(), result.InventorySha256);
        Assert.False(Directory.Exists(hint)); Assert.Equal(new[] { old }, Directory.GetDirectories(_area, ".xmldb-epoch-backup-*"));
        Assert.Equal("retained", File.ReadAllText(Path.Combine(old, "sentinel"))); AssertInputs(before);
        Assert.False(typeof(ScalarEpochAdministration).IsVisible); Assert.False(typeof(EpochPublishedReceipt).IsVisible);
    }

    /// <summary>Separate-root publication preserves every sequence and returns only the actual published store path.</summary>
    /// <param name="restore">Restore an epoch instead of migrating legacy.</param>
    /// <param name="count">History length.</param>
    [Theory]
    [InlineData(false, 0)]
    [InlineData(false, 3)]
    [InlineData(true, 0)]
    [InlineData(true, 3)]
    public void Publish_ValidHistory_ReturnsAcknowledgedIndependentCandidate(bool restore, int count)
    {
        var original = Seed(count); var before = CaptureInputs(); var destination = Path.Combine(_area, "published");
        using var oldOwner = ScalarEpochDatabase.Open(original.StorePath, new(DurabilityMode.ProcessCrash, ScalarEpochRecovery.FullHistory));
        using var oldRead = oldOwner.BeginRead(0); oldOwner.Dispose();
        var result = Publish(Admin(), restore, destination);
        Assert.Equal(restore ? EpochPublicationKind.IndependentEpochRestore : EpochPublicationKind.LegacyMigration, result.Kind);
        Assert.Equal(restore ? original.Destination : null, result.SourceEpoch); Assert.NotEqual(original.Destination, result.DestinationEpoch);
        Assert.NotEqual(Guid.Empty, result.OperationId); Assert.Equal(Path.Combine(destination, "store"), result.StorePath); Assert.Equal((ulong)count, result.CommitSequence);
        Assert.Equal(count == 0 ? "old" : "new-3", oldRead.ReadValue(Target(oldRead)));
        ReadAll(result, count); AssertInputs(before);
        var published = CaptureTree(destination);
        Assert.Throws<IOException>(() => Publish(Admin(), restore, destination)); AssertTree(published, destination);
    }

    /// <summary>Errors before and after namespace publication never turn into a false no-publication receipt or automatic retry.</summary>
    /// <param name="restore">Publication role.</param>
    /// <param name="stage">Injected administrative boundary.</param>
    [Theory]
    [InlineData(false, (int)EpochAdministrativeStage.ProofVerified)]
    [InlineData(false, (int)EpochAdministrativeStage.ReadyToPublish)]
    [InlineData(false, (int)EpochAdministrativeStage.Published)]
    [InlineData(true, (int)EpochAdministrativeStage.ProofVerified)]
    [InlineData(true, (int)EpochAdministrativeStage.ReadyToPublish)]
    [InlineData(true, (int)EpochAdministrativeStage.Published)]
    public void Publish_UnacknowledgedFailure_PreservesObservedOutcomeAndInputs(bool restore, int stage)
    {
        Seed(1); var before = CaptureInputs(); var destination = Path.Combine(_area, "attempt"); var fired = false;
        var admin = ScalarEpochAdministration.CreateCore(Options, new LocalTransactionStorage(), observed =>
        { if ((int)observed == stage) { fired = true; throw new IOException("publication-unknown"); } });
        EpochPublishedReceipt? receipt = null;
        var error = Assert.Throws<IOException>(() => receipt = Publish(admin, restore, destination));
        Assert.Equal("publication-unknown", error.Message); Assert.True(fired); Assert.Null(receipt); AssertInputs(before);
        if (stage == (int)EpochAdministrativeStage.Published)
        {
            Assert.True(Directory.Exists(Path.Combine(destination, "store")));
            using var owner = ScalarEpochDatabase.Open(Path.Combine(destination, "store"), new(DurabilityMode.ProcessCrash, ScalarEpochRecovery.FullHistory));
            Assert.Equal(1UL, owner.CommitSequence); owner.Dispose();
            var published = CaptureTree(destination); Assert.Throws<IOException>(() => Publish(Admin(), restore, destination)); AssertTree(published, destination);
        }
        else
        {
            Assert.False(Directory.Exists(destination)); var result = Publish(Admin(), restore, destination); ReadAll(result, 1);
        }
        AssertInputs(before);
    }

    /// <summary>Legacy and epoch artifact roles cannot be confused by verification or publication entry points.</summary>
    /// <param name="epoch">Supply an epoch artifact to a legacy operation or conversely.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Administration_WrongProfile_RejectsWithoutOutput(bool epoch)
    {
        Seed(0); var before = CaptureInputs(); var destination = Path.Combine(_area, "wrong"); var admin = Admin();
        if (epoch)
        {
            Assert.Throws<InvalidDataException>(() => admin.VerifyLegacyBackup(Epoch, destination));
            Assert.Throws<InvalidDataException>(() => admin.ConvertLegacyBackup(Epoch, destination));
        }
        else
        {
            Assert.Throws<InvalidDataException>(() => admin.VerifyEpochBackup(Legacy, destination));
            Assert.Throws<InvalidDataException>(() => admin.RestoreEpochBackup(Legacy, destination));
        }
        Assert.False(Directory.Exists(destination)); Assert.Empty(Directory.GetDirectories(_area, ".xmldb-epoch-backup-*")); AssertInputs(before);
    }

    /// <summary>A source change after private proof cannot be acknowledged as verification success.</summary>
    /// <param name="epoch">Artifact role.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Verify_InputChangedAfterProof_RejectsInsteadOfReturningStaleReceipt(bool epoch)
    {
        Seed(1); var artifact = epoch ? Epoch : Legacy; var fired = false;
        var admin = ScalarEpochAdministration.CreateCore(Options, new LocalTransactionStorage(), stage =>
        {
            if (stage != EpochAdministrativeStage.ProofVerified) return;
            fired = true; var path = Path.Combine(artifact, "inventory.bin"); var bytes = File.ReadAllBytes(path); bytes[^1] ^= 1; File.WriteAllBytes(path, bytes);
        });
        var hint = Path.Combine(_area, "hint");
        Assert.Throws<InvalidDataException>(() => { if (epoch) admin.VerifyEpochBackup(artifact, hint); else admin.VerifyLegacyBackup(artifact, hint); });
        Assert.True(fired); Assert.False(Directory.Exists(hint));
    }

    /// <summary>Invalid sealed input rejects before creating a private workspace or candidate.</summary>
    /// <param name="epoch">Artifact role.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Verify_CorruptSeal_RejectsBeforeWrites(bool epoch)
    {
        Seed(1); var artifact = epoch ? Epoch : Legacy; var seal = Path.Combine(artifact, "COMPLETE"); var bytes = File.ReadAllBytes(seal); bytes[^1] ^= 1; File.WriteAllBytes(seal, bytes);
        var before = CaptureInputs(); var hint = Path.Combine(_area, "hint");
        Assert.Throws<InvalidDataException>(() => { if (epoch) Admin().VerifyEpochBackup(artifact, hint); else Admin().VerifyLegacyBackup(artifact, hint); });
        Assert.Empty(Directory.GetDirectories(_area, ".xmldb-epoch-backup-*")); AssertInputs(before);
    }

    /// <summary>A fully resealed but logically inconsistent WAL cannot pass the administrative complete-history oracle.</summary>
    [Fact]
    public void VerifyEpoch_ResealedLogicalCorruption_RequiresHistoryProof()
    {
        Seed(1); var inventory = EpochBackupStorage.ReadArtifact(Epoch); var data = Path.Combine(Epoch, "data");
        var walPath = Path.Combine(data, ".transactions", "wal", EpochAuthorityCodec.WalFileName(1));
        var wal = EpochAuthorityCodec.DecodeWal(File.ReadAllBytes(walPath), inventory.Source);
        File.WriteAllBytes(walPath, EpochAuthorityCodec.EncodeWal(wal with { Value = "forged" })); var digest = SHA256.HashData(File.ReadAllBytes(walPath));
        var witnessPath = Path.Combine(EpochScalarHistory.Generation(data, 1), "GENERATION");
        var witness = EpochAuthorityCodec.DecodeGeneration(File.ReadAllBytes(witnessPath), inventory.Source);
        File.WriteAllBytes(witnessPath, EpochAuthorityCodec.EncodeGeneration(witness with { WalHash = digest }));
        File.WriteAllBytes(Path.Combine(data, ".transactions", "CURRENT"), EpochAuthorityCodec.EncodeCurrent(new(inventory.Source, 1, inventory.HeadManifestHash, digest)));
        var entries = inventory.Files.Select(file => { var bytes = File.ReadAllBytes(Path.Combine(data, file.Path)); return new BackupEntry(file.Path, bytes.Length, SHA256.HashData(bytes)); }).ToArray();
        var encoded = EpochBackupCodec.EncodeInventory(inventory with { Files = entries, HeadWalHash = digest });
        File.WriteAllBytes(Path.Combine(Epoch, "inventory.bin"), encoded); File.WriteAllBytes(Path.Combine(Epoch, "COMPLETE"), EpochBackupCodec.Complete(encoded));
        EpochBackupStorage.ReadArtifact(Epoch); // Seal, file hashes and headers alone deliberately pass.
        var before = CaptureInputs(); var stages = new List<EpochAdministrativeStage>();
        var admin = ScalarEpochAdministration.CreateCore(Options, new LocalTransactionStorage(), stages.Add);
        Assert.Throws<InvalidDataException>(() => admin.VerifyEpochBackup(Epoch, Path.Combine(_area, "semantic-hint")));
        Assert.Contains(EpochAdministrativeStage.PreflightVerified, stages); Assert.DoesNotContain(EpochAdministrativeStage.ProofVerified, stages);
        AssertInputs(before);
    }

    /// <summary>Placement hints and publication destinations never authorize overlap, existing data replacement or implicit parent creation.</summary>
    /// <param name="verify">Verify rather than publish.</param>
    /// <param name="kind">Rejected placement.</param>
    [Theory]
    [InlineData(false, "existing")]
    [InlineData(false, "overlap")]
    [InlineData(false, "missing-parent")]
    [InlineData(true, "existing")]
    [InlineData(true, "overlap")]
    [InlineData(true, "missing-parent")]
    public void Administration_InvalidPlacement_PreservesExistingData(bool verify, string kind)
    {
        Seed(0); var destination = kind == "overlap" ? Path.Combine(Legacy, "nested") : kind == "missing-parent" ? Path.Combine(_area, "absent", "output") : Path.Combine(_area, "existing");
        if (kind == "existing") { Directory.CreateDirectory(destination); File.WriteAllText(Path.Combine(destination, "sentinel"), "keep"); }
        var before = CaptureTree(_area);
        var error = Record.Exception(() => { if (verify) Admin().VerifyLegacyBackup(Legacy, destination); else Admin().ConvertLegacyBackup(Legacy, destination); });
        Assert.True(error is ArgumentException or IOException, error?.ToString() ?? "Unexpected acceptance."); AssertTree(before, _area);
    }

    /// <summary>Policy and argument validation is explicit and cannot introduce storage writes through invalid calls.</summary>
    [Fact]
    public void Administration_InvalidArguments_RejectBeforeStorageAccess()
    {
        Assert.Throws<ArgumentNullException>(() => ScalarEpochAdministration.Create(null!));
        Assert.Throws<ArgumentOutOfRangeException>(() => ScalarEpochAdministration.Create(new((DurabilityMode)99)));
        Assert.Throws<ArgumentException>(() => ScalarEpochAdministration.CreateCore(new(DurabilityMode.FileAndDirectoryFlush), new LocalTransactionStorage()));
        Assert.Throws<ArgumentException>(() => Admin().VerifyEpochBackup(" ", "unused"));
        Assert.Throws<ArgumentException>(() => Admin().ConvertLegacyBackup("unused", "")); Assert.False(Directory.Exists(_area));
    }

    /// <summary>Explicit native administrative proof executes on Linux and rejects without fallback elsewhere.</summary>
    [Fact]
    public void Administration_NativePolicy_HasNoFallback()
    {
        if (!OperatingSystem.IsLinux()) { Assert.Throws<PlatformNotSupportedException>(() => ScalarEpochAdministration.Create(new(DurabilityMode.FileAndDirectoryFlush))); return; }
        Seed(1); var before = CaptureInputs(); var admin = ScalarEpochAdministration.Create(new(DurabilityMode.FileAndDirectoryFlush));
        Assert.Equal(1UL, admin.VerifyEpochBackup(Epoch, Path.Combine(_area, "native-hint")).CommitSequence); AssertInputs(before);
    }

    private EpochPublishedReceipt Publish(ScalarEpochAdministration admin, bool restore, string destination) => restore ? admin.RestoreEpochBackup(Epoch, destination) : admin.ConvertLegacyBackup(Legacy, destination);
    private EpochMigrationResult Seed(int count)
    {
        Directory.CreateDirectory(_area); using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, Source);
        using (var owner = EmbeddedXmlDatabase.Open(Source))
        {
            using var read = owner.BeginRead(); var target = Target(read);
            for (var sequence = 1; sequence <= count; sequence++) { using var tx = owner.BeginWrite(); tx.ReplaceNodeValue(target, "new-" + sequence); tx.Commit(); }
            owner.CreateBackup(Legacy);
        }
        var result = EpochLegacyMigration.Convert(Legacy, Path.Combine(_area, "initial"));
        using var epoch = ScalarEpochDatabase.Open(result.StorePath, new(DurabilityMode.ProcessCrash, ScalarEpochRecovery.FullHistory)); epoch.CreateBackup(Epoch); return result;
    }
    private static void ReadAll(EpochPublishedReceipt result, int count)
    {
        using var owner = ScalarEpochDatabase.Open(result.StorePath, new(DurabilityMode.ProcessCrash, ScalarEpochRecovery.FullHistory, result.DestinationEpoch));
        using var admission = EpochAdmission.Acquire(result.StorePath, result.DestinationEpoch, profile: EpochProfile.ScalarWal);
        var binding = EpochEmptyCoordinator.ReadAuthority(result.StorePath, result.DestinationEpoch, true);
        for (ulong sequence = 0; sequence <= (ulong)count; sequence++)
        {
            var hash = sequence == 0 ? binding.BaseHash : EpochAuthorityCodec.DecodeWal(File.ReadAllBytes(Path.Combine(result.StorePath, ".transactions", "wal", EpochAuthorityCodec.WalFileName(sequence))), binding).ManifestHash;
            using var read = EpochScalarHistory.Open(result.StorePath, sequence, admission, hash); Assert.Equal(sequence == 0 ? "old" : "new-" + sequence, read.ReadValue(Target(read)));
        }
    }
    private static ulong Target(ImmutableXmlSnapshot read) => Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id)).Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();
    private sealed record Tree(string[] Directories, Dictionary<string, byte[]> Files);
    private static Tree CaptureTree(string root) => new(Directory.GetDirectories(root, "*", SearchOption.AllDirectories).Order().ToArray(), Directory.GetFiles(root, "*", SearchOption.AllDirectories).ToDictionary(path => path, File.ReadAllBytes));
    private static void AssertTree(Tree before, string root)
    { var after = CaptureTree(root); Assert.Equal(before.Directories, after.Directories); Assert.Equal(before.Files.Keys.Order(), after.Files.Keys.Order()); foreach (var pair in before.Files) Assert.Equal(pair.Value, after.Files[pair.Key]); }
    private Dictionary<string, Tree> CaptureInputs() => new[] { Source, Legacy, Epoch, Path.Combine(_area, "initial") }.ToDictionary(root => root, CaptureTree);
    private static void AssertInputs(Dictionary<string, Tree> before) { foreach (var pair in before) AssertTree(pair.Value, pair.Key); }
    /// <summary>Deletes only this test's GUID-owned temporary data after all verification and reader handles have closed.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
