// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies fixed-head epoch backup publication and source preservation across process kills.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 27-10-2026     | Repeat interruptions, retry unpublished paths and reject existing outputs
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Verifies actual epoch capture publication, kill windows and source preservation.</summary>
public sealed class EpochBackupCaptureProcessTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-et9b-process-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "epoch");
    private string Backup => Path.Combine(_area, "backup");

    /// <summary>Only a complete published artifact is visible after capture process exit or kill; source bytes remain unchanged.</summary>
    /// <param name="stage">Normal exit, private failure window, publication or acknowledgment loss.</param>
    [Theory]
    [InlineData("normal")]
    [InlineData("Copied")]
    [InlineData("Completed")]
    [InlineData("Published")]
    [InlineData("ACK")]
    public async Task Capture_FreshProcessOrKill_PreservesSourceAndPublishesOnlyCompleteHistory(string stage)
    {
        Seed();
        for (var attempt = 0; attempt < 3; attempt++)
        {
            var backup = Path.Combine(_area, "backup-" + attempt); var before = Bytes(Root);
            var info = new ProcessStartInfo("dotnet") { RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false };
            foreach (var argument in new[] { typeof(EpochBackupCaptureProcessTests).Assembly.Location, "et9b-capture", Root, backup, stage }) info.ArgumentList.Add(argument);
            using var process = Process.Start(info) ?? throw new InvalidOperationException("Cannot start epoch capture probe.");
            var stdout = process.StandardOutput.ReadToEndAsync(); var stderr = process.StandardError.ReadToEndAsync();
            try { await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(40)); }
            catch { if (!process.HasExited) process.Kill(true); throw; }
            var output = await stdout; var error = await stderr;
            if (stage == "normal") { Assert.True(process.ExitCode == 0, error); using var json = JsonDocument.Parse(output); Assert.Equal(3, json.RootElement.GetProperty("CommitSequence").GetInt32()); }
            else { Assert.NotEqual(0, process.ExitCode); Assert.Contains(stage == "ACK" ? "ET9B-ACK" : "ET9B-FAULT:" + stage, output); }
            AssertBytes(before, Root);
            if (stage is "normal" or "Published" or "ACK")
            {
                var inventory = EpochBackupStorage.ReadArtifact(backup); Assert.Equal(3UL, inventory.CommitSequence);
                foreach (var entry in inventory.Files) Assert.Equal(File.ReadAllBytes(Path.Combine(Root, entry.Path)), File.ReadAllBytes(Path.Combine(backup, "data", entry.Path)));
                Assert.False(Directory.Exists(Path.Combine(backup, "data", ".epoch")));
            }
            else Assert.False(Directory.Exists(backup));
            using var reopened = EpochScalarCoordinator.Open(Root); using var read = reopened.BeginRead(0);
            Assert.Equal(3UL, read.CommitSequence); Assert.Equal("ET9B-three", read.ReadValue(Target(read, "DocumentID")));
            Assert.Equal("ET9B-line", read.ReadValue(Target(read, "ItemID", true)));
            if (stage is "Copied" or "Completed") reopened.CreateBackup(backup);
            Assert.Equal(3UL, EpochBackupStorage.ReadArtifact(backup).CommitSequence);
            var published = Bytes(backup);
            Assert.Throws<IOException>(() => reopened.CreateBackup(backup)); AssertBytes(published, backup);
            read.Dispose(); reopened.Dispose(); AssertBytes(before, Root);
        }
    }

    private void Seed()
    {
        Directory.CreateDirectory(_area); var source = Path.Combine(_area, "source");
        var xml = "<SalesOrder><SalesOrderHeader><DocumentID>old</DocumentID></SalesOrderHeader>" +
            string.Concat(Enumerable.Range(1, 20).Select(id => $"<SalesOrderLine><Item><ItemID>{id}</ItemID></Item></SalesOrderLine>")) + "</SalesOrder>";
        using var input = new MemoryStream(Encoding.UTF8.GetBytes(xml)); XmlFragmentImporter.Import(input, source, linesPerFragment: 4);
        EpochEmptyRoot.CreateFixture(source, Root, 1, new LocalTransactionStorage()); using var owner = EpochScalarCoordinator.Open(Root); using var read = owner.BeginRead();
        for (var index = 1; index <= 3; index++)
        { using var tx = owner.BeginTransaction(); tx.ReplaceNodeValue(Target(read, index == 2 ? "ItemID" : "DocumentID", index == 2), index == 1 ? "ET9B-one" : index == 2 ? "ET9B-line" : "ET9B-three"); tx.Commit(); }
    }
    private static ulong Target(ImmutableXmlSnapshot snapshot, string name, bool last = false)
    {
        var nodes = Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id)).Where(node => node.Kind == StorageNodeKind.Element && node.LocalName == name);
        return (last ? nodes.Last() : nodes.Single()).Children.Single();
    }
    private static Dictionary<string, byte[]> Bytes(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories).ToDictionary(path => Path.GetRelativePath(root, path), File.ReadAllBytes);
    private static void AssertBytes(Dictionary<string, byte[]> expected, string root)
    { var actual = Bytes(root); Assert.Equal(expected.Keys.Order(), actual.Keys.Order()); foreach (var file in expected) Assert.Equal(file.Value, actual[file.Key]); }
    /// <summary>Removes isolated fixture data after processes and handles close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
