// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Qualifies preannounced attempts across process death and competing publication.
// SPECIAL NOTES        : Local baseline compatibility only; no archived release or actual routing claim.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Tests restart inspection and destination contention without reconstructing executable plans.</summary>
public sealed class EpochAdministrativeAttemptProcessTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-rc3-" + Guid.NewGuid().ToString("N"));
    private string Artifact => Path.Combine(_area, "artifact");
    private string Destination => Path.Combine(_area, "destination");
    private static EpochPublicationKind Kind(bool epoch) => epoch ? EpochPublicationKind.IndependentEpochRestore : EpochPublicationKind.LegacyMigration;

    /// <summary>Retained primitive correlation survives publisher death; inspection does not resume its plan.</summary>
    /// <param name="epoch">Restore rather than migrate.</param>
    /// <param name="stage">Process termination boundary.</param>
    [Theory]
    [InlineData(false, "ProofVerified")]
    [InlineData(false, "ReadyToPublish")]
    [InlineData(false, "Published")]
    [InlineData(false, "ACK")]
    [InlineData(true, "ProofVerified")]
    [InlineData(true, "ReadyToPublish")]
    [InlineData(true, "Published")]
    [InlineData(true, "ACK")]
    public async Task Execute_ProcessDies_RetainedIdInspectsOutcome(bool epoch, string stage)
    {
        Seed(epoch); var inputs = Bytes(Artifact);
        var info = new ProcessStartInfo("dotnet") { RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false };
        foreach (var arg in new[] { typeof(EpochAdministrativeAttemptProcessTests).Assembly.Location, "rc3-execute", Artifact, Destination, Kind(epoch).ToString(), stage }) info.ArgumentList.Add(arg);
        using var process = Process.Start(info) ?? throw new InvalidOperationException("No probe process.");
        try
        {
            var errors = process.StandardError.ReadToEndAsync();
            var line = await process.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(30));
            using var json = JsonDocument.Parse(line!); var id = json.RootElement.GetProperty("AttemptId").GetGuid();
            var pin = json.RootElement.GetProperty("InventorySha256").GetString()!; Assert.NotEqual(Guid.Empty, id);
            await process.StandardInput.WriteLineAsync("dispatch"); await process.StandardInput.FlushAsync();
            var output = process.StandardOutput.ReadToEndAsync();
            await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(45));
            Assert.NotEqual(0, process.ExitCode); Assert.Contains("RC3:" + stage, await output); _ = await errors;
            var before = Bytes(_area);
            var admin = ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash));
            var observation = admin.InspectPublication(new(Kind(epoch), Artifact, Destination, pin, id));
            Assert.True(observation.WritersMustRemainStopped);
            AssertBytes(before, _area); AssertBytes(inputs, Artifact);
            if (stage is "Published" or "ACK")
            {
                Assert.Equal(EpochInspectionStatus.KnownOperationMatched, observation.Status); Assert.Equal(id, observation.Observed!.OperationId);
                Assert.Throws<IOException>(() => admin.PrepareAttempt(Kind(epoch), Artifact, Destination));
            }
            else
            {
                Assert.Equal(EpochInspectionStatus.NotObserved, observation.Status);
                // Exit was awaited: this test owns dispatch and has reconciled absence before creating a new attempt.
                var fresh = admin.PrepareAttempt(Kind(epoch), Artifact, Destination); Assert.NotEqual(id, fresh.Describe().AttemptId);
                Assert.Equal(fresh.Describe().AttemptId, admin.ExecuteAttempt(fresh).OperationId);
            }
        }
        finally { if (!process.HasExited) { process.Kill(true); await process.WaitForExitAsync(); } }
    }

    /// <summary>Two fully verified independent plans race on one destination; exactly one publishes without overwrite.</summary>
    /// <param name="epoch">Restore rather than migrate.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Execute_CompetingPlans_OnePublicationMatchesOnlyWinner(bool epoch)
    {
        Seed(epoch); var inputs = Bytes(Artifact); using var ready = new Barrier(2);
        ScalarEpochAdministration Admin() => ScalarEpochAdministration.CreateCore(new(DurabilityMode.ProcessCrash), new LocalTransactionStorage(), stage =>
        {
            if (stage == EpochAdministrativeStage.ReadyToPublish && !ready.SignalAndWait(TimeSpan.FromSeconds(30))) throw new TimeoutException("Publisher rendezvous.");
        });
        var a = Admin(); var b = Admin(); var pa = a.PrepareAttempt(Kind(epoch), Artifact, Destination); var pb = b.PrepareAttempt(Kind(epoch), Artifact, Destination);
        var results = await Task.WhenAll(Task.Run(() => Record.Exception(() => a.ExecuteAttempt(pa))), Task.Run(() => Record.Exception(() => b.ExecuteAttempt(pb))));
        Assert.Single(results, error => error is null); Assert.Single(results, error => error is IOException);
        Assert.Equal(EpochAttemptState.Dispatched, pa.State); Assert.Equal(EpochAttemptState.Dispatched, pb.State);
        var winner = results[0] is null ? pa : pb; var loser = results[0] is null ? pb : pa; var before = Bytes(_area);
        Assert.Equal(EpochInspectionStatus.KnownOperationMatched, a.InspectPublication(winner.Describe().ToInspectionRequest()).Status);
        Assert.Equal(EpochInspectionStatus.ReconciliationRequired, a.InspectPublication(loser.Describe().ToInspectionRequest()).Status);
        Assert.Throws<InvalidOperationException>(() => a.ExecuteAttempt(pa)); Assert.Throws<InvalidOperationException>(() => b.ExecuteAttempt(pb));
        AssertBytes(before, _area); AssertBytes(inputs, Artifact);
    }

    /// <summary>Concurrent execution of the same plan permits one pipeline entry and rejects every duplicate.</summary>
    /// <param name="epoch">Restore rather than migrate.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Execute_SamePlan_OnlyOneDispatcherEnters(bool epoch)
    {
        Seed(epoch); using var start = new ManualResetEventSlim();
        var admin = ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash));
        var plan = admin.PrepareAttempt(Kind(epoch), Artifact, Destination);
        var workers = Enumerable.Range(0, 4).Select(_ => Task.Run(() => { start.Wait(); return Record.Exception(() => admin.ExecuteAttempt(plan)); })).ToArray();
        start.Set(); var results = await Task.WhenAll(workers);
        Assert.Single(results, error => error is null); Assert.Equal(3, results.Count(error => error is InvalidOperationException));
        Assert.Equal(EpochInspectionStatus.KnownOperationMatched, admin.InspectPublication(plan.Describe().ToInspectionRequest()).Status);
    }

    private void Seed(bool epoch)
    {
        Directory.CreateDirectory(_area); var source = Path.Combine(_area, "source"); var legacy = epoch ? Path.Combine(_area, "legacy") : Artifact;
        using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, source);
        using (var owner = EmbeddedXmlDatabase.Open(source))
        { using var read = owner.BeginRead(); for (var index = 1; index <= 1; index++) { using var tx = owner.BeginWrite(); tx.ReplaceNodeValue(Target(read), "new-" + index); tx.Commit(); } owner.CreateBackup(legacy); }
        if (!epoch) return;
        var result = EpochLegacyMigration.Convert(legacy, Path.Combine(_area, "initial"));
        using var candidate = ScalarEpochDatabase.Open(result.StorePath, new(DurabilityMode.ProcessCrash, ScalarEpochRecovery.FullHistory)); candidate.CreateBackup(Artifact);
    }
    private static ulong Target(ImmutableXmlSnapshot read) => Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();
    private static Dictionary<string, byte[]> Bytes(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories).ToDictionary(p => Path.GetRelativePath(root, p), File.ReadAllBytes);
    private static void AssertBytes(Dictionary<string, byte[]> expected, string root) { var actual = Bytes(root); Assert.Equal(expected.Keys.Order(), actual.Keys.Order()); foreach (var pair in expected) Assert.Equal(pair.Value, actual[pair.Key]); }
    /// <summary>Deletes only this test's GUID-owned tree after child processes and handles close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
