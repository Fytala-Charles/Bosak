// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Verifies read-only administrative preparation, immutable intent and owner-bound atomic claims.
// SPECIAL NOTES        : Local baseline compatibility only; no archived release or actual routing claim.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Qualifies RC1 local intent preparation and claim state without planned pipeline execution.</summary>
public sealed class EpochAdministrativeAttemptPlanTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-rc1-" + Guid.NewGuid().ToString("N"));
    private string Artifact => Path.Combine(_area, "artifact");
    private string Destination => Path.Combine(_area, "destination");
    private static EpochPublicationKind Kind(bool epoch) => epoch ? EpochPublicationKind.IndependentEpochRestore : EpochPublicationKind.LegacyMigration;

    /// <summary>Preparation binds both source profiles and history endpoints without mutation, barriers, publication or retained handles.</summary>
    /// <param name="epoch">Source artifact profile.</param>
    /// <param name="count">Source history length.</param>
    [Theory]
    [InlineData(false, 0)]
    [InlineData(false, 3)]
    [InlineData(true, 0)]
    [InlineData(true, 3)]
    public void Prepare_BindsExactIntentWithoutWrites(bool epoch, int count)
    {
        var source = Seed(epoch, count); var before = Capture(); var storage = new NoWritesStorage();
        var admin = ScalarEpochAdministration.CreateCore(new(DurabilityMode.ProcessCrash), storage);
        var plan = admin.PrepareAttempt(Kind(epoch), Artifact, Destination); var descriptor = plan.Describe();
        Assert.Equal(EpochAttemptState.Prepared, plan.State); Assert.NotEqual(Guid.Empty, descriptor.AttemptId);
        Assert.Equal(Kind(epoch), descriptor.Kind); Assert.Equal(Path.GetFullPath(Artifact), descriptor.ArtifactRoot); Assert.Equal(Path.GetFullPath(Destination), descriptor.BundleRoot);
        Assert.Equal(source, descriptor.SourceEpoch); Assert.Equal((ulong)count, descriptor.CommitSequence); Assert.Equal(1UL, descriptor.DocumentId);
        Assert.NotEqual(Guid.Empty, descriptor.BackupId); Assert.Equal(EpochProfile.ScalarWal, descriptor.DestinationProfile); Assert.Equal(DurabilityMode.ProcessCrash, descriptor.Durability);
        Assert.Equal(Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(Path.Combine(Artifact, "inventory.bin")))).ToLowerInvariant(), descriptor.InventorySha256);
        var request = descriptor.ToInspectionRequest(); Assert.Equal(descriptor.AttemptId, request.ExpectedOperationId); Assert.Equal(descriptor.InventorySha256, request.ExpectedInventorySha256);
        Assert.Equal(descriptor.BundleRoot, request.Bundle); Assert.Null(request.ExpectedDestination);
        Assert.Equal(0, storage.Calls); Assert.False(Directory.Exists(Destination)); AssertUnchanged(before);
        foreach (var file in before.Files.Keys) using (new FileStream(file, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) { }
    }

    /// <summary>Descriptive copies can be changed independently but cannot reconstruct, clone or publicly expose the opaque plan.</summary>
    [Fact]
    public void Describe_ReturnsDetachedImmutableIntentWithoutExecutableReconstruction()
    {
        Seed(false, 0); var admin = ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash)); var plan = admin.PrepareAttempt(Kind(false), Artifact, Destination);
        var original = plan.Describe(); var detached = plan.Describe(); Assert.Equal(original, detached); Assert.NotSame(original, detached);
        detached = detached with { AttemptId = Guid.NewGuid(), BundleRoot = Path.Combine(_area, "other") };
        Assert.Equal(original, plan.Describe()); Assert.NotEqual(detached, plan.Describe()); Assert.Equal(EpochAttemptState.Prepared, plan.State);
        Assert.True(typeof(EpochAdministrativeAttemptPlan).IsSealed); Assert.False(typeof(EpochAdministrativeAttemptPlan).IsVisible);
        Assert.All(typeof(EpochAdministrativeAttemptPlan).GetConstructors(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic), constructor => Assert.True(constructor.IsPrivate));
        Assert.DoesNotContain(typeof(EpochAdministrativeAttemptPlan).GetMethods(BindingFlags.Public | BindingFlags.Static), method => method.ReturnType == typeof(EpochAdministrativeAttemptPlan));
    }

    /// <summary>Foreign/null plans and changed injected policy reject before consuming the real owner's prepared state.</summary>
    /// <param name="fault">Pure preclaim rejection.</param>
    [Theory]
    [InlineData("foreign")]
    [InlineData("null")]
    [InlineData("policy")]
    public void Claim_InvalidOwnerOrPolicy_DoesNotConsumeOrAccessStorage(string fault)
    {
        Seed(false, 0); var before = Capture(); var storage = new NoWritesStorage(); var admin = ScalarEpochAdministration.CreateCore(new(DurabilityMode.ProcessCrash), storage);
        var plan = admin.PrepareAttempt(Kind(false), Artifact, Destination);
        switch (fault)
        {
            case "foreign": Assert.Throws<ArgumentException>(() => ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash)).ClaimAttempt(plan)); break;
            case "null": Assert.Throws<ArgumentNullException>(() => admin.ClaimAttempt(null!)); break;
            case "policy": storage.Durability = DurabilityMode.FileAndDirectoryFlush; Assert.Throws<ArgumentException>(() => admin.ClaimAttempt(plan)); storage.Durability = DurabilityMode.ProcessCrash; break;
        }
        Assert.Equal(EpochAttemptState.Prepared, plan.State); Assert.Equal(plan.Describe(), admin.ClaimAttempt(plan));
        Assert.Equal(EpochAttemptState.Dispatched, plan.State); Assert.Equal(0, storage.Calls); AssertUnchanged(before);
    }

    /// <summary>Eight synchronized workers obtain exactly one local claim and no filesystem effects.</summary>
    /// <param name="epoch">Source profile.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Claim_ConcurrentWorkers_ExactlyOneWinsWithoutIo(bool epoch)
    {
        Seed(epoch, 1); var before = Capture(); var storage = new NoWritesStorage(); var admin = ScalarEpochAdministration.CreateCore(new(DurabilityMode.ProcessCrash), storage);
        var plan = admin.PrepareAttempt(Kind(epoch), Artifact, Destination); using var barrier = new Barrier(8); var winners = 0; var rejected = 0;
        var workers = Enumerable.Range(0, 8).Select(_ => Task.Factory.StartNew(() =>
        {
            if (!barrier.SignalAndWait(TimeSpan.FromSeconds(10))) throw new TimeoutException("Claim workers did not synchronize.");
            try { var descriptor = admin.ClaimAttempt(plan); Assert.Equal(plan.Describe(), descriptor); Interlocked.Increment(ref winners); }
            catch (InvalidOperationException error) { Assert.Contains("already been dispatched", error.Message); Interlocked.Increment(ref rejected); }
        }, CancellationToken.None, TaskCreationOptions.LongRunning, TaskScheduler.Default)).ToArray();
        await Task.WhenAll(workers).WaitAsync(TimeSpan.FromSeconds(20));
        Assert.Equal(1, winners); Assert.Equal(7, rejected); Assert.Equal(EpochAttemptState.Dispatched, plan.State);
        Assert.Throws<InvalidOperationException>(() => admin.ClaimAttempt(plan)); Assert.Equal(0, storage.Calls); AssertUnchanged(before);
    }

    /// <summary>Claim is only local state: even absent input and a now-existing target cannot cause hidden I/O or rearm after later failure.</summary>
    [Fact]
    public void Claim_DoesNotValidateFilesystemOrAllowReplay()
    {
        Seed(false, 0); var storage = new NoWritesStorage(); var admin = ScalarEpochAdministration.CreateCore(new(DurabilityMode.ProcessCrash), storage);
        var plan = admin.PrepareAttempt(Kind(false), Artifact, Destination); var descriptor = plan.Describe();
        Directory.Delete(Artifact, true); Directory.CreateDirectory(Destination); File.WriteAllText(Path.Combine(Destination, "sentinel"), "keep"); var before = Capture();
        Assert.Equal(descriptor, admin.ClaimAttempt(plan));
        Assert.Throws<InvalidOperationException>(() => admin.ClaimAttempt(plan)); Assert.Equal(EpochAttemptState.Dispatched, plan.State);
        Assert.Equal(0, storage.Calls); AssertUnchanged(before);
    }

    /// <summary>Prepared plans neither reserve the destination nor change existing unplanned publication behavior.</summary>
    /// <param name="epoch">Publication role.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Prepare_DoesNotReserveTargetOrChangeUnplannedIds(bool epoch)
    {
        Seed(epoch, 0); var admin = ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash));
        var first = admin.PrepareAttempt(Kind(epoch), Artifact, Destination); var second = admin.PrepareAttempt(Kind(epoch), Artifact, Destination);
        Assert.NotEqual(first.Describe().AttemptId, second.Describe().AttemptId);
        var published = epoch ? admin.RestoreEpochBackup(Artifact, Destination) : admin.ConvertLegacyBackup(Artifact, Destination);
        Assert.NotEqual(first.Describe().AttemptId, published.OperationId); Assert.NotEqual(second.Describe().AttemptId, published.OperationId);
        Assert.Equal(EpochAttemptState.Prepared, first.State); Assert.Equal(EpochAttemptState.Prepared, second.State);
        Assert.Equal(EpochInspectionStatus.ReconciliationRequired, admin.InspectPublication(first.Describe().ToInspectionRequest()).Status);
    }

    /// <summary>Raw role/argument errors reject before allocating any filesystem output.</summary>
    [Fact]
    public void Prepare_InvalidArguments_RejectBeforeFilesystemWork()
    {
        var admin = ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash));
        Assert.Throws<ArgumentOutOfRangeException>(() => admin.PrepareAttempt((EpochPublicationKind)99, "unused", "unused-destination"));
        Assert.Throws<ArgumentException>(() => admin.PrepareAttempt(Kind(false), " ", "unused"));
        Assert.Throws<ArgumentException>(() => admin.PrepareAttempt(Kind(false), "unused", "")); Assert.False(Directory.Exists(_area));
    }

    /// <summary>Wrong roles, corrupt seals, existing/overlapping/aliased destinations and missing parents cannot prepare.</summary>
    /// <param name="epoch">Source profile.</param>
    /// <param name="fault">Rejected preparation.</param>
    [Theory]
    [InlineData(false, "wrong-role")]
    [InlineData(false, "seal")]
    [InlineData(false, "existing")]
    [InlineData(false, "overlap")]
    [InlineData(false, "missing-parent")]
    [InlineData(false, "portable-alias")]
    [InlineData(true, "wrong-role")]
    [InlineData(true, "seal")]
    [InlineData(true, "existing")]
    [InlineData(true, "overlap")]
    [InlineData(true, "missing-parent")]
    [InlineData(true, "portable-alias")]
    public void Prepare_InvalidArtifactOrPlacement_PreservesAllData(bool epoch, string fault)
    {
        Seed(epoch, 1); var destination = fault switch { "overlap" => Path.Combine(Artifact, "nested"), "missing-parent" => Path.Combine(_area, "absent", "destination"), "portable-alias" => Path.Combine(_area, "alias~1"), _ => Destination };
        if (fault == "seal") { var path = Path.Combine(Artifact, "COMPLETE"); var bytes = File.ReadAllBytes(path); bytes[^1] ^= 1; File.WriteAllBytes(path, bytes); }
        if (fault == "existing") { Directory.CreateDirectory(destination); File.WriteAllText(Path.Combine(destination, "sentinel"), "keep"); }
        var before = Capture(); var storage = new NoWritesStorage(); var admin = ScalarEpochAdministration.CreateCore(new(DurabilityMode.ProcessCrash), storage);
        var error = Record.Exception(() => admin.PrepareAttempt(Kind(fault == "wrong-role" ? !epoch : epoch), Artifact, destination));
        Assert.True(error is InvalidDataException or IOException or ArgumentException, error?.ToString() ?? "Unexpected preparation.");
        Assert.Equal(0, storage.Calls); AssertUnchanged(before);
    }

    /// <summary>Actual Linux links are rejected by read-only preparation; Windows does not execute this link branch.</summary>
    [Fact]
    public void Prepare_LinkedArtifact_RejectsWithoutFollowingOrWrites()
    {
        if (!OperatingSystem.IsLinux()) return;
        Seed(false, 0); var link = Path.Combine(_area, "linked"); Directory.CreateSymbolicLink(link, Artifact); var before = Capture();
        Assert.Throws<InvalidDataException>(() => ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash)).PrepareAttempt(Kind(false), link, Destination)); AssertUnchanged(before);
    }

    /// <summary>A well-sealed logical inconsistency may prepare but never substitutes for complete/full-redo verification.</summary>
    [Fact]
    public void Prepare_IsNotAFullHistoryVerificationReceipt()
    {
        Seed(true, 1); var inventory = EpochBackupStorage.ReadArtifact(Artifact); var data = Path.Combine(Artifact, "data");
        var walPath = Path.Combine(data, ".transactions", "wal", EpochAuthorityCodec.WalFileName(1));
        var wal = EpochAuthorityCodec.DecodeWal(File.ReadAllBytes(walPath), inventory.Source);
        File.WriteAllBytes(walPath, EpochAuthorityCodec.EncodeWal(wal with { Value = "forged" })); var digest = SHA256.HashData(File.ReadAllBytes(walPath));
        var witnessPath = Path.Combine(EpochScalarHistory.Generation(data, 1), "GENERATION");
        var witness = EpochAuthorityCodec.DecodeGeneration(File.ReadAllBytes(witnessPath), inventory.Source);
        File.WriteAllBytes(witnessPath, EpochAuthorityCodec.EncodeGeneration(witness with { WalHash = digest }));
        File.WriteAllBytes(Path.Combine(data, ".transactions", "CURRENT"), EpochAuthorityCodec.EncodeCurrent(new(inventory.Source, 1, inventory.HeadManifestHash, digest)));
        var entries = inventory.Files.Select(file => { var bytes = File.ReadAllBytes(Path.Combine(data, file.Path)); return new BackupEntry(file.Path, bytes.Length, SHA256.HashData(bytes)); }).ToArray();
        var encoded = EpochBackupCodec.EncodeInventory(inventory with { Files = entries, HeadWalHash = digest });
        File.WriteAllBytes(Path.Combine(Artifact, "inventory.bin"), encoded); File.WriteAllBytes(Path.Combine(Artifact, "COMPLETE"), EpochBackupCodec.Complete(encoded));
        var before = Capture(); var admin = ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash)); var plan = admin.PrepareAttempt(Kind(true), Artifact, Destination);
        Assert.Equal(EpochAttemptState.Prepared, plan.State); AssertUnchanged(before);
        Assert.Throws<InvalidDataException>(() => admin.VerifyEpochBackup(Artifact, Path.Combine(_area, "proof-hint")));
        Assert.Equal(EpochAttemptState.Prepared, plan.State); Assert.False(Directory.Exists(Destination));
    }

    private EpochIdentity? Seed(bool epoch, int count)
    {
        Directory.CreateDirectory(_area); var source = Path.Combine(_area, "source"); var legacy = epoch ? Path.Combine(_area, "legacy") : Artifact;
        using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, source);
        using (var owner = EmbeddedXmlDatabase.Open(source))
        { using var read = owner.BeginRead(); for (var index = 1; index <= count; index++) { using var tx = owner.BeginWrite(); tx.ReplaceNodeValue(Target(read), "new-" + index); tx.Commit(); } owner.CreateBackup(legacy); }
        if (!epoch) return null;
        var migrated = EpochLegacyMigration.Convert(legacy, Path.Combine(_area, "initial"));
        using var candidate = ScalarEpochDatabase.Open(migrated.StorePath, new(DurabilityMode.ProcessCrash, ScalarEpochRecovery.FullHistory)); candidate.CreateBackup(Artifact); return migrated.Destination;
    }
    private static ulong Target(ImmutableXmlSnapshot read) => Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id)).Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();
    private sealed record Tree(string[] Directories, Dictionary<string, byte[]> Files);
    private Tree Capture() => new(Directory.GetDirectories(_area, "*", SearchOption.AllDirectories).Order().ToArray(), Directory.GetFiles(_area, "*", SearchOption.AllDirectories).ToDictionary(path => path, File.ReadAllBytes));
    private void AssertUnchanged(Tree before) { var after = Capture(); Assert.Equal(before.Directories, after.Directories); Assert.Equal(before.Files.Keys.Order(), after.Files.Keys.Order()); foreach (var pair in before.Files) Assert.Equal(pair.Value, after.Files[pair.Key]); }
    private sealed class NoWritesStorage : ITransactionStorage
    {
        internal int Calls { get; private set; }
        public DurabilityMode Durability { get; set; } = DurabilityMode.ProcessCrash;
        private void Reject() { Calls++; throw new InvalidOperationException("Preparation or claim attempted storage mutation/barrier."); }
        public ITransactionFile CreateFile(string path) { Reject(); throw new InvalidOperationException(); }
        public void CreateDirectory(string path) => Reject();
        public void MoveFile(string source, string destination, bool overwrite) => Reject();
        public void MoveDirectory(string source, string destination) => Reject();
        public void DeleteFile(string path) => Reject();
        public void DeleteDirectory(string path) => Reject();
        public void SyncDirectory(string path) => Reject();
        public void SyncFile(string path) => Reject();
    }
    /// <summary>Deletes only this test's isolated GUID temporary root after every child, proof and claim worker has completed.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
