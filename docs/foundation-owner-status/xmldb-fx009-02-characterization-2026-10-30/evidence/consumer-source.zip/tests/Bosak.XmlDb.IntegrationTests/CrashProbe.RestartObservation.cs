// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 30 October 2026
// PURPOSE              : Runs process-held stopped restart observation and interruption probes.
// SPECIAL NOTES        : SR2-C current test worker only; no restored capabilities, routing or write admission.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 30-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Runs process-held stopped restart observation and interruption probes.</summary>
internal static partial class CrashProbe
{
    private sealed class RestartProcessProbe(string point, bool closing, Action close) : IRestartObservationProbe
    {
        /// <inheritdoc/>
        public void BeforeProtectedPathRead(string path) { }
        /// <inheritdoc/>
        public void AtStage(RestartObservationStage stage)
        {
            if (stage.ToString() != point) return;
            if (closing) close();
            RestartPause("AT:" + point, "continue");
        }
    }
    private static void RestartPause(string line, string expected)
    {
        Console.WriteLine(line); Console.Out.Flush();
        if (Console.ReadLine() != expected) throw new IOException("Restart observation probe input ended.");
    }
    private static int RunRestartObservation(string[] args)
    {
        if (args.Length != 9) return 2;
        if (args[0] == "sr2c-race") RestartPause("READY", "start");
        try
        {
            using var source = EmbeddedXmlDatabase.Open(args[3]); using var snapshot = source.BeginRead();
            using var parent = EmbeddedHostLifetime.OpenExisting(args[1], "embedded-pilot", "orders", [args[2], args[3], args[4]]);
            var configuration = new ApplicationAuthorityConfiguration(Guid.Parse(args[5]), Guid.Parse(args[6]), "embedded-pilot", "orders", "admin", "authority");
            using var authority = ApplicationAuthorityLifetime.OpenExisting(parent, parent.JournalStatus.KnownPosition,
                new(parent.Context, true, true, true, true, true), args[2], configuration,
                new Dictionary<string, string> { ["admin"] = args[1], ["authority"] = args[2], ["source"] = args[3], ["capture"] = args[4] });
            void CloseWrappers() { source.Dispose(); authority.Dispose(); parent.Dispose(); }
            RestartPause("OPENED", "begin"); // Explicit recovery and reader setup precede the observed read-only boundary.
            var evidence = new ApplicationRestartEvidence(parent.Context, configuration.AuthorityId, "capture", EnrollmentRestartFact.Confirmed,
                EnrollmentRestartFact.Confirmed, EnrollmentRestartFact.Confirmed, EnrollmentRestartFact.Confirmed, EnrollmentRestartFact.Confirmed);
            ApplicationAuthorityLifetime.StoppedRestartObservation? scope = null; ApplicationRestartDescription? description = null;
            try
            {
                try
                {
                    scope = authority.BeginRestartObservationCore(source, evidence, new RestartProcessProbe(args[7], bool.Parse(args[8]), CloseWrappers), null);
                    description = scope.Observe();
                    if (description.Assessment.Decision != EnrollmentRestartDecision.ObservedEnrolledStopped || !description.WritersMustRemainStopped || authority.ConfirmedEnrollment is not null) return 4;
                    if (args[7] == "Observed") { if (bool.Parse(args[8])) CloseWrappers(); RestartPause("AT:Observed", "continue"); }
                    Console.WriteLine("RESULT:ObservedEnrolledStopped:" + description.Observations.Observed!.Digest); Console.Out.Flush();
                }
                catch (ObjectDisposedException) when (bool.Parse(args[8])) { Console.WriteLine("RESULT:Refused"); Console.Out.Flush(); }
                catch (InvalidOperationException) when (bool.Parse(args[8])) { Console.WriteLine("RESULT:Refused"); Console.Out.Flush(); }
                RestartPause("HELD", "release");
            }
            finally { scope?.Dispose(); CloseWrappers(); }
            source.WhenEnrollmentOwnershipReleased.GetAwaiter().GetResult(); authority.WhenReleased.GetAwaiter().GetResult(); parent.WhenReleased.GetAwaiter().GetResult();
            var target = Enumerable.Range(1, snapshot.NodeCount).Select(i => snapshot.GetNode((ulong)i)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();
            if (snapshot.ReadValue(target) != "new-0") return 4;
            if (description is not null && !description.Assessment.WritersMustRemainStopped) return 4;
            RestartPause("RELEASED", "exit"); return 0;
        }
        catch (IOException) when (args[0] == "sr2c-race") { Console.WriteLine("BLOCKED"); Console.Out.Flush(); return 0; }
    }
}
