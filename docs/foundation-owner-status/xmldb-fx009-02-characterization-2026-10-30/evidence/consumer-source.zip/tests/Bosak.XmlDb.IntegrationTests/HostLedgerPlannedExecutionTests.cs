// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Tests modeled ledger boundaries around real owner-bound planned publication.
// SPECIAL NOTES        : Test-only orchestration; memory commits are not durable host persistence or fencing.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Text;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Connects modeled ledger decisions to actual publication without a production host adapter.</summary>
public sealed class HostLedgerPlannedExecutionTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ha1-integration-" + Guid.NewGuid().ToString("N"));
    private string Artifact => Path.Combine(_area, "artifact");
    private string Destination => Path.Combine(_area, "destination");
    private static EpochPublicationKind Kind(bool epoch) => epoch ? EpochPublicationKind.IndependentEpochRestore : EpochPublicationKind.LegacyMigration;
    private static ScalarEpochAdministration Admin() => ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash));

    /// <summary>Explicit reads resolve modeled lost saves; execution waits for confirmed intent/authorization and is never replayed.</summary>
    /// <param name="epoch">Restore rather than migrate.</param>
    /// <param name="boundary">Modeled ledger save boundary.</param>
    /// <param name="fault">Before/after/no commit exception.</param>
    [Theory]
    [InlineData(false, "intent", 0)]
    [InlineData(false, "intent", 1)]
    [InlineData(false, "intent", 2)]
    [InlineData(false, "authorization", 0)]
    [InlineData(false, "authorization", 1)]
    [InlineData(false, "authorization", 2)]
    [InlineData(false, "receipt", 0)]
    [InlineData(false, "receipt", 1)]
    [InlineData(false, "receipt", 2)]
    [InlineData(true, "intent", 0)]
    [InlineData(true, "intent", 1)]
    [InlineData(true, "intent", 2)]
    [InlineData(true, "authorization", 0)]
    [InlineData(true, "authorization", 1)]
    [InlineData(true, "authorization", 2)]
    [InlineData(true, "receipt", 0)]
    [InlineData(true, "receipt", 1)]
    [InlineData(true, "receipt", 2)]
    public void LedgerSaveBoundaries_ResolveByReadWithoutPipelineReplay(bool epoch, string boundary, int fault)
    {
        Seed(epoch, 1); var inputs = Inputs(); var admin = Admin(); var plan = admin.PrepareAttempt(Kind(epoch), Artifact, Destination);
        var context = Context(plan); var ledger = new HostAttemptLedgerHarness(); var initial = new HostLedgerSnapshot(context, HostLedgerStage.Recorded);
        var attempts = 0;
        var recordFault = boundary == "intent" ? (HostLedgerCommitFault)fault : HostLedgerCommitFault.None;
        Commit(() => ledger.Record(Evidence(initial, original: true), recordFault), recordFault);
        Assert.False(Directory.Exists(Destination)); Assert.Equal(EpochAttemptState.Prepared, plan.State); Assert.Equal(0, attempts);
        var recorded = ledger.Read();
        if (recorded is null)
        {
            Assert.Equal("intent", boundary); Assert.Equal(1, fault);
            // Explicit read confirmed no modeled commit; the original live plan remains unconsumed.
            Assert.Equal(HostLedgerTransition.Applied, ledger.Record(Evidence(initial, original: true)));
            recorded = ledger.Read()!;
        }
        Assert.Equal(context, recorded.Context); Assert.Equal(HostLedgerStage.Recorded, recorded.Stage);
        var authFault = boundary == "authorization" ? (HostLedgerCommitFault)fault : HostLedgerCommitFault.None;
        Commit(() => ledger.Authorize(recorded, Evidence(recorded, original: true), authFault), authFault);
        Assert.False(Directory.Exists(Destination)); Assert.Equal(EpochAttemptState.Prepared, plan.State); Assert.Equal(0, attempts);
        var authorized = ledger.Read()!;
        if (authorized.Stage == HostLedgerStage.Recorded)
        {
            Assert.Equal("authorization", boundary); Assert.Equal(1, fault);
            Assert.Equal(HostLedgerTransition.Applied, ledger.Authorize(authorized, Evidence(authorized, original: true)));
            authorized = ledger.Read()!;
        }
        Assert.Equal(HostLedgerStage.DispatchAuthorized, authorized.Stage);
        Assert.Equal(plan.Describe(), authorized.Context.Intent); Assert.Equal(context.OwnerSession, authorized.Context.OwnerSession);
        Assert.Equal(HostLedgerTransition.Rejected, ledger.Authorize(authorized, Evidence(authorized, original: true)));
        // This test alone owns dispatch, still holds the exact original live plan and has not invoked it.
        attempts++; var receipt = admin.ExecuteAttempt(plan);
        Assert.Equal(plan.Describe().AttemptId, receipt.OperationId); Assert.Equal(EpochAttemptState.Dispatched, plan.State);
        var candidate = CaptureTree(Destination);
        var receiptFault = boundary == "receipt" ? (HostLedgerCommitFault)fault : HostLedgerCommitFault.None;
        Commit(() => ledger.Acknowledge(authorized, receipt, receiptFault), receiptFault);
        var saved = ledger.Read()!;
        if (saved.Stage != HostLedgerStage.Acknowledged)
        {
            Assert.Equal("receipt", boundary); Assert.Equal(1, fault); Assert.Null(saved.Receipt);
            // Retry only the modeled conditional receipt save, using the actual retained return value.
            Assert.Equal(HostLedgerTransition.Applied, ledger.Acknowledge(saved, receipt)); saved = ledger.Read()!;
        }
        Assert.Equal(receipt, saved.Receipt); Assert.Equal(HostLedgerStage.Acknowledged, saved.Stage); Assert.Equal(1, attempts);
        Assert.Equal(new[] { HostLedgerStage.Recorded, HostLedgerStage.DispatchAuthorized, HostLedgerStage.Acknowledged }, ledger.History().Select(x => x.Stage));
        Assert.Throws<InvalidOperationException>(() => admin.ExecuteAttempt(plan)); AssertTree(candidate, Destination);
        Assert.Equal(EpochInspectionStatus.KnownOperationMatched, admin.InspectPublication(plan.Describe().ToInspectionRequest()).Status);
        Assert.True(ledger.WritersMustRemainStopped); AssertInputs(inputs); ReadAll(receipt, 1);
    }

    /// <summary>Actual acknowledged publication retains every generation and the exact preannounced ID through the modeled ledger.</summary>
    /// <param name="epoch">Publication role.</param>
    /// <param name="count">Initial head.</param>
    [Theory]
    [InlineData(false, 0)]
    [InlineData(false, 3)]
    [InlineData(true, 0)]
    [InlineData(true, 3)]
    public void AcknowledgedPublication_RetainsBoundIdentityAndCompleteHistory(bool epoch, int count)
    {
        Seed(epoch, count); var inputs = Inputs(); var admin = Admin(); var plan = admin.PrepareAttempt(Kind(epoch), Artifact, Destination);
        var ledger = Authorized(plan); var authorized = ledger.Read()!; var receipt = admin.ExecuteAttempt(plan);
        Assert.Equal(HostLedgerTransition.Applied, ledger.Acknowledge(authorized, receipt));
        Assert.Equal(plan.Describe().AttemptId, ledger.Read()!.Receipt!.OperationId); ReadAll(receipt, count); AssertInputs(inputs);
    }

    /// <summary>Pipeline exceptions remain unacknowledged; fresh retry requires completed execution and explicit absence reconciliation.</summary>
    /// <param name="epoch">Publication role.</param>
    /// <param name="published">Throw after publication instead of after proof.</param>
    [Theory]
    [InlineData(false, false)]
    [InlineData(false, true)]
    [InlineData(true, false)]
    [InlineData(true, true)]
    public void PipelineFailure_SeparatesObservedPublicationFromReconciledAbsence(bool epoch, bool published)
    {
        Seed(epoch, 1); var inputs = Inputs();
        var admin = ScalarEpochAdministration.CreateCore(new(DurabilityMode.ProcessCrash), new LocalTransactionStorage(), stage =>
        {
            if (stage == (published ? EpochAdministrativeStage.Published : EpochAdministrativeStage.ProofVerified)) throw new IOException("Unacknowledged publication test.");
        });
        var plan = admin.PrepareAttempt(Kind(epoch), Artifact, Destination); var ledger = Authorized(plan); var authorized = ledger.Read()!;
        EpochPublishedReceipt? receipt = null; Assert.Throws<IOException>(() => receipt = admin.ExecuteAttempt(plan)); Assert.Null(receipt);
        Assert.Equal(EpochAttemptState.Dispatched, plan.State); Assert.Equal(HostLedgerTransition.Applied, ledger.MarkUncertain(authorized));
        var uncertain = ledger.Read()!; var before = CaptureTree(_area);
        var observation = Admin().InspectPublication(plan.Describe().ToInspectionRequest()); AssertTree(before, _area);
        Assert.Null(ledger.Read()!.Receipt);
        if (published)
        {
            Assert.Equal(EpochInspectionStatus.KnownOperationMatched, observation.Status);
            Assert.Equal(HostLedgerTransition.Applied, ledger.ObserveKnown(uncertain, Evidence(uncertain, observation: observation)));
            Assert.Equal(HostLedgerStage.ObservedKnown, ledger.Read()!.Stage); Assert.Null(ledger.Read()!.Receipt);
            Assert.Equal(HostLedgerTransition.Rejected, ledger.Acknowledge(ledger.Read(), null));
            Assert.Throws<IOException>(() => Admin().PrepareAttempt(Kind(epoch), Artifact, Destination));
        }
        else
        {
            Assert.Equal(EpochInspectionStatus.NotObserved, observation.Status);
            // The synchronous executor has returned; this test owns all dispatch and has no queued workers.
            Assert.Equal(HostLedgerTransition.Applied, ledger.ReconcileAbsent(uncertain, Evidence(uncertain, observation: observation)));
            var reconciled = ledger.Read()!; Assert.Equal(HostLedgerStage.ReconciledAbsent, reconciled.Stage);
            var nextAdmin = Admin(); var fresh = nextAdmin.PrepareAttempt(Kind(epoch), Artifact, Destination);
            Assert.NotEqual(plan.Describe().AttemptId, fresh.Describe().AttemptId);
            var nextLedger = Authorized(fresh, reconciled.Context.RequestId); var nextAuthorized = nextLedger.Read()!;
            var nextReceipt = nextAdmin.ExecuteAttempt(fresh); Assert.Equal(HostLedgerTransition.Applied, nextLedger.Acknowledge(nextAuthorized, nextReceipt));
            Assert.Equal(reconciled, ledger.Read()); Assert.Equal(reconciled.Context.RequestId, nextLedger.Read()!.Context.RequestId);
            Assert.NotEqual(reconciled.Context.Intent.AttemptId, nextLedger.Read()!.Context.Intent.AttemptId);
        }
        Assert.Throws<InvalidOperationException>(() => admin.ExecuteAttempt(plan)); AssertInputs(inputs);
    }

    /// <summary>A discarded actual return is reconciled by inspection without rebuilding an acknowledged receipt or executable plan.</summary>
    /// <param name="epoch">Publication role.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void LostReturn_RecordsOnlyKnownObservation(bool epoch)
    {
        Seed(epoch, 1); var inputs = Inputs(); var admin = Admin(); var plan = admin.PrepareAttempt(Kind(epoch), Artifact, Destination);
        var ledger = Authorized(plan); var authorized = ledger.Read()!;
        _ = admin.ExecuteAttempt(plan); // Simulate loss before the caller retains/persists the return value.
        Assert.Equal(HostLedgerTransition.Applied, ledger.MarkUncertain(authorized)); var uncertain = ledger.Read()!;
        var observer = Admin(); var before = CaptureTree(_area); var observation = observer.InspectPublication(plan.Describe().ToInspectionRequest());
        Assert.Equal(EpochInspectionStatus.KnownOperationMatched, observation.Status); AssertTree(before, _area);
        Assert.Equal(HostLedgerTransition.Applied, ledger.ObserveKnown(uncertain, Evidence(uncertain, observation: observation)));
        Assert.Null(ledger.Read()!.Receipt); Assert.Equal(plan.Describe().AttemptId, ledger.Read()!.Observed!.OperationId);
        Assert.Throws<ArgumentException>(() => observer.ExecuteAttempt(plan)); Assert.Throws<InvalidOperationException>(() => admin.ExecuteAttempt(plan));
        AssertTree(before, _area); AssertInputs(inputs);
    }

    /// <summary>Eight competing modeled authorizers cause one real pipeline dispatch and one retained acknowledged publication.</summary>
    /// <param name="epoch">Publication role.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ConcurrentAuthorization_OnlyWinnerInvokesRealPlan(bool epoch)
    {
        Seed(epoch, 1); var inputs = Inputs(); var admin = Admin(); var plan = admin.PrepareAttempt(Kind(epoch), Artifact, Destination);
        var ledger = new HostAttemptLedgerHarness(); var initial = new HostLedgerSnapshot(Context(plan), HostLedgerStage.Recorded);
        Assert.Equal(HostLedgerTransition.Applied, ledger.Record(Evidence(initial, original: true))); var recorded = ledger.Read()!;
        using var start = new ManualResetEventSlim(); var dispatched = 0;
        var workers = Enumerable.Range(0, 8).Select(_ => Task.Run(() =>
        {
            start.Wait(); var result = ledger.Authorize(recorded, Evidence(recorded, original: true));
            if (result != HostLedgerTransition.Applied) return (result, receipt: (EpochPublishedReceipt?)null);
            Interlocked.Increment(ref dispatched); return (result, receipt: (EpochPublishedReceipt?)admin.ExecuteAttempt(plan));
        })).ToArray();
        start.Set(); var results = await Task.WhenAll(workers); var winner = Assert.Single(results, x => x.result == HostLedgerTransition.Applied);
        Assert.Equal(7, results.Count(x => x.result == HostLedgerTransition.Conflict)); Assert.Equal(1, dispatched);
        Assert.Equal(plan.Describe().AttemptId, winner.receipt!.OperationId);
        Assert.Equal(HostLedgerTransition.Applied, ledger.Acknowledge(ledger.Read(), winner.receipt));
        Assert.Equal(3, ledger.History().Length); AssertInputs(inputs);
    }

    /// <summary>An actual active publisher defeats absence-based retry and unsafe takeover before it later completes.</summary>
    /// <param name="epoch">Publication role.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ActivePublisher_AbsenceDoesNotAuthorizeRetryOrTakeover(bool epoch)
    {
        Seed(epoch, 1); var inputs = Inputs(); using var reached = new ManualResetEventSlim(); using var release = new ManualResetEventSlim();
        var admin = ScalarEpochAdministration.CreateCore(new(DurabilityMode.ProcessCrash), new LocalTransactionStorage(), stage =>
        {
            if (stage != EpochAdministrativeStage.ProofVerified) return;
            reached.Set(); if (!release.Wait(TimeSpan.FromSeconds(30))) throw new TimeoutException("Publisher release.");
        });
        var plan = admin.PrepareAttempt(Kind(epoch), Artifact, Destination); var ledger = Authorized(plan); var authorized = ledger.Read()!;
        var execution = Task.Run(() => admin.ExecuteAttempt(plan)); EpochPublishedReceipt? receipt = null;
        try
        {
            Assert.True(reached.Wait(TimeSpan.FromSeconds(30))); var before = CaptureTree(_area);
            var observed = Admin().InspectPublication(plan.Describe().ToInspectionRequest()); Assert.Equal(EpochInspectionStatus.NotObserved, observed.Status);
            var evidence = Evidence(authorized, observation: observed); evidence = evidence with { Ownership = evidence.Ownership! with { AllPriorPublishersExcluded = false }, Record = evidence.Record! with { OriginalExecutor = true } };
            Assert.Equal(HostLedgerTransition.Rejected, ledger.ReconcileAbsent(authorized, evidence));
            Assert.Equal(HostLedgerTransition.Rejected, ledger.TakeOver(authorized, new(authorized.Context, true, true, false, true, true), Guid.NewGuid(), 2));
            Assert.Equal(authorized, ledger.Read()); AssertTree(before, _area);
        }
        finally { release.Set(); receipt = await execution; }
        Assert.Equal(HostLedgerTransition.Applied, ledger.Acknowledge(authorized, receipt)); AssertInputs(inputs);
    }

    /// <summary>A real publication from a different plan cannot acknowledge the retained attempt.</summary>
    /// <param name="epoch">Publication role.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void OtherAttemptReceipt_CannotAcknowledgeOriginalIntent(bool epoch)
    {
        Seed(epoch, 1); var inputs = Inputs(); var admin = Admin(); var original = admin.PrepareAttempt(Kind(epoch), Artifact, Destination);
        var ledger = Authorized(original); var authorized = ledger.Read()!;
        var foreign = admin.PrepareAttempt(Kind(epoch), Artifact, Path.Combine(_area, "other-destination")); var receipt = admin.ExecuteAttempt(foreign);
        Assert.NotEqual(original.Describe().AttemptId, receipt.OperationId);
        Assert.Equal(HostLedgerTransition.Rejected, ledger.Acknowledge(authorized, receipt)); Assert.Equal(authorized, ledger.Read());
        Assert.Equal(EpochAttemptState.Prepared, original.State); Assert.False(Directory.Exists(Destination)); AssertInputs(inputs);
    }

    private static void Commit(Func<HostLedgerTransition> operation, HostLedgerCommitFault fault)
    {
        if (fault == HostLedgerCommitFault.None) Assert.Equal(HostLedgerTransition.Applied, operation());
        else Assert.Throws<InvalidOperationException>(() => operation());
    }
    private static HostLedgerContext Context(EpochAdministrativeAttemptPlan plan, Guid? request = null) => new(request ?? Guid.NewGuid(), "test-deployment", Path.GetDirectoryName(plan.Describe().BundleRoot)!, plan.Describe(), 1, Guid.NewGuid(), 1);
    private static HostAttemptLedgerHarness Authorized(EpochAdministrativeAttemptPlan plan, Guid? request = null)
    {
        var ledger = new HostAttemptLedgerHarness(); var initial = new HostLedgerSnapshot(Context(plan, request), HostLedgerStage.Recorded);
        Assert.Equal(HostLedgerTransition.Applied, ledger.Record(Evidence(initial, original: true))); var recorded = ledger.Read()!;
        Assert.Equal(HostLedgerTransition.Applied, ledger.Authorize(recorded, Evidence(recorded, original: true))); return ledger;
    }
    // All host facts below model this test's private, queue-free dispatch scope. Memory save
    // confirmation is a protocol assumption, not a claim of durable host persistence.
    private static HostLedgerEvidence Evidence(HostLedgerSnapshot snapshot, bool original = false, EpochPublicationObservation? observation = null)
    {
        var c = snapshot.Context; var phase = snapshot.Stage switch
        {
            HostLedgerStage.Recorded => HostLedgerPhase.Recorded,
            HostLedgerStage.DispatchAuthorized => HostLedgerPhase.DispatchAuthorized,
            HostLedgerStage.Acknowledged => HostLedgerPhase.Acknowledged,
            _ => HostLedgerPhase.Uncertain
        };
        var state = observation?.Status switch
        {
            EpochInspectionStatus.KnownOperationMatched => HostPublicationState.KnownAttempt,
            EpochInspectionStatus.NotObserved => HostPublicationState.Absent,
            _ => HostPublicationState.Unknown
        };
        return new(c, new(c, true, true, true, phase, HostLedgerSave.ConfirmedDurable, original, original, original, false, snapshot.Receipt),
            new(c, true, true, true, true, true), new(c, true, state, observation?.Observed), new(c, true, false, false, true, true, snapshot.Observed is not null || snapshot.Receipt is not null));
    }
    private void Seed(bool epoch, int count)
    {
        Directory.CreateDirectory(_area); var source = Path.Combine(_area, "source"); var legacy = epoch ? Path.Combine(_area, "legacy") : Artifact;
        using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, source);
        using (var owner = EmbeddedXmlDatabase.Open(source))
        { using var read = owner.BeginRead(); for (var index = 1; index <= count; index++) { using var tx = owner.BeginWrite(); tx.ReplaceNodeValue(Target(read), "new-" + index); tx.Commit(); } owner.CreateBackup(legacy); }
        if (!epoch) return;
        var result = EpochLegacyMigration.Convert(legacy, Path.Combine(_area, "initial"));
        using var candidate = ScalarEpochDatabase.Open(result.StorePath, new(DurabilityMode.ProcessCrash, ScalarEpochRecovery.FullHistory)); candidate.CreateBackup(Artifact);
    }
    private static void ReadAll(EpochPublishedReceipt result, int count)
    {
        using var admission = EpochAdmission.Acquire(result.StorePath, result.DestinationEpoch, profile: EpochProfile.ScalarWal);
        var binding = EpochEmptyCoordinator.ReadAuthority(result.StorePath, result.DestinationEpoch, true);
        for (ulong sequence = 0; sequence <= (ulong)count; sequence++)
        {
            var hash = sequence == 0 ? binding.BaseHash : EpochAuthorityCodec.DecodeWal(File.ReadAllBytes(Path.Combine(result.StorePath, ".transactions", "wal", EpochAuthorityCodec.WalFileName(sequence))), binding).ManifestHash;
            using var read = EpochScalarHistory.Open(result.StorePath, sequence, admission, hash); Assert.Equal(sequence == 0 ? "old" : "new-" + sequence, read.ReadValue(Target(read)));
        }
    }
    private static ulong Target(ImmutableXmlSnapshot read) => Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id)).Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();
    private sealed record Tree(string[] Directories, Dictionary<string, byte[]> Files);
    private static Tree CaptureTree(string root) => new(Directory.GetDirectories(root, "*", SearchOption.AllDirectories).Order().ToArray(), Directory.GetFiles(root, "*", SearchOption.AllDirectories).ToDictionary(path => path, File.ReadAllBytes));
    private static void AssertTree(Tree before, string root) { var after = CaptureTree(root); Assert.Equal(before.Directories, after.Directories); Assert.Equal(before.Files.Keys.Order(), after.Files.Keys.Order()); foreach (var pair in before.Files) Assert.Equal(pair.Value, after.Files[pair.Key]); }
    private Dictionary<string, Tree> Inputs() => Directory.GetDirectories(_area).Where(path => path != Destination && !Path.GetFileName(path).StartsWith(".xmldb-", StringComparison.Ordinal)).ToDictionary(path => path, CaptureTree);
    private static void AssertInputs(Dictionary<string, Tree> before) { foreach (var pair in before) AssertTree(pair.Value, pair.Key); }
    /// <summary>Deletes only this GUID-owned test tree after all publishers, readers and proof handles close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
