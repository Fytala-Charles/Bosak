// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Qualifies paired inspection ownership across processes and real filesystem aliases.
// SPECIAL NOTES        : Fresh private test roots only; no live store, provisioning capability or write authority is exercised.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Qualifies paired inspection ownership across processes and real filesystem aliases.</summary>
public sealed class ApplicationAuthorityLifetimeProcessTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ep7c-process-" + Guid.NewGuid().ToString("N"));
    private string Host => Path.Combine(_area, "host");
    private string Root => Path.Combine(_area, "authority");
    private string Data => Path.Combine(_area, "source");
    private static Guid Admin => Guid.Parse("20314253-6475-8697-a8b9-cadbecfd0e1f");
    private static Guid Authority => Guid.Parse("10213243-5465-7687-98a9-bacbdcedfe0f");
    private static ApplicationAuthorityConfiguration Configuration() => new(Authority, Admin, "embedded-pilot", "orders", "admin-root", "application-root");
    private Dictionary<string, string> Roots(string? authority = null, string? source = null) => new()
    { ["admin-root"] = Host, ["application-root"] = authority ?? Root, ["source-root"] = source ?? Data };
    private void Seed()
    {
        Directory.CreateDirectory(Host); Directory.CreateDirectory(Root); Directory.CreateDirectory(Data);
        File.WriteAllBytes(Path.Combine(Host, "owner.lock"), []);
        File.WriteAllBytes(Path.Combine(Host, "host.meta"), HostJournalCodec.EncodeMetadata(Admin, "embedded-pilot", "orders"));
        File.WriteAllBytes(Path.Combine(Host, "journal.bin"), []);
        File.WriteAllBytes(Path.Combine(Root, "authority.lock"), []);
        File.WriteAllBytes(Path.Combine(Root, "authority.meta"), ApplicationAuthorityCodec.EncodeMetadata(Configuration()));
        File.WriteAllBytes(Path.Combine(Root, "authority.log"), Convert.FromHexString(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "TestData", "application-authority-enroll-v1.hex")).Trim()));
    }
    private EmbeddedHostLifetime Parent() => EmbeddedHostLifetime.OpenExisting(Host, "embedded-pilot", "orders", [Data, Root]);
    private ApplicationAuthorityLifetime Open(EmbeddedHostLifetime parent, string? root = null, string? source = null) => ApplicationAuthorityLifetime.OpenExisting(parent,
        parent.JournalStatus.KnownPosition, new(parent.Context, true, true, true, true, true), root ?? Root, Configuration(), Roots(root, source));
    private Dictionary<string, byte[]> Bytes() => new[] { Host, Root }.SelectMany(Directory.GetFiles)
        .ToDictionary(p => Path.GetRelativePath(_area, p), File.ReadAllBytes);
    private void AssertBytes(Dictionary<string, byte[]> before)
    {
        var actual = Bytes(); Assert.Equal(before.Keys.Order(), actual.Keys.Order()); foreach (var pair in before) Assert.Equal(pair.Value, actual[pair.Key]);
    }
    private Process Start(string mode)
    {
        var info = new ProcessStartInfo("dotnet") { RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false, CreateNoWindow = true };
        foreach (var argument in new[] { typeof(ApplicationAuthorityLifetimeProcessTests).Assembly.Location, "ep7c-hold", Host, Root, Data, Authority.ToString(), Admin.ToString(), mode }) info.ArgumentList.Add(argument);
        return Process.Start(info) ?? throw new InvalidOperationException("Cannot start paired lifetime probe.");
    }
    private static async Task Line(Process process, string expected) => Assert.Equal(expected, await process.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(30)));
    private static async Task Stop(Process process) { if (!process.HasExited) { process.Kill(true); await process.WaitForExitAsync(); } }

    /// <summary>Actual process exit or graceful drain releases both unchanged role sets only after the real read ends.</summary>
    /// <param name="mode">Exit, kill or paused-read drain boundary.</param>
    /// <returns>A task that completes when qualification finishes.</returns>
    [Theory]
    [InlineData("exit")]
    [InlineData("kill")]
    [InlineData("drain")]
    [InlineData("kill-drain")]
    public async Task PairedOwnership_ProcessExitAndDrain_RetainsBothLeases(string mode)
    {
        Seed(); var before = Bytes();
        for (var repeat = 0; repeat < 3; repeat++)
        {
            using var child = Start(mode); var errors = child.StandardError.ReadToEndAsync();
            try
            {
                await Line(child, "ACQUIRED"); if (mode is "drain" or "kill-drain") await Line(child, "DRAINING");
                Assert.Throws<IOException>(() => { using var contender = Parent(); });
                Assert.Throws<IOException>(() => { using var contender = new FileStream(Path.Combine(Root, "authority.lock"), FileMode.Open, FileAccess.ReadWrite, FileShare.None); });
                if (mode.StartsWith("kill", StringComparison.Ordinal)) child.Kill(true);
                else
                {
                    await child.StandardInput.WriteLineAsync("continue"); await child.StandardInput.FlushAsync(); await Line(child, "RELEASED");
                    Assert.False(child.HasExited);
                    using (var parent = Parent()) using (var authority = Open(parent)) Assert.True(authority.Inspect().WritersMustRemainStopped);
                    await child.StandardInput.WriteLineAsync("exit"); await child.StandardInput.FlushAsync();
                }
                await child.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30));
                if (!mode.StartsWith("kill", StringComparison.Ordinal)) Assert.True(child.ExitCode == 0, await errors);
                using (var parent = Parent()) using (var authority = Open(parent)) Assert.True(authority.WritersMustRemainStopped);
                AssertBytes(before);
            }
            finally { await Stop(child); _ = await errors; }
        }
    }

    /// <summary>Hard-linked owner, metadata and log roles reject even when their bytes and checksums are valid.</summary>
    /// <param name="role">Role with a second directory entry.</param>
    /// <returns>A task that completes when qualification finishes.</returns>
    [Theory]
    [InlineData("authority.lock")]
    [InlineData("authority.meta")]
    [InlineData("authority.log")]
    public async Task HardLinkedRole_RejectsWithoutMutation(string role)
    {
        Seed(); var peer = Path.Combine(_area, "peer"); var path = Path.Combine(Root, role);
        File.Move(path, peer); await Link(path, peer, true); var before = Bytes(); var peerBytes = File.ReadAllBytes(peer);
        using (var parent = Parent()) Assert.Throws<InvalidDataException>(() => Open(parent));
        AssertBytes(before); Assert.Equal(peerBytes, File.ReadAllBytes(peer));
    }

    /// <summary>Root, ancestor, protected-path and role reparse aliases reject without namespace repair.</summary>
    /// <param name="placement">Location of the actual directory link/junction.</param>
    /// <returns>A task that completes when qualification finishes.</returns>
    [Theory]
    [InlineData("root")]
    [InlineData("ancestor")]
    [InlineData("source")]
    [InlineData("metadata")]
    public async Task LinkedPlacement_RejectsWithoutRepair(string placement)
    {
        Seed(); var link = Path.Combine(_area, "alias"); string? root = null, source = null; byte[]? original = null;
        if (placement == "metadata") { link = Path.Combine(Root, "authority.meta"); original = File.ReadAllBytes(link); File.Delete(link); }
        await Link(link, placement == "ancestor" ? _area : placement is "source" or "metadata" ? Data : Root, false);
        try
        {
            if (placement == "root") root = link;
            if (placement == "ancestor") root = Path.Combine(link, "authority");
            if (placement == "source") source = link;
            var before = Bytes(); var inventory = Directory.GetFileSystemEntries(Root).Select(Path.GetFileName).Order().ToArray();
            using (var parent = Parent()) Assert.Throws<InvalidDataException>(() => Open(parent, root, source));
            AssertBytes(before); Assert.Equal(inventory, Directory.GetFileSystemEntries(Root).Select(Path.GetFileName).Order().ToArray());
        }
        finally { Directory.Delete(link); if (original is not null) File.WriteAllBytes(link, original); }
    }

    /// <summary>Protected namespace changes during acquisition or an owned read are detected, never silently adopted.</summary>
    /// <param name="acquisition">Whether the change occurs at acquisition rather than a later inspection.</param>
    /// <returns>A task that completes when qualification finishes.</returns>
    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task ProtectedNamespaceChanged_RejectsAndStaysStopped(bool acquisition)
    {
        Seed(); var before = Bytes(); using var parent = Parent(); ApplicationAuthorityLifetime? authority = null; var linked = false;
        async Task Change()
        {
            Directory.Delete(Data); await Link(Data, Root, false); linked = true;
        }
        try
        {
            if (acquisition)
            {
                Assert.Throws<InvalidDataException>(() => ApplicationAuthorityLifetime.OpenExistingCore(parent, parent.JournalStatus.KnownPosition,
                    new(parent.Context, true, true, true, true, true), Root, Configuration(), Roots(), stage => { if (stage == ApplicationInspectionStage.OwnerOpened) Change().GetAwaiter().GetResult(); }));
                Assert.Equal(0, parent.ActiveOperations);
            }
            else
            {
                authority = Open(parent); await Change(); Assert.Throws<InvalidDataException>(() => authority.Inspect()); Assert.True(authority.IsFaulted);
                Directory.Delete(Data); linked = false; Directory.CreateDirectory(Data);
                Assert.Throws<InvalidOperationException>(() => authority.Inspect());
            }
        }
        finally
        {
            authority?.Dispose(); parent.Dispose(); if (linked) { Directory.Delete(Data); Directory.CreateDirectory(Data); }
        }
        AssertBytes(before);
    }

    /// <summary>Linux FIFO roles fail before content reads; Windows rows are explicit guards, not FIFO execution evidence.</summary>
    /// <param name="role">Non-regular role.</param>
    /// <returns>A task that completes when qualification finishes.</returns>
    [Theory]
    [InlineData("authority.lock")]
    [InlineData("authority.meta")]
    [InlineData("authority.log")]
    public async Task FifoRole_LinuxOnly_RejectsWithoutBlocking(string role)
    {
        if (!OperatingSystem.IsLinux()) return;
        Seed(); var path = Path.Combine(Root, role); File.Delete(path); await Utility("mkfifo", [path]);
        using var parent = Parent(); Assert.Throws<InvalidDataException>(() => Open(parent)); Assert.Equal(0, parent.ActiveOperations);
    }

    private static Task Link(string link, string target, bool hard)
    {
        if (OperatingSystem.IsWindows()) return Utility("cmd.exe", ["/c", "mklink", hard ? "/H" : "/J", link, target]);
        if (hard) return Utility("ln", [target, link]);
        Directory.CreateSymbolicLink(link, target); return Task.CompletedTask;
    }
    private static async Task Utility(string command, string[] arguments)
    {
        var info = new ProcessStartInfo(command) { UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true };
        foreach (var argument in arguments) info.ArgumentList.Add(argument);
        using var process = Process.Start(info) ?? throw new InvalidOperationException("Cannot run native fixture utility.");
        var stdout = process.StandardOutput.ReadToEndAsync(); var stderr = process.StandardError.ReadToEndAsync();
        await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(15)); Assert.True(process.ExitCode == 0, await stdout + await stderr);
    }
    /// <summary>Removes only this fixture's owned private tree after process and role-handle release.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
