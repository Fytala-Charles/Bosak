// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies epoch scalar commit publication and reopening in independent processes.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 27-10-2026     | Verify commit and repeated redo process kills across publication
//                      | Charles Korthout | 0.3   | 27-10-2026     | Verify interrupted multi-generation redo with retained late witnesses and old readers
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Bosak.XmlDb.Storage;
using Bosak.XmlDb.Xdm;
using Bosak.XPath.Api;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Verifies scalar publication and complete-chain process reopen.</summary>
public sealed class EpochScalarProcessTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-et5-process-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "epoch");
    private string Source => Path.Combine(_area, "source");

    /// <summary>A returned commit and complete publication survive process exit, kill and lost acknowledgment.</summary>
    /// <param name="stage">Publication or acknowledgment boundary.</param>
    [Theory]
    [InlineData("normal")]
    [InlineData("GenerationPublished")]
    [InlineData("BeforeCurrent")]
    [InlineData("ACK")]
    public async Task Commit_FreshProcess_ReopensVerifiedNewState(string stage)
    {
        Seed(); var source = Bytes(Source);
        var write = await Run(stage == "ACK" ? "et5-write-ack" : "et5-write", stage);
        if (stage == "normal") Assert.Equal(0, write.Code);
        else { Assert.NotEqual(0, write.Code); Assert.Contains(stage == "ACK" ? "ET5-ACK" : "ET5-FAULT:" + stage, write.Output); }
        for (var repeat = 0; repeat < 2; repeat++)
        {
            var reopened = await Run("et5-read"); Assert.True(reopened.Code == 0, reopened.Error);
            using var json = JsonDocument.Parse(reopened.Output); Assert.Equal("ET5-new", json.RootElement.GetProperty("Value").GetString());
            Assert.Equal(1, json.RootElement.GetProperty("CommitSequence").GetInt32());
        }
        AssertBytes(source, Source);
    }

    /// <summary>An old uncached reader retains all node identities and values across a commit and owner replacement.</summary>
    [Fact]
    public void Commit_PinnedSnapshot_PreservesExactMetadataAndLazyXPathParity()
    {
        Seed(); using var expected = ImmutableXmlSnapshot.Open(Source, cacheBytes: 0);
        var owner = EpochScalarCoordinator.Open(Root); using var old = owner.BeginRead(0);
        var target = Enumerable.Range(1, old.NodeCount).Select(id => old.GetNode((ulong)id))
            .Single(node => node.LocalName == "DocumentID").Children.Single();
        using (var transaction = owner.BeginTransaction()) { transaction.ReplaceNodeValue(target, "ET5-new"); transaction.Commit(); }
        owner.Dispose(); using var next = EpochScalarCoordinator.Open(Root); using var current = next.BeginRead(0);
        Assert.Equal(expected.DocumentUri, current.DocumentUri); Assert.Equal(expected.NodeCount, current.NodeCount);
        for (ulong id = 1; id <= (ulong)old.NodeCount; id++)
        {
            var before = expected.GetNode(id); var after = current.GetNode(id);
            Assert.Equal(before with { ValueOffset = after.ValueOffset, ValueLength = after.ValueLength, Children = after.Children, Attributes = after.Attributes, Namespaces = after.Namespaces }, after);
            Assert.Equal(before.Children, after.Children); Assert.Equal(before.Attributes, after.Attributes); Assert.Equal(before.Namespaces, after.Namespaces);
            Assert.Equal(expected.ReadValue(id), old.ReadValue(id));
            Assert.Equal(id == target ? "ET5-new" : expected.ReadValue(id), current.ReadValue(id));
        }
        foreach (var query in new[] { "string(/SalesOrder/SalesOrderHeader/DocumentID)", "string(count(/SalesOrder/SalesOrderLine))", "string(/SalesOrder/SalesOrderLine[last()]/Item/ItemID)" })
            Assert.Equal(XPath31Expression.Compile(query).Evaluate(new PersistentXdmNode(expected)).StringValue,
                XPath31Expression.Compile(query).Evaluate(new PersistentXdmNode(old)).StringValue);
    }

    /// <summary>Updating a line fragment leaves the header intact and old lazy line reads pinned across owners.</summary>
    [Fact]
    public void Commit_LineFragment_PreservesHeaderAndOldUncachedValues()
    {
        Seed(); var owner = EpochScalarCoordinator.Open(Root); using var old = owner.BeginRead(0);
        var target = Enumerable.Range(1, old.NodeCount).Select(id => old.GetNode((ulong)id))
            .Last(node => node.LocalName == "ItemID").Children.Single();
        using (var transaction = owner.BeginTransaction()) { transaction.ReplaceNodeValue(target, "changed-line"); transaction.Commit(); }
        owner.Dispose(); using var next = EpochScalarCoordinator.Open(Root); using var current = next.BeginRead(0);
        Assert.Equal("20", old.ReadValue(target)); Assert.Equal("changed-line", current.ReadValue(target));
        Assert.True(old.Metrics.LineFragmentReads > 0);
        Assert.Equal("SO-1", XPath31Expression.Compile("string(/SalesOrder/SalesOrderHeader/DocumentID)").Evaluate(new PersistentXdmNode(current)).StringValue);
    }

    /// <summary>Process exit before WAL or after complete WAL selects old state or exact redo respectively.</summary>
    /// <param name="stage">Commit interruption boundary.</param>
    [Theory]
    [InlineData("BeforeWal")]
    [InlineData("WalFlushed")]
    [InlineData("ReaderPublished")]
    [InlineData("CurrentPublished")]
    [InlineData("Committed")]
    public async Task Commit_ProcessKilledAtRemainingBoundaries_ReopensExactHead(string stage)
    {
        Seed(); var killed = await Run("et5-write", stage); Assert.NotEqual(0, killed.Code); Assert.Contains("ET5-FAULT:" + stage, killed.Output);
        for (var repeat = 0; repeat < 2; repeat++)
        {
            var result = await Run("et5-read"); Assert.True(result.Code == 0, result.Error); using var json = JsonDocument.Parse(result.Output);
            Assert.Equal(stage == "BeforeWal" ? "SO-1" : "ET5-new", json.RootElement.GetProperty("Value").GetString());
            Assert.Equal(stage == "BeforeWal" ? 0 : 1, json.RootElement.GetProperty("CommitSequence").GetInt32());
        }
    }

    /// <summary>Repeated recovery kills retain intact WAL and eventually reproduce the same materialization.</summary>
    /// <param name="stage">Redo interruption boundary.</param>
    [Theory]
    [InlineData("RecoveryStageWritten")]
    [InlineData("RecoveryGenerationPublished")]
    [InlineData("RecoveryCurrentPublished")]
    public async Task Redo_ProcessKilled_RepeatsWithoutLosingCommitAuthority(string stage)
    {
        Seed(); var write = await Run("et5-write", "WalFlushed"); Assert.NotEqual(0, write.Code);
        var wal = Path.Combine(Root, ".transactions", "wal", EpochAuthorityCodec.WalFileName(1)); var bytes = File.ReadAllBytes(wal);
        for (var repeat = 0; repeat < (stage == "RecoveryStageWritten" ? 2 : 1); repeat++)
        { var killed = await Run("et5-read", stage); Assert.NotEqual(0, killed.Code); Assert.Contains("ET5-FAULT:" + stage, killed.Output); }
        for (var repeat = 0; repeat < 2; repeat++)
        {
            var result = await Run("et5-read"); Assert.True(result.Code == 0, result.Error); using var json = JsonDocument.Parse(result.Output);
            Assert.Equal("ET5-new", json.RootElement.GetProperty("Value").GetString()); Assert.Equal(1, json.RootElement.GetProperty("CommitSequence").GetInt32());
        }
        Assert.Equal(bytes, File.ReadAllBytes(wal));
    }

    /// <summary>Successive process kills redo multiple generations while an old uncached reader retains admission and stable data.</summary>
    /// <param name="keepLater">Whether a later published generation survives while its predecessors are missing.</param>
    /// <param name="strong">Whether native Linux directory barriers are requested.</param>
    [Theory]
    [InlineData(false, false)]
    [InlineData(true, false)]
    [InlineData(false, true)]
    [InlineData(true, true)]
    public async Task Redo_MultipleMissingGenerationsAndKills_PreservesExactHistoryAndPinnedSnapshot(bool keepLater, bool strong)
    {
        if (strong && !OperatingSystem.IsLinux()) return;
        Seed(); var owner = EpochScalarCoordinator.Open(Root); using var old = owner.BeginRead(0);
        try
        {
            var header = Enumerable.Range(1, old.NodeCount).Select(id => old.GetNode((ulong)id)).Single(node => node.LocalName == "DocumentID").Children.Single();
            var line = Enumerable.Range(1, old.NodeCount).Select(id => old.GetNode((ulong)id)).Last(node => node.LocalName == "ItemID").Children.Single();
            for (var index = 1; index <= 3; index++)
            { using var tx = owner.BeginTransaction(); tx.ReplaceNodeValue(index == 2 ? line : header, index == 1 ? "ET7-one" : index == 2 ? "ET7-line" : "ET7-three"); tx.Commit(); }
            owner.Dispose();
            var expected = Bytes(Root); var identity = EpochAdmission.ReadIdentity(Root, EpochProfile.ScalarWal);
            var expectedHead = EpochEmptyCoordinator.ReadAuthority(Root, identity, true);
            var first = EpochAuthorityCodec.DecodeWal(File.ReadAllBytes(Path.Combine(Root, ".transactions", "wal", EpochAuthorityCodec.WalFileName(1))), expectedHead);
            File.WriteAllBytes(Path.Combine(Root, ".transactions", "CURRENT"), EpochAuthorityCodec.EncodeCurrent(new(expectedHead, 1, first.ManifestHash,
                System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(Path.Combine(Root, ".transactions", "wal", EpochAuthorityCodec.WalFileName(1)))))));
            for (ulong sequence = 1; sequence <= (keepLater ? 2UL : 3UL); sequence++) Directory.Delete(EpochScalarHistory.Generation(Root, sequence), true);
            var action = strong ? "et7-read-strong" : "et5-read";
            for (var index = 0; index < (keepLater ? 2 : 3); index++)
            {
                var killed = await Run(action, "RecoveryGenerationPublished"); Assert.NotEqual(0, killed.Code); Assert.Contains("ET5-FAULT:RecoveryGenerationPublished", killed.Output);
                Assert.Throws<IOException>(() => EpochAdmission.Acquire(Root, identity, true, EpochProfile.ScalarWal));
                Assert.Equal("SO-1", old.ReadValue(header)); Assert.Equal("20", old.ReadValue(line));
            }
            for (var repeat = 0; repeat < 2; repeat++)
            {
                var result = await Run(action); Assert.True(result.Code == 0, result.Error); using var json = JsonDocument.Parse(result.Output);
                Assert.Equal("ET7-three", json.RootElement.GetProperty("Value").GetString()); Assert.Equal(3, json.RootElement.GetProperty("CommitSequence").GetInt32());
            }
            AssertBytes(expected, Root);
            using var reopened = EpochScalarCoordinator.Open(Root); using var read = reopened.BeginRead(0);
            Assert.Equal("ET7-line", read.ReadValue(line)); Assert.Equal(old.DocumentUri, read.DocumentUri); Assert.Equal(old.NodeCount, read.NodeCount);
        }
        finally { owner.Dispose(); }
    }

    private void Seed()
    {
        Directory.CreateDirectory(_area);
        var xml = "<SalesOrder><SalesOrderHeader><DocumentID>SO-1</DocumentID></SalesOrderHeader>" +
            string.Concat(Enumerable.Range(1, 20).Select(id => $"<SalesOrderLine number='{id}'><Item><ItemID>{id}</ItemID></Item></SalesOrderLine>")) + "</SalesOrder>";
        using var input = new MemoryStream(Encoding.UTF8.GetBytes(xml));
        XmlFragmentImporter.Import(input, Source, linesPerFragment: 4, documentUri: "https://example.test/et4.xml");
        EpochEmptyRoot.CreateFixture(Source, Root, 1, new LocalTransactionStorage());
    }
    private static Dictionary<string, byte[]> Bytes(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories).ToDictionary(path => Path.GetRelativePath(root, path), File.ReadAllBytes);
    private static void AssertBytes(Dictionary<string, byte[]> before, string root)
    { var after = Bytes(root); Assert.Equal(before.Keys.Order(), after.Keys.Order()); foreach (var item in before) Assert.Equal(item.Value, after[item.Key]); }
    private Process Start(string action, string? argument = null)
    {
        var info = new ProcessStartInfo("dotnet") { RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false };
        info.ArgumentList.Add(typeof(EpochScalarProcessTests).Assembly.Location); info.ArgumentList.Add(action); info.ArgumentList.Add(Root);
        if (argument is not null) info.ArgumentList.Add(argument);
        return Process.Start(info) ?? throw new InvalidOperationException("Cannot start ET5 probe.");
    }
    private async Task<(int Code, string Output, string Error)> Run(string action, string? argument = null)
    {
        using var process = Start(action, argument); var stdout = process.StandardOutput.ReadToEndAsync(); var stderr = process.StandardError.ReadToEndAsync();
        try { await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); }
        catch { if (!process.HasExited) process.Kill(true); throw; }
        return (process.ExitCode, await stdout, await stderr);
    }
    /// <inheritdoc />
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
