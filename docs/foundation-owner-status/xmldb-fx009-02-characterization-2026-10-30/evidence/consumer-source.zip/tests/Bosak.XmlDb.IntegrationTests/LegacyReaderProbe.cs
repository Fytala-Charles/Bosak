// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Runs frozen format-1 public open paths in an isolated assembly load context.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 27-10-2026     | Probe frozen immutable epoch reader against mutable profiles
//                      | Charles Korthout | 0.3   | 28-10-2026     | Classify exact missing wrapper FORMAT without accepting unrelated probe failures
// ===========================================================================================================================================================

using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;

namespace Bosak.XmlDb.IntegrationTests;

internal static class LegacyReaderProbe
{
    internal static int RunImmutableEpoch(string root)
    {
        var directory = Path.Combine(AppContext.BaseDirectory, "LegacyEpochReader");
        var storage = Path.Combine(directory, "Bosak.XmlDb.Storage.dll"); var core = Path.Combine(directory, "Bosak.XmlDb.Core.dll");
        if (Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(storage))) != "3DCC349ECDF97053F46E5DF69F42DD519C7C00F4C22D22E89AC62538E1FF818B" ||
            Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(core))) != "60A9AF0EED267CB20D55FFB507ED3AE2C5102A5C18C0151D45E99B701E590804")
            throw new InvalidDataException("Frozen immutable epoch reader changed.");
        var context = new AssemblyLoadContext("FrozenImmutableEpochReader", isCollectible: true);
        try
        {
            _ = context.LoadFromAssemblyPath(core);
            var assembly = context.LoadFromAssemblyPath(storage);
            var type = assembly.GetType("Bosak.XmlDb.Storage.ReadOnlyEpochDatabase", throwOnError: true)!;
            var method = type.GetMethod("Open", [typeof(string)]) ?? throw new MissingMethodException("Frozen epoch Open missing.");
            try
            {
                (method.Invoke(null, [root]) as IDisposable)?.Dispose();
                Console.WriteLine("UNEXPECTEDLY-ACCEPTED"); return 0;
            }
            catch (TargetInvocationException exception) when (exception.InnerException is InvalidDataException { Message: "Invalid mandatory epoch format framing, version or checksum." } || MissingWrapperFormat(exception.InnerException, root))
            { Console.WriteLine("FROZEN-IMMUTABLE-EPOCH-REJECTED"); return 23; }
        }
        finally { context.Unload(); }
    }

    internal static int Run(string root, string operation)
    {
        var directory = Path.Combine(AppContext.BaseDirectory, "LegacyReader");
        var storagePath = Path.Combine(directory, "Bosak.XmlDb.Storage.dll");
        var corePath = Path.Combine(directory, "Bosak.XmlDb.Core.dll");
        if (Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(storagePath))) != "88C16E73BCCF0641B8BCC1392C4AB9D038CD9BBD025100EB5CC6404A5BA0D67C" ||
            Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(corePath))) != "60A9AF0EED267CB20D55FFB507ED3AE2C5102A5C18C0151D45E99B701E590804")
            throw new InvalidDataException("Frozen format-1 reader fixture changed.");
        var context = new AssemblyLoadContext("FrozenFormat1Reader", isCollectible: true);
        try
        {
            _ = context.LoadFromAssemblyPath(corePath);
            var assembly = context.LoadFromAssemblyPath(storagePath);
            var owner = assembly.GetType(operation == "raw" ? "Bosak.XmlDb.Storage.ImmutableXmlSnapshot" : "Bosak.XmlDb.Storage.EmbeddedXmlDatabase", throwOnError: true)!;
            var durability = assembly.GetType("Bosak.XmlDb.Storage.DurabilityMode", throwOnError: true)!;
            var recovery = assembly.GetType("Bosak.XmlDb.Storage.RecoveryMode", throwOnError: true)!;
            object[] args = operation switch
            {
                "raw" => [root, 1UL, 0],
                "coordinator" => [root, 1UL],
                "durability" => [root, Enum.ToObject(durability, 0), 1UL],
                "recovery" => [root, Enum.ToObject(recovery, 0), Enum.ToObject(durability, 0), 1UL],
                _ => throw new ArgumentException("Unknown legacy probe operation.", nameof(operation)),
            };
            var method = owner.GetMethod("Open", args.Select(value => value.GetType()).ToArray()) ?? throw new MissingMethodException("Frozen Open overload missing.");
            try
            {
                var accepted = method.Invoke(null, args);
                (accepted as IDisposable)?.Dispose();
                Console.WriteLine("UNEXPECTEDLY-ACCEPTED");
                return 0;
            }
            catch (TargetInvocationException exception) when (exception.InnerException is InvalidDataException ||
                operation == "raw" && exception.InnerException is InvalidOperationException { Message: "This store uses transactions. Open EmbeddedXmlDatabase and call BeginRead for recovery and generation selection." } || MissingWrapperFormat(exception.InnerException, root))
            {
                Console.WriteLine("FROZEN-FORMAT1-REJECTED:" + operation);
                return 23;
            }
        }
        finally { context.Unload(); }
    }
    private static bool MissingWrapperFormat(Exception? exception, string root) =>
        (exception is FileNotFoundException missing && missing.FileName == Path.Combine(root, "FORMAT") ||
            exception is InvalidDataException { Message: "Store paths must not traverse symbolic links or junctions." }) &&
        !File.Exists(Path.Combine(root, "FORMAT")) && File.Exists(Path.Combine(root, "migration.bin")) &&
        Directory.Exists(Path.Combine(root, "store"));

}
