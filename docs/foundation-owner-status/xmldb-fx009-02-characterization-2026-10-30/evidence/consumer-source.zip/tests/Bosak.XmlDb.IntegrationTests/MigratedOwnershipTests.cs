// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Verifies migrated child creation, owner disposal races and cross-process holder release.
// SPECIAL NOTES        : Local baseline compatibility only; no archived release or actual routing claim.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Qualifies local migrated-candidate child lifetime and concurrent owner disposal.</summary>
public sealed class MigratedOwnershipTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ca2-" + Guid.NewGuid().ToString("N"));

    /// <summary>Ordered and simultaneous child creation/disposal either retain a valid independent child or reject without leaked admission.</summary>
    /// <param name="count">Migrated history length.</param>
    /// <param name="transaction">Whether the child is a transaction.</param>
    /// <param name="schedule">Child-first, owner-first, or simultaneous execution.</param>
    [Theory]
    [InlineData(0, false, "child-first")]
    [InlineData(0, false, "owner-first")]
    [InlineData(0, false, "simultaneous")]
    [InlineData(0, true, "child-first")]
    [InlineData(0, true, "owner-first")]
    [InlineData(0, true, "simultaneous")]
    [InlineData(3, false, "child-first")]
    [InlineData(3, false, "owner-first")]
    [InlineData(3, false, "simultaneous")]
    [InlineData(3, true, "child-first")]
    [InlineData(3, true, "owner-first")]
    [InlineData(3, true, "simultaneous")]
    public async Task ChildCreation_RacesOwnerDispose_HasBoundedOwnershipOutcome(int count, bool transaction, string schedule)
    {
        var result = Prepare(count); var before = Capture(result.StorePath);
        // Ordered schedules prove both endpoints; repeated simultaneous schedules exercise the race
        // without requiring a particular scheduler winner or introducing production test hooks.
        for (var repeat = 0; repeat < 12; repeat++)
        {
            using var owner = EpochScalarCoordinator.Open(result.StorePath);
            using var start = new ManualResetEventSlim();
            IDisposable? child = null; Exception? failure = null;
            void Create()
            {
                try { child = transaction ? owner.BeginTransaction() : owner.BeginRead(0); }
                catch (Exception error) { failure = error; }
            }
            if (schedule == "child-first") { Create(); owner.Dispose(); Assert.Null(failure); }
            else if (schedule == "owner-first") { owner.Dispose(); Create(); Assert.IsType<ObjectDisposedException>(failure); }
            else
            {
                var creation = Task.Run(() => { if (!start.Wait(TimeSpan.FromSeconds(10))) throw new TimeoutException(); Create(); });
                var disposal = Task.Run(() => { if (!start.Wait(TimeSpan.FromSeconds(10))) throw new TimeoutException(); owner.Dispose(); });
                start.Set(); await Task.WhenAll(creation, disposal).WaitAsync(TimeSpan.FromSeconds(20));
                Assert.True(child is not null && failure is null || child is null && failure is ObjectDisposedException, failure?.ToString());
            }
            try
            {
                if (child is not null)
                {
                    Assert.Throws<IOException>(() => Exclusive(result));
                    using (var next = EpochScalarCoordinator.Open(result.StorePath))
                    { using var read = next.BeginRead(0); Assert.Equal(Expected(count), read.ReadValue(Target(read))); }
                    if (child is EpochScalarTransaction tx)
                    {
                        Assert.Equal((ulong)count, tx.BaseSequence); Assert.Equal(result.Destination, tx.Identity);
                        Assert.Equal(Expected(count), tx.ReadValue(TargetId));
                        tx.ReplaceNodeValue(TargetId, "uncommitted");
                        Assert.Throws<ObjectDisposedException>(() => tx.Commit());
                    }
                    else
                    {
                        var snapshot = Assert.IsType<ImmutableXmlSnapshot>(child);
                        Assert.Equal((ulong)count, snapshot.CommitSequence); Assert.Equal(Expected(count), snapshot.ReadValue(TargetId));
                    }
                }
            }
            finally { child?.Dispose(); }
            using (Exclusive(result)) { }
            AssertUnchanged(before, result.StorePath);
        }
    }

    /// <summary>A child in a separate process retains epoch and generation exclusion after owner disposal and releases on graceful exit or kill.</summary>
    /// <param name="transaction">Whether to hold a transaction.</param>
    /// <param name="kill">Whether to kill instead of close the holder.</param>
    [Theory]
    [InlineData(false, false)]
    [InlineData(false, true)]
    [InlineData(true, false)]
    [InlineData(true, true)]
    public async Task ChildProcess_OwnerDisposed_BlocksMaintenanceUntilHolderEnds(bool transaction, bool kill)
    {
        var result = Prepare(3); var before = Capture(result.StorePath);
        var start = new ProcessStartInfo("dotnet") { RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false };
        foreach (var argument in new[] { typeof(MigratedOwnershipTests).Assembly.Location, "ca2-hold", result.StorePath,
            transaction ? "transaction" : "snapshot", TargetId.ToString(System.Globalization.CultureInfo.InvariantCulture) }) start.ArgumentList.Add(argument);
        using var holder = Process.Start(start) ?? throw new InvalidOperationException("Cannot start ownership holder.");
        var errors = holder.StandardError.ReadToEndAsync();
        try
        {
            Assert.Equal("PINNED", await holder.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(20)));
            Assert.Throws<IOException>(() => Exclusive(result));
            // Resolve the concrete published generation lease from the stable reader directory.
            var readers = Directory.GetFiles(Path.Combine(result.StorePath, ".transactions", "readers"));
            Assert.Equal(4, readers.Length);
            var headReaders = readers.Where(path => Path.GetFileName(path).Contains("00000000000000000003", StringComparison.Ordinal)).ToArray();
            Assert.Single(headReaders);
            foreach (var path in headReaders)
                Assert.Throws<IOException>(() => new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None));
            using (var owner = EpochScalarCoordinator.Open(result.StorePath))
            { using var read = owner.BeginRead(0); Assert.Equal("new-3", read.ReadValue(Target(read))); }
            AssertUnchanged(before, result.StorePath);
            if (kill) holder.Kill(true);
            else
            {
                await holder.StandardInput.WriteLineAsync(); await holder.StandardInput.FlushAsync();
                Assert.Equal("new-3", await holder.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(20)));
            }
            await holder.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(20));
            if (!kill) Assert.Equal(0, holder.ExitCode);
            Assert.Equal("", await errors);
            using (Exclusive(result)) { }
            foreach (var path in readers) using (new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) { }
            AssertUnchanged(before, result.StorePath);
        }
        finally
        {
            if (!holder.HasExited) { holder.Kill(true); await holder.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(20)); }
        }
    }

    private ulong TargetId { get; set; }
    private EpochMigrationResult Prepare(int count)
    {
        Directory.CreateDirectory(_area); var source = Path.Combine(_area, "source"); var backup = Path.Combine(_area, "backup");
        using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, source);
        using (var owner = EmbeddedXmlDatabase.Open(source))
        {
            using (var read = owner.BeginRead()) TargetId = Target(read);
            for (var sequence = 1; sequence <= count; sequence++)
            { using var tx = owner.BeginWrite(); tx.ReplaceNodeValue(TargetId, "new-" + sequence); tx.Commit(); }
            owner.CreateBackup(backup);
        }
        return EpochLegacyMigration.Convert(backup, Path.Combine(_area, "bundle"));
    }
    private static string Expected(int count) => count == 0 ? "old" : "new-" + count;
    private static ulong Target(ImmutableXmlSnapshot read) => Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id))
        .Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();
    private static EpochAdmissionLease Exclusive(EpochMigrationResult result) => EpochAdmission.Acquire(result.StorePath, result.Destination, exclusive: true, profile: EpochProfile.ScalarWal);
    private sealed record Tree(string[] Directories, Dictionary<string, byte[]> Files, Dictionary<string, string> Identities);
    private Tree Capture(string store) => new(Directory.GetDirectories(_area, "*", SearchOption.AllDirectories).Order().ToArray(),
        Directory.GetFiles(_area, "*", SearchOption.AllDirectories).ToDictionary(path => path, File.ReadAllBytes), MigrationRuntimeIdentities.Read(store));
    private void AssertUnchanged(Tree expected, string store)
    {
        var actual = Capture(store); Assert.Equal(expected.Directories, actual.Directories);
        Assert.Equal(expected.Files.Keys.Order(), actual.Files.Keys.Order());
        foreach (var pair in expected.Files) Assert.Equal(pair.Value, actual.Files[pair.Key]);
        Assert.Equal(expected.Identities.OrderBy(pair => pair.Key), actual.Identities.OrderBy(pair => pair.Key));
    }
    /// <summary>Deletes only the isolated test-owned area after workers, processes and handles have completed.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
