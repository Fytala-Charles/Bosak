// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Exercises the internal explicit mutable facade from a friend consumer assembly.
// SPECIAL NOTES        : Local baseline compatibility only; no archived release or actual routing claim.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Text;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Exercises proposed mutable consumer semantics without exposing any new public types.</summary>
public sealed class ScalarEpochFacadeTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-pa1-" + Guid.NewGuid().ToString("N"));
    private string Source => Path.Combine(_area, "source");
    private static ScalarEpochOpenOptions Options(EpochIdentity? identity = null) => new(DurabilityMode.ProcessCrash, ScalarEpochRecovery.FullHistory, identity);

    /// <summary>Real migrated histories support pinned reads, stale conflicts, scalar commits and explicit reopen with no public gate widening.</summary>
    /// <param name="count">Initial migrated head.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(3)]
    public void Consumer_MigratedHistory_ReadCommitConflictAndReopen(int count)
    {
        var result = Seed(count);
        using (var owner = ScalarEpochDatabase.Open(result.StorePath, Options(result.Destination)))
        {
            Assert.Equal(result.Destination, owner.Identity); Assert.Equal((ulong)count, owner.CommitSequence); Assert.Equal(DurabilityMode.ProcessCrash, owner.Durability);
            using var old = owner.BeginRead(0); var node = Target(old); var value = old.ReadValue(node);
            using var first = owner.BeginTransaction(); using var stale = owner.BeginTransaction();
            Assert.Equal((ulong)count, first.BaseSequence); Assert.Equal(result.Destination, first.Identity); Assert.NotEqual(Guid.Empty, first.TransactionId);
            first.ReplaceNodeValue(node, "committed"); Assert.Equal((ulong)count + 1, first.Commit());
            stale.ReplaceNodeValue(node, "stale"); Assert.Throws<TransactionConflictException>(() => stale.Commit());
            Assert.Equal(value, old.ReadValue(node)); using var current = owner.BeginRead(0); Assert.Equal("committed", current.ReadValue(node));
        }
        using var reopened = ScalarEpochDatabase.Open(result.StorePath, Options(result.Destination));
        Assert.Equal((ulong)count + 1, reopened.CommitSequence);
        Assert.Throws<InvalidDataException>(() => EmbeddedXmlDatabase.Open(result.StorePath));
        Assert.Throws<InvalidDataException>(() => ReadOnlyEpochDatabase.Open(result.StorePath));
        Assert.False(typeof(ScalarEpochDatabase).IsVisible); Assert.False(typeof(ScalarEpochWriteTransaction).IsVisible);
        Assert.DoesNotContain(typeof(ScalarEpochDatabase).Assembly.GetExportedTypes(), type => type.Name.StartsWith("ScalarEpoch", StringComparison.Ordinal));
    }

    /// <summary>Children retain their own admission and values after owner disposal, while writes fail and rollback/disposal release protection.</summary>
    /// <param name="transaction">Whether to keep a transaction child.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Consumer_OwnerDisposed_ChildrenRetainIndependentLifetime(bool transaction)
    {
        var result = Seed(1); var owner = ScalarEpochDatabase.Open(result.StorePath, Options());
        using var initial = owner.BeginRead(0); var node = Target(initial); initial.Dispose();
        using var snapshot = transaction ? null : owner.BeginRead(0);
        using var tx = transaction ? owner.BeginTransaction() : null;
        owner.Dispose(); owner.Dispose();
        Assert.Throws<ObjectDisposedException>(() => owner.BeginRead()); Assert.Throws<ObjectDisposedException>(() => owner.BeginTransaction());
        Assert.Throws<ObjectDisposedException>(() => owner.CommitSequence);
        Assert.Throws<IOException>(() => EpochAdmission.Acquire(result.StorePath, result.Destination, true, EpochProfile.ScalarWal));
        if (tx is not null)
        {
            Assert.Equal("new-1", tx.ReadValue(node)); tx.ReplaceNodeValue(node, "pending");
            Assert.Throws<ObjectDisposedException>(() => tx.Commit()); tx.Dispose();
        }
        else { Assert.Equal("new-1", snapshot!.ReadValue(node)); snapshot.Dispose(); }
        using var exclusive = EpochAdmission.Acquire(result.StorePath, result.Destination, true, EpochProfile.ScalarWal);
    }

    /// <summary>Profile rejection preserves existing legacy or immutable epoch files and directories.</summary>
    /// <param name="immutable">Whether to reject immutable epoch metadata instead of legacy data.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Open_UnsupportedProfile_RejectsWithoutAdoption(bool immutable)
    {
        Seed(0); var path = Source;
        if (immutable) { path = Path.Combine(_area, "immutable"); EpochAdmission.CreateFixtureRoot(path, 1, new LocalTransactionStorage()); }
        var before = Capture();
        Assert.Throws<InvalidDataException>(() => ScalarEpochDatabase.Open(path, Options())); AssertUnchanged(before);
    }

    /// <summary>Exact expected store, epoch or document mismatch rejects before even attempting occupied admission.</summary>
    /// <param name="part">Identity component changed.</param>
    [Theory]
    [InlineData("store")]
    [InlineData("epoch")]
    [InlineData("document")]
    public void Open_WrongExpectedIdentity_RejectsBeforeAdmission(string part)
    {
        var result = Seed(0); var before = Capture();
        var wrong = part switch { "store" => result.Destination with { StoreId = Guid.NewGuid() }, "epoch" => result.Destination with { EpochId = Guid.NewGuid() }, _ => result.Destination with { DocumentId = 2 } };
        using (var occupied = new FileStream(Path.Combine(result.StorePath, ".epoch", "admission.lease"), FileMode.Open, FileAccess.ReadWrite, FileShare.None))
        {
            var error = Assert.Throws<InvalidDataException>(() => ScalarEpochDatabase.Open(result.StorePath, Options(wrong)));
            Assert.Contains("expected", error.Message, StringComparison.OrdinalIgnoreCase);
        }
        AssertUnchanged(before);
    }

    /// <summary>Options are validated before storage access, and an unsupported native platform never falls back.</summary>
    /// <param name="fault">Invalid option or root.</param>
    [Theory]
    [InlineData("null-options")]
    [InlineData("empty-root")]
    [InlineData("durability")]
    [InlineData("recovery")]
    [InlineData("storage-policy")]
    public void Open_InvalidArguments_HaveExplicitDiagnostics(string fault)
    {
        var options = Options();
        switch (fault)
        {
            case "null-options": Assert.Throws<ArgumentNullException>(() => ScalarEpochDatabase.Open("unused-root", null!)); break;
            case "empty-root": Assert.Throws<ArgumentException>(() => ScalarEpochDatabase.Open(" ", options)); break;
            case "durability": Assert.Throws<ArgumentOutOfRangeException>(() => ScalarEpochDatabase.Open("unused-root", options with { Durability = (DurabilityMode)99 })); break;
            case "recovery": Assert.Throws<ArgumentOutOfRangeException>(() => ScalarEpochDatabase.Open("unused-root", options with { Recovery = (ScalarEpochRecovery)99 })); break;
            default: Assert.Throws<ArgumentException>(() => ScalarEpochDatabase.OpenCore("unused-root", options with { Durability = DurabilityMode.FileAndDirectoryFlush }, new LocalTransactionStorage())); break;
        }
        Assert.False(Directory.Exists(_area));
    }

    /// <summary>Contention and corruption retain their original exception categories, and failed Open leaks no admission.</summary>
    /// <param name="corrupt">Whether to corrupt current authority or contend with a live owner.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Open_ContentionOrCorruption_PreservesDiagnosticAndReleasesHandles(bool corrupt)
    {
        var result = Seed(1);
        if (corrupt)
        {
            var current = Path.Combine(result.StorePath, ".transactions", "CURRENT"); var bytes = File.ReadAllBytes(current); bytes[^1] ^= 1; File.WriteAllBytes(current, bytes);
            var before = Capture(); Assert.Throws<InvalidDataException>(() => ScalarEpochDatabase.Open(result.StorePath, Options())); AssertUnchanged(before);
        }
        else
        {
            using var occupied = ScalarEpochDatabase.Open(result.StorePath, Options());
            Assert.Throws<IOException>(() => ScalarEpochDatabase.Open(result.StorePath, Options()));
        }
        using var exclusive = EpochAdmission.Acquire(result.StorePath, result.Destination, true, EpochProfile.ScalarWal);
    }

    /// <summary>Commit I/O errors are not converted to no-commit promises; explicit reopen resolves publication without replaying edits.</summary>
    /// <param name="stage">Boundary at which the callback reports I/O failure.</param>
    /// <param name="committed">Whether full history recovery must observe the new edit.</param>
    [Theory]
    [InlineData((int)EpochScalarStage.BeforeWal, false)]
    [InlineData((int)EpochScalarStage.WalFlushed, true)]
    [InlineData((int)EpochScalarStage.CurrentPublished, true)]
    public void Commit_UnacknowledgedIo_RequiresExplicitReopen(int stage, bool committed)
    {
        var result = Seed(0);
        using (var owner = ScalarEpochDatabase.OpenCore(result.StorePath, Options(), new LocalTransactionStorage(), observed =>
            { if ((int)observed == stage) throw new IOException("injected-unacknowledged"); }))
        {
            using var read = owner.BeginRead(); var node = Target(read); using var tx = owner.BeginTransaction();
            tx.ReplaceNodeValue(node, "unacknowledged");
            var error = Assert.Throws<IOException>(() => tx.Commit()); Assert.Equal("injected-unacknowledged", error.Message);
            Assert.Throws<InvalidOperationException>(() => owner.BeginRead());
        }
        using var reopened = ScalarEpochDatabase.Open(result.StorePath, Options()); using var selected = reopened.BeginRead(0);
        Assert.Equal(committed ? 1UL : 0UL, reopened.CommitSequence); Assert.Equal(committed ? "unacknowledged" : "old", selected.ReadValue(Target(selected)));
    }

    /// <summary>Backup delegates fixed-head full history and remains restorable without routing or changing public profile gates.</summary>
    [Fact]
    public void Consumer_Backup_RetainsHistoryAndIndependentRestore()
    {
        var result = Seed(1); var backup = Path.Combine(_area, "epoch-backup");
        using (var owner = ScalarEpochDatabase.Open(result.StorePath, Options()))
        {
            var capture = owner.CreateBackup(backup); Assert.Equal(result.Destination, capture.Source); Assert.Equal(1UL, capture.CommitSequence);
        }
        var restored = EpochBackupRestore.Restore(backup, Path.Combine(_area, "restored"));
        using var independent = ScalarEpochDatabase.Open(restored.StorePath, Options(restored.Destination));
        Assert.NotEqual(result.Destination, independent.Identity); Assert.Equal(1UL, independent.CommitSequence);
        using var read = independent.BeginRead(0); Assert.Equal("new-1", read.ReadValue(Target(read)));
    }

    /// <summary>Explicit native policy executes only on Linux; other platforms reject before admission without fallback.</summary>
    [Fact]
    public void Open_ExplicitNativePolicy_HasNoFallback()
    {
        var result = Seed(0); var options = new ScalarEpochOpenOptions(DurabilityMode.FileAndDirectoryFlush, ScalarEpochRecovery.FullHistory, result.Destination);
        if (!OperatingSystem.IsLinux())
        {
            var before = Capture(); Assert.Throws<PlatformNotSupportedException>(() => ScalarEpochDatabase.Open(result.StorePath, options)); AssertUnchanged(before); return;
        }
        using var owner = ScalarEpochDatabase.Open(result.StorePath, options); Assert.Equal(DurabilityMode.FileAndDirectoryFlush, owner.Durability);
        using var read = owner.BeginRead(); using var tx = owner.BeginTransaction(); tx.ReplaceNodeValue(Target(read), "native"); Assert.Equal(1UL, tx.Commit());
    }

    private EpochMigrationResult Seed(int count)
    {
        Directory.CreateDirectory(_area); using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, Source);
        var backup = Path.Combine(_area, "backup");
        using (var owner = EmbeddedXmlDatabase.Open(Source))
        {
            using var read = owner.BeginRead(); var node = Target(read);
            for (var sequence = 1; sequence <= count; sequence++) { using var tx = owner.BeginWrite(); tx.ReplaceNodeValue(node, "new-" + sequence); tx.Commit(); }
            owner.CreateBackup(backup);
        }
        return EpochLegacyMigration.Convert(backup, Path.Combine(_area, "bundle"));
    }
    private static ulong Target(ImmutableXmlSnapshot read) => Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id))
        .Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();
    private sealed record Tree(string[] Directories, Dictionary<string, byte[]> Files);
    private Tree Capture() => new(Directory.GetDirectories(_area, "*", SearchOption.AllDirectories).Order().ToArray(), Directory.GetFiles(_area, "*", SearchOption.AllDirectories).ToDictionary(path => path, File.ReadAllBytes));
    private void AssertUnchanged(Tree before)
    {
        var after = Capture(); Assert.Equal(before.Directories, after.Directories); Assert.Equal(before.Files.Keys.Order(), after.Files.Keys.Order());
        foreach (var pair in before.Files) Assert.Equal(pair.Value, after.Files[pair.Key]);
    }
    /// <summary>Deletes only this test's temporary area after all owner, snapshot and transaction handles close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
