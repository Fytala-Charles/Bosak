// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Tests actual process interruption and retained uncertain journal frames.
// SPECIAL NOTES        : Internal ProcessCrash append only; uncertain sessions remain faulted and all writers stopped.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Uses actual process termination without asserting power-loss durability or executable replay.</summary>
public sealed class EmbeddedHostJournalProcessTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ep4-process-" + Guid.NewGuid().ToString("N"));
    /// <summary>Incomplete data blocks reopen; complete frames remain stopped observations regardless of lost flush/return acknowledgment.</summary>
    /// <param name="stage">Actual interruption point.</param>
    [Theory]
    [InlineData("Validated")]
    [InlineData("BeforeWrite")]
    [InlineData("Written")]
    [InlineData("Flushed")]
    [InlineData("BeforeAcknowledge")]
    [InlineData("ACK")]
    [InlineData("partial")]
    public async Task Append_ProcessDies_RetainsUncertainBytes(string stage)
    {
        var root = Path.Combine(_area, "host"); var data = Path.Combine(_area, "data"); Directory.CreateDirectory(data);
        var info = new ProcessStartInfo("dotnet") { UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true, CreateNoWindow = true };
        foreach (var arg in new[] { typeof(EmbeddedHostJournalProcessTests).Assembly.Location, "ep4-append", root, "pilot", "scope", data, stage }) info.ArgumentList.Add(arg);
        using var child = Process.Start(info) ?? throw new InvalidOperationException("No append probe."); var output = child.StandardOutput.ReadToEndAsync(); var errors = child.StandardError.ReadToEndAsync();
        try
        {
            await child.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); Assert.NotEqual(0, child.ExitCode); Assert.Contains("EP4:" + stage, await output); _ = await errors;
            var before = Directory.GetFiles(root).ToDictionary(path => path, File.ReadAllBytes);
            if (stage == "partial") Assert.Throws<InvalidDataException>(() => { using var rejected = EmbeddedHostLifetime.OpenExisting(root, "pilot", "scope", [data]); });
            else
            {
                using var observed = EmbeddedHostLifetime.OpenExisting(root, "pilot", "scope", [data]);
                var count = stage is "Validated" or "BeforeWrite" ? 0 : 1;
                Assert.Equal(count, observed.History.Frames.Count); Assert.False(observed.AdmissionsOpen); Assert.False(observed.WasProvisionedHere); Assert.False(observed.JournalStatus.CanAttemptAppend);
                Assert.True(observed.History.WritersMustRemainStopped);
                if (count == 0)
                {
                    var evidence = new EmbeddedHostAdmissionEvidence(observed.Context, true, true, true, true, true, true);
                    observed.OpenAdministrativeAdmissions(evidence); Assert.Throws<InvalidOperationException>(() => observed.EnableJournalAppend(observed.JournalStatus.KnownPosition, evidence));
                }
            }
            foreach (var pair in before) Assert.Equal(pair.Value, File.ReadAllBytes(pair.Key));
        }
        finally { if (!child.HasExited) { child.Kill(true); await child.WaitForExitAsync(); } }
    }
    /// <summary>Deletes only the owned GUID tree after actual child exit and read handles close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
