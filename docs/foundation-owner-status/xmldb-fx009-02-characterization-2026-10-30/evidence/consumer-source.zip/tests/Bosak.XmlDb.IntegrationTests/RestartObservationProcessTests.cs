// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 30 October 2026
// PURPOSE              : Qualifies stopped restart observation across actual process ownership and interruption.
// SPECIAL NOTES        : SR2-C process-boundary evidence only; explicit source open precedes read-only measurement.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 30-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;
using Xunit.Abstractions;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Qualifies stopped restart observation across actual process ownership and interruption.</summary>
/// <param name="output">Captures process counts and boundary markers.</param>
public sealed class RestartObservationProcessTests(ITestOutputHelper output) : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-sr2c-process-" + Guid.NewGuid().ToString("N"));
    private readonly Guid _admin = Guid.NewGuid();
    private readonly Guid _authority = Guid.NewGuid();
    private string Source => Path.Combine(_area, "source");
    private string Capture => Path.Combine(_area, "capture");
    private string Host => Path.Combine(_area, "host");
    private string Authority => Path.Combine(_area, "authority");
    private ApplicationAuthorityConfiguration Configuration => new(_authority, _admin, "embedded-pilot", "orders", "admin", "authority");
    private Dictionary<string, string> Roots => new() { ["admin"] = Host, ["authority"] = Authority, ["source"] = Source, ["capture"] = Capture };
    private void Seed()
    {
        using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, Source);
        Directory.CreateDirectory(Host); File.WriteAllBytes(Path.Combine(Host, "owner.lock"), []); File.WriteAllBytes(Path.Combine(Host, "host.meta"), HostJournalCodec.EncodeMetadata(_admin, "embedded-pilot", "orders")); File.WriteAllBytes(Path.Combine(Host, "journal.bin"), []);
        using var source = EmbeddedXmlDatabase.Open(Source); using (var read = source.BeginRead())
        {
            var target = Enumerable.Range(1, read.NodeCount).Select(i => read.GetNode((ulong)i)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();
            using var tx = source.BeginWrite(); tx.ReplaceNodeValue(target, "new-0"); tx.Commit();
        }
        using var final = source.BeginRead();
        using var parent = EmbeddedHostLifetime.OpenExisting(Host, "embedded-pilot", "orders", [Source, Capture, Authority]);
        using var authority = ApplicationAuthorityLifetime.Provision(parent, parent.JournalStatus.KnownPosition, new(parent.Context, true, true, true, true, true), Authority, Configuration, Roots, new(Authority, true, true, true));
        using var freeze = MigrationSourceFreeze.Acquire(source, true); var capture = freeze.Capture(Capture);
        var evidence = new ApplicationEnrollmentEvidence(parent.Context, _authority, "source", "source-admission", "capture", Guid.NewGuid(), new string('a', 64), true, true, true, true, true, true);
        using var plan = authority.PrepareRetainedFirstEnrollment(freeze, capture, evidence);
        Assert.Equal(ApplicationEnrollmentAppendDisposition.AcknowledgedStopped, authority.AppendFirstEnrollment(plan, evidence).Disposition);
    }
    private Process Start(string point = "normal", bool closing = false, bool race = false)
    {
        var info = new ProcessStartInfo("dotnet") { RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false, CreateNoWindow = true };
        foreach (var argument in new[] { typeof(RestartObservationProcessTests).Assembly.Location, race ? "sr2c-race" : "sr2c-observe", Host, Authority, Source, Capture, _authority.ToString(), _admin.ToString(), point, closing.ToString() }) info.ArgumentList.Add(argument);
        return Process.Start(info) ?? throw new InvalidOperationException("Cannot start restart observation worker.");
    }
    private static async Task<string?> Line(Process process) => await process.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(45));
    private static async Task Send(Process process, string line) { await process.StandardInput.WriteLineAsync(line); await process.StandardInput.FlushAsync(); }
    private static async Task Stop(Process process) { if (!process.HasExited) { process.Kill(true); await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); } }
    private Dictionary<string, byte[]> Bytes()
    {
        var result = new Dictionary<string, byte[]>();
        foreach (var path in Directory.GetFiles(_area, "*", SearchOption.AllDirectories).Where(p => Path.GetFileName(p) is not ("writer.lock" or "owner.lock" or "authority.lock")))
        { using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite); var bytes = new byte[(int)stream.Length]; stream.ReadExactly(bytes); result.Add(path, bytes); }
        return result;
    }
    private string[] Inventory() => Directory.GetFileSystemEntries(_area, "*", SearchOption.AllDirectories).Order().ToArray();
    private void Preserved(Dictionary<string, byte[]> bytes, string[] inventory)
    { var after = Bytes(); Assert.Equal(inventory, Inventory()); Assert.Equal(bytes.Keys.Order(), after.Keys.Order()); foreach (var pair in bytes) Assert.Equal(pair.Value, after[pair.Key]); }
    private void Blocked()
    {
        foreach (var path in new[] { Path.Combine(Source, ".transactions", "writer.lock"), Path.Combine(Host, "owner.lock"), Path.Combine(Authority, "authority.lock") })
            Assert.Throws<IOException>(() => { using var blocked = new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None); });
    }
    private void Available()
    {
        foreach (var path in new[] { Path.Combine(Source, ".transactions", "writer.lock"), Path.Combine(Host, "owner.lock"), Path.Combine(Authority, "authority.lock") })
        { using var available = new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None); }
    }
    private async Task FreshStoppedObservation(Dictionary<string, byte[]> bytes, string[] inventory)
    {
        using var worker = Start(); var errors = worker.StandardError.ReadToEndAsync();
        try
        {
            Assert.Equal("OPENED", await Line(worker)); Preserved(bytes, inventory); await Send(worker, "begin");
            Assert.Equal("RESULT:ObservedEnrolledStopped:" + FrameDigestShared(), await Line(worker)); Assert.Equal("HELD", await Line(worker)); Blocked();
            await Send(worker, "release"); Assert.Equal("RELEASED", await Line(worker)); Available(); Preserved(bytes, inventory);
            await Send(worker, "exit"); await worker.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); Assert.True(worker.ExitCode == 0, await errors);
        }
        finally { await Stop(worker); _ = await errors; }
    }
    private string FrameDigestShared()
    {
        var stream = new FileStream(Path.Combine(Authority, "authority.log"), FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        using (stream) { var bytes = new byte[(int)stream.Length]; stream.ReadExactly(bytes); return Assert.Single(ApplicationAuthorityCodec.DecodeJournal(bytes, ApplicationAuthorityCodec.DecodeMetadata(ApplicationAuthorityCodec.EncodeMetadata(Configuration), Configuration)).Frames).Digest; }
    }

    /// <summary>Actual process holders retain all three owners through wrapper closing and release only on real scope drain.</summary>
    /// <param name="closing">Whether caller wrappers close before holding the observed scope.</param>
    /// <returns>A task completing after contention, drain, fresh observation and worker exit.</returns>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Observe_ProcessHolder_DrainsBeforeIndependentReopen(bool closing)
    {
        Seed(); var bytes = Bytes(); var inventory = Inventory(); using var worker = Start("Observed", closing); var errors = worker.StandardError.ReadToEndAsync();
        try
        {
            Assert.Equal("OPENED", await Line(worker)); Preserved(bytes, inventory); await Send(worker, "begin"); Assert.Equal("AT:Observed", await Line(worker)); Blocked();
            using (var contender = Start(race: true))
            {
                var contenderErrors = contender.StandardError.ReadToEndAsync();
                try { Assert.Equal("READY", await Line(contender)); await Send(contender, "start"); Assert.Equal("BLOCKED", await Line(contender)); await contender.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); Assert.True(contender.ExitCode == 0, await contenderErrors); }
                finally { await Stop(contender); _ = await contenderErrors; }
            }
            Preserved(bytes, inventory); await Send(worker, "continue"); Assert.Equal("RESULT:ObservedEnrolledStopped:" + FrameDigestShared(), await Line(worker)); Assert.Equal("HELD", await Line(worker));
            await Send(worker, "release"); Assert.Equal("RELEASED", await Line(worker)); Assert.False(worker.HasExited); Available(); Preserved(bytes, inventory);
            await FreshStoppedObservation(bytes, inventory); // Original worker still holds its independent old snapshot.
            await Send(worker, "exit"); await worker.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); Assert.True(worker.ExitCode == 0, await errors);
            output.WriteLine("SR2C_PROCESS_HOLDER closing=" + closing + " workers=3 oldReaderSurvived=true preserved=true");
        }
        finally { await Stop(worker); _ = await errors; }
    }

    /// <summary>Repeated real process kills discard live scope identity without changing bytes or recreating an acknowledgment.</summary>
    /// <param name="point">Actual read-only pause boundary.</param>
    /// <param name="closing">Whether caller wrappers close at that boundary.</param>
    /// <returns>A task completing after two killed holders and two fresh stopped observations.</returns>
    [Theory]
    [InlineData("Registered", false)]
    [InlineData("SourceRetained", false)]
    [InlineData("BaselineVerified", false)]
    [InlineData("BeforeFinalValidation", false)]
    [InlineData("BeforeFinalValidation", true)]
    [InlineData("Observed", false)]
    [InlineData("Observed", true)]
    public async Task Observe_ProcessInterruption_ReopensOnlyFreshStoppedEvidence(string point, bool closing)
    {
        Seed(); var bytes = Bytes(); var inventory = Inventory();
        for (var repeat = 0; repeat < 2; repeat++)
        {
            using var worker = Start(point, closing); var errors = worker.StandardError.ReadToEndAsync();
            try
            {
                Assert.Equal("OPENED", await Line(worker)); Preserved(bytes, inventory); await Send(worker, "begin"); Assert.Equal("AT:" + point, await Line(worker)); Blocked();
                await Stop(worker); _ = await errors; Available(); Preserved(bytes, inventory);
                await FreshStoppedObservation(bytes, inventory);
            }
            finally { await Stop(worker); _ = await errors; }
        }
        output.WriteLine("SR2C_PROCESS_KILL point=" + point + " closing=" + closing + " killed=2 fresh=2 preserved=true");
    }

    /// <summary>Two independent new observations compete for real owners rather than sharing executable scope state.</summary>
    /// <returns>A task completing after two repeated exclusive process races.</returns>
    [Fact]
    public async Task Observe_IndependentProcessRace_ExactlyOneHolder()
    {
        Seed(); var bytes = Bytes(); var inventory = Inventory();
        for (var repeat = 0; repeat < 2; repeat++)
        {
            using var first = Start(race: true); using var second = Start(race: true); var firstErrors = first.StandardError.ReadToEndAsync(); var secondErrors = second.StandardError.ReadToEndAsync();
            try
            {
                Assert.Equal("READY", await Line(first)); Assert.Equal("READY", await Line(second)); await Send(first, "start"); await Send(second, "start");
                var lines = await Task.WhenAll(Line(first), Line(second)); Assert.Equal(new[] { "BLOCKED", "OPENED" }, lines.Order());
                var winner = lines[0] == "OPENED" ? first : second; var loser = ReferenceEquals(winner, first) ? second : first;
                await loser.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); Assert.Equal(0, loser.ExitCode); Preserved(bytes, inventory); Blocked();
                await Send(winner, "begin"); Assert.Equal("RESULT:ObservedEnrolledStopped:" + FrameDigestShared(), await Line(winner)); Assert.Equal("HELD", await Line(winner));
                await Send(winner, "release"); Assert.Equal("RELEASED", await Line(winner)); Available(); await Send(winner, "exit"); await winner.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); Assert.Equal(0, winner.ExitCode); Preserved(bytes, inventory);
            }
            finally { await Stop(first); await Stop(second); _ = await firstErrors; _ = await secondErrors; }
        }
        output.WriteLine("SR2C_PROCESS_RACES repeats=2 workers=4 exactlyOneHolder=true preserved=true");
    }

    /// <summary>Removes only this fresh owned process workspace after all workers and handles close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
