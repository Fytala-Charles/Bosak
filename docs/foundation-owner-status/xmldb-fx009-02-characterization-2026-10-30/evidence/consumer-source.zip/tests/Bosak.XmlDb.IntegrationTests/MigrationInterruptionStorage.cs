// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Interrupts private migration copy and redo writes without replacing native storage behavior.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using Bosak.XmlDb.Storage;

namespace Bosak.XmlDb.IntegrationTests;

internal sealed class MigrationInterruptionStorage(DurabilityMode durability, string target, Action interrupt) : ITransactionStorage
{
    private readonly LocalTransactionStorage _local = new(durability);
    internal bool SourceVerified { get; set; }
    public DurabilityMode Durability => _local.Durability;
    public ITransactionFile CreateFile(string path) => new File(this, _local.CreateFile(path), path);
    public void CreateDirectory(string path) => _local.CreateDirectory(path);
    public void MoveFile(string source, string destination, bool overwrite) => _local.MoveFile(source, destination, overwrite);
    public void MoveDirectory(string source, string destination) => _local.MoveDirectory(source, destination);
    public void DeleteFile(string path) => _local.DeleteFile(path);
    public void DeleteDirectory(string path) => _local.DeleteDirectory(path);
    public void SyncDirectory(string path) => _local.SyncDirectory(path);
    public void SyncFile(string path) => _local.SyncFile(path);
    private void Written(string path)
    {
        var relative = path.Replace('\\', '/');
        var match = target switch
        {
            "LegacyCompleteCopy" => !SourceVerified && relative.Contains("/verify-complete/", StringComparison.Ordinal),
            "LegacyRedoWrite" => !SourceVerified && relative.Contains("/verify-redo/.transactions/staging/", StringComparison.Ordinal),
            "EpochRedoWrite" => SourceVerified && relative.Contains("/verify-redo/.transactions/staging/", StringComparison.Ordinal),
            _ => false
        };
        if (match) interrupt();
    }
    private sealed class File(MigrationInterruptionStorage owner, ITransactionFile inner, string path) : ITransactionFile
    {
        public void Write(ReadOnlySpan<byte> bytes) { inner.Write(bytes); owner.Written(path); }
        public void FlushToDisk() => inner.FlushToDisk();
        public void Dispose() => inner.Dispose();
    }
}
