// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Verifies read-only publication observations, correlation limits and nonmutation.
// SPECIAL NOTES        : Local baseline compatibility only; no archived release or actual routing claim.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Security.Cryptography;
using System.Text;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Verifies point-in-time publication correlation without adopting, recovering or routing candidates.</summary>
public sealed class EpochPublicationInspectorTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-pa3-" + Guid.NewGuid().ToString("N"));
    private string Bundle => Path.Combine(_area, "bundle");
    private string Store => Path.Combine(Bundle, "store");

    /// <summary>Exact initial publications correlate with the artifact; only a supplied matching operation ID yields known-operation correlation.</summary>
    /// <param name="restore">Publication role.</param>
    /// <param name="count">History length.</param>
    /// <param name="known">Whether the caller already knows the operation ID.</param>
    [Theory]
    [InlineData(false, 0, false)]
    [InlineData(false, 0, true)]
    [InlineData(false, 3, false)]
    [InlineData(false, 3, true)]
    [InlineData(true, 0, false)]
    [InlineData(true, 0, true)]
    [InlineData(true, 3, false)]
    [InlineData(true, 3, true)]
    public void Inspect_InitialPublication_CorrelatesWithoutWrites(bool restore, int count, bool known)
    {
        var (request, receipt) = Seed(restore, count); request = request with { ExpectedOperationId = known ? receipt.OperationId : null, ExpectedDestination = receipt.DestinationEpoch };
        var before = Capture(); var ids = MigrationRuntimeIdentities.Read(Store); var storage = new NoWritesStorage();
        var admin = ScalarEpochAdministration.CreateCore(new(DurabilityMode.ProcessCrash), storage);
        var result = admin.InspectPublication(request);
        Assert.Equal(known ? EpochInspectionStatus.KnownOperationMatched : EpochInspectionStatus.ArtifactMatched, result.Status);
        Assert.NotNull(result.Observed); Assert.Equal(receipt.OperationId, result.Observed.OperationId); Assert.Equal(receipt.DestinationEpoch, result.Observed.DestinationEpoch);
        Assert.Equal(receipt.StorePath, result.Observed.StorePath); Assert.Equal((ulong)count, result.Observed.CommitSequence);
        Assert.True(result.WritersMustRemainStopped); Assert.Equal(0, storage.Calls); AssertUnchanged(before);
        Assert.Equal(ids.OrderBy(pair => pair.Key), MigrationRuntimeIdentities.Read(Store).OrderBy(pair => pair.Key));
    }

    /// <summary>Publication after a lost acknowledgment remains an artifact match without inventing a known request ID.</summary>
    /// <param name="restore">Publication role.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Inspect_AcknowledgmentLost_DoesNotInventOperationKnowledge(bool restore)
    {
        var (request, _) = Seed(restore, 1); var unknownBundle = Path.Combine(_area, "unacknowledged");
        var admin = ScalarEpochAdministration.CreateCore(new(DurabilityMode.ProcessCrash), new LocalTransactionStorage(), stage =>
        { if (stage == EpochAdministrativeStage.Published) throw new IOException("ack-lost"); });
        Assert.Throws<IOException>(() => { if (restore) admin.RestoreEpochBackup(request.Artifact, unknownBundle); else admin.ConvertLegacyBackup(request.Artifact, unknownBundle); });
        var before = Capture(); var result = EpochPublicationInspector.Inspect(request with { Bundle = unknownBundle });
        Assert.Equal(EpochInspectionStatus.ArtifactMatched, result.Status); Assert.True(result.WritersMustRemainStopped); AssertUnchanged(before);
    }

    /// <summary>Changed/incomplete/foreign candidates require reconciliation, never repair or cleanup.</summary>
    /// <param name="restore">Publication role.</param>
    /// <param name="fault">Candidate or correlation damage.</param>
    [Theory]
    [InlineData(false, "missing-generation")]
    [InlineData(false, "missing-reader")]
    [InlineData(false, "missing-writer")]
    [InlineData(false, "origin-checksum")]
    [InlineData(false, "extra-role")]
    [InlineData(false, "staging")]
    [InlineData(false, "advanced")]
    [InlineData(false, "fragment")]
    [InlineData(false, "inventory-request")]
    [InlineData(false, "operation-id")]
    [InlineData(false, "destination-id")]
    [InlineData(false, "partial-wal")]
    [InlineData(false, "coherent-wal")]
    [InlineData(true, "missing-generation")]
    [InlineData(true, "missing-reader")]
    [InlineData(true, "missing-writer")]
    [InlineData(true, "origin-checksum")]
    [InlineData(true, "extra-role")]
    [InlineData(true, "staging")]
    [InlineData(true, "advanced")]
    [InlineData(true, "fragment")]
    [InlineData(true, "inventory-request")]
    [InlineData(true, "operation-id")]
    [InlineData(true, "destination-id")]
    [InlineData(true, "partial-wal")]
    [InlineData(true, "coherent-wal")]
    public void Inspect_ChangedCandidate_ReconcilesWithoutMutation(bool restore, string fault)
    {
        var (request, receipt) = Seed(restore, 1);
        var originPath = Path.Combine(Bundle, restore ? "origin.bin" : "migration.bin");
        switch (fault)
        {
            case "missing-generation": Directory.Delete(EpochScalarHistory.Generation(Store, 1), true); break;
            case "missing-reader": File.Delete(Path.Combine(Store, ".transactions", "readers", EpochAuthorityCodec.ReaderFileName(1))); break;
            case "missing-writer": File.Delete(Path.Combine(Store, ".transactions", "writer.lock")); break;
            case "origin-checksum": var origin = File.ReadAllBytes(originPath); origin[^1] ^= 1; File.WriteAllBytes(originPath, origin); break;
            case "extra-role": File.WriteAllText(Path.Combine(Bundle, "unexpected"), "retain"); break;
            case "staging": File.WriteAllText(Path.Combine(Store, ".transactions", "staging", "pending"), "retain"); break;
            case "advanced":
                using (var owner = ScalarEpochDatabase.Open(Store, new(DurabilityMode.ProcessCrash, ScalarEpochRecovery.FullHistory)))
                { using var read = owner.BeginRead(); using var tx = owner.BeginTransaction(); tx.ReplaceNodeValue(Target(read), "advanced"); tx.Commit(); }
                break;
            case "fragment": var fragment = Directory.GetFiles(Path.Combine(EpochScalarHistory.Generation(Store, 1), "fragments"))[0]; var bytes = File.ReadAllBytes(fragment); bytes[^1] ^= 1; File.WriteAllBytes(fragment, bytes); break;
            case "inventory-request": request = request with { ExpectedInventorySha256 = new string('0', 64) }; break;
            case "operation-id": request = request with { ExpectedOperationId = Guid.NewGuid() }; break;
            case "destination-id": request = request with { ExpectedDestination = receipt.DestinationEpoch with { EpochId = Guid.NewGuid() } }; break;
            case "partial-wal": var wal = Path.Combine(Store, ".transactions", "wal", EpochAuthorityCodec.WalFileName(1)); File.WriteAllBytes(wal, File.ReadAllBytes(wal)[..20]); break;
            case "coherent-wal": ResealCandidateTransaction(restore); break;
        }
        var before = Capture(); var result = EpochPublicationInspector.Inspect(request);
        Assert.Equal(EpochInspectionStatus.ReconciliationRequired, result.Status); Assert.Null(result.Observed); Assert.True(result.WritersMustRemainStopped); AssertUnchanged(before);
    }

    /// <summary>An active cooperating writer makes observation unavailable without being mislabeled as corrupt or implicitly opened.</summary>
    /// <param name="restore">Publication role.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Inspect_ActiveOwner_UnavailableAndReleasesOwnHandles(bool restore)
    {
        var (request, receipt) = Seed(restore, 1); var before = Capture();
        using (var owner = ScalarEpochDatabase.Open(Store, new(DurabilityMode.ProcessCrash, ScalarEpochRecovery.FullHistory)))
        {
            var result = EpochPublicationInspector.Inspect(request); Assert.Equal(EpochInspectionStatus.Unavailable, result.Status); Assert.Null(result.Observed);
        }
        AssertUnchanged(before);
        using var exclusive = EpochAdmission.Acquire(Store, receipt.DestinationEpoch, true, EpochProfile.ScalarWal);
    }

    /// <summary>Changing only resealed provenance identity cannot be attributed to the caller's known operation; unknown callers receive only artifact correlation.</summary>
    /// <param name="restore">Publication role.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void Inspect_ResealedOperationId_DistinguishesCorrelationFromAuthenticity(bool restore)
    {
        var (request, receipt) = Seed(restore, 1); var changed = Guid.NewGuid(); var path = Path.Combine(Bundle, restore ? "origin.bin" : "migration.bin");
        File.WriteAllBytes(path, restore ? EpochBackupCodec.EncodeOrigin(EpochBackupCodec.DecodeOrigin(File.ReadAllBytes(path)) with { RestoreId = changed }) :
            EpochMigrationCodec.Encode(EpochMigrationCodec.Decode(File.ReadAllBytes(path)) with { MigrationId = changed }));
        var before = Capture();
        var unknown = EpochPublicationInspector.Inspect(request); Assert.Equal(EpochInspectionStatus.ArtifactMatched, unknown.Status); Assert.Equal(changed, unknown.Observed!.OperationId);
        Assert.Equal(EpochInspectionStatus.ReconciliationRequired, EpochPublicationInspector.Inspect(request with { ExpectedOperationId = receipt.OperationId }).Status); AssertUnchanged(before);
    }

    /// <summary>Absent publication is a point-in-time observation only and creates no output.</summary>
    [Fact]
    public void Inspect_AbsentBundle_ReportsNotObservedWithoutCreation()
    {
        var (request, _) = Seed(false, 0); var before = Capture(); var absent = Path.Combine(_area, "absent");
        var result = EpochPublicationInspector.Inspect(request with { Bundle = absent }); Assert.Equal(EpochInspectionStatus.NotObserved, result.Status);
        Assert.True(result.WritersMustRemainStopped); AssertUnchanged(before); Assert.False(Directory.Exists(absent));
    }

    /// <summary>Invalid request metadata rejects before filesystem access.</summary>
    [Fact]
    public void Inspect_InvalidRequest_RejectsWithoutIo()
    {
        var request = new EpochPublicationInspectionRequest(EpochPublicationKind.LegacyMigration, "unused-artifact", "unused-bundle", new string('a', 64));
        Assert.Throws<ArgumentNullException>(() => EpochPublicationInspector.Inspect(null!));
        Assert.Throws<ArgumentException>(() => EpochPublicationInspector.Inspect(request with { ExpectedOperationId = Guid.Empty }));
        Assert.Throws<ArgumentException>(() => EpochPublicationInspector.Inspect(request with { ExpectedInventorySha256 = "bad" }));
        Assert.Throws<ArgumentException>(() => EpochPublicationInspector.Inspect(request with { Kind = (EpochPublicationKind)99 }));
        Assert.Throws<ArgumentException>(() => EpochPublicationInspector.Inspect(request with { Bundle = request.Artifact })); Assert.False(Directory.Exists(_area));
    }

    /// <summary>Linked bundle paths reject before following the candidate; the Linux case verifies the actual link boundary.</summary>
    [Fact]
    public void Inspect_LinkedBundle_RejectsWithoutFollowingOrMutating()
    {
        if (!OperatingSystem.IsLinux()) return;
        var (request, _) = Seed(false, 1); var link = Path.Combine(_area, "linked"); Directory.CreateSymbolicLink(link, Bundle);
        var before = Capture(); var result = EpochPublicationInspector.Inspect(request with { Bundle = link });
        Assert.Equal(EpochInspectionStatus.ReconciliationRequired, result.Status); AssertUnchanged(before);
    }

    private (EpochPublicationInspectionRequest Request, EpochPublishedReceipt Receipt) Seed(bool restore, int count)
    {
        Directory.CreateDirectory(_area); var source = Path.Combine(_area, "source"); var artifact = Path.Combine(_area, "legacy");
        using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, source);
        using (var owner = EmbeddedXmlDatabase.Open(source))
        { using var read = owner.BeginRead(); for (var index = 1; index <= count; index++) { using var tx = owner.BeginWrite(); tx.ReplaceNodeValue(Target(read), "new-" + index); tx.Commit(); } owner.CreateBackup(artifact); }
        var admin = ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash));
        EpochPublishedReceipt receipt;
        if (restore)
        {
            var initial = admin.ConvertLegacyBackup(artifact, Path.Combine(_area, "initial")); artifact = Path.Combine(_area, "epoch");
            using (var owner = ScalarEpochDatabase.Open(initial.StorePath, new(DurabilityMode.ProcessCrash, ScalarEpochRecovery.FullHistory))) owner.CreateBackup(artifact);
            receipt = admin.RestoreEpochBackup(artifact, Bundle);
        }
        else receipt = admin.ConvertLegacyBackup(artifact, Bundle);
        return (new(receipt.Kind, artifact, Bundle, Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(Path.Combine(artifact, "inventory.bin")))).ToLowerInvariant()), receipt);
    }
    private void ResealCandidateTransaction(bool restore)
    {
        var format = File.ReadAllBytes(Path.Combine(Store, "FORMAT")); var binding = EpochAuthorityBinding.Create(format, TransactionCodec.ManifestHash(Store, 1));
        var walPath = Path.Combine(Store, ".transactions", "wal", EpochAuthorityCodec.WalFileName(1));
        var wal = EpochAuthorityCodec.DecodeWal(File.ReadAllBytes(walPath), binding); var changed = EpochAuthorityCodec.EncodeWal(wal with { TransactionId = Guid.NewGuid() }); File.WriteAllBytes(walPath, changed); var digest = SHA256.HashData(changed);
        File.WriteAllBytes(Path.Combine(EpochScalarHistory.Generation(Store, 1), "GENERATION"), EpochAuthorityCodec.EncodeGeneration(new(binding, 1, wal.PreviousManifestHash, wal.ManifestHash, digest)));
        File.WriteAllBytes(Path.Combine(Store, ".transactions", "CURRENT"), EpochAuthorityCodec.EncodeCurrent(new(binding, 1, wal.ManifestHash, digest)));
        var origin = Path.Combine(Bundle, restore ? "origin.bin" : "migration.bin");
        File.WriteAllBytes(origin, restore ? EpochBackupCodec.EncodeOrigin(EpochBackupCodec.DecodeOrigin(File.ReadAllBytes(origin)) with { DestinationHeadWalHash = digest }) :
            EpochMigrationCodec.Encode(EpochMigrationCodec.Decode(File.ReadAllBytes(origin)) with { DestinationHeadWalHash = digest }));
    }
    private static ulong Target(ImmutableXmlSnapshot read) => Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id)).Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();
    private sealed record Tree(string[] Directories, Dictionary<string, byte[]> Files);
    private Tree Capture() => new(Directory.GetDirectories(_area, "*", SearchOption.AllDirectories).Order().ToArray(), Directory.GetFiles(_area, "*", SearchOption.AllDirectories).ToDictionary(path => path, File.ReadAllBytes));
    private void AssertUnchanged(Tree before)
    { var after = Capture(); Assert.Equal(before.Directories, after.Directories); Assert.Equal(before.Files.Keys.Order(), after.Files.Keys.Order()); foreach (var pair in before.Files) Assert.Equal(pair.Value, after.Files[pair.Key]); }
    private sealed class NoWritesStorage : ITransactionStorage
    {
        internal int Calls { get; private set; }
        public DurabilityMode Durability => DurabilityMode.ProcessCrash;
        private void Reject() { Calls++; throw new InvalidOperationException("Inspection attempted a storage mutation/barrier."); }
        public ITransactionFile CreateFile(string path) { Reject(); throw new InvalidOperationException(); }
        public void CreateDirectory(string path) => Reject();
        public void MoveFile(string source, string destination, bool overwrite) => Reject();
        public void MoveDirectory(string source, string destination) => Reject();
        public void DeleteFile(string path) => Reject();
        public void DeleteDirectory(string path) => Reject();
        public void SyncDirectory(string path) => Reject();
        public void SyncFile(string path) => Reject();
    }
    /// <summary>Deletes only this test's GUID-owned temporary data after all observation handles close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
