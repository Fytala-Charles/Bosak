// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies cutover process ownership and that process exit cannot preserve readiness evidence.
// SPECIAL NOTES        : Internal prototype acceptance only; no persistent fence, routing service or retirement.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Verifies process-held ownership, exit release and nonpersistent cutover readiness.</summary>
public sealed class MigrationCutoverProcessTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-mg5-process-" + Guid.NewGuid().ToString("N"));
    /// <summary>Owner exit or termination releases OS locks without persisting a cutover fence or route decision.</summary>
    /// <param name="kill">Whether to terminate the holder.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Freeze_HolderExitOrKill_ReleasesOwnershipWithoutRouting(bool kill)
    {
        Directory.CreateDirectory(_area); var root = Path.Combine(_area, "legacy"); var backup = Path.Combine(_area, "backup"); var destination = Path.Combine(_area, "candidate");
        using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, root);
        using (var source = EmbeddedXmlDatabase.Open(root)) { }
        using var pinned = ImmutableXmlSnapshot.OpenVersion(root, 1, 0, 0);
        var info = new ProcessStartInfo("dotnet") { RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false };
        foreach (var arg in new[] { typeof(MigrationCutoverProcessTests).Assembly.Location, "mg5-hold", root, backup, destination }) info.ArgumentList.Add(arg);
        using var process = Process.Start(info) ?? throw new InvalidOperationException("Cannot start cutover holder.");
        var stderr = process.StandardError.ReadToEndAsync();
        try
        {
            var line = await process.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(50)); Assert.NotNull(line);
            using var json = JsonDocument.Parse(line); Assert.Equal("RoutingUncertain", json.RootElement.GetProperty("State").GetString());
            var store = json.RootElement.GetProperty("StorePath").GetString()!;
            var sourceBytes = Bytes(root); var candidateBytes = Bytes(destination);
            Assert.Throws<IOException>(() => EmbeddedXmlDatabase.Open(root)); Assert.Throws<IOException>(() => EpochScalarCoordinator.Open(store));
            if (kill) process.Kill(true); else await process.StandardInput.WriteLineAsync("release");
            await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(20)); if (!kill) Assert.True(process.ExitCode == 0, await stderr);
            AssertBytes(sourceBytes, root); AssertBytes(candidateBytes, destination);
            using var source = EmbeddedXmlDatabase.Open(root); using var candidate = EpochScalarCoordinator.Open(store);
            // No old freeze is inherited: both owners can begin work. No commit or routing occurs here.
            using var legacyTx = source.BeginWrite(); using var epochTx = candidate.BeginTransaction();
            Assert.Equal("old", pinned.ReadValue(Target(pinned)));
        }
        finally { if (!process.HasExited) { process.Kill(true); await process.WaitForExitAsync(); } }
    }
    private static ulong Target(ImmutableXmlSnapshot read) => Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();
    private static Dictionary<string, byte[]> Bytes(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories).Where(p => Path.GetFileName(p) != "writer.lock").ToDictionary(p => Path.GetRelativePath(root, p), File.ReadAllBytes);
    private static void AssertBytes(Dictionary<string, byte[]> expected, string root) { var actual = Bytes(root); Assert.Equal(expected.Keys.Order(), actual.Keys.Order()); foreach (var f in expected) Assert.Equal(f.Value, actual[f.Key]); }
    /// <summary>Removes isolated fixture data after processes and snapshots close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
