// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Qualifies live plan-bound orchestration under actual journal and owner lifetimes.
// SPECIAL NOTES        : Internal pilot qualification; no routing, plan replay or global/adversarial fencing.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Text;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Tests actual journal-backed single dispatch, drain and separate component acknowledgments.</summary>
public sealed class EmbeddedHostOrchestratorTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ep5-" + Guid.NewGuid().ToString("N"));
    private string Artifact => Path.Combine(_area, "artifact");
    private string Destination => Path.Combine(_area, "destination");
    private string HostRoot => Path.Combine(_area, "host");
    private static EpochPublicationKind Kind(bool epoch) => epoch ? EpochPublicationKind.IndependentEpochRestore : EpochPublicationKind.LegacyMigration;
    private EmbeddedHostLifetime Host()
    {
        var host = EmbeddedHostLifetime.Provision(HostRoot, "pilot", "scope", [Path.Combine(_area, "source"), Artifact, Destination, Path.Combine(_area, "legacy"), Path.Combine(_area, "initial")],
            new(HostRoot, "pilot", "scope", true, true, true));
        host.OpenAdministrativeAdmissions(Evidence(host)); Assert.True(host.EnableJournalAppend(host.JournalStatus.KnownPosition, Evidence(host))); return host;
    }
    private static EmbeddedHostAdmissionEvidence Evidence(EmbeddedHostLifetime host) => new(host.Context, true, true, true, true, true, true);
    private static EmbeddedHostInspectionEvidence InspectionEvidence(EmbeddedHostLifetime host) => new(host.Context, true, true, true, true, true);

    /// <summary>Both roles retain H0/H3 history with the exact preannounced ID and separate actual pipeline/journal acknowledgments.</summary>
    /// <param name="epoch">Publication role.</param>
    /// <param name="count">Initial head.</param>
    [Theory]
    [InlineData(false, 0)]
    [InlineData(false, 3)]
    [InlineData(true, 0)]
    [InlineData(true, 3)]
    public void NormalFlow_PublishesAndAcknowledgesExactlyOnce(bool epoch, int count)
    {
        Seed(epoch, count); var inputs = Inputs(); using var host = Host(); var flow = EmbeddedHostOrchestrator.Create(host);
        var ticket = flow.Prepare(Guid.NewGuid(), Kind(epoch), Artifact, Destination); var intent = ticket.Describe();
        Assert.Equal(EmbeddedHostAttemptState.Prepared, ticket.State); Assert.Empty(host.ReadJournalForReconciliation().Frames);
        var record = flow.Record(ticket); Assert.Equal(intent, record.Frame!.Snapshot.Context.Intent);
        var result = flow.Execute(ticket); Assert.Equal(EmbeddedHostExecutionDisposition.Succeeded, result.Disposition);
        Assert.Equal(intent.AttemptId, result.PipelineReceipt!.OperationId); Assert.Equal(result.PipelineReceipt, result.ReceiptSave!.Frame!.Snapshot.Receipt);
        Assert.Equal(HostJournalAppendDisposition.Acknowledged, result.Authorization!.Disposition); Assert.True(result.WritersMustRemainStopped);
        Assert.Equal(EmbeddedHostAttemptState.Completed, ticket.State); Assert.Equal(EpochAttemptState.Dispatched, ticket.PlanState);
        Assert.Equal(3, host.ReadJournalForReconciliation().Frames.Count); Assert.Equal(0, host.ActiveOperations);
        Assert.Throws<InvalidOperationException>(() => flow.Execute(ticket)); Assert.Throws<InvalidOperationException>(() => flow.Record(ticket));
        Assert.Equal(EpochInspectionStatus.KnownOperationMatched, flow.Inspect(intent, InspectionEvidence(host)).Status); AssertInputs(inputs); ReadAll(result.PipelineReceipt, count);
    }

    /// <summary>Null, foreign and unrecorded tickets reject before consuming valid plans or writing host/data output.</summary>
    /// <param name="fault">Invalid ticket use.</param>
    [Theory]
    [InlineData("null")]
    [InlineData("foreign-record")]
    [InlineData("foreign-execute")]
    [InlineData("unrecorded")]
    public void InvalidTicket_RejectsWithoutOutput(string fault)
    {
        Seed(false, 0); using var host = Host(); var flow = EmbeddedHostOrchestrator.Create(host); var other = EmbeddedHostOrchestrator.Create(host);
        var ticket = flow.Prepare(Guid.NewGuid(), Kind(false), Artifact, Destination);
        if (fault == "null") Assert.Throws<ArgumentNullException>(() => flow.Execute(null!));
        else if (fault == "foreign-record") Assert.Throws<ArgumentException>(() => other.Record(ticket));
        else if (fault == "foreign-execute") Assert.Throws<ArgumentException>(() => other.Execute(ticket));
        else Assert.Throws<InvalidOperationException>(() => flow.Execute(ticket));
        Assert.Equal(EmbeddedHostAttemptState.Prepared, ticket.State); Assert.Equal(EpochAttemptState.Prepared, ticket.PlanState);
        Assert.Empty(host.ReadJournalForReconciliation().Frames); Assert.False(Directory.Exists(Destination)); Assert.False(flow.ReconciliationRequired);
    }

    /// <summary>Unknown record/authorization/receipt writes never rearm a ticket; a returned pipeline receipt is preserved independently.</summary>
    /// <param name="epoch">Publication role.</param>
    /// <param name="save">One-based host save number.</param>
    [Theory]
    [InlineData(false, 1)]
    [InlineData(false, 2)]
    [InlineData(false, 3)]
    [InlineData(true, 1)]
    [InlineData(true, 2)]
    [InlineData(true, 3)]
    public void LostHostAcknowledgment_StopsWithoutReplay(bool epoch, int save)
    {
        Seed(epoch, 1); using var host = Host(); var flow = EmbeddedHostOrchestrator.CreateCore(host, ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash)),
            appendCheckpoint: stage => { if (stage == HostAppendStage.Flushed && host.JournalStatus.KnownPosition.Sequence == (ulong)save - 1) throw new IOException("Unknown host save."); });
        var ticket = flow.Prepare(Guid.NewGuid(), Kind(epoch), Artifact, Destination); var intent = ticket.Describe();
        if (save == 1) Assert.Throws<IOException>(() => flow.Record(ticket));
        else
        {
            flow.Record(ticket); var result = flow.Execute(ticket);
            Assert.Equal(save == 2 ? EmbeddedHostExecutionDisposition.NotInvoked : EmbeddedHostExecutionDisposition.ReconciliationRequired, result.Disposition);
            Assert.Equal(save == 3, result.PipelineReceipt is not null); Assert.Null(result.ReceiptSave);
        }
        Assert.Equal(EmbeddedHostAttemptState.ReconciliationRequired, ticket.State); Assert.True(flow.ReconciliationRequired); Assert.True(host.JournalStatus.Faulted);
        Assert.Equal(save == 3 ? EpochAttemptState.Dispatched : EpochAttemptState.Prepared, ticket.PlanState);
        Assert.Equal(save == 3, Directory.Exists(Destination)); Assert.Equal(save, host.ReadJournalForReconciliation().Frames.Count);
        Assert.Throws<InvalidOperationException>(() => flow.Execute(ticket)); Assert.Throws<InvalidOperationException>(() => flow.Record(ticket));
        var observed = flow.Inspect(intent, InspectionEvidence(host)); Assert.Equal(save == 3 ? EpochInspectionStatus.KnownOperationMatched : EpochInspectionStatus.NotObserved, observed.Status);
        Assert.Equal(0, host.ActiveOperations);
    }

    /// <summary>Real pipeline exceptions never become receipts; the host saves uncertainty and allows only read-only bound inspection.</summary>
    /// <param name="epoch">Publication role.</param>
    /// <param name="published">Failure after publication rather than proof.</param>
    [Theory]
    [InlineData(false, false)]
    [InlineData(false, true)]
    [InlineData(true, false)]
    [InlineData(true, true)]
    public void PipelineError_PreservesUnknownPublicationAndOriginalDiagnostics(bool epoch, bool published)
    {
        Seed(epoch, 1); using var host = Host(); var expected = new IOException("Original pipeline error.");
        var admin = ScalarEpochAdministration.CreateCore(new(DurabilityMode.ProcessCrash), new LocalTransactionStorage(), stage =>
        { if (stage == (published ? EpochAdministrativeStage.Published : EpochAdministrativeStage.ProofVerified)) throw expected; });
        var flow = EmbeddedHostOrchestrator.CreateCore(host, admin); var ticket = flow.Prepare(Guid.NewGuid(), Kind(epoch), Artifact, Destination); flow.Record(ticket);
        var result = flow.Execute(ticket); Assert.Equal(EmbeddedHostExecutionDisposition.PipelineFailed, result.Disposition); Assert.Same(expected, result.Error); Assert.Null(result.PipelineReceipt);
        Assert.Null(result.LedgerError); Assert.Equal(HostLedgerStage.Uncertain, host.ReadJournalForReconciliation().Frames[^1].Snapshot.Stage);
        Assert.False(host.AdmissionsOpen); Assert.Equal(EpochAttemptState.Dispatched, ticket.PlanState); Assert.Equal(0, host.ActiveOperations);
        Assert.Equal(published ? EpochInspectionStatus.KnownOperationMatched : EpochInspectionStatus.NotObserved, flow.Inspect(ticket.Describe(), InspectionEvidence(host)).Status);
    }

    /// <summary>Control-boundary failures preserve actual component acknowledgments without reporting normal workflow completion.</summary>
    /// <param name="stage">Orchestration checkpoint.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(2)]
    [InlineData(3)]
    [InlineData(4)]
    [InlineData(5)]
    public void ControlBoundaryError_NeverReplaysOrFabricatesReceipt(int stage)
    {
        Seed(false, 0); using var host = Host(); var selected = (HostOrchestrationStage)stage;
        var flow = EmbeddedHostOrchestrator.CreateCore(host, ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash)),
            checkpoint: at => { if (at == selected) throw new IOException("Control boundary."); });
        var ticket = flow.Prepare(Guid.NewGuid(), Kind(false), Artifact, Destination);
        if (selected == HostOrchestrationStage.IntentAcknowledged) Assert.Throws<IOException>(() => flow.Record(ticket));
        else
        {
            flow.Record(ticket); var result = flow.Execute(ticket); var beforeInvoke = selected is HostOrchestrationStage.AuthorizationAcknowledged or HostOrchestrationStage.BeforeInvoke;
            Assert.Equal(beforeInvoke ? EmbeddedHostExecutionDisposition.NotInvoked : EmbeddedHostExecutionDisposition.ReconciliationRequired, result.Disposition);
            Assert.Equal(!beforeInvoke, result.PipelineReceipt is not null); Assert.Equal(selected == HostOrchestrationStage.BeforeReturn, result.ReceiptSave is not null);
        }
        Assert.True(flow.ReconciliationRequired); Assert.False(host.AdmissionsOpen); Assert.Equal(0, host.ActiveOperations);
        Assert.Throws<InvalidOperationException>(() => flow.Execute(ticket));
    }

    /// <summary>Concurrent use of one live ticket yields one actual executor and one authorization/receipt pair.</summary>
    /// <param name="epoch">Publication role.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ConcurrentTicketExecution_OneWinner(bool epoch)
    {
        Seed(epoch, 0); using var host = Host(); var flow = EmbeddedHostOrchestrator.Create(host);
        var ticket = flow.Prepare(Guid.NewGuid(), Kind(epoch), Artifact, Destination); flow.Record(ticket); using var start = new ManualResetEventSlim();
        var tasks = Enumerable.Range(0, 8).Select(_ => Task.Run(() =>
        {
            start.Wait(); try { return (Result: flow.Execute(ticket), Error: (Exception?)null); }
            catch (Exception error) { return (Result: (EmbeddedHostExecutionResult?)null, Error: error); }
        })).ToArray();
        start.Set(); var outcomes = await Task.WhenAll(tasks); var winner = Assert.Single(outcomes, x => x.Result is not null);
        Assert.Equal(EmbeddedHostExecutionDisposition.Succeeded, winner.Result!.Disposition); Assert.Equal(7, outcomes.Count(x => x.Error is InvalidOperationException));
        Assert.Equal(3, host.ReadJournalForReconciliation().Frames.Count); Assert.False(flow.ReconciliationRequired); Assert.Equal(0, host.ActiveOperations);
    }

    /// <summary>Actual running publishers retain host ownership through shutdown; an unsaved receipt remains a separate actual return.</summary>
    /// <param name="epoch">Publication role.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ShutdownDuringPipeline_RetainsActualExecutorAndReceipt(bool epoch)
    {
        Seed(epoch, 1); using var host = Host(); using var reached = new ManualResetEventSlim(); using var release = new ManualResetEventSlim();
        var admin = ScalarEpochAdministration.CreateCore(new(DurabilityMode.ProcessCrash), new LocalTransactionStorage(), stage =>
        { if (stage == EpochAdministrativeStage.ProofVerified) { reached.Set(); if (!release.Wait(TimeSpan.FromSeconds(30))) throw new TimeoutException(); } });
        var flow = EmbeddedHostOrchestrator.CreateCore(host, admin); var ticket = flow.Prepare(Guid.NewGuid(), Kind(epoch), Artifact, Destination); flow.Record(ticket);
        var execution = Task.Run(() => flow.Execute(ticket)); EmbeddedHostExecutionResult? result = null;
        try
        {
            Assert.True(reached.Wait(TimeSpan.FromSeconds(30))); host.Dispose(); Assert.False(host.WhenReleased.IsCompleted);
            Assert.Throws<IOException>(() => { using var contender = EmbeddedHostLifetime.OpenExisting(HostRoot, "pilot", "scope", [Artifact, Destination]); });
        }
        finally { release.Set(); result = await execution; }
        await host.WhenReleased.WaitAsync(TimeSpan.FromSeconds(5)); Assert.Equal(EmbeddedHostExecutionDisposition.ReconciliationRequired, result.Disposition);
        Assert.NotNull(result.PipelineReceipt); Assert.Null(result.ReceiptSave); Assert.Equal(0, host.ActiveOperations);
        using var observer = EmbeddedHostLifetime.OpenExisting(HostRoot, "pilot", "scope", [Artifact, Destination]);
        Assert.Equal(2, observer.History.Frames.Count); Assert.False(observer.AdmissionsOpen);
    }

    /// <summary>A second orchestrator cannot reserve another executor while the same host has an active publisher.</summary>
    [Fact]
    public async Task DifferentFronts_ShareOneHostExecutorReservation()
    {
        Seed(false, 0); using var host = Host(); using var reached = new ManualResetEventSlim(); using var release = new ManualResetEventSlim();
        var admin = ScalarEpochAdministration.CreateCore(new(DurabilityMode.ProcessCrash), new LocalTransactionStorage(), stage =>
        { if (stage == EpochAdministrativeStage.ProofVerified) { reached.Set(); if (!release.Wait(TimeSpan.FromSeconds(30))) throw new TimeoutException(); } });
        var a = EmbeddedHostOrchestrator.CreateCore(host, admin); var b = EmbeddedHostOrchestrator.Create(host);
        var first = a.Prepare(Guid.NewGuid(), Kind(false), Artifact, Destination); var other = b.Prepare(Guid.NewGuid(), Kind(false), Artifact, Path.Combine(_area, "other"));
        a.Record(first); b.Record(other); var active = Task.Run(() => a.Execute(first));
        try
        {
            Assert.True(reached.Wait(TimeSpan.FromSeconds(30))); var rejected = b.Execute(other);
            Assert.Equal(EmbeddedHostExecutionDisposition.NotInvoked, rejected.Disposition); Assert.Null(rejected.Authorization); Assert.Equal(EpochAttemptState.Prepared, other.PlanState);
        }
        finally { release.Set(); await active; }
        Assert.False(Directory.Exists(Path.Combine(_area, "other"))); Assert.Equal(0, host.ActiveOperations);
    }
    /// <summary>A low-level state change after record cannot be adopted as this live ticket's own authorization.</summary>
    [Fact]
    public void ChangedPersistedAttempt_PreventsInvocation()
    {
        Seed(false, 0); using var host = Host(); var flow = EmbeddedHostOrchestrator.Create(host);
        var ticket = flow.Prepare(Guid.NewGuid(), Kind(false), Artifact, Destination); flow.Record(ticket);
        var old = host.ReadJournalForReconciliation().Frames[^1].Snapshot;
        host.AppendJournal(host.JournalStatus.KnownPosition, HostJournalEvent.AuthorizeDispatch,
            old with { Context = old.Context with { Revision = 2 }, Stage = HostLedgerStage.DispatchAuthorized });
        var result = flow.Execute(ticket); Assert.Equal(EmbeddedHostExecutionDisposition.NotInvoked, result.Disposition);
        Assert.Null(result.Authorization); Assert.Equal(EpochAttemptState.Prepared, ticket.PlanState); Assert.False(Directory.Exists(Destination));
    }

    /// <summary>Read-only reconciliation rejects tampered descriptors or stale/unbound exclusion facts and never rearms tickets.</summary>
    /// <param name="fault">Reconciliation context mismatch.</param>
    [Theory]
    [InlineData("descriptor")]
    [InlineData("session")]
    [InlineData("stale")]
    [InlineData("prior")]
    [InlineData("writers")]
    public void InvalidInspectionEvidence_Rejects(string fault)
    {
        Seed(false, 0); using var host = Host(); var flow = EmbeddedHostOrchestrator.Create(host);
        var ticket = flow.Prepare(Guid.NewGuid(), Kind(false), Artifact, Destination); flow.Record(ticket);
        var descriptor = fault == "descriptor" ? ticket.Describe() with { BackupId = Guid.NewGuid() } : ticket.Describe();
        var evidence = InspectionEvidence(host); evidence = fault switch
        {
            "session" => evidence with { Context = evidence.Context with { SessionId = Guid.NewGuid() } },
            "stale" => evidence with { Fresh = false },
            "prior" => evidence with { PriorExecutorsExcluded = false },
            "writers" => evidence with { AllWritersControlled = false },
            _ => evidence
        };
        Assert.Throws<InvalidOperationException>(() => flow.Inspect(descriptor, evidence)); Assert.Equal(EmbeddedHostAttemptState.Recorded, ticket.State);
        Assert.Single(host.ReadJournalForReconciliation().Frames); Assert.False(Directory.Exists(Destination));
    }

    /// <summary>Saved descriptive records have no public ticket constructor or clone authority.</summary>
    [Fact]
    public void Ticket_IsSealedWithPrivateConstructor()
    {
        Assert.True(typeof(EmbeddedHostAttempt).IsSealed);
        Assert.Empty(typeof(EmbeddedHostAttempt).GetConstructors(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance));
        Assert.All(typeof(EmbeddedHostAttempt).GetConstructors(System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance), constructor => Assert.True(constructor.IsPrivate));
    }

    /// <summary>Concurrent attempts to persist one ticket produce one acknowledged intent before its one allowed execution.</summary>
    /// <param name="epoch">Publication role.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ConcurrentRecord_OneIntentAndNoPlanConsumption(bool epoch)
    {
        Seed(epoch, 0); using var host = Host(); var flow = EmbeddedHostOrchestrator.Create(host);
        var ticket = flow.Prepare(Guid.NewGuid(), Kind(epoch), Artifact, Destination); using var start = new ManualResetEventSlim();
        var tasks = Enumerable.Range(0, 8).Select(_ => Task.Run(() =>
        {
            start.Wait(); try { return (Result: flow.Record(ticket), Error: (Exception?)null); }
            catch (Exception error) { return (Result: (HostJournalAppendResult?)null, Error: error); }
        })).ToArray();
        start.Set(); var results = await Task.WhenAll(tasks); Assert.Single(results, r => r.Result is not null);
        Assert.Equal(7, results.Count(r => r.Error is InvalidOperationException)); Assert.Equal(EpochAttemptState.Prepared, ticket.PlanState);
        Assert.Single(host.ReadJournalForReconciliation().Frames); Assert.Equal(EmbeddedHostExecutionDisposition.Succeeded, flow.Execute(ticket).Disposition);
    }

    /// <summary>A failed uncertainty save never masks the original library exception or creates an acknowledged receipt.</summary>
    [Fact]
    public void PipelineAndLedgerFailure_PreservesBothErrors()
    {
        Seed(false, 0); using var host = Host(); var pipeline = new IOException("Original pipeline exception.");
        var admin = ScalarEpochAdministration.CreateCore(new(DurabilityMode.ProcessCrash), new LocalTransactionStorage(), stage => { if (stage == EpochAdministrativeStage.Published) throw pipeline; });
        var flow = EmbeddedHostOrchestrator.CreateCore(host, admin, appendCheckpoint: stage =>
        { if (stage == HostAppendStage.Flushed && host.JournalStatus.KnownPosition.Sequence == 2) throw new IOException("Unknown uncertainty save."); });
        var ticket = flow.Prepare(Guid.NewGuid(), Kind(false), Artifact, Destination); flow.Record(ticket); var result = flow.Execute(ticket);
        Assert.Equal(EmbeddedHostExecutionDisposition.PipelineFailed, result.Disposition); Assert.Same(pipeline, result.Error); Assert.IsType<IOException>(result.LedgerError);
        Assert.Null(result.PipelineReceipt); Assert.True(host.JournalStatus.Faulted);
        Assert.Equal(EpochInspectionStatus.KnownOperationMatched, flow.Inspect(ticket.Describe(), InspectionEvidence(host)).Status);
    }

    /// <summary>Shutdown after acknowledged authorization but before executor admission does not invoke the plan.</summary>
    [Fact]
    public async Task ShutdownBeforeInvocation_DoesNotDispatch()
    {
        Seed(false, 0); using var host = Host(); var flow = EmbeddedHostOrchestrator.CreateCore(host, ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash)),
            checkpoint: stage => { if (stage == HostOrchestrationStage.BeforeInvoke) host.Dispose(); });
        var ticket = flow.Prepare(Guid.NewGuid(), Kind(false), Artifact, Destination); flow.Record(ticket); var result = flow.Execute(ticket);
        Assert.Equal(EmbeddedHostExecutionDisposition.NotInvoked, result.Disposition); Assert.NotNull(result.Authorization); Assert.Null(result.PipelineReceipt);
        Assert.Equal(EpochAttemptState.Prepared, ticket.PlanState); Assert.False(Directory.Exists(Destination)); await host.WhenReleased.WaitAsync(TimeSpan.FromSeconds(5));
    }

    /// <summary>Execution retains the original inventory commitment after preparation/record rather than silently preparing changed input.</summary>
    [Fact]
    public void ChangedArtifactAfterRecord_ConsumesPlanButNeverPublishes()
    {
        Seed(false, 0); using var host = Host(); var flow = EmbeddedHostOrchestrator.Create(host);
        var ticket = flow.Prepare(Guid.NewGuid(), Kind(false), Artifact, Destination); var intent = ticket.Describe(); flow.Record(ticket);
        File.WriteAllBytes(Path.Combine(Artifact, "COMPLETE"), [0]); var result = flow.Execute(ticket);
        Assert.Equal(EmbeddedHostExecutionDisposition.PipelineFailed, result.Disposition); Assert.Null(result.PipelineReceipt); Assert.Equal(intent, ticket.Describe());
        Assert.Equal(EpochAttemptState.Dispatched, ticket.PlanState); Assert.False(Directory.Exists(Destination)); Assert.Equal(HostLedgerStage.Uncertain, host.ReadJournalForReconciliation().Frames[^1].Snapshot.Stage);
    }

    /// <summary>Low-level append cannot supersede an active attempt between acknowledged authorization and library invocation.</summary>
    [Fact]
    public void ActiveAttemptMutation_RequiresOpaqueExecutorRegistration()
    {
        Seed(false, 0); using var host = Host(); var checkedGuard = false;
        var flow = EmbeddedHostOrchestrator.CreateCore(host, ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash)), checkpoint: stage =>
        {
            if (stage != HostOrchestrationStage.BeforeInvoke) return;
            var active = host.ReadJournalForReconciliation().Frames[^1].Snapshot;
            Assert.Throws<InvalidOperationException>(() => host.AppendJournal(host.JournalStatus.KnownPosition, HostJournalEvent.MarkUncertain,
                active with { Context = active.Context with { Revision = 3 }, Stage = HostLedgerStage.Uncertain }));
            checkedGuard = true;
        });
        var ticket = flow.Prepare(Guid.NewGuid(), Kind(false), Artifact, Destination); flow.Record(ticket);
        Assert.Equal(EmbeddedHostExecutionDisposition.Succeeded, flow.Execute(ticket).Disposition); Assert.True(checkedGuard);
        Assert.Equal(3, host.ReadJournalForReconciliation().Frames.Count); Assert.False(host.JournalStatus.Faulted);
    }

    private void Seed(bool epoch, int count)
    {
        Directory.CreateDirectory(_area); var source = Path.Combine(_area, "source"); var legacy = epoch ? Path.Combine(_area, "legacy") : Artifact;
        using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, source);
        using (var owner = EmbeddedXmlDatabase.Open(source))
        { using var read = owner.BeginRead(); for (var index = 1; index <= count; index++) { using var tx = owner.BeginWrite(); tx.ReplaceNodeValue(Target(read), "new-" + index); tx.Commit(); } owner.CreateBackup(legacy); }
        if (!epoch) return;
        var result = EpochLegacyMigration.Convert(legacy, Path.Combine(_area, "initial"));
        using var candidate = ScalarEpochDatabase.Open(result.StorePath, new(DurabilityMode.ProcessCrash, ScalarEpochRecovery.FullHistory)); candidate.CreateBackup(Artifact);
    }
    private static void ReadAll(EpochPublishedReceipt result, int count)
    {
        using var admission = EpochAdmission.Acquire(result.StorePath, result.DestinationEpoch, profile: EpochProfile.ScalarWal);
        var binding = EpochEmptyCoordinator.ReadAuthority(result.StorePath, result.DestinationEpoch, true);
        for (ulong sequence = 0; sequence <= (ulong)count; sequence++)
        {
            var hash = sequence == 0 ? binding.BaseHash : EpochAuthorityCodec.DecodeWal(File.ReadAllBytes(Path.Combine(result.StorePath, ".transactions", "wal", EpochAuthorityCodec.WalFileName(sequence))), binding).ManifestHash;
            using var read = EpochScalarHistory.Open(result.StorePath, sequence, admission, hash); Assert.Equal(sequence == 0 ? "old" : "new-" + sequence, read.ReadValue(Target(read)));
        }
    }
    private static ulong Target(ImmutableXmlSnapshot read) => Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id)).Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();
    private sealed record Tree(string[] Directories, Dictionary<string, byte[]> Files);
    private static Tree CaptureTree(string root) => new(Directory.GetDirectories(root, "*", SearchOption.AllDirectories).Order().ToArray(), Directory.GetFiles(root, "*", SearchOption.AllDirectories).ToDictionary(path => path, File.ReadAllBytes));
    private static void AssertTree(Tree before, string root) { var after = CaptureTree(root); Assert.Equal(before.Directories, after.Directories); Assert.Equal(before.Files.Keys.Order(), after.Files.Keys.Order()); foreach (var pair in before.Files) Assert.Equal(pair.Value, after.Files[pair.Key]); }
    private Dictionary<string, Tree> Inputs() => Directory.GetDirectories(_area).Where(path => path != Destination && !Path.GetFileName(path).StartsWith(".xmldb-", StringComparison.Ordinal)).ToDictionary(path => path, CaptureTree);
    private static void AssertInputs(Dictionary<string, Tree> before) { foreach (var pair in before) AssertTree(pair.Value, pair.Key); }
    /// <summary>Deletes only the GUID-owned tree after all real executors, tokens and handles close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
