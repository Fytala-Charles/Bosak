// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Qualifies retained legacy-source ownership across process exit and explicit child drain.
// SPECIAL NOTES        : Fresh real source stores only; no authority output or application writer admission.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Qualifies retained legacy-source ownership across process exit and explicit child drain.</summary>
public sealed class EnrollmentSourceRetentionProcessTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ef1-process-" + Guid.NewGuid().ToString("N"));
    private static Dictionary<string, byte[]> Bytes(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories).Where(p => Path.GetFileName(p) != "writer.lock").ToDictionary(p => p, File.ReadAllBytes);
    private static void AssertBytes(Dictionary<string, byte[]> before, string root)
    { var after = Bytes(root); Assert.Equal(before.Keys.Order(), after.Keys.Order()); foreach (var pair in before) Assert.Equal(pair.Value, after[pair.Key]); }
    private static async Task Stop(Process child) { if (!child.HasExited) { child.Kill(true); await child.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); } }
    private static async Task<string?> Line(Process child) => await child.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(45));

    /// <summary>Original ownership survives disposed wrappers and releases only at actual child drain or process death.</summary>
    /// <param name="armed">Whether source-local arming precedes owner/freeze disposal.</param>
    /// <param name="kill">Whether to terminate the process while ownership is retained.</param>
    /// <returns>A task that completes after two independent process attempts and byte-preservation checks.</returns>
    [Theory]
    [InlineData(false, false)]
    [InlineData(false, true)]
    [InlineData(true, false)]
    [InlineData(true, true)]
    public async Task RetainedChild_ProcessExitOrDrain_PreservesOriginalOwnership(bool armed, bool kill)
    {
        for (var repeat = 0; repeat < 2; repeat++)
        {
            var root = Path.Combine(_area, repeat.ToString(System.Globalization.CultureInfo.InvariantCulture), "source"); var backup = Path.Combine(Path.GetDirectoryName(root)!, "capture");
            using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, root);
            using (var source = EmbeddedXmlDatabase.Open(root)) using (var read = source.BeginRead()) { }
            var before = Bytes(root); var inventory = Directory.GetFileSystemEntries(root, "*", SearchOption.AllDirectories).Order().ToArray();
            var info = new ProcessStartInfo("dotnet") { RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false, CreateNoWindow = true };
            foreach (var arg in new[] { typeof(EnrollmentSourceRetentionProcessTests).Assembly.Location, "ef1-retain", root, backup, armed ? "armed" : "pending" }) info.ArgumentList.Add(arg);
            using var child = Process.Start(info) ?? throw new InvalidOperationException("Cannot start retained source probe."); var errors = child.StandardError.ReadToEndAsync();
            try
            {
                Assert.Equal("HELD", await Line(child));
                Assert.Throws<IOException>(() => { using var blocked = EmbeddedXmlDatabase.Open(root); });
                if (kill) await Stop(child);
                else
                {
                    await child.StandardInput.WriteLineAsync("release"); await child.StandardInput.FlushAsync(); Assert.Equal("RELEASED", await Line(child)); Assert.False(child.HasExited);
                    using (var reopened = EmbeddedXmlDatabase.Open(root)) using (reopened.BeginWrite()) { Assert.False(reopened.EnrollmentOwnershipStatus.StopLatched); }
                    await child.StandardInput.WriteLineAsync("exit"); await child.StandardInput.FlushAsync(); await child.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30));
                    Assert.True(child.ExitCode == 0, await errors);
                }
                using (var reopened = EmbeddedXmlDatabase.Open(root)) using (var read = reopened.BeginRead()) Assert.Equal(0UL, read.CommitSequence);
                AssertBytes(before, root); Assert.Equal(inventory, Directory.GetFileSystemEntries(root, "*", SearchOption.AllDirectories).Order().ToArray());
            }
            finally { await Stop(child); _ = await errors; }
        }
    }
    /// <summary>Deletes only this process test's freshly owned private workspace after all processes and snapshots finish.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
