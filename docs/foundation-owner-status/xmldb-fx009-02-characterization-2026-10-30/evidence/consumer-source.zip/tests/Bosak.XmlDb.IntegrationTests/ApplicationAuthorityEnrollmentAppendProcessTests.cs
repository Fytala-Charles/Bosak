// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 30 October 2026
// PURPOSE              : Qualifies stopped first enrollment and independent process reopen of the exact frame.
// SPECIAL NOTES        : EF3 graceful publication only; interruption/ACK-loss sweeps remain EF4.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 30-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Qualifies stopped first enrollment and independent process reopen of the exact frame.</summary>
public sealed class ApplicationAuthorityEnrollmentAppendProcessTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ef3-process-" + Guid.NewGuid().ToString("N"));
    private static async Task<string?> Line(Process process) => await process.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(45));
    private static async Task Stop(Process process) { if (!process.HasExited) { process.Kill(true); await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); } }
    private static Dictionary<string, byte[]> Bytes(params string[] roots) => roots.SelectMany(r => Directory.GetFiles(r, "*", SearchOption.AllDirectories)).ToDictionary(p => p, File.ReadAllBytes);
    private static void AssertBytes(Dictionary<string, byte[]> expected, params string[] roots)
    { var after = Bytes(roots); Assert.Equal(expected.Keys.Order(), after.Keys.Order()); foreach (var pair in expected) Assert.Equal(pair.Value, after[pair.Key]); }
    /// <summary>Independent process publication preserves source/admin bytes and reopens only as stopped inspection.</summary>
    /// <param name="sequence">Real source history length.</param>
    /// <returns>A task that completes after graceful publication, live-child drain and independent reopen.</returns>
    [Theory]
    [InlineData(0)]
    [InlineData(2)]
    public async Task FirstEnrollment_IndependentPublisher_ReopensExactStoppedHistory(int sequence)
    {
        var source = Path.Combine(_area, "source"); var host = Path.Combine(_area, "host"); var authority = Path.Combine(_area, "authority"); var capture = Path.Combine(_area, "capture"); var adminId = Guid.NewGuid(); var authorityId = Guid.NewGuid();
        using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, source);
        using (var owner = EmbeddedXmlDatabase.Open(source))
        {
            for (var i = 0; i < sequence; i++)
            {
                using var read = owner.BeginRead(); var target = Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();
                using var tx = owner.BeginWrite(); tx.ReplaceNodeValue(target, "new-" + i); tx.Commit();
            }
            using var final = owner.BeginRead();
        }
        Directory.CreateDirectory(host); File.WriteAllBytes(Path.Combine(host, "owner.lock"), []); File.WriteAllBytes(Path.Combine(host, "host.meta"), HostJournalCodec.EncodeMetadata(adminId, "embedded-pilot", "orders")); File.WriteAllBytes(Path.Combine(host, "journal.bin"), []); var before = Bytes(source, host);
        var info = new ProcessStartInfo("dotnet") { RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false, CreateNoWindow = true };
        foreach (var arg in new[] { typeof(ApplicationAuthorityEnrollmentAppendProcessTests).Assembly.Location, "ef3-append", host, authority, source, capture, authorityId.ToString(), adminId.ToString() }) info.ArgumentList.Add(arg);
        using var child = Process.Start(info) ?? throw new InvalidOperationException("Cannot start EF3 publisher."); var errors = child.StandardError.ReadToEndAsync();
        try
        {
            var ack = await Line(child); Assert.NotNull(ack); Assert.StartsWith("ACK:", ack);
            foreach (var path in new[] { Path.Combine(source, ".transactions", "writer.lock"), Path.Combine(host, "owner.lock"), Path.Combine(authority, "authority.lock") }) Assert.Throws<IOException>(() => { using var blocked = new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None); });
            await child.StandardInput.WriteLineAsync("release"); await child.StandardInput.FlushAsync(); Assert.Equal("RELEASED", await Line(child)); Assert.False(child.HasExited);
            AssertBytes(before, source, host); var configuration = new ApplicationAuthorityConfiguration(authorityId, adminId, "embedded-pilot", "orders", "admin", "authority");
            var bytes = File.ReadAllBytes(Path.Combine(authority, "authority.log")); var history = ApplicationAuthorityCodec.DecodeJournal(bytes, ApplicationAuthorityCodec.DecodeMetadata(File.ReadAllBytes(Path.Combine(authority, "authority.meta")), configuration));
            var frame = Assert.Single(history.Frames); Assert.Equal(ack[4..], frame.Digest); Assert.Equal(1UL, frame.Sequence); Assert.Equal((ulong)sequence, Assert.IsType<ApplicationEnroll>(frame.Entry.Data).Source.InitialSequence);
            using (var reopenedSource = EmbeddedXmlDatabase.Open(source)) using (reopenedSource.BeginRead()) { }
            using (var parent = EmbeddedHostLifetime.OpenExisting(host, "embedded-pilot", "orders", [source, capture, authority]))
            using (var inspection = ApplicationAuthorityLifetime.OpenExisting(parent, parent.JournalStatus.KnownPosition, new(parent.Context, true, true, true, true, true), authority, configuration, new Dictionary<string, string> { ["admin"] = host, ["authority"] = authority, ["source"] = source, ["capture"] = capture }))
            { Assert.Equal(frame, Assert.Single(inspection.Inspect().Frames)); Assert.True(inspection.WritersMustRemainStopped); Assert.Throws<InvalidOperationException>(() => inspection.ReserveInitializer()); }
            Assert.Equal(bytes, File.ReadAllBytes(Path.Combine(authority, "authority.log")));
            await child.StandardInput.WriteLineAsync("exit"); await child.StandardInput.FlushAsync(); await child.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); Assert.True(child.ExitCode == 0, await errors);
        }
        finally { await Stop(child); _ = await errors; }
    }
    /// <summary>Removes only the fresh owned workspace after processes and handles close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
