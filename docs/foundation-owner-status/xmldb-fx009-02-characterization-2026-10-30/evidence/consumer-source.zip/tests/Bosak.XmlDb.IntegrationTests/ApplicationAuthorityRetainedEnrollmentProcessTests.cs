// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Qualifies combined retained enrollment ownership through real process exit and drain.
// SPECIAL NOTES        : EF2 real owners only; authority log stays empty and no application work is invoked.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Qualifies combined retained enrollment ownership through real process exit and drain.</summary>
public sealed class ApplicationAuthorityRetainedEnrollmentProcessTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ef2-process-" + Guid.NewGuid().ToString("N"));
    private static async Task<string?> Line(Process process) => await process.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(45));
    private static async Task Stop(Process process) { if (!process.HasExited) { process.Kill(true); await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); } }
    private static Dictionary<string, byte[]> Bytes(params string[] roots) => roots.SelectMany(r => Directory.GetFiles(r, "*", SearchOption.AllDirectories)).ToDictionary(p => p, File.ReadAllBytes);
    private static void AssertBytes(Dictionary<string, byte[]> expected, params string[] roots)
    { var after = Bytes(roots); Assert.Equal(expected.Keys.Order(), after.Keys.Order()); foreach (var pair in expected) Assert.Equal(pair.Value, after[pair.Key]); }
    /// <summary>All original owners survive disposed caller wrappers until actual execution drain or process exit.</summary>
    /// <param name="kill">Whether to terminate the holder rather than release the actual execution.</param>
    /// <returns>A task that completes after three independent process attempts and retained-byte checks.</returns>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ArmedExecution_ProcessExitOrDrain_RetainsThreeOwners(bool kill)
    {
        for (var repeat = 0; repeat < 3; repeat++)
        {
            var area = Path.Combine(_area, repeat.ToString(System.Globalization.CultureInfo.InvariantCulture)); var source = Path.Combine(area, "source"); var host = Path.Combine(area, "host");
            var authority = Path.Combine(area, "authority"); var capture = Path.Combine(area, "capture"); var adminId = Guid.NewGuid(); var authorityId = Guid.NewGuid();
            using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, source);
            using (var owner = EmbeddedXmlDatabase.Open(source)) using (owner.BeginRead()) { }
            Directory.CreateDirectory(host); File.WriteAllBytes(Path.Combine(host, "owner.lock"), []); File.WriteAllBytes(Path.Combine(host, "host.meta"), HostJournalCodec.EncodeMetadata(adminId, "embedded-pilot", "orders")); File.WriteAllBytes(Path.Combine(host, "journal.bin"), []);
            var before = Bytes(source, host);
            var info = new ProcessStartInfo("dotnet") { RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false, CreateNoWindow = true };
            foreach (var arg in new[] { typeof(ApplicationAuthorityRetainedEnrollmentProcessTests).Assembly.Location, "ef2-hold", host, authority, source, capture, authorityId.ToString(), adminId.ToString() }) info.ArgumentList.Add(arg);
            using var child = Process.Start(info) ?? throw new InvalidOperationException("Cannot start EF2 holder."); var errors = child.StandardError.ReadToEndAsync();
            try
            {
                Assert.Equal("HELD", await Line(child));
                foreach (var path in new[] { Path.Combine(source, ".transactions", "writer.lock"), Path.Combine(host, "owner.lock"), Path.Combine(authority, "authority.lock") })
                    Assert.Throws<IOException>(() => { using var blocked = new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None); });
                if (kill) await Stop(child);
                else
                {
                    await child.StandardInput.WriteLineAsync("release"); await child.StandardInput.FlushAsync(); Assert.Equal("RELEASED", await Line(child)); Assert.False(child.HasExited);
                    using (var reopened = EmbeddedXmlDatabase.Open(source)) using (reopened.BeginRead()) { }
                    await child.StandardInput.WriteLineAsync("exit"); await child.StandardInput.FlushAsync(); await child.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); Assert.True(child.ExitCode == 0, await errors);
                }
                AssertBytes(before, source, host); Assert.Empty(File.ReadAllBytes(Path.Combine(authority, "authority.log"))); Assert.Equal(3, Directory.GetFiles(authority).Length);
                var configuration = new ApplicationAuthorityConfiguration(authorityId, adminId, "embedded-pilot", "orders", "admin", "authority");
                Assert.Equal(ApplicationAuthorityCodec.EncodeMetadata(configuration), File.ReadAllBytes(Path.Combine(authority, "authority.meta")));
                using var parent = EmbeddedHostLifetime.OpenExisting(host, "embedded-pilot", "orders", [source, capture, authority]);
                using var inspection = ApplicationAuthorityLifetime.OpenExisting(parent, parent.JournalStatus.KnownPosition, new(parent.Context, true, true, true, true, true), authority, configuration,
                    new Dictionary<string, string> { ["admin"] = host, ["authority"] = authority, ["source"] = source, ["capture"] = capture });
                Assert.Empty(inspection.Inspect().Frames); Assert.Throws<InvalidOperationException>(() => inspection.ReserveInitializer());
            }
            finally { await Stop(child); _ = await errors; }
        }
    }
    /// <summary>Removes only this process test's fresh owned workspace after processes and real handles close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
