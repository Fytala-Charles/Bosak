// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Qualifies stopped restart inspection and separately acknowledged outcome saves.
// SPECIAL NOTES        : Internal pilot qualification; no routing, plan replay or global/adversarial fencing.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Text;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Tests actual stopped restart observations without executable ticket reconstruction.</summary>
public sealed class EmbeddedHostRestartReconcilerTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ep6b-" + Guid.NewGuid().ToString("N"));
    private string Artifact => Path.Combine(_area, "artifact");
    private string Destination => Path.Combine(_area, "destination");
    private string HostRoot => Path.Combine(_area, "host");
    private static EpochPublicationKind Kind(bool epoch) => epoch ? EpochPublicationKind.IndependentEpochRestore : EpochPublicationKind.LegacyMigration;
    private EmbeddedHostLifetime Host()
    {
        var host = EmbeddedHostLifetime.Provision(HostRoot, "pilot", "scope", [Path.Combine(_area, "source"), Artifact, Destination, Path.Combine(_area, "legacy"), Path.Combine(_area, "initial")],
            new(HostRoot, "pilot", "scope", true, true, true));
        host.OpenAdministrativeAdmissions(Evidence(host)); Assert.True(host.EnableJournalAppend(host.JournalStatus.KnownPosition, Evidence(host))); return host;
    }
    private static EmbeddedHostAdmissionEvidence Evidence(EmbeddedHostLifetime host) => new(host.Context, true, true, true, true, true, true);
    private static EmbeddedHostInspectionEvidence InspectionEvidence(EmbeddedHostLifetime host) => new(host.Context, true, true, true, true, true);


    private EmbeddedHostLifetime Reopen() => EmbeddedHostLifetime.OpenExisting(HostRoot, "pilot", "scope", [Path.Combine(_area, "source"), Artifact, Destination, Path.Combine(_area, "legacy"), Path.Combine(_area, "initial")]);
    private HostLedgerSnapshot Saved(bool epoch, bool publish, bool acknowledge)
    {
        using var host = Host(); var flow = EmbeddedHostOrchestrator.Create(host); var ticket = flow.Prepare(Guid.NewGuid(), Kind(epoch), Artifact, Destination); flow.Record(ticket);
        if (publish)
        {
            if (acknowledge) Assert.Equal(EmbeddedHostExecutionDisposition.Succeeded, flow.Execute(ticket).Disposition);
            else
            {
                var uncertain = EmbeddedHostOrchestrator.CreateCore(host, ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash)), checkpoint: stage =>
                { if (stage == HostOrchestrationStage.BeforeReceiptSave) throw new IOException("Lost receipt save."); });
                var own = uncertain.Prepare(Guid.NewGuid(), Kind(epoch), Artifact, Destination); uncertain.Record(own);
                Assert.Equal(EmbeddedHostExecutionDisposition.ReconciliationRequired, uncertain.Execute(own).Disposition);
            }
        }
        return host.ReadJournalForReconciliation().Frames[^1].Snapshot;
    }
    private static EmbeddedHostAbsenceEvidence Absence(EmbeddedHostLifetime host, HostLedgerSnapshot snapshot) => new(host.Context, snapshot, true, true, true);

    /// <summary>Both roles and heads persist actual known observations separately from receipts, or qualified absence.</summary>
    /// <param name="epoch">Role.</param><param name="head">Source head.</param><param name="mode">Prior outcome.</param>
    [Theory]
    [InlineData(false, 0, "absent")]
    [InlineData(false, 3, "absent")]
    [InlineData(true, 0, "absent")]
    [InlineData(true, 3, "absent")]
    [InlineData(false, 0, "known")]
    [InlineData(false, 3, "known")]
    [InlineData(true, 0, "known")]
    [InlineData(true, 3, "known")]
    [InlineData(false, 0, "ack")]
    [InlineData(false, 3, "ack")]
    [InlineData(true, 0, "ack")]
    [InlineData(true, 3, "ack")]
    public void ReopenPersistsExactOutcome(bool epoch, int head, string mode)
    {
        Seed(epoch, head); var saved = Saved(epoch, mode != "absent", mode == "ack"); using var host = Reopen();
        var result = EmbeddedHostRestartReconciler.Reconcile(host, host.JournalStatus.KnownPosition, saved, InspectionEvidence(host), Absence(host, saved));
        Assert.NotNull(result.Transfer); Assert.False(host.AdmissionsOpen); Assert.False(host.JournalStatus.CanAttemptAppend); Assert.True(result.WritersMustRemainStopped);
        Assert.Equal(host.Context.SessionId, result.Snapshot.Context.OwnerSession); Assert.Equal(saved.Context.OwnerGeneration + 1, result.Snapshot.Context.OwnerGeneration);
        if (mode == "absent") { Assert.Equal(EmbeddedHostReconciliationDisposition.QualifiedAbsent, result.Disposition); Assert.Equal(HostLedgerStage.ReconciledAbsent, result.Snapshot.Stage); Assert.NotNull(result.Outcome); Assert.Null(result.Snapshot.Receipt); }
        else
        {
            Assert.Equal(EmbeddedHostReconciliationDisposition.KnownPublication, result.Disposition);
            Assert.Equal(saved.Context.Intent.AttemptId, result.Observation.Observed!.OperationId);
            if (mode == "ack") { Assert.Equal(saved.Receipt, result.Snapshot.Receipt); Assert.Null(result.Outcome); }
            else { Assert.Null(result.Snapshot.Receipt); Assert.NotNull(result.Snapshot.Observed); Assert.NotNull(result.Outcome); }
        }
        Assert.Equal(result.Snapshot, host.ReadJournalForReconciliation().Frames[^1].Snapshot);
    }
    /// <summary>Point-in-time absence cannot be saved without every bound namespace fact.</summary>
    /// <param name="invalid">Invalid absence fact.</param>
    [Theory]
    [InlineData("missing")]
    [InlineData("context")]
    [InlineData("snapshot")]
    [InlineData("fresh")]
    [InlineData("namespace")]
    [InlineData("retained")]
    public void AbsenceRequiresAdditionalEvidence(string invalid)
    {
        Seed(false, 0); var saved = Saved(false, false, false); using var host = Reopen(); var a = Absence(host, saved);
        a = invalid switch { "context" => a with { Context = a.Context with { SessionId = Guid.NewGuid() } }, "snapshot" => a with { Expected = saved with { Context = saved.Context with { Revision = 99 } } }, "fresh" => a with { Fresh = false }, "namespace" => a with { StableDestinationNamespace = false }, "retained" => a with { NoRetainedPublicationEvidence = false }, _ => a };
        var result = EmbeddedHostRestartReconciler.Reconcile(host, host.JournalStatus.KnownPosition, saved, InspectionEvidence(host), invalid == "missing" ? null : a);
        Assert.Equal(EmbeddedHostReconciliationDisposition.EvidenceRequired, result.Disposition); Assert.Null(result.Outcome); Assert.Equal(HostLedgerStage.Uncertain, result.Snapshot.Stage); Assert.False(host.AdmissionsOpen);
    }
    /// <summary>Invalid pinned artifacts cannot become reconciled absence.</summary>
    /// <param name="epoch">Role.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void CorruptArtifactStaysStopped(bool epoch)
    {
        Seed(epoch, 0); var saved = Saved(epoch, false, false); File.WriteAllBytes(Path.Combine(Artifact, "COMPLETE"), [0]); using var host = Reopen();
        var result = EmbeddedHostRestartReconciler.Reconcile(host, host.JournalStatus.KnownPosition, saved, InspectionEvidence(host), Absence(host, saved));
        Assert.Equal(EmbeddedHostReconciliationDisposition.EvidenceRequired, result.Disposition); Assert.Null(result.Outcome); Assert.False(host.AdmissionsOpen);
    }
    /// <summary>Unknown transfer or outcome acknowledgments fault the session and never replay saves.</summary>
    /// <param name="save">Faulted save index.</param>
    [Theory]
    [InlineData(1)]
    [InlineData(2)]
    public void LostSaveAcknowledgmentFaults(int save)
    {
        Seed(false, 0); var saved = Saved(false, false, false); using var host = Reopen(); var writes = 0;
        Assert.Throws<IOException>(() => EmbeddedHostRestartReconciler.Reconcile(host, host.JournalStatus.KnownPosition, saved, InspectionEvidence(host), Absence(host, saved), stage =>
        { if (stage == HostAppendStage.Flushed && ++writes == save) throw new IOException(); }));
        Assert.True(host.JournalStatus.Faulted); Assert.False(host.AdmissionsOpen); Assert.Equal(1 + save, host.ReadJournalForReconciliation().Frames.Count);
    }
    /// <summary>A mismatched snapshot is rejected before transfer or inspection.</summary>
    [Fact]
    public void ChangedSnapshotDoesNotWrite()
    {
        Seed(false, 0); var saved = Saved(false, false, false); var before = File.ReadAllBytes(Path.Combine(HostRoot, "journal.bin")); using var host = Reopen();
        Assert.Throws<InvalidOperationException>(() => EmbeddedHostRestartReconciler.Reconcile(host, host.JournalStatus.KnownPosition, saved with { Context = saved.Context with { Revision = 99 } }, InspectionEvidence(host)));
        host.Dispose(); Assert.Equal(before, File.ReadAllBytes(Path.Combine(HostRoot, "journal.bin")));
    }
    /// <summary>A prior actual receipt contradicts fresh absence and is never replaced.</summary>
    /// <param name="epoch">Role.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void AcknowledgedButMissingPublicationContradicts(bool epoch)
    {
        Seed(epoch, 0); var saved = Saved(epoch, true, true);
        Directory.Move(Destination, Path.Combine(_area, "retained-candidate"));
        using var host = Reopen();
        var result = EmbeddedHostRestartReconciler.Reconcile(host, host.JournalStatus.KnownPosition, saved, InspectionEvidence(host), Absence(host, saved));
        Assert.Equal(EmbeddedHostReconciliationDisposition.Contradiction, result.Disposition); Assert.Equal(saved.Receipt, result.Snapshot.Receipt); Assert.Null(result.Outcome);
        Assert.True(Directory.Exists(Path.Combine(_area, "retained-candidate"))); Assert.False(host.AdmissionsOpen);
    }
    /// <summary>Fresh inspection of a terminal absent snapshot does not create another outcome record.</summary>
    [Fact]
    public void RepeatedAbsentInspectionDoesNotReplayOutcome()
    {
        Seed(false, 0); var saved = Saved(false, false, false); using var host = Reopen();
        var first = EmbeddedHostRestartReconciler.Reconcile(host, host.JournalStatus.KnownPosition, saved, InspectionEvidence(host), Absence(host, saved));
        var before = host.JournalStatus.KnownPosition;
        var second = EmbeddedHostRestartReconciler.Reconcile(host, before, first.Snapshot, InspectionEvidence(host), Absence(host, first.Snapshot));
        Assert.Equal(EmbeddedHostReconciliationDisposition.QualifiedAbsent, second.Disposition); Assert.Null(second.Transfer); Assert.Null(second.Outcome); Assert.Equal(before, host.JournalStatus.KnownPosition);
    }
    private void Seed(bool epoch, int count)
    {
        Directory.CreateDirectory(_area); var source = Path.Combine(_area, "source"); var legacy = epoch ? Path.Combine(_area, "legacy") : Artifact;
        using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, source);
        using (var owner = EmbeddedXmlDatabase.Open(source))
        { using var read = owner.BeginRead(); for (var index = 1; index <= count; index++) { using var tx = owner.BeginWrite(); tx.ReplaceNodeValue(Target(read), "new-" + index); tx.Commit(); } owner.CreateBackup(legacy); }
        if (!epoch) return;
        var result = EpochLegacyMigration.Convert(legacy, Path.Combine(_area, "initial"));
        using var candidate = ScalarEpochDatabase.Open(result.StorePath, new(DurabilityMode.ProcessCrash, ScalarEpochRecovery.FullHistory)); candidate.CreateBackup(Artifact);
    }
    private static ulong Target(ImmutableXmlSnapshot read) => Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id)).Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();

    /// <summary>Deletes only the GUID-owned fixture after all handles close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
