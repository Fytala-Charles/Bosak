// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Tests host lifetime drain around actual planned publication.
// SPECIAL NOTES        : Test-only token integration; host persistence/provisioning and global fencing remain open.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Text;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Retains real ownership while a registered library publisher is still executing.</summary>
public sealed class EmbeddedHostPublicationTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ep3-publication-" + Guid.NewGuid().ToString("N"));
    private string Artifact => Path.Combine(_area, "artifact");
    private string Destination => Path.Combine(_area, "destination");

    /// <summary>Shutdown holds the host lock through actual publication; completion then releases ownership with all writers stopped.</summary>
    /// <param name="epoch">Restore rather than migrate.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ActualPublisher_ShutdownRetainsLeaseUntilCompleted(bool epoch)
    {
        Seed(epoch, 1); var root = Path.Combine(_area, "host"); Directory.CreateDirectory(root);
        File.WriteAllBytes(Path.Combine(root, "owner.lock"), []);
        File.WriteAllBytes(Path.Combine(root, "host.meta"), HostJournalCodec.EncodeMetadata(Guid.NewGuid(), "pilot", "scope"));
        File.WriteAllBytes(Path.Combine(root, "journal.bin"), []);
        var before = Directory.GetFiles(root).ToDictionary(path => path, File.ReadAllBytes);
        EmbeddedHostLifetime Open() => EmbeddedHostLifetime.OpenExisting(root, "pilot", "scope", [Path.Combine(_area, "source"), Artifact, Destination, Path.Combine(_area, "legacy"), Path.Combine(_area, "initial")]);
        using var owner = Open(); owner.OpenAdministrativeAdmissions(new(owner.Context, true, true, true, true, true, true));
        using var reached = new ManualResetEventSlim(); using var release = new ManualResetEventSlim();
        var admin = ScalarEpochAdministration.CreateCore(new(DurabilityMode.ProcessCrash), new LocalTransactionStorage(), stage =>
        {
            if (stage != EpochAdministrativeStage.ProofVerified) return;
            reached.Set(); if (!release.Wait(TimeSpan.FromSeconds(30))) throw new TimeoutException("Publisher release.");
        });
        var plan = admin.PrepareAttempt(epoch ? EpochPublicationKind.IndependentEpochRestore : EpochPublicationKind.LegacyMigration, Artifact, Destination);
        using var operation = owner.BeginOperation(); var execution = Task.Run(() => admin.ExecuteAttempt(plan)); EpochPublishedReceipt? receipt = null;
        try
        {
            Assert.True(reached.Wait(TimeSpan.FromSeconds(30))); owner.Dispose();
            Assert.False(owner.WhenReleased.IsCompleted); Assert.Equal(1, owner.ActiveOperations);
            Assert.Throws<ObjectDisposedException>(() => owner.BeginOperation());
            Assert.Throws<IOException>(() => { using var contender = Open(); });
            Assert.Equal(EpochInspectionStatus.NotObserved, admin.InspectPublication(plan.Describe().ToInspectionRequest()).Status);
        }
        finally { release.Set(); try { receipt = await execution; } finally { operation.Dispose(); } }
        await owner.WhenReleased.WaitAsync(TimeSpan.FromSeconds(5)); Assert.True(owner.IsReleased); Assert.Equal(plan.Describe().AttemptId, receipt!.OperationId);
        using (var next = Open()) { Assert.False(next.AdmissionsOpen); Assert.True(next.WritersMustRemainStopped); Assert.Empty(next.History.Frames); }
        foreach (var pair in before) Assert.Equal(pair.Value, File.ReadAllBytes(pair.Key));
        Assert.Equal(EpochInspectionStatus.KnownOperationMatched, admin.InspectPublication(plan.Describe().ToInspectionRequest()).Status);
    }
    private void Seed(bool epoch, int count)
    {
        Directory.CreateDirectory(_area); var source = Path.Combine(_area, "source"); var legacy = epoch ? Path.Combine(_area, "legacy") : Artifact;
        using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, source);
        using (var owner = EmbeddedXmlDatabase.Open(source))
        { using var read = owner.BeginRead(); for (var index = 1; index <= count; index++) { using var tx = owner.BeginWrite(); tx.ReplaceNodeValue(Target(read), "new-" + index); tx.Commit(); } owner.CreateBackup(legacy); }
        if (!epoch) return;
        var result = EpochLegacyMigration.Convert(legacy, Path.Combine(_area, "initial"));
        using var candidate = ScalarEpochDatabase.Open(result.StorePath, new(DurabilityMode.ProcessCrash, ScalarEpochRecovery.FullHistory)); candidate.CreateBackup(Artifact);
    }
    private static ulong Target(ImmutableXmlSnapshot read) => Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();
    /// <summary>Deletes only this test's private tree after the actual publisher and host handle close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
