// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies empty-chain epoch ownership, uncached snapshots and initialization crashes.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Bosak.XmlDb.Storage;
using Bosak.XmlDb.Xdm;
using Bosak.XPath.Api;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Verifies empty-chain epoch ownership, uncached snapshots and initialization crashes.</summary>
public sealed class EpochCoordinatorProcessTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-et4-process-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "epoch");
    private string Source => Path.Combine(_area, "source");

    /// <summary>A terminated initializer releases ownership at every observable admission/writer/reader boundary.</summary>
    /// <param name="stage">Initialization stage or returned acknowledgment.</param>
    [Theory]
    [InlineData("AdmissionAcquired")]
    [InlineData("AuthorityValidated")]
    [InlineData("WriterAcquired")]
    [InlineData("ReaderPublished")]
    [InlineData("Opened")]
    [InlineData("ACK")]
    public async Task Open_ProcessKilled_ReleasesAllHandlesAndReopensEmptyChain(string stage)
    {
        Seed(); var sourceBefore = Bytes(Source);
        var crash = await Run(stage == "ACK" ? "et4-open-ack" : "et4-open", stage);
        Assert.NotEqual(0, crash.Code); Assert.Contains(stage == "ACK" ? "ET4-ACK" : "ET4-FAULT:" + stage, crash.Output);
        Assert.Equal(0, (await Run("et4-try-exclusive")).Code);
        for (var attempt = 0; attempt < 2; attempt++)
        {
            var read = await Run("et4-open"); Assert.Equal(0, read.Code);
            using var json = JsonDocument.Parse(read.Output); Assert.Equal("SO-1", json.RootElement.GetProperty("Value").GetString());
            Assert.Equal(0, json.RootElement.GetProperty("CommitSequence").GetInt32());
        }
        AssertBytes(sourceBefore, Source);
    }

    /// <summary>A live owner excludes another writer and maintenance, then releases them on disposal.</summary>
    [Fact]
    public async Task Owner_CrossProcess_ExcludesWriterAndMaintenance()
    {
        Seed(); using var holder = Start("et4-hold");
        try
        {
            Assert.Equal("OWNED", await holder.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(20)));
            Assert.Equal(3, (await Run("et4-try-open")).Code);
            Assert.Equal(3, (await Run("et4-try-exclusive")).Code);
            await holder.StandardInput.WriteLineAsync(); await holder.StandardInput.FlushAsync();
            await holder.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(20));
            Assert.Equal(0, (await Run("et4-try-open")).Code);
            Assert.Equal(0, (await Run("et4-try-exclusive")).Code);
        }
        finally { if (!holder.HasExited) { holder.Kill(true); await holder.WaitForExitAsync(); } }
    }

    /// <summary>An uncached snapshot retains both epoch/base identities across owners and releases on close or process death.</summary>
    /// <param name="transaction">Whether the holder owns a transaction context instead of a snapshot.</param>
    /// <param name="kill">Whether to kill the old holder.</param>
    [Theory]
    [InlineData(false, false)]
    [InlineData(false, true)]
    [InlineData(true, false)]
    [InlineData(true, true)]
    public async Task Snapshot_OwnerDisposed_RetainsRootAndGenerationProtection(bool transaction, bool kill)
    {
        Seed(); using var holder = Start(transaction ? "et4-pin-transaction" : "et4-pin");
        try
        {
            Assert.Equal("PINNED", await holder.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(20)));
            Assert.Equal(0, (await Run("et4-try-open")).Code);
            Assert.Equal(3, (await Run("et4-try-exclusive")).Code);
            Assert.Equal(3, (await Run("et4-try-base-exclusive")).Code);
            if (kill) holder.Kill(true);
            else
            {
                await holder.StandardInput.WriteLineAsync(); await holder.StandardInput.FlushAsync();
                var line = await holder.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(20));
                using var json = JsonDocument.Parse(line!); Assert.Equal("20", json.RootElement.GetProperty("Value").GetString());
                Assert.True(json.RootElement.GetProperty("Metrics").GetProperty("LineFragmentReads").GetInt64() > 0);
            }
            await holder.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(20));
            Assert.Equal(0, (await Run("et4-try-exclusive")).Code);
            Assert.Equal(0, (await Run("et4-try-base-exclusive")).Code);
        }
        finally { if (!holder.HasExited) { holder.Kill(true); await holder.WaitForExitAsync(); } }
    }

    /// <summary>Empty-chain snapshots use unchanged XPath semantics and avoid line payloads for header/count queries.</summary>
    [Fact]
    public void Snapshot_XPathAndIdentityParity_PreservesLazyReaderBehavior()
    {
        Seed(); using var expected = ImmutableXmlSnapshot.Open(Source);
        var owner = EpochEmptyCoordinator.Open(Root); using var snapshot = owner.BeginRead(0); owner.Dispose();
        var node = new PersistentXdmNode(snapshot); var original = new PersistentXdmNode(expected);
        Assert.Equal(0L, snapshot.Metrics.PhysicalFragmentReads);
        Assert.Equal("SO-1", XPath31Expression.Compile("string(/SalesOrder/SalesOrderHeader/DocumentID)").Evaluate(node).StringValue);
        Assert.Equal(20, XPath31Expression.Compile("count(/SalesOrder/SalesOrderLine)").Evaluate(node).IntegerValue);
        Assert.Equal(0L, snapshot.Metrics.LineFragmentReads);
        foreach (var query in new[] { "string(/SalesOrder/SalesOrderLine[last()]/Item/ItemID)", "string(/SalesOrder/SalesOrderLine[3]/preceding-sibling::SalesOrderLine[1]/Item/ItemID)", "string(/SalesOrder/SalesOrderLine[3]/@number)" })
            Assert.Equal(XPath31Expression.Compile(query).Evaluate(original).StringValue, XPath31Expression.Compile(query).Evaluate(node).StringValue);
        Assert.Equal(expected.NodeCount, snapshot.NodeCount); Assert.Equal(expected.DocumentUri, snapshot.DocumentUri);
    }

    private void Seed()
    {
        Directory.CreateDirectory(_area);
        var xml = "<SalesOrder><SalesOrderHeader><DocumentID>SO-1</DocumentID></SalesOrderHeader>" +
            string.Concat(Enumerable.Range(1, 20).Select(id => $"<SalesOrderLine number='{id}'><Item><ItemID>{id}</ItemID></Item></SalesOrderLine>")) + "</SalesOrder>";
        using var input = new MemoryStream(Encoding.UTF8.GetBytes(xml));
        XmlFragmentImporter.Import(input, Source, linesPerFragment: 4, documentUri: "https://example.test/et4.xml");
        EpochEmptyRoot.CreateFixture(Source, Root, 1, new LocalTransactionStorage());
    }
    private static Dictionary<string, byte[]> Bytes(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories).ToDictionary(path => Path.GetRelativePath(root, path), File.ReadAllBytes);
    private static void AssertBytes(Dictionary<string, byte[]> before, string root)
    { var after = Bytes(root); Assert.Equal(before.Keys.Order(), after.Keys.Order()); foreach (var item in before) Assert.Equal(item.Value, after[item.Key]); }
    private Process Start(string action, string? argument = null)
    {
        var info = new ProcessStartInfo("dotnet") { RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false };
        info.ArgumentList.Add(typeof(EpochCoordinatorProcessTests).Assembly.Location); info.ArgumentList.Add(action); info.ArgumentList.Add(Root);
        if (argument is not null) info.ArgumentList.Add(argument);
        return Process.Start(info) ?? throw new InvalidOperationException("Cannot start ET4 probe.");
    }
    private async Task<(int Code, string Output, string Error)> Run(string action, string? argument = null)
    {
        using var process = Start(action, argument); var stdout = process.StandardOutput.ReadToEndAsync(); var stderr = process.StandardError.ReadToEndAsync();
        try { await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); }
        catch { if (!process.HasExited) process.Kill(true); throw; }
        return (process.ExitCode, await stdout, await stderr);
    }
    /// <inheritdoc />
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
