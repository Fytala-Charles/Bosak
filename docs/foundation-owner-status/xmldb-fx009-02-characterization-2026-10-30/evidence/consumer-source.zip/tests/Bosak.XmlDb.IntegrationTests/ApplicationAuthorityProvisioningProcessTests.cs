// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Qualifies authority provisioning process interruption and independent competing creators.
// SPECIAL NOTES        : Fresh metadata-only roots; no database enrollment, append or application work.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Qualifies authority provisioning process interruption and independent competing creators.</summary>
public sealed class ApplicationAuthorityProvisioningProcessTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ep7c-provision-process-" + Guid.NewGuid().ToString("N"));
    private static readonly Guid Authority = Guid.Parse("10213243-5465-7687-98a9-bacbdcedfe0f");
    private static ApplicationAuthorityConfiguration Configuration(Guid admin) => new(Authority, admin, "embedded-pilot", "orders", "admin-root", "application-root");
    private static Dictionary<string, string> Roots(string host, string root, string source) => new()
    { ["admin-root"] = host, ["application-root"] = root, ["source-root"] = source };
    private static void Seed(string host, string source, Guid admin)
    {
        Directory.CreateDirectory(host); Directory.CreateDirectory(source);
        File.WriteAllBytes(Path.Combine(host, "owner.lock"), []);
        File.WriteAllBytes(Path.Combine(host, "host.meta"), HostJournalCodec.EncodeMetadata(admin, "embedded-pilot", "orders"));
        File.WriteAllBytes(Path.Combine(host, "journal.bin"), []);
        File.WriteAllText(Path.Combine(source, "evidence.txt"), "metadata-only protected source");
    }
    private static EmbeddedHostLifetime Parent(string host, string root, string source) => EmbeddedHostLifetime.OpenExisting(host, "embedded-pilot", "orders", [root, source]);
    private static EmbeddedHostInspectionEvidence Evidence(EmbeddedHostLifetime parent) => new(parent.Context, true, true, true, true, true);
    private static Dictionary<string, byte[]> Bytes(params string[] paths) => paths.Where(Directory.Exists).SelectMany(Directory.GetFiles).ToDictionary(p => p, File.ReadAllBytes);
    private static void AssertBytes(Dictionary<string, byte[]> before, params string[] paths)
    {
        var after = Bytes(paths); Assert.Equal(before.Keys.Order(), after.Keys.Order()); foreach (var pair in before) Assert.Equal(pair.Value, after[pair.Key]);
    }
    private static Process Start(string host, string root, string source, Guid admin, string point)
    {
        var info = new ProcessStartInfo("dotnet") { RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false, CreateNoWindow = true };
        foreach (var arg in new[] { typeof(ApplicationAuthorityProvisioningProcessTests).Assembly.Location, "ep7c-provision", host, root, source, Authority.ToString(), admin.ToString(), point }) info.ArgumentList.Add(arg);
        return Process.Start(info) ?? throw new InvalidOperationException("Cannot start authority provisioning probe.");
    }
    private static async Task<string?> Line(Process child) => await child.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(30));
    private static async Task Continue(Process child) { await child.StandardInput.WriteLineAsync("continue"); await child.StandardInput.FlushAsync(); }
    private static async Task Stop(Process child) { if (!child.HasExited) { child.Kill(true); await child.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); } }

    /// <summary>Actual process death retains exact role inventory and never reconstructs a live initializer.</summary>
    /// <param name="point">Process interruption boundary.</param>
    /// <param name="roles">Expected number of retained authority roles, or minus one for an absent root.</param>
    /// <returns>A task that completes after both independent process attempts are checked.</returns>
    [Theory]
    [InlineData("PreflightValidated", -1)]
    [InlineData("RootCreated", 0)]
    [InlineData("OwnerCreated", 1)]
    [InlineData("OwnerFlushed", 1)]
    [InlineData("MetadataCreated", 2)]
    [InlineData("PartialMetadata", 2)]
    [InlineData("MetadataWritten", 2)]
    [InlineData("MetadataFlushed", 2)]
    [InlineData("JournalCreated", 3)]
    [InlineData("JournalFlushed", 3)]
    [InlineData("BeforeReturn", 3)]
    [InlineData("ACK", 3)]
    [InlineData("RESERVED", 3)]
    [InlineData("DRAIN", 3)]
    public async Task Provision_ProcessDeath_RetainsStoppedOutcome(string point, int roles)
    {
        for (var repeat = 0; repeat < 2; repeat++)
        {
            var area = Path.Combine(_area, repeat.ToString(System.Globalization.CultureInfo.InvariantCulture));
            var host = Path.Combine(area, "host"); var root = Path.Combine(area, "authority"); var source = Path.Combine(area, "source"); var admin = Guid.NewGuid();
            Seed(host, source, admin); var original = Bytes(host, source);
            using var child = Start(host, root, source, admin, point); var errors = child.StandardError.ReadToEndAsync();
            try
            {
                Assert.Equal("AT:" + point, await Line(child));
                Assert.Throws<IOException>(() => { using var blocked = Parent(host, root, source); });
                if (roles >= 1) Assert.Throws<IOException>(() => { using var blocked = new FileStream(Path.Combine(root, "authority.lock"), FileMode.Open, FileAccess.ReadWrite, FileShare.None); });
                await Stop(child); _ = await errors; AssertBytes(original, host, source);
                using var parent = Parent(host, root, source);
                if (roles < 0) { Assert.False(Directory.Exists(root)); continue; }
                Assert.Equal(roles, Directory.GetFiles(root).Length); var retained = Bytes(root);
                if (point == "PartialMetadata") Assert.Equal(56, new FileInfo(Path.Combine(root, "authority.meta")).Length);
                if (roles == 3)
                {
                    Assert.Equal(ApplicationAuthorityCodec.EncodeMetadata(Configuration(admin)), File.ReadAllBytes(Path.Combine(root, "authority.meta")));
                    Assert.Empty(File.ReadAllBytes(Path.Combine(root, "authority.log")));
                    using var authority = ApplicationAuthorityLifetime.OpenExisting(parent, parent.JournalStatus.KnownPosition, Evidence(parent), root, Configuration(admin), Roots(host, root, source));
                    Assert.Empty(authority.Inspect().Frames); Assert.True(authority.WritersMustRemainStopped);
                    Assert.Throws<InvalidOperationException>(() => authority.ReserveInitializer());
                }
                else Assert.Throws<InvalidDataException>(() => ApplicationAuthorityLifetime.OpenExisting(parent, parent.JournalStatus.KnownPosition, Evidence(parent), root, Configuration(admin), Roots(host, root, source)));
                Assert.Throws<IOException>(() => ApplicationAuthorityLifetime.Provision(parent, parent.JournalStatus.KnownPosition, Evidence(parent), root, Configuration(admin), Roots(host, root, source), new(root, true, true, true)));
                AssertBytes(retained, root); parent.Dispose(); AssertBytes(original, host, source);
            }
            finally { await Stop(child); _ = await errors; }
        }
    }

    /// <summary>Independent administrative owners cannot overwrite, complete or clean up the winning authority.</summary>
    /// <param name="repeat">Independent contention schedule.</param>
    /// <returns>A task that completes when both processes exit and the winner is inspected read-only.</returns>
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(2)]
    public async Task Provision_IndependentCreators_OneWinnerRetained(int repeat)
    {
        var root = Path.Combine(_area, "authority"); var source = Path.Combine(_area, "source");
        var hosts = new[] { Path.Combine(_area, "host-a"), Path.Combine(_area, "host-b") }; var admins = new[] { Guid.NewGuid(), Guid.NewGuid() };
        Seed(hosts[0], source, admins[0]); Seed(hosts[1], source, admins[1]); var original = Bytes(hosts[0], hosts[1], source);
        using var a = Start(hosts[0], root, source, admins[0], "RACE"); using var b = Start(hosts[1], root, source, admins[1], "RACE");
        var children = new[] { a, b }; var errors = children.Select(c => c.StandardError.ReadToEndAsync()).ToArray();
        try
        {
            Assert.Equal("READY", await Line(a)); Assert.Equal("READY", await Line(b));
            // Alternate send order while preserving independent process execution.
            await Task.WhenAll(Continue(children[repeat % 2]), Continue(children[1 - repeat % 2]));
            var outcomes = await Task.WhenAll(Line(a), Line(b)); Assert.Equal(new[] { "ACQUIRED", "REJECTED" }, outcomes.Order().ToArray());
            var winner = Array.IndexOf(outcomes, "ACQUIRED"); var loser = 1 - winner;
            await children[loser].WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); Assert.Equal(0, children[loser].ExitCode);
            Assert.Throws<IOException>(() => { using var blocked = new FileStream(Path.Combine(root, "authority.lock"), FileMode.Open, FileAccess.ReadWrite, FileShare.None); });
            var identity = ApplicationAuthorityFileIdentity.PathIdentity(root, true);
            await Continue(children[winner]); await children[winner].WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); Assert.Equal(0, children[winner].ExitCode);
            Assert.Equal(identity, ApplicationAuthorityFileIdentity.PathIdentity(root, true));
            Assert.Equal(3, Directory.GetFiles(root).Length);
            Assert.Equal(ApplicationAuthorityCodec.EncodeMetadata(Configuration(admins[winner])), File.ReadAllBytes(Path.Combine(root, "authority.meta")));
            var retained = Bytes(root);
            using (var parent = Parent(hosts[winner], root, source))
            using (var authority = ApplicationAuthorityLifetime.OpenExisting(parent, parent.JournalStatus.KnownPosition, Evidence(parent), root, Configuration(admins[winner]), Roots(hosts[winner], root, source)))
            { Assert.Empty(authority.Inspect().Frames); Assert.Throws<InvalidOperationException>(() => authority.ReserveInitializer()); }
            AssertBytes(retained, root); AssertBytes(original, hosts[0], hosts[1], source);
        }
        finally { foreach (var child in children) await Stop(child); foreach (var error in errors) _ = await error; }
    }

    /// <summary>Removes only the current test's fresh metadata-only workspace.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
