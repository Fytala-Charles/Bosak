// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies frozen and current public readers reject mutable profiles without mutation.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 27-10-2026     | Parse explicit profiles without widening immutable entry points
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Verifies frozen and current public readers reject mutable profiles without mutation.</summary>
public sealed class MutableProfileRejectionTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-profile-" + Guid.NewGuid().ToString("N"));
    private string Source => Path.Combine(_area, "source");
    private string Root => Path.Combine(_area, "mutable");

    /// <summary>Both frozen generations of reader reject mutable roots/private generations without adopting state.</summary>
    /// <param name="operation">Frozen public entry point.</param>
    /// <param name="generation">Whether to test an internal generation path.</param>
    [Theory]
    [InlineData("raw", false)]
    [InlineData("coordinator", false)]
    [InlineData("durability", false)]
    [InlineData("recovery", false)]
    [InlineData("immutable", false)]
    [InlineData("raw", true)]
    [InlineData("coordinator", true)]
    [InlineData("durability", true)]
    [InlineData("recovery", true)]
    [InlineData("immutable", true)]
    public async Task FrozenReader_MutableProfile_RejectsBeforeAdoption(string operation, bool generation)
    {
        var path = Prepare(generation); var before = Bytes();
        var start = new ProcessStartInfo("dotnet") { RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false };
        start.ArgumentList.Add(typeof(MutableProfileRejectionTests).Assembly.Location);
        start.ArgumentList.Add(operation == "immutable" ? "legacy-immutable-epoch" : "legacy-format");
        start.ArgumentList.Add(path);
        if (operation != "immutable") start.ArgumentList.Add(operation);
        using var process = Process.Start(start) ?? throw new InvalidOperationException("Cannot start frozen profile reader.");
        var stdout = process.StandardOutput.ReadToEndAsync(); var stderr = process.StandardError.ReadToEndAsync();
        try { await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); }
        catch { if (!process.HasExited) process.Kill(true); throw; }
        Assert.Equal(23, process.ExitCode); Assert.Contains("REJECTED", await stdout); Assert.Equal("", await stderr);
        AssertBytes(before);
        Assert.False(File.Exists(Path.Combine(path, ".transactions", "writer.lock")));
    }

    /// <summary>New generic parsing cannot allow current public entry points to acquire admission for a mutable profile.</summary>
    /// <param name="generation">Whether the supplied root is a private generation.</param>
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void CurrentReaders_MutableProfileAndOccupiedLease_RejectBeforeAdmission(bool generation)
    {
        var path = Prepare(generation); var before = Bytes();
        // Occupied stable admission distinguishes profile refusal from an attempted shared acquisition.
        using (var occupied = new FileStream(Path.Combine(Root, ".epoch", "admission.lease"), FileMode.Open, FileAccess.ReadWrite, FileShare.None))
        {
            var failure = Assert.Throws<InvalidDataException>(() => ReadOnlyEpochDatabase.Open(path));
            Assert.Contains("profile", failure.Message, StringComparison.OrdinalIgnoreCase);
            if (generation) Assert.Throws<InvalidDataException>(() => ImmutableXmlSnapshot.Open(path));
            else Assert.Throws<InvalidOperationException>(() => ImmutableXmlSnapshot.Open(path));
            Assert.Throws<InvalidDataException>(() => EmbeddedXmlDatabase.Open(path));
            Assert.Throws<InvalidDataException>(() => EmbeddedXmlDatabase.Open(path, DurabilityMode.ProcessCrash));
            Assert.Throws<InvalidDataException>(() => EmbeddedXmlDatabase.Open(path, RecoveryMode.PreferCheckpoint));
            Assert.Throws<InvalidDataException>(() => EpochAdmission.Acquire(path, EpochCodec.DecodeProfile(File.ReadAllBytes(Path.Combine(path, "FORMAT"))).Identity));
        }
        AssertBytes(before);
    }

    private string Prepare(bool generation)
    {
        Directory.CreateDirectory(_area);
        using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r>old</r>"))) XmlFragmentImporter.Import(input, Source);
        // Synthetic role fixture only, constructed fresh. No in-place conversion or production mutable root builder.
        Directory.CreateDirectory(Root);
        var identity = new EpochIdentity(Guid.NewGuid(), Guid.NewGuid(), 1);
        var format = EpochCodec.EncodeProfile(identity, EpochProfile.ScalarWal);
        File.WriteAllBytes(Path.Combine(Root, "FORMAT"), format);
        File.WriteAllBytes(Path.Combine(Root, "EPOCH"), EpochCodec.EncodeBinding("BXEP", identity, format));
        Directory.CreateDirectory(Path.Combine(Root, ".epoch"));
        File.WriteAllBytes(Path.Combine(Root, ".epoch", "admission.lease"), EpochCodec.EncodeBinding("BXEA", identity, format));
        var manifest = StoreCodec.ReadManifest(TransactionCodec.ReadManifestBytes(Source, 1));
        var names = new[] { "documents/1/manifest.bin", "documents/1/directory.bin" }.Concat(manifest.Fragments.Select(fragment => "fragments/" + fragment.Id.ToString(System.Globalization.CultureInfo.InvariantCulture) + ".bin"));
        BackupStorage.Copy(Source, Root, names, new LocalTransactionStorage());
        var binding = EpochAuthorityBinding.Create(format, TransactionCodec.ManifestHash(Source, 1));
        File.WriteAllBytes(Path.Combine(Root, "BASE"), EpochAuthorityCodec.EncodeBase(new(binding)));
        Directory.CreateDirectory(Path.Combine(Root, ".transactions"));
        File.WriteAllBytes(Path.Combine(Root, ".transactions", "CONTROL"), EpochAuthorityCodec.EncodeControl(EpochAuthorityCodec.CreateControl(binding)));
        if (!generation) return Root;
        var path = Path.Combine(Root, ".transactions", "generations", EpochAuthorityCodec.GenerationName(1));
        Directory.CreateDirectory(path);
        File.WriteAllBytes(Path.Combine(path, "FORMAT"), format);
        BackupStorage.Copy(Source, path, names, new LocalTransactionStorage());
        var wal = EpochAuthorityCodec.EncodeWal(new(binding, 1, Guid.NewGuid(), 2, "new", binding.BaseHash, binding.BaseHash, new byte[32]));
        File.WriteAllBytes(Path.Combine(path, "GENERATION"), EpochAuthorityCodec.EncodeGeneration(new(binding, 1, binding.BaseHash, binding.BaseHash, SHA256.HashData(wal))));
        return path;
    }
    private Dictionary<string, byte[]> Bytes() => Directory.GetFiles(_area, "*", SearchOption.AllDirectories).ToDictionary(path => Path.GetRelativePath(_area, path), File.ReadAllBytes);
    private void AssertBytes(Dictionary<string, byte[]> before)
    { var after = Bytes(); Assert.Equal(before.Keys.Order(), after.Keys.Order()); foreach (var entry in before) Assert.Equal(entry.Value, after[entry.Key]); }
    /// <inheritdoc />
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
