// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Verifies public reader rejection of real migrated bundles and all materialized generations.
// SPECIAL NOTES        : Local baseline compatibility only; no archived release or actual routing claim.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 28-10-2026     | Share physical identity oracle with CA2 lifetime tests
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Verifies local frozen/current public readers cannot adopt real migrated stores or nested roots.</summary>
public sealed class MigratedBundleRejectionTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ca1-" + Guid.NewGuid().ToString("N"));

    /// <summary>Each frozen public entry point rejects wrapper, store and every actual generation without mutation.</summary>
    /// <param name="count">Published history length.</param>
    /// <param name="operation">Frozen entry point.</param>
    [Theory]
    [InlineData(0, "raw")]
    [InlineData(0, "coordinator")]
    [InlineData(0, "durability")]
    [InlineData(0, "recovery")]
    [InlineData(0, "immutable")]
    [InlineData(3, "raw")]
    [InlineData(3, "coordinator")]
    [InlineData(3, "durability")]
    [InlineData(3, "recovery")]
    [InlineData(3, "immutable")]
    public async Task FrozenReaders_PublishedMigration_RejectAllRootsWithoutMutation(int count, string operation)
    {
        var result = Prepare(count); var before = Capture();
        foreach (var path in Paths(result, count))
        {
            var start = new ProcessStartInfo("dotnet") { RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false };
            start.ArgumentList.Add(typeof(MigratedBundleRejectionTests).Assembly.Location);
            start.ArgumentList.Add(operation == "immutable" ? "legacy-immutable-epoch" : "legacy-format");
            start.ArgumentList.Add(path);
            if (operation != "immutable") start.ArgumentList.Add(operation);
            using var process = Process.Start(start) ?? throw new InvalidOperationException("Cannot start frozen reader.");
            var stdout = process.StandardOutput.ReadToEndAsync(); var stderr = process.StandardError.ReadToEndAsync();
            try { await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(30)); }
            catch { if (!process.HasExited) process.Kill(true); throw; }
            var output = await stdout; var error = await stderr;
            Assert.True(process.ExitCode == 23, $"{operation} at {path}: exit={process.ExitCode}, stdout={output}, stderr={error}");
            Assert.Contains("REJECTED", output); Assert.Equal("", error);
            AssertUnchanged(before);
        }
        AssertInternalReadable(result, count); AssertUnchanged(before);
    }

    /// <summary>Current public entry points reject every actual root; internal histories remain readable.</summary>
    /// <param name="count">Published history length.</param>
    [Theory]
    [InlineData(0)]
    [InlineData(3)]
    public void CurrentReaders_PublishedMigration_RejectAllRootsBeforeMutation(int count)
    {
        var result = Prepare(count); var before = Capture();
        {
            foreach (var path in Paths(result, count))
            {
                var wrapper = path == Path.GetDirectoryName(result.StorePath);
                Reject(() => ImmutableXmlSnapshot.Open(path), wrapper, rawStore: path == result.StorePath);
                AssertUnchanged(before);
                Reject(() => EmbeddedXmlDatabase.Open(path), wrapper); AssertUnchanged(before);
                Reject(() => EmbeddedXmlDatabase.Open(path, DurabilityMode.ProcessCrash), wrapper); AssertUnchanged(before);
                Reject(() => EmbeddedXmlDatabase.Open(path, RecoveryMode.PreferCheckpoint), wrapper); AssertUnchanged(before);
                if (wrapper) Reject(() => ReadOnlyEpochDatabase.Open(path), true);
                else
                {
                    var error = Assert.Throws<InvalidDataException>(() => ReadOnlyEpochDatabase.Open(path));
                    Assert.Contains("profile", error.Message, StringComparison.OrdinalIgnoreCase);
                }
                AssertUnchanged(before);
                Reject(() => EpochAdmission.Acquire(path, result.Destination), wrapper); AssertUnchanged(before);
            }
        }
        AssertInternalReadable(result, count); AssertUnchanged(before);
    }

    private static void Reject(Func<IDisposable> open, bool wrapper, bool rawStore = false)
    {
        // A wrapper has no FORMAT; only that exact absent file is an expected I/O rejection.
        if (wrapper)
        {
            var error = Record.Exception(() => { using var unexpected = open(); });
            Assert.True(error is FileNotFoundException or InvalidDataException, error?.ToString() ?? "Wrapper unexpectedly accepted.");
        }
        else if (rawStore) Assert.Throws<InvalidOperationException>(() => { using var unexpected = open(); });
        else Assert.Throws<InvalidDataException>(() => { using var unexpected = open(); });
    }

    private EpochMigrationResult Prepare(int count)
    {
        Directory.CreateDirectory(_area);
        var source = Path.Combine(_area, "source"); var backup = Path.Combine(_area, "backup");
        using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, source);
        using (var owner = EmbeddedXmlDatabase.Open(source))
        {
            for (var sequence = 1; sequence <= count; sequence++)
            {
                using var read = owner.BeginRead(); using var tx = owner.BeginWrite();
                tx.ReplaceNodeValue(Target(read), "new-" + sequence); tx.Commit();
            }
            owner.CreateBackup(backup);
        }
        var result = EpochLegacyMigration.Convert(backup, Path.Combine(_area, "bundle"));
        AssertInternalReadable(result, count);
        return result;
    }

    private static IEnumerable<string> Paths(EpochMigrationResult result, int count)
    {
        yield return Path.GetDirectoryName(result.StorePath)!;
        yield return result.StorePath;
        for (ulong sequence = 1; sequence <= (ulong)count; sequence++)
            yield return Path.Combine(result.StorePath, ".transactions", "generations", EpochAuthorityCodec.GenerationName(sequence));
    }

    private static void AssertInternalReadable(EpochMigrationResult result, int count)
    {
        using var owner = EpochScalarCoordinator.Open(result.StorePath);
        Assert.Equal(result.Destination, owner.Identity);
        using var admission = EpochAdmission.Acquire(result.StorePath, result.Destination, profile: EpochProfile.ScalarWal);
        var binding = EpochEmptyCoordinator.ReadAuthority(result.StorePath, result.Destination, true);
        for (ulong sequence = 0; sequence <= (ulong)count; sequence++)
        {
            var hash = sequence == 0 ? binding.BaseHash : EpochAuthorityCodec.DecodeWal(File.ReadAllBytes(Path.Combine(result.StorePath, ".transactions", "wal", EpochAuthorityCodec.WalFileName(sequence))), binding).ManifestHash;
            using var read = EpochScalarHistory.Open(result.StorePath, sequence, admission, hash);
            Assert.Equal(sequence, read.CommitSequence);
            Assert.Equal(sequence == 0 ? "old" : "new-" + sequence, read.ReadValue(Target(read)));
        }
    }

    private static ulong Target(ImmutableXmlSnapshot read) => Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id))
        .Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();

    private sealed record Tree(string[] Directories, Dictionary<string, byte[]> Files, Dictionary<string, string> Identities);
    private Tree Capture()
    {
        var files = Directory.GetFiles(_area, "*", SearchOption.AllDirectories).ToDictionary(path => Path.GetRelativePath(_area, path), File.ReadAllBytes);
        return new(Directory.GetDirectories(_area, "*", SearchOption.AllDirectories).Select(path => Path.GetRelativePath(_area, path)).Order().ToArray(), files, MigrationRuntimeIdentities.Read(Path.Combine(_area, "bundle", "store")));
    }
    private void AssertUnchanged(Tree before)
    {
        Assert.Equal(before.Directories, Directory.GetDirectories(_area, "*", SearchOption.AllDirectories).Select(path => Path.GetRelativePath(_area, path)).Order());
        var after = Directory.GetFiles(_area, "*", SearchOption.AllDirectories).ToDictionary(path => Path.GetRelativePath(_area, path), File.ReadAllBytes);
        Assert.Equal(before.Files.Keys.Order(), after.Keys.Order());
        foreach (var pair in before.Files) Assert.Equal(pair.Value, after[pair.Key]);
        Assert.Equal(before.Identities.OrderBy(pair => pair.Key), MigrationRuntimeIdentities.Read(Path.Combine(_area, "bundle", "store")).OrderBy(pair => pair.Key));
    }
    /// <summary>Deletes only this test's isolated temporary area after all readers have closed.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
