// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Tests actual orchestration process death across acknowledged dispatch boundaries.
// SPECIAL NOTES        : Stopped restart inspection only; no ticket reconstruction, retry, routing or global fence.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Qualifies durable journal/real publisher process gaps without rebuilding execution authority.</summary>
public sealed class EmbeddedHostOrchestrationProcessTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-ep5-process-" + Guid.NewGuid().ToString("N"));
    private string Artifact => Path.Combine(_area, "artifact");
    private string Destination => Path.Combine(_area, "destination");

    /// <summary>Retained attempt IDs inspect exact process outcomes while every restarted owner stays stopped.</summary>
    /// <param name="epoch">Publication role.</param>
    /// <param name="stage">Actual process termination boundary.</param>
    [Theory]
    [InlineData(false, "IntentAcknowledged")]
    [InlineData(false, "AuthorizationAcknowledged")]
    [InlineData(false, "BeforeInvoke")]
    [InlineData(false, "PipelineReturned")]
    [InlineData(false, "BeforeReceiptSave")]
    [InlineData(false, "BeforeReturn")]
    [InlineData(false, "ACK")]
    [InlineData(true, "IntentAcknowledged")]
    [InlineData(true, "AuthorizationAcknowledged")]
    [InlineData(true, "BeforeInvoke")]
    [InlineData(true, "PipelineReturned")]
    [InlineData(true, "BeforeReceiptSave")]
    [InlineData(true, "BeforeReturn")]
    [InlineData(true, "ACK")]
    public async Task ProcessDies_RetainsKnownAttemptWithoutExecutionReplay(bool epoch, string stage)
    {
        Seed(epoch, 1); var root = Path.Combine(_area, "host");
        var kind = epoch ? EpochPublicationKind.IndependentEpochRestore : EpochPublicationKind.LegacyMigration;
        var info = new ProcessStartInfo("dotnet") { UseShellExecute = false, RedirectStandardInput = true, RedirectStandardOutput = true, RedirectStandardError = true, CreateNoWindow = true };
        foreach (var arg in new[] { typeof(EmbeddedHostOrchestrationProcessTests).Assembly.Location, "ep5-execute", root, Artifact, Destination, kind.ToString(), stage }) info.ArgumentList.Add(arg);
        using var child = Process.Start(info) ?? throw new InvalidOperationException("No orchestration probe."); var errors = child.StandardError.ReadToEndAsync();
        try
        {
            var line = await child.StandardOutput.ReadLineAsync().WaitAsync(TimeSpan.FromSeconds(30)); using var json = JsonDocument.Parse(line!);
            var id = json.RootElement.GetProperty("AttemptId").GetGuid(); var pin = json.RootElement.GetProperty("InventorySha256").GetString()!;
            await child.StandardInput.WriteLineAsync("dispatch"); await child.StandardInput.FlushAsync(); var output = child.StandardOutput.ReadToEndAsync();
            await child.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(45)); Assert.NotEqual(0, child.ExitCode); Assert.Contains("EP5:" + stage, await output); _ = await errors;
            var before = Capture();
            using (var host = EmbeddedHostLifetime.OpenExisting(root, "pilot", "scope", [Artifact, Destination, Path.Combine(_area, "source"), Path.Combine(_area, "legacy"), Path.Combine(_area, "initial")]))
            {
                var count = stage == "IntentAcknowledged" ? 1 : stage is "BeforeReturn" or "ACK" ? 3 : 2;
                Assert.Equal(count, host.History.Frames.Count); Assert.Equal(id, host.History.Frames[0].Snapshot.Context.Intent.AttemptId);
                Assert.False(host.AdmissionsOpen); Assert.False(host.JournalStatus.CanAttemptAppend); Assert.False(host.WasProvisionedHere);
                Assert.Throws<InvalidOperationException>(() => EmbeddedHostOrchestrator.Create(host));
                var observed = ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash)).InspectPublication(new(kind, Artifact, Destination, pin, id));
                var published = stage is "PipelineReturned" or "BeforeReceiptSave" or "BeforeReturn" or "ACK";
                Assert.Equal(published ? EpochInspectionStatus.KnownOperationMatched : EpochInspectionStatus.NotObserved, observed.Status);
                Assert.True(observed.WritersMustRemainStopped);
                Assert.Equal(stage is "BeforeReturn" or "ACK", host.History.Frames[^1].Snapshot.Receipt is not null);
            }
            var after = Capture(); Assert.Equal(before.Keys.Order(), after.Keys.Order()); foreach (var pair in before) Assert.Equal(pair.Value, after[pair.Key]);
        }
        finally { if (!child.HasExited) { child.Kill(true); await child.WaitForExitAsync(); } _ = await errors; }
    }
    private Dictionary<string, byte[]> Capture() => Directory.GetFiles(_area, "*", SearchOption.AllDirectories).ToDictionary(path => path, File.ReadAllBytes);
    private void Seed(bool epoch, int count)
    {
        Directory.CreateDirectory(_area); var source = Path.Combine(_area, "source"); var legacy = epoch ? Path.Combine(_area, "legacy") : Artifact;
        using (var input = new MemoryStream(Encoding.UTF8.GetBytes("<r><DocumentID>old</DocumentID></r>"))) XmlFragmentImporter.Import(input, source);
        using (var owner = EmbeddedXmlDatabase.Open(source))
        { using var read = owner.BeginRead(); for (var index = 1; index <= count; index++) { using var tx = owner.BeginWrite(); tx.ReplaceNodeValue(Target(read), "new-" + index); tx.Commit(); } owner.CreateBackup(legacy); }
        if (!epoch) return;
        var result = EpochLegacyMigration.Convert(legacy, Path.Combine(_area, "initial"));
        using var candidate = ScalarEpochDatabase.Open(result.StorePath, new(DurabilityMode.ProcessCrash, ScalarEpochRecovery.FullHistory)); candidate.CreateBackup(Artifact);
    }
    private static ulong Target(ImmutableXmlSnapshot read) => Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id)).Single(n => n.Kind == StorageNodeKind.Element && n.LocalName == "DocumentID").Children.Single();
    /// <summary>Deletes only the GUID-owned tree after actual child exit and all reader/owner handles close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
