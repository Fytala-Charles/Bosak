// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies independent epoch restore bundle publication and immutable artifact preservation.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 27-10-2026     | Repeat interruptions, retry unpublished paths and reject existing outputs
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Xunit;

namespace Bosak.XmlDb.IntegrationTests;

/// <summary>Verifies fresh-process restore and provenance-bundle publication boundaries.</summary>
public sealed class EpochBackupRestoreProcessTests : IDisposable
{
    private readonly string _area = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-et9c-process-" + Guid.NewGuid().ToString("N"));
    private string Root => Path.Combine(_area, "epoch");
    private string Backup => Path.Combine(_area, "backup");

    /// <summary>Only a verified store/origin bundle is published after restore exit, process kill or acknowledgment loss.</summary>
    /// <param name="stage">Restore publication boundary.</param>
    [Theory]
    [InlineData("normal")]
    [InlineData("Rebound")]
    [InlineData("OriginFlushed")]
    [InlineData("BundleVerified")]
    [InlineData("Published")]
    [InlineData("ACK")]
    public async Task Restore_FreshProcessOrKill_PublishesWholeIndependentBundle(string stage)
    {
        Seed();
        for (var attempt = 0; attempt < 3; attempt++)
        {
            var before = Bytes(Root); var artifact = Bytes(Backup); var destination = Path.Combine(_area, "restored-" + attempt);
            var info = new ProcessStartInfo("dotnet") { RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false };
            foreach (var argument in new[] { typeof(EpochBackupRestoreProcessTests).Assembly.Location, "et9c-restore", Backup, destination, stage }) info.ArgumentList.Add(argument);
            using var process = Process.Start(info) ?? throw new InvalidOperationException("Cannot start restore probe.");
            var stdout = process.StandardOutput.ReadToEndAsync(); var stderr = process.StandardError.ReadToEndAsync();
            try { await process.WaitForExitAsync().WaitAsync(TimeSpan.FromSeconds(50)); }
            catch { if (!process.HasExited) process.Kill(true); throw; }
            var output = await stdout; var error = await stderr;
            if (stage == "normal")
            { Assert.True(process.ExitCode == 0, error); using var json = JsonDocument.Parse(output); Assert.Equal(Path.Combine(destination, "store"), json.RootElement.GetProperty("StorePath").GetString()); }
            else { Assert.NotEqual(0, process.ExitCode); Assert.Contains(stage == "ACK" ? "ET9C-ACK" : "ET9C-FAULT:" + stage, output); }
            AssertBytes(before, Root); AssertBytes(artifact, Backup);
            if (stage is "normal" or "Published" or "ACK")
            {
                var origin = EpochBackupCodec.DecodeOrigin(File.ReadAllBytes(Path.Combine(destination, "origin.bin"))); var store = Path.Combine(destination, "store");
                Assert.NotEqual(origin.Source.Identity, origin.Destination); Assert.Equal(3UL, origin.CommitSequence);
                for (var repeat = 0; repeat < 2; repeat++)
                {
                    using var owner = EpochScalarCoordinator.Open(store); using var read = owner.BeginRead(0);
                    Assert.Equal(origin.Destination, owner.Identity); Assert.Equal(3UL, read.CommitSequence);
                    Assert.Equal("ET9B-three", read.ReadValue(Target(read, "DocumentID"))); Assert.Equal("ET9B-line", read.ReadValue(Target(read, "ItemID", true)));
                }
                var originBytes = File.ReadAllBytes(Path.Combine(destination, "origin.bin"));
                using (var owner = EpochScalarCoordinator.Open(store))
                { using var read = owner.BeginRead(); using var tx = owner.BeginTransaction(); tx.ReplaceNodeValue(Target(read, "DocumentID"), "independent"); Assert.Equal(4UL, tx.Commit()); }
                Assert.Equal(originBytes, File.ReadAllBytes(Path.Combine(destination, "origin.bin")));
            }
            else
            {
                Assert.False(Directory.Exists(destination));
                var retry = EpochBackupRestore.Restore(Backup, destination);
                using var reopened = EpochScalarCoordinator.Open(retry.StorePath);
                using var read = reopened.BeginRead();
                Assert.Equal(3UL, read.CommitSequence); Assert.Equal("ET9B-three", read.ReadValue(Target(read, "DocumentID")));
            }
            var published = Bytes(destination);
            Assert.Throws<IOException>(() => EpochBackupRestore.Restore(Backup, destination)); AssertBytes(published, destination);
            AssertBytes(before, Root); AssertBytes(artifact, Backup);
        }
    }

    private void Seed()
    {
        Directory.CreateDirectory(_area); var source = Path.Combine(_area, "source");
        var xml = "<SalesOrder><SalesOrderHeader><DocumentID>old</DocumentID></SalesOrderHeader>" +
            string.Concat(Enumerable.Range(1, 20).Select(id => $"<SalesOrderLine><Item><ItemID>{id}</ItemID></Item></SalesOrderLine>")) + "</SalesOrder>";
        using var input = new MemoryStream(Encoding.UTF8.GetBytes(xml)); XmlFragmentImporter.Import(input, source, linesPerFragment: 4);
        EpochEmptyRoot.CreateFixture(source, Root, 1, new LocalTransactionStorage()); using var owner = EpochScalarCoordinator.Open(Root); using var read = owner.BeginRead();
        for (var index = 1; index <= 3; index++)
        { using var tx = owner.BeginTransaction(); tx.ReplaceNodeValue(Target(read, index == 2 ? "ItemID" : "DocumentID", index == 2), index == 1 ? "ET9B-one" : index == 2 ? "ET9B-line" : "ET9B-three"); tx.Commit(); }
        owner.CreateBackup(Backup);
    }
    private static ulong Target(ImmutableXmlSnapshot snapshot, string name, bool last = false)
    {
        var nodes = Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id)).Where(node => node.Kind == StorageNodeKind.Element && node.LocalName == name);
        return (last ? nodes.Last() : nodes.Single()).Children.Single();
    }
    private static Dictionary<string, byte[]> Bytes(string root) => Directory.GetFiles(root, "*", SearchOption.AllDirectories).ToDictionary(path => Path.GetRelativePath(root, path), File.ReadAllBytes);
    private static void AssertBytes(Dictionary<string, byte[]> expected, string root)
    { var actual = Bytes(root); Assert.Equal(expected.Keys.Order(), actual.Keys.Order()); foreach (var file in expected) Assert.Equal(file.Value, actual[file.Key]); }
    /// <summary>Removes isolated fixture data after processes and handles close.</summary>
    public void Dispose() { if (Directory.Exists(_area)) Directory.Delete(_area, true); }
}
