"""Independent EP7-B metadata vectors and format checks; Python standard library only.
Copyright Fytala; LICENSE.md. Metadata examples are not authority roots or stores.
Default execution checks pinned files without rewriting them. --create only creates absent files.
"""
from pathlib import Path
import hashlib
import json
import struct
import sys
import unittest
import uuid

ROOT = Path(__file__).resolve().parent
MAGIC = b"BXAM0001"
SPECS = (
    {
        "file": "pilot-authority-meta-ascii-v1.hex",
        "authorityId": "10213243-5465-7687-98a9-bacbdcedfe0f",
        "administrativeJournalId": "20314253-6475-8697-a8b9-cadbecfd0e1f",
        "scope": ["embedded-pilot", "orders", "admin-root", "application-root"],
    },
    {
        "file": "pilot-authority-meta-utf8-v1.hex",
        "authorityId": "30415263-7485-96a7-b8c9-daebfc0d1e2f",
        "administrativeJournalId": "40516273-8495-a6b7-c8d9-eafb0c1d2e3f",
        "scope": ["pilote", "r\u00e9serve", "administration", "application"],
    },
)
MANIFEST = "pilot-authority-fixtures-v1.json"


def digest(data):
    return hashlib.sha256(data).digest()


def scope_digest(scope):
    if len(scope) != 4:
        raise ValueError("Exactly four configured scope keys required")
    encoded = []
    for tag, key in enumerate(scope, 1):
        if not isinstance(key, str) or not key.strip() or key.startswith("\ufeff") or "\0" in key:
            raise ValueError("Invalid canonical key")
        value = key.encode("utf-8", errors="strict")
        if len(value) > 4096:
            raise ValueError("UTF-8 key bound exceeded")
        encoded.append(struct.pack("<HI", tag, len(value)) + value)
    return digest(b"".join(encoded))


def encode_metadata(spec):
    authority = uuid.UUID(spec["authorityId"])
    admin = uuid.UUID(spec["administrativeJournalId"])
    if not authority.int or not admin.int:
        raise ValueError("Empty identity")
    body = MAGIC + authority.bytes + admin.bytes + scope_digest(spec["scope"]) + struct.pack("<HHI", 1, 0, 0)
    if len(body) != 80:
        raise ValueError("Unexpected layout")
    return body + digest(body)


def decode_metadata(data, expected):
    if len(data) != 112 or data[:8] != MAGIC:
        raise ValueError("Length or magic")
    if digest(data[:80]) != data[80:]:
        raise ValueError("Checksum")
    if struct.unpack("<HHI", data[72:80]) != (1, 0, 0):
        raise ValueError("Unsupported policy/flags/reserved")
    authority, admin = uuid.UUID(bytes=data[8:24]), uuid.UUID(bytes=data[24:40])
    if not authority.int or not admin.int:
        raise ValueError("Empty identity")
    if str(authority) != expected["authorityId"] or str(admin) != expected["administrativeJournalId"]:
        raise ValueError("Foreign trusted identity")
    if data[40:72] != scope_digest(expected["scope"]):
        raise ValueError("Foreign configured scope")
    return authority, admin


def reseal(data):
    return bytes(data[:80]) + digest(data[:80])


def create_absent_vectors():
    paths = [ROOT / s["file"] for s in SPECS] + [ROOT / MANIFEST]
    if any(path.exists() for path in paths):
        raise ValueError("Refusing to overwrite existing pinned fixture/manifest")
    records = []
    for spec in SPECS:
        data = encode_metadata(spec)
        with (ROOT / spec["file"]).open("x", encoding="ascii", newline="\n") as stream:
            stream.write(data.hex() + "\n")
        records.append({**spec, "bytes": len(data), "sha256": digest(data).hex()})
    manifest = {
        "date": "2026-10-29",
        "method": "Independent Python struct/uuid/hashlib; no production encoder",
        "reference": "pilot-authority-fixtures-v1.py",
        "scope": "Metadata-only examples; not complete journals, stores or executable authority",
        "records": records,
    }
    with (ROOT / MANIFEST).open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(manifest, stream, indent=2, ensure_ascii=True)
        stream.write("\n")


class MetadataContractTests(unittest.TestCase):
    def setUp(self):
        self.spec = SPECS[0]
        self.data = encode_metadata(self.spec)

    def test_pinned_independent_vectors(self):
        manifest = json.loads((ROOT / MANIFEST).read_text(encoding="utf-8"))
        self.assertEqual(2, len(manifest["records"]))
        for expected, spec in zip(manifest["records"], SPECS):
            with self.subTest(file=spec["file"]):
                actual = bytes.fromhex((ROOT / spec["file"]).read_text(encoding="ascii"))
                self.assertEqual(112, expected["bytes"])
                self.assertEqual(expected["sha256"], digest(actual).hex())
                self.assertEqual(spec, {key: expected[key] for key in spec})
                self.assertEqual(encode_metadata(spec), actual)
                authority, admin = decode_metadata(actual, spec)
                self.assertEqual(uuid.UUID(spec["authorityId"]), authority)
                self.assertEqual(uuid.UUID(spec["administrativeJournalId"]), admin)

    def test_every_short_length_and_extra_byte_rejected(self):
        for length in range(112):
            with self.subTest(length=length), self.assertRaises(ValueError):
                decode_metadata(self.data[:length], self.spec)
        with self.assertRaises(ValueError):
            decode_metadata(self.data + b"\0", self.spec)

    def test_existing_vectors_never_overwritten(self):
        paths = [ROOT / spec["file"] for spec in SPECS] + [ROOT / MANIFEST]
        before = [path.read_bytes() for path in paths]
        with self.assertRaises(ValueError):
            create_absent_vectors()
        self.assertEqual(before, [path.read_bytes() for path in paths])
    def test_checksum_corruption_rejected(self):
        for offset in (8, 40, 72, 80, 111):
            data = bytearray(self.data)
            data[offset] ^= 1
            with self.subTest(offset=offset), self.assertRaises(ValueError):
                decode_metadata(data, self.spec)

    def test_resealed_unknown_magic_rejected(self):
        data = bytearray(self.data)
        data[:8] = b"BXHM0001"
        with self.assertRaises(ValueError):
            decode_metadata(reseal(data), self.spec)

    def test_resealed_unsupported_policy_rejected(self):
        for policy in (0, 2, 65535):
            data = bytearray(self.data)
            struct.pack_into("<H", data, 72, policy)
            with self.subTest(policy=policy), self.assertRaises(ValueError):
                decode_metadata(reseal(data), self.spec)

    def test_resealed_flags_and_reserved_rejected(self):
        for offset in (74, 75, 76, 77, 78, 79):
            data = bytearray(self.data)
            data[offset] = 1
            with self.subTest(offset=offset), self.assertRaises(ValueError):
                decode_metadata(reseal(data), self.spec)

    def test_resealed_empty_identities_rejected(self):
        for offset in (8, 24):
            data = bytearray(self.data)
            data[offset:offset + 16] = bytes(16)
            with self.subTest(offset=offset), self.assertRaises(ValueError):
                decode_metadata(reseal(data), self.spec)

    def test_foreign_trusted_identity_rejected(self):
        for key in ("authorityId", "administrativeJournalId"):
            expected = {**self.spec, key: "ffffffff-ffff-ffff-ffff-ffffffffffff"}
            with self.subTest(key=key), self.assertRaises(ValueError):
                decode_metadata(self.data, expected)

    def test_each_configured_scope_key_bound(self):
        for index in range(4):
            scope = list(self.spec["scope"])
            scope[index] += "-other"
            with self.subTest(index=index), self.assertRaises(ValueError):
                decode_metadata(self.data, {**self.spec, "scope": scope})

    def test_mixed_endian_guid_rejected(self):
        data = bytearray(self.data)
        data[8:24] = uuid.UUID(self.spec["authorityId"]).bytes_le
        with self.assertRaises(ValueError):
            decode_metadata(reseal(data), self.spec)

    def test_utf8_byte_bound_not_character_bound(self):
        self.assertEqual(32, len(scope_digest(["a", "\u00e9" * 2048, "b", "c"])))
        with self.assertRaises(ValueError):
            scope_digest(["a", "\u00e9" * 2049, "b", "c"])

    def test_invalid_canonical_keys_rejected(self):
        for key in ("", " ", "a\0b", "\ufeffa", "\ud800"):
            with self.subTest(key=repr(key)), self.assertRaises(ValueError):
                scope_digest(["a", key, "b", "c"])


if __name__ == "__main__":
    if "--create" in sys.argv:
        if sys.argv[1:] != ["--create"]:
            raise ValueError("Use --create alone; default execution verifies only")
        create_absent_vectors()
        sys.argv = sys.argv[:1]
    unittest.main(verbosity=2)
