# Frozen Format-1 Reader Fixture

Captured 2026-10-27 from this checkout's built post-backup implementation, before
EpochCodec/EpochAdmission existed. SDK 10.0.301, net10.0, no initial Git commit/tag.
The managed Core and Storage binaries are immutable test evidence. Their SHA-256 values
are in manifest.json and pinned by LegacyReaderProbe; tests load them in a separate
AssemblyLoadContext in a subprocess. Do not regenerate them from current source or
silently update hashes to make compatibility tests pass.

This proves behavior of this exact local format-1 baseline, not an unavailable archived
pre-lease or released reader. Broader historical compatibility remains pending. No
third-party runtime DLLs are included. Both binaries retain the proprietary Fytala
[license](../../../LICENSE.md); root dependency notices remain unchanged.

See [epoch validation](../../../docs/implementation/M2_EPOCH_VALIDATION.md) for the four
Open overloads, nonmutation assertions and limits.
