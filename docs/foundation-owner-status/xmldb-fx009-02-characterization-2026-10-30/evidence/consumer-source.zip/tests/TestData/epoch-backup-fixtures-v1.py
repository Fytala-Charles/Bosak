"""Independently authored ET9-A fixtures; stdlib struct/uuid/hashlib only.
Copyright Fytala; LICENSE.md. No production encoder is loaded or invoked.
These are metadata codec vectors, not complete store/backup artifacts.
"""
from pathlib import Path
import struct, uuid, hashlib, json
root=Path(__file__).resolve().parent
G=lambda text:uuid.UUID(text).bytes_le
H=lambda data:hashlib.sha256(data).digest()
def envelope(magic, body, major=1, minor=0):
    prefix=magic.encode('ascii')+struct.pack('<HHi',major,minor,len(body))+body
    return prefix+H(prefix)
source_store='00112233-4455-6677-8899-aabbccddeeff'
source_epoch='10213243-5465-7687-98a9-bacbdcedfe0f'
backup='20314253-6475-8697-a8b9-cadbecfd0e1f'
dest_store='30415263-7485-96a7-b8c9-daebfc0d1e2f'
dest_epoch='40516273-8495-a6b7-c8d9-eafb0c1d2e3f'
restore='50617283-94a5-b6c7-d8e9-fa0b1c2d3e4f'
def format_bytes(store,epoch):
    return envelope('BXDB',struct.pack('<B16s16sQHHHQ',1,G(store),G(epoch),1,3,3,2,3),2,1)
source_format=format_bytes(source_store,source_epoch)
assert source_format==bytes.fromhex((root/'epoch-mutable-format-v2.hex').read_text().strip())
source_hash=H(source_format); dest_hash=H(format_bytes(dest_store,dest_epoch))
base=bytes(range(1,33)); head=bytes(range(33,65)); source_wal=bytes(range(65,97)); dest_wal=bytes(range(97,129))
binding=G(source_store)+G(source_epoch)+struct.pack('<Q',1)+source_hash+base
files=[('BASE',157,bytes(range(129,161))),('FORMAT',99,source_hash)]
body=struct.pack('<H',1)+G(backup)+binding+struct.pack('<Q',2)+head+source_wal+struct.pack('<i',len(files))
assert len(body)==198
for path,length,digest in files:
    encoded=path.encode('ascii');body+=struct.pack('<i',len(encoded))+encoded+struct.pack('<i',length)+digest
inventory=envelope('BXEI',body)
complete=envelope('BXEZ',G(backup)+H(inventory))
origin=envelope('BXEO',G(restore)+G(backup)+H(inventory)+G(source_store)+G(source_epoch)+G(dest_store)+G(dest_epoch)+struct.pack('<QQ',1,2)+source_hash+dest_hash+base+head+source_wal+dest_wal)
assert (len(inventory),len(complete),len(origin))==(332,92,380)
records={'epoch-backup-inventory-v1.hex':inventory,'epoch-backup-completion-v1.hex':complete,'epoch-restore-origin-v1.hex':origin}
for name,value in records.items(): (root/name).write_text(value.hex()+'\n',encoding='ascii')
manifest={'date':'2026-10-27','method':'Independent Python standard-library field assembly; no production encoder calls','generator':'epoch-backup-fixtures-v1.py','scope':'Metadata codec vectors, not complete backup/store artifacts','identities':{'sourceStore':source_store,'sourceEpoch':source_epoch,'backup':backup,'destinationStore':dest_store,'destinationEpoch':dest_epoch,'restore':restore,'document':1,'sequence':2},'digestVectors':{'base':'01..20','head':'21..40','sourceWal':'41..60','destinationWal':'61..80','BASEentry':'81..a0','format':'SHA256 of independently assembled exact ScalarWal2.1 FORMAT'},'records':{name:{'bytes':len(value),'sha256':H(value).hex()} for name,value in records.items()}}
(root/'epoch-backup-fixtures-v1.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
for name,value in records.items():print(name,len(value),H(value).hex())
