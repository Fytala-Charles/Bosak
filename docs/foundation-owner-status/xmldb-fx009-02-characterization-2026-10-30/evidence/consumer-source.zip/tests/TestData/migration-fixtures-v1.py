"""Independent MG1 metadata vectors. Python stdlib only; no production encoders.
Copyright Fytala; LICENSE.md. Header context only, not complete stores/artifacts.
"""
from pathlib import Path
import struct, uuid, hashlib, json
root=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).digest()
G=lambda x:uuid.UUID(x).bytes_le
def env(magic,body,major=1,minor=0):
 b=magic.encode()+struct.pack('<HHi',major,minor,len(body))+body
 return b+H(b)
backup=G('20314253-6475-8697-a8b9-cadbecfd0e1f')
migration=G('50617283-94a5-b6c7-d8e9-fa0b1c2d3e4f')
store=G('30415263-7485-96a7-b8c9-daebfc0d1e2f')
epoch=G('40516273-8495-a6b7-c8d9-eafb0c1d2e3f')
base=bytes(range(1,33));positive_head=bytes(range(33,65));positive_source_wal=bytes(range(65,97));positive_dest_wal=bytes(range(97,129))
legacy=env('BXDB',bytes([0]));control=env('BXTC',struct.pack('<QQ',1,0)+base)
dest=env('BXDB',struct.pack('<B16s16sQHHHQ',1,store,epoch,1,3,3,2,3),2,1)
records={'migration-source-format-v1.hex':legacy,'migration-source-control-v1.hex':control,'migration-destination-format-v1.hex':dest}
for label,n in [('zero',0),('positive',2)]:
 head=positive_head if n else base; sw=positive_source_wal if n else bytes(32); dw=positive_dest_wal if n else bytes(32)
 files=[('.transactions/CONTROL',len(control),H(control)),('FORMAT',len(legacy),H(legacy))]
 if n:
  current=env('BXHD',struct.pack('<QQ',1,n)+head)
  records['migration-source-current-v1.hex']=current
  files +=[('.transactions/CURRENT',len(current),H(current))]
  for seq in range(1,n+1):files.append((f'.transactions/wal/{seq:020}.wal',300,sw if seq==n else bytes([201])*32))
 body=backup+struct.pack('<QQ',1,n)+base+head+struct.pack('<i',len(files))
 for path,size,digest in sorted(files):
  p=path.encode();body+=struct.pack('<i',len(p))+p+struct.pack('<i',size)+digest
 inventory=env('BXBI',body)
 completion=env('BXBC',H(inventory))
 origin=env('BXEM',struct.pack('<H',1)+migration+backup+H(inventory)+H(legacy)+store+epoch+struct.pack('<QQ',1,n)+H(dest)+base+head+sw+dw)
 binding=store+epoch+struct.pack('<Q',1)+H(dest)+base
 current=env('BXEH',binding+bytes([3])+struct.pack('<Q',n)+head+dw)
 # Epoch authority role is u8, as fixed in the existing 1.0 contract.
 assert len(origin)==350 and len(current)==221
 records.update({f'migration-{label}-origin-v1.hex':origin,f'migration-{label}-inventory-v1.hex':inventory,f'migration-{label}-completion-v1.hex':completion,f'migration-{label}-destination-current-v1.hex':current})
for name,data in records.items():(root/name).write_text(data.hex()+'\n',encoding='ascii')
manifest={'date':'2026-10-27','method':'Independent Python struct/uuid/hashlib assembly; no production calls','generator':'migration-fixtures-v1.py','scope':'Metadata/header vectors only, not complete artifacts or stores','records':{name:{'bytes':len(data),'sha256':H(data).hex()} for name,data in records.items()}}
(root/'migration-fixtures-v1.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
for name,data in records.items():
 if 'origin' in name:print(name,len(data),H(data).hex())
