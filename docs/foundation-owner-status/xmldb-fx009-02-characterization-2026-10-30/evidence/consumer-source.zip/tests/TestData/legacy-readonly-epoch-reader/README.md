# Frozen Immutable Epoch Reader Fixture

Captured 2026-10-27 from this checkout's built post-ADR-011 immutable epoch reader,
before profile/authority codecs. SDK 10.0.301, net10.0, no Git commit/release provenance.
Core and Storage are immutable managed binary evidence, with SHA-256 in manifest.json
and LegacyReaderProbe. Do not regenerate or replace them during normal builds/tests.
The fixture is copied into LegacyEpochReader in integration outputs and loaded in an
isolated subprocess AssemblyLoadContext to exercise ReadOnlyEpochDatabase.Open.

These are exact local baseline bytes, not unavailable archived pre-lease readers.
Both retain proprietary Fytala [licensing](../../../LICENSE.md); no third-party DLL is
added. Broader historical compatibility and full C1 remain open. See
[authority validation](../../../docs/implementation/M2_EPOCH_AUTHORITY_VALIDATION.md).
