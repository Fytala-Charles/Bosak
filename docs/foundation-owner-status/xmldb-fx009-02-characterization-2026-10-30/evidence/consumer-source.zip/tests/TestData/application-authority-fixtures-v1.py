"""Independent application-authority v1 frame/history vectors; stdlib only.
Copyright Fytala; LICENSE.md. No production encoder or host I/O is invoked.
Default verifies existing pins. --create refuses any existing target file.
"""
from pathlib import Path
import hashlib
import json
import struct
import sys
import uuid

ROOT = Path(__file__).resolve().parent
H = lambda data: hashlib.sha256(data).digest()
G = lambda value: uuid.UUID(value).bytes
Q = lambda value: struct.pack("<Q", value)
B = lambda value: bytes([value])
T = lambda value: value.encode("utf-8")
OWNER = G("50617283-94a5-b6c7-d8e9-fa0b1c2d3e4f")
OWNER2 = G("60718293-a4b5-c6d7-e8f9-0a1b2c3d4e5f")
BASELINE = G("708192a3-b4c5-d6e7-f809-1a2b3c4d5e6f")
WORK1 = G("8091a2b3-c4d5-e6f7-0819-2a3b4c5d6e7f")
WORK2 = G("90a1b2c3-d4e5-f607-1829-3a4b5c6d7e8f")
ATTEMPT = G("a0b1c2d3-e4f5-0617-2839-4a5b6c7d8e9f")
BACKUP = G("b0c1d2e3-f405-1627-3849-5a6b7c8d9e0f")
SOURCE_STORE = G("c0d1e2f3-0415-2637-4859-6a7b8c9d0e1f")
SOURCE_EPOCH = G("d0e1f203-1425-3647-5869-7a8b9c0d1e2f")
DEST_STORE = G("e0f10213-2435-4657-6879-8a9b0c1d2e3f")
DEST_EPOCH = G("f0011223-3445-5667-7889-9a0b1c2d3e4f")
PROOF = bytes.fromhex("ee" * 32)
INTENT = bytes.fromhex("cc" * 32)


def tlv(*fields):
    assert all(tag < fields[index + 1][0] for index, (tag, _) in enumerate(fields[:-1]))
    return b"".join(struct.pack("<HI", tag, len(value)) + value for tag, value in fields)


def metadata(restore):
    authority, admin, scope = (
        ("30415263-7485-96a7-b8c9-daebfc0d1e2f", "40516273-8495-a6b7-c8d9-eafb0c1d2e3f", ["pilote", "r\u00e9serve", "administration", "application"])
        if restore else
        ("10213243-5465-7687-98a9-bacbdcedfe0f", "20314253-6475-8697-a8b9-cadbecfd0e1f", ["embedded-pilot", "orders", "admin-root", "application-root"])
    )
    prefix = b"BXAM0001" + G(authority) + G(admin) + H(tlv(*[(i + 1, T(key)) for i, key in enumerate(scope)])) + struct.pack("<HHI", 1, 0, 0)
    assert len(prefix) == 80
    return prefix + H(prefix)


def root(epoch, candidate, head):
    values = [(1, B(2 if epoch else 1)), (2, T("candidate-root" if candidate else "source-root")),
              (3, T("candidate-admission" if candidate else "source-admission")), (4, Q(7)), (5, Q(head)),
              (6, bytes.fromhex(("bb" if candidate else "aa") * 32))]
    if epoch:
        values.append((7, tlv((1, DEST_STORE if candidate else SOURCE_STORE), (2, DEST_EPOCH if candidate else SOURCE_EPOCH))))
    return tlv(*values)


def publication(restore):
    return tlv((1, B(2 if restore else 1)), (2, ATTEMPT), (3, bytes.fromhex("dd" * 32)), (4, Q(4)),
               (5, bytes.fromhex("ff" * 32)), (6, T("artifact-root")), (7, T("bundle-root")), (8, BACKUP))


def payload(kind, data, owner=OWNER, generation=1, revision=1, branch=1):
    return tlv((1, B(kind)), (2, owner), (3, Q(generation)), (4, BASELINE), (5, Q(revision)),
               (6, B(branch)), (7, PROOF), (8, data))


def chain(meta, payloads):
    frames = []
    previous = bytes(32)
    for sequence, value in enumerate(payloads, 1):
        header = b"BXAJ0001" + struct.pack("<HHIQ", 1, 0, len(value), sequence) + meta[8:24] + previous + meta[80:]
        assert len(header) == 104
        previous = H(header + value)
        frames.append(header + value + previous + b"AJEND001")
    return b"".join(frames)


def observe(kind, work=None, accepted=None, revision=1, branch=1):
    fields = [(1, B(kind))]
    if work is not None:
        fields += [(2, work), (3, Q(accepted)), (4, INTENT)]
    return tlv(*(fields + [(5, Q(revision)), (6, B(branch))]))


def vectors():
    source, destination = root(False, False, 3), root(True, True, 3)
    enroll = payload(1, tlv((1, source)))
    values = [enroll, payload(2, tlv((1, destination), (2, publication(False)))),
              payload(3, tlv((1, Q(1)), (2, B(1))), revision=2, branch=2),
              payload(4, tlv((1, WORK1), (2, INTENT), (3, H(destination))), revision=2, branch=2),
              payload(5, tlv((1, WORK1), (2, INTENT), (3, Q(4)), (4, B(3))), revision=2, branch=2),
              payload(7, tlv((1, OWNER), (2, Q(1))), OWNER2, 2, 2, 2),
              payload(6, observe(2, WORK1, 4, 2, 2), OWNER2, 2, 2, 2),
              payload(6, observe(1, revision=2, branch=2), OWNER2, 2, 2, 2),
              payload(4, tlv((1, WORK2), (2, INTENT), (3, H(destination))), OWNER2, 2, 2, 2),
              payload(5, tlv((1, WORK2), (2, INTENT), (3, Q(9)), (4, B(2))), OWNER2, 2, 2, 2),
              payload(6, observe(3, WORK2, 9, 2, 2), OWNER2, 2, 2, 2)]
    legacy = chain(metadata(False), values)
    source, destination = root(True, False, 0), root(True, True, 0)
    values = [payload(1, tlv((1, source))), payload(2, tlv((1, destination), (2, publication(True)))),
              payload(4, tlv((1, WORK1), (2, INTENT), (3, H(source)))),
              payload(6, observe(4, WORK1, 3)),
              payload(7, tlv((1, OWNER), (2, Q(1))), OWNER2, 2),
              payload(6, observe(3, WORK1, 3), OWNER2, 2),
              payload(4, tlv((1, WORK2), (2, INTENT), (3, H(source))), OWNER2, 2),
              payload(5, tlv((1, WORK2), (2, INTENT), (3, Q(7)), (4, B(1))), OWNER2, 2),
              payload(6, observe(2, WORK2, 7), OWNER2, 2)]
    restore = chain(metadata(True), values)
    source, destination = root(False, False, 10000), root(True, True, 10000)
    values = [payload(1, tlv((1, source))), payload(2, tlv((1, destination), (2, publication(False)))),
              payload(3, tlv((1, Q(1)), (2, B(1))), revision=2, branch=2),
              payload(3, tlv((1, Q(2)), (2, B(2))), revision=3),
              payload(6, observe(1, revision=3), revision=3),
              payload(7, tlv((1, OWNER), (2, Q(1))), OWNER2, 2, 3),
              payload(6, observe(1, revision=3), OWNER2, 2, 3)]
    return {
        "application-authority-enroll-v1.hex": (chain(metadata(False), [enroll]), 1, "ascii", 0, 0),
        "application-authority-legacy-chain-v1.hex": (legacy, 11, "ascii", 0, 2),
        "application-authority-restore-chain-v1.hex": (restore, 9, "utf8", 2, 0),
        "application-authority-zero-chain-v1.hex": (chain(metadata(False), values), 7, "ascii", 0, 0),
    }


def main():
    records = vectors()
    manifest_path = ROOT / "application-authority-fixtures-v1.json"
    if sys.argv[1:] == ["--create"]:
        if manifest_path.exists() or any((ROOT / name).exists() for name in records):
            raise ValueError("Refusing to overwrite existing fixture/manifest")
        manifest = {"date": "2026-10-29", "method": "Independent Python struct/uuid/hashlib; no production calls",
                    "reference": "application-authority-fixtures-v1.py", "scope": "Canonical host-only frame histories; no provisioned authority or live store proof", "records": []}
        for name, (data, frames, meta, source, candidate) in records.items():
            with (ROOT / name).open("x", encoding="ascii", newline="\n") as output:
                output.write(data.hex() + "\n")
            manifest["records"].append({"file": name, "bytes": len(data), "sha256": H(data).hex(), "frames": frames,
                                         "metadata": meta, "sourceAccepted": source, "candidateAccepted": candidate})
        with manifest_path.open("x", encoding="utf-8", newline="\n") as output:
            json.dump(manifest, output, indent=2)
            output.write("\n")
    elif sys.argv[1:]:
        raise ValueError("Default verifies; --create only for absent fixtures")
    for restore, name in [(False, "pilot-authority-meta-ascii-v1.hex"), (True, "pilot-authority-meta-utf8-v1.hex")]:
        assert metadata(restore) == bytes.fromhex((ROOT / name).read_text(encoding="ascii"))
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    assert len(manifest["records"]) == len(records)
    for record in manifest["records"]:
        data, frames, meta, source, candidate = records[record["file"]]
        assert bytes.fromhex((ROOT / record["file"]).read_text(encoding="ascii")) == data
        assert (len(data), H(data).hex(), frames, meta, source, candidate) == tuple(record[key] for key in
            ["bytes", "sha256", "frames", "metadata", "sourceAccepted", "candidateAccepted"])
        print(record["file"], len(data), H(data).hex())


if __name__ == "__main__":
    main()
