// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Compares persistent XPath semantics and lazy I/O with Bosak.
// SPECIAL NOTES        : Immutable M1 format; no transaction or crash recovery guarantee.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Text;
using System.Xml;
using System.Xml.Linq;
using Bosak.XmlDb.Storage;
using Bosak.XPath.Api;
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Providers.Xml;
using Bosak.XPath.Runtime.Vm;
using Xunit;

namespace Bosak.XmlDb.Xdm.Tests;

/// <summary>Compares persistent XPath semantics and lazy I/O with Bosak.</summary>
public sealed class PersistentQueryTests : IDisposable
{
    private readonly string _root = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-xdm-" + Guid.NewGuid().ToString("N"));

    /// <summary>Provides deterministic corpus sizes and grouping variations.</summary>
    public static IEnumerable<object[]> Cases =>
        from count in new[] { 0, 1, 10, 500, 10_000 }
        from groupSize in new[] { 1, 16, 128, new Random(2701 + count).Next(2, 100) }
        select new object[] { count, groupSize };

    /// <summary>Checks core acceptance queries across corpus sizes and fragment boundaries.</summary>
    [Theory]
    [MemberData(nameof(Cases))]
    public void XPath_VaryingGroups_MatchesInMemoryWithoutUnrelatedReads(int count, int group)
    {
        var xml = SalesOrder(count);
        Import(xml, group);
        using var snapshot = ImmutableXmlSnapshot.Open(_root);
        var persistent = new PersistentXdmNode(snapshot);
        var memory = XDocument.Parse(xml, LoadOptions.PreserveWhitespace).ToXdmNode();
        Assert.Equal("SO-1", Evaluate("string(/SalesOrder/SalesOrderHeader/DocumentID)", persistent));
        Assert.Equal(0, snapshot.Metrics.LineFragmentReads);
        Assert.Equal(1, snapshot.Metrics.HeaderFragmentReads);
        Assert.Equal(count.ToString(System.Globalization.CultureInfo.InvariantCulture), Evaluate("count(/SalesOrder/SalesOrderLine)", persistent));
        Assert.Equal(0, snapshot.Metrics.LineFragmentReads);
        var query = "/SalesOrder/SalesOrderLine[10]/Item/ItemID";
        Assert.Equal(Evaluate("string(" + query + ")", memory), Evaluate("string(" + query + ")", persistent));
        Assert.Equal(count >= 10 ? 1 : 0, snapshot.Metrics.LineFragmentReads);
        foreach (var expression in new[]
        {
            "count(/SalesOrder/SalesOrderLine[last()]/ancestor::SalesOrder)",
            "string(/SalesOrder/SalesOrderLine[1]/following-sibling::SalesOrderLine[1]/Item/ItemID)",
            "string(/SalesOrder/SalesOrderLine[last()]/preceding-sibling::SalesOrderLine[1]/Item/ItemID)",
            "count(/SalesOrder/SalesOrderLine/ancestor-or-self::*)",
            "string(/SalesOrder/SalesOrderLine[last()]/@number)",
            "/SalesOrder is /SalesOrder/SalesOrderHeader/parent::*",
            "count(/SalesOrder/SalesOrderLine[1]/following::ItemID)",
            "count(/SalesOrder/SalesOrderLine[last()]/preceding::ItemID)",
        }) Assert.Equal(Evaluate(expression, memory), Evaluate(expression, persistent));
    }

    /// <summary>Checks namespaces, mixed content, base URIs and serialization.</summary>
    [Fact]
    public void XPath_NamespacesAndMixedContent_MatchesProvider()
    {
        const string xml = "<?test value?><!--before--><o:SalesOrder xmlns:o='urn:o' xmlns:q='urn:q' xml:base='https://example.test/base/' q:id='a'> lead <o:SalesOrderHeader><o:DocumentID>SO-1</o:DocumentID></o:SalesOrderHeader><o:SalesOrderLine number='1'><o:Item xml:base='nested/'>a<![CDATA[b]]><!--c--><?pi d?><q:ItemID>42</q:ItemID> z </o:Item></o:SalesOrderLine><plain xmlns=''>tail</plain></o:SalesOrder>";
        Import(xml, 1);
        using var snapshot = ImmutableXmlSnapshot.Open(_root);
        var persistent = new PersistentXdmNode(snapshot);
        using var reader = XmlReader.Create(new StringReader(xml), new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit }, "https://example.test/order.xml");
        var memory = XDocument.Load(reader, LoadOptions.PreserveWhitespace | LoadOptions.SetBaseUri).ToXdmNode();
        foreach (var query in new[]
        {
            "string(/*)", "count(//node())", "count(//@*)", "count(/*/namespace::*)",
            "string(/*/@q:id)", "string(/*/o:SalesOrderLine/o:Item/q:ItemID)",
            "count(/*/o:SalesOrderLine/o:Item/preceding::node())",
            "count(/*/o:SalesOrderLine/@number/following::node())",
            "count(/*/o:SalesOrderLine/o:Item/ancestor::*)", "document-uri(/)",
        }) Assert.True(Evaluate(query, memory) == Evaluate(query, persistent), query + ": expected " + Evaluate(query, memory) + "; actual " + Evaluate(query, persistent));
        var serialized = XDocument.Parse(persistent.ToXmlString(), LoadOptions.PreserveWhitespace);
        // Compare the serialized infoset through the same provider (CDATA and text are equivalent).
        var serializedNode = serialized.ToXdmNode();
        Assert.Equal(Evaluate("string(/*)", memory), Evaluate("string(/*)", serializedNode));
        foreach (var query in new[] { "count(//*)", "count(//comment())", "count(//processing-instruction())" })
            Assert.Equal(Evaluate(query, memory), Evaluate(query, serializedNode));
        Assert.Equal(Evaluate("count(//@*)", memory), Evaluate("count(//@*)", serializedNode));
        Assert.Equal("https://example.test/base/nested/", Nodes(persistent.Axis(XdmAxis.Descendant))
            .Single(node => node.LocalName == "Item").BaseUri);
        var item = Nodes(persistent.Axis(XdmAxis.Descendant)).Single(node => node.LocalName == "Item");
        var roundTripItem = XElement.Parse(item.ToXmlString());
        Assert.Equal("urn:o", roundTripItem.Name.NamespaceName);
        Assert.Equal("42", roundTripItem.Descendants(XName.Get("ItemID", "urn:q")).Single().Value);
    }

    /// <summary>Verifies same-snapshot identity and late enumeration guards.</summary>
    [Fact]
    public void LazySequence_DisposedBetweenFetches_Throws()
    {
        Import(SalesOrder(10), 2);
        var snapshot = ImmutableXmlSnapshot.Open(_root);
        var document = new PersistentXdmNode(snapshot);
        Assert.True(document.IsSameNode(new PersistentXdmNode(snapshot)));
        using var other = ImmutableXmlSnapshot.Open(_root);
        Assert.False(document.IsSameNode(new PersistentXdmNode(other)));
        var sequence = document.Axis(XdmAxis.Descendant);
        var enumerator = sequence.GetEnumerator();
        Assert.True(enumerator.MoveNext());
        var late = document.Children();
        var queryResult = document.BindResult(XPath31Expression.Compile("/SalesOrder/SalesOrderLine").EvaluateNodes(document));
        snapshot.Dispose();
        Assert.Throws<ObjectDisposedException>(() => enumerator.MoveNext());
        Assert.Throws<ObjectDisposedException>(() => late.GetEnumerator().MoveNext());
        Assert.Throws<ObjectDisposedException>(() => document.StringValue);
        Assert.Throws<ObjectDisposedException>(() => queryResult.GetEnumerator().MoveNext());
    }

    /// <summary>Composes the exact stored URI with the real evaluation context.</summary>
    [Fact]
    public void DocumentLoader_SnapshotScoped_PreservesIdentityAndPayloadIsolation()
    {
        Import(SalesOrder(20), 4);
        using var snapshot = ImmutableXmlSnapshot.Open(_root);
        var document = new PersistentXdmNode(snapshot);
        var context = new EvaluationContext().WithFocus(XdmValue.FromNode(document), 1, 1);
        context.DocumentLoader = document.ResolveDocument;
        Assert.Equal("SO-1", XPath31Expression.Compile("string(doc('https://example.test/order.xml')/SalesOrder/SalesOrderHeader/DocumentID)").Evaluate(context).StringValue);
        Assert.Equal("true", XPath31Expression.Compile("doc('https://example.test/order.xml') is .").Evaluate(context).ToString());
        Assert.Equal(0, snapshot.Metrics.LineFragmentReads);
        Assert.Throws<FileNotFoundException>(() => document.ResolveDocument("https://example.test/missing.xml"));
    }

    /// <summary>Checks all axes directly, including scalar-node contexts and inherited namespaces.</summary>
    [Fact]
    public void Axes_AllNodeContexts_MatchInMemoryProvider()
    {
        const string xml = "<!--a--><r xmlns='urn:r' xmlns:p='urn:p' xml:base='https://example.test/base/' xml:id='root'><p:a k='1'>before<b xmlns='' p:q='2'>inside</b>after</p:a><?pi data?><p:a k='3'/></r><!--z-->";
        Import(xml, 1);
        using var snapshot = ImmutableXmlSnapshot.Open(_root);
        var persistent = new PersistentXdmNode(snapshot);
        using var reader = XmlReader.Create(new StringReader(xml), new XmlReaderSettings(), "https://example.test/order.xml");
        var memory = XDocument.Load(reader, LoadOptions.PreserveWhitespace | LoadOptions.SetBaseUri).ToXdmNode();
        var expected = new[] { memory }.Concat(Nodes(memory.Axis(XdmAxis.Descendant))).ToArray();
        var actual = new IXdmNode[] { persistent }.Concat(Nodes(persistent.Axis(XdmAxis.Descendant))).ToArray();
        Assert.Equal(expected.Length, actual.Length);
        for (var i = 0; i < expected.Length; i++)
        {
            Compare(expected[i], actual[i]);
            // Bosak 1.26.2 Attributes() includes xmlns declarations; the XPath attribute axis correctly excludes them.
            var expectedAttributes = Nodes(expected[i].Axis(XdmAxis.Attribute));
            var actualAttributes = Nodes(actual[i].Attributes());
            Assert.Equal(expectedAttributes.Count, actualAttributes.Count);
            for (var a = 0; a < expectedAttributes.Count; a++) Compare(expectedAttributes[a], actualAttributes[a]);
            var expectedNamespaces = Nodes(expected[i].Axis(XdmAxis.Namespace)).OrderBy(node => node.LocalName).ToArray();
            var actualNamespaces = Nodes(actual[i].Axis(XdmAxis.Namespace)).OrderBy(node => node.LocalName).ToArray();
            Assert.Equal(expectedNamespaces.Length, actualNamespaces.Length);
            for (var n = 0; n < expectedNamespaces.Length; n++) Compare(expectedNamespaces[n], actualNamespaces[n]);
        }

        static string Key(IXdmNode node) => $"{node.NodeKind}|{node.LocalName}|{node.NamespaceUri}|{node.Prefix}|{node.StringValue}";
        static void Compare(IXdmNode left, IXdmNode right)
        {
            Assert.Equal(Key(left), Key(right));
            Assert.Equal(left.TypedValue.ToString(), right.TypedValue.ToString());
            Assert.Equal(left.IsId, right.IsId);
            Assert.Equal(left.SchemaTypeAnnotation, right.SchemaTypeAnnotation);
            if (left.NodeKind is XdmNodeKind.Attribute or XdmNodeKind.Namespace)
                Assert.Equal(left.ToXmlString(), right.ToXmlString());
            foreach (var axis in Enum.GetValues<XdmAxis>())
            {
                var expectedAxis = Nodes(left.Axis(axis)).Select(Key);
                var actualAxis = Nodes(right.Axis(axis)).Select(Key);
                // Namespace-axis order is implementation defined; compare bindings as a set.
                if (axis == XdmAxis.Namespace)
                    Assert.Equal(expectedAxis.Order(), actualAxis.Order());
                else Assert.Equal(expectedAxis, actualAxis);
            }
        }
    }
    private void Import(string xml, int group)
    {
        using var stream = new MemoryStream(Encoding.UTF8.GetBytes(xml));
        XmlFragmentImporter.Import(stream, _root, linesPerFragment: group, documentUri: "https://example.test/order.xml");
    }

    private static string SalesOrder(int count) => "<SalesOrder><SalesOrderHeader><DocumentID>SO-1</DocumentID></SalesOrderHeader>" +
        string.Concat(Enumerable.Range(1, count).Select(i => $"<SalesOrderLine number='{i}'><Item><ItemID>{i}</ItemID></Item></SalesOrderLine>")) + "</SalesOrder>";

    private static string Evaluate(string query, IXdmNode node)
    {
        var context = new EvaluationContext().WithFocus(XdmValue.FromNode(node), 1, 1)
            .WithNamespace("o", "urn:o").WithNamespace("q", "urn:q");
        return XPath31Expression.Compile(query).Evaluate(context).ToString();
    }

    private static List<IXdmNode> Nodes(XdmSequence sequence)
    {
        var nodes = new List<IXdmNode>();
        foreach (var value in sequence) nodes.Add(value.NodeValue);
        return nodes;
    }

    /// <inheritdoc />
    public void Dispose()
    {
        if (Directory.Exists(_root)) Directory.Delete(_root, true);
    }
}






