// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Verifies the M0 project dependency boundary.
// SPECIAL NOTES        : Architecture checks only; no storage or XPath behavior is implemented.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      | Author          | Version | Date       | Notes
//                      | Charles Korthout | 0.1     | 26-10-2026 | Creation
//                      | Charles Korthout | 0.2     | 26-10-2026 | Enforce exact M1 Bosak dependency
// ===========================================================================================================================================================

using System.Xml.Linq;
using Xunit;

namespace Bosak.XmlDb.Xdm.Tests;

/// <summary>Verifies the M0 project dependency boundary.</summary>
public sealed class DependencyBoundaryTests
{
    /// <summary>Checks the permitted foundation references.</summary>
    [Fact]
    public void ProjectReferences_FoundationGraph_MatchesApprovedBoundary()
    {
        var project = XDocument.Load(Path.Combine(AppContext.BaseDirectory, "ProjectUnderTest.xml"));
        var references = project.Descendants("ProjectReference")
            .Select(reference => Path.GetFileNameWithoutExtension((string?)reference.Attribute("Include")))
            .Order().ToArray();

        Assert.Equal(new[] { "Bosak.XmlDb.Core", "Bosak.XmlDb.Storage" }, references);
    }

    /// <summary>Guards embedded use against infrastructure dependencies.</summary>
    [Fact]
    public void PackageReferences_EmbeddedAdapter_HasOnlyPinnedBosakCore()
    {
        var project = XDocument.Load(Path.Combine(AppContext.BaseDirectory, "ProjectUnderTest.xml"));

        var package = Assert.Single(project.Descendants("PackageReference"));
        Assert.Equal("Bosak.XPath.Core", (string?)package.Attribute("Include"));
        Assert.Equal("[1.26.2]", (string?)package.Attribute("Version"));
    }
}

