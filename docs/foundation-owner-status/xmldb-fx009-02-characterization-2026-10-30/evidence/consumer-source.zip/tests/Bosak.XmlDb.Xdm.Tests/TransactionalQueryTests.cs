// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Verifies XPath semantics across committed document generations.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Text;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Bosak.XPath.Api;

using Xunit;

namespace Bosak.XmlDb.Xdm.Tests;

/// <summary>Verifies XPath semantics across committed document generations.</summary>
public sealed class TransactionalQueryTests : IDisposable
{
    private readonly string _root = Path.Combine(Path.GetTempPath(), "Bosak.XmlDb-m2-xdm-" + Guid.NewGuid().ToString("N"));

    /// <summary>Checks old and new XPath values, stable node order and serialized updates without unrelated payload reads.</summary>
    [Fact]
    public void XPath_CommittedScalar_PreservesSnapshotsAndLazyNavigation()
    {
        const string xml = "<SalesOrder><SalesOrderHeader><DocumentID>SO-1</DocumentID></SalesOrderHeader><SalesOrderLine number='1'><Item>line</Item></SalesOrderLine></SalesOrder>";
        using (var input = new MemoryStream(Encoding.UTF8.GetBytes(xml))) XmlFragmentImporter.Import(input, _root);
        using var database = EmbeddedXmlDatabase.Open(_root);
        using var before = database.BeginRead();
        var target = Enumerable.Range(1, before.NodeCount).Select(id => before.GetNode((ulong)id))
            .Single(node => node.Kind == StorageNodeKind.Element && node.LocalName == "DocumentID").Children.Single();
        var oldDocument = new PersistentXdmNode(before);
        var lazy = oldDocument.BindResult(XPath31Expression.Compile("/SalesOrder/SalesOrderHeader/DocumentID").EvaluateNodes(oldDocument));
        using (var transaction = database.BeginWrite())
        {
            transaction.ReplaceNodeValue(target, "SO-2 & \u03bb");
            Assert.Equal(1UL, transaction.Commit());
        }
        using var after = database.BeginRead();
        var newDocument = new PersistentXdmNode(after);
        var query = XPath31Expression.Compile("string(/SalesOrder/SalesOrderHeader/DocumentID)");
        Assert.Equal("SO-1", query.Evaluate(oldDocument).StringValue);
        Assert.Equal("SO-2 & \u03bb", query.Evaluate(newDocument).StringValue);
        Assert.Equal(0, before.Metrics.LineFragmentReads);
        Assert.Equal(0, after.Metrics.LineFragmentReads);
        var oldNode = new PersistentXdmNode(before, target);
        var newNode = new PersistentXdmNode(after, target);
        Assert.Equal(oldNode.DocumentOrder, newNode.DocumentOrder);
        Assert.False(oldNode.IsSameNode(newNode));
        foreach (var item in lazy) Assert.Equal("SO-1", item.NodeValue.StringValue);
        var roundTrip = System.Xml.Linq.XDocument.Parse(newDocument.ToXmlString());
        Assert.Equal("SO-2 & \u03bb", roundTrip.Root!.Element("SalesOrderHeader")!.Element("DocumentID")!.Value);
        Assert.Equal("line", roundTrip.Root!.Element("SalesOrderLine")!.Element("Item")!.Value);
    }

    /// <inheritdoc />
    public void Dispose()
    {
        if (Directory.Exists(_root)) Directory.Delete(_root, true);
    }
}

