# Bosak.XmlDb M2 Progress

- Date: 2026-10-30; workspace D:/Development/Bosal.XmlDb; product Bosak.XmlDb.
- Implemented: scalar WAL transactions, filesystem policies, non-deleting checkpoints,
  independent recovery descriptors, snapshot-owned reader leases, conservative retention
  inventory, fixed-sequence backup/restore, read-only epoch data, internal epoch ownership, scalar epoch commit and deterministic redo/publication recovery.
- M2 remains in progress. Public epoch APIs, actual application cutover/release qualification, committed-history deletion and
  WAL-prefix truncation are not implemented. CanReclaim remains false.
- Proprietary Fytala license, Bosak 1.26.2 pins and disabled packaging are unchanged.
- Checkpoint 7da1b17 (through SR2-C) is committed/pushed; SR1/SR2 readiness review is local. Runtime/test code unchanged; no fresh execution, release/deployment or upstream edits.

## SR3-A Stopped Handoff Preparation Design (2026-10-30)

[ADR-036](docs/ADR-036-stopped-handoff-preparation-and-lifetime.md) and
[contract](docs/implementation/M2_STOPPED_HANDOFF_PREPARATION_CONTRACT.md) define private success-only
proof, actual preparation/plan/executor child drain and the actual paired parent session as
successor. Closing before claim refuses; claim-before-close retains original usable handles
through completion. No runtime or format change. Readiness checkpoint `069332c` is committed
and pushed; this design is local/uncommitted. Next SR3-B1 implements private proof and child
lifetime before SR3-B2 preparation/claim, SR3-C qualification and the separate SR4 writer.
Prior Windows 2,752 and focused Linux 394 cases remain retained evidence, not fresh execution.
Host/public/archive/durable-fence and all retirement gates remain open; CanReclaim=false.

## SR1/SR2 Stopped Restart Readiness Review (2026-10-30)

[Review](docs/implementation/M2_STOPPED_RESTART_READINESS_REVIEW.md) verifies 64 retained
artifacts, 15 historical source inputs and complete Windows test-ID growth from 2,529 to 2,752.
All 223 additions appear in the latest 394-case focused Linux catalog; platform bodies/guards
remain distinct. Initial restore timeouts stay separate from passing project rechecks.
No runtime changes or fresh execution. Next SR3-A defines success-only proof consumption,
actual plan-child drain and successor/session binding before preparation code. Existing
observation/descriptor success grants no handoff or write authority. Host/public/archive and
all retirement gates remain open. Checkpoint `7da1b17` is committed/pushed; this review is local.

## SR2-C Native, Process and Disposal Qualification (2026-10-30)

[Validation](docs/implementation/M2_OWNED_RESTART_QUALIFICATION_VALIDATION.md) adds 38 cases
without product source changes. Eleven native roles/roots are replaced with identical bytes
at two boundaries: 22 actual Linux executions, separately recorded as 22 Windows guards.
Ordered and repeated concurrent disposal, 14 process kills and 14 fresh observations and independent
holders/races preserve bytes/inventory and keep every result stopped. Final focused runs pass
189 Windows and 394 Linux cases.
All 2,752 Windows cases pass across complete project runs. The initial restore timeouts are
retained and pass focused plus complete Integration rechecks. Next consolidate SR1/SR2
readiness before SR3 handoff preparation. Host/public/archive/retirement gates remain open.
Checkpoint `de5c9a4` is committed/pushed; SR2-C qualification is local/uncommitted.

## SR2-B Paired Stopped Restart Observation (2026-10-30)

[Implementation and validation](docs/implementation/M2_OWNED_RESTART_OBSERVATION_VALIDATION.md)
bind actual parent/authority/source retention through read-only complete source/sealed-capture
proof and fresh exact journal/native identity checks. All results stay stopped and inert;
no capture association, receipt, initializer or handoff capability is recreated. Nonterminal
administrative history forces reconciliation despite caller assertions. All 58 new cases and
282 focused Windows cases pass; 356 focused Linux cases pass, including all 58 new bodies.
All 2,714 Windows cases pass across complete project runs. The initial restore timeout is
retained and passes focused plus complete Integration rechecks. Next SR2-C native/process/race
qualification; SR3/SR4 and host/public/archive/retirement gates remain open. Checkpoint `a31203b`
is committed/pushed; SR2-B is local/uncommitted. Public and frozen formats remain unchanged.

## SR2-A Actual Restart Source Retention (2026-10-30)

[Implementation and validation](docs/implementation/M2_RESTART_SOURCE_RETENTION_VALIDATION.md)
add a separate restart-only actual source child, permanent stopped admission and original
usable writer retention through real drain. No old capture association or initializer is
recreated. Native source inspection runs outside its gate; close uncertainty never retries or
clears the stop. All 38 new cases and 152 focused Windows cases pass; 268 focused Linux cases
also pass, including all 38 new bodies. All 2,656 Windows cases pass across complete project runs. The initial restore timeout is
retained and passes focused plus complete Integration rechecks.
This source-only slice does not implement paired restart observation. Next SR2-B full actual
parent/authority/source-bound proof and freshness; SR2-C/SR3/SR4 and host/public/archive/retirement
gates remain open. Checkpoint `bc5e490` is committed/pushed; SR2-A is local/uncommitted.

## SR2 Actual Ownership Integration Design (2026-10-30)

[ADR-035](docs/ADR-035-owned-stopped-restart-observation.md),
[design](docs/implementation/M2_OWNED_RESTART_OBSERVATION_DESIGN.md) and
[review](docs/implementation/M2_OWNED_RESTART_OBSERVATION_REVIEW.md) specify a separate
restart-only retained source child and paired stopped observation. Existing freeze/capture
association and initializer checks remain strict. Verification must not hide live recovery
writes or confuse the inventory commitment with the manifest hash. Design only; no runtime
change. Next SR2-A source lifetime primitive, then SR2-B/C observation and qualification;
SR3/SR4 and all host/public/archive/retirement gates remain open.
Checkpoint `b0c94bd` is committed/pushed. SR2 design is local/uncommitted; prior 2,618 Windows
passing cases across complete project runs and 451 focused Linux cases are retained evidence,
not new execution. All source/candidate/WAL histories remain retained, CanReclaim=false.

## SR1 Pure Stopped Enrollment Assessment (2026-10-30)

[Implementation and validation](docs/implementation/M2_ENROLLMENT_RESTART_CLASSIFIER_VALIDATION.md)
add an internal pure classifier of supplied exact-head, source/capture and stopped-host facts.
Every result remains stopped and inert. Empty/unsupported/missing observations require
reconciliation; invalid history or contradictory facts refuse. No receipt, initializer, live
ownership, handoff plan or execution permission is recreated. All 89 new cases and 335 focused
Windows cases pass; 451 focused Linux cases also pass, including all 89 new bodies.
All 2,618 Windows cases pass across complete project runs. The initial restore timeout is
retained and passes focused plus complete Integration rechecks. Public/frozen formats and
actual source/authority lifetimes remain unchanged. Next SR2 actual owner-bound stopped
evidence; SR3/SR4 capability/output and host/public/archive/retirement gates remain open.
Checkpoint `100b39d` is committed/pushed; SR1 is local/uncommitted.

## ER-004 Stopped Restart and Owner Handoff Design (2026-10-30)

[ADR-034](docs/ADR-034-stopped-enrollment-restart-and-owner-handoff.md) and the
[contract](docs/implementation/M2_STOPPED_ENROLLMENT_RESTART_CONTRACT.md) define inert stopped
assessment, fresh actual ownership/exclusion and a separately gated future TransferOwner.
[Review](docs/implementation/M2_STOPPED_ENROLLMENT_RESTART_REVIEW.md) records design checks;
no runtime, public API or frozen format changes. Valid Enroll bytes never recreate a receipt
or initializer. Empty/unsupported/uncertain restarts require reconciliation; corruption rejects
without repair. All histories remain retained. Next SR1 implements only the pure stopped
classifier; SR2-SR4 actual evidence, capability and output qualification remain unimplemented.
ER-003 checkpoint `edf0b72` is committed/pushed. Its 2,529 Windows passing cases across complete
project runs and 740 focused Linux cases remain prior execution evidence, with initial
Integration timeouts preserved separately. This design adds no runtime test cases.

## ER-003 Authority and Parent Release Qualification (2026-10-30)

[Contract](docs/implementation/M2_ENROLLMENT_ROLE_RELEASE.md) and
[validation](docs/implementation/M2_ENROLLMENT_ROLE_RELEASE_VALIDATION.md) add an actual-owner,
internal close seam and 42 direct role-close cases. Before/after/no-op errors suppress required
cleanup acknowledgment, preserve bytes and keep release uncertainty separate from physical
handle availability. All 2,529 Windows cases qualify across complete project runs and 740 broad
Linux cases pass, including all 42 new bodies per platform. Two initial restore timeouts are
retained and pass focused plus complete Integration rechecks. Production null/default close delegation and public/frozen contracts remain
unchanged. Next ER-004 defines stopped restart/enrollment reconciliation and owner handoff;
no further writer, work/routing admission, source replacement or reclamation is enabled.
Historical sections below retain their dated scope.

## ER-002 Retained Preflight Boundary (2026-10-30)

[Implementation](docs/implementation/M2_RETAINED_ENROLLMENT_PREFLIGHT.md) and
[validation](docs/implementation/M2_RETAINED_ENROLLMENT_PREFLIGHT_VALIDATION.md) move retained
protected-path inspection outside authority serialization. Actual source/parent/authority
ownership spans the unlocked phases; exact roles/metadata/empty head are checked again after
the last placement pass. All 2,487 Windows cases pass across complete project runs; 698 broad
Linux cases pass, including all 19 new bodies per platform. Two initial restore timeouts are
retained and pass focused plus complete Integration rechecks. Generic readers and frozen/public
contracts remain unchanged. Next ER-003 qualifies direct authority/parent close errors;
ER-004 and all host/public/archive/retirement gates remain open. Historical sections below
retain their dated scope.

## EF1-EF4 Consolidated Readiness Review (2026-10-30)

[Review](docs/implementation/M2_ENROLLMENT_READINESS_REVIEW.md) verifies 51 retained TRX
artifacts, 256 unchanged source/build/fixture inputs and all 2,468 Windows test IDs; 679 Linux
focused IDs are retained separately. Fresh public metadata remains 95/95, with no additions.
No runtime suite or feature is added by the review. ER-002 identifies protected-ancestor I/O
under the shared authority monitor during retained preflight; next harden that boundary under
ADR-033. Direct authority/parent close-fault qualification and stopped restart/owner handoff
remain later gaps. No public API, application admission, routing or reclamation is enabled.
Historical sections below retain their dated scope.

## EF4 Enrollment Fault and Process Qualification (2026-10-30)

[Qualification](docs/implementation/M2_FIRST_ENROLLMENT_FAULT_VALIDATION.md) adds observed
call-edge/all-prefix fault sweeps, actual Linux inode substitutions, cross-thread I/O closing,
repeated process/ACK-loss boundaries and independent competing publishers. The 387-byte frame
produces 393 sweep attempts; 34 new catalog cases include eight Windows host guards. Each
focused process run uses 48 workers. Production runtime/format/public surface is unchanged.
All 2,468 Windows and 679 isolated Linux focused cases pass; eight new Windows rows are
explicit host guards. Formatting/docs/portability and frozen fixture checks pass. Next consolidate
EF1-EF4 readiness and remaining host/restart contracts before another authority writer.
No application admission, actual routing or reclamation is enabled. Historical sections below
retain their dated scope.

## EF3 Conditional First Enrollment (2026-10-30)

[Implemented contract](docs/implementation/M2_FIRST_ENROLLMENT_APPEND.md) and
[validation](docs/implementation/M2_FIRST_ENROLLMENT_APPEND_VALIDATION.md) add one terminal
stopped Enroll append from the actual retained preparation. Exact empty-head/native-role checks,
flush/readback/full-history validation and cleanup confirmation precede acknowledgment.
Possible output or release uncertainty retains bytes and prevents receipt synthesis/retry.
All 2,434 Windows and 645 isolated Linux focused cases pass, including all 45 new cases per
platform. Formatting/docs/portability and frozen fixture checks pass. No application work admission or public API is enabled. Next EF4 qualifies observed
persistence positions, process interruption/ACK loss and competing owners. Real host/archive/
retirement gates remain open. Historical sections below retain their dated scope.

## EF2 Retained Enrollment Admission (2026-10-29)

[Implemented contract](docs/implementation/M2_RETAINED_ENROLLMENT_ADMISSION.md) adds a
separate owner-bound retained preparation, resource transfer to actual execution and a
nonblocking authority/parent/source arm decision. Wrapper disposal retains all three original
owners through actual execution; unknown source close retains authority/parent operations.
All 2,389 Windows and 600 isolated Linux focused cases pass, including 29 new cases per
platform. Formatting/docs/portability and frozen fixture checks pass. No authority output or application admission is enabled. Next EF3 implements the
conditional first Enroll frame; EF4 persistence qualification and real host/public/archive/
retirement gates remain open. Historical sections below retain their dated scope.

## EF1 Source Lifetime Checkpoint (2026-10-29)

Preparation/design checkpoint `5237ee3` is committed and pushed. Subsequent local
[EF1](docs/implementation/M2_ENROLLMENT_SOURCE_RETENTION_VALIDATION.md) implements actual
source/freeze retention, deferred original-stream close, explicit release uncertainty and
an original-owner stop latch. All 2,360 Windows tests / 571 focused Linux cases pass;
29 cases are new per platform. Static documentation/formatting/fixture checks pass. No authority append or actual application admission is enabled. Next EF2 retained
preparation/atomic admission without output. All histories and remaining release gates stay.

## Retained Source and First-Enrollment Design (2026-10-29)

[ADR-033](docs/ADR-033-retained-source-exclusion-and-first-enrollment.md) specifies
opt-in source/freeze retention, atomic arming, a source stop latch and one-frame terminal
stopped append/uncertainty. Design only: current runtime/build inputs remain unchanged at
2,331 passing Windows / 542 focused Linux baseline cases. Next EF1 qualifies source child
retention/deferred close/stop latch without authority output; EF2-EF4 remain unimplemented.
The source latch is not durable fencing or verified operational truth. All histories remain.

## First-Enrollment Preparation Checkpoint (2026-10-29)

Provisioning is committed/pushed as `3f722da`. Subsequent local
[read-only preparation](docs/implementation/M2_APPLICATION_AUTHORITY_ENROLLMENT_VALIDATION.md)
binds real frozen legacy history/capture and actual writer ownership to supplied scoped
reconciliation assertions. All 2,331 Windows cases pass across full project runs; 542
isolated Linux cases pass, including all 35 new cases per platform. One existing Windows
post-kill case failed once and passed focused/complete reruns; retain the observation.
All writers remain stopped. Next conditional first-enrollment append/uncertainty design;
no operational-truth inference, public API, actual routing or reclamation is enabled.

## Application-Authority Provisioning Checkpoint (2026-10-29)

Prior classifier/codec/paired ownership work is committed and pushed as `21a33af`.
The subsequent local [provisioning slice](docs/implementation/M2_APPLICATION_AUTHORITY_PROVISIONING_VALIDATION.md)
creates only absent separate roots and retains partial outcomes. Its live initializer
reservation is read-only and holds actual paired leases; empty reopen cannot recreate it.
All 2,296 Windows cases pass across full project runs; 475 focused Linux cases pass.
46 cases are new per platform. One existing Windows release case failed once; focused
and complete reruns pass, with the observation retained in the validation report.
Actual provisioning process interruption/contention/acknowledgment loss is qualified.
Next bind real baseline evidence to owner-bound first-enrollment preparation before append. All application writers stay stopped; no routing or reclamation.
Historical checkpoints below retain their dated scope.

## Host Restart Checkpoint (2026-10-29)

EP6-C is pushed as `5977451`; this checkpoint includes the completed EP6-D process tests and
documentation. All 1,055 focused cases passed per Windows/Linux platform (732 Storage,
323 Integration), including 72 new process cases. Formatting and strict documentation/portability
checks passed. No production source, public API, package pin or wire format changed in EP6-D.
Hosted run `40822530134` was blocked before runner execution by account payment/spending limits.

The [XDM 4.0 assessment](docs/implementation/M2_XDM40_COMPATIBILITY_ASSESSMENT.md)
records existing Bosak foundations and proposed provider qualification (REQ-009). It does not
claim full current-draft conformance or introduce persistent JSON/general XDM storage.

After restart, inspect `git status --short` and `git log -1`, then read this handover and
[EP6-D evidence](docs/implementation/M2_EMBEDDED_HOST_RESTART_PROCESS_VALIDATION.md).
Next: audit consuming-host selected-root authority and accepted-work accounting before adding
application integration. Reopened stores/host journals stay stopped; no automatic retry, route
change, writer resumption or reclamation is authorized by these tests. Proprietary licensing,
Bosak 1.26.2 pins and disabled packaging remain fixed. Earlier sections are historical step
records; this checkpoint supersedes their delivery status and next-action wording.

## EP6-D Restart/Retry Process Qualification (2026-10-29)

EP6-C is pushed as `5977451`. [EP6-D validation](docs/implementation/M2_EMBEDDED_HOST_RESTART_PROCESS_VALIDATION.md)
adds 72 actual process-kill cases across both roles at H=1, covering transfer, known/absent
outcomes, fresh retry intent and execution acknowledgment gaps. Reopen remains stopped;
separate reconciliation retains data and never recreates execution tickets. All 1,055 focused
cases pass per Windows/Linux platform. EP6-D is included in this restart checkpoint. Next audit the consuming application's selected-root/work-accounting gate;
production routing, writer resumption, public release and physical durability remain open.

## EP6-C Explicit Fresh-Plan Retry (2026-10-29)

EP6-A/B is pushed as `8d38762`. [EP6-C validation](docs/implementation/M2_EMBEDDED_HOST_RETRY_VALIDATION.md)
adds explicit retry preparation with a fresh real plan/attempt ID after exact qualified absence.
It retains request/pin/destination, reinspects before recording and uses an exact-position save
to exclude duplicate retry intents across fronts. 22 new cases cover success, changed facts,
concurrency and lost intent acknowledgment. All 983 focused cases pass per Windows/Linux platform.
EP6-C remains local/uncommitted. Next qualify
process termination across the combined restart/retry workflow; automatic retry/writer resume
and application routing remain disabled.

## EP6-B Stopped Restart Inspection (2026-10-29)

[EP6-B validation](docs/implementation/M2_EMBEDDED_HOST_RESTART_INSPECTION_VALIDATION.md)
adds actual pinned-operation inspection with acknowledged owner transfer and separate known
observation/qualified absence saves. Admissions stay closed; saved receipts cannot be synthesized
or replaced from inspection. 26 new Integration cases cover both roles/heads, contradictory
terminal facts and uncertain saves. All 961 focused cases pass on Windows and Linux.
Next: explicit fresh-plan retry after qualified absence;
retry runtime and process-kill qualification remain pending. EP6-A/B remain local/uncommitted.

## EP6-A Stopped Append Boundary (2026-10-29)

The EP6 contract is pushed as `22eeddf`. [EP6-A validation](docs/implementation/M2_EMBEDDED_HOST_STOPPED_APPEND_VALIDATION.md)
adds exclusive stopped-session registration and restricted transfer/observation/absence saves,
without opening administrative admissions. 25 new cases cover evidence, stale/foreign tokens,
concurrency, uncertainty and shutdown drain. All 935 focused cases pass on Windows and Linux.
Inspector composition, explicit fresh-plan retry
and process-kill qualification remain pending. EP6-A changes are local/uncommitted.

## EP6 Stopped Restart Design (2026-10-29)

EP4/EP5 is committed and pushed as `24feda2`. The [EP6 contract](docs/implementation/M2_EMBEDDED_HOST_RESTART_CONTRACT.md)
specifies a restricted reconciliation session with admissions closed, exact owner transfer,
separate known-operation observations and qualified absence before an explicit fresh-plan retry.
This is design only; restart persistence and retry runtime remain pending. Next implement the
stopped lifetime registration/append path and qualify its uncertainty and concurrency boundaries.
Existing 910 focused tests per platform remain the baseline; no new runtime coverage is claimed.
Hosted run `40793748444` could not start runner steps due to GitHub payment/spending limits.

## EP5 Live Plan-Bound Orchestration (2026-10-28)

[ADR-026](docs/ADR-026-live-plan-bound-embedded-orchestration.md) and
[validation](docs/implementation/M2_EMBEDDED_HOST_ORCHESTRATION_VALIDATION.md) add
opaque live tickets, exact acknowledged intent/authorization and one registered executor per
host. Actual receipts and host acknowledgments/errors remain separate; no saved plan is
reconstructed. 56 new cases qualify process gaps, duplicate use, active-attempt mutation and
shutdown; 910 focused cases pass per platform. Public metadata/wire formats stay unchanged.
Next: stopped persisted restart reconciliation and explicit new-ID retry after qualified
absence. HA2 application, global fencing, release and physical durability gates remain open.
EP4/EP5 was subsequently committed/pushed as `24feda2`; hosted CI remains billing-blocked.

## EP4 Owned Conditional Append (2026-10-28)

Pushed-baseline CI run 40771851255 did not start build/tests because GitHub account payment/
spending limits blocked both jobs. Local EP4 validation is separate; account-owner action is
needed for hosted runners. No billing/settings change or automatic rerun was made.

EP2/EP3 is committed/pushed as `4642b09`. [ADR-025](docs/ADR-025-owned-conditional-host-journal-append.md)
and [append validation](docs/implementation/M2_EMBEDDED_HOST_APPEND_VALIDATION.md)
now qualify exact-head append, actual file flush/readback and permanently faulted uncertain
sessions. 47 new cases cover write/flush failures, process interruption and test-only planned
publication composition; focused runs pass 854 cases per platform. Public Storage metadata
and wire formats stay unchanged. Reopened history remains stopped and never recreates a plan.
Next EP5 binds acknowledged ledger transitions to one registered live executor in an internal
orchestrator. HA2 application, release and physical durability gates remain open. EP4 is local.

## EP3 Explicit No-Overwrite Provisioning (2026-10-28)

[ADR-024](docs/ADR-024-explicit-no-overwrite-host-provisioning.md) and
[validation](docs/implementation/M2_EMBEDDED_HOST_PROVISIONING_VALIDATION.md) qualify
controlled absent-root creation, continuous CreateNew owner handoff and retained interrupted
state. 60 new tests cover partial writes, checkpoint/process kills and synchronized contenders;
807 focused cases pass per platform. Existing roots are never adopted or repaired by provision.
Reopened empty roots remain stopped; the live initializer diagnostic is not durable authority.
Next EP4 implements bounded conditional journal append and unknown-flush fault handling.
Physical durability, hostile namespace/global fencing, HA2 and release gates remain open.
Changes remain local/uncommitted; pushed baseline `2141eac` is unchanged.

## EP3 Existing Host Lifetime Ownership (2026-10-28)

[Ownership validation](docs/implementation/M2_EMBEDDED_HOST_OWNERSHIP_VALIDATION.md)
adds existing-root cooperative exclusion, stopped administrative admissions and token-drained
shutdown. 50 new catalog cases cover process exit/active drain, aliases, invalid roots and
real publisher lifetimes. Focused runs pass 747 cases per platform; three FIFO rows execute
only on Linux. Public Storage metadata remains unchanged. No host files are provisioned,
repaired or appended by this implementation, and no global fence or writer resume is implied.
Next: explicit no-overwrite provisioning and interruption/contender tests before EP4 append.
EP2/EP3 work remains local/uncommitted; the pushed baseline remains `2141eac`.

## EP2 Internal Journal Codec (2026-10-28)

[Codec validation](docs/implementation/M2_HOST_JOURNAL_CODEC_VALIDATION.md) now covers
strict bounded metadata/frame/TLV encoding, complete history checks and four independently
authored host-only vectors. 117 new codec cases pass; focused Windows/Linux runs pass 697
cases each. All 168 prior runtime/test/fixture files and public Storage metadata are unchanged.
Decoded history always keeps writers stopped; no codec output grants execution or proves
flush, anti-rollback or fencing. Next EP3 qualifies stable host-root lifetime ownership with
explicit provisioning boundaries and real process tests. EP4 durable append, HA2 application
integration and release gates remain open. EP2 design/codec changes remain local/uncommitted.

## Current Delivery and EP2 Journal Contract (2026-10-28)

The embedded profile is committed/pushed as `2141eac`. [ADR-023](docs/ADR-023-bounded-embedded-host-journal-contract.md)
and the [journal contract](docs/implementation/M2_EMBEDDED_HOST_JOURNAL_CONTRACT.md)
now define bounded canonical host-only frames, conditional transitions and explicit append/flush
uncertainty. Damaged tails are retained and block appends; restart never replays a plan.
No codec/writer, anti-rollback authority or durable-host proof is implemented. Next: a pure
internal codec with independent byte vectors, before filesystem persistence. This contract
is local/uncommitted; earlier delivery notes below retain their original scope.

## Current Delivery and Embedded Pilot Selection (2026-10-28)

RC2 through test-only HA1 integration is committed/pushed as `5d23ba2` on `origin/main`.
The user selected single-process embedded integration first. [ADR-022](docs/ADR-022-single-process-embedded-pilot-host.md)
and the [pilot profile](docs/implementation/M2_EMBEDDED_HOST_PROFILE.md) define one
controlled process, a dedicated host-state root, lifetime ownership and stopped restart
reconciliation. A local file journal is proposed; no backend or host is implemented yet.
Next EP2 defines its bounded codec, commit and corruption/rollback contract. M4 server,
HA2 application routing/work, public/archived-reader/release and retirement gates stay open.
This post-push profile is local; older uncommitted statements below describe their original
milestones. No runtime/test/fixture source changes or new runtime runs occur in this step.

## HA1 Ledger and Planned Execution Tests (2026-10-28)

[Test-only integration](docs/implementation/M2_HOST_LEDGER_PLANNED_EXECUTION_VALIDATION.md)
now connects memory-ledger intent/authorization/receipt transitions to real owner-bound
migration and restore. 34 new cases cover lost-save acknowledgments, actual publication
uncertainty, new-ID retry after reconciled absence, concurrent authorizers and an active
publisher that defeats absence-based retry. Focused runs pass 448 cases per platform.
All prior runtime/test/fixture files are unchanged; no production adapter is introduced.
The bounded model/library integration is complete. Next: identify the actual consuming host,
durable backend, effective publisher exclusion and route/work authorities before HA2.
No memory commit proves durability or fencing. Changes remain local and uncommitted.

## HA1 Conditional Transition Harness (2026-10-28)

The internal [in-memory transition harness](docs/implementation/M2_HOST_LEDGER_TRANSITION_VALIDATION.md)
now models exact-revision commits, single dispatch authorization, explicit read reconciliation
of lost acknowledgments and supplied-exclusion ownership transfer. 83 new tests cover commit
boundaries, concurrent winners, stale owners and preservation of receipts/observations;
414 focused cases pass per platform. Public Storage metadata remains unchanged.
No durable backend, executable permit, effective fence, routing or writer resume is supplied.
Next: test-only integration of these transitions with actual planned execution and lost-save
acknowledgments. Actual host selection and HA2 remain open; changes are uncommitted.

## HA1 Internal Ledger Model (2026-10-28)

The [ledger decision model](docs/implementation/M2_HOST_ATTEMPT_LEDGER_MODEL_VALIDATION.md)
now checks supplied request/attempt/revision/owner bindings, durable-intent assumptions,
publication/receipt identity and prior-executor exclusion. All 180 new model tests pass;
focused validation covers 331 cases per platform, retaining earlier full-suite evidence at
its original scope. Every output keeps writers stopped and grants no executable authority.
Actual host selection, persistence and HA2 integration remain open. Next: an internal
conditional-transition harness for revision/CAS and lost-acknowledgment protocol tests.
Changes remain local and uncommitted; proprietary licensing and release gates are unchanged.

## HA1 Host Ledger Contract (2026-10-28)

[ADR-021](docs/ADR-021-host-attempt-ledger-and-publisher-exclusion.md) and the
[host ledger contract](docs/implementation/M2_HOST_ATTEMPT_LEDGER_CONTRACT.md) define
durable intent before dispatch, revision-checked ownership, separate acknowledgment and
observation records, and prior-executor exclusion before any fresh attempt. A ledger lease
cannot fence the current publication path; an old publisher must be stopped or effectively
excluded before takeover/retry. The 24 design scenarios are requirements, not runtime tests.
Actual host selection and HA2 integration remain open. Next: an internal pure supplied-evidence
ledger decision model and adversarial tests. No persistent backend, routing, public API or
writer resume is enabled. RC2/RC3 and this contract remain local and uncommitted.

## Previous Step: RC2 Planned Administrative Execution

[ADR-020](docs/ADR-020-planned-administrative-attempt-correlation.md) now has RC1 preparation/
claim and RC2 explicit execution. The creating service consumes a plan before filesystem
I/O, requires its pinned inventory/role/paths/policy before output and publishes its preknown
ID in the existing provenance field. Unplanned default behavior and frozen bytes remain fixed.
[Validation](docs/implementation/M2_ADMINISTRATIVE_ATTEMPT_EXECUTION_VALIDATION.md) adds
31 cases for H0/H3 roles, changed input, consumed state and lost publication acknowledgment.
Next RC3 qualifies actual process/restart and competing publishers. No public API, routing,
source replacement, durable replay or reclamation is enabled.

## Latest Runtime Evidence: Consolidated Regression and API Readiness Review

Internal epoch commit/recovery, full-history backup/restore/migration, MG5 modeled cutover,
CA1/CA2 compatibility/ownership, HC1 classification and PA1-PA3 consumer/administrative/
read-only observation prototypes are implemented. Existing public APIs remain profile-specific;
mutable facades are internal. M2 shipping, real host routing and all retirement remain open.

[Current review](docs/implementation/M2_CONSOLIDATED_API_READINESS_REVIEW.md) and
[results](docs/implementation/m2-consolidated-api-readiness-results.json) distinguish the
unfiltered 1,050-case baseline from the final 80-case classifier hardening batch. Aggregation
replaces earlier classifier rows and adds one case: 1,051 unique catalog cases per platform.
All 27 expensive ET9-D/MG4 matrix rows are included freshly in the baseline; Windows native
nonexecution and actual Linux execution remain separate. No unfiltered 1,051-case run is claimed.

The public Storage metadata matches its exact local frozen baseline. Review fixes HC1 null
identity classification and Linux/Windows CI documentation portability; current-source
hosted CI remains unrun. That correlation design is now recorded in ADR-020; RC1 implementation/tests are next
before any public administrative diagnostics. Keep archived release, actual host, physical
qualification and public release gates explicit. CanReclaim=false.

The following sections preserve earlier evidence at its original dated scope.

## Historical Runtime Gate: Internal ET8 Native Durability Fault Qualification

[Native durability evidence](docs/implementation/M2_EPOCH_NATIVE_DURABILITY_VALIDATION.md)
now qualifies the recorded local Windows ProcessCrash and Linux FileAndDirectoryFlush
failure models. FaultingTransactionStorage retains modeled delegation by default; explicit
native mode delegates the exact requested policy. The existing commit/redo/tail sweep bodies
are reused and assert EffectiveDurability against the actual underlying LocalTransactionStorage.

Twelve new Linux sweeps inject before/after calls and real partial writes around actual
file/directory operations, including native directory fsync. Old uncached readers remain
protected and repeated reopen reproduces exact state. A real procfs fsync errno propagates
without weaker fallback. Windows rejects unsupported native policy before epoch mutation;
the Linux-only branches do not execute there. Runner diagnostics now record test-temp
filesystem/OS provenance. No engine behavior, wire/public API or frozen reader change is needed.
ET9 epoch backup/history migration and public mutable APIs remain pending.

## Admission-Owned Read-Only Epoch Data

[ADR-011](docs/ADR-011-admission-owned-read-only-epoch-snapshots.md) adds
ReadOnlyEpochDatabase.Open and BeginRead, returning the existing ImmutableXmlSnapshot
accepted by PersistentXdmNode. Sessions and snapshots own independent shared admission;
uncached lazy reads continue after session disposal and block exclusive maintenance
until snapshot close/process exit. Metadata/argument failure cleanup does not leak handles.

Major-2 FORMAT/EPOCH/BXEA bytes remain unchanged. A new SNAPSHOT/BXES binds identity,
sequence zero, FORMAT and manifest digests. Existing manifest/directory/fragments preserve
IDs/order/values/URI/namespaces. Open validates metadata; payloads are lazy/hash-checked.
A .transactions marker/nonzero sequence is refused rather than silently reading stale
base data. Legacy entry points and frozen format-1 readers still reject populated epochs.

Fixture production is internal only: copy an immutable unadopted M1 source into fresh
staging without nested legacy FORMAT, bind/verify the data, close verification leases,
then publish the complete root. Source bytes remain intact. There is no public creation,
transactional history migration, epoch writer/recovery/backup or reclamation API.
The unavailable archived pre-lease readers still prevent a complete C1 claim.

## Backup and Restore

CreateBackup(destination) holds the coordinator gate for its full capture, excluding
commits and checkpoint publication. It retains the original source and captures base,
CONTROL, every WAL and complete generation 1..H, plus CURRENT for H>0. Optional
checkpoints/descriptors and runtime locks/readers/staging are omitted. Unknown dependencies
or missing materializations fail; reopen FullJournal to reconstruct missing generations.

The artifact contains data/, inventory.bin and COMPLETE. BXBI binds BackupId, document,
exact H, base/head hashes, and sorted canonical file names/sizes/SHA-256. BXBC binds the
inventory digest. RestoreBackup validates the sealed closure and hashes, copies to new
staging and verifies exact H/head through FullJournal on a disposable clone with zero
replay. All lazy values are read; manifest/directory/fragment digests preserve IDs/order.
Only operation-owned verification clones/workspaces are cleaned; source history is retained.

Destination parents must exist. Existing, overlapping, linked or portable alias/device
paths are refused. Capture argument errors leave the owner usable; I/O/verification
errors fault it until reopen. An unacknowledged publication can already be complete.
Retry into a fresh destination; never merge. Failures can leave unroutable sibling
.xmldb-backup-* workspaces. No automatic abandoned-workspace cleanup is provided.

See [ADR-009](docs/ADR-009-verified-full-history-backup-and-restore.md),
[format](docs/implementation/M2_BACKUP_FORMAT_V1.md),
[validation](docs/implementation/M2_BACKUP_VALIDATION.md) and
[integration](docs/INTEGRATION.md).

## Retained Runtime Validation (ET9-D)

**669 tests pass on Windows and 669 on Linux**, zero final failures/skips:
519 Storage, 27 Xdm, 123 Integration. The new 18-case Storage matrix records every observed
H=1 persistence call and injects before/after errors plus real partial writes. Six native-only
branches return on Windows; they are not native evidence. Existing process cases now repeat
three times and cover same-path retry after unpublished interruption and immutable refusal
to overwrite published results.

[Structured evidence](docs/implementation/m2-epoch-backup-fault-results.json) records actual
fault counts, policy delegation and durations. Windows combines focused Storage, isolated
Storage/Xdm regressions and canonical Integration; Linux combines the full suite and final
Integration assertions. Retained sweeps remain 2,162 Windows /2,579 Linux positions, including
481 native ET8 Linux positions. See [qualification](docs/implementation/M2_EPOCH_BACKUP_FAULT_VALIDATION.md).
Prior ET9-C evidence is retained in [restore results](docs/implementation/m2-epoch-backup-restore-results.json).
Frozen fixtures, proprietary licensing and existing formats remain unchanged. SDK10.0.301;
Windows dotnet10.0.11/NTFS and Linux10.0.9/Ubuntu24.04.4/overlayfs. No physical power-loss,
real ENOSPC, migration or remote CI certification is claimed.

Public read-epoch sample smoke against an internally prepared root: SO-1, 20 lines,
sequence zero, one header fragment read and zero line payload reads. Ignored
.tools/epoch-readonly-example.json records it; preparation was via the test probe,
not a public creation/migration API.

Public sample smoke: captured H=2 / SO-3, advanced source to H=3 / SO-4, restored the
original H=2 / SO-3 and all 20 lines. BackupId and document identity match. Ignored
.tools/backup-smoke-result.json records the example.

New checks cover H=0/multiple commits, source byte preservation, exact node/value parity,
independent restored writes, fixed-H serialization with an old uncached reader, corruption,
wrong resealed head, missing WAL, unknown dependencies, path refusal, independent golden
bytes/truncation, exhaustive capture/restore storage failures and real process kills.
Native Linux directory barriers and symlink refusal are exercised in the pinned isolated
SDK runner. Windows uses ProcessCrash plus modeled stronger-policy tests.

## Existing Transaction, Checkpoint and Reader Contracts

One text or ordinary attribute value per transaction; empty attributes supported, empty
text/structural/multi-target edits unsupported. Stale writes conflict. FullJournal remains
default; PreferCheckpoint validates every retained WAL record and selected prefix before
skipping old materializations. Optional corruption can select an independent descriptor
or fall back to full history; required corruption fails closed. LastRecovery describes
the completed selected pass, not all startup I/O.

Snapshots/transactions own stable shared generation handles even after coordinator
disposal. Never unlink or replace lease identities. Old binaries may hold no leases:
PlanRetention cannot infer their absence or authorize deletion. Original Open overloads,
M1 and WAL/control/checkpoint/lease bytes remain unchanged.

ProcessCrash is default. FileAndDirectoryFlush is experimental Linux-only with no fallback.
Policies are per operation/coordinator, not a persisted SLA. Local container results do
not certify production filesystems/controllers, physical power loss or real ENOSPC.
Capture blocks writes; there is no online/incremental backup, authenticity/encryption,
replication, cross-region service or mutable-store performance promise.

## Next Recommendation

Internal MG1-MG5 are implemented. Next: audit compatibility/release-readiness evidence
against original M2/C1-C3 criteria, inventory exact missing archived pre-lease binaries and
provenance, and keep prototype evidence separate from shipping qualification. No public
mutable API, actual routing/configuration rewrite, source replacement or history deletion.

[ADR-008](docs/ADR-008-reader-compatibility-backup-and-retirement.md) and the
[protocol](docs/implementation/M2_COMPATIBILITY_BACKUP_RETIREMENT.md) remain the design
for these later phases. The journal limit remains 10,000 commits; backup inventory is
bounded at 100,000 files and the existing 64 MiB per-file limit.

*Last updated: 2026-10-30*


ET9-D qualification update (2026-10-27): capture/restore persistence sweeps now enumerate
every observed before/after call and actual partial-write position on a one-commit history.
Process-crash and modeled strong ordering are separate from actual native Linux delegation.
Repeated process interruption covers private publication windows, published outcomes and
acknowledgment loss. Source/backup bytes, historical reads, provenance and released handles
are checked. See [fault qualification](docs/implementation/M2_EPOCH_BACKUP_FAULT_VALIDATION.md).
Full-history migration/cutover acceptance is now specified by ADR-018; runtime implementation remains pending. Public mutable APIs, source replacement and history reclamation remain disabled.


Migration/cutover design update (2026-10-27): [ADR-018](docs/ADR-018-full-history-legacy-migration-and-cutover.md)
now specifies internal conversion of a sealed format-1 full-history backup into a fresh
ScalarWal 2.1 bundle. [Acceptance criteria](docs/implementation/M2_EPOCH_MIGRATION_DESIGN.md)
require complete-history and full-redo verification on both sides, exact sequence/data
parity, separate migration provenance and explicit operator-controlled cutover. The
converter never opens the live legacy root. Source paths/history are retained; cutover
requires a write freeze and source/candidate freshness checks. No runtime migration,
routing API or retirement is implemented. MG1 codecs/fixtures are now implemented; next: MG2 legacy verification. The design-only step retained the 669-case runtime baseline; the MG1 update below records
fresh codec/regression coverage separately, without claiming runtime migration proof.


MG1 implementation update (2026-10-27): internal EpochMigrationCodec now encodes the
separate 350-byte BXEM 1.0 migration-origin role, frozen with independent H0/H2 vectors in
[the byte contract](docs/implementation/M2_EPOCH_MIGRATION_FORMAT_V1.md). Pure
source/destination header checks preserve legacy H0 CURRENT omission and reject malformed
bounds and substituted commitments. They perform no I/O and grant no closure/history,
admission, migration or cutover capability. See [validation](docs/implementation/M2_EPOCH_MIGRATION_CODEC_VALIDATION.md).
MG2 legacy verification is now implemented; next: MG3 conversion and verified bundle publication.
No runtime converter, routing API, source replacement or retirement is enabled.


MG2 implementation update (2026-10-27): internal [LegacyMigrationVerifier](docs/implementation/M2_LEGACY_MIGRATION_VERIFICATION.md)
now validates sealed legacy closure, every scalar transition and exact fixed-H authority
before workspace writes, then verifies complete and independent full-WAL-redo clones.
Only private clones can initialize runtime files or republish byte-identical CURRENT;
sealed input and live source roots are not recovered or rewritten. No destination store
is published. [Validation](docs/implementation/M2_LEGACY_MIGRATION_VERIFICATION_VALIDATION.md)
distinguishes 33 new cases/738 fresh filtered regressions per platform from retained ET9-D
evidence. MG3 internal conversion is implemented; next: MG4 exhaustive fault qualification.
Public migration/mutable APIs, cutover and retirement remain disabled.


MG3 implementation update (2026-10-27): internal [EpochLegacyMigration](docs/implementation/M2_EPOCH_MIGRATION_CONVERSION.md)
now verifies sealed legacy full history through MG2, assigns fresh epoch identity and
re-encodes every authority/WAL link while preserving H, transaction/document/node IDs and
XML data bytes. Both destination history oracles and fresh runtime/provenance checks must
pass before atomic store/ plus migration.bin bundle publication; staging handles close first.
Source paths/artifact stay intact. [Validation](docs/implementation/M2_EPOCH_MIGRATION_CONVERSION_VALIDATION.md)
records 27 new Storage and six process cases with 771 fresh filtered regressions per platform,
separately retaining the unchanged 18-case ET9-D matrix. MG4 observed fault/native/process qualification is now recorded. Public APIs, actual cutover and retirement stay disabled.


MG4 qualification update (2026-10-27): [conversion fault evidence](docs/implementation/M2_EPOCH_MIGRATION_FAULT_VALIDATION.md)
now covers every observed H=1 persistence call before/after and actual partial writes,
with immutable input and valid/absent publication checks. Process probes repeat 12 windows
three times per supported policy, including private legacy copy/redo, epoch redo and ACK
loss, with actual native Linux delegation separate from modeled ordering. Production
algorithms and bytes are unchanged. Fresh regressions cover 798 cases per platform, with
18 unchanged ET9-D cases retained separately. Next: MG5 source/candidate freshness and
explicit cutover/rollback acceptance harness. Public APIs, routing service, source
replacement and all retirement remain disabled.


MG5 acceptance update (2026-10-27): [internal cutover harness](docs/implementation/M2_MIGRATION_CUTOVER_ACCEPTANCE.md)
now freezes cooperating mutations, registers capture under that freeze, and revalidates
exact source/candidate commitments for session-bound single-use routing observations.
It models known/uncertain outcomes and verified no-work return versus reconciliation,
without changing any route/configuration or store path. [Validation](docs/implementation/M2_MIGRATION_CUTOVER_ACCEPTANCE_VALIDATION.md)
records 32 Storage/two process cases and 823 fresh filtered regressions per platform, with
27 unchanged fault-matrix cases retained separately. MG1-MG5 are internal prototype gates;
next: compatibility/release-readiness evidence audit. Archived-reader gaps, public API/
shipping qualification and retirement remain open; all source data stays retained.


Compatibility audit (2026-10-28): [release-readiness evidence](docs/implementation/M2_RELEASE_READINESS_AUDIT.md) verifies both frozen local reader families and records C1-C3 gaps. No shipping gate is closed. Next: CA1 rejection/nonmutation coverage for actual published migration bundles and every nested generation; archived release provenance remains unavailable locally.


CA1 update (2026-10-28): [real migrated-bundle compatibility validation](docs/implementation/M2_MIGRATED_BUNDLE_COMPATIBILITY_VALIDATION.md) adds 12 local frozen/current rejection cases for H0/H3 wrapper, store and every generation, including exact file/directory and runtime identity preservation. Complete archived C1 and actual routing remain open. Next: CA2 migrated-candidate child/owner disposal races and cross-process lifetime checks.


CA2 update (2026-10-28): [migrated ownership validation](docs/implementation/M2_MIGRATED_OWNERSHIP_VALIDATION.md) adds 12 repeated child/owner race cases and four cross-process holder-release cases. Local ownership proof is stronger; archived compatibility, actual routing and shipping remain open. Next: define supported public API and host cutover/restart contracts before implementing real routing.


API/host contract design (2026-10-28): [ADR-019](docs/ADR-019-explicit-mutable-api-and-host-cutover-boundary.md) and the [contract](docs/implementation/M2_PUBLIC_API_AND_HOST_CUTOVER_CONTRACT.md) separate explicit mutable access from host-owned writer exclusion, revision-checked routing and restart reconciliation. Proposed names are not public APIs; no host adapter or durable routing record is implemented. Next: HC1 pure restart/reconciliation classifier. Archived compatibility and release gates remain open.


HC1 update (2026-10-28): [pure restart classification](docs/implementation/M2_RESTART_CLASSIFICATION_VALIDATION.md) adds internal supplied-observation decisions and 79 Storage cases. Every result keeps writers stopped, including new-workflow eligibility; no host observation, route change or durable receipt is created. Next: PA1 explicit mutable facade prototype and ownership/profile/diagnostic tests, remaining internal until release gates pass.


PA1 prototype update (2026-10-28): [internal mutable facade](docs/implementation/M2_SCALAR_EPOCH_FACADE_VALIDATION.md) wraps explicit options, independent snapshots/transactions, scalar commits and fixed-head backup. An optional expected identity rejects before admission/recovery. 22 new internal consumer cases preserve diagnostics and uncertainty semantics; public exposure remains disabled. Next: PA2 separate administrative facade prototype and publication-outcome tests.


PA2 prototype update (2026-10-28): [separate administration facade](docs/implementation/M2_SCALAR_EPOCH_ADMINISTRATION_VALIDATION.md) adds sealed legacy/epoch verification and independent restore/migration receipts. 29 new cases cover bound results, input preservation, strict proof and publication uncertainty. No public API or automatic routing/retry is enabled. Next: PA3 read-only publication inspection and reconciliation observations.


PA3 update (2026-10-28): [read-only publication inspection](docs/implementation/M2_PUBLICATION_INSPECTION_VALIDATION.md) adds pinned-artifact and optional known-operation correlation, with reconciliation for changed/incomplete inputs and no adoption/recovery. 43 new cases preserve bytes/runtime identities; every observation keeps writers stopped. Next: consolidated cross-platform regression and API/readiness review. Public/host/archive/release gates remain open.


## RC3 Process and Contention Qualification (2026-10-28)

RC3 qualifies preannounced IDs across publisher process death, independent plans racing
one destination and concurrent dispatch of one plan. See [validation](docs/implementation/M2_ADMINISTRATIVE_ATTEMPT_PROCESS_VALIDATION.md).
Focused Windows/Linux runs pass 71 cases each, including 12 new RC3 cases; earlier
full-suite evidence retains its dated scope. This supersedes earlier next-RC3 statements.
RC2/RC3 remain local; a3b578c contains work through RC1. No public API, host routing,
durable replay, source replacement or reclamation is enabled. Next HA1 defines the host
attempt-ledger and fencing contract; local inspection alone never authorizes retry.
