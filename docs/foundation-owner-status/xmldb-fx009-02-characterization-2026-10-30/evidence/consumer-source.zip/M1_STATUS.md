# Bosak.XmlDb M1 Status

- Date: 2026-10-26; repository D:/Development/Bosal.XmlDb.
- Scope: implemented immutable embedded experiment, format 1.0; no M2 work.
- License: proprietary Fytala, as explicitly selected by the owner.
- Upstream: exact Bosak 1.26.2 packages; nuspec commit
  6a3372fc3b91e733b71a426cf40f26feaaeb3bcb verified with Git cat-file.
  The original archive baseline is historical, not the implementation dependency.
- Environment: Windows 10.0.26300 x64; SDK 10.0.301; runtime 10.0.11.
- Git: no commit, tag, push, remote creation or release publication performed.

## Implemented Surfaces

Core defines immutable node metadata, kinds and I/O metrics. Storage implements
versioned bounded binary codecs, SHA-256 integrity, SalesOrder ingestion, persisted
manifest/directory, metadata graph validation, snapshots and byte-bounded LRU cache.
Xdm implements IXdmNode, all axes, identity/equality/order, scalar/descendant values,
XML serialization, exact stored-URI resolution and bound lazy result lifetime.

Added process integration tests, runnable EmbeddedQuickstart, benchmark mode,
transitive package lock files, third-party notices and ADR-002/003. Upstream Bosak,
compiler/VM and remote Database provider remain unchanged.

## Validation Commands and Results

- `dotnet restore Bosak.XmlDb.slnx --locked-mode`: passed for seven projects.
- `dotnet build Bosak.XmlDb.slnx -c Release --no-restore`: passed, zero errors;
  seven existing MINVER1001 warnings in this checkout/account environment. No version
  tag exists; MinVer fell back to its default alpha. No warning suppression added.
- `dotnet test Bosak.XmlDb.slnx -c Release --no-build`: 45 passed, 0 failed, 0 skipped:
  18 Storage, 26 Xdm, 1 process integration test.
- `dotnet format Bosak.XmlDb.slnx --verify-no-changes --no-restore`: passed.
- `pwsh tools/check-docs.ps1 -ProjectPath . -Strict`: passed, including kit hashes, renderer settings, provenance, branding, links and section numbering.
- `dotnet samples/EmbeddedQuickstart/bin/Release/net10.0/EmbeddedQuickstart.dll benchmark <new-store> 500`:
  executed successfully; see benchmarks/m1/windows-net10-500-lines.jsonl.

## Acceptance Evidence

| Gate | Evidence |
|------|----------|
| Persist/reopen | Separate import/read processes return SO-1 and 500 lines without source XML |
| Header payload isolation | LineFragmentReads=0 across corpus/group variations and the process probe |
| Metadata count | Zero payload reads in benchmark count queries |
| Tenth-line selection | One needed line-group read for fixtures with at least ten lines |
| Semantic parity | Corpus sizes 0/1/10/500/10,000; groups 1/16/128 plus seeded variable sizes; core XPath expressions and direct thirteen-axis comparisons |
| XML details | Namespace inheritance/undeclaration, attributes, xml:id, mixed content, comments, PIs, base/document URI and equivalent serialization |
| Lifetime | Direct axes, mid-enumeration fetches, node access and BindResult reject disposed snapshots |
| Corruption | Golden bytes for every file; framing/version/length/hash/truncation, directory graph and pointer validation; lazy fragment checks |
| Cache | Cache hits, disabled caching and byte-budget eviction tests |
| Performance | Recorded warm/fresh fragment cache p50/p95/p99, allocations, reads/bytes/hits and directory footprint |

## Scope Limits and Deviations

- One immutable document per newly created store root; no catalog, updates, transactions,
  WAL, lock coordination, fsync/crash-safe publication or server/messaging code.
- Import materializes bounded XML/metadata; lazy I/O applies to reading. XML 1.0 untyped
  documents only; DTD/external entities prohibited. CDATA boundaries are not lexical guarantees.
- IDs provide immutable preorder; future insertion order is unresolved. Cross-snapshot
  wrappers are distinct. Snapshot access/disposal is confined to one evaluation thread.
- BindResult is required for lazy results produced by the VM, which may materialize its
  own sequence. The adapter cannot change arbitrary raw VM sequence enumeration.
- Bosak 1.26.2 Attributes() includes namespace declarations; its XPath attribute axis
  correctly excludes them. Differential attribute tests use Axis(Attribute); see ADR-002.
- Cold extensions remain in the header fragment in this first policy. Namespace axis
  order is implementation defined; bindings, identity and ordering consistency are tested.
- Format 1.0 is experimental and rejects all unsupported major/minor versions; no migration.
- Benchmark fresh cache means empty application fragment cache, not flushed OS disk cache.
  Retained metadata memory is a GC estimate; no general performance/HA SLA is claimed.
- Local Windows checks passed. Linux/remote CI and visual renderer checks have not run here.
  Packaging remains disabled, and the API has not been published.

## Next Recommended Action

Review the format, public API/lifetime contract, known upstream helper discrepancy and
benchmark evidence before M2. Define transaction span, mutable identity/order, WAL/root
publication and filesystem crash-injection strategy. Do not infer authorization to
change upstream or deploy distributed infrastructure from M1 completion.

*Last updated: 2026-10-26*
