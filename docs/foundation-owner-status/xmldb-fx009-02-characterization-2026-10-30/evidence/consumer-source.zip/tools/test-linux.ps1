#Requires -Version 7
<#
.SYNOPSIS
Runs the pinned suite in an isolated Linux container.
.DESCRIPTION
Requires Docker, an explicitly fetched SDK image and the restored host NuGet cache.
Source/cache are read-only and the container has no network.
.EXAMPLE
./tools/test-linux.ps1 -Filter 'FullyQualifiedName~DurabilityTests'
#>
[CmdletBinding()]
param(
    [ValidatePattern('^[A-Za-z0-9][A-Za-z0-9./:@_-]*$')]
    [string]$Image = 'mcr.microsoft.com/dotnet/sdk:10.0.301',
    [string]$ResultsDirectory = '.tools/linux-tests',
    [string]$Filter = ''
)
$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath((Split-Path $PSScriptRoot -Parent))
$results = [IO.Path]::GetFullPath((Join-Path $root $ResultsDirectory))
$comparison = if ($IsWindows) { [StringComparison]::OrdinalIgnoreCase } else { [StringComparison]::Ordinal }
if (-not $results.StartsWith($root + [IO.Path]::DirectorySeparatorChar, $comparison)) {
    throw 'ResultsDirectory must be inside the project workspace.'
}
$cache = Join-Path ([Environment]::GetFolderPath('UserProfile')) '.nuget/packages'
if (-not (Test-Path -LiteralPath $cache -PathType Container)) { throw 'Restore the project in the host NuGet cache first.' }
$null = Get-Command docker -ErrorAction Stop
& docker image inspect $Image --format '{{.Id}}'
if ($LASTEXITCODE -ne 0) { throw "Fetch the pinned SDK image explicitly first: docker pull $Image" }
New-Item -ItemType Directory -Force -Path $results | Out-Null
$runner = @(
'set -euo pipefail',
'mkdir -p /work',
'(tar -C /source --exclude=''.git'' --exclude=''.tools'' --exclude=''*/bin'' --exclude=''*/obj'' -cf - .) | tar -C /work -xf -',
'cd /work',
'dotnet --info > /results/dotnet-info.txt',
'uname -a > /results/kernel.txt',
'stat -f -c ''%T'' /work > /results/filesystem.txt',
'stat -f -c ''%T'' /tmp > /results/temp-filesystem.txt',
'stat -f -c ''%T'' /proc > /results/proc-filesystem.txt',
'cat /etc/os-release > /results/os-release.txt',
'df -T /tmp /work > /results/filesystems.txt',
'dotnet restore Bosak.XmlDb.slnx --locked-mode --ignore-failed-sources -p:RestoreFallbackFolders=/cache -p:NuGetAudit=false',
'dotnet build Bosak.XmlDb.slnx -c Release --no-restore',
'args=()',
'if [ -n "${BOSAK_TEST_FILTER:-}" ]; then args+=(--filter "$BOSAK_TEST_FILTER"); fi',
'dotnet test Bosak.XmlDb.slnx -c Release --no-build "${args[@]}" --logger ''trx;LogFilePrefix=linux'' --results-directory /results'
) -join "`n"
[IO.File]::WriteAllText((Join-Path $results 'run-linux-tests.sh'), $runner + "`n")
& docker run --rm --network none `
    --mount "type=bind,source=$root,target=/source,readonly" `
    --mount "type=bind,source=$cache,target=/cache,readonly" `
    --mount "type=bind,source=$results,target=/results" `
    -e DOTNET_CLI_TELEMETRY_OPTOUT=1 -e DOTNET_SKIP_FIRST_TIME_EXPERIENCE=1 `
    -e "BOSAK_TEST_FILTER=$Filter" $Image bash /results/run-linux-tests.sh
if ($LASTEXITCODE -ne 0) { throw "Linux build/test failed with exit code $LASTEXITCODE." }
