#Requires -Version 7
<#
.SYNOPSIS
    Verifies installed kit integrity, renderer wiring, branding, generation provenance, and local links.
#>
[CmdletBinding()]
param([string]$ProjectPath = '.')
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'documentation-kit.ps1')
$root = (Resolve-Path -LiteralPath $ProjectPath).Path
$marker = Get-Content (Resolve-KitPath $root '.fytala-docs.json') -Raw -Encoding utf8 | ConvertFrom-Json
if ($marker.schemaVersion -ne 1 -or $marker.manifest -ne 'docs-kit/manifest.json') { throw 'Invalid kit adoption marker.' }
$manifest = Get-DocumentationKit $root $marker.kitVersion -Installed
# Verify destinations as well as sources: consumers need not preserve a release's source layout.
foreach ($file in $manifest.files) {
    $path = Resolve-KitPath $root $file.destination
    if (-not (Test-Path -LiteralPath $path -PathType Leaf) -or
        (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $file.sha256) {
        throw "Modified or missing governed file: $($file.destination)"
    }
}
$attributes = Get-Content (Resolve-KitPath $root '.gitattributes') -Raw -Encoding utf8
$rules = @($manifest.files | ForEach-Object { '"' + $_.destination.Replace('\', '/') + '" -text' }) + @('"docs-kit/manifest.json" -text')
$expectedBlock = $rules -join [string][char]10
if (-not $attributes.Replace([string][char]13, '').TrimEnd().EndsWith($expectedBlock, [StringComparison]::Ordinal)) {
    throw 'The byte-preserving kit Git attribute block must remain final.'
}
$settings = Get-Content (Resolve-KitPath $root '.vscode/settings.json') -Raw -Encoding utf8 | ConvertFrom-Json -AsHashtable
foreach ($property in $manifest.workspaceSettings.PSObject.Properties) {
    if (-not $settings.ContainsKey($property.Name)) { throw "Missing renderer setting: $($property.Name)" }
    if ($property.Value -is [array]) {
        foreach ($expected in $property.Value) {
            if ($expected -notin $settings[$property.Name]) { throw "Renderer setting drift: $($property.Name)" }
        }
    } elseif ($settings[$property.Name] -ne $property.Value) { throw "Renderer setting drift: $($property.Name)" }
}
if ($settings.ContainsKey('markdown-pdf.executablePath')) { throw 'Keep machine-specific browser paths in user settings.' }
$provenance = Get-Content (Resolve-KitPath $root '.template-provenance.json') -Raw -Encoding utf8 | ConvertFrom-Json
if ($provenance.schemaVersion -ne 1 -or $provenance.templateVersion -notmatch '^\d+\.\d+\.\d+$' -or
    $provenance.kitVersion -notmatch '^\d+\.\d+\.\d+$' -or
    $provenance.templateManifestSha256 -notmatch '^[a-fA-F0-9]{64}$' -or
    $provenance.scaffoldSha256 -notmatch '^[a-fA-F0-9]{64}$' -or -not $provenance.generatedAtUtc -or
    -not $provenance.projectName) { throw 'Invalid template provenance.' }
$null = [DateTime]::Parse($provenance.generatedAtUtc)
$canonical = @('README.md','ROADMAP.md','docs/ARCHITECTURE.md','docs/FEATURE_REQUESTS.md','docs/INTEGRATION.md')
foreach ($document in $canonical) {
    $text = Get-Content (Join-Path $root $document) -Raw -Encoding utf8
    if ($text -notmatch '<div align="center">' -or $text -notmatch '<h1>' -or $text -notmatch 'alt="Fytala [^"]+"') {
        throw "Missing branded banner: $document"
    }
    if ($text -notmatch '\(c\) .+\. All rights reserved\.') { throw "Missing copyright: $document" }
}
$guide = Get-Content (Join-Path $root 'docs/DOCUMENTATION_STYLE_GUIDE.md') -Raw -Encoding utf8
$mission = [regex]::Match($guide, '(?s)## About FYTALA\r?\n(.*?)\r?\n---\r?\n\r?\n## About PRIME').Groups[1].Value.Trim()
$readme = Get-Content (Join-Path $root 'README.md') -Raw -Encoding utf8
if (-not $mission -or -not $readme.Contains($mission)) { throw 'Canonical FYTALA statement missing or altered.' }
foreach ($file in Get-ChildItem -LiteralPath $root -Recurse -File -Force | Where-Object {
    $_.FullName -notmatch '[\\/](\.git|bin|obj|node_modules)[\\/]' -and
    $_.Extension -in '.md','.json','.yml','.yaml','.xml','.props','.targets','.csproj','.ps1'
}) {
    $text = Get-Content -LiteralPath $file.FullName -Raw -Encoding utf8
    if ($text -match '\{\{[A-Z][A-Za-z0-9]*\}\}') { throw "Unresolved template token: $($file.Name): $($matches[0])" }
    if ($file.Extension -ne '.md') { continue }
    # Example links inside fenced snippets are not rendered links.
    $text = [regex]::Replace($text, '(?ms)^\x60{3}[^\r\n]*\r?\n.*?^\x60{3}[^\r\n]*$|^~{3}[^\r\n]*\r?\n.*?^~{3}[^\r\n]*$', '')
    foreach ($match in [regex]::Matches($text, '(?:!?\[[^\]]*\]\(([^)]+)\)|<img\b[^>]*\bsrc="([^"]+)")')) {
        $reference = if ($match.Groups[1].Success) { $match.Groups[1].Value } else { $match.Groups[2].Value }
        if ($reference -match '^(https?:|mailto:|#)' -or $reference -match '[*<>]') { continue }
        $relative = ($reference -split '#', 2)[0]
        if ($relative -and -not (Test-Path -LiteralPath (Join-Path $file.DirectoryName $relative))) {
            throw "Broken local reference: $($file.Name): $reference"
        }
    }
    foreach ($image in [regex]::Matches($text, '<img\b[^>]*>')) {
        if ($image.Value -notmatch '\balt="[^"]+"') { throw "Image lacks alt text: $($file.Name)" }
    }
}
Write-Host "Kit $($manifest.kitVersion), renderer settings, branding, provenance, placeholders, and local references passed."
