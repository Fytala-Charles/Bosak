#Requires -Version 7
<#
.SYNOPSIS
    Full local rebuild for Bosak.XmlDb: clean, restore, build, test.

.DESCRIPTION
    Runs a complete clean → restore → build (Release) → test cycle for the
    solution. Used locally before committing and mirrors the CI workflow in
    .github/workflows/build.yml.

.EXAMPLE
    .\tools\rebuild.ps1
#>
[CmdletBinding()]
param ()

$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent

Push-Location $root
try {
    dotnet clean "Bosak.XmlDb.slnx" --configuration Release
    if ($LASTEXITCODE -ne 0) { throw "Rebuild command failed with exit code $LASTEXITCODE." }
    dotnet restore "Bosak.XmlDb.slnx"
    if ($LASTEXITCODE -ne 0) { throw "Rebuild command failed with exit code $LASTEXITCODE." }
    dotnet build "Bosak.XmlDb.slnx" --configuration Release --no-restore
    if ($LASTEXITCODE -ne 0) { throw "Rebuild command failed with exit code $LASTEXITCODE." }
    dotnet test "Bosak.XmlDb.slnx" --configuration Release --no-build
    if ($LASTEXITCODE -ne 0) { throw "Rebuild command failed with exit code $LASTEXITCODE." }
}
finally {
    Pop-Location
}
