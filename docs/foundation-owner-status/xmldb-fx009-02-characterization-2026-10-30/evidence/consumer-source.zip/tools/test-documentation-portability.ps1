#Requires -Version 7
<#
.SYNOPSIS
Exercises hidden-file resolution and link/traversal rejection on the current host.
.DESCRIPTION
Uses only a freshly owned temporary directory. No governed kit file is modified.
#>
# 2026-10-28: regression coverage for GitHub Linux hidden-dotfile resolution.
[CmdletBinding()]
param([string]$ProjectPath = '.')
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path -LiteralPath $ProjectPath).Path
. (Join-Path $root 'tools/documentation-kit.ps1')
$tempRoot = [IO.Path]::GetFullPath([IO.Path]::GetTempPath())
$probeRoot = [IO.Path]::GetFullPath((Join-Path $tempRoot ('Bosak.XmlDb-docs-' + [Guid]::NewGuid().ToString('N'))))
$comparison = if ($IsWindows) { [StringComparison]::OrdinalIgnoreCase } else { [StringComparison]::Ordinal }
$created = $false
$link = Join-Path $probeRoot 'linked'
try {
    if (Test-Path -LiteralPath $probeRoot) { throw 'Probe path already exists.' }
    $null = New-Item -ItemType Directory -Path $probeRoot
    $created = $true
    $hidden = Join-Path $probeRoot '.marker.json'
    [IO.File]::WriteAllText($hidden, '{}')
    if ($IsWindows) { [IO.File]::SetAttributes($hidden, [IO.FileAttributes]::Hidden) }
    if ((Resolve-KitPath $probeRoot '.marker.json') -ne $hidden) { throw 'Hidden marker did not resolve.' }
    $hiddenDirectory = Join-Path $probeRoot '.hidden'
    $null = New-Item -ItemType Directory -Path $hiddenDirectory
    [IO.File]::WriteAllText((Join-Path $hiddenDirectory 'fixture.txt'), 'retained')
    if ($IsWindows) { [IO.File]::SetAttributes($hiddenDirectory, [IO.FileAttributes]::Hidden) }
    $null = Resolve-KitPath $probeRoot '.hidden/fixture.txt'
    $null = Resolve-KitPath $hiddenDirectory 'fixture.txt'
    $rejected = $false
    try { $null = Resolve-KitPath $probeRoot '../escape' } catch { $rejected = $_.Exception.Message -like 'Unsafe kit path:*' }
    if (-not $rejected) { throw 'Traversal was not rejected by the path guard.' }
    $kind = if ($IsWindows) { 'Junction' } else { 'SymbolicLink' }
    $null = New-Item -ItemType $kind -Path $link -Target $hiddenDirectory
    $rejected = $false
    try { $null = Resolve-KitPath $probeRoot 'linked/fixture.txt' } catch { $rejected = $_.Exception.Message -like 'Kit paths must not traverse symlinks or junctions:*' }
    if (-not $rejected) { throw 'The actual link boundary was not rejected.' }
    if ([IO.File]::ReadAllText((Join-Path $hiddenDirectory 'fixture.txt')) -ne 'retained') { throw 'Fixture changed.' }
    Write-Host 'Hidden file/directory/root resolution and actual link/traversal rejection passed.'
} finally {
    if ($created) {
        $resolvedProbe = [IO.Path]::GetFullPath($probeRoot)
        $allowedParent = $tempRoot.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
        if (-not $resolvedProbe.StartsWith($allowedParent, $comparison) -or -not [IO.Path]::GetFileName($resolvedProbe).StartsWith('Bosak.XmlDb-docs-', [StringComparison]::Ordinal)) { throw 'Refusing cleanup outside the owned temporary probe.' }
        $linkItem = Get-Item -LiteralPath $link -Force -ErrorAction SilentlyContinue
        if ($null -ne $linkItem) {
            if (-not ($linkItem.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Probe link was replaced; refusing cleanup.' }
            Remove-Item -LiteralPath $link -Force
        }
        Remove-Item -LiteralPath $resolvedProbe -Recurse -Force
    }
}
