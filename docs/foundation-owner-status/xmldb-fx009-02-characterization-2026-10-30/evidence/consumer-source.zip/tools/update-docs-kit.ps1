#Requires -Version 7
<#
.SYNOPSIS
    Adopts an explicitly selected, locally available FYTALA documentation kit.
.DESCRIPTION
    Verifies the entire source kit before writing. Rejects modified consumer kit files,
    merges portable renderer settings, preserves project companions, and rolls back
    file contents if installation fails. No network fetch or implicit latest version.
.EXAMPLE
    ./tools/update-docs-kit.ps1 -ProjectPath . -KitSourcePath ../Templates -KitVersion 1.2.0 -WhatIf
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory)][string]$ProjectPath,
    [Parameter(Mandatory)][string]$KitSourcePath,
    [Parameter(Mandatory)][string]$KitVersion
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'documentation-kit.ps1')
$sourceRoot = (Resolve-Path -LiteralPath $KitSourcePath).Path
$targetRoot = [IO.Path]::GetFullPath($ProjectPath)
$kit = Get-DocumentationKit $sourceRoot $KitVersion
$markerPath = Resolve-KitPath $targetRoot '.fytala-docs.json'
$oldDestinations = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
if (Test-Path -LiteralPath $markerPath) {
    $marker = Get-Content -LiteralPath $markerPath -Raw -Encoding utf8 | ConvertFrom-Json
    if ($marker.schemaVersion -ne 1 -or $marker.manifest -ne 'docs-kit/manifest.json') { throw 'Invalid consumer adoption marker.' }
    $oldKit = Get-DocumentationKit $targetRoot $marker.kitVersion -Installed
    foreach ($file in $oldKit.files) {
        $path = Resolve-KitPath $targetRoot $file.destination
        if (-not (Test-Path -LiteralPath $path -PathType Leaf) -or
            (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $file.sha256) {
            throw "Modified consumer kit file: $($file.destination). Review local changes before upgrading."
        }
        $null = $oldDestinations.Add($file.destination.Replace('\', '/'))
    }
}
$writes = [ordered]@{}
foreach ($file in $kit.files) {
    $path = Resolve-KitPath $targetRoot $file.destination
    if ((Test-Path -LiteralPath $path) -and -not $oldDestinations.Contains($file.destination.Replace('\', '/')) -and
        (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $file.sha256) {
        throw "Existing file conflicts with adoption: $($file.destination)"
    }
    $writes[$path] = [IO.File]::ReadAllBytes((Resolve-KitPath $sourceRoot $file.source))
}
$settingsPath = Resolve-KitPath $targetRoot '.vscode/settings.json'
$settings = if (Test-Path -LiteralPath $settingsPath) {
    Get-Content -LiteralPath $settingsPath -Raw -Encoding utf8 | ConvertFrom-Json -AsHashtable
} else { @{} }
foreach ($property in $kit.workspaceSettings.PSObject.Properties) {
    if ($property.Value -is [array]) {
        $settings[$property.Name] = @($property.Value) + @($settings[$property.Name] | Where-Object { $_ -notin $property.Value })
    } else { $settings[$property.Name] = $property.Value }
}
$writes[$settingsPath] = ConvertTo-KitJsonBytes $settings
# Prevent Git's autocrlf or text normalization from changing manifest-governed bytes.
$attributesPath = Resolve-KitPath $targetRoot '.gitattributes'
$attributes = if (Test-Path -LiteralPath $attributesPath) { [IO.File]::ReadAllText($attributesPath) } else { '* text=auto' }
$attributeLines = @($kit.files | ForEach-Object { '"' + $_.destination.Replace('\', '/') + '" -text' }) + @('"docs-kit/manifest.json" -text')
$attributeBlock = $attributeLines -join [Environment]::NewLine
# Rules must remain last: a later wildcard could otherwise re-enable text conversion.
$normalizedAttributes = $attributes.Replace([string][char]13, '').TrimEnd()
$normalizedBlock = $attributeBlock.Replace([string][char]13, '')
if (-not $normalizedAttributes.EndsWith($normalizedBlock, [StringComparison]::Ordinal)) {
    $attributes = $attributes.TrimEnd() + [Environment]::NewLine + $attributeBlock + [Environment]::NewLine
}
$writes[$attributesPath] = [Text.UTF8Encoding]::new($false).GetBytes($attributes)
$writes[(Resolve-KitPath $targetRoot 'docs-kit/manifest.json')] = [IO.File]::ReadAllBytes((Resolve-KitPath $sourceRoot 'docs-kit/manifest.json'))
$kitReadme = Resolve-KitPath $sourceRoot 'docs-kit/README.md'
if (Test-Path -LiteralPath $kitReadme) { $writes[(Resolve-KitPath $targetRoot 'docs-kit/README.md')] = [IO.File]::ReadAllBytes($kitReadme) }
$writes[$markerPath] = ConvertTo-KitJsonBytes @{ schemaVersion = 1; kitVersion = $KitVersion; manifest = 'docs-kit/manifest.json' }
# Updating Templates also updates its pin; consumer generation provenance stays historical.
$pinPath = Resolve-KitPath $targetRoot 'template.json'
if (Test-Path -LiteralPath $pinPath) {
    $pin = Get-Content -LiteralPath $pinPath -Raw -Encoding utf8 | ConvertFrom-Json
    $pin.kitVersion = $KitVersion
    $writes[$pinPath] = ConvertTo-KitJsonBytes $pin
}
if (-not $PSCmdlet.ShouldProcess($targetRoot, "Adopt verified FYTALA kit $KitVersion ($($writes.Count) files)")) { return }
$backups = [ordered]@{}
try {
    foreach ($entry in $writes.GetEnumerator()) {
        $backups[$entry.Key] = if (Test-Path -LiteralPath $entry.Key -PathType Leaf) { [IO.File]::ReadAllBytes($entry.Key) } else { $null }
        New-Item -ItemType Directory -Path (Split-Path $entry.Key) -Force | Out-Null
        [IO.File]::WriteAllBytes($entry.Key, $entry.Value)
    }
} catch {
    foreach ($path in @($backups.Keys)) {
        if ($null -eq $backups[$path]) {
            if (Test-Path -LiteralPath $path -PathType Leaf) { Remove-Item -LiteralPath $path }
        } else { [IO.File]::WriteAllBytes($path, $backups[$path]) }
    }
    throw
}
Write-Host "Adopted FYTALA kit $KitVersion. Review the diff and run the renderer acceptance fixture."
