#Requires -Version 7
# Shared offline kit validation. Governed content is never expanded as a template.
# 2026-10-28: inspect hidden dotfiles with -Force while retaining the reparse-point guard.
function Resolve-KitPath {
    param([string]$Root, [string]$RelativePath)
    if ([string]::IsNullOrWhiteSpace($RelativePath) -or [IO.Path]::IsPathRooted($RelativePath) -or
        $RelativePath -match '[:<>|?*]' -or ($RelativePath -split '[\\/]') -contains '..' -or
        ($RelativePath -split '[\\/]') -contains '.') {
        throw "Unsafe kit path: $RelativePath"
    }
    $absoluteRoot = [IO.Path]::GetFullPath($Root).TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
    $path = [IO.Path]::GetFullPath((Join-Path $absoluteRoot $RelativePath))
    if (-not $path.StartsWith($absoluteRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Kit path escapes repository: $RelativePath"
    }
    $cursor = $path
    while ($cursor -and $cursor.Length -ge $absoluteRoot.Length) {
        if ((Test-Path -LiteralPath $cursor) -and ((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) {
            throw "Kit paths must not traverse symlinks or junctions: $RelativePath"
        }
        if ($cursor -eq $absoluteRoot) { break }
        $cursor = Split-Path $cursor -Parent
    }
    return $path
}

function Get-DocumentationKit {
    param([string]$KitRoot, [string]$ExpectedVersion, [switch]$Installed)
    $manifestPath = Resolve-KitPath $KitRoot 'docs-kit/manifest.json'
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding utf8 | ConvertFrom-Json
    if ($manifest.schemaVersion -ne 1 -or $manifest.kitVersion -notmatch '^\d+\.\d+\.\d+$') {
        throw 'Unsupported kit schema or version.'
    }
    if ($ExpectedVersion -and $manifest.kitVersion -ne $ExpectedVersion) {
        throw "Expected kit $ExpectedVersion; found $($manifest.kitVersion)."
    }
    if (@($manifest.files).Count -eq 0) { throw 'Kit manifest has no files.' }
    $destinations = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($file in $manifest.files) {
        $destination = $file.destination.Replace('\', '/')
        if ($destination -notmatch '^(assets/|\.crossnote/|docs/)' -or
            $destination -eq 'docs/PROJECT_DOCUMENTATION_CONVENTIONS.md') {
            throw "Unsupported governed destination: $destination"
        }
        $null = Resolve-KitPath $KitRoot $file.destination
        if (-not $destinations.Add($destination)) { throw "Duplicate kit destination: $destination" }
        if ($file.sha256 -notmatch '^[a-fA-F0-9]{64}$') { throw "Invalid hash: $destination" }
        $source = Resolve-KitPath $KitRoot $(if ($Installed) { $file.destination } else { $file.source })
        if (-not (Test-Path -LiteralPath $source -PathType Leaf) -or
            (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $file.sha256) {
            throw "Kit integrity mismatch: $($file.source)"
        }
    }
    foreach ($required in @('docs/DOCUMENTATION_STYLE_GUIDE.md','docs/DOCUMENTATION_RENDERER_TEST.md')) {
        if (-not $destinations.Contains($required)) { throw "Kit missing required document: $required" }
    }
    if ($null -eq $manifest.workspaceSettings -or
        $null -ne $manifest.workspaceSettings.PSObject.Properties['markdown-pdf.executablePath']) {
        throw 'Kit must supply portable renderer settings.'
    }
    return $manifest
}

function ConvertTo-KitJsonBytes {
    param($Value)
    return ,([Text.UTF8Encoding]::new($false).GetBytes(($Value | ConvertTo-Json -Depth 30) + [Environment]::NewLine))
}
