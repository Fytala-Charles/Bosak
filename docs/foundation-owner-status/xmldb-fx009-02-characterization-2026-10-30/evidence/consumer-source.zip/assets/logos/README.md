# FYTALA Logos

The approved dark and light SVG masters are governed by docs-kit/manifest.json. Use the dark logo on light backgrounds and the light logo on dark backgrounds. Preserve the governed files byte-for-byte, and use meaningful alt text.

*Last updated: 2026-10-26*
