<div align="center">
  <img src="assets/logos/fytala-logo-color-dark.svg" width="100" alt="Fytala Bosak.XmlDb">
  <br><br>
  <h1>Bosak.XmlDb</h1>
  <p>Embedded native XML fragment storage and persistent XDM navigation.</p>
</div>

## SR3-A Stopped Handoff Preparation Design (2026-10-30)

[ADR-036](docs/ADR-036-stopped-handoff-preparation-and-lifetime.md) and
[contract](docs/implementation/M2_STOPPED_HANDOFF_PREPARATION_CONTRACT.md) define private success-only
proof, actual preparation/plan/executor child drain and the actual paired parent session as
successor. Closing before claim refuses; claim-before-close retains original usable handles
through completion. No runtime or format change. Readiness checkpoint `069332c` is committed
and pushed; this design is local/uncommitted. Next SR3-B1 implements private proof and child
lifetime before SR3-B2 preparation/claim, SR3-C qualification and the separate SR4 writer.
Prior Windows 2,752 and focused Linux 394 cases remain retained evidence, not fresh execution.
Host/public/archive/durable-fence and all retirement gates remain open; CanReclaim=false.

## SR1/SR2 Stopped Restart Readiness Review (2026-10-30)

[Review](docs/implementation/M2_STOPPED_RESTART_READINESS_REVIEW.md) verifies 64 retained
artifacts, 15 historical source inputs and complete Windows test-ID growth from 2,529 to 2,752.
All 223 additions appear in the latest 394-case focused Linux catalog; platform bodies/guards
remain distinct. Initial restore timeouts stay separate from passing project rechecks.
No runtime changes or fresh execution. Next SR3-A defines success-only proof consumption,
actual plan-child drain and successor/session binding before preparation code. Existing
observation/descriptor success grants no handoff or write authority. Host/public/archive and
all retirement gates remain open. Checkpoint `7da1b17` is committed/pushed; this review is local.

## SR2-C Native, Process and Disposal Qualification (2026-10-30)

[Validation](docs/implementation/M2_OWNED_RESTART_QUALIFICATION_VALIDATION.md) adds 38 cases
without product source changes. Eleven native roles/roots are replaced with identical bytes
at two boundaries: 22 actual Linux executions, separately recorded as 22 Windows guards.
Ordered and repeated concurrent disposal, 14 process kills and 14 fresh observations and independent
holders/races preserve bytes/inventory and keep every result stopped. Final focused runs pass
189 Windows and 394 Linux cases.
All 2,752 Windows cases pass across complete project runs. The initial restore timeouts are
retained and pass focused plus complete Integration rechecks. Next consolidate SR1/SR2
readiness before SR3 handoff preparation. Host/public/archive/retirement gates remain open.
Checkpoint `de5c9a4` is committed/pushed; SR2-C qualification is local/uncommitted.

## SR2-B Paired Stopped Restart Observation (2026-10-30)

[Implementation and validation](docs/implementation/M2_OWNED_RESTART_OBSERVATION_VALIDATION.md)
bind actual parent/authority/source retention through read-only complete source/sealed-capture
proof and fresh exact journal/native identity checks. All results stay stopped and inert;
no capture association, receipt, initializer or handoff capability is recreated. Nonterminal
administrative history forces reconciliation despite caller assertions. All 58 new cases and
282 focused Windows cases pass; 356 focused Linux cases pass, including all 58 new bodies.
All 2,714 Windows cases pass across complete project runs. The initial restore timeout is
retained and passes focused plus complete Integration rechecks. Next SR2-C native/process/race
qualification; SR3/SR4 and host/public/archive/retirement gates remain open. Checkpoint `a31203b`
is committed/pushed; SR2-B is local/uncommitted. Public and frozen formats remain unchanged.

## SR2-A Actual Restart Source Retention (2026-10-30)

[Implementation and validation](docs/implementation/M2_RESTART_SOURCE_RETENTION_VALIDATION.md)
add a separate restart-only actual source child, permanent stopped admission and original
usable writer retention through real drain. No old capture association or initializer is
recreated. Native source inspection runs outside its gate; close uncertainty never retries or
clears the stop. All 38 new cases and 152 focused Windows cases pass; 268 focused Linux cases
also pass, including all 38 new bodies. All 2,656 Windows cases pass across complete project runs. The initial restore timeout is
retained and passes focused plus complete Integration rechecks.
This source-only slice does not implement paired restart observation. Next SR2-B full actual
parent/authority/source-bound proof and freshness; SR2-C/SR3/SR4 and host/public/archive/retirement
gates remain open. Checkpoint `bc5e490` is committed/pushed; SR2-A is local/uncommitted.

## SR2 Actual Ownership Integration Design (2026-10-30)

[ADR-035](docs/ADR-035-owned-stopped-restart-observation.md),
[design](docs/implementation/M2_OWNED_RESTART_OBSERVATION_DESIGN.md) and
[review](docs/implementation/M2_OWNED_RESTART_OBSERVATION_REVIEW.md) specify a separate
restart-only retained source child and paired stopped observation. Existing freeze/capture
association and initializer checks remain strict. Verification must not hide live recovery
writes or confuse the inventory commitment with the manifest hash. Design only; no runtime
change. Next SR2-A source lifetime primitive, then SR2-B/C observation and qualification;
SR3/SR4 and all host/public/archive/retirement gates remain open.
Checkpoint `b0c94bd` is committed/pushed. SR2 design is local/uncommitted; prior 2,618 Windows
passing cases across complete project runs and 451 focused Linux cases are retained evidence,
not new execution. All source/candidate/WAL histories remain retained, CanReclaim=false.

## SR1 Pure Stopped Enrollment Assessment (2026-10-30)

[Implementation and validation](docs/implementation/M2_ENROLLMENT_RESTART_CLASSIFIER_VALIDATION.md)
add an internal pure classifier of supplied exact-head, source/capture and stopped-host facts.
Every result remains stopped and inert. Empty/unsupported/missing observations require
reconciliation; invalid history or contradictory facts refuse. No receipt, initializer, live
ownership, handoff plan or execution permission is recreated. All 89 new cases and 335 focused
Windows cases pass; 451 focused Linux cases also pass, including all 89 new bodies.
All 2,618 Windows cases pass across complete project runs. The initial restore timeout is
retained and passes focused plus complete Integration rechecks. Public/frozen formats and
actual source/authority lifetimes remain unchanged. Next SR2 actual owner-bound stopped
evidence; SR3/SR4 capability/output and host/public/archive/retirement gates remain open.
Checkpoint `100b39d` is committed/pushed; SR1 is local/uncommitted.

## ER-004 Stopped Restart and Owner Handoff Design (2026-10-30)

[ADR-034](docs/ADR-034-stopped-enrollment-restart-and-owner-handoff.md) and the
[contract](docs/implementation/M2_STOPPED_ENROLLMENT_RESTART_CONTRACT.md) define inert stopped
assessment, fresh actual ownership/exclusion and a separately gated future TransferOwner.
[Review](docs/implementation/M2_STOPPED_ENROLLMENT_RESTART_REVIEW.md) records design checks;
no runtime, public API or frozen format changes. Valid Enroll bytes never recreate a receipt
or initializer. Empty/unsupported/uncertain restarts require reconciliation; corruption rejects
without repair. All histories remain retained. Next SR1 implements only the pure stopped
classifier; SR2-SR4 actual evidence, capability and output qualification remain unimplemented.
ER-003 checkpoint `edf0b72` is committed/pushed. Its 2,529 Windows passing cases across complete
project runs and 740 focused Linux cases remain prior execution evidence, with initial
Integration timeouts preserved separately. This design adds no runtime test cases.

## ER-003 Authority and Parent Release Qualification (2026-10-30)

[Contract](docs/implementation/M2_ENROLLMENT_ROLE_RELEASE.md) and
[validation](docs/implementation/M2_ENROLLMENT_ROLE_RELEASE_VALIDATION.md) add an actual-owner,
internal close seam and 42 direct role-close cases. Before/after/no-op errors suppress required
cleanup acknowledgment, preserve bytes and keep release uncertainty separate from physical
handle availability. All 2,529 Windows cases qualify across complete project runs and 740 broad
Linux cases pass, including all 42 new bodies per platform. Two initial restore timeouts are
retained and pass focused plus complete Integration rechecks. Production null/default close delegation and public/frozen contracts remain
unchanged. Next ER-004 defines stopped restart/enrollment reconciliation and owner handoff;
no further writer, work/routing admission, source replacement or reclamation is enabled.
Historical sections below retain their dated scope.

## ER-002 Retained Preflight Boundary (2026-10-30)

[Implementation](docs/implementation/M2_RETAINED_ENROLLMENT_PREFLIGHT.md) and
[validation](docs/implementation/M2_RETAINED_ENROLLMENT_PREFLIGHT_VALIDATION.md) move retained
protected-path inspection outside authority serialization. Actual source/parent/authority
ownership spans the unlocked phases; exact roles/metadata/empty head are checked again after
the last placement pass. All 2,487 Windows cases pass across complete project runs; 698 broad
Linux cases pass, including all 19 new bodies per platform. Two initial restore timeouts are
retained and pass focused plus complete Integration rechecks. Generic readers and frozen/public
contracts remain unchanged. Next ER-003 qualifies direct authority/parent close errors;
ER-004 and all host/public/archive/retirement gates remain open. Historical sections below
retain their dated scope.

## EF1-EF4 Consolidated Readiness Review (2026-10-30)

[Review](docs/implementation/M2_ENROLLMENT_READINESS_REVIEW.md) verifies 51 retained TRX
artifacts, 256 unchanged source/build/fixture inputs and all 2,468 Windows test IDs; 679 Linux
focused IDs are retained separately. Fresh public metadata remains 95/95, with no additions.
No runtime suite or feature is added by the review. ER-002 identifies protected-ancestor I/O
under the shared authority monitor during retained preflight; next harden that boundary under
ADR-033. Direct authority/parent close-fault qualification and stopped restart/owner handoff
remain later gaps. No public API, application admission, routing or reclamation is enabled.
Historical sections below retain their dated scope.

## EF4 Enrollment Fault and Process Qualification (2026-10-30)

[Qualification](docs/implementation/M2_FIRST_ENROLLMENT_FAULT_VALIDATION.md) adds observed
call-edge/all-prefix fault sweeps, actual Linux inode substitutions, cross-thread I/O closing,
repeated process/ACK-loss boundaries and independent competing publishers. The 387-byte frame
produces 393 sweep attempts; 34 new catalog cases include eight Windows host guards. Each
focused process run uses 48 workers. Production runtime/format/public surface is unchanged.
All 2,468 Windows and 679 isolated Linux focused cases pass; eight new Windows rows are
explicit host guards. Formatting/docs/portability and frozen fixture checks pass. Next consolidate
EF1-EF4 readiness and remaining host/restart contracts before another authority writer.
No application admission, actual routing or reclamation is enabled. Historical sections below
retain their dated scope.

## EF3 Conditional First Enrollment (2026-10-30)

[Implemented contract](docs/implementation/M2_FIRST_ENROLLMENT_APPEND.md) and
[validation](docs/implementation/M2_FIRST_ENROLLMENT_APPEND_VALIDATION.md) add one terminal
stopped Enroll append from the actual retained preparation. Exact empty-head/native-role checks,
flush/readback/full-history validation and cleanup confirmation precede acknowledgment.
Possible output or release uncertainty retains bytes and prevents receipt synthesis/retry.
All 2,434 Windows and 645 isolated Linux focused cases pass, including all 45 new cases per
platform. Formatting/docs/portability and frozen fixture checks pass. No application work admission or public API is enabled. Next EF4 qualifies observed
persistence positions, process interruption/ACK loss and competing owners. Real host/archive/
retirement gates remain open. Historical sections below retain their dated scope.

## EF2 Retained Enrollment Admission (2026-10-29)

[Implemented contract](docs/implementation/M2_RETAINED_ENROLLMENT_ADMISSION.md) adds a
separate owner-bound retained preparation, resource transfer to actual execution and a
nonblocking authority/parent/source arm decision. Wrapper disposal retains all three original
owners through actual execution; unknown source close retains authority/parent operations.
All 2,389 Windows and 600 isolated Linux focused cases pass, including 29 new cases per
platform. Formatting/docs/portability and frozen fixture checks pass. No authority output or application admission is enabled. Next EF3 implements the
conditional first Enroll frame; EF4 persistence qualification and real host/public/archive/
retirement gates remain open. Historical sections below retain their dated scope.

## EF1 Retained Source Lifetime (2026-10-29)

[Implemented contract](docs/implementation/M2_ENROLLMENT_SOURCE_RETENTION.md) and
[validation](docs/implementation/M2_ENROLLMENT_SOURCE_RETENTION_VALIDATION.md)
add opt-in source/freeze children, deferred original writer-stream close and a source-owner
stop latch. Native identity, actual drain and release uncertainty remain explicit. All 2,360
Windows tests and 571 isolated Linux focused cases pass, including 29 new cases per platform.
Formatting/docs/portability and frozen fixture checks pass. No authority output or application admission is enabled. Next EF2 integrates a
separate retained preparation and atomic dispatch admission, still without authority writes.
Historical design/qualification blocks below retain their dated scope.

## Retained Source Exclusion and First-Enrollment Design (2026-10-29)

[ADR-033](docs/ADR-033-retained-source-exclusion-and-first-enrollment.md) and
[contract](docs/implementation/M2_APPLICATION_AUTHORITY_ENROLLMENT_APPEND_DESIGN.md)
specify opt-in source/freeze retention, one atomic arm decision, a stopped original-source
latch and exact one-frame conditional append with terminal uncertainty. This is design only;
current preparation remains read-only. The [review](docs/implementation/M2_APPLICATION_AUTHORITY_ENROLLMENT_APPEND_DESIGN_REVIEW.md)
records 24 future acceptance scenarios, not test passes. Runtime/build inputs remain at the
qualified 2,331-case Windows / 542-case focused Linux baseline. Next EF1 implements source
retention/deferred close/stop-latch qualification with no authority writes. EF2-EF4, actual
host control, public APIs, archived compatibility and all reclamation remain open.

## Owner-Bound First-Enrollment Preparation (2026-10-29)

[ADR-032](docs/ADR-032-owner-bound-first-enrollment-preparation.md) and
[validation](docs/implementation/M2_APPLICATION_AUTHORITY_ENROLLMENT_VALIDATION.md)
add read-only preparation against a real frozen legacy store and its registered sealed
capture, actual source owner identity and scoped reconciliation assertions. The actual
owner-bound preparation is single-use and retains authority/admin leases. All 2,331 Windows
cases pass across full project runs; 542 isolated Linux cases pass, including all 35 new cases
per platform. One existing Windows kill case failed once and passed focused/complete reruns;
the validation report retains the observation. Operational
assertions remain supplied assumptions; no enrollment/append or application work is enabled.
Next design conditional first-enrollment save/uncertainty with continuing real ownership and
fresh explicit operational evidence. Historical next-action blocks retain their dated scope.

## EP7-C Explicit Authority Provisioning Slice (2026-10-29)

[ADR-031](docs/ADR-031-application-authority-provisioning-and-initializer.md) and
[provisioning validation](docs/implementation/M2_APPLICATION_AUTHORITY_PROVISIONING_VALIDATION.md)
add separate no-overwrite absent-root creation, direct exclusive-owner handoff, retained
partial state and a single-use live initializer reservation that holds actual paired leases.
All 2,296 Windows cases pass across full project runs; 475 focused Linux cases pass, including
46 new cases per platform. One existing Windows release case failed once and passed focused
and complete reruns; the validation report retains that observation.
All writers stay stopped. No enrollment/append or real application baseline is established.
Actual process interruption, acknowledgment loss and independent creators are now qualified.
Next bind a real operational baseline to owner-bound first-enrollment preparation before
conditional append. Historical next-action sections below retain their dated scope.

## EP7-C Paired Existing-Root Authority Inspection (2026-10-29)

[ADR-030](docs/ADR-030-paired-read-only-application-authority-ownership.md) and
[lifetime validation](docs/implementation/M2_APPLICATION_AUTHORITY_LIFETIME_VALIDATION.md)
add opaque parent-mode exclusion, real authority ownership/native identity checks, read-only
full-history inspection and actual-read drain. All 429 focused Windows cases pass, including
71 new cases (three Windows FIFO guards). Full Windows passes all 2,250 tests; fresh isolated
Linux passes 429 focused cases with actual FIFO bodies. Formatting/docs/portability and fixture
checks pass; exact scope and XML-only final test documentation are recorded in the report. Next explicit no-overwrite provisioning/initializer
qualification before append; no authority writes, routing or application admission is added.

## Application-Authority Pure Codec (2026-10-29)

[Codec validation](docs/implementation/M2_APPLICATION_AUTHORITY_CODEC_VALIDATION.md) records
strict metadata/frame/TLV decoding and complete-history transitions with retained work obligations.
Four independent frame/history vectors and 166 focused cases pass. Successful Windows project
runs cover all 2,179 tests after a full Integration rerun cleared two initial timeouts. The
report retains those failures and the Docker-blocked Linux result; docs/formatting/portability pass. All decoded results stay stopped;
existing formats/public APIs remain unchanged. Next EP7-C starts with the new owner-bound
application child lifetime/existing-root boundary before provisioning and persistence.

## EP7-B Application-Authority Format Specification (2026-10-29)

[ADR-029](docs/ADR-029-separate-application-authority-journal-v1.md) and the
[v1 contract](docs/implementation/M2_APPLICATION_AUTHORITY_FORMAT_V1.md) specify separate
metadata/frames, retained work transitions, no-overwrite provisioning and uncertain-save rules.
[Validation](docs/implementation/M2_APPLICATION_AUTHORITY_FORMAT_VALIDATION.md) records two
independent metadata-only vectors and 13 passing Python checks. No production codec or
persistence is implemented. Existing C# remains at the passing 2,013-test Windows baseline.
Next implement the pure codec/full-history validator with independent frame/history vectors
before EP7-C owned persistence. Existing host/store bytes and all histories remain protected.

## EP7-A Pure Pilot Authority Classification (2026-10-29)

[Classification validation](docs/implementation/M2_EMBEDDED_PILOT_AUTHORITY_CLASSIFICATION_VALIDATION.md)
records the internal supplied-evidence model: exact authority/root/baseline/publication bindings,
nullable branch accounting, retained acceptance obligations and stopped-only outcomes.
All 119 focused Windows cases pass; the fresh full Windows regression passes 2,013 tests.
Formatting, strict docs and portability pass; Linux execution remains Docker-blocked. Next EP7-B specifies separate application-authority bytes/transitions
and provisioning/commit rules. No authority persistence, routing, work execution or public API
is implemented; existing host/store formats and all histories remain protected.

## Internal Embedded Pilot Authority Design (2026-10-29)

The user selected the internal embedded pilot. [ADR-028](docs/ADR-028-embedded-pilot-selection-and-work-authority.md)
and its [authority contract](docs/implementation/M2_EMBEDDED_PILOT_AUTHORITY_CONTRACT.md) define
separate selected-root/work accounting with acceptance before mutation, retained obligations
and stopped restart. This is design only; existing journal/store bytes and public APIs stay
unchanged. Next EP7-A is a pure supplied-evidence classifier with no I/O or write authority;
format, persistence and actual consuming-host execution remain later gates. The preceding
1,894-test Windows regression covers unchanged runtime, not this proposed backend.

## Post-EP6-D Readiness Review (2026-10-29)

The [current audit](docs/implementation/M2_POST_EP6_READINESS_REVIEW.md) reviews checkpoint `4598346` and confirms that the next gate is
a consuming-host selected-root/work-authority contract. Administrative operation drain and
publication reconciliation do not establish application selection or accepted-work accounting.
Fresh Windows full regression passes all 1,894 tests; Linux execution is blocked by the
unavailable Docker engine. Formatting, strict documentation and portability pass. Historical
RC/EP reports retain their original scope; no runtime/API/format or release gate changes here.

## About FYTALA

**FYTALA — Feeling Young, Thriving, Active, Learning Always** — is a personal initiative founded after retirement, driven by the belief that curiosity, enthusiasm, and learning have no age limit.

It is about staying engaged, exploring new ideas, and sharing the excitement of technology and innovation with others. A special ambition of FYTALA is to spark that enthusiasm in young people and encourage them to discover how fascinating technology can be—not just by talking about technology, but by making it visible, tangible, surprising, and fun.

My dream captures that ambition perfectly: **to walk into a classroom one day, side by side with a humanoid robot, and make my enthusiasm for technology and innovation contagious.**

If that experience inspires even a few young minds to start asking questions, experimenting, building, programming, or imagining what might be possible, FYTALA has achieved something worthwhile.

Technology, after all, is not just about machines, electronics, or software. It is about curiosity, creativity, and turning ideas into reality. FYTALA therefore takes a deliberately broad perspective, embracing software, electronics, engineering, science, artificial intelligence, robotics, and whatever comes next.

> Experimenting matters.
>
> Making mistakes matters.
>
> Understanding *why* something works matters even more.

Every project is an opportunity to learn something new and, hopefully, to help someone else learn as well.

The cable-stayed bridge in the FYTALA logo represents that philosophy. A bridge connects places, but it can also connect people, ideas, generations, and fields of knowledge. Its strength comes from many individual elements working together—much like technology itself.

FYTALA wants to help build those bridges: between experience and youthful curiosity, theory and practice, and imagination and real-world creation. It encourages looking beyond the obvious, asking questions, taking things apart, and building them again in new ways.

Above all, FYTALA is about keeping the desire to discover alive—and passing that desire on to the next generation.

> Because we never have to stop being curious.
>
> We never have to stop creating.
>
> And we are never too old—or too young—to learn something new.

---

## 1. Purpose and Current Status

## Host Restart Checkpoint (2026-10-29)

EP6-C is pushed as `5977451`; this checkpoint includes the completed EP6-D process tests and
documentation. All 1,055 focused cases passed per Windows/Linux platform (732 Storage,
323 Integration), including 72 new process cases. Formatting and strict documentation/portability
checks passed. No production source, public API, package pin or wire format changed in EP6-D.
Hosted run `40822530134` was blocked before runner execution by account payment/spending limits.

The [XDM 4.0 assessment](docs/implementation/M2_XDM40_COMPATIBILITY_ASSESSMENT.md)
records existing Bosak foundations and proposed provider qualification (REQ-009). It does not
claim full current-draft conformance or introduce persistent JSON/general XDM storage.

After restart, inspect `git status --short` and `git log -1`, then read this handover and
[EP6-D evidence](docs/implementation/M2_EMBEDDED_HOST_RESTART_PROCESS_VALIDATION.md).
Next: audit consuming-host selected-root authority and accepted-work accounting before adding
application integration. Reopened stores/host journals stay stopped; no automatic retry, route
change, writer resumption or reclamation is authorized by these tests. Proprietary licensing,
Bosak 1.26.2 pins and disabled packaging remain fixed. Earlier sections are historical step
records; this checkpoint supersedes their delivery status and next-action wording.

## EP6-D Restart/Retry Process Qualification (2026-10-29)

EP6-C is pushed as `5977451`. [EP6-D validation](docs/implementation/M2_EMBEDDED_HOST_RESTART_PROCESS_VALIDATION.md)
adds 72 actual process-kill cases across both roles at H=1, covering transfer, known/absent
outcomes, fresh retry intent and execution acknowledgment gaps. Reopen remains stopped;
separate reconciliation retains data and never recreates execution tickets. All 1,055 focused
cases pass per Windows/Linux platform. EP6-D is included in this restart checkpoint. Next audit the consuming application's selected-root/work-accounting gate;
production routing, writer resumption, public release and physical durability remain open.

## EP6-C Explicit Fresh-Plan Retry (2026-10-29)

EP6-A/B is pushed as `8d38762`. [EP6-C validation](docs/implementation/M2_EMBEDDED_HOST_RETRY_VALIDATION.md)
adds explicit retry preparation with a fresh real plan/attempt ID after exact qualified absence.
It retains request/pin/destination, reinspects before recording and uses an exact-position save
to exclude duplicate retry intents across fronts. 22 new cases cover success, changed facts,
concurrency and lost intent acknowledgment. All 983 focused cases pass per Windows/Linux platform.
EP6-C remains local/uncommitted. Next qualify
process termination across the combined restart/retry workflow; automatic retry/writer resume
and application routing remain disabled.

## EP6-B Stopped Restart Inspection (2026-10-29)

[EP6-B validation](docs/implementation/M2_EMBEDDED_HOST_RESTART_INSPECTION_VALIDATION.md)
adds actual pinned-operation inspection with acknowledged owner transfer and separate known
observation/qualified absence saves. Admissions stay closed; saved receipts cannot be synthesized
or replaced from inspection. 26 new Integration cases cover both roles/heads, contradictory
terminal facts and uncertain saves. All 961 focused cases pass on Windows and Linux.
Next: explicit fresh-plan retry after qualified absence;
retry runtime and process-kill qualification remain pending. EP6-A/B remain local/uncommitted.

## EP6-A Stopped Append Boundary (2026-10-29)

The EP6 contract is pushed as `22eeddf`. [EP6-A validation](docs/implementation/M2_EMBEDDED_HOST_STOPPED_APPEND_VALIDATION.md)
adds exclusive stopped-session registration and restricted transfer/observation/absence saves,
without opening administrative admissions. 25 new cases cover evidence, stale/foreign tokens,
concurrency, uncertainty and shutdown drain. All 935 focused cases pass on Windows and Linux.
Inspector composition, explicit fresh-plan retry
and process-kill qualification remain pending. EP6-A changes are local/uncommitted.

## EP6 Stopped Restart Design (2026-10-29)

EP4/EP5 is committed and pushed as `24feda2`. The [EP6 contract](docs/implementation/M2_EMBEDDED_HOST_RESTART_CONTRACT.md)
specifies a restricted reconciliation session with admissions closed, exact owner transfer,
separate known-operation observations and qualified absence before an explicit fresh-plan retry.
This is design only; restart persistence and retry runtime remain pending. Next implement the
stopped lifetime registration/append path and qualify its uncertainty and concurrency boundaries.
Existing 910 focused tests per platform remain the baseline; no new runtime coverage is claimed.
Hosted run `40793748444` could not start runner steps due to GitHub payment/spending limits.

## EP5 Live Plan-Bound Orchestration (2026-10-28)

[ADR-026](docs/ADR-026-live-plan-bound-embedded-orchestration.md) and
[validation](docs/implementation/M2_EMBEDDED_HOST_ORCHESTRATION_VALIDATION.md) add
opaque live tickets, exact acknowledged intent/authorization and one registered executor per
host. Actual receipts and host acknowledgments/errors remain separate; no saved plan is
reconstructed. 56 new cases qualify process gaps, duplicate use, active-attempt mutation and
shutdown; 910 focused cases pass per platform. Public metadata/wire formats stay unchanged.
Next: stopped persisted restart reconciliation and explicit new-ID retry after qualified
absence. HA2 application, global fencing, release and physical durability gates remain open.
EP4/EP5 was subsequently committed/pushed as `24feda2`; hosted CI remains billing-blocked.

## EP4 Owned Conditional Append (2026-10-28)

EP2/EP3 is committed/pushed as `4642b09`. [ADR-025](docs/ADR-025-owned-conditional-host-journal-append.md)
and [append validation](docs/implementation/M2_EMBEDDED_HOST_APPEND_VALIDATION.md)
now qualify exact-head append, actual file flush/readback and permanently faulted uncertain
sessions. 47 new cases cover write/flush failures, process interruption and test-only planned
publication composition; focused runs pass 854 cases per platform. Public Storage metadata
and wire formats stay unchanged. Reopened history remains stopped and never recreates a plan.
Next EP5 binds acknowledged ledger transitions to one registered live executor in an internal
orchestrator. HA2 application, release and physical durability gates remain open. EP4 is local.

## EP3 Explicit No-Overwrite Provisioning (2026-10-28)

[ADR-024](docs/ADR-024-explicit-no-overwrite-host-provisioning.md) and
[validation](docs/implementation/M2_EMBEDDED_HOST_PROVISIONING_VALIDATION.md) qualify
controlled absent-root creation, continuous CreateNew owner handoff and retained interrupted
state. 60 new tests cover partial writes, checkpoint/process kills and synchronized contenders;
807 focused cases pass per platform. Existing roots are never adopted or repaired by provision.
Reopened empty roots remain stopped; the live initializer diagnostic is not durable authority.
Next EP4 implements bounded conditional journal append and unknown-flush fault handling.
Physical durability, hostile namespace/global fencing, HA2 and release gates remain open.
Changes remain local/uncommitted; pushed baseline `2141eac` is unchanged.

## EP3 Existing Host Lifetime Ownership (2026-10-28)

[Ownership validation](docs/implementation/M2_EMBEDDED_HOST_OWNERSHIP_VALIDATION.md)
adds existing-root cooperative exclusion, stopped administrative admissions and token-drained
shutdown. 50 new catalog cases cover process exit/active drain, aliases, invalid roots and
real publisher lifetimes. Focused runs pass 747 cases per platform; three FIFO rows execute
only on Linux. Public Storage metadata remains unchanged. No host files are provisioned,
repaired or appended by this implementation, and no global fence or writer resume is implied.
Next: explicit no-overwrite provisioning and interruption/contender tests before EP4 append.
EP2/EP3 work remains local/uncommitted; the pushed baseline remains `2141eac`.

## EP2 Internal Journal Codec (2026-10-28)

[Codec validation](docs/implementation/M2_HOST_JOURNAL_CODEC_VALIDATION.md) now covers
strict bounded metadata/frame/TLV encoding, complete history checks and four independently
authored host-only vectors. 117 new codec cases pass; focused Windows/Linux runs pass 697
cases each. All 168 prior runtime/test/fixture files and public Storage metadata are unchanged.
Decoded history always keeps writers stopped; no codec output grants execution or proves
flush, anti-rollback or fencing. Next EP3 qualifies stable host-root lifetime ownership with
explicit provisioning boundaries and real process tests. EP4 durable append, HA2 application
integration and release gates remain open. EP2 design/codec changes remain local/uncommitted.

## Current Delivery and EP2 Journal Contract (2026-10-28)

The embedded profile is committed/pushed as `2141eac`. [ADR-023](docs/ADR-023-bounded-embedded-host-journal-contract.md)
and the [journal contract](docs/implementation/M2_EMBEDDED_HOST_JOURNAL_CONTRACT.md)
now define bounded canonical host-only frames, conditional transitions and explicit append/flush
uncertainty. Damaged tails are retained and block appends; restart never replays a plan.
No codec/writer, anti-rollback authority or durable-host proof is implemented. Next: a pure
internal codec with independent byte vectors, before filesystem persistence. This contract
is local/uncommitted; earlier delivery notes below retain their original scope.

## Current Delivery and Embedded Pilot Selection (2026-10-28)

RC2 through test-only HA1 integration is committed/pushed as `5d23ba2` on `origin/main`.
The user selected single-process embedded integration first. [ADR-022](docs/ADR-022-single-process-embedded-pilot-host.md)
and the [pilot profile](docs/implementation/M2_EMBEDDED_HOST_PROFILE.md) define one
controlled process, a dedicated host-state root, lifetime ownership and stopped restart
reconciliation. A local file journal is proposed; no backend or host is implemented yet.
Next EP2 defines its bounded codec, commit and corruption/rollback contract. M4 server,
HA2 application routing/work, public/archived-reader/release and retirement gates stay open.
This post-push profile is local; older uncommitted statements below describe their original
milestones. No runtime/test/fixture source changes or new runtime runs occur in this step.

## HA1 Ledger and Planned Execution Tests (2026-10-28)

[Test-only integration](docs/implementation/M2_HOST_LEDGER_PLANNED_EXECUTION_VALIDATION.md)
now connects memory-ledger intent/authorization/receipt transitions to real owner-bound
migration and restore. 34 new cases cover lost-save acknowledgments, actual publication
uncertainty, new-ID retry after reconciled absence, concurrent authorizers and an active
publisher that defeats absence-based retry. Focused runs pass 448 cases per platform.
All prior runtime/test/fixture files are unchanged; no production adapter is introduced.
The bounded model/library integration is complete. Next: identify the actual consuming host,
durable backend, effective publisher exclusion and route/work authorities before HA2.
No memory commit proves durability or fencing. Changes remain local and uncommitted.

## HA1 Conditional Transition Harness (2026-10-28)

The internal [in-memory transition harness](docs/implementation/M2_HOST_LEDGER_TRANSITION_VALIDATION.md)
now models exact-revision commits, single dispatch authorization, explicit read reconciliation
of lost acknowledgments and supplied-exclusion ownership transfer. 83 new tests cover commit
boundaries, concurrent winners, stale owners and preservation of receipts/observations;
414 focused cases pass per platform. Public Storage metadata remains unchanged.
No durable backend, executable permit, effective fence, routing or writer resume is supplied.
Next: test-only integration of these transitions with actual planned execution and lost-save
acknowledgments. Actual host selection and HA2 remain open; changes are uncommitted.

## HA1 Internal Ledger Model (2026-10-28)

The [ledger decision model](docs/implementation/M2_HOST_ATTEMPT_LEDGER_MODEL_VALIDATION.md)
now checks supplied request/attempt/revision/owner bindings, durable-intent assumptions,
publication/receipt identity and prior-executor exclusion. All 180 new model tests pass;
focused validation covers 331 cases per platform, retaining earlier full-suite evidence at
its original scope. Every output keeps writers stopped and grants no executable authority.
Actual host selection, persistence and HA2 integration remain open. Next: an internal
conditional-transition harness for revision/CAS and lost-acknowledgment protocol tests.
Changes remain local and uncommitted; proprietary licensing and release gates are unchanged.

## HA1 Host Ledger Contract (2026-10-28)

[ADR-021](docs/ADR-021-host-attempt-ledger-and-publisher-exclusion.md) and the
[host ledger contract](docs/implementation/M2_HOST_ATTEMPT_LEDGER_CONTRACT.md) define
durable intent before dispatch, revision-checked ownership, separate acknowledgment and
observation records, and prior-executor exclusion before any fresh attempt. A ledger lease
cannot fence the current publication path; an old publisher must be stopped or effectively
excluded before takeover/retry. The 24 design scenarios are requirements, not runtime tests.
Actual host selection and HA2 integration remain open. Next: an internal pure supplied-evidence
ledger decision model and adversarial tests. No persistent backend, routing, public API or
writer resume is enabled. RC2/RC3 and this contract remain local and uncommitted.

Earlier milestone notes below retain their dated scope; the HA1 next step above is current.

RC2 implementation (2026-10-28): [planned administrative execution](docs/implementation/M2_ADMINISTRATIVE_ATTEMPT_EXECUTION_VALIDATION.md) claims once, revalidates pinned intent before output and publishes the preknown ID in unchanged provenance fields. 31 new cases cover identity, early rejection and publication uncertainty. Next: RC3 process/restart and competing-publisher qualification; no public API or routing is enabled.

RC1 implementation (2026-10-28): [read-only preparation and single-dispatch state](docs/implementation/M2_ADMINISTRATIVE_ATTEMPT_PLAN_VALIDATION.md) add bound attempt descriptors and owner/policy checks with 28 new cases. Claim is a pure local primitive; pipeline execution remains deferred. Next: RC2 planned execution with exact preknown IDs and publication-outcome tests.

Administrative attempt design (2026-10-28): [ADR-020](docs/ADR-020-planned-administrative-attempt-correlation.md) and the [identity/retry contract](docs/implementation/M2_ADMINISTRATIVE_ATTEMPT_CONTRACT.md) define preknown library-created attempt IDs, single-use process-local plans and descriptor-only restart inspection. No runtime API or caller-ID parameter is implemented. Next: RC1 read-only prepare and plan ownership/concurrency tests.

Current review (2026-10-28): [consolidated regression and API readiness](docs/implementation/M2_CONSOLIDATED_API_READINESS_REVIEW.md) covers internal CA/HC/PA prototypes, fresh fault matrices, public metadata and documentation portability. Public mutable access, actual host routing, archived compatibility and release remain open. Next: request-to-publication operation correlation.

**Bosak.XmlDb** is a planned native XML database built on Bosak's existing
XPath/XQuery compiler, runtime and XDM interfaces. Logical XML documents will be
stored as independently loadable fragments so queries can navigate the parts they
need without parsing or loading the entire document.

The product uses **one storage engine in two hosting modes**: an embedded library
first, then a server and potentially distributed entity services. Both modes must
preserve the same physical format and query semantics. Embedded use must remain
independent of NATS, JetStream, Docker and Kubernetes.

**Implemented today: M1, experimental M2 transactions and internal epoch/administrative prototypes.** The embedded
provider supports immutable import/reopen, persistent XDM queries, and a single
text/ordinary-attribute replacement per transaction. An exclusive coordinator adds
optimistic conflicts, retained snapshot generations, a checksummed WAL and tested
process-crash recovery. Packaging remains disabled.

See [M2 status](M2_STATUS.md), the [crash matrix](docs/implementation/M2_CRASH_MATRIX.md)
and the historical [M1 measurements](benchmarks/m1/README.md). The checkout folder
remains `Bosal.XmlDb`; the canonical product is `Bosak.XmlDb`.

The retained ET9-D transaction/checkpoint/backup/epoch baseline passed **669 tests on Windows and 669 on Linux**.
Non-deleting checkpoints, optional verified checkpoint recovery and snapshot-owned
cross-process leases are implemented. Native Linux directory barriers were exercised
on Docker overlayfs with SDK 10.0.301. See [native durability validation](docs/implementation/M2_EPOCH_NATIVE_DURABILITY_VALIDATION.md)
and [ADR-006](docs/ADR-006-nondeleting-checkpoints-and-reader-leases.md).

All committed history remains retained. Physical power-loss certification, old-reader compatibility and fault-tested retirement remain open. Windows
continues to support the default ProcessCrash mode; directory mode is Linux-only.
The [compatibility and backup design](docs/ADR-008-reader-compatibility-backup-and-retirement.md)
now defines a separate-root format transition, fixed-sequence full-history backup and
restore, and retirement gates. The backup/restore slice is implemented in
[ADR-009](docs/ADR-009-verified-full-history-backup-and-restore.md); migration and
reclamation remain unimplemented.

## 2. First Deliverable: Immutable Persistent XML

M1 splits SalesOrder XML into header and line-group fragments, a persisted node
directory and a manifest. A snapshot-bound implementation of Bosak's existing
`IXdmNode` exposes the data without compiler or VM changes.

| Example XPath | Required M1 behavior |
|---------------|----------------------|
| `/SalesOrder/SalesOrderHeader/DocumentID` | Correct ID with zero line payload reads |
| `count(/SalesOrder/SalesOrderLine)` | Correct count, using directory metadata where possible |
| `/SalesOrder/SalesOrderLine[10]/Item/ItemID` | Correct ItemID; load only the needed line group |
| `/SalesOrder/SalesOrderLine[last()]/ancestor::SalesOrder` | Correct ancestry, positional semantics, identity and order |

These examples use an unnamespaced fixture; OAGIS fixtures require namespace-bound
expressions. M1 also requires cross-process reopen without parsing source XML,
corruption rejection, equivalent XML serialization and deterministic failure when
lazy results are enumerated after snapshot disposal.

Success means correctness and measured avoidance of unrelated payload I/O. No speed
advantage over in-memory XML is assumed. The initial scalar transaction path is now available; broader transactions, secondary indexes,
server APIs and replication remain future work.

## 3. Architecture and Project Boundaries

| Project | Planned responsibility | Current state |
|---------|------------------------|---------------|
| Core | Shared identities and snapshot/storage contracts | Implemented |
| Storage | Codecs, snapshots/cache, scalar transactions and WAL recovery | Implemented; references Core |
| Xdm | Persistent node adapter and evaluation integration | Implemented; references Core and Storage |
| Storage.Tests | Storage correctness and corruption suite | Implemented test suite |
| Xdm.Tests | Differential semantics and snapshot lifetime suite | Implemented test suite |

Bosak remains an independent upstream dependency. Preserve its remote
`Bosak.XPath.Providers.Database` connector for BaseX, eXist-db and MarkLogic.
Native resolution will compose with existing evaluation hooks rather than replacing
the remote connector. Bosak packages are pinned exactly to 1.26.2 with transitive lock files; see [ADR-003](docs/ADR-003-pinned-bosak-dependency.md).

See [architecture](docs/ARCHITECTURE.md) for storage, query and durability design,
and [roadmap](ROADMAP.md) for stages and acceptance gates.

## 4. Build and Verify

Requires .NET SDK **10.0.301**, NuGet access and PowerShell 7.

```sh
dotnet restore Bosak.XmlDb.slnx
dotnet build Bosak.XmlDb.slnx -c Release --no-restore
dotnet test Bosak.XmlDb.slnx -c Release --no-build
dotnet format Bosak.XmlDb.slnx --verify-no-changes --no-restore
pwsh tools/check-docs.ps1 -ProjectPath . -Strict
```

`pwsh tools/rebuild.ps1` performs a clean Release restore/build/test cycle. `pwsh tools/test-linux.ps1` runs the pinned SDK in an isolated Linux container using read-only source/cache inputs; see the validation report for prerequisites.
MinVer derives versions from Git tags; no release has been tagged. Windows/Linux CI
is configured. [M2_STATUS.md](M2_STATUS.md) records current evidence and warnings.
The suites cover format corruption, cache/disposal, XPath parity, all axes and cross-process reopen. Restore in CI uses --locked-mode.

## 5. Repository and Documentation

| Path | Contents |
|------|----------|
| `src/` | Core, Storage and Xdm |
| samples/EmbeddedQuickstart | Import, read and benchmark CLI |
| `tests/` | Storage, Xdm and process integration tests; shared TestData |
| `docs/` | Canonical docs, original designs, ADRs and fixture plan |
| `tools/` | Rebuild and FYTALA hygiene verification |
| `.github/workflows/build.yml` | Windows/Linux build, tests, formatting and hygiene |
| `assets/`, `docs-kit/` | FYTALA rendering assets and governed manifest |

Read the supplied sources in this order:

1. [Agent handover v0.1](docs/Bosak_XmlDb_Agent_Handover_v0.1.md): assignment and constraints.
2. [M1 plan v0.2](docs/Bosak_M1_Persistent_Fragment_Provider_Implementation_Plan_v0.2.md): authoritative M0/M1 scope and acceptance.
3. [Technical design v0.3](docs/Bosak_Native_XML_Storage_Engine_Technical_Design_v0.3.md): longer-term proposals and resilience design.

Maintained references include [integration](docs/INTEGRATION.md),
[feature requests](docs/FEATURE_REQUESTS.md), [current handover](docs/AGENT_HANDOVER.md),
[repository ADR](docs/ADR-001-repository-and-hosting.md) and
[fixture plan](docs/implementation/FIXTURE_PLAN.md).

## 6. Update and Reopen Example

Use a new store path for import:

```sh
dotnet run --project samples/EmbeddedQuickstart -c Release -- import order-store 20
dotnet run --project samples/EmbeddedQuickstart -c Release -- update order-store SO-2
dotnet run --project samples/EmbeddedQuickstart -c Release -- checkpoint order-store
dotnet run --project samples/EmbeddedQuickstart -c Release -- read-checkpoint order-store
```

The last command returns SO-2 at commit sequence 1 with twenty lines and reports checkpoint selection. FullJournal remains the default for ordinary read/Open calls. After adopting
a store for transactions, open it through EmbeddedXmlDatabase and BeginRead so recovery
and generation selection occur. See [integration](docs/INTEGRATION.md) and [ADR-004](docs/ADR-004-embedded-scalar-transactions.md).

## 7. Open Decisions

The project uses the proprietary Fytala license in [LICENSE.md](LICENSE.md), matching
Bosak.Braid. Bosak 1.26.2 uses Apache-2.0; see [notices](THIRD-PARTY-NOTICES.md).
The archive baseline in the original plan is historical; the selected packages record
commit 6a3372fc3b91e733b71a426cf40f26feaaeb3bcb, verified in upstream Git.

M1 stores one immutable document per root, imports through a bounded in-memory
XDocument and supports untyped XML 1.0 without DTDs. Keep snapshots alive and use
BindResult for evaluator-owned lazy results; see [integration](docs/INTEGRATION.md).
The scalar transaction slice supports process-crash recovery. It does not support structural edits, reclamation, server/distributed operation or a tested power-loss guarantee.
Linux CI and visual renderer acceptance have not executed here. Later durability,
fencing, failover, migrations and performance targets still require evidence.



(c) Fytala. All rights reserved.

## Recovery Descriptors and Retention Inventory

Implemented in [ADR-007](docs/ADR-007-recovery-descriptors-and-retention-inventory.md):
`CreateRecoveryAnchor()` publishes an immutable descriptor after a verified complete
checkpoint. Publish at separate commits to retain independent older recovery copies.
`PreferCheckpoint` tries canonical descriptors newest-first when CHECKPOINT is invalid
or absent; every retained WAL record and selected prefix must still validate.
`PlanRetention()` reports file dependencies and selected-root files without mutation.
Its `CanReclaim` is always false: older readers, base compatibility, stable lease
identities and full WAL history remain protected. The report is a point-in-time
inventory, not a backup or permission to delete files. The compatibility transition and backup/retirement protocol are now specified in
ADR-008 (design only). Verified full-history backup/restore is now implemented per ADR-009; migration and
reclamation remain disabled.



## Verified Full-History Backup and Restore

```powershell
dotnet run --project samples/EmbeddedQuickstart -c Release -- backup ./order-store ./order-backup
dotnet run --project samples/EmbeddedQuickstart -c Release -- restore ./order-backup ./restored-order
```

Use new destinations beneath existing parents. Capture blocks writes at one sequence;
restore verifies full history before publishing an independently writable store. It
retains source history and omits process locks and optional checkpoints. Existing,
linked and overlapping destinations are refused. After an I/O error, reopen the owner
and use a fresh destination. See [native durability validation](docs/implementation/M2_EPOCH_NATIVE_DURABILITY_VALIDATION.md).



## Internal Epoch Compatibility and Admission

[ADR-010](docs/ADR-010-mandatory-epoch-format-and-admission-primitives.md) implements
mandatory-major-2 metadata and stable shared/exclusive admission tokens in isolated
metadata-only roots. Frozen format-1 reader binaries reject those roots before writes.
A separate read-only epoch data API is now implemented in ADR-011. Legacy entry points
remain format-1-only; data migration and deletion are not enabled. Broader archived-reader
compatibility remains pending.



## Read-Only Epoch Data

```csharp
using var store = ReadOnlyEpochDatabase.Open(preparedEpochRoot);
using var snapshot = store.BeginRead(cacheBytes: 0);
var document = new PersistentXdmNode(snapshot);
```

Snapshots retain their own shared admission after store disposal. The sample command
`read-epoch <prepared-root>` queries header/line count without line payload reads. Only
complete immutable sequence-zero roots are supported. Preparation is currently internal
test infrastructure, not a public importer or migration path. Public epoch transactions,
redo/backups and history reclamation remain unimplemented. See
[ADR-011](docs/ADR-011-admission-owned-read-only-epoch-snapshots.md).



## Mutable Epoch Codec Status

[ADR-013](docs/ADR-013-epoch-profile-and-authority-codecs.md) implements ET1-ET3: explicit
2.0/2.1 profile parsing, bounded epoch-bound authority codecs, independent fixtures and
frozen-reader rejection. Existing public APIs still refuse mutable profile 2.1; parsing
it grants no admission or write capability. ADR-014 adds internal empty-chain ownership;
[ADR-015](docs/ADR-015-internal-scalar-epoch-commit.md) adds internal one-scalar staging,
stale validation and commit. [ADR-016](docs/ADR-016-internal-epoch-redo-and-publication-faults.md)
adds deterministic missing-generation redo and narrowly witnessed incomplete-tail recovery,
with commit/recovery fault sweeps and repeated process kills. Old uncached snapshots retain
their values and handles. Public mutable APIs, epoch backup/migration and reclamation remain
pending. ET7 now qualifies adversarial classification and multi-generation interrupted redo;
corrupt published state fails closed. ET8 now adds faults around actual Linux durability
operations and explicit Windows policy rejection.
[ADR-017](docs/ADR-017-epoch-full-history-backup-and-independent-restore.md) now defines ET9
fixed-head backup and fresh-identity restore bundles. ET9-A now implements pure bounded
BXEI/BXEZ/BXEO metadata codecs with [independent fixtures](docs/implementation/M2_EPOCH_BACKUP_CODEC_VALIDATION.md).
ET9-B now adds internal [fixed-H capture](docs/implementation/M2_EPOCH_BACKUP_CAPTURE.md),
exact file closure and both complete-data/full-WAL-redo verification oracles. Source history
and old readers remain intact. ET9-C now adds internal [independent restore](docs/implementation/M2_EPOCH_BACKUP_RESTORE.md),
fresh store/epoch identities and atomic store/provenance bundles. Public APIs remain unavailable.
ET9-D fault and interruption qualification is now implemented; next: MG2 legacy verification.
See the [recovery contract](docs/implementation/M2_EPOCH_RECOVERY.md) and
[native durability validation](docs/implementation/M2_EPOCH_NATIVE_DURABILITY_VALIDATION.md).

*Last updated: 2026-10-30*


ET9-D qualification update (2026-10-27): capture/restore persistence sweeps now enumerate
every observed before/after call and actual partial-write position on a one-commit history.
Process-crash and modeled strong ordering are separate from actual native Linux delegation.
Repeated process interruption covers private publication windows, published outcomes and
acknowledgment loss. Source/backup bytes, historical reads, provenance and released handles
are checked. See [fault qualification](docs/implementation/M2_EPOCH_BACKUP_FAULT_VALIDATION.md).
Full-history migration/cutover acceptance is now specified by ADR-018; runtime implementation remains pending. Public mutable APIs, source replacement and history reclamation remain disabled.


Migration/cutover design update (2026-10-27): [ADR-018](docs/ADR-018-full-history-legacy-migration-and-cutover.md)
now specifies internal conversion of a sealed format-1 full-history backup into a fresh
ScalarWal 2.1 bundle. [Acceptance criteria](docs/implementation/M2_EPOCH_MIGRATION_DESIGN.md)
require complete-history and full-redo verification on both sides, exact sequence/data
parity, separate migration provenance and explicit operator-controlled cutover. The
converter never opens the live legacy root. Source paths/history are retained; cutover
requires a write freeze and source/candidate freshness checks. No runtime migration,
routing API or retirement is implemented. MG1 codecs/fixtures are now implemented; next: MG2 legacy verification. The design-only step retained the 669-case runtime baseline; the MG1 update below records
fresh codec/regression coverage separately, without claiming runtime migration proof.


MG1 implementation update (2026-10-27): internal EpochMigrationCodec now encodes the
separate 350-byte BXEM 1.0 migration-origin role, frozen with independent H0/H2 vectors in
[the byte contract](docs/implementation/M2_EPOCH_MIGRATION_FORMAT_V1.md). Pure
source/destination header checks preserve legacy H0 CURRENT omission and reject malformed
bounds and substituted commitments. They perform no I/O and grant no closure/history,
admission, migration or cutover capability. See [validation](docs/implementation/M2_EPOCH_MIGRATION_CODEC_VALIDATION.md).
MG2 legacy verification is now implemented; next: MG3 conversion and verified bundle publication.
No runtime converter, routing API, source replacement or retirement is enabled.


MG2 implementation update (2026-10-27): internal [LegacyMigrationVerifier](docs/implementation/M2_LEGACY_MIGRATION_VERIFICATION.md)
now validates sealed legacy closure, every scalar transition and exact fixed-H authority
before workspace writes, then verifies complete and independent full-WAL-redo clones.
Only private clones can initialize runtime files or republish byte-identical CURRENT;
sealed input and live source roots are not recovered or rewritten. No destination store
is published. [Validation](docs/implementation/M2_LEGACY_MIGRATION_VERIFICATION_VALIDATION.md)
distinguishes 33 new cases/738 fresh filtered regressions per platform from retained ET9-D
evidence. MG3 internal conversion is implemented; next: MG4 exhaustive fault qualification.
Public migration/mutable APIs, cutover and retirement remain disabled.


MG3 implementation update (2026-10-27): internal [EpochLegacyMigration](docs/implementation/M2_EPOCH_MIGRATION_CONVERSION.md)
now verifies sealed legacy full history through MG2, assigns fresh epoch identity and
re-encodes every authority/WAL link while preserving H, transaction/document/node IDs and
XML data bytes. Both destination history oracles and fresh runtime/provenance checks must
pass before atomic store/ plus migration.bin bundle publication; staging handles close first.
Source paths/artifact stay intact. [Validation](docs/implementation/M2_EPOCH_MIGRATION_CONVERSION_VALIDATION.md)
records 27 new Storage and six process cases with 771 fresh filtered regressions per platform,
separately retaining the unchanged 18-case ET9-D matrix. MG4 observed fault/native/process qualification is now recorded. Public APIs, actual cutover and retirement stay disabled.


MG4 qualification update (2026-10-27): [conversion fault evidence](docs/implementation/M2_EPOCH_MIGRATION_FAULT_VALIDATION.md)
now covers every observed H=1 persistence call before/after and actual partial writes,
with immutable input and valid/absent publication checks. Process probes repeat 12 windows
three times per supported policy, including private legacy copy/redo, epoch redo and ACK
loss, with actual native Linux delegation separate from modeled ordering. Production
algorithms and bytes are unchanged. Fresh regressions cover 798 cases per platform, with
18 unchanged ET9-D cases retained separately. Next: MG5 source/candidate freshness and
explicit cutover/rollback acceptance harness. Public APIs, routing service, source
replacement and all retirement remain disabled.


MG5 acceptance update (2026-10-27): [internal cutover harness](docs/implementation/M2_MIGRATION_CUTOVER_ACCEPTANCE.md)
now freezes cooperating mutations, registers capture under that freeze, and revalidates
exact source/candidate commitments for session-bound single-use routing observations.
It models known/uncertain outcomes and verified no-work return versus reconciliation,
without changing any route/configuration or store path. [Validation](docs/implementation/M2_MIGRATION_CUTOVER_ACCEPTANCE_VALIDATION.md)
records 32 Storage/two process cases and 823 fresh filtered regressions per platform, with
27 unchanged fault-matrix cases retained separately. MG1-MG5 are internal prototype gates;
next: compatibility/release-readiness evidence audit. Archived-reader gaps, public API/
shipping qualification and retirement remain open; all source data stays retained.


Compatibility audit (2026-10-28): [release-readiness evidence](docs/implementation/M2_RELEASE_READINESS_AUDIT.md) verifies both frozen local reader families and records C1-C3 gaps. No shipping gate is closed. Next: CA1 rejection/nonmutation coverage for actual published migration bundles and every nested generation; archived release provenance remains unavailable locally.


CA1 update (2026-10-28): [real migrated-bundle compatibility validation](docs/implementation/M2_MIGRATED_BUNDLE_COMPATIBILITY_VALIDATION.md) adds 12 local frozen/current rejection cases for H0/H3 wrapper, store and every generation, including exact file/directory and runtime identity preservation. Complete archived C1 and actual routing remain open. Next: CA2 migrated-candidate child/owner disposal races and cross-process lifetime checks.


CA2 update (2026-10-28): [migrated ownership validation](docs/implementation/M2_MIGRATED_OWNERSHIP_VALIDATION.md) adds 12 repeated child/owner race cases and four cross-process holder-release cases. Local ownership proof is stronger; archived compatibility, actual routing and shipping remain open. Next: define supported public API and host cutover/restart contracts before implementing real routing.


API/host contract design (2026-10-28): [ADR-019](docs/ADR-019-explicit-mutable-api-and-host-cutover-boundary.md) and the [contract](docs/implementation/M2_PUBLIC_API_AND_HOST_CUTOVER_CONTRACT.md) separate explicit mutable access from host-owned writer exclusion, revision-checked routing and restart reconciliation. Proposed names are not public APIs; no host adapter or durable routing record is implemented. Next: HC1 pure restart/reconciliation classifier. Archived compatibility and release gates remain open.


HC1 update (2026-10-28): [pure restart classification](docs/implementation/M2_RESTART_CLASSIFICATION_VALIDATION.md) adds internal supplied-observation decisions and 79 Storage cases. Every result keeps writers stopped, including new-workflow eligibility; no host observation, route change or durable receipt is created. Next: PA1 explicit mutable facade prototype and ownership/profile/diagnostic tests, remaining internal until release gates pass.


PA1 prototype update (2026-10-28): [internal mutable facade](docs/implementation/M2_SCALAR_EPOCH_FACADE_VALIDATION.md) wraps explicit options, independent snapshots/transactions, scalar commits and fixed-head backup. An optional expected identity rejects before admission/recovery. 22 new internal consumer cases preserve diagnostics and uncertainty semantics; public exposure remains disabled. Next: PA2 separate administrative facade prototype and publication-outcome tests.


PA2 prototype update (2026-10-28): [separate administration facade](docs/implementation/M2_SCALAR_EPOCH_ADMINISTRATION_VALIDATION.md) adds sealed legacy/epoch verification and independent restore/migration receipts. 29 new cases cover bound results, input preservation, strict proof and publication uncertainty. No public API or automatic routing/retry is enabled. Next: PA3 read-only publication inspection and reconciliation observations.


PA3 update (2026-10-28): [read-only publication inspection](docs/implementation/M2_PUBLICATION_INSPECTION_VALIDATION.md) adds pinned-artifact and optional known-operation correlation, with reconciliation for changed/incomplete inputs and no adoption/recovery. 43 new cases preserve bytes/runtime identities; every observation keeps writers stopped. Next: consolidated cross-platform regression and API/readiness review. Public/host/archive/release gates remain open.


## RC3 Process and Contention Qualification (2026-10-28)

RC3 now qualifies preannounced IDs across publisher process death, independent plans racing
one destination and concurrent dispatch of one plan. See [validation](docs/implementation/M2_ADMINISTRATIVE_ATTEMPT_PROCESS_VALIDATION.md).
The focused Windows/Linux runs cover 71 cases each, including 12 new RC3 cases; prior
full-suite evidence retains its dated scope. This supersedes earlier “next RC3” statements.
RC2/RC3 remain local; a3b578c contains work through RC1. No public API, host routing,
durable replay, source replacement or reclamation is enabled. Next HA1 defines the host
attempt-ledger and fencing contract; local inspection alone never authorizes retry.
