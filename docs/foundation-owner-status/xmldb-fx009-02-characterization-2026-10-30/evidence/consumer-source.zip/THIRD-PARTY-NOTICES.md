# Third-Party Notices

Bosak.XmlDb is proprietary Fytala software; see LICENSE.md. This does not change
licenses of its dependencies.

Bosak XPath packages 1.26.2 are Copyright (c) 2026 FYTALA and licensed under
Apache License 2.0, as recorded in their NuGet metadata and bundled license.
See [Bosak license](licenses/Bosak.Apache-2.0.md). Package metadata records source
commit 6a3372fc3b91e733b71a426cf40f26feaaeb3bcb, verified to exist in the local
upstream Git repository. No upstream source has been copied into this implementation
or modified. Test and build dependencies retain their own package licenses.

*Last updated: 2026-10-26*
