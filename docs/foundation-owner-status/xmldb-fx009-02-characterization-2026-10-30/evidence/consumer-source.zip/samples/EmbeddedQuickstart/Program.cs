// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Demonstrates immutable import, reopen and query measurements.
// SPECIAL NOTES        : Immutable M1 format; no transaction or crash recovery guarantee.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      | Charles Korthout | 0.2   | 26-10-2026     | Add scalar update and transactional read example
//                      | Charles Korthout | 0.3   | 26-10-2026     | Demonstrate checkpoint publication and recovery statistics
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.4   | 27-10-2026     | Add verified full-history backup and restore commands
//                      | Charles Korthout | 0.5   | 27-10-2026     | Demonstrate admission-owned read-only epoch queries
// ===========================================================================================================================================================

using System.Diagnostics;
using System.Text;
using System.Text.Json;
using System.Xml.Linq;
using Bosak.XmlDb.Storage;
using Bosak.XmlDb.Xdm;
using Bosak.XPath.Api;
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Providers.Xml;

namespace Bosak.XmlDb.Samples;

internal static class Program
{
    private static int Main(string[] args)
    {
        if (args.Length < 2)
        {
            Console.Error.WriteLine("Usage: import|read|read-epoch|read-checkpoint|checkpoint|backup|restore|update|benchmark <store-path> [line-count|replacement-value|destination]");
            return 2;
        }
        if (args[0] is "backup" or "restore")
        {
            if (args.Length != 3) return 2;
            if (args[0] == "restore") Console.WriteLine(JsonSerializer.Serialize(EmbeddedXmlDatabase.RestoreBackup(args[1], args[2])));
            else
            {
                using var owner = EmbeddedXmlDatabase.Open(args[1]);
                Console.WriteLine(JsonSerializer.Serialize(owner.CreateBackup(args[2])));
            }
            return 0;
        }
        if (args[0] == "read-epoch")
        {
            using var store = ReadOnlyEpochDatabase.Open(args[1]);
            using var snapshot = store.BeginRead();
            var node = new PersistentXdmNode(snapshot);
            var header = XPath31Expression.Compile("string(/SalesOrder/SalesOrderHeader/DocumentID)").Evaluate(node).StringValue;
            var lines = XPath31Expression.Compile("count(/SalesOrder/SalesOrderLine)").Evaluate(node).IntegerValue;
            Console.WriteLine(JsonSerializer.Serialize(new { store.StoreId, store.EpochId, store.DocumentId, Header = header, Lines = lines, snapshot.CommitSequence, snapshot.Metrics }));
            return 0;
        }
        var count = args[0] is "import" or "benchmark" && args.Length > 2 ? int.Parse(args[2], System.Globalization.CultureInfo.InvariantCulture) : 500;
        if (args[0] == "import")
        {
            using var input = new MemoryStream(Encoding.UTF8.GetBytes(Generate(count)));
            XmlFragmentImporter.Import(input, args[1], linesPerFragment: 16, documentUri: "https://example.test/order.xml");
            return 0;
        }
        if (args[0] is "read" or "read-checkpoint")
        {
            using var database = Directory.Exists(Path.Combine(args[1], ".transactions"))
                ? EmbeddedXmlDatabase.Open(args[1], args[0] == "read-checkpoint" ? RecoveryMode.PreferCheckpoint : RecoveryMode.FullJournal) : null;
            using var snapshot = database is null ? ImmutableXmlSnapshot.Open(args[1]) : database.BeginRead();
            var node = new PersistentXdmNode(snapshot);
            var header = XPath31Expression.Compile("string(/SalesOrder/SalesOrderHeader/DocumentID)").Evaluate(node).StringValue;
            var lines = XPath31Expression.Compile("count(/SalesOrder/SalesOrderLine)").Evaluate(node).IntegerValue;
            Console.WriteLine(JsonSerializer.Serialize(new { Header = header, Lines = lines, snapshot.CommitSequence, snapshot.Metrics, snapshot.DirectoryBytes, Recovery = database?.LastRecovery }));
            return 0;
        }
        if (args[0] == "checkpoint")
        {
            using var database = EmbeddedXmlDatabase.Open(args[1]);
            Console.WriteLine(JsonSerializer.Serialize(new { CheckpointSequence = database.CreateCheckpoint() }));
            return 0;
        }
        if (args[0] == "update")
        {
            if (args.Length != 3) return 2;
            using var database = EmbeddedXmlDatabase.Open(args[1]);
            using var read = database.BeginRead();
            var element = Enumerable.Range(1, read.NodeCount).Select(id => read.GetNode((ulong)id))
                .Single(node => node.Kind == Bosak.XmlDb.Core.StorageNodeKind.Element && node.LocalName == "DocumentID");
            using var transaction = database.BeginWrite();
            transaction.ReplaceNodeValue(element.Children.Single(), args[2]);
            Console.WriteLine(JsonSerializer.Serialize(new { CommitSequence = transaction.Commit() }));
            return 0;
        }
        if (args[0] != "benchmark") return 2;
        Benchmark(args[1], count);
        return 0;
    }

    private static string Generate(int count) => "<SalesOrder><SalesOrderHeader><DocumentID>SO-1</DocumentID></SalesOrderHeader>" +
        string.Concat(Enumerable.Range(1, count).Select(i => $"<SalesOrderLine number='{i}'><Item><ItemID>{i}</ItemID></Item></SalesOrderLine>")) + "</SalesOrder>";

    private static void Benchmark(string root, int count)
    {
        const int repetitions = 100;
        var xml = Generate(count);
        using (var input = new MemoryStream(Encoding.UTF8.GetBytes(xml)))
            XmlFragmentImporter.Import(input, root, linesPerFragment: 16);
        var memory = XDocument.Parse(xml).ToXdmNode();
        var before = GC.GetTotalMemory(true);
        var allocated = GC.GetAllocatedBytesForCurrentThread();
        using var resident = ImmutableXmlSnapshot.Open(root);
        var openAllocated = GC.GetAllocatedBytesForCurrentThread() - allocated;
        var retained = GC.GetTotalMemory(true) - before;
        Console.WriteLine(JsonSerializer.Serialize(new
        {
            Environment = System.Runtime.InteropServices.RuntimeInformation.OSDescription,
            Runtime = Environment.Version.ToString(),
            Count = count,
            Repetitions = repetitions,
            resident.NodeCount,
            resident.DirectoryBytes,
            OpenAllocatedBytes = openAllocated,
            ApproximateRetainedSnapshotBytes = retained,
            Note = "Query-only timings; fresh snapshot excludes metadata open. OS cache is not flushed. Retained memory is a GC estimate.",
        }));
        foreach (var query in new[]
        {
            "string(/SalesOrder/SalesOrderHeader/DocumentID)",
            "count(/SalesOrder/SalesOrderLine)",
            "string(/SalesOrder/SalesOrderLine[10]/Item/ItemID)",
        })
        {
            var expression = XPath31Expression.Compile(query);
            for (var i = 0; i < 10; i++) _ = expression.Evaluate(memory);
            Measure("in-memory", query, repetitions, () => expression.Evaluate(memory), null);
            using var warm = ImmutableXmlSnapshot.Open(root);
            var warmNode = new PersistentXdmNode(warm);
            _ = expression.Evaluate(warmNode);
            Measure("warm-fragment-cache", query, repetitions, () => expression.Evaluate(warmNode), () => warm.Metrics);
            var samples = new List<double>();
            long allocations = 0;
            long reads = 0, bytes = 0, headerReads = 0, lineReads = 0, hits = 0;
            for (var i = 0; i < repetitions; i++)
            {
                using var fresh = ImmutableXmlSnapshot.Open(root);
                var node = new PersistentXdmNode(fresh);
                var startAllocation = GC.GetAllocatedBytesForCurrentThread();
                var start = Stopwatch.GetTimestamp();
                _ = expression.Evaluate(node);
                samples.Add(Stopwatch.GetElapsedTime(start).TotalMicroseconds);
                allocations += GC.GetAllocatedBytesForCurrentThread() - startAllocation;
                var metrics = fresh.Metrics;
                reads += metrics.PhysicalFragmentReads;
                bytes += metrics.BytesRead;
                headerReads += metrics.HeaderFragmentReads;
                lineReads += metrics.LineFragmentReads;
                hits += metrics.CacheHits;
            }
            Report("fresh-fragment-cache", query, samples, allocations,
                new { PhysicalFragmentReads = reads, BytesRead = bytes, HeaderFragmentReads = headerReads, LineFragmentReads = lineReads, CacheHits = hits });
        }
    }

    private static void Measure(string mode, string query, int count, Func<XdmValue> evaluate, Func<object>? metrics)
    {
        var samples = new List<double>();
        var allocations = GC.GetAllocatedBytesForCurrentThread();
        for (var i = 0; i < count; i++)
        {
            var start = Stopwatch.GetTimestamp();
            _ = evaluate();
            samples.Add(Stopwatch.GetElapsedTime(start).TotalMicroseconds);
        }
        allocations = GC.GetAllocatedBytesForCurrentThread() - allocations;
        Report(mode, query, samples, allocations, metrics?.Invoke());
    }

    private static void Report(string mode, string query, List<double> samples, long allocations, object? metrics)
    {
        samples.Sort();
        double Percentile(double fraction) => samples[(int)Math.Ceiling(samples.Count * fraction) - 1];
        Console.WriteLine(JsonSerializer.Serialize(new
        {
            Mode = mode,
            Query = query,
            P50Microseconds = Percentile(.50),
            P95Microseconds = Percentile(.95),
            P99Microseconds = Percentile(.99),
            MeanAllocatedBytes = allocations / samples.Count,
            Metrics = metrics,
        }));
    }
}


