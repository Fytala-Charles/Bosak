# Bosak.XmlDb Agent Handover

## Host Restart Checkpoint (2026-10-29)

EP6-C is pushed as `5977451`; this checkpoint includes the completed EP6-D process tests and
documentation. All 1,055 focused cases passed per Windows/Linux platform (732 Storage,
323 Integration), including 72 new process cases. Formatting and strict documentation/portability
checks passed. No production source, public API, package pin or wire format changed in EP6-D.
Hosted run `40822530134` was blocked before runner execution by account payment/spending limits.

The [XDM 4.0 assessment](../docs/implementation/M2_XDM40_COMPATIBILITY_ASSESSMENT.md)
records existing Bosak foundations and proposed provider qualification (REQ-009). It does not
claim full current-draft conformance or introduce persistent JSON/general XDM storage.

After restart, inspect `git status --short` and `git log -1`, then read this handover and
[EP6-D evidence](../docs/implementation/M2_EMBEDDED_HOST_RESTART_PROCESS_VALIDATION.md).
Next: audit consuming-host selected-root authority and accepted-work accounting before adding
application integration. Reopened stores/host journals stay stopped; no automatic retry, route
change, writer resumption or reclamation is authorized by these tests. Proprietary licensing,
Bosak 1.26.2 pins and disabled packaging remain fixed. Earlier sections are historical step
records; this checkpoint supersedes their delivery status and next-action wording.

## EP6-D Restart/Retry Process Qualification (2026-10-29)

EP6-C is pushed as `5977451`. [EP6-D validation](../docs/implementation/M2_EMBEDDED_HOST_RESTART_PROCESS_VALIDATION.md)
adds 72 actual process-kill cases across both roles at H=1, covering transfer, known/absent
outcomes, fresh retry intent and execution acknowledgment gaps. Reopen remains stopped;
separate reconciliation retains data and never recreates execution tickets. All 1,055 focused
cases pass per Windows/Linux platform. EP6-D is included in this restart checkpoint. Next audit the consuming application's selected-root/work-accounting gate;
production routing, writer resumption, public release and physical durability remain open.

## EP6-C Explicit Fresh-Plan Retry (2026-10-29)

EP6-A/B is pushed as `8d38762`. [EP6-C validation](../docs/implementation/M2_EMBEDDED_HOST_RETRY_VALIDATION.md)
adds explicit retry preparation with a fresh real plan/attempt ID after exact qualified absence.
It retains request/pin/destination, reinspects before recording and uses an exact-position save
to exclude duplicate retry intents across fronts. 22 new cases cover success, changed facts,
concurrency and lost intent acknowledgment. All 983 focused cases pass per Windows/Linux platform.
EP6-C remains local/uncommitted. Next qualify
process termination across the combined restart/retry workflow; automatic retry/writer resume
and application routing remain disabled.

## EP6-B Stopped Restart Inspection (2026-10-29)

[EP6-B validation](../docs/implementation/M2_EMBEDDED_HOST_RESTART_INSPECTION_VALIDATION.md)
adds actual pinned-operation inspection with acknowledged owner transfer and separate known
observation/qualified absence saves. Admissions stay closed; saved receipts cannot be synthesized
or replaced from inspection. 26 new Integration cases cover both roles/heads, contradictory
terminal facts and uncertain saves. All 961 focused cases pass on Windows and Linux.
Next: explicit fresh-plan retry after qualified absence;
retry runtime and process-kill qualification remain pending. EP6-A/B remain local/uncommitted.

## EP6-A Stopped Append Boundary (2026-10-29)

The EP6 contract is pushed as `22eeddf`. [EP6-A validation](../docs/implementation/M2_EMBEDDED_HOST_STOPPED_APPEND_VALIDATION.md)
adds exclusive stopped-session registration and restricted transfer/observation/absence saves,
without opening administrative admissions. 25 new cases cover evidence, stale/foreign tokens,
concurrency, uncertainty and shutdown drain. All 935 focused cases pass on Windows and Linux.
Inspector composition, explicit fresh-plan retry
and process-kill qualification remain pending. EP6-A changes are local/uncommitted.

## EP6 Stopped Restart Design (2026-10-29)

EP4/EP5 is committed and pushed as `24feda2`. The [EP6 contract](../docs/implementation/M2_EMBEDDED_HOST_RESTART_CONTRACT.md)
specifies a restricted reconciliation session with admissions closed, exact owner transfer,
separate known-operation observations and qualified absence before an explicit fresh-plan retry.
This is design only; restart persistence and retry runtime remain pending. Next implement the
stopped lifetime registration/append path and qualify its uncertainty and concurrency boundaries.
Existing 910 focused tests per platform remain the baseline; no new runtime coverage is claimed.
Hosted run `40793748444` could not start runner steps due to GitHub payment/spending limits.

## EP5 Live Plan-Bound Orchestration (2026-10-28)

[ADR-026](../docs/ADR-026-live-plan-bound-embedded-orchestration.md) and
[validation](../docs/implementation/M2_EMBEDDED_HOST_ORCHESTRATION_VALIDATION.md) add
opaque live tickets, exact acknowledged intent/authorization and one registered executor per
host. Actual receipts and host acknowledgments/errors remain separate; no saved plan is
reconstructed. 56 new cases qualify process gaps, duplicate use, active-attempt mutation and
shutdown; 910 focused cases pass per platform. Public metadata/wire formats stay unchanged.
Next: stopped persisted restart reconciliation and explicit new-ID retry after qualified
absence. HA2 application, global fencing, release and physical durability gates remain open.
EP4/EP5 was subsequently committed/pushed as `24feda2`; hosted CI remains billing-blocked.

## EP4 Owned Conditional Append (2026-10-28)

Pushed-baseline CI run 40771851255 did not start build/tests because GitHub account payment/
spending limits blocked both jobs. Local EP4 validation is separate; account-owner action is
needed for hosted runners. No billing/settings change or automatic rerun was made.

EP2/EP3 is committed/pushed as `4642b09`. [ADR-025](../docs/ADR-025-owned-conditional-host-journal-append.md)
and [append validation](../docs/implementation/M2_EMBEDDED_HOST_APPEND_VALIDATION.md)
now qualify exact-head append, actual file flush/readback and permanently faulted uncertain
sessions. 47 new cases cover write/flush failures, process interruption and test-only planned
publication composition; focused runs pass 854 cases per platform. Public Storage metadata
and wire formats stay unchanged. Reopened history remains stopped and never recreates a plan.
Next EP5 binds acknowledged ledger transitions to one registered live executor in an internal
orchestrator. HA2 application, release and physical durability gates remain open. EP4 is local.

## EP3 Explicit No-Overwrite Provisioning (2026-10-28)

[ADR-024](../docs/ADR-024-explicit-no-overwrite-host-provisioning.md) and
[validation](../docs/implementation/M2_EMBEDDED_HOST_PROVISIONING_VALIDATION.md) qualify
controlled absent-root creation, continuous CreateNew owner handoff and retained interrupted
state. 60 new tests cover partial writes, checkpoint/process kills and synchronized contenders;
807 focused cases pass per platform. Existing roots are never adopted or repaired by provision.
Reopened empty roots remain stopped; the live initializer diagnostic is not durable authority.
Next EP4 implements bounded conditional journal append and unknown-flush fault handling.
Physical durability, hostile namespace/global fencing, HA2 and release gates remain open.
Changes remain local/uncommitted; pushed baseline `2141eac` is unchanged.

## EP3 Existing Host Lifetime Ownership (2026-10-28)

[Ownership validation](../docs/implementation/M2_EMBEDDED_HOST_OWNERSHIP_VALIDATION.md)
adds existing-root cooperative exclusion, stopped administrative admissions and token-drained
shutdown. 50 new catalog cases cover process exit/active drain, aliases, invalid roots and
real publisher lifetimes. Focused runs pass 747 cases per platform; three FIFO rows execute
only on Linux. Public Storage metadata remains unchanged. No host files are provisioned,
repaired or appended by this implementation, and no global fence or writer resume is implied.
Next: explicit no-overwrite provisioning and interruption/contender tests before EP4 append.
EP2/EP3 work remains local/uncommitted; the pushed baseline remains `2141eac`.

## EP2 Internal Journal Codec (2026-10-28)

[Codec validation](../docs/implementation/M2_HOST_JOURNAL_CODEC_VALIDATION.md) now covers
strict bounded metadata/frame/TLV encoding, complete history checks and four independently
authored host-only vectors. 117 new codec cases pass; focused Windows/Linux runs pass 697
cases each. All 168 prior runtime/test/fixture files and public Storage metadata are unchanged.
Decoded history always keeps writers stopped; no codec output grants execution or proves
flush, anti-rollback or fencing. Next EP3 qualifies stable host-root lifetime ownership with
explicit provisioning boundaries and real process tests. EP4 durable append, HA2 application
integration and release gates remain open. EP2 design/codec changes remain local/uncommitted.

## Current Delivery and EP2 Journal Contract (2026-10-28)

The embedded profile is committed/pushed as `2141eac`. [ADR-023](../docs/ADR-023-bounded-embedded-host-journal-contract.md)
and the [journal contract](../docs/implementation/M2_EMBEDDED_HOST_JOURNAL_CONTRACT.md)
now define bounded canonical host-only frames, conditional transitions and explicit append/flush
uncertainty. Damaged tails are retained and block appends; restart never replays a plan.
No codec/writer, anti-rollback authority or durable-host proof is implemented. Next: a pure
internal codec with independent byte vectors, before filesystem persistence. This contract
is local/uncommitted; earlier delivery notes below retain their original scope.

## Current Delivery and Embedded Pilot Selection (2026-10-28)

RC2 through test-only HA1 integration is committed/pushed as `5d23ba2` on `origin/main`.
The user selected single-process embedded integration first. [ADR-022](../docs/ADR-022-single-process-embedded-pilot-host.md)
and the [pilot profile](../docs/implementation/M2_EMBEDDED_HOST_PROFILE.md) define one
controlled process, a dedicated host-state root, lifetime ownership and stopped restart
reconciliation. A local file journal is proposed; no backend or host is implemented yet.
Next EP2 defines its bounded codec, commit and corruption/rollback contract. M4 server,
HA2 application routing/work, public/archived-reader/release and retirement gates stay open.
This post-push profile is local; older uncommitted statements below describe their original
milestones. No runtime/test/fixture source changes or new runtime runs occur in this step.

## HA1 Ledger and Planned Execution Tests (2026-10-28)

[Test-only integration](../docs/implementation/M2_HOST_LEDGER_PLANNED_EXECUTION_VALIDATION.md)
now connects memory-ledger intent/authorization/receipt transitions to real owner-bound
migration and restore. 34 new cases cover lost-save acknowledgments, actual publication
uncertainty, new-ID retry after reconciled absence, concurrent authorizers and an active
publisher that defeats absence-based retry. Focused runs pass 448 cases per platform.
All prior runtime/test/fixture files are unchanged; no production adapter is introduced.
The bounded model/library integration is complete. Next: identify the actual consuming host,
durable backend, effective publisher exclusion and route/work authorities before HA2.
No memory commit proves durability or fencing. Changes remain local and uncommitted.

## HA1 Conditional Transition Harness (2026-10-28)

The internal [in-memory transition harness](../docs/implementation/M2_HOST_LEDGER_TRANSITION_VALIDATION.md)
now models exact-revision commits, single dispatch authorization, explicit read reconciliation
of lost acknowledgments and supplied-exclusion ownership transfer. 83 new tests cover commit
boundaries, concurrent winners, stale owners and preservation of receipts/observations;
414 focused cases pass per platform. Public Storage metadata remains unchanged.
No durable backend, executable permit, effective fence, routing or writer resume is supplied.
Next: test-only integration of these transitions with actual planned execution and lost-save
acknowledgments. Actual host selection and HA2 remain open; changes are uncommitted.

## HA1 Internal Ledger Model (2026-10-28)

The [ledger decision model](../docs/implementation/M2_HOST_ATTEMPT_LEDGER_MODEL_VALIDATION.md)
now checks supplied request/attempt/revision/owner bindings, durable-intent assumptions,
publication/receipt identity and prior-executor exclusion. All 180 new model tests pass;
focused validation covers 331 cases per platform, retaining earlier full-suite evidence at
its original scope. Every output keeps writers stopped and grants no executable authority.
Actual host selection, persistence and HA2 integration remain open. Next: an internal
conditional-transition harness for revision/CAS and lost-acknowledgment protocol tests.
Changes remain local and uncommitted; proprietary licensing and release gates are unchanged.

## HA1 Host Ledger Contract (2026-10-28)

[ADR-021](../docs/ADR-021-host-attempt-ledger-and-publisher-exclusion.md) and the
[host ledger contract](../docs/implementation/M2_HOST_ATTEMPT_LEDGER_CONTRACT.md) define
durable intent before dispatch, revision-checked ownership, separate acknowledgment and
observation records, and prior-executor exclusion before any fresh attempt. A ledger lease
cannot fence the current publication path; an old publisher must be stopped or effectively
excluded before takeover/retry. The 24 design scenarios are requirements, not runtime tests.
Actual host selection and HA2 integration remain open. Next: an internal pure supplied-evidence
ledger decision model and adversarial tests. No persistent backend, routing, public API or
writer resume is enabled. RC2/RC3 and this contract remain local and uncommitted.

Earlier milestone notes below retain their dated scope; the HA1 next step above is current.

## 1. Session State

2026-10-28: RC2 explicit planned execution implemented after requested commit/push. Workspace
D:/Development/Bosal.XmlDb; product Bosak.XmlDb. Commit a3b578c pushes validated work through RC1 to private Fytala-Charles/Bosak.XmlDb.
RC2 is subsequent local uncommitted work. No release, deployment or upstream change. Proprietary license,
Bosak 1.26.2 pins, disabled packaging and all frozen binary formats/fixtures remain fixed.

## 2. What Changed

ExecuteAttempt claims the original owner/policy-bound plan before filesystem I/O. A private
one-entry execution context binds role/absolute roots/policy and cannot be recreated from
descriptive data or replayed. Both pipelines accept optional internal context, check original
inventory SHA/source selection before verification output and after source-proof callbacks,
then use the preknown ID in the existing MigrationId/RestoreId field. Legacy verifier also
checks the optional pin before its private output. Default unplanned behavior remains fixed.

No public API, provenance layout/version change, durable plan/descriptor codec, automatic
retry/routing or source replacement. Plan state stays Dispatched on success or failure;
normal receipt versus exception conveys acknowledgment. Post-rename/cleanup errors can
leave a valid known candidate with no receipt. PA3 observes it without synthesizing success.
See docs/implementation/M2_ADMINISTRATIVE_ATTEMPT_EXECUTION_VALIDATION.md and result JSON.

## 3. Validation

Latest RC2 focused runs pass 449 cases/platform (255 Storage, 194 Integration), including
31 new execution cases plus prior proof/facade/plan/observation/restart/compatibility tests.
Catalog 1,110 is not a new full run. Native planned execution runs on Linux; Windows
asserts unsupported policy. Frozen four DLLs and 15 metadata vectors remain unchanged.

Latest RC1 focused runs pass 287 cases/platform (124 Storage, 163 Integration), including
28 new plan cases. Eight synchronized workers per role produce one claim/seven rejections.
The link branch executes on Linux, not Windows. Catalog 1,079 is not a new full run; prior
consolidated evidence below retains its original scope. Four DLLs/15 metadata vectors fixed.

Unfiltered source-baseline runs passed all 1,050 cases per platform: 753 Storage, 270
Integration, 27 Xdm, including all 27 expensive ET9-D/MG4 matrix rows freshly. Final HC1
hardening batches pass 80 cases per platform and replace the previous 79 classifier rows.
Aggregate unique coverage is 1,051 (754/270/27), not one unfiltered 1,051-case run. Runtime
source fingerprints show only the classifier and its test changed after baseline capture.
Windows final tests used an isolated identical-source build to preserve active full-run
assemblies; the default workspace was subsequently rebuilt successfully with zero warnings.

Matrix output separates ProcessCrash, modeled strong and actual Linux native positions;
Windows native early returns are not execution. Full per-case traces and process repetitions
are in results JSON. Four frozen DLL hashes and 15 metadata fixture hashes remain verified.
Windows and actual Linux PowerShell hygiene/hidden/link checks and Git LF checkout simulation
pass; formatting passes. SDK 10.0.301, Windows runtime 10.0.11, Linux 10.0.9 on WSL2/overlayfs.
These are local process/fault boundaries, not physical power-loss or actual ENOSPC proof.

## 4. Required Boundaries and CI State

Read AGENTS.md, ADR-018/019 and the PA/HC contracts. No public mutable APIs, routing service,
external writer fence, durable receipt journal, source replacement or reclamation. Every
HC1/PA3 output keeps writers stopped. Artifact/operation matching is correlation, not
acknowledgment/authenticity or a capability. Do not open sealed inputs as live roots.
Keep original paths, stable runtime identities and every committed history; CanReclaim=false.

Historical CA1 hosted run 40651032546 failed only Documentation hygiene on Ubuntu/Windows;
Restore/Build/Test/Formatting passed there for that older code. Both portability fixes
are included in a3b578c; its hosted run is separate from later local RC2 source. No hosted
RC2 success is claimed. Actual archived releases, supported public signatures/diagnostics, real host
writer exclusion/work accounting/routing/restart proof and physical/release gates stay open.

## 5. Next Work

RC3 next: process-level preannounced attempt descriptors, failure/kill before/after publish,
read-only restart inspection with known IDs and no descriptor replay, competing same/different
plans, and explicit new-ID retry only after executor exit/outcome reconciliation. Preserve
separate unknown artifact-only versus known-attempt observations and no false acknowledgments.

Actual host ledger/exclusion/accepted work/routing/restart, public signature/consumer,
archived release and physical/release gates remain open. No automatic retry, source path
replacement, public API or reclamation; keep all histories and CanReclaim=false.

*Last updated: 2026-10-29*


## RC3 Process and Contention Qualification (2026-10-28)

RC3 now qualifies preannounced IDs across publisher process death, independent plans racing
one destination and concurrent dispatch of one plan. See [validation](../docs/implementation/M2_ADMINISTRATIVE_ATTEMPT_PROCESS_VALIDATION.md).
The focused Windows/Linux runs cover 71 cases each, including 12 new RC3 cases; prior
full-suite evidence retains its dated scope. This supersedes earlier “next RC3” statements.
RC2/RC3 remain local; a3b578c contains work through RC1. No public API, host routing,
durable replay, source replacement or reclamation is enabled. Next HA1 defines the host
attempt-ledger and fencing contract; local inspection alone never authorizes retry.
