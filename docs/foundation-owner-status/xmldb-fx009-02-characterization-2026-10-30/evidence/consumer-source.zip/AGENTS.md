# Bosak.XmlDb â€” Agent Guide

> **Canonical agent instructions** for the Bosak.XmlDb project.  
> Deeper `AGENTS.md` files in subdirectories override these instructions for their scopes.

---

## 1. Project Identity

**Bosak.XmlDb** is a Embedded native XML fragment storage and persistent XDM navigation..

- **Solution:** `Bosak.XmlDb.slnx`
- **Framework:** .NET 10
- **Target:** net10.0

---

## 2. Build & Test

```bash
# Full build
dotnet build Bosak.XmlDb.slnx

# Run all tests
dotnet test Bosak.XmlDb.slnx

# Run with verbosity
dotnet test Bosak.XmlDb.slnx --logger "console;verbosity=detailed"

# Full clean rebuild (clean â†’ restore â†’ build â†’ test)
pwsh tools/rebuild.ps1

# Documentation hygiene check
pwsh tools/check-docs.ps1 -ProjectPath .
```

**Rule:** All tests must pass before a task is considered complete.

---

## 3. Code Conventions

### 3.1 File Headers

**Every `.cs` file** (excluding generated files in `obj/`, `bin/`) must begin with the following header:

```csharp
// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : <dd MMMM yyyy>
// PURPOSE              : <One-line description of the file's responsibility>
// SPECIAL NOTES        : <Implementation notes, assumptions, or layer-specific warnings>
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | <dd-MM-yyyy>   | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
```

**Rules:**
1. **PURPOSE** â€” Derive from the XML `<summary>` of the primary type. Keep under 100 characters.
2. **Change History** â€” When modifying an existing file, append a new row with the current date, a bumped version number, and a brief note.
3. **Generated files** â€” Skip `obj/`, `bin/`, and any file containing "Generated" or "Auto-generated" in the first 200 characters.

### 3.2 Naming & Language

- Use **English** for all identifiers, comments, and documentation.
- Use `PascalCase` for classes, records, methods, enums, and public members.
- Use `camelCase` for local variables and parameters.
- Use `PascalCase` for acronyms longer than two characters (e.g., `XmlDocument`, not `XMLDocument`).
- Prefer `sealed` classes unless inheritance is explicitly designed.
- Use `record` or `record struct` for immutable DTOs.
- Use `file`-scoped namespaces when possible.

### 3.3 Nullability

All projects must have `<Nullable>enable</Nullable>`. Always annotate nullability in public APIs.

### 3.4 Implicit Usings

All projects should have `<ImplicitUsings>enable</ImplicitUsings>`. Do not redundantly import `System` namespaces.

### 3.5 Build Enforcement

Conventions are enforced by the build, not just by review:

- Root `Directory.Build.props` â€” `TreatWarningsAsErrors`, `AnalysisLevel=latest`, `EnforceCodeStyleInBuild`, MinVer versioning, shared package metadata.
- Root `.editorconfig` â€” formatting and analyzer severities.
- Root `global.json` â€” .NET SDK pin.

---

## 4. XML Documentation

All projects must generate documentation files:

```xml
<PropertyGroup>
  <GenerateDocumentationFile>true</GenerateDocumentationFile>
</PropertyGroup>
```

**Rules:**
- Every `public` and `protected` type and member must have a triple-slash XML comment (`///`).
- Use `<summary>` for the primary description.
- Use `<param>` for every parameter.
- Use `<returns>` for methods with non-void return types.
- Use `<exception>` when a method throws documented exceptions.
- Use `<remarks>` for extended context or examples.

**Example:**

```csharp
/// <summary>
/// Parses the supplied EDI payload into a canonical evidence set.
/// </summary>
/// <param name="payload">Raw EDI text. Must not be null.</param>
/// <param name="options">Optional parsing flags.</param>
/// <returns>A <see cref="CanonicalEvidenceSet"/> containing extracted evidence.</returns>
/// <exception cref="ArgumentNullException"><paramref name="payload"/> is null.</exception>
public CanonicalEvidenceSet Parse(string payload, ParseOptions? options = null)
```

---

## 5. Testing Requirements

### 5.1 Test Organization

| Test Project | Purpose |
|--------------|---------|
| `Bosak.XmlDb.Core.Tests` | Domain invariants, pure logic, state transitions |
| `Bosak.XmlDb.Application.Tests` | Use-case handlers (ports mocked) |
| `Bosak.XmlDb.Infrastructure.Tests` | Repository, service, and integration behavior |
| `Bosak.XmlDb.*.Tests` | One test project per source project (1:1 mapping preferred) |

### 5.2 Test Patterns

- Use the same test framework across all projects (MSTest, xUnit, or NUnit â€” pick one and stay consistent).
- Test classes are marked with the appropriate attribute (`[TestClass]`, `[TestCollection]`, etc.).
- Test methods describe the behavior under test: `MethodName_Scenario_ExpectedResult`.
- Use `NullLogger<T>.Instance` when testing services that require `ILogger<T>`.
- Clean up temporary files after tests.
- Add golden-file tests for serialization, XML, or document output.
- Place shared sample/golden data in `tests/TestData/`; suite-specific data in `tests/<Suite>/` (e.g., `Schemas/`).

### 5.3 Coverage Rule

New functionality must have **at least one unit test** covering the happy path and **one test** covering a failure mode or edge case.

---

## 6. Versioning

- Use [Semantic Versioning](https://semver.org/) (`Major.Minor.Patch`).
- Versions are produced **from git tags** (`v1.2.3`) by MinVer, configured in root `Directory.Build.props`. Never hard-code `<Version>` in project files.
- Bump `Minor` for new features; bump `Patch` for bug fixes (tag accordingly).
- Record version bumps in:
  - File header change-history tables
  - `docs/FEATURE_REQUESTS.md` target versions
  - `docs/ARCHITECTURE.md` status line
  - `docs/INTEGRATION.md` version history
  - `ROADMAP.md` milestones

### 6.1 Architecture Decision Records

- **Minor decisions** go in the `docs/ARCHITECTURE.md` *Key Design Decisions* table.
- **Cross-cutting or expensive-to-reverse decisions** get an ADR: copy `docs/ADR-000-TEMPLATE.md` to `docs/ADR-NNN-<slug>.md` (NNN = next zero-padded number, never reused).
- Link ADRs from the REQ detail sections that motivated them.

---

## 7. Documentation Sync Checklist (Mandatory)

After **every** successful implementation step, update the following canonical documents before concluding the step or session:

| File | Purpose | When to Update |
|------|---------|----------------|
| `README.md` | Human-facing project overview | Structural, CLI, or dependency changes |
| `ROADMAP.md` | Release stages, milestones, known limitations | Stage or milestone change |
| `docs/ARCHITECTURE.md` | Package tiers, dependency rules, use cases, canonical models | New projects, tier changes, new use cases, API additions |
| `docs/FEATURE_REQUESTS.md` | Living registry of all REQ items | Any REQ status change, new REQ, or completed item |
| `docs/INTEGRATION.md` | Consumer integration guide, APIs, extension points | New public APIs, CLI commands, behavioral changes |
| `docs/DOCUMENTATION_STYLE_GUIDE.md` | Documentation & diagram rules | Any documentation-style change |
| `docs/ADR-*.md` | Architecture decision records | Any significant decision (one new file per decision) |
| `docs/AGENT_HANDOVER.md` | Session state and canonical agent context | Major architectural shifts, current session scratchpad |

**Rule:** If a file was modified during the step, its documentation counterpart must be updated in the same step. No exceptions.

### Pre-Handover Checklist

```markdown
- [ ] `README.md` â€” Repository tree, build/test commands, and quick-start are current.
- [ ] `ROADMAP.md` â€” Stage and milestone status reflect reality.
- [ ] `docs/ARCHITECTURE.md` â€” Status line reflects reality; use-case catalog and project matrix are current.
- [ ] `docs/FEATURE_REQUESTS.md` â€” Registry table and detail sections are accurate; "Last updated" date is today.
- [ ] `docs/INTEGRATION.md` â€” Feature status matrix is accurate; version history appended for behavioral changes.
- [ ] `docs/AGENT_HANDOVER.md` â€” Date and commit hash match latest; "What Was Built" includes every feature/bugfix.
- [ ] `AGENTS.md` â€” Coding conventions still match reality.
```

---

## 8. Git Rules

- Never run `git commit`, `git push`, `git reset`, `git rebase` unless the user explicitly asks.
- Never modify files outside the working directory unless explicitly instructed.
- Keep commits focused; one logical change per commit.

---

## 9. Related Documents

| Document | Purpose |
|----------|---------|
| `README.md` | Human-readable quick start |
| `ROADMAP.md` | Release stages, milestones, known limitations |
| `docs/ARCHITECTURE.md` | Package tiers, dependency rules, use cases |
| `docs/FEATURE_REQUESTS.md` | Living registry of cross-cutting feature requests |
| `docs/INTEGRATION.md` | Consumer integration guide |
| `docs/DOCUMENTATION_STYLE_GUIDE.md` | Documentation & diagram rules |
| `docs/AGENT_HANDOVER.md` | Session state for AI agents |

---

*Last updated: 2026-10-30*

Documentation maintenance: docs/DOCUMENTATION_STYLE_GUIDE.md and docs/DOCUMENTATION_RENDERER_TEST.md are immutable kit files. Put local framework, license, host, and fixture rules in docs/PROJECT_DOCUMENTATION_CONVENTIONS.md. Upgrade governed files only with tools/update-docs-kit.ps1 and an explicit release version. Preserve .template-provenance.json as generation history.

For the Templates repository itself, read the Templates maintenance record and run tools/test-scaffold.ps1. Placeholder-bearing source documents are intentional templates; validate generated output rather than running the consumer checker on Templates.

## 10. Bosak.XmlDb Scope and Boundaries

This checkout is named Bosal.XmlDb; the canonical product/solution/namespace is
Bosak.XmlDb. M1 implements Core metadata, Storage and Xdm; M2 adds the first scalar transaction/recovery slice. Storage references
Core; Xdm references Core and Storage. Bosak Core is pinned to 1.26.2 with verified package provenance. Never silently follow upstream main.

Do not implement server/NATS/Kubernetes dependencies in M0/M1 or modify Bosak.
The owner selected the proprietary Fytala license, matching Bosak.Braid; packaging
remains disabled. Read M2_STATUS.md, ADR-004/005/006/007/008/009/010/011/012/013/014/015/016/017/018 and the transaction/checkpoint formats before persistence changes.
Current suites cover architecture, binary corruption, persistent XPath, lifetime and process reopen. Use EmbeddedXmlDatabase.BeginRead for transactional roots. Do not add structural edits, reclaim history or claim power-loss durability without the required design and tests.

Use the internal transaction storage seam for all data writes, namespace changes and barriers.
ProcessCrash is the default; FileAndDirectoryFlush is an experimental Linux-only policy
with no silent fallback. Windows fault modeling is not native directory-fsync or power-loss
evidence by itself. Native overlayfs execution now passes in the isolated Linux runner. Preserve the original Open overload and existing versioned bytes. Checkpoints and snapshot-owned shared leases are implemented; no committed history may be reclaimed by the current implementation.

Checkpoint recovery is opt-in and still requires all retained WAL records. Optional anchor
corruption must fall back to independently validated full history. Keep canonical lease
identities stable and release handles with snapshots/transactions, not coordinator disposal.
Use tools/test-linux.ps1 for isolated native Linux checks; read-only source/cache mounts and
no container network preserve host build outputs. Do not treat container success as physical
power-loss certification or approval to delete history.

Independent recovery descriptors are explicit publications, not guessed checkpoint directories.
Retention reports must never authorize deletion or infer old-reader absence from lease probes.

ADR-009 and M2_BACKUP_FORMAT_V1.md define implemented fixed-H full-history backup/restore.
ADR-010 implements epoch metadata/admission; ADR-011 adds explicit read-only epoch
data sessions/snapshots. Public epoch transactions, epoch backup, history migration and
retirement remain pending. Keep CanReclaim=false and
all source history. DeleteDirectory is only for freshly owned backup verification
clones/workspaces, never live store history or unidentified abandoned paths. Runtime
locks/leases are excluded from backups. ADR-013 implements ET1-ET3 pure authority/profile
codecs and frozen-reader rejection. ADR-014 implements explicit internal empty-chain
admission/coordinator, independent snapshots and lifetime-only transaction contexts.
Default/public immutable profile gates remain strict. ADR-015 adds internal ET5 scalar
staging/commit and complete-history reopen. ADR-016 adds internal ET6 redo/publication-fault recovery. ET7 adversarial classification is now qualified. ET8 local native-durability fault qualification is now recorded. ET9 internal fault qualification is implemented; migration, retirement
and full C1-C3 remain pending.

Frozen tests/TestData/legacy-format1-reader binaries are immutable pre-epoch format-1
baseline evidence with pinned hashes, not archived pre-lease releases. Never rebuild
or silently replace them during tests. Legacy public data APIs still reject major 2. ReadOnlyEpochDatabase accepts only
complete immutable zero-sequence roots with SNAPSHOT and no transaction state. Metadata-only
fixtures are not XML stores. Data-root production is internal test infrastructure, not
a public import/migration API. Do not bypass admission or create nested M1 FORMAT roots.

Frozen legacy-readonly-epoch-reader fixtures are also immutable baseline evidence with
pinned hashes. Preserve both families; never rebuild them during tests. Authority codecs
are not chain/materialization validators and do not classify/delete incomplete tails.
Current default DecodeFormat/admission/read-only data paths remain immutable-profile-only.
Explicit internal ScalarWal admission forks must preserve profile and precede coordinator
selection. ET4 rejects nonempty WAL/generation/head state; it cannot replay, clean or
downgrade it. No public mutable open/creation/commit API is added.

ET5 EpochScalarCoordinator is internal and separate from zero-only EpochEmptyCoordinator.
Capture selected-head manifest identity for stale validation, not permanent BASE after zero.
Keep exact admission and independent reader handles. Read ADR-015 and
M2_EPOCH_SCALAR_COMMIT.md before persistence changes. Complete WAL/materialization histories
can reopen with lagging CURRENT. ADR-016 now implements exact missing-generation redo
and strictly unwitnessed incomplete-final-WAL removal. Corrupt or witnessed torn state
fails closed. No public mutable API, epoch migration or committed-history deletion is enabled.

Read ADR-016 and M2_EPOCH_RECOVERY.md before modifying recovery. Preflight all WAL,
CURRENT, published generations and stable readers before recovery writes. Never overwrite
corrupt present generations or stable identities. Redo must reproduce the recorded hash.
Only supported physically incomplete final WAL without any publication witness may be
removed through ITransactionStorage plus directory barrier. Keep every committed record.

ET7 classification evidence is in M2_EPOCH_CLASSIFICATION_VALIDATION.md. Invalid histories
must preserve bytes and directory/file inventory and start no recovery content writes,
even with missing earlier generations. Valid multi-generation redo must reproduce exact
materializations and retain old snapshot handles. ET8 local native fault qualification is now recorded;
ET9 backup/restore qualification is implemented; migration remains pending; test qualification does not enable public mutable APIs.

ET8 evidence is in M2_EPOCH_NATIVE_DURABILITY_VALIDATION.md. FaultingTransactionStorage
keeps modeled delegation by default; use explicit native mode and assert EffectiveDurability
for native Linux sweeps. Windows must reject native FileAndDirectoryFlush without fallback.
Keep native fault counts separate from modeled/process positions and host-only branches.
The recorded NTFS/overlayfs/WSL2 runs are not physical power-loss or real ENOSPC proof.
ADR-017 designs epoch-bound full-history backup and separate-root fresh-epoch restore;
never reuse format-1 bytes, replace original roots or reduce history to sequence zero.

ADR-017 and M2_EPOCH_BACKUP_DESIGN.md define ET9 backup/independent restore. ET9-A now
implements pure BXEI/BXEZ/BXEO metadata codecs, frozen in M2_EPOCH_BACKUP_FORMAT_V1.md with
independent fixtures; the candidate document is historical. ET9-B now adds capture/verification; ET9-C now adds independent restore.
ET9-D qualifies observed capture/restore persistence traces and repeated process boundaries. Restore design uses fresh StoreId/EpochId while
preserving H, transaction/document/node IDs and data bytes; rebind every authority/WAL link.
Publish store/ plus external origin.bin together as a bundle and return the store path.
Provenance is not recovery authority; no unchanged-profile mandatory root record is added.
Do not enable public APIs, source replacement, history reduction or reclamation from this design.

ET9-A EpochBackupCodec performs no I/O or admission. Header-context checks do not establish
actual closure/data/WAL/bundle verification or grant capability. Its golden vectors are
metadata-only, not complete backup artifacts; never weaken later file-closure checks to
accept them. Preserve the three new frozen fixture hashes and independent Python provenance.
ET9-B must hold admission/coordinator exclusion through fixed-H publication and implement
both verification oracles; restore/public APIs/migration/retirement remain later gates.

ET9-B capture is internal; read M2_EPOCH_BACKUP_CAPTURE.md and its validation report.
Keep operation admission before gate and hold writer/gate through exact-H publication.
Capture never repairs source state. ReadArtifact checks seal/closure/headers only; both
private verification oracles are mandatory for full history proof. Source-identity clone
admission files are new private inodes, not copied ownership. Delete only contained owned
clones and empty operation workspace. Never open sealed data as a live store. ET9-C restore is now implemented;
ET9-D fault qualification is implemented; public APIs/migration/retirement remain pending.

ET9-C EpochBackupRestore is internal; read M2_EPOCH_BACKUP_RESTORE.md and its validation.
Verify source and transformed history with both oracles; fresh StoreId/EpochId preserve
all H/transaction/document/node IDs and XML data bytes while rebinding authority/WAL hashes.
Close staging handles before publishing store/ plus external origin.bin as one bundle.
Return published StorePath; origin describes the initial prefix, not current recovery.
Source and backup remain immutable to restore. ET9-D adds exhaustive observed storage faults,
real partial writes and repeated process interruption with actual native Linux delegation; no public API or retirement.


ET9-D qualification update (2026-10-27): capture/restore persistence sweeps now enumerate
every observed before/after call and actual partial-write position on a one-commit history.
Process-crash and modeled strong ordering are separate from actual native Linux delegation.
Repeated process interruption covers private publication windows, published outcomes and
acknowledgment loss. Source/backup bytes, historical reads, provenance and released handles
are checked. See [fault qualification](docs/implementation/M2_EPOCH_BACKUP_FAULT_VALIDATION.md).
Migration/cutover acceptance is now specified by ADR-018; MG1 pure codecs/fixtures are implemented; MG2 legacy verification is implemented; MG3 conversion is implemented; MG4 qualification is implemented; MG5 acceptance is next. Public mutable APIs, source replacement and history reclamation remain disabled.


ADR-018 and docs/implementation/M2_EPOCH_MIGRATION_DESIGN.md specify sealed format-1
full-history migration and explicit cutover acceptance; MG1-MG3 internal codecs/verification/conversion are implemented; MG4/MG5 remain open. Conversion never
opens/repairs the live source or modifies the sealed artifact. Preserve every sequence,
transaction/document/node identity and document data byte; generate fresh destination
StoreId/EpochId and re-encode every authority/WAL link. Require legacy and destination
complete-history plus full-redo oracles. Separate migration.bin provenance has no source
epoch IDs and cannot reuse/relax BXEO. It grants no recovery, routing or retirement authority.
MG1 pure codec/independent-fixture work is now implemented and the BXEM bytes are frozen. Existing formats/fixtures remain immutable.
Actual cutover needs operator writer freeze through capture/conversion/freshness checks
and explicit routing; no source path replacement, automatic rollback after divergence,
pre-lease reader-absence inference or deletion. Keep archived C1-C3 gaps explicit.

Legacy H0 BXBI backup closure omits CURRENT; epoch H0 still requires canonical CURRENT.
Legacy FullJournal Open republishes positive-H CURRENT even for valid history: MG2 must
preflight strictly, then allow only byte-identical republication and fresh runtime files
inside owned verification clones, never writes to sealed input or the original source.


MG1 is now implemented: EpochMigrationCodec and BXEM 1.0, fixed 350 bytes with independent
H0/H2 metadata-only fixtures. Read M2_EPOCH_MIGRATION_FORMAT_V1.md and its codec validation.
Keep source inventories bounded by remaining bytes before allocation. Context checks bind
seal/headers only; they do not prove closure, WAL contents/history or admit/route any root.
Do not repurpose BXEO or fabricate legacy epoch IDs. Preserve all newly frozen hashes.
MG2 strict sealed legacy complete/redo verification is now implemented with no input I/O
writes; private FullJournal clones permit byte-identical CURRENT republication and fresh
runtime initialization. MG3 internal conversion is implemented; no public APIs/cutover/retirement.


MG2 LegacyMigrationVerifier is now implemented; read M2_LEGACY_MIGRATION_VERIFICATION.md
and its validation. ReadArtifact verifies seal/closure/bytes only; Verify also requires
strict every-transition preflight before any storage writes, then owned complete and
base/full-WAL redo clones. Never call the coordinator on sealed data or a live source.
Partial artifact WAL, stale CURRENT, missing/corrupt generations and hidden second edits
are corruption, not repair opportunities. Legacy clone CURRENT republication is allowed
only byte-identically; H0 omits CURRENT. Cleanup only named contained owned clones/empty
nonce workspace. Input mutation, faults and retries never authorize artifact/source cleanup.
MG3 now adds internal fresh-epoch transformation and verified two-role bundle publication;
MG4 fault qualification and MG5 internal acceptance are implemented below. No public APIs/source replacement or
retirement. Keep original formats/fixtures and all histories intact.


MG3 EpochLegacyMigration now implements internal sealed legacy-to-ScalarWal conversion;
read M2_EPOCH_MIGRATION_CONVERSION.md and validation. Invoke MG2 for legacy proof, preserve
all sequences/operations/document data, create fresh StoreId/EpochId, and re-encode the full
WAL predecessor digest chain. Verify destination complete/redo oracles and fresh runtime
before publishing store/ plus frozen BXEM migration.bin together. Check exact operation
provenance bytes (including MigrationId), not header consistency alone. Close staging
handles before rename and return only the published store path. No live source opening,
source replacement, public API, routing or retirement. Source has no epoch IDs to fabricate.
MG4 now qualifies observed persistence faults and repeated process/native interruption;
MG5 internal acceptance is implemented below; actual routing remains later. Retain all old/new frozen fixture hashes and existing formats.


MG4 now qualifies all observed H=1 conversion storage before/after/partial-write positions
and repeated process/native interruption; read M2_EPOCH_MIGRATION_FAULT_VALIDATION.md.
Keep exact counts/durations, per-policy traces, actual EffectiveDurability and host-only
branches distinct. Four worker attempts share only read-only inputs and own separate
same-depth workspaces; snapshots/coordinators must not be shared across worker threads.
Process tests use actual local policy and kill private legacy copy/redo and epoch redo,
then publication/ACK boundaries. Prior ET9-D cases are retained explicitly, not counted as
fresh runs. These are application-boundary tests, not physical power-loss/real ENOSPC proof.
MG5 now implements a bounded internal cutover/freshness/rollback acceptance harness only. No actual
routing service/configuration rewrite, public API, source replacement, reader-absence
inference or retirement. Keep CanReclaim=false and all source/candidate histories intact.


MG5 now implements internal prototype cutover acceptance; read M2_MIGRATION_CUTOVER_ACCEPTANCE.md
and validation. Cooperating source/candidate in-memory freeze guards block new/pending
mutations; capture must be registered under that source freeze. Acquire candidate child
admission before inspection gates; inspect source then candidate. Scopes/evidence are
caller-thread/process confined, latest/single-use, and freshness is rechecked on consumption.
No actual route/configuration callback, recovery or write during validation/evaluation.
Unknown routes, work acceptance, owner loss or changed bytes require uncertainty/reconciliation,
not automatic rollback. Flags do not fence uncooperative/old binaries or prove reader absence.
MG1-MG5 completion is internal prototype only. Next audit compatibility/release evidence and
explicit missing archived pre-lease binaries/provenance. Public APIs, actual cutover service,
source replacement and all retirement/reclamation remain disabled; retain all histories.


2026-10-28 readiness audit: read docs/implementation/M2_RELEASE_READINESS_AUDIT.md.
Next CA1 strengthens local frozen/current rejection against real MG3 bundles and all nested
generations, including directory inventory nonmutation. Do not equate local binary hashes
with archived release provenance or synthetic profile tests with full migrated-root coverage.


CA1 local real-migration rejection is implemented; see
docs/implementation/M2_MIGRATED_BUNDLE_COMPATIBILITY_VALIDATION.md. Next CA2 qualifies
migrated-candidate child/owner disposal races and cross-process ownership; keep archived
release and actual routing gaps open. Preserve binary fixtures, formats and all histories.


CA2 migrated ownership race/holder qualification is implemented; read
docs/implementation/M2_MIGRATED_OWNERSHIP_VALIDATION.md. Ordered schedules prove endpoints;
repeated simultaneous runs do not prove every interleaving. Next define supported public
API and actual host cutover/restart contracts before real routing implementation. Archived
release compatibility and all retirement remain open. No public APIs or formats change.


ADR-019 and docs/implementation/M2_PUBLIC_API_AND_HOST_CUTOVER_CONTRACT.md now define
explicit mutable API and host cutover/restart boundaries (design only). Names are proposed;
no public facade, real routing or durable host authority is implemented. Next HC1 pure
restart/reconciliation classifier must perform no I/O or callbacks and cannot authorize
write resume. Missing/contradictory observations require reconciliation, not receipt replay.


HC1 internal pure restart classification is implemented; read
docs/implementation/M2_RESTART_CLASSIFICATION_VALIDATION.md. Inputs are supplied assumptions,
not verified host facts; every output keeps writers stopped. Next PA1 prototypes an explicit
mutable facade internally with ownership/profile/diagnostic tests. No public surface, host
route adapter, durable receipt authority or retirement is enabled by HC1.


PA1 internal mutable facade prototype is implemented; read
docs/implementation/M2_SCALAR_EPOCH_FACADE_VALIDATION.md. Expected identity checks precede
admission/adoption; commit I/O retains possible-publication uncertainty. No public API is
exposed. Next PA2 prototypes separate administrative outcomes; preserve sealed inputs,
existing formats, all history and explicit release/host compatibility gaps.


PA2 internal administrative prototype is implemented; read
docs/implementation/M2_SCALAR_EPOCH_ADMINISTRATION_VALIDATION.md. Receipts are acknowledged
in-memory results, not durable capabilities; exceptions can leave valid publication. Next
PA3 inspects uncertain publication read-only without adoption, implicit retry or routing.
Artifact match alone does not prove an unknown operation ID. Preserve all history.


PA3 read-only publication inspection is implemented; read
docs/implementation/M2_PUBLICATION_INSPECTION_VALIDATION.md. Match is point-in-time
correlation, not acknowledgment/authenticity or routing authority. Missing/changed candidates
are never adopted/recovered. Next consolidate cross-platform regression and API/readiness
evidence before further API work; keep host/archive/public/retirement gates explicit.


Consolidated review (2026-10-28): read
docs/implementation/M2_CONSOLIDATED_API_READINESS_REVIEW.md. Separate the full 1,050-case
baseline from final 80-case HC1 hardening; aggregate 1,051 only after replacing old classifier
rows. Catalog pass includes host-only early returns; preserve actual per-policy matrix
traces. Local public metadata equality is not archived release qualification. README LF
and hidden-file-safe local kit resolution are CI requirements; run portability regressions.
Next design request-to-publication operation correlation before public administration.


ADR-020 and docs/implementation/M2_ADMINISTRATIVE_ATTEMPT_CONTRACT.md define design-only
known-attempt correlation/retry rules. Next RC1 implements internal read-only prepare and
owner-bound single-dispatch state/tests; RC2 pipeline integration is later. Descriptors
never recreate executable authority. New retries require new IDs and prior executor/outcome
reconciliation; no automatic replay, target reservation, arbitrary caller IDs or wire changes.


RC1 internal read-only preparation/owner-bound atomic claim is implemented; read
docs/implementation/M2_ADMINISTRATIVE_ATTEMPT_PLAN_VALIDATION.md. Claim does not execute
or touch the filesystem; RC2 must revalidate bound intent after claim before any output.
Next RC2 wires known IDs without changing existing unplanned behavior/frozen layouts.
No descriptor replay, target reservation, global registry, routing or public API is enabled.


RC2 explicit ExecuteAttempt is implemented; read
docs/implementation/M2_ADMINISTRATIVE_ATTEMPT_EXECUTION_VALIDATION.md. Claim precedes FS I/O;
private one-entry contexts bind prepared intent and cannot be recreated from descriptors.
Preknown IDs use unchanged provenance fields; old unplanned defaults remain unchanged.
Next RC3 qualifies process/restart and competing publishers. No inferred acknowledgment,
automatic retry, public API, routing, source replacement or retirement.


## RC3 Process and Contention Qualification (2026-10-28)

RC3 qualifies preannounced IDs across publisher process death, independent plans racing
one destination and concurrent dispatch of one plan. See [validation](docs/implementation/M2_ADMINISTRATIVE_ATTEMPT_PROCESS_VALIDATION.md).
Focused Windows/Linux runs pass 71 cases each, including 12 new RC3 cases; earlier
full-suite evidence retains its dated scope. This supersedes earlier next-RC3 statements.
RC2/RC3 remain local; a3b578c contains work through RC1. No public API, host routing,
durable replay, source replacement or reclamation is enabled. Next HA1 defines the host
attempt-ledger and fencing contract; local inspection alone never authorizes retry.


## HA1 Host Ledger Contract (2026-10-28)

[ADR-021](docs/ADR-021-host-attempt-ledger-and-publisher-exclusion.md) and the
[host ledger contract](docs/implementation/M2_HOST_ATTEMPT_LEDGER_CONTRACT.md) define
durable intent before dispatch, revision-checked ownership, separate acknowledgment and
observation records, and prior-executor exclusion before any fresh attempt. A ledger lease
cannot fence the current publication path; an old publisher must be stopped or effectively
excluded before takeover/retry. The 24 design scenarios are requirements, not runtime tests.
Actual host selection and HA2 integration remain open. Next: an internal pure supplied-evidence
ledger decision model and adversarial tests. No persistent backend, routing, public API or
writer resume is enabled. RC2/RC3 and this contract remain local and uncommitted.


HA1 pure supplied-evidence ledger classification is implemented; read
docs/implementation/M2_HOST_ATTEMPT_LEDGER_MODEL_VALIDATION.md. Outputs are descriptive,
not authenticated durable state, dispatch permits or fencing. Every output keeps writers
stopped. Prior publication evidence survives later absence/unknown observations. New-attempt
eligibility requires supplied exclusion, drained queues and no surviving original plan/executor.
Next implement only an internal conditional-transition protocol harness; actual host/backend,
publisher fence, routing and HA2 remain open. Preserve all source/candidate/history bytes.


HA1 conditional in-memory transition harness is implemented; read
docs/implementation/M2_HOST_LEDGER_TRANSITION_VALIDATION.md. Exact snapshots/revisions
serialize this one model instance, not a host/resource registry. After-commit exceptions
retain state and require explicit reads; never infer failed persistence or replay a plan.
Takeover requires supplied exclusion and cannot erase receipt/observation history. No
memory commit is durable evidence. Next add test-only planned-execution/ledger-boundary
integration; actual host/backend/fencing, public exposure and HA2 remain open.


HA1 test-only modeled ledger/planned-execution integration is qualified; read
docs/implementation/M2_HOST_LEDGER_PLANNED_EXECUTION_VALIDATION.md. Test-controlled dispatch
is not an enforced production adapter or global fence. Preserve separately acknowledged
receipts, observations and old/new attempt histories. Next gather actual consuming-host,
durable backend, executor/queue, publisher-exclusion and route/work authority inputs before
HA2; do not invent a host or add persistence dependencies merely to continue local models.
All public/release/archive/physical-durability and retention gates remain open.


User selected single-process embedded integration first; see ADR-022 and
docs/implementation/M2_EMBEDDED_HOST_PROFILE.md. Work through HA1 test integration is
pushed as 5d23ba2. Next EP2 designs the proposed local host journal's bounded codec,
commit/flush and corruption/rollback limits before persistence code. Require controlled
all-in-process scope, lifetime ownership, closed admissions and drain before release;
restart stays stopped. Do not add M4 server/remote queues or treat the proposed backend
as implemented durability, global fencing or application routing/work authority.


EP2 journal design is specified in ADR-023 and
docs/implementation/M2_EMBEDDED_HOST_JOURNAL_CONTRACT.md; profile pushed as 2141eac.
Next implement only the pure internal codec and independent vectors. Frame size is 112+N,
header 72 bytes; explicit TLV/wire mappings and cumulative bounds are required. Do not
truncate/resynchronize corrupt or partial tails, adopt a prefix as authoritative, infer
anti-rollback from hashing or reconstruct plans. Ownership/provisioning/file flush and
process qualification remain EP3/EP4; no host journal file is added to store/artifact roots.


EP2 pure journal codec is implemented; read docs/implementation/M2_HOST_JOURNAL_CODEC_VALIDATION.md.
The four new host-journal v1 hex vectors/manifest are independent reference evidence; do not
regenerate them from the encoder. Old frozen readers/15 metadata fixtures remain unchanged.
Decode validates complete bounded histories and returns stopped descriptions, never plans or
append/dispatch authority. Version 1 same-request retries require reconciled absence and
identical input/destination; independent-destination reasoning is not serialized. Next EP3
implements stable existing-host-root lifetime ownership/process tests; no implicit provisioning,
repair, tail truncation or durable-writer claim is enabled by the codec.


EP3 existing-root lifetime ownership is implemented; read
docs/implementation/M2_EMBEDDED_HOST_OWNERSHIP_VALIDATION.md. OpenExisting never provisions,
repairs or appends. It requires controlled stable local roots and caller-supplied complete
protected-root inventory. Administrative admissions start closed and never resume database
writers. Dispose requests shutdown; await WhenReleased after every operation/child token
actually drains. Cancellation/timeouts are not token completion. Cross-process owner locks
exclude cooperating instances only; namespace replacement and all alias/global fencing are
not proved. Next qualify explicit no-overwrite provisioning before EP4 persistence.


Explicit controlled provisioning is implemented under ADR-024; read
docs/implementation/M2_EMBEDDED_HOST_PROVISIONING_VALIDATION.md. Require bound fresh
no-prior-host/controlled-provisioner assertions, absent target and stable existing parent.
CreateNew owner decides cooperative races; directory creation is not an exclusive claim.
Never delete/repair/replay partial roots, and transfer the original owner handle without
an unlock gap. WasProvisionedHere is live-only diagnostic state, never append/dispatch
permission; reopened empty roots remain stopped. Next EP4 qualifies conditional append,
flush uncertainty and faulted sessions before EP5 orchestration. Global/hostile fencing
and physical durability remain unqualified.


EP2/EP3 is pushed as 4642b09. EP4 owned append is implemented; read
docs/implementation/M2_EMBEDDED_HOST_APPEND_VALIDATION.md. Exact expected positions and
current owner/scope bind proposals; only actual successful flush/readback returns host append
acknowledgment. Post-entry uncertainty irreversibly faults this lifetime and closes admissions;
read-only reconciliation never rearms it or adopts a prefix. Reopened empty roots cannot gain
initializer first-write eligibility. Backend results/healthy bytes are not dispatch permits.
Next EP5 prototypes internal plan/descriptor-bound single dispatch with actual operation drain;
no replay, automatic route/write resume, global fencing or reclamation is enabled.


EP5 internal live-ticket orchestration is implemented under ADR-026; read
docs/implementation/M2_EMBEDDED_HOST_ORCHESTRATION_VALIDATION.md. Only its own real plan and
secret owner-bound ticket can dispatch after acknowledged exact intent/authorization. A host-wide
executor reservation also protects active-attempt journal mutations via its opaque registration.
No execution runs under journal/lifetime locks. Every actual executor remains registered through
completion; shutdown/fault before admission blocks invocation. Preserve separate pipeline receipt,
host acknowledgments and primary/secondary errors; no claimed ticket is rearmed. Next add stopped
persisted restart reconciliation/new-ID retry under fresh exclusion; never recreate tickets from
saved descriptors or resume writers from a match. Direct/hostile bypass and HA2 remain unqualified.


EP4/EP5 is pushed as 24feda2. EP6 design is specified in ADR-027 and
 docs/implementation/M2_EMBEDDED_HOST_RESTART_CONTRACT.md; runtime remains pending.
Implement stopped reconciliation through a restricted opaque lifetime registration with
admissions closed, never by asserting an already reconciled outcome. Ordinary append keeps
its existing admission requirements. Transfer/observe/absence saves retain EP4 exact-position
and sticky uncertainty rules. A retry requires a new real plan and fresh ID after qualified
absence; never recreate a ticket, fabricate a receipt or automatically resume writers.


EP6-A restricted stopped append is implemented; read
 docs/implementation/M2_EMBEDDED_HOST_STOPPED_APPEND_VALIDATION.md. Keep its registration
exclusive with admission/dispatch, reject foreign/disposed tokens and empty reopened history,
and retain EP4 exact-position/uncertainty checks. It is a low-level boundary, not independent
proof of inspection/absence. Next compose the actual inspector and explicit fresh-plan retry;
process-kill qualification remains pending. Never synthesize receipts from observations.


EP6-B actual stopped inspection/outcome composition is implemented; read
 docs/implementation/M2_EMBEDDED_HOST_RESTART_INSPECTION_VALIDATION.md. Reconcile only the
latest recorded request attempt and its exact snapshot; transfer is not dispatch. Known matches
save observations, never receipts. Absence needs fresh bound stable-namespace/no-retained-proof
facts plus excluded publishers and repeat inspection. Unknown/contradictory results stay stopped.
Next implement explicit fresh-plan/fresh-ID retry after acknowledged absence; do not reuse plans,
automatically open admissions or claim process-kill qualification from in-process save failures.


EP6-A/B is pushed as 8d38762. EP6-C explicit retry is implemented; read
 docs/implementation/M2_EMBEDDED_HOST_RETRY_VALIDATION.md. Require a current-owner exact latest
absent snapshot, fresh exclusion/namespace evidence and separate explicit administrative readiness.
Prepare a new real plan/ID with identical descriptor otherwise; recheck before Record and use its
captured exact journal position. Never adopt a newer head, replay an unknown intent acknowledgment,
rearm consumed tickets or automatically resume writers. Next qualify combined process-kill gaps.


EP6-C is pushed as 5977451. EP6-D adds combined actual process-kill qualification; read
 docs/implementation/M2_EMBEDDED_HOST_RESTART_PROCESS_VALIDATION.md. Keep H=1 process rows
separate from H=0/H=3 functional evidence and physical power-loss claims. Transfer ACK is the
next outcome validation checkpoint; complete Written frames are not flush acknowledgments.
Reopen always stays stopped; separate reconciliation must preserve source/artifact/candidate
bytes and never reconstruct tickets. Next audit consuming-host selection/work authority before
application integration, public release or automatic writer admission.


Host restart checkpoint 2026-10-29 includes EP6-D (1,055 focused cases per platform, 72 new
process rows). Read the latest docs/AGENT_HANDOVER.md checkpoint before historical next-step
notes. Next audit actual consuming-host selected-root/work authority. XDM 4.0 assessment is in
 docs/implementation/M2_XDM40_COMPATIBILITY_ASSESSMENT.md; REQ-009 is proposed qualification,
not a pin upgrade or general XDM/JSON persistence decision. Keep stopped reopen and all existing
release/physical durability boundaries. Git HEAD identifies this checkpoint commit after push.


User selected the internal embedded pilot for application authority (2026-10-29).
Read ADR-028 and docs/implementation/M2_EMBEDDED_PILOT_AUTHORITY_CONTRACT.md.
This is design only: preserve existing host-root roles and frozen BXHM/BXHJ/store bytes.
Next EP7-A is a pure supplied-evidence classifier with every output stopped and no I/O.
Acceptance obligations survive completion; administrative drain is not application work
accounting. Separate authority persistence/actual consumer remain pending; no routing,
writer resume, public API or reclamation is enabled. The prior Windows 1,894-case full run
covers unchanged runtime; Linux fresh execution remains Docker-blocked.


EP7-A internal pure classifier is implemented; read
docs/implementation/M2_EMBEDDED_PILOT_AUTHORITY_CLASSIFICATION_VALIDATION.md. Inputs remain
supplied facts, every outcome stays stopped, completed/no-effect acceptance is retained and
unknown branch accounting never becomes zero. The 1,024-record model limit is not a wire
format. Next EP7-B specifies separate bounded application-authority bytes/transitions and
provisioning/commit rules before persistence. No existing format/public API, route or writer
admission changes. Keep all histories and CanReclaim=false.

EP7-A final Windows qualification passes 119 focused cases and all 2,013 full-solution
tests (1,393 Storage, 593 Integration, 27 Xdm), zero failures/skips. Formatting, strict
docs and portability pass; source fingerprints remain unchanged through full execution.
Linux fresh execution is Docker-blocked, not a current pass. See machine evidence in
docs/implementation/m2-embedded-pilot-authority-classification-results.json.


EP7-B specification is defined by ADR-029 and
docs/implementation/M2_APPLICATION_AUTHORITY_FORMAT_V1.md; read its validation report.
BXAM0001 metadata is 112 bytes and BXAJ0001 frame envelope is 144+N; separate authority root
roles do not change existing BXHM/BXHJ/store formats. Preserve both new metadata fixture
hashes and independent Python provenance. They are not complete histories or authority.
Next implement the pure codec/full-history validator with independent frame/history vectors
before EP7-C persistence. No counter reset, baseline replacement, work replay, routing or
automatic writer resume; every decoded result remains stopped and CanReclaim=false.


ApplicationAuthorityCodec now implements pure metadata/frame/TLV and full-history validation;
read docs/implementation/M2_APPLICATION_AUTHORITY_CODEC_VALIDATION.md. Preserve all four new
frame/history fixture hashes and original metadata pins. Frames validate shape only; whole
histories retain every acceptance, and all decoded results stay stopped. Unknown observations
and outcomes require reconciliation; no actual acknowledgment/authority is inferred from bytes.
Next EP7-C starts with the new owner-bound application child lifetime/existing-root inspection
before provisioning/conditional persistence. No filesystem ownership, writer, routing, work
execution, public API or reclamation is enabled by the codec. CanReclaim=false.

Codec qualification: 166 focused cases pass; successful Windows project executions cover
2,179 tests (1,559 Storage, 593 Integration, 27 Xdm). Initial solution execution had two
existing restore process timeouts; the unchanged full Integration rerun passed the same
593 IDs. Preserve that distinction and original failures; no single green full-solution
command is claimed. Formatting/docs/portability pass, Linux execution is Docker-blocked,
and source fingerprints remain unchanged. Next EP7-C paired lifetime/existing-root gate.


EP7-C existing-root paired authority inspection is implemented under ADR-030; read
docs/implementation/M2_APPLICATION_AUTHORITY_LIFETIME_VALIDATION.md. The opaque application
mode excludes admin dispatch/append/read/stopped modes and retains parent ownership through
actual child reads. Authority roles must be regular/single-link with stable native IDs;
Windows fixed NTFS and Linux x64/arm64 ext-family/overlayfs/tmpfs are the implementation scope.
Windows native checks are exercised; Linux remains Docker-blocked, including three guarded
FIFO rows. No provisioning/append, actual work or writer admission is added. Next no-overwrite
authority provisioning/initializer qualification; existing OpenExisting cannot create/repair,
empty reopen cannot grant first-write authority, all histories remain and CanReclaim=false.

EP7-C final evidence supersedes its earlier Docker blocker: full Windows passes 2,250 tests;
final-source Windows and isolated Linux focused runs pass 429 cases each. Linux x64 overlayfs
executes all new FIFO/process/native identity bodies; Windows has three new FIFO guards.
Docker was started detached using the cached pinned SDK image, with read-only source/cache
and no container network; backend remains running. ARM64/other allowed filesystems and a
new full Linux suite are not qualified. Only XML returns comments changed after full Windows
compilation; final focused IDs/bodies match, with both hashes retained. No provisioning/append
or writer admission is enabled; next explicit no-overwrite initializer qualification.


EP7-C provisioning slice (2026-10-29): read ADR-031 and
docs/implementation/M2_APPLICATION_AUTHORITY_PROVISIONING_VALIDATION.md. Explicit Provision
is separate from OpenExisting and rejects every existing target. Retain failed partial
roots; no cleanup/resume. Transfer the CreateNew owner handle directly. Only the successful
live instance may reserve its initializer once; this is a real retained operation, not
enrollment/write authority or a verified application baseline. Reopened empty roots cannot
reserve. Actual process interruption, partial writes, acknowledgment loss and independent
creators are qualified in the validation report. Next bind real baseline evidence to
owner-bound first-enrollment preparation before conditional append.
All writers remain stopped; no public API/routing/reclamation or wire changes.


Owner-bound first-enrollment preparation (2026-10-29): read ADR-032 and
docs/implementation/M2_APPLICATION_AUTHORITY_ENROLLMENT_PREPARATION.md plus validation.
Legacy-only PrepareFirstEnrollment consumes the original initializer reservation and binds
a real live MigrationSourceFreeze with its exact registered sealed capture. Actual history/
closure/native writer identity is verified; operational assertions remain caller-supplied.
The retained object is caller-thread confined, reference-bound and single-use on Check.
Source owner/freeze are borrowed dependencies; losing them invalidates consumption. No
source/coordinator open, capture, recovery, repair, append or cleanup occurs during preparation.
All writers stay stopped. Next design conditional first-enrollment append/uncertainty;
never execute descriptions, infer prior-work truth or enable public APIs/routing/reclamation.


ADR-033 and docs/implementation/M2_APPLICATION_AUTHORITY_ENROLLMENT_APPEND_DESIGN.md
now specify retained source exclusion and conditional first enrollment (design only).
Current borrowed preparations cannot append or be upgraded. Next EF1 adds only opt-in
actual source/freeze child retention, deferred original writer-stream close and owner stop
latch; no authority writes. Arming must make closure races deterministic with actual retained
operations, no source I/O under authority locks, and no automatic unfreeze after an armed
result. Preserve no-retainer behavior, ordinary caller-thread confinement and independent
readers. EF2-EF4, public/host/archive/retirement gates remain open; retain all histories.


EF1 source retention is implemented; read docs/implementation/M2_ENROLLMENT_SOURCE_RETENTION.md
and its validation report. RetainForEnrollment requires the actual live owner/freeze and
registered nonnull capture, once per freeze. InspectState checks the original native handle;
source-local Arm is memory-only and requires prior native inspection. Actual child drain
defers original writer close and freeze release. Arming or native-inspection fault latches
the original owner stopped; no clearing/resume API. Close errors/no-op close adapters report
Unknown with logical retention and no automatic close retry. No-retainer behavior and borrowed
preparation remain unchanged. EF1 has no authority writes. Next EF2 distinct retained
preparation and atomic authority/parent/source admission; EF3/EF4 and all public/host/archive/
retirement gates stay open. Retain every history; CanReclaim=false.


## EF2 Retained Enrollment Admission (2026-10-29)

Read docs/implementation/M2_RETAINED_ENROLLMENT_ADMISSION.md and its validation.
Separate retained preparation consumes the original initializer and transfers actual resources
to one execution. Nonblocking authority -> parent -> source admission performs no I/O/callbacks.
Never upgrade borrowed plans or recreate authority from descriptions. Source close uncertainty
retains authority/parent operations. No authority output yet; EF3 first-frame output is next.
Operational assertions remain supplied assumptions; preserve all history and existing formats.


## EF3 First Enrollment (2026-10-30)

Read docs/implementation/M2_FIRST_ENROLLMENT_APPEND.md and its validation. AppendFirstEnrollment
consumes only the actual retained preparation, arms once and emits exactly one existing-v1
Enroll frame at the exact empty head. No source/admin I/O or lifecycle/source gate under the
authority serializer. Mark possible output before write hooks; flush and verify full exact
history/native roles. Confirm cleanup before acknowledgment; unknown source release retains
parent/authority operations even without output. Acquisition History remains immutable; the
receipt is separate. Every dispatched result is terminal/stopped, never replayed or repaired.
Next EF4 observed fault traces/process/ACK-loss/contention qualification. No public API,
application admission, persistent fencing, source replacement or reclamation is enabled.


## EF4 Enrollment Qualification (2026-10-30)

Read docs/implementation/M2_FIRST_ENROLLMENT_FAULT_VALIDATION.md. Qualification observes six
actual seam edges and all 386 incomplete prefixes of the observed 387-byte frame, preserving
exact survivors/inventory and read-only reopen. Forty-two killed plus six racing publishers
run per focused process suite. Eight Linux inode-substitution bodies are Windows host guards,
not Windows native passes. Three closing-during-I/O schedules retain actual owners to drain.
Runtime/formats are unchanged; ProcessCrash only, no power-loss/ENOSPC certification.
Next consolidate EF1-EF4 readiness and remaining host/restart contracts before further writers.
No public API, application admission, actual routing, source replacement or reclamation.


## EF1-EF4 Readiness Review (2026-10-30)

Read docs/implementation/M2_ENROLLMENT_READINESS_REVIEW.md and its machine evidence.
The review verifies 51 TRX artifacts and all 2,468 Windows IDs/679 focused Linux IDs, not new
runtime suites. Display names are not unique. Public metadata is still 95/95; frozen local
binaries are not archived release evidence. ER-002: retained ValidateEmptyEnrollmentAuthority
locks _readGate then ReadOwned visits protected ancestry. The authority-only output phase is
clean, but the broader ADR-033 preflight boundary needs hardening before another writer.
Next move protected-path preflight work outside authority serialization while retaining actual
owners and exact authority checks; qualify stale/closing/corrupt schedules. ER-003 direct
parent/authority role-close faults remain unqualified; source close faults are covered.
ER-004 stopped restart/owner handoff remains later. No public API, work admission, routing,
persistent fence, source replacement or reclamation is enabled; preserve every history.


## ER-002 Retained Preflight Hardening (2026-10-30)

Read docs/implementation/M2_RETAINED_ENROLLMENT_PREFLIGHT.md and validation. The actual source
child is registered before protected inspection. Placement -> serialized authority-only empty
check -> placement -> serialized empty recheck keeps all owners retained across unlocked
phases. Retained paths must not call generic ReadOwned under _readGate; generic readers and
borrowed preparation remain unchanged. Probe callbacks are internal/default-null, outside all
monitors and bound to actual resources; never make them a public extension/capability.
Final preflight failure may consume the freeze registration but creates no retry authority.
After arm the original-owner stop latch is permanent. Next ER-003 direct authority/parent
close-fault qualification, then ER-004 restart/owner-handoff contract. No new writer/public
API, application admission, routing, source replacement or reclamation is enabled.


## ER-003 Direct Role-Release Qualification (2026-10-30)

Read docs/implementation/M2_ENROLLMENT_ROLE_RELEASE.md and validation. A lifetime-bound internal
IRetainedRoleLeaseClose seam receives actual acquired streams; production null/default directly
disposes as before. No mutable installation, public provider or descriptor authority exists.
Before/after/no-op close errors fault release tasks, never retry or infer physical absence.
Source release precedes authority and parent; authority failure keeps the parent registration.
Required cleanup failure suppresses append receipt with ReleaseUnknown even without possible
output. A later independent owner-close failure reports via its task without rewriting a past
qualified publication receipt. Fixture handle teardown is not live recovery or logical release
confirmation. Next ER-004 stopped restart/enrollment reconciliation and owner-handoff contract;
no new writer/public API, work/routing admission, source replacement or reclamation is enabled.


## ER-004 Stopped Restart and Handoff Design (2026-10-30)

Read ADR-034 and docs/implementation/M2_STOPPED_ENROLLMENT_RESTART_CONTRACT.md before restart
or post-enrollment authority changes. Design only: next SR1 is a pure internal stopped
classifier with no I/O/callbacks, capabilities, receipt synthesis or write resume. SR2 actual
owner/source-bound evidence, SR3 single-use handoff preparation and SR4 conditional output
remain unimplemented. Valid empty reopen never recreates an initializer; exact Enroll is
observed state, not acknowledgment. Corruption rejects without repair; unsupported valid or
unknown state needs reconciliation. Source stop latch remains permanent for the original
object; fresh owner availability is not durable fencing or confirmed prior release. Use
existing v1 TransferOwner only in a separately qualified future writer; preserve every history
and CanReclaim=false. No public API, actual routing/work admission or retirement is enabled.


## SR1 Pure Enrollment Restart Classifier (2026-10-30)

EnrollmentRestartClassifier is internal and pure; read M2_ENROLLMENT_RESTART_CLASSIFIER_VALIDATION.md.
Inputs are supplied assumptions, not verified storage/host facts. Every assessment remains
stopped, with no receipt/initializer/live ownership or permission. Exact expected positions,
source/capture correlation and explicit unknown/contradictory facts stay distinct. Empty
reopen never re-enrolls; valid later history is unsupported, not automatically corrupt. Optional
successor validation does not make a handoff plan. Next SR2 actual retained owner/source-bound
stopped evidence and freshness/race qualification; SR3/SR4 remain later. Preserve formats,
original stop latch, all histories and CanReclaim=false. No routing/work/public API is enabled.


## SR2 Owned Restart Observation Design (2026-10-30)

Read ADR-035 and docs/implementation/M2_OWNED_RESTART_OBSERVATION_DESIGN.md before SR2 code.
Design only: next SR2-A adds a separate actual source child with permanent stopped admission,
original usable stream retention and deferred once-only close. Never recreate the original
freeze/capture association or relax its checks. A cutover freeze alone permits backup and is
insufficient. SR2-B/C later pair actual parent/authority/source operations and qualify read-only
verification/races. Never call live OpenCore/recovery during observation; it may publish CURRENT.
Enroll InitialHistoryDigest is the exact inventory.bin hash, not the manifest hash. Keep
source/capture inspection outside all lifecycle/journal gates. No receipt, initializer,
handoff/write authority, source latch clear, public API, routing/work or reclamation is enabled.


## SR2-A Actual Restart Source Retention (2026-10-30)

RetainedRestartSource is internal source-only ownership, not paired observation. Read
M2_RESTART_SOURCE_RETENTION_VALIDATION.md. It binds an actual fresh source, no capture or
initializer; shares the original writer close/task and permanent stopped latch. All cooperating
mutations/publishers remain blocked after drain. Native inspection is outside the source gate;
current-owner checks reject closing/foreign/released state. Close failures stay unknown with no
retry. Existing enrollment/capture association and original armed-owner rejection remain strict.
Next SR2-B actual parent/authority/source-bound complete proof and freshness. Do not call the
source-only blocking Acquire under peer lifetime gates. Preserve all bytes/history, public
formats and CanReclaim=false; no actual routing/work/handoff authority or persistent fence.


## SR2-B Paired Stopped Restart Observation (2026-10-30)

Read M2_OWNED_RESTART_OBSERVATION_VALIDATION.md. Existing-root single-use observation binds
actual paired reads and SR2-A source retention; source acquisition is outside peer gates.
Derive actual role/head/ownership facts, keep host assertions distinct, and never call live
OpenCore/recovery or recreate a frozen capture. Source/capture proof and placement remain
outside serializers; the last placement precedes complete second proof. Native parent role
pins and exact acquired journals are rechecked; final source check is nonblocking under peers.
Nonterminal admin stages force reconciliation and cannot be hidden by caller work flags.
Descriptors/forged scopes cannot consume actual registrations; all results stay stopped/inert.
Unknown source close retains the pair with no retry. Next SR2-C native/process/concurrency
qualification; SR3/SR4, public/host/archive release and all retirement remain open. No format,
write-resume, actual routing/work acceptance, source replacement or reclamation is enabled.


## SR2-C Owned Restart Qualification (2026-10-30)

Read M2_OWNED_RESTART_QUALIFICATION_VALIDATION.md. Eleven same-byte native roles/roots at two
unlocked boundaries execute 22 Linux bodies; Windows has 22 explicit sharing guards, not native
substitution evidence. Five ordered closure endpoints and twelve simultaneous attempts retain
actual roles through drain. Ten process cases launch 38 workers per qualified run, including 14
kills and 14 fresh stopped observations; independent holders/races preserve bytes and old reads.
Explicit source open/recovery precedes OPENED/read-only measurement. No exhaustive scheduler,
reader-absence, power-loss/real ENOSPC or stronger-policy claim. Product source/formats unchanged.
Next consolidate SR1/SR2 readiness/evidence before SR3. No receipt/scope replay, write resume,
actual routing/work, source replacement or reclamation; retain all history and CanReclaim=false.


## SR1/SR2 Readiness Review (2026-10-30)

Read docs/implementation/M2_STOPPED_RESTART_READINESS_REVIEW.md before SR3. Review-only:
64 retained artifacts and 15 historical source inputs verify; 2529->2752 Windows IDs retain
all 223 additions, also present in focused Linux 394. Same IDs do not prove same platform bodies;
22 Windows guards remain separate from 22 Linux native executions. Initial restore timeouts
are failed attempts with passing project rechecks, never a clean unfiltered command.
Observe is one-attempt; _attempted=true does not mean success. Its description is inert and
Dispose currently drains the actual source/pair immediately. Before SR3 code define a private
success-only proof state, fresh revalidation/host facts, actual plan-child drain after claim,
closing linearization and live successor/session binding. First Enroll uses actual parent
Context.SessionId; a supplied successor GUID is not live owner authority. Next SR3-A contract/
ADR design. No handoff output, public API, work/routing, latch clear or reclamation is enabled.


## SR3-A Handoff Preparation Design (2026-10-30)

ADR-036 and docs/implementation/M2_STOPPED_HANDOFF_PREPARATION_CONTRACT.md define
success-only private proof, actual child lifetime and successor = actual paired parent
Context.SessionId. Design only. No descriptor/attempted flag creates proof or capability.
Preserve the single actual paired read and original usable source writer; close-before-claim
refuses, claim-before-close retains actual executor ownership. No source rearm or append.
Next SR3-B1 implements private proof and resource-child accounting before preparation/claim.
SR4 writer and host/public/archive/fencing/retirement remain separate gates; retain all history.
