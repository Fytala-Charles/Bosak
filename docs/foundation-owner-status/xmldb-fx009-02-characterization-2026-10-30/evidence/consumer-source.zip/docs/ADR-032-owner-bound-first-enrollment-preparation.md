# ADR-032: Owner-Bound First-Enrollment Preparation from a Frozen Legacy Baseline

**Status:** Accepted internal read-only legacy preparation; Windows full-project and Linux focused qualification recorded
**Date:** 2026-10-29
**Deciders:** Authorized continuation of the internal embedded pilot

## Context

[REQ-007](FEATURE_REQUESTS.md#req-007-mutable-epoch-authority-and-recovery),
[ADR-028](ADR-028-embedded-pilot-selection-and-work-authority.md) and
[ADR-031](ADR-031-application-authority-provisioning-and-initializer.md) require a real
baseline before first enrollment. A fresh authority root and a disposable reservation do
not identify a source history or reconcile earlier application work. Existing MG5 already
provides a caller-thread source freeze, one registered sealed capture, and strict read-only
live-source/history checks. Reuse those established proofs without opening/recovering stores.

## Decision

Add internal PrepareFirstEnrollment and single-use CheckFirstEnrollment on the successful
original authority initializer. Preparation consumes its one live reservation before source
I/O and keeps that actual authority/admin operation registered until explicit disposal.
Require the actual live MigrationSourceFreeze and its exact registered FrozenMigrationCapture.
The caller retains both source owner and freeze; losing either invalidates consumption.
This slice supports a legacy source only. No epoch-source preparation is implied.

Read the sealed capture with strict closure/history validation, compare its registered
inventory bytes, and require the live source's document ID, sequence, manifest and complete
retained data to match. Inspect the real source writer handle and its path identity through
the existing owner gate. Require regular/single-link empty admission and stable native
source directory/owner identities. Reject unpublished staging/temporary files without cleanup.
Do not create captures, open coordinators, recover, repair, publish or write during preparation.

Bind exact authority/admin session/scope, protected source/capture keys, configured admission
key, reconciliation ID/digest and explicit fresh ingress/executor/publisher/prior-work/queue
assertions. Those assertions remain caller-supplied operational assumptions. They are not
validated host facts, inferred zero work, or proof of old-reader absence. The real data proof
and the claimed operational reconciliation remain distinguishable.

Generate a fresh library baseline ID and a bounded v1 Enroll entry at owner generation one,
source selection revision one. Its source history commitment is SHA-256 of the exact registered
legacy inventory. The private evidence digest additionally binds baseline ID, authority path/
keys/native role identities, admin position/session, source native identities and reconciliation.
Pre-encode/decode in memory using the existing whole-history codec; no new wire layout.

Retain the exact preparation object under its owner. Consumption checks caller thread and
actual reference, atomically burns the object before revalidation, then repeats real source,
authority and scope checks. Descriptions/copies/forged objects cannot reconstruct registration.
A real consumption failure faults the authority session. All results keep writers stopped.

## Consequences

### Positive

- Reuse established bounded complete-history inspection and actual cooperative source ownership.
- Bind diagnostic enrollment intent to real source bytes without adding a persistence path.
- Keep authority/admin ownership through actual preparation lifetime and disposal races.

### Negative / Accepted Costs

- Callers must retain thread-confined source scopes and reconcile application facts externally.
- Failed/abandoned initialization cannot be retried or reconstructed from clean bytes.
- Real epoch-source preparation, conditional append, acknowledgment and host work admission remain open.
- Native identity has the existing supported-filesystem limits and cannot detect coherent offline rollback.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Trust source path/head and supplied booleans alone | Does not verify retained history or actual writer ownership |
| Create/recover a source or backup during preparation | Violates read-only preparation and obscures side-effect uncertainty |
| Deserialize an entry/description into executable authority | Loses actual owner, freeze, single-use and lifetime binding |
| Add append in the same step | Baseline preparation and conditional save/uncertainty need separate qualification |

## References

- [Preparation contract](implementation/M2_APPLICATION_AUTHORITY_ENROLLMENT_PREPARATION.md)
- [Validation](implementation/M2_APPLICATION_AUTHORITY_ENROLLMENT_VALIDATION.md)
- [MG5 acceptance](implementation/M2_MIGRATION_CUTOVER_ACCEPTANCE.md)
- [Existing authority format](implementation/M2_APPLICATION_AUTHORITY_FORMAT_V1.md)
