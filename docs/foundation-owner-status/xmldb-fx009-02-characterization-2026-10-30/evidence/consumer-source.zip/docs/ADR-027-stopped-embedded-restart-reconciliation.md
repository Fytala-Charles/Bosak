# ADR-027: Stopped Embedded Restart Reconciliation

**Status:** Accepted internal EP6-A/B/C runtime with EP6-D H1 process qualification; application integration pending
**Date:** 2026-10-29
**Deciders:** Authorized continuation of the single-process embedded pilot

## Context

REQ-006/007 and [ADR-026](ADR-026-live-plan-bound-embedded-orchestration.md) require
restart handling without reconstructing executable plans. Existing owned append requires
administrative admissions and evidence that outcomes are already reconciled. Using it to
establish those outcomes would open admissions too early and create a circular prerequisite.
A readable complete journal is structural evidence, not acknowledgment of a previous call.

## Decision

Implement a separate stopped reconciliation session under the retained host owner. Its
capability is process-local, private-constructor and lifetime-bound. Acquisition requires
fresh bound controlled-writer/publisher, prior-executor exclusion and empty/drained queue
facts, closed administrative admissions, no active executor and an exact current journal
position. It does not require an already reconciled outcome. These are trusted host facts,
not proof against hostile publishers. Ordinary append/dispatch must remain excluded while
the session exists; shutdown retains ownership until its actual inspection/save work drains.
The session cannot execute plans or enable writers.

Use the existing v1 TransferOwner, ObserveKnown and ReconcileAbsent transitions. Each save
uses the same exact-position, full-history, flush/readback and sticky uncertainty rules as
EP4, through a restricted stopped path. Do not globally relax ordinary append admission.
A failed or unknown write stops the session without replay; reopen and inspect the full
history under new exclusion. Never repair/truncate a corrupt tail or promote a prefix.

Transfer the exact latest attempt to the current owner before saving its outcome, advancing
revision and owner generation with checked arithmetic. Preserve descriptor, request,
receipt and observation; Recorded/DispatchAuthorized become Uncertain as v1 requires.
A transfer is not dispatch authorization and never recreates an old ticket. If the latest
attempt already belongs to this session, require its exact snapshot rather than fabricating
a transfer. All prior attempts for a request and the complete resource inventory remain in scope.

Inspect the pinned artifact and destination using the exact persisted attempt ID. Save a
KnownOperationMatched result as ObserveKnown only where the existing transition allows it;
never synthesize an actual pipeline receipt or Acknowledge from inspection. NotObserved is
only a point-in-time observation: save ReconcileAbsent only after separately validating fresh
publisher exclusion, stable destination namespace, no retained publication evidence and no
contradictory receipt/observation. Malformed, inaccessible, foreign-operation, artifact-only
or conflicting results leave the request stopped. Previously terminal snapshots must agree
with fresh inspection; disagreement requires external reconciliation, not regression.

After acknowledged absence, an explicit retry prepares a new real plan with a fresh ID and
the identical v1 input/destination descriptor, retaining the request ID and every old record.
Recheck the artifact pin, exact reconciled snapshot and exclusion before recording the new
intent. Do not reuse a consumed plan or dispatch a saved descriptor. A later independent
admission decision may permit this new administrative workflow; reconciliation itself never
opens administrative admissions, routes data or resumes database writers. Empty reopened
journals remain stopped without initializer first-write eligibility.

## Consequences

### Positive

- Reconciliation can establish an outcome with admissions closed and without circular facts.
- Existing wire mappings, frozen readers, immutable fixtures and public APIs remain unchanged.
- Unknown save outcomes retain candidates and cannot silently duplicate publication.

### Negative / Accepted Costs

- A restricted append capability and mutually exclusive lifetime mode need new tests.
- Stopped observations do not solve application routing, accepted-work accounting or HA.
- Unavailable or contradictory evidence requires intervention; no automatic cleanup is added.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Open ordinary admissions to reconcile | Requires the result before establishing it and exposes dispatch too early |
| Recreate a ticket from the saved descriptor | Loses the real opaque single-use plan and owner binding |
| Treat absent path or healthy bytes as sufficient | Does not exclude late publishers or establish a prior acknowledgment |
| Generate a receipt from a known-operation match | Confuses read-only observation with an actual returned pipeline receipt |

## References

- [EP6 contract and qualification plan](implementation/M2_EMBEDDED_HOST_RESTART_CONTRACT.md)
- [EP5 evidence](implementation/M2_EMBEDDED_HOST_ORCHESTRATION_VALIDATION.md)
- [Owned append decision](ADR-025-owned-conditional-host-journal-append.md)
