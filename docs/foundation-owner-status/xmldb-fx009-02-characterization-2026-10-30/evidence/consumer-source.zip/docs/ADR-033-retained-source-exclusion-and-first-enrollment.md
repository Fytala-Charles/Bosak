# ADR-033: Retained Source Exclusion and Conditional First Enrollment

**Status:** Accepted; bounded EF1-EF4, ER-002 and ER-003 implemented internally; ER-004/host/release gates remain open
**Date:** 2026-10-29
**Deciders:** Authorized continuation of the internal embedded pilot

## Context

[REQ-007](FEATURE_REQUESTS.md#req-007-mutable-epoch-authority-and-recovery),
[ADR-029](ADR-029-separate-application-authority-journal-v1.md) and
[ADR-032](ADR-032-owner-bound-first-enrollment-preparation.md) require continuous actual
exclusion between source validation and authority publication. Current preparation borrows
MigrationSourceFreeze: its Dispose clears the source token, while EmbeddedXmlDatabase.Dispose
immediately closes the writer handle. An authority operation does not retain either source
condition. CheckFirstEnrollment consumes a read-only observation, not an append capability.

Current authority inspection also owns an immutable acquisition snapshot. Letting an ordinary
Inspect race the first append would compare the new head with its old empty snapshot. Source
CreateBackup is deliberately allowed by the existing migration freeze; data mutation guards
alone therefore do not exclude every cooperating publisher.

## Decision

Introduce an opt-in, reference-bound retained legacy-source registration in a later EF1 step.
Acquire it under the original source gate from the actual live freeze and registered capture.
Retain both its mutation exclusion and the exact original writer FileStream, without closing/
reopening or relying on a separately pinned already-disposed stream. Caller disposal closes
new admission immediately and defers the relevant token/handle release until actual children
drain. No-retainer behavior and existing borrowed preparation remain unchanged.

Use a distinct retained preparation in EF2; never upgrade existing borrowed preparations or
reconstruct a guard from descriptions. One atomic dispatch decision checks authority, parent
and source closing/exclusion under brief lifetime gates in the existing compatible order:
authority lifetime -> parent lifetime -> source coordinator. It performs no I/O or callbacks.
If closing wins, no append is admitted. If arming wins, its real operation survives later
disposal and retains every owner through actual execution and cleanup.

Arming latches the original source owner stopped. Guard release or caller freeze disposal
cannot resume its mutations or publishers after acknowledged, refused-after-arm or uncertain
execution. This first slice has no latch-clear/handoff API. The latch is process-local,
not a persisted fence; another explicit owner or old binary is not fenced by it. All outcomes
keep application admissions stopped, and operational assertions remain caller assumptions.

EF3 may append exactly one existing-v1 Enroll frame to an exact empty authority under its
serializer. Complete source/capture verification occurs outside authority locks while the
retained guard spans the gap. Check exact metadata/native roles/head/EOF, validate the bounded
frame in memory, mark possible-output uncertainty before delegating write, flush to disk and
verify exact bytes plus full history before acknowledging. No data-store invocation, callback,
source gate or artifact inspection occurs under the authority serializer.

A possible-write failure is terminal uncertainty: retain all bytes, poison the session and
never retry, truncate, overwrite, adopt a plausible prefix or synthesize acknowledgment.
Successful first append is also a terminal stopped writer session for this bounded prototype;
its receipt records the confirmed head, and generic inspection cannot reuse the old empty
snapshot. Dispose/reopen may inspect the complete journal read-only. Neither path admits work.

## Consequences

### Positive

- Actual source ownership and exclusion span the unlocked validation-to-publication gap.
- Disposal has a defined linearization point and cannot cancel an admitted executor by dropping leases.
- Single-frame output uses frozen v1 bytes and explicit acknowledgment/uncertainty semantics.

### Negative / Accepted Costs

- Legacy source closing needs opt-in child accounting and deferred original-handle disposal.
- An armed original source owner stays stopped until explicit disposal; no in-place rearm is provided.
- Existing borrowed preparations cannot be used for append; a fresh initializer must choose one mode.
- This design still does not prove host ingress/prior-work truth, old-binary exclusion or reader absence.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Check borrowed preparation, then write | Caller disposal can release source exclusion in the gap |
| Pin only a native handle or retain only the freeze token | Does not retain both usable original ownership and mutation/publisher exclusion |
| Hold a source monitor across journal I/O | Couples locks and I/O, violating the established source/authority boundary |
| Clear the freeze automatically after execution | Can resume source writes after acknowledged or uncertain enrollment |
| Add a durable source fence or new journal role | Changes frozen formats and claims unsupported persistent fencing |
| Enable a general append session now | Exceeds first-enrollment scope and needs separate host/restart qualification |

## References

- [Retained exclusion and append contract](implementation/M2_APPLICATION_AUTHORITY_ENROLLMENT_APPEND_DESIGN.md)
- [Design review and evidence](implementation/M2_APPLICATION_AUTHORITY_ENROLLMENT_APPEND_DESIGN_REVIEW.md)
- [Current read-only preparation](implementation/M2_APPLICATION_AUTHORITY_ENROLLMENT_PREPARATION.md)
- [Frozen authority v1](implementation/M2_APPLICATION_AUTHORITY_FORMAT_V1.md)

EF1 follow-up (2026-10-29): [implemented contract](implementation/M2_ENROLLMENT_SOURCE_RETENTION.md)
and [validation](implementation/M2_ENROLLMENT_SOURCE_RETENTION_VALIDATION.md) add the
source-only lifecycle primitive. Source-local Arm is not the EF2 atomic dispatch decision;
existing borrowed preparations still cannot append. No authority output is implemented.

EF3 follow-up (2026-10-30): [implemented first writer](implementation/M2_FIRST_ENROLLMENT_APPEND.md)
and [validation](implementation/M2_FIRST_ENROLLMENT_APPEND_VALIDATION.md) add conditional
single-frame output with terminal stopped outcomes and release uncertainty. EF4 is next.

EF4 follow-up (2026-10-30): [local fault/process qualification](implementation/M2_FIRST_ENROLLMENT_FAULT_VALIDATION.md)
records observed call edges, every incomplete frame prefix, native identity substitutions,
I/O closing schedules, repeated process/ACK-loss and independent owner races. Qualification
adds no runtime/public API and grants no routing, work admission or reclamation authority.

Readiness follow-up (2026-10-30): [consolidated review](implementation/M2_ENROLLMENT_READINESS_REVIEW.md)
verifies retained evidence and identifies ER-002 protected-ancestor inspection under the shared
preflight monitor and ER-003 missing direct authority/parent close-fault injection. No lock
policy relaxation is accepted. Address ER-002 before another writer; public/host/release and
all retirement gates remain open.

ER-002 follow-up (2026-10-30): [retained preflight hardening](implementation/M2_RETAINED_ENROLLMENT_PREFLIGHT.md)
registers the source child before protected inspection and separates unlocked placement from
serialized authority-only checks, including a final recheck. Generic readers remain unchanged.
Direct authority/parent close-error qualification remains ER-003; no additional writer is enabled.

ER-003 follow-up (2026-10-30): [role-release qualification](implementation/M2_ENROLLMENT_ROLE_RELEASE.md)
adds lifetime-bound direct authority/parent close faults, managed no-op detection and explicit
receipt/release-task outcomes. No general writer or public contract changes. Next ER-004
stopped restart/enrollment and owner-handoff design; all host/release/retirement gates remain open.

ER-004 design follow-up (2026-10-30): [stopped restart/handoff contract](implementation/M2_STOPPED_ENROLLMENT_RESTART_CONTRACT.md)
separates pure stopped assessment from actual retained evidence and future owner transfer.
Next SR1 pure classifier. No additional writer, resumed source or new capability is implemented.
