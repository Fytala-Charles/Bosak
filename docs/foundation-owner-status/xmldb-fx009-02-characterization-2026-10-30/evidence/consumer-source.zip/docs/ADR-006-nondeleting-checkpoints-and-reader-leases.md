# ADR-006: Non-Deleting Checkpoints and Reader Leases

- Date: 2026-10-26
- Status: Implemented experimental checkpoint/lease gate; reclamation remains deferred
- Request: REQ-005

## Context

M2 already has scalar WAL commits, retained generations and explicit filesystem barriers.
The next safe step is a verifiable checkpoint path and reader protection without deleting
history. The original checkpoint design calls for replay parity before truncation and
cross-process protection for snapshots that outlive their coordinator.

## Decision: Immutable Self-Contained Checkpoints

CreateCheckpoint publishes at the current nonzero committed sequence. Copy and validate
a complete M1-format materialization into staging, write a versioned SHA-256 anchor,
then publish the immutable checkpoint directory and a separately checksummed selector.
Anchors bind document/sequence, the complete manifest hash, the WAL record hash at S,
the digest of the entire prefix and the referenced materialization format. See the
[byte contract](implementation/M2_CHECKPOINT_FORMAT_V1.md).

The selector is an optimization hint, not a new commit authority. FullJournal remains
the default recovery mode and ignores optional checkpoints. PreferCheckpoint independently
validates the selected materialization and every retained canonical WAL record. It checks
the prefix digest at S, then uses the checkpoint copy to skip earlier generation
validation/materialization and replays or validates the suffix. LastRecovery exposes
selected sequence, records checked, materializations checked/replayed and rejection.

Missing/corrupt optional checkpoint artifacts or a failed prefix binding trigger full
recovery. Full history must independently succeed; a checkpoint cannot authorize missing,
corrupt or semantically inconsistent WAL. A stale valid selector still replays through
the latest commit. Do not guess the newest directory. Existing immutable checkpoints
cannot be overwritten; repeat publication at the same sequence validates/reuses them.

No old manifest/fragment/WAL bytes change, and no history is removed. The checkpoint
holds its own fragment/directory copies; it does not depend on an old generation being
present. A later write can use this verified materialization as its source.

## Decision: Snapshot-Owned Stable Leases

BeginRead and BeginWrite acquire a shared OS-backed lease for the selected logical
sequence while under coordinator selection. The lease belongs to the snapshot and is
released only on snapshot/transaction completion, not coordinator disposal. FileShare.Read
permits cooperative readers; an exclusive open is blocked while any holder is alive,
including in another process. Process exit releases its handles.

Lease files contain a versioned immutable identity (DocumentId, sequence). Publish the
complete identity via a temporary file before opening its shared handle. Never unlink,
replace or truncate a stable lease file: that could split lock identity. A corrupt
stable identity fails closed. File/barrier errors during reader acquisition fault the
coordinator and leave no partially published canonical identity.

Stronger-mode adoption synchronizes lease directory entries but skips writes/flushes
of stable lock identity files with active shared handles. Their identity was
flushed before publication; treating them as ordinary writable data would conflict
with real readers. Temporary unpublished files remain eligible for normal synchronization.

## Compatibility and Scope

Direct pre-adoption M1 snapshots and older binaries do not own these new leases. Retain
the original base and all generations. Private generation/checkpoint paths are not an
alternative supported public snapshot API. This is cooperative protection, not a defense
against external administrators unlinking files or noncooperating old processes.

No public retirement/GC method is added. Before future deletion, protect live roots,
checkpoint dependencies and lease holders; add redundant anchors, an old-reader
compatibility transition and a crash/fault-tested retirement protocol. Checkpoint
recovery still requires the complete retained WAL prefix; truncation is not supported.

## Validation and Costs

Tests compare checkpoint and full recovery, reject corrupt/missing required WAL, fall
back from optional corruption, verify fixed byte fixtures and survive checkpoint
publication kills. Shared leases survive coordinator disposal and block exclusive
opens in separate processes until snapshot disposal or process termination. Storage
fault sweeps cover checkpoint and lease publication, including real partial writes.

The existing SDK 10.0.301 image is run in an isolated Linux filesystem with read-only
source/package inputs and no container network. Native Linux directory fsync is now
executed on Docker overlayfs; the same code is also tested on Windows. This does not
establish a physical power-loss or production-filesystem guarantee. Checkpoint copies
increase disk use; full prefix validation remains O(number of retained WAL records).

*Last updated: 2026-10-26*
