# ADR-021: Host Attempt Ledger and Publisher Exclusion

**Status:** Accepted host-neutral contract; actual host selection and HA1/HA2 integration remain open
**Date:** 2026-10-28
**Deciders:** Bosak.XmlDb implementation within authorized M2 contract design work

## Context

[REQ-006 and REQ-007](FEATURE_REQUESTS.md), [ADR-019](ADR-019-explicit-mutable-api-and-host-cutover-boundary.md)
and [ADR-020](ADR-020-planned-administrative-attempt-correlation.md) require host-owned restart
reconciliation. RC1-RC3 establish process-local single dispatch and preknown publication IDs.
They do not persist host intent, prevent a stale process publishing, or make routing atomic
with storage publication. No actual consuming host or authoritative external fence is present.

## Decision

Specify a host-owned, versioned ledger outside store and sealed artifact roots. Persist an
immutable attempt descriptor and its host request relation before authorizing dispatch.
Use conditional revision changes to record dispatch authorization exactly once. Treat an
uncertain ledger write as uncertain until an authoritative read resolves it; do not dispatch
on a failed/unknown save. Record library acknowledgments separately from observations.
A saved descriptor never reconstructs an executable plan after restart.

Require exclusion over the complete publication scope: all workers, delayed/queued jobs,
retries and overlapping destinations for the same request. A ledger ownership token can
reject stale ledger writers, but the current library and filesystem rename do not validate
that token. Lease expiry or token replacement therefore cannot fence an already running
publisher. Before retry, establish actual prior-executor termination or an independently
proven mechanism preventing every old publisher from reaching publication. Otherwise stop
and reconcile. Administrative publisher exclusion and database-writer exclusion are separate
requirements; neither is supplied by this ledger design.

Keep request, attempt, publication and route/work states distinct. No transaction spans ledger,
store rename and host route change. Conditional writes and authoritative observations resolve
each uncertainty independently. Routing, accepted-work accounting, readiness and source
freeze must be re-established under ADR-019; ledger state grants no write-resume permission.

The [host contract](implementation/M2_HOST_ATTEMPT_LEDGER_CONTRACT.md) specifies logical fields,
transitions, restart rules, fault scenarios and implementation gates. This introduces no
production codec, database dependency, root file, automatic recovery or public API.

## Consequences

### Positive

- Dispatch has a defined durable-intent boundary and explicit uncertain states.
- An ownership lease is no longer mistaken for an effective publisher fence.
- Known-operation correlation survives restart without fabricating library acknowledgments.
- Host-neutral requirements can be reviewed before selecting a persistence/backend technology.

### Negative / Accepted Costs

- The host must provide durable conditional persistence, exclusion and work/route authorities.
- A lost process-local plan can strand an authorized attempt with no safe replay.
- Unknown durability, old publisher reachability or conflicting observations prolong downtime.
- Actual HA1 host selection and HA2 crash/fencing qualification remain open.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Serialize and replay executable plans | Violates owner-bound single use; may duplicate uncertain publication |
| Put the ledger inside the store/artifact | Creates new store authority and violates sealed input/layout boundaries |
| Treat lease expiry as fencing | Existing publication path accepts no fencing token and old workers may continue |
| Dispatch before confirmed durable intent | A crash can leave publication without retained correlation |
| Deduplicate by request ID or equal artifact | Physical attempts and independent publications are distinct |
| Choose a server/database now | No actual consuming host or durability requirement has been selected |

## References

- [Host/API boundary](implementation/M2_PUBLIC_API_AND_HOST_CUTOVER_CONTRACT.md)
- [Attempt contract](implementation/M2_ADMINISTRATIVE_ATTEMPT_CONTRACT.md)
- [RC3 qualification](implementation/M2_ADMINISTRATIVE_ATTEMPT_PROCESS_VALIDATION.md)
- [Host ledger contract](implementation/M2_HOST_ATTEMPT_LEDGER_CONTRACT.md)


HA1 model follow-up (2026-10-28): [pure classification validation](implementation/M2_HOST_ATTEMPT_LEDGER_MODEL_VALIDATION.md)
qualifies supplied-evidence rules internally with 180 new cases. This implements no backend
CAS, persistence or effective fence. Actual host selection and HA2 remain open. Next is an
internal conditional-transition harness for revision and lost-acknowledgment protocol tests.


HA1 transition follow-up (2026-10-28): [in-memory protocol validation](implementation/M2_HOST_LEDGER_TRANSITION_VALIDATION.md)
adds exact-revision transitions and simulated lost acknowledgments with 83 new cases. It
provides no durability or effective fence. Next is test-only integration with planned execution;
actual host/backend selection and HA2 remain open. Earlier next-step notes retain their scope.


HA1 test integration follow-up (2026-10-28): [actual planned execution tests](implementation/M2_HOST_LEDGER_PLANNED_EXECUTION_VALIDATION.md)
qualify modeled save boundaries with real library publication. This closes the bounded local
integration step, not HA1 host selection or HA2. Next identify actual host/backend, exclusion
and route/work authorities. No production orchestration or durable ledger is implemented.


Host selection follow-up (2026-10-28): user selected single-process embedded first.
[ADR-022](ADR-022-single-process-embedded-pilot-host.md) defines the pilot scope; backend
codec, ownership/persistence implementation and HA2 application qualification remain open.
