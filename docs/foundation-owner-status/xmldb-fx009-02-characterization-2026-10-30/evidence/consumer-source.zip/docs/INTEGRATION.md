<div align="center">
  <img src="../assets/logos/fytala-logo-color-dark.svg" width="100" alt="Fytala Bosak.XmlDb Integration Guide">
  <br><br>
  <h1>Bosak.XmlDb Integration Guide</h1>
  <p>Embedded native XML fragment storage and persistent XDM navigation.</p>
</div>

## SR3-A Stopped Handoff Preparation Design (2026-10-30)

[ADR-036](ADR-036-stopped-handoff-preparation-and-lifetime.md) and
[contract](implementation/M2_STOPPED_HANDOFF_PREPARATION_CONTRACT.md) define private success-only
proof, actual preparation/plan/executor child drain and the actual paired parent session as
successor. Closing before claim refuses; claim-before-close retains original usable handles
through completion. No runtime or format change. Readiness checkpoint `069332c` is committed
and pushed; this design is local/uncommitted. Next SR3-B1 implements private proof and child
lifetime before SR3-B2 preparation/claim, SR3-C qualification and the separate SR4 writer.
Prior Windows 2,752 and focused Linux 394 cases remain retained evidence, not fresh execution.
Host/public/archive/durable-fence and all retirement gates remain open; CanReclaim=false.

## SR1/SR2 Stopped Restart Readiness Review (2026-10-30)

[Review](implementation/M2_STOPPED_RESTART_READINESS_REVIEW.md) verifies 64 retained
artifacts, 15 historical source inputs and complete Windows test-ID growth from 2,529 to 2,752.
All 223 additions appear in the latest 394-case focused Linux catalog; platform bodies/guards
remain distinct. Initial restore timeouts stay separate from passing project rechecks.
No runtime changes or fresh execution. Next SR3-A defines success-only proof consumption,
actual plan-child drain and successor/session binding before preparation code. Existing
observation/descriptor success grants no handoff or write authority. Host/public/archive and
all retirement gates remain open. Checkpoint `7da1b17` is committed/pushed; this review is local.

## SR2-C Native, Process and Disposal Qualification (2026-10-30)

[Validation](implementation/M2_OWNED_RESTART_QUALIFICATION_VALIDATION.md) adds 38 cases
without product source changes. Eleven native roles/roots are replaced with identical bytes
at two boundaries: 22 actual Linux executions, separately recorded as 22 Windows guards.
Ordered and repeated concurrent disposal, 14 process kills and 14 fresh observations and independent
holders/races preserve bytes/inventory and keep every result stopped. Final focused runs pass
189 Windows and 394 Linux cases.
All 2,752 Windows cases pass across complete project runs. The initial restore timeouts are
retained and pass focused plus complete Integration rechecks. Next consolidate SR1/SR2
readiness before SR3 handoff preparation. Host/public/archive/retirement gates remain open.
Checkpoint `de5c9a4` is committed/pushed; SR2-C qualification is local/uncommitted.

## SR2-B Paired Stopped Restart Observation (2026-10-30)

[Implementation and validation](implementation/M2_OWNED_RESTART_OBSERVATION_VALIDATION.md)
bind actual parent/authority/source retention through read-only complete source/sealed-capture
proof and fresh exact journal/native identity checks. All results stay stopped and inert;
no capture association, receipt, initializer or handoff capability is recreated. Nonterminal
administrative history forces reconciliation despite caller assertions. All 58 new cases and
282 focused Windows cases pass; 356 focused Linux cases pass, including all 58 new bodies.
All 2,714 Windows cases pass across complete project runs. The initial restore timeout is
retained and passes focused plus complete Integration rechecks. Next SR2-C native/process/race
qualification; SR3/SR4 and host/public/archive/retirement gates remain open. Checkpoint `a31203b`
is committed/pushed; SR2-B is local/uncommitted. Public and frozen formats remain unchanged.

## SR2-A Actual Restart Source Retention (2026-10-30)

[Implementation and validation](implementation/M2_RESTART_SOURCE_RETENTION_VALIDATION.md)
add a separate restart-only actual source child, permanent stopped admission and original
usable writer retention through real drain. No old capture association or initializer is
recreated. Native source inspection runs outside its gate; close uncertainty never retries or
clears the stop. All 38 new cases and 152 focused Windows cases pass; 268 focused Linux cases
also pass, including all 38 new bodies. All 2,656 Windows cases pass across complete project runs. The initial restore timeout is
retained and passes focused plus complete Integration rechecks.
This source-only slice does not implement paired restart observation. Next SR2-B full actual
parent/authority/source-bound proof and freshness; SR2-C/SR3/SR4 and host/public/archive/retirement
gates remain open. Checkpoint `bc5e490` is committed/pushed; SR2-A is local/uncommitted.

## SR2 Actual Ownership Integration Design (2026-10-30)

[ADR-035](ADR-035-owned-stopped-restart-observation.md),
[design](implementation/M2_OWNED_RESTART_OBSERVATION_DESIGN.md) and
[review](implementation/M2_OWNED_RESTART_OBSERVATION_REVIEW.md) specify a separate
restart-only retained source child and paired stopped observation. Existing freeze/capture
association and initializer checks remain strict. Verification must not hide live recovery
writes or confuse the inventory commitment with the manifest hash. Design only; no runtime
change. Next SR2-A source lifetime primitive, then SR2-B/C observation and qualification;
SR3/SR4 and all host/public/archive/retirement gates remain open.
Checkpoint `b0c94bd` is committed/pushed. SR2 design is local/uncommitted; prior 2,618 Windows
passing cases across complete project runs and 451 focused Linux cases are retained evidence,
not new execution. All source/candidate/WAL histories remain retained, CanReclaim=false.

## SR1 Pure Stopped Enrollment Assessment (2026-10-30)

[Implementation and validation](implementation/M2_ENROLLMENT_RESTART_CLASSIFIER_VALIDATION.md)
add an internal pure classifier of supplied exact-head, source/capture and stopped-host facts.
Every result remains stopped and inert. Empty/unsupported/missing observations require
reconciliation; invalid history or contradictory facts refuse. No receipt, initializer, live
ownership, handoff plan or execution permission is recreated. All 89 new cases and 335 focused
Windows cases pass; 451 focused Linux cases also pass, including all 89 new bodies.
All 2,618 Windows cases pass across complete project runs. The initial restore timeout is
retained and passes focused plus complete Integration rechecks. Public/frozen formats and
actual source/authority lifetimes remain unchanged. Next SR2 actual owner-bound stopped
evidence; SR3/SR4 capability/output and host/public/archive/retirement gates remain open.
Checkpoint `100b39d` is committed/pushed; SR1 is local/uncommitted.

## ER-004 Stopped Restart and Owner Handoff Design (2026-10-30)

[ADR-034](ADR-034-stopped-enrollment-restart-and-owner-handoff.md) and the
[contract](implementation/M2_STOPPED_ENROLLMENT_RESTART_CONTRACT.md) define inert stopped
assessment, fresh actual ownership/exclusion and a separately gated future TransferOwner.
[Review](implementation/M2_STOPPED_ENROLLMENT_RESTART_REVIEW.md) records design checks;
no runtime, public API or frozen format changes. Valid Enroll bytes never recreate a receipt
or initializer. Empty/unsupported/uncertain restarts require reconciliation; corruption rejects
without repair. All histories remain retained. Next SR1 implements only the pure stopped
classifier; SR2-SR4 actual evidence, capability and output qualification remain unimplemented.
ER-003 checkpoint `edf0b72` is committed/pushed. Its 2,529 Windows passing cases across complete
project runs and 740 focused Linux cases remain prior execution evidence, with initial
Integration timeouts preserved separately. This design adds no runtime test cases.

## ER-003 Authority and Parent Release Qualification (2026-10-30)

[Contract](implementation/M2_ENROLLMENT_ROLE_RELEASE.md) and
[validation](implementation/M2_ENROLLMENT_ROLE_RELEASE_VALIDATION.md) add an actual-owner,
internal close seam and 42 direct role-close cases. Before/after/no-op errors suppress required
cleanup acknowledgment, preserve bytes and keep release uncertainty separate from physical
handle availability. All 2,529 Windows cases qualify across complete project runs and 740 broad
Linux cases pass, including all 42 new bodies per platform. Two initial restore timeouts are
retained and pass focused plus complete Integration rechecks. Production null/default close delegation and public/frozen contracts remain
unchanged. Next ER-004 defines stopped restart/enrollment reconciliation and owner handoff;
no further writer, work/routing admission, source replacement or reclamation is enabled.
Historical sections below retain their dated scope.

## ER-002 Retained Preflight Boundary (2026-10-30)

[Implementation](implementation/M2_RETAINED_ENROLLMENT_PREFLIGHT.md) and
[validation](implementation/M2_RETAINED_ENROLLMENT_PREFLIGHT_VALIDATION.md) move retained
protected-path inspection outside authority serialization. Actual source/parent/authority
ownership spans the unlocked phases; exact roles/metadata/empty head are checked again after
the last placement pass. All 2,487 Windows cases pass across complete project runs; 698 broad
Linux cases pass, including all 19 new bodies per platform. Two initial restore timeouts are
retained and pass focused plus complete Integration rechecks. Generic readers and frozen/public
contracts remain unchanged. Next ER-003 qualifies direct authority/parent close errors;
ER-004 and all host/public/archive/retirement gates remain open. Historical sections below
retain their dated scope.

## EF1-EF4 Consolidated Readiness Review (2026-10-30)

[Review](implementation/M2_ENROLLMENT_READINESS_REVIEW.md) verifies 51 retained TRX
artifacts, 256 unchanged source/build/fixture inputs and all 2,468 Windows test IDs; 679 Linux
focused IDs are retained separately. Fresh public metadata remains 95/95, with no additions.
No runtime suite or feature is added by the review. ER-002 identifies protected-ancestor I/O
under the shared authority monitor during retained preflight; next harden that boundary under
ADR-033. Direct authority/parent close-fault qualification and stopped restart/owner handoff
remain later gaps. No public API, application admission, routing or reclamation is enabled.
Historical sections below retain their dated scope.

## EF4 Enrollment Fault and Process Qualification (2026-10-30)

[Qualification](implementation/M2_FIRST_ENROLLMENT_FAULT_VALIDATION.md) adds observed
call-edge/all-prefix fault sweeps, actual Linux inode substitutions, cross-thread I/O closing,
repeated process/ACK-loss boundaries and independent competing publishers. The 387-byte frame
produces 393 sweep attempts; 34 new catalog cases include eight Windows host guards. Each
focused process run uses 48 workers. Production runtime/format/public surface is unchanged.
All 2,468 Windows and 679 isolated Linux focused cases pass; eight new Windows rows are
explicit host guards. Formatting/docs/portability and frozen fixture checks pass. Next consolidate
EF1-EF4 readiness and remaining host/restart contracts before another authority writer.
No application admission, actual routing or reclamation is enabled. Historical sections below
retain their dated scope.

## EF3 Conditional First Enrollment (2026-10-30)

[Implemented contract](implementation/M2_FIRST_ENROLLMENT_APPEND.md) and
[validation](implementation/M2_FIRST_ENROLLMENT_APPEND_VALIDATION.md) add one terminal
stopped Enroll append from the actual retained preparation. Exact empty-head/native-role checks,
flush/readback/full-history validation and cleanup confirmation precede acknowledgment.
Possible output or release uncertainty retains bytes and prevents receipt synthesis/retry.
All 2,434 Windows and 645 isolated Linux focused cases pass, including all 45 new cases per
platform. Formatting/docs/portability and frozen fixture checks pass. No application work admission or public API is enabled. Next EF4 qualifies observed
persistence positions, process interruption/ACK loss and competing owners. Real host/archive/
retirement gates remain open. Historical sections below retain their dated scope.

## EF2 Retained Enrollment Admission (2026-10-29)

[Implemented contract](implementation/M2_RETAINED_ENROLLMENT_ADMISSION.md) adds a
separate owner-bound retained preparation, resource transfer to actual execution and a
nonblocking authority/parent/source arm decision. Wrapper disposal retains all three original
owners through actual execution; unknown source close retains authority/parent operations.
All 2,389 Windows and 600 isolated Linux focused cases pass, including 29 new cases per
platform. Formatting/docs/portability and frozen fixture checks pass. No authority output or application admission is enabled. Next EF3 implements the
conditional first Enroll frame; EF4 persistence qualification and real host/public/archive/
retirement gates remain open. Historical sections below retain their dated scope.

## EF1 Retained Source Lifetime (2026-10-29)

[Implemented contract](implementation/M2_ENROLLMENT_SOURCE_RETENTION.md) and
[validation](implementation/M2_ENROLLMENT_SOURCE_RETENTION_VALIDATION.md)
add opt-in source/freeze children, deferred original writer-stream close and a source-owner
stop latch. Native identity, actual drain and release uncertainty remain explicit. All 2,360
Windows tests and 571 isolated Linux focused cases pass, including 29 new cases per platform.
Formatting/docs/portability and frozen fixture checks pass. No authority output or application admission is enabled. Next EF2 integrates a
separate retained preparation and atomic dispatch admission, still without authority writes.
Historical design/qualification blocks below retain their dated scope.

## Retained Source Exclusion and First-Enrollment Design (2026-10-29)

[ADR-033](ADR-033-retained-source-exclusion-and-first-enrollment.md) and
[contract](implementation/M2_APPLICATION_AUTHORITY_ENROLLMENT_APPEND_DESIGN.md)
specify opt-in source/freeze retention, one atomic arm decision, a stopped original-source
latch and exact one-frame conditional append with terminal uncertainty. This is design only;
current preparation remains read-only. The [review](implementation/M2_APPLICATION_AUTHORITY_ENROLLMENT_APPEND_DESIGN_REVIEW.md)
records 24 future acceptance scenarios, not test passes. Runtime/build inputs remain at the
qualified 2,331-case Windows / 542-case focused Linux baseline. Next EF1 implements source
retention/deferred close/stop-latch qualification with no authority writes. EF2-EF4, actual
host control, public APIs, archived compatibility and all reclamation remain open.

## Owner-Bound First-Enrollment Preparation (2026-10-29)

[ADR-032](ADR-032-owner-bound-first-enrollment-preparation.md) and
[validation](implementation/M2_APPLICATION_AUTHORITY_ENROLLMENT_VALIDATION.md)
add read-only preparation against a real frozen legacy store and its registered sealed
capture, actual source owner identity and scoped reconciliation assertions. The actual
owner-bound preparation is single-use and retains authority/admin leases. All 2,331 Windows
cases pass across full project runs; 542 isolated Linux cases pass, including all 35 new cases
per platform. One existing Windows kill case failed once and passed focused/complete reruns;
the validation report retains the observation. Operational
assertions remain supplied assumptions; no enrollment/append or application work is enabled.
Next design conditional first-enrollment save/uncertainty with continuing real ownership and
fresh explicit operational evidence. Historical next-action blocks retain their dated scope.

## EP7-C Explicit Authority Provisioning Slice (2026-10-29)

[ADR-031](ADR-031-application-authority-provisioning-and-initializer.md) and
[provisioning validation](implementation/M2_APPLICATION_AUTHORITY_PROVISIONING_VALIDATION.md)
add separate no-overwrite absent-root creation, direct exclusive-owner handoff, retained
partial state and a single-use live initializer reservation that holds actual paired leases.
All 2,296 Windows cases pass across full project runs; 475 focused Linux cases pass, including
46 new cases per platform. One existing Windows release case failed once and passed focused
and complete reruns; the validation report retains that observation.
All writers stay stopped. No enrollment/append or real application baseline is established.
Actual process interruption, acknowledgment loss and independent creators are now qualified.
Next bind a real operational baseline to owner-bound first-enrollment preparation before
conditional append. Historical next-action sections below retain their dated scope.

## EP7-C Paired Existing-Root Authority Inspection (2026-10-29)

[ADR-030](ADR-030-paired-read-only-application-authority-ownership.md) and
[lifetime validation](implementation/M2_APPLICATION_AUTHORITY_LIFETIME_VALIDATION.md)
add opaque parent-mode exclusion, real authority ownership/native identity checks, read-only
full-history inspection and actual-read drain. All 429 focused Windows cases pass, including
71 new cases (three Windows FIFO guards). Full Windows passes all 2,250 tests; fresh isolated
Linux passes 429 focused cases with actual FIFO bodies. Formatting/docs/portability and fixture
checks pass; exact scope and XML-only final test documentation are recorded in the report. Next explicit no-overwrite provisioning/initializer
qualification before append; no authority writes, routing or application admission is added.

## Application-Authority Pure Codec (2026-10-29)

[Codec validation](implementation/M2_APPLICATION_AUTHORITY_CODEC_VALIDATION.md) records
strict metadata/frame/TLV decoding and complete-history transitions with retained work obligations.
Four independent frame/history vectors and 166 focused cases pass. Successful Windows project
runs cover all 2,179 tests after a full Integration rerun cleared two initial timeouts. The
report retains those failures and the Docker-blocked Linux result; docs/formatting/portability pass. All decoded results stay stopped;
existing formats/public APIs remain unchanged. Next EP7-C starts with the new owner-bound
application child lifetime/existing-root boundary before provisioning and persistence.

## EP7-B Application-Authority Format Specification (2026-10-29)

[ADR-029](ADR-029-separate-application-authority-journal-v1.md) and the
[v1 contract](implementation/M2_APPLICATION_AUTHORITY_FORMAT_V1.md) specify separate
metadata/frames, retained work transitions, no-overwrite provisioning and uncertain-save rules.
[Validation](implementation/M2_APPLICATION_AUTHORITY_FORMAT_VALIDATION.md) records two
independent metadata-only vectors and 13 passing Python checks. No production codec or
persistence is implemented. Existing C# remains at the passing 2,013-test Windows baseline.
Next implement the pure codec/full-history validator with independent frame/history vectors
before EP7-C owned persistence. Existing host/store bytes and all histories remain protected.

## EP7-A Pure Pilot Authority Classification (2026-10-29)

[Classification validation](implementation/M2_EMBEDDED_PILOT_AUTHORITY_CLASSIFICATION_VALIDATION.md)
records the internal supplied-evidence model: exact authority/root/baseline/publication bindings,
nullable branch accounting, retained acceptance obligations and stopped-only outcomes.
All 119 focused Windows cases pass; the fresh full Windows regression passes 2,013 tests.
Formatting, strict docs and portability pass; Linux execution remains Docker-blocked. Next EP7-B specifies separate application-authority bytes/transitions
and provisioning/commit rules. No authority persistence, routing, work execution or public API
is implemented; existing host/store formats and all histories remain protected.

## Internal Embedded Pilot Authority Design (2026-10-29)

The user selected the internal embedded pilot. [ADR-028](ADR-028-embedded-pilot-selection-and-work-authority.md)
and its [authority contract](implementation/M2_EMBEDDED_PILOT_AUTHORITY_CONTRACT.md) define
separate selected-root/work accounting with acceptance before mutation, retained obligations
and stopped restart. This is design only; existing journal/store bytes and public APIs stay
unchanged. Next EP7-A is a pure supplied-evidence classifier with no I/O or write authority;
format, persistence and actual consuming-host execution remain later gates. The preceding
1,894-test Windows regression covers unchanged runtime, not this proposed backend.

## Post-EP6-D Readiness Review (2026-10-29)

The [current audit](implementation/M2_POST_EP6_READINESS_REVIEW.md) reviews checkpoint `4598346` and confirms that the next gate is
a consuming-host selected-root/work-authority contract. Administrative operation drain and
publication reconciliation do not establish application selection or accepted-work accounting.
Fresh Windows full regression passes all 1,894 tests; Linux execution is blocked by the
unavailable Docker engine. Formatting, strict documentation and portability pass. Historical
RC/EP reports retain their original scope; no runtime/API/format or release gate changes here.

## 1. Status and Dependencies

## Host Restart Checkpoint (2026-10-29)

EP6-C is pushed as `5977451`; this checkpoint includes the completed EP6-D process tests and
documentation. All 1,055 focused cases passed per Windows/Linux platform (732 Storage,
323 Integration), including 72 new process cases. Formatting and strict documentation/portability
checks passed. No production source, public API, package pin or wire format changed in EP6-D.
Hosted run `40822530134` was blocked before runner execution by account payment/spending limits.

The [XDM 4.0 assessment](implementation/M2_XDM40_COMPATIBILITY_ASSESSMENT.md)
records existing Bosak foundations and proposed provider qualification (REQ-009). It does not
claim full current-draft conformance or introduce persistent JSON/general XDM storage.

After restart, inspect `git status --short` and `git log -1`, then read this handover and
[EP6-D evidence](implementation/M2_EMBEDDED_HOST_RESTART_PROCESS_VALIDATION.md).
Next: audit consuming-host selected-root authority and accepted-work accounting before adding
application integration. Reopened stores/host journals stay stopped; no automatic retry, route
change, writer resumption or reclamation is authorized by these tests. Proprietary licensing,
Bosak 1.26.2 pins and disabled packaging remain fixed. Earlier sections are historical step
records; this checkpoint supersedes their delivery status and next-action wording.

## EP6-D Restart/Retry Process Qualification (2026-10-29)

EP6-C is pushed as `5977451`. [EP6-D validation](implementation/M2_EMBEDDED_HOST_RESTART_PROCESS_VALIDATION.md)
adds 72 actual process-kill cases across both roles at H=1, covering transfer, known/absent
outcomes, fresh retry intent and execution acknowledgment gaps. Reopen remains stopped;
separate reconciliation retains data and never recreates execution tickets. All 1,055 focused
cases pass per Windows/Linux platform. EP6-D is included in this restart checkpoint. Next audit the consuming application's selected-root/work-accounting gate;
production routing, writer resumption, public release and physical durability remain open.

## EP6-C Explicit Fresh-Plan Retry (2026-10-29)

EP6-A/B is pushed as `8d38762`. [EP6-C validation](implementation/M2_EMBEDDED_HOST_RETRY_VALIDATION.md)
adds explicit retry preparation with a fresh real plan/attempt ID after exact qualified absence.
It retains request/pin/destination, reinspects before recording and uses an exact-position save
to exclude duplicate retry intents across fronts. 22 new cases cover success, changed facts,
concurrency and lost intent acknowledgment. All 983 focused cases pass per Windows/Linux platform.
EP6-C remains local/uncommitted. Next qualify
process termination across the combined restart/retry workflow; automatic retry/writer resume
and application routing remain disabled.

## EP6-B Stopped Restart Inspection (2026-10-29)

[EP6-B validation](implementation/M2_EMBEDDED_HOST_RESTART_INSPECTION_VALIDATION.md)
adds actual pinned-operation inspection with acknowledged owner transfer and separate known
observation/qualified absence saves. Admissions stay closed; saved receipts cannot be synthesized
or replaced from inspection. 26 new Integration cases cover both roles/heads, contradictory
terminal facts and uncertain saves. All 961 focused cases pass on Windows and Linux.
Next: explicit fresh-plan retry after qualified absence;
retry runtime and process-kill qualification remain pending. EP6-A/B remain local/uncommitted.

## EP6-A Stopped Append Boundary (2026-10-29)

The EP6 contract is pushed as `22eeddf`. [EP6-A validation](implementation/M2_EMBEDDED_HOST_STOPPED_APPEND_VALIDATION.md)
adds exclusive stopped-session registration and restricted transfer/observation/absence saves,
without opening administrative admissions. 25 new cases cover evidence, stale/foreign tokens,
concurrency, uncertainty and shutdown drain. All 935 focused cases pass on Windows and Linux.
Inspector composition, explicit fresh-plan retry
and process-kill qualification remain pending. EP6-A changes are local/uncommitted.

## EP6 Stopped Restart Design (2026-10-29)

EP4/EP5 is committed and pushed as `24feda2`. The [EP6 contract](implementation/M2_EMBEDDED_HOST_RESTART_CONTRACT.md)
specifies a restricted reconciliation session with admissions closed, exact owner transfer,
separate known-operation observations and qualified absence before an explicit fresh-plan retry.
This is design only; restart persistence and retry runtime remain pending. Next implement the
stopped lifetime registration/append path and qualify its uncertainty and concurrency boundaries.
Existing 910 focused tests per platform remain the baseline; no new runtime coverage is claimed.
Hosted run `40793748444` could not start runner steps due to GitHub payment/spending limits.

## EP5 Live Plan-Bound Orchestration (2026-10-28)

[ADR-026](ADR-026-live-plan-bound-embedded-orchestration.md) and
[validation](implementation/M2_EMBEDDED_HOST_ORCHESTRATION_VALIDATION.md) add
opaque live tickets, exact acknowledged intent/authorization and one registered executor per
host. Actual receipts and host acknowledgments/errors remain separate; no saved plan is
reconstructed. 56 new cases qualify process gaps, duplicate use, active-attempt mutation and
shutdown; 910 focused cases pass per platform. Public metadata/wire formats stay unchanged.
Next: stopped persisted restart reconciliation and explicit new-ID retry after qualified
absence. HA2 application, global fencing, release and physical durability gates remain open.
EP4/EP5 was subsequently committed/pushed as `24feda2`; hosted CI remains billing-blocked.

## EP4 Owned Conditional Append (2026-10-28)

EP2/EP3 is committed/pushed as `4642b09`. [ADR-025](ADR-025-owned-conditional-host-journal-append.md)
and [append validation](implementation/M2_EMBEDDED_HOST_APPEND_VALIDATION.md)
now qualify exact-head append, actual file flush/readback and permanently faulted uncertain
sessions. 47 new cases cover write/flush failures, process interruption and test-only planned
publication composition; focused runs pass 854 cases per platform. Public Storage metadata
and wire formats stay unchanged. Reopened history remains stopped and never recreates a plan.
Next EP5 binds acknowledged ledger transitions to one registered live executor in an internal
orchestrator. HA2 application, release and physical durability gates remain open. EP4 is local.

## EP3 Explicit No-Overwrite Provisioning (2026-10-28)

[ADR-024](ADR-024-explicit-no-overwrite-host-provisioning.md) and
[validation](implementation/M2_EMBEDDED_HOST_PROVISIONING_VALIDATION.md) qualify
controlled absent-root creation, continuous CreateNew owner handoff and retained interrupted
state. 60 new tests cover partial writes, checkpoint/process kills and synchronized contenders;
807 focused cases pass per platform. Existing roots are never adopted or repaired by provision.
Reopened empty roots remain stopped; the live initializer diagnostic is not durable authority.
Next EP4 implements bounded conditional journal append and unknown-flush fault handling.
Physical durability, hostile namespace/global fencing, HA2 and release gates remain open.
Changes remain local/uncommitted; pushed baseline `2141eac` is unchanged.

## EP3 Existing Host Lifetime Ownership (2026-10-28)

[Ownership validation](implementation/M2_EMBEDDED_HOST_OWNERSHIP_VALIDATION.md)
adds existing-root cooperative exclusion, stopped administrative admissions and token-drained
shutdown. 50 new catalog cases cover process exit/active drain, aliases, invalid roots and
real publisher lifetimes. Focused runs pass 747 cases per platform; three FIFO rows execute
only on Linux. Public Storage metadata remains unchanged. No host files are provisioned,
repaired or appended by this implementation, and no global fence or writer resume is implied.
Next: explicit no-overwrite provisioning and interruption/contender tests before EP4 append.
EP2/EP3 work remains local/uncommitted; the pushed baseline remains `2141eac`.

## EP2 Internal Journal Codec (2026-10-28)

[Codec validation](implementation/M2_HOST_JOURNAL_CODEC_VALIDATION.md) now covers
strict bounded metadata/frame/TLV encoding, complete history checks and four independently
authored host-only vectors. 117 new codec cases pass; focused Windows/Linux runs pass 697
cases each. All 168 prior runtime/test/fixture files and public Storage metadata are unchanged.
Decoded history always keeps writers stopped; no codec output grants execution or proves
flush, anti-rollback or fencing. Next EP3 qualifies stable host-root lifetime ownership with
explicit provisioning boundaries and real process tests. EP4 durable append, HA2 application
integration and release gates remain open. EP2 design/codec changes remain local/uncommitted.

## Current Delivery and EP2 Journal Contract (2026-10-28)

The embedded profile is committed/pushed as `2141eac`. [ADR-023](ADR-023-bounded-embedded-host-journal-contract.md)
and the [journal contract](implementation/M2_EMBEDDED_HOST_JOURNAL_CONTRACT.md)
now define bounded canonical host-only frames, conditional transitions and explicit append/flush
uncertainty. Damaged tails are retained and block appends; restart never replays a plan.
No codec/writer, anti-rollback authority or durable-host proof is implemented. Next: a pure
internal codec with independent byte vectors, before filesystem persistence. This contract
is local/uncommitted; earlier delivery notes below retain their original scope.

## Current Delivery and Embedded Pilot Selection (2026-10-28)

RC2 through test-only HA1 integration is committed/pushed as `5d23ba2` on `origin/main`.
The user selected single-process embedded integration first. [ADR-022](ADR-022-single-process-embedded-pilot-host.md)
and the [pilot profile](implementation/M2_EMBEDDED_HOST_PROFILE.md) define one
controlled process, a dedicated host-state root, lifetime ownership and stopped restart
reconciliation. A local file journal is proposed; no backend or host is implemented yet.
Next EP2 defines its bounded codec, commit and corruption/rollback contract. M4 server,
HA2 application routing/work, public/archived-reader/release and retirement gates stay open.
This post-push profile is local; older uncommitted statements below describe their original
milestones. No runtime/test/fixture source changes or new runtime runs occur in this step.

## HA1 Ledger and Planned Execution Tests (2026-10-28)

[Test-only integration](implementation/M2_HOST_LEDGER_PLANNED_EXECUTION_VALIDATION.md)
now connects memory-ledger intent/authorization/receipt transitions to real owner-bound
migration and restore. 34 new cases cover lost-save acknowledgments, actual publication
uncertainty, new-ID retry after reconciled absence, concurrent authorizers and an active
publisher that defeats absence-based retry. Focused runs pass 448 cases per platform.
All prior runtime/test/fixture files are unchanged; no production adapter is introduced.
The bounded model/library integration is complete. Next: identify the actual consuming host,
durable backend, effective publisher exclusion and route/work authorities before HA2.
No memory commit proves durability or fencing. Changes remain local and uncommitted.

## HA1 Conditional Transition Harness (2026-10-28)

The internal [in-memory transition harness](implementation/M2_HOST_LEDGER_TRANSITION_VALIDATION.md)
now models exact-revision commits, single dispatch authorization, explicit read reconciliation
of lost acknowledgments and supplied-exclusion ownership transfer. 83 new tests cover commit
boundaries, concurrent winners, stale owners and preservation of receipts/observations;
414 focused cases pass per platform. Public Storage metadata remains unchanged.
No durable backend, executable permit, effective fence, routing or writer resume is supplied.
Next: test-only integration of these transitions with actual planned execution and lost-save
acknowledgments. Actual host selection and HA2 remain open; changes are uncommitted.

## HA1 Internal Ledger Model (2026-10-28)

The [ledger decision model](implementation/M2_HOST_ATTEMPT_LEDGER_MODEL_VALIDATION.md)
now checks supplied request/attempt/revision/owner bindings, durable-intent assumptions,
publication/receipt identity and prior-executor exclusion. All 180 new model tests pass;
focused validation covers 331 cases per platform, retaining earlier full-suite evidence at
its original scope. Every output keeps writers stopped and grants no executable authority.
Actual host selection, persistence and HA2 integration remain open. Next: an internal
conditional-transition harness for revision/CAS and lost-acknowledgment protocol tests.
Changes remain local and uncommitted; proprietary licensing and release gates are unchanged.

## HA1 Host Ledger Contract (2026-10-28)

[ADR-021](ADR-021-host-attempt-ledger-and-publisher-exclusion.md) and the
[host ledger contract](implementation/M2_HOST_ATTEMPT_LEDGER_CONTRACT.md) define
durable intent before dispatch, revision-checked ownership, separate acknowledgment and
observation records, and prior-executor exclusion before any fresh attempt. A ledger lease
cannot fence the current publication path; an old publisher must be stopped or effectively
excluded before takeover/retry. The 24 design scenarios are requirements, not runtime tests.
Actual host selection and HA2 integration remain open. Next: an internal pure supplied-evidence
ledger decision model and adversarial tests. No persistent backend, routing, public API or
writer resume is enabled. RC2/RC3 and this contract remain local and uncommitted.

Earlier milestone notes below retain their dated scope; the HA1 next step above is current.

RC2 implementation (2026-10-28): [planned administrative execution](implementation/M2_ADMINISTRATIVE_ATTEMPT_EXECUTION_VALIDATION.md) claims once, revalidates pinned intent before output and publishes the preknown ID in unchanged provenance fields. 31 new cases cover identity, early rejection and publication uncertainty. Next: RC3 process/restart and competing-publisher qualification; no public API or routing is enabled.

RC1 implementation (2026-10-28): [read-only preparation and single-dispatch state](implementation/M2_ADMINISTRATIVE_ATTEMPT_PLAN_VALIDATION.md) add bound attempt descriptors and owner/policy checks with 28 new cases. Claim is a pure local primitive; pipeline execution remains deferred. Next: RC2 planned execution with exact preknown IDs and publication-outcome tests.

Administrative attempt design (2026-10-28): [ADR-020](ADR-020-planned-administrative-attempt-correlation.md) and the [identity/retry contract](implementation/M2_ADMINISTRATIVE_ATTEMPT_CONTRACT.md) define preknown library-created attempt IDs, single-use process-local plans and descriptor-only restart inspection. No runtime API or caller-ID parameter is implemented. Next: RC1 read-only prepare and plan ownership/concurrency tests.

Current review (2026-10-28): [consolidated regression and API readiness](implementation/M2_CONSOLIDATED_API_READINESS_REVIEW.md) covers internal CA/HC/PA prototypes, fresh fault matrices, public metadata and documentation portability. Public mutable access, actual host routing, archived compatibility and release remain open. Next: request-to-publication operation correlation.

M1 and the first M2 scalar transaction APIs are implemented and tested locally. They are not a
published stable package. XmlDb uses the proprietary Fytala license; Bosak 1.26.2
retains Apache-2.0 licensing. Packaging stays disabled. See
[dependency ADR](ADR-003-pinned-bosak-dependency.md) and [M1 status](../M1_STATUS.md).

## 2. Import, Reopen and Query

```csharp
using Bosak.XmlDb.Storage;
using Bosak.XmlDb.Xdm;
using Bosak.XPath.Api;

// The store root must not already exist. The caller owns the input stream.
using (var input = File.OpenRead("order.xml"))
    XmlFragmentImporter.Import(input, "order-store", documentId: 1,
        linesPerFragment: 16, documentUri: "https://example.test/order.xml");

using var snapshot = ImmutableXmlSnapshot.Open("order-store");
var document = new PersistentXdmNode(snapshot);
var query = XPath31Expression.Compile("string(/SalesOrder/SalesOrderHeader/DocumentID)");
var id = query.Evaluate(document).StringValue;
var metrics = snapshot.Metrics; // LineFragmentReads == 0
```

The caller owns the snapshot and must retain it through lazy result consumption.
Snapshots are confined to one evaluation thread; concurrent access/disposal is not
supported. Use BindResult for evaluator-produced node sequences:

```csharp
var selection = XPath31Expression.Compile("/SalesOrder/SalesOrderLine");
var result = document.BindResult(selection.EvaluateNodes(document));
foreach (var item in result)
    Console.WriteLine(item.NodeValue.StringValue);
```

Direct adapter sequences and bound results reject enumeration after disposal. Raw
VM-owned sequences may materialize wrappers and are outside the adapter's enumeration
control; always bind escaping results. Node metadata/value access itself checks lifetime.

## 3. Snapshot-Scoped Document Resolution

```csharp
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Runtime.Vm;

var context = new EvaluationContext().WithFocus(XdmValue.FromNode(document), 1, 1);
context.DocumentLoader = document.ResolveDocument;
var expression = XPath31Expression.Compile(
    "doc('https://example.test/order.xml')/SalesOrder/SalesOrderHeader/DocumentID");
var value = expression.Evaluate(context);
```

ResolveDocument accepts only the exact nonempty stored absolute URI and returns the
same logical document within this snapshot. Other URIs raise FileNotFoundException;
the Bosak context maps document errors through its existing handling. No new URI
scheme, arbitrary file/network fallback, collection catalog or remote connector
behavior is introduced. Add explicit composition if an application needs other loaders.

## 4. Runnable Example and Measurements

```sh
dotnet run --project samples/EmbeddedQuickstart -c Release -- import order-store 500
dotnet run --project samples/EmbeddedQuickstart -c Release -- read order-store
dotnet run --project samples/EmbeddedQuickstart -c Release -- benchmark benchmark-store 500
```

Use new paths for imports/benchmarks. Read opens a persisted store without source XML.
Benchmark outputs JSON lines for in-memory, warm fragment cache and fresh fragment
cache queries. Metadata-open cost is reported separately; OS cache is not flushed.
See [measurements](../benchmarks/m1/README.md).

## 5. Limits, Compatibility and History

The importer uses a bounded XDocument and retains metadata in memory. It supports
untyped XML 1.0 and rejects DTDs/external entities. Serialization preserves logical
content, not CDATA boundaries or byte-identical lexical forms. A store root holds
one immutable document. M1 APIs remain immutable. Section 6 describes the limited M2 scalar transaction coordinator; structural updates, server and collection APIs remain unsupported. Follow [format 1.0](implementation/BINARY_FORMAT_V1.md) and
[ADR-002](ADR-002-immutable-format-and-snapshot.md) for limits and identity policy.

Use packages.lock.json and locked restore in CI. A source-reference development
workflow must explicitly verify the pinned commit; see ADR-003. Never follow main.

2026-10-30: [ER-003](implementation/M2_ENROLLMENT_ROLE_RELEASE.md) qualifies direct authority/
parent close errors through actual-lifetime internal test seams. Required cleanup failure
suppresses append acknowledgment even after a valid frame; late independent disposal faults
its release task without rewriting an earlier qualified publication receipt. No public or
wire change, retry or additional writer is added.

2026-10-30: [ER-002](implementation/M2_RETAINED_ENROLLMENT_PREFLIGHT.md) changes internal
retained preflight ordering: acquire the source child before protected inspection, inspect
placement outside authority monitors and recheck the exact empty authority after the final
unlocked pass. Failed initial validation can consume this freeze's one-shot registration;
no retry capability, public API or wire change is added. Generic readers are unchanged.

2026-10-30: [Readiness review](implementation/M2_ENROLLMENT_READINESS_REVIEW.md) changes no
runtime/API behavior. Public signatures remain 95/95; retained preflight lock-boundary and
release-fault qualification gaps remain explicit before further authority operations.

2026-10-30: [EF4](implementation/M2_FIRST_ENROLLMENT_FAULT_VALIDATION.md) qualifies observed
first-enrollment faults/process/restart behavior. Runtime/public surface and frozen layouts
are unchanged; no stronger durability or application admission is enabled.

2026-10-30: [EF3](implementation/M2_FIRST_ENROLLMENT_APPEND.md) adds internal AppendFirstEnrollment,
terminal stopped dispositions and a separate confirmed receipt. ProcessCrash only, exact one-frame
conditional output; no general append, public API, frozen layout change or release tag.

2026-10-29: [EF2](implementation/M2_RETAINED_ENROLLMENT_ADMISSION.md) adds internal
PrepareRetainedFirstEnrollment/TryArmRetainedFirstEnrollment and actual no-output execution.
Only original provisioned owners qualify; generic inspection stays excluded in retained mode.
No public API, format, authority output or release tag changes.

2026-10-29: [EF1](implementation/M2_ENROLLMENT_SOURCE_RETENTION.md) implements internal
RetainForEnrollment/InspectState/Arm and explicit ownership release diagnostics. Source
close/backup behavior changes only in opt-in mode. No public surface or format bytes change.

2026-10-29: [ADR-033](ADR-033-retained-source-exclusion-and-first-enrollment.md)
specifies source retention and one-frame conditional enrollment, design only. Proposed names
are internal; existing read-only APIs/bytes remain unchanged and no release tag is created.

2026-10-29: [ADR-032](ADR-032-owner-bound-first-enrollment-preparation.md) adds internal
PrepareFirstEnrollment/CheckFirstEnrollment with real frozen legacy history and actual source
owner identity. Both remain read-only, with all writers stopped and no new wire/public API.

2026-10-29: [ADR-031](ADR-031-application-authority-provisioning-and-initializer.md)
adds internal separate no-overwrite authority provisioning and a live-only read-only
initializer reservation with process-interruption/acknowledgment-loss qualification. Baseline
binding and enrollment append remain later gates; no public API or byte-format version is added and no release tag is created.

2026-10-26: M0 scaffold followed by M1 immutable provider, lifetime guards, differential
checks, process reopen and initial query measurements. No release tag was created.

## 6. Scalar Transactions and Recovered Reads

After a store is adopted for transactions, use the embedded coordinator rather than
ImmutableXmlSnapshot.Open on the base root:

```csharp
using var database = EmbeddedXmlDatabase.Open("order-store");
using var before = database.BeginRead();
var idElement = Enumerable.Range(1, before.NodeCount)
    .Select(id => before.GetNode((ulong)id))
    .Single(node => node.Kind == Bosak.XmlDb.Core.StorageNodeKind.Element
        && node.LocalName == "DocumentID");
var scalarId = idElement.Children.Single(); // Text node in this fixture.

using (var transaction = database.BeginWrite())
{
    transaction.ReplaceNodeValue(scalarId, "SO-2");
    var committedSequence = transaction.Commit();
}

using var after = database.BeginRead();
var updated = new PersistentXdmNode(after);
// before still reads the previous value; after reads SO-2 at the new sequence.
```

A transaction supports one text node or ordinary attribute. It may restage the same
node; changing a second node, an element/document/namespace or any XML-namespace
attribute is rejected. Values must be valid XML characters within the 1 MiB limit.
Dispose/Rollback abandons an uncommitted replacement. There is no read-your-writes
query API. Concurrent pending transactions share a base, but any committed document
change makes older transactions conflict with TransactionConflictException.

One coordinator owns the OS writer lease. Snapshot/transaction use remains confined
to one caller thread. Disposing the coordinator prevents new work but does not dispose
already-owned snapshots. All generations, WAL and orphan staging paths are retained.
Do not remove them manually from an active store.

Commit returns only after WAL flush and root publication. A persistence exception can
have an uncertain outcome; the coordinator then rejects new work. Dispose/reopen to
recover before deciding on a retry. A kill during an unflushed append may recover
old or new, while acknowledged commits remain new in the tested process-crash model.
No caller-supplied idempotency-key or power-loss durability contract is provided yet.

Recovery validates retained generations and may eagerly read all their payloads;
per-snapshot query counters exclude this startup/recovery work. See the
[format](implementation/M2_TRANSACTION_FORMAT_V1.md), [crash matrix](implementation/M2_CRASH_MATRIX.md)
and [M2 status](../M2_STATUS.md). Public example:

```sh
dotnet run --project samples/EmbeddedQuickstart -c Release -- update order-store SO-2
dotnet run --project samples/EmbeddedQuickstart -c Release -- read order-store
```

2026-10-26: first M2 scalar transaction slice, optimistic conflicts, retained snapshots,
WAL/replay and process-kill validation; full M2 remains in progress.

Empty ordinary-attribute values are supported. Empty text replacement is rejected
because it requires structural removal rather than a scalar-only change.

## 7. Explicit Filesystem Barriers and Error Handling

Existing code retains the default process-crash behavior:

```csharp
using var database = EmbeddedXmlDatabase.Open("order-store");
// database.Durability == DurabilityMode.ProcessCrash
```

The new overload can request explicit file and directory barriers:

```csharp
using var database = EmbeddedXmlDatabase.Open(
    "order-store", durability: DurabilityMode.FileAndDirectoryFlush);
```

The directory adapter is experimental and Linux-only. On Windows/macOS it throws
PlatformNotSupportedException before sidecar adoption; on Linux a failed directory
probe/barrier raises an error rather than choosing weaker semantics. Windows tests verify rejection/modeling. The full suite now also passes natively on Linux Docker overlayfs, including directory fsync; physical power-loss behavior remains unverified. The original two-argument Open overload remains intact.

The requested policy applies to this coordinator session. Reopening with the default
still selects ProcessCrash; no persisted per-store SLA or automatic policy upgrade is
claimed. Stronger-mode adoption first synchronizes existing base/history and namespaces
before relying on future writes. It can therefore be expensive. All failures during
Open release ownership; commit persistence failures fault the owner until dispose/reopen.

Disk-full-style tests use injected IOException errors and real partial writes to
temporary test files. They do not exhaust the user's disk. Successful barriers still
need validation against the intended filesystem/controller before a power-loss guarantee.
See [fault report](implementation/M2_FILESYSTEM_FAULT_VALIDATION.md) and
[ADR-005](ADR-005-filesystem-barriers-and-checkpoint-gates.md).

Checkpoint anchors and cross-process reader leases are now implemented; see section 8. Log truncation and committed-generation deletion remain unsupported. Retain the complete store.

2026-10-26: explicit durability selection, directory-barrier ordering and 333 injected
filesystem failure positions added; full M2 and production durability remain open.
## 8. Non-Deleting Checkpoints and Pinned Readers

After at least one committed scalar edit:

```csharp
using (var owner = EmbeddedXmlDatabase.Open("order-store"))
    owner.CreateCheckpoint();

using var database = EmbeddedXmlDatabase.Open(
    "order-store", recovery: RecoveryMode.PreferCheckpoint);
using var snapshot = database.BeginRead();
var work = database.LastRecovery;
// work.CheckpointSequence, WalRecordsValidated, GenerationsValidated,
// GenerationsReplayed and CheckpointRejected describe this open.
```

FullJournal remains the default and validates all generation history. PreferCheckpoint
validates the complete retained WAL prefix/suffix and a self-contained anchor, then
skips earlier materializations. This is not log truncation or an independent backup.
Optional checkpoint damage falls back to full recovery; a broken required WAL still
fails. A stale valid selector replays through the latest commit. Repeating checkpoint
publication at the same sequence validates/reuses immutable data without overwriting it.

BeginRead and BeginWrite pin their selected generation with a shared per-sequence OS
lease. The snapshot/transaction owns the handle until Dispose/commit/rollback; closing
its coordinator does not release it. An uncached old snapshot can keep reading while
another coordinator commits and checkpoints. Process exit releases its handles. Never
remove or recreate stable lease files: lock identity must remain stable.

```csharp
ImmutableXmlSnapshot pinned;
using (var owner = EmbeddedXmlDatabase.Open("order-store"))
    pinned = owner.BeginRead(cacheBytes: 0);
using (pinned)
{
    var document = new PersistentXdmNode(pinned);
    // Original generation remains available after owner disposal.
}
```

Private generation/checkpoint directories must not be opened through raw legacy reader
APIs. Older binaries and pre-adoption M1 readers do not have these leases, so all base,
committed WAL, generations, checkpoints and lock identities remain retained. No public
retirement/GC method exists. Failures during checkpoint/lease publication fault the
owner until recovery; temporary files do not become partially valid canonical identities.

Sample commands: `checkpoint <store-path>` publishes an anchor;
`read-checkpoint <store-path>` requests verified checkpoint recovery; ordinary `read`
keeps full recovery. [Current validation](implementation/M2_EMPTY_EPOCH_VALIDATION.md) records
669 passing tests on each of Windows/Linux and a runnable cross-platform helper.
See [ADR-006](ADR-006-nondeleting-checkpoints-and-reader-leases.md) and the
[byte contract](implementation/M2_CHECKPOINT_FORMAT_V1.md) before changing encoding.

2026-10-26: non-deleting checkpoint publication/recovery and snapshot-owned reader
leases implemented; no history reclamation or physical power-loss certification.


(c) Fytala. All rights reserved.

## Recovery Descriptors and Retention Inventory

Implemented in [ADR-007](ADR-007-recovery-descriptors-and-retention-inventory.md):
`CreateRecoveryAnchor()` publishes an immutable descriptor after a verified complete
checkpoint. Publish at separate commits to retain independent older recovery copies.
`PreferCheckpoint` tries canonical descriptors newest-first when CHECKPOINT is invalid
or absent; every retained WAL record and selected prefix must still validate.
`PlanRetention()` reports file dependencies and selected-root files without mutation.
Its `CanReclaim` is always false: older readers, base compatibility, stable lease
identities and full WAL history remain protected. The report is a point-in-time
inventory, not a backup or permission to delete files. The compatibility transition and backup/retirement protocol are now specified in
ADR-008 (design only). Verified full-history backup/restore is now implemented per ADR-009; migration and
reclamation remain disabled.


Example (after at least one scalar commit):

```csharp
using var database = EmbeddedXmlDatabase.Open(storePath);
ulong anchoredSequence = database.CreateRecoveryAnchor();
RetentionReport inventory = database.PlanRetention();
// inventory.CanReclaim is always false. Inspect inventory.Files for retention reasons.
```

The current suite passes 669 tests per platform, including backup/restore fault sweeps
and publication kills. See [current structured evidence](implementation/m2-epoch-backup-fault-results.json).
Earlier descriptor-only recovery and selected-root evidence is retained in
[historical results](implementation/m2-retention-results.json).

## Full-History Backup and Restore

```csharp
using var owner = EmbeddedXmlDatabase.Open(storePath);
BackupResult captured = owner.CreateBackup(backupPath);
BackupResult restored = EmbeddedXmlDatabase.RestoreBackup(backupPath, newStorePath);
```

Both destination parents must exist, with final destinations absent and nonoverlapping
with their sources. Capture uses the owner's Durability policy, blocks commits/checkpoints
for its entire fixed-H operation and retains old snapshots and source history. A backup
holds complete base/WAL/generations with canonical hashes, not only CURRENT/checkpoints.
The inventory omits optional checkpoint/descriptor trees, runtime readers/locks/staging.
Missing generation materializations require a separate FullJournal reopen before capture.
Unknown dependencies fail closed. Sealed inventory is bounded at 100,000 files.

RestoreBackup accepts an optional explicit DurabilityMode (default ProcessCrash), uses
full recovery on a clone, requires exact H/head with zero generation replay, and publishes
a fresh independent mutable store. It never changes the backup or overwrites a destination.
Future Open creates new OS ownership. Writes on source and restore diverge; there is no
replication or automatic cutover. The proprietary license and Bosak 1.26.2 remain unchanged.

Pure destination argument errors leave an owner usable; capture I/O/verification errors
fault it until reopen. A failed acknowledgment can leave an already-complete final root.
Use a new destination for retry; no merge/overwrite or automatic workspace cleanup exists.
Incomplete .xmldb-backup-* sibling workspaces are never routable stores. Only operation-owned
verification clones/workspaces are removed during normal operation; all source history stays.

Sample: backup <store-path> <new-backup-path> and restore <backup-path> <new-store-path>.
See [ADR-009](ADR-009-verified-full-history-backup-and-restore.md),
[format](implementation/M2_BACKUP_FORMAT_V1.md) and
[validation](implementation/M2_BACKUP_VALIDATION.md). ADR-008's mandatory-format migration,
epoch data integration, migration and retirement remain pending. Internal metadata-only
admission primitives are implemented in ADR-010. No deletion API is added.

2026-10-27: full-history backup/restore APIs, sealed inventory/completion, sample commands,
clone verification, persistence-fault and process-kill validation added. Existing store
format/overloads are preserved; no online/incremental backup or physical power-loss SLA.



## Read-Only Epoch Snapshots

```csharp
using var store = ReadOnlyEpochDatabase.Open(preparedEpochRoot);
using var read = store.BeginRead(cacheBytes: 0);
var document = new PersistentXdmNode(read);
```

StoreId, EpochId and DocumentId expose immutable identity. BeginRead returns the same
ImmutableXmlSnapshot accepted by the XPath adapter. Its shared epoch handle is independent
of the session: closing store does not invalidate read. Exclusive maintenance remains
blocked until every session/snapshot closes or its process exits. Thread confinement,
disposal and BindResult rules still apply.

Only complete immutable major-2 roots with sequence-zero SNAPSHOT binding are supported.
Missing/corrupt metadata, wrong identities/hashes, nonzero sequence and any .transactions
file/directory fail closed without adoption or repair. Opening validates metadata, not
all payloads; lazy corrupt fragments fail on access. Header/count queries avoid line
payload reads. Negative cache arguments do not acquire child handles; failed opens close
all partially acquired handles. Reading creates no runtime state or source mutations.

Sample: read-epoch <prepared-root>. Production creation/import/history migration is not
a public API yet; current preparation is an internal immutable-M1 fixture producer.
Legacy ImmutableXmlSnapshot.Open and EmbeddedXmlDatabase.Open remain format-1 entry
points and reject populated major-2 roots. Frozen old binaries are unchanged and prove
that rejection; unavailable pre-lease/released readers remain an open compatibility gate.
Do not replace a legacy root's FORMAT or infer permission to delete from admission.

See [ADR-011](ADR-011-admission-owned-read-only-epoch-snapshots.md),
[contract](implementation/M2_READONLY_EPOCH_SNAPSHOT.md) and
[validation](implementation/M2_READONLY_EPOCH_VALIDATION.md). Epoch transactions, WAL
recovery, backup and full-history migration remain unsupported. Licensing and source
history retention are unchanged. Current CanReclaim stays false.

2026-10-27: public read-only epoch session/snapshot API and sample, BXES descriptor,
internal atomic immutable-data fixture production, XPath/I/O parity and actual snapshot
cross-process lifetime/fault/kill tests added. No mutable epoch authority or deletion.



## Mutable Epoch Codec Status

[ADR-013](ADR-013-epoch-profile-and-authority-codecs.md) implements internal ET1-ET3
profile/authority codecs. No new callable mutable API is available. Existing read-only
admission/data entry points explicitly require immutable profile 2.0 even though generic
parsing recognizes 2.1. Do not add transaction state or rewrite a root's FORMAT. No
fallback to a base/immutable reader is allowed after an unsupported mutable open.

The frozen authority layout binds expected StoreId/EpochId/document, full FORMAT hash,
base hash and role. Validation enforces scalar/framing/name bounds, not actual chain
uniqueness, target-node kind or materialization/recovery semantics. The codecs reject
truncation; they never classify/delete an incomplete WAL tail or publish a commit.
See [format](implementation/M2_EPOCH_AUTHORITY_FORMAT_V1.md) and
[validation](implementation/M2_EPOCH_AUTHORITY_VALIDATION.md).

Both captured reader baselines independently reject mutable root/generation fixtures
before writes. Current read-only opens also refuse while admission is occupied, proving
capability rejection occurs first. Broader archived pre-lease compatibility remains open.

ADR-014 implements internal ET4 admitted empty-chain ownership. ADR-015 adds internal
ET5 scalar commit and complete-history reopen. ADR-016 adds internal redo and narrow unwitnessed incomplete-tail handling;
public mutable access is unavailable. ET7 classification is now qualified; ET8 local native qualification is recorded; ET9 backup/
migration and all reclamation remain unsupported. Licensing and source retention are unchanged.

2026-10-27: internal exact profile and epoch-bound authority codecs/fixtures plus frozen
immutable-reader capture/probes added. Existing 2.0/legacy bytes and public behavior remain.



## Internal Empty-Chain Epoch Ownership

[ADR-014](ADR-014-admitted-empty-chain-epoch-coordinator.md) implements an internal
empty-chain coordinator and immutable-source fixture builder. There is no new public
mutable API or user creation/migration command. Existing format-1 APIs and public
ReadOnlyEpochDatabase remain unchanged and keep their explicit capability gates.

The prototype validates ScalarWal identity/BASE/CONTROL/empty state and all base payload
references before taking writer ownership, then publishes/reuses a stable zero-reader
identity. Snapshots and lifetime-only transaction contexts hold their own admission and
base-reader handles, surviving owner disposal and blocking maintenance until completion.
Rollback only disposes context ownership; no value staging, commit or read-your-writes
semantics is added to this ET4 prototype. Nonempty WAL, published generations, nonzero CURRENT and unknown
transaction state are refused, never replayed/cleaned or silently read as the base.

Strong-mode epoch initialization synchronizes data/namespace while skipping writable
opens of already-published active identity files. Linux directory barriers are native;
Windows stronger tests are modeled. An initialization failure returns no owner and
releases its handles; leftover private reader temporaries are retained, not adopted.
Later valid reopen can reuse a complete canonical identity without replacement.
See [contract](implementation/M2_EMPTY_EPOCH_COORDINATOR.md) and
[validation](implementation/M2_EMPTY_EPOCH_VALIDATION.md).

2026-10-27: internal ET4 admitted zero-head coordinator, profile forks, protected snapshots/
transaction contexts, runtime initialization fault/kill and disposal-race evidence added.
No public mutable operations, scalar commit/recovery, migration, deletion or wire changes.

2026-10-27: [ADR-015](ADR-015-internal-scalar-epoch-commit.md) adds internal ET5 scalar
staging/conflict/commit and fully materialized history reopen. Public integration APIs
remain unchanged. Failed commits may have published a complete new head; redo and
incomplete-tail handling are not implemented. See [contract](implementation/M2_EPOCH_SCALAR_COMMIT.md)
and [validation](implementation/M2_EPOCH_SCALAR_VALIDATION.md).

2026-10-27: [ADR-016](ADR-016-internal-epoch-redo-and-publication-faults.md) adds internal ET6
redo, witnessed incomplete-tail removal and verified CURRENT recovery. Public integration
APIs are unchanged. A failed commit can still become the recovered head; no automatic retry
or caller idempotency service is introduced. Full history and stable reader identities are
retained. See [runtime contract](implementation/M2_EPOCH_RECOVERY.md) and
[validation](implementation/M2_EPOCH_RECOVERY_VALIDATION.md).

2026-10-27: ET7 [classification validation](implementation/M2_EPOCH_CLASSIFICATION_VALIDATION.md)
qualifies the existing internal recovery path against foreign/role/chain/publication and
resealed logical corruption, plus multi-generation interrupted redo with old readers.
No public API or engine/wire change is introduced. Public mutable access, epoch backup/
migration, archived reader qualification and reclamation remain pending.

2026-10-27: [ET8 native fault qualification](implementation/M2_EPOCH_NATIVE_DURABILITY_VALIDATION.md)
adds actual Linux durability-operation fault sweeps and real native fsync error propagation,
with Windows unsupported-policy rejection and explicit test-temp provenance. Public APIs,
wire bytes and engine behavior are unchanged. Native support remains Linux-only and local
filesystem evidence does not imply power-loss certification. ET9 epoch backup/migration,
public mutable access and reclamation remain pending.

2026-10-27: [ADR-017](ADR-017-epoch-full-history-backup-and-independent-restore.md) accepts
ET9 epoch backup/independent-restore design only. Proposed restore publishes a bundle with
store/ plus origin.bin, returns StorePath explicitly, and assigns fresh store/epoch IDs while
preserving complete logical history and document/node IDs. Provenance is outside recovery
authority. The [candidate records](implementation/M2_EPOCH_BACKUP_FORMAT_DESIGN.md) have no
codecs/fixtures yet; neither epoch backup/restore methods nor a new public integration path
exist. Format-1 backup/restore remains unchanged. Next: ET9-A pure codecs and independent fixtures.

2026-10-27: ET9-A implements internal pure backup inventory/completion/origin metadata codecs
and header-context checks, frozen with [independent fixtures](implementation/M2_EPOCH_BACKUP_CODEC_VALIDATION.md)
in the [versioned contract](implementation/M2_EPOCH_BACKUP_FORMAT_V1.md). Parsed metadata is
not a verified artifact, admitted store or source/destination history proof. No capture/restore
operation, public integration API or legacy-format change is added. Next: ET9-B internal
fixed-H capture and both data/history verification oracles.

2026-10-27: ET9-B adds internal fixed-head epoch capture and seal/closure/header reading,
plus complete-data/no-repair and exact full-WAL-redo private verification. Source identity,
H, all data/history and old readers remain intact. A sealed artifact has no copied runtime
admission/readers and is not a mutable root. No public method or restore is exposed. Read-only
closure/header checks are not full history proof; callers must use both private oracles.
See [contract](implementation/M2_EPOCH_BACKUP_CAPTURE.md) and
[validation](implementation/M2_EPOCH_BACKUP_CAPTURE_VALIDATION.md). Next: ET9-C restore.

2026-10-27: ET9-C adds internal independent restore/rebinding. Returned StorePath is the
published bundle/store directory; origin.bin beside it records initial-prefix provenance.
Fresh StoreId/EpochId and WAL hashes preserve complete H/transaction/document/node/data
history. No existing destination/source/backup is overwritten, and staging-path handles do
not escape publication. Source and restored branches can write independently; origin is
not a current recovery selector. Public APIs are unchanged. See
[contract](implementation/M2_EPOCH_BACKUP_RESTORE.md) and
[validation](implementation/M2_EPOCH_BACKUP_RESTORE_VALIDATION.md). ET9-D fault qualification is now implemented.

*Last updated: 2026-10-30*


ET9-D qualification update (2026-10-27): capture/restore persistence sweeps now enumerate
every observed before/after call and actual partial-write position on a one-commit history.
Process-crash and modeled strong ordering are separate from actual native Linux delegation.
Repeated process interruption covers private publication windows, published outcomes and
acknowledgment loss. Source/backup bytes, historical reads, provenance and released handles
are checked. See [fault qualification](implementation/M2_EPOCH_BACKUP_FAULT_VALIDATION.md).
Full-history migration/cutover acceptance is now specified by ADR-018; runtime implementation remains pending. Public mutable APIs, source replacement and history reclamation remain disabled.


Migration/cutover design update (2026-10-27): [ADR-018](ADR-018-full-history-legacy-migration-and-cutover.md)
now specifies internal conversion of a sealed format-1 full-history backup into a fresh
ScalarWal 2.1 bundle. [Acceptance criteria](implementation/M2_EPOCH_MIGRATION_DESIGN.md)
require complete-history and full-redo verification on both sides, exact sequence/data
parity, separate migration provenance and explicit operator-controlled cutover. The
converter never opens the live legacy root. Source paths/history are retained; cutover
requires a write freeze and source/candidate freshness checks. No runtime migration,
routing API or retirement is implemented. MG1 codecs/fixtures are now implemented; next: MG2 legacy verification. The design-only step retained the 669-case runtime baseline; the MG1 update below records
fresh codec/regression coverage separately, without claiming runtime migration proof.


MG1 implementation update (2026-10-27): internal EpochMigrationCodec now encodes the
separate 350-byte BXEM 1.0 migration-origin role, frozen with independent H0/H2 vectors in
[the byte contract](implementation/M2_EPOCH_MIGRATION_FORMAT_V1.md). Pure
source/destination header checks preserve legacy H0 CURRENT omission and reject malformed
bounds and substituted commitments. They perform no I/O and grant no closure/history,
admission, migration or cutover capability. See [validation](implementation/M2_EPOCH_MIGRATION_CODEC_VALIDATION.md).
MG2 legacy verification is now implemented; next: MG3 conversion and verified bundle publication.
No runtime converter, routing API, source replacement or retirement is enabled.


MG2 implementation update (2026-10-27): internal [LegacyMigrationVerifier](implementation/M2_LEGACY_MIGRATION_VERIFICATION.md)
now validates sealed legacy closure, every scalar transition and exact fixed-H authority
before workspace writes, then verifies complete and independent full-WAL-redo clones.
Only private clones can initialize runtime files or republish byte-identical CURRENT;
sealed input and live source roots are not recovered or rewritten. No destination store
is published. [Validation](implementation/M2_LEGACY_MIGRATION_VERIFICATION_VALIDATION.md)
distinguishes 33 new cases/738 fresh filtered regressions per platform from retained ET9-D
evidence. MG3 internal conversion is implemented; next: MG4 exhaustive fault qualification.
Public migration/mutable APIs, cutover and retirement remain disabled.


MG3 implementation update (2026-10-27): internal [EpochLegacyMigration](implementation/M2_EPOCH_MIGRATION_CONVERSION.md)
now verifies sealed legacy full history through MG2, assigns fresh epoch identity and
re-encodes every authority/WAL link while preserving H, transaction/document/node IDs and
XML data bytes. Both destination history oracles and fresh runtime/provenance checks must
pass before atomic store/ plus migration.bin bundle publication; staging handles close first.
Source paths/artifact stay intact. [Validation](implementation/M2_EPOCH_MIGRATION_CONVERSION_VALIDATION.md)
records 27 new Storage and six process cases with 771 fresh filtered regressions per platform,
separately retaining the unchanged 18-case ET9-D matrix. MG4 observed fault/native/process qualification is now recorded. Public APIs, actual cutover and retirement stay disabled.


MG4 qualification update (2026-10-27): [conversion fault evidence](implementation/M2_EPOCH_MIGRATION_FAULT_VALIDATION.md)
now covers every observed H=1 persistence call before/after and actual partial writes,
with immutable input and valid/absent publication checks. Process probes repeat 12 windows
three times per supported policy, including private legacy copy/redo, epoch redo and ACK
loss, with actual native Linux delegation separate from modeled ordering. Production
algorithms and bytes are unchanged. Fresh regressions cover 798 cases per platform, with
18 unchanged ET9-D cases retained separately. Next: MG5 source/candidate freshness and
explicit cutover/rollback acceptance harness. Public APIs, routing service, source
replacement and all retirement remain disabled.


MG5 acceptance update (2026-10-27): [internal cutover harness](implementation/M2_MIGRATION_CUTOVER_ACCEPTANCE.md)
now freezes cooperating mutations, registers capture under that freeze, and revalidates
exact source/candidate commitments for session-bound single-use routing observations.
It models known/uncertain outcomes and verified no-work return versus reconciliation,
without changing any route/configuration or store path. [Validation](implementation/M2_MIGRATION_CUTOVER_ACCEPTANCE_VALIDATION.md)
records 32 Storage/two process cases and 823 fresh filtered regressions per platform, with
27 unchanged fault-matrix cases retained separately. MG1-MG5 are internal prototype gates;
next: compatibility/release-readiness evidence audit. Archived-reader gaps, public API/
shipping qualification and retirement remain open; all source data stays retained.


Compatibility audit (2026-10-28): [release-readiness evidence](implementation/M2_RELEASE_READINESS_AUDIT.md) verifies both frozen local reader families and records C1-C3 gaps. No shipping gate is closed. Next: CA1 rejection/nonmutation coverage for actual published migration bundles and every nested generation; archived release provenance remains unavailable locally.


CA1 update (2026-10-28): [real migrated-bundle compatibility validation](implementation/M2_MIGRATED_BUNDLE_COMPATIBILITY_VALIDATION.md) adds 12 local frozen/current rejection cases for H0/H3 wrapper, store and every generation, including exact file/directory and runtime identity preservation. Complete archived C1 and actual routing remain open. Next: CA2 migrated-candidate child/owner disposal races and cross-process lifetime checks.


CA2 update (2026-10-28): [migrated ownership validation](implementation/M2_MIGRATED_OWNERSHIP_VALIDATION.md) adds 12 repeated child/owner race cases and four cross-process holder-release cases. Local ownership proof is stronger; archived compatibility, actual routing and shipping remain open. Next: define supported public API and host cutover/restart contracts before implementing real routing.


API/host contract design (2026-10-28): [ADR-019](ADR-019-explicit-mutable-api-and-host-cutover-boundary.md) and the [contract](implementation/M2_PUBLIC_API_AND_HOST_CUTOVER_CONTRACT.md) separate explicit mutable access from host-owned writer exclusion, revision-checked routing and restart reconciliation. Proposed names are not public APIs; no host adapter or durable routing record is implemented. Next: HC1 pure restart/reconciliation classifier. Archived compatibility and release gates remain open.


HC1 update (2026-10-28): [pure restart classification](implementation/M2_RESTART_CLASSIFICATION_VALIDATION.md) adds internal supplied-observation decisions and 79 Storage cases. Every result keeps writers stopped, including new-workflow eligibility; no host observation, route change or durable receipt is created. Next: PA1 explicit mutable facade prototype and ownership/profile/diagnostic tests, remaining internal until release gates pass.


PA1 prototype update (2026-10-28): [internal mutable facade](implementation/M2_SCALAR_EPOCH_FACADE_VALIDATION.md) wraps explicit options, independent snapshots/transactions, scalar commits and fixed-head backup. An optional expected identity rejects before admission/recovery. 22 new internal consumer cases preserve diagnostics and uncertainty semantics; public exposure remains disabled. Next: PA2 separate administrative facade prototype and publication-outcome tests.


PA2 prototype update (2026-10-28): [separate administration facade](implementation/M2_SCALAR_EPOCH_ADMINISTRATION_VALIDATION.md) adds sealed legacy/epoch verification and independent restore/migration receipts. 29 new cases cover bound results, input preservation, strict proof and publication uncertainty. No public API or automatic routing/retry is enabled. Next: PA3 read-only publication inspection and reconciliation observations.


PA3 update (2026-10-28): [read-only publication inspection](implementation/M2_PUBLICATION_INSPECTION_VALIDATION.md) adds pinned-artifact and optional known-operation correlation, with reconciliation for changed/incomplete inputs and no adoption/recovery. 43 new cases preserve bytes/runtime identities; every observation keeps writers stopped. Next: consolidated cross-platform regression and API/readiness review. Public/host/archive/release gates remain open.


## RC3 Process and Contention Qualification (2026-10-28)

RC3 now qualifies preannounced IDs across publisher process death, independent plans racing
one destination and concurrent dispatch of one plan. See [validation](implementation/M2_ADMINISTRATIVE_ATTEMPT_PROCESS_VALIDATION.md).
The focused Windows/Linux runs cover 71 cases each, including 12 new RC3 cases; prior
full-suite evidence retains its dated scope. This supersedes earlier “next RC3” statements.
RC2/RC3 remain local; a3b578c contains work through RC1. No public API, host routing,
durable replay, source replacement or reclamation is enabled. Next HA1 defines the host
attempt-ledger and fencing contract; local inspection alone never authorizes retry.
