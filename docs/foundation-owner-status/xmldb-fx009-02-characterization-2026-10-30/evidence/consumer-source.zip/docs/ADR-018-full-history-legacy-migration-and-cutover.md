# ADR-018: Full-History Legacy Migration and Explicit Cutover

**Status:** Accepted design; MG1-MG5 internal prototype gates implemented; public routing/archived release/retirement remain open  
**Date:** 2026-10-27  
**Deciders:** Bosak.XmlDb implementation within authorized M2 design work

## Context

[REQ-006](FEATURE_REQUESTS.md) requires a compatibility transition that preserves committed
history and existing readers. [ADR-008](ADR-008-reader-compatibility-backup-and-retirement.md)
forbids replacing the legacy root. ET9 now qualifies internal ScalarWal 2.1 backup/restore;
that operation requires a source epoch and cannot convert format-1 transaction authority.
Legacy BXWL records have manifest links but no store/epoch or predecessor-WAL binding.
Opening a legacy store can adopt, recover or publish state, so it is unsuitable as an
implicit read-only migration step. Format 1 also has no StoreId/EpochId to put in BXEO.

## Decision

Design an internal offline converter from an already sealed, fully verified format-1
BXBI/BXBC backup into a new ScalarWal 2.1 store. Preserve every sequence 0..H and all
transaction/document/node identities and XML data bytes. Validate the legacy history with
complete-materialization and deterministic full-redo oracles before conversion. Verify
the destination independently with both epoch oracles before publication.

Generate fresh destination StoreId/EpochId and MigrationId. Re-encode authority and every
WAL link; never relabel legacy records as epoch records or reduce history to sequence zero.
Publish `store/` with a new external `migration.bin` provenance record in one atomic bundle.
Design a separate bounded migration-origin codec: existing BXEO requires a source epoch
and must not be weakened or populated with invented legacy identities. This ADR fixes
semantic requirements, not record magic, field offsets or frozen bytes.

Migration success creates a verified candidate, not permission to route application writes.
The operator must freeze/drain writers across capture, conversion, final source comparison
and explicit routing. A one-time writer lease or provenance file cannot fence old binaries.
Keep the source at its original path, its stable OS identities and every retained file.
Published candidates may remain independent branches if source or destination advances.
Rollback after either history diverges requires an explicit reconciliation decision.

The [migration contract and acceptance matrix](implementation/M2_EPOCH_MIGRATION_DESIGN.md)
define MG1-MG5. MG1 pure bounded codecs and independently authored fixtures are implemented.
MG2 now verifies complete legacy history and exact redo; next MG3 adds internal conversion
and verified publication. Cutover and retirement remain disabled.

## Consequences

### Positive

- Conversion never opens, repairs, adopts or writes the live legacy source.
- Sealed input provides an exact fixed-H identity and a reproducible verification oracle.
- Legacy readers keep their original paths and lazy payloads throughout publication.
- Candidate publication, application routing and reclamation have separate evidence gates.

### Negative / Accepted Costs

- The operator needs a sealed full-history artifact, write downtime and space for multiple
  verification copies, all materializations and the new bundle.
- The existing format-1 backup verifier alone does not discharge migration's two-oracle
  requirement; a dedicated legacy redo proof and strict transition validation are required.
- Source freshness and application routing require cooperation outside the converter.
- Actual archived pre-lease reader evidence is still unavailable; local frozen baselines
  cannot close full C1-C3 or authorize retirement.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Convert a live root by calling Open internally | Can mutate recovery/adoption state and obscures the capture boundary |
| Reuse epoch restore/BXEO with fabricated source IDs | Misstates provenance and weakens a frozen role contract |
| Migrate only the latest XML snapshot | Loses sequence and transaction history and persistent identities |
| Rewrite legacy WAL in place | Breaks old readers and rollback while mixing authority profiles |
| Automatically replace the source or switch configuration | Cannot fence old binaries, disposed-owner readers or in-flight work |
| Delete source history after candidate verification | Verification does not establish reader absence or retirement authority |

## References

- [ADR-008](ADR-008-reader-compatibility-backup-and-retirement.md)
- [Format-1 backup contract](implementation/M2_BACKUP_FORMAT_V1.md)
- [Legacy WAL contract](implementation/M2_TRANSACTION_FORMAT_V1.md)
- [Epoch authority contract](implementation/M2_EPOCH_AUTHORITY_FORMAT_V1.md)
- [ET9 qualification](implementation/M2_EPOCH_BACKUP_FAULT_VALIDATION.md)

*Last updated: 2026-10-27*

MG1 implementation update (2026-10-27): [BXEM 1.0](implementation/M2_EPOCH_MIGRATION_FORMAT_V1.md)
now has independently authored vectors, fixed-size codecs and bounded pure header-context
checks. [Validation](implementation/M2_EPOCH_MIGRATION_CODEC_VALIDATION.md) records their
scope; no I/O, admission or history capability is granted. Next MG2 implements strict
legacy complete/full-redo verification; runtime conversion and cutover remain later gates.

MG2 implementation update (2026-10-27): [strict legacy verification](implementation/M2_LEGACY_MIGRATION_VERIFICATION.md)
now preflights complete closure/history without writes and checks two owned private oracles.
It rejects stale heads/hidden edits and noncanonical redo, preserves input and publishes no
store. MG3 now implements fresh-epoch transformation and verified bundle publication.

MG3 implementation update (2026-10-27): [internal conversion](implementation/M2_EPOCH_MIGRATION_CONVERSION.md)
now preserves exact legacy history with fresh epoch authority and atomic verified two-role
publication. [Validation](implementation/M2_EPOCH_MIGRATION_CONVERSION_VALIDATION.md) covers
per-sequence parity, branch independence and selected failure/process windows. Next MG4
qualifies exhaustive observed faults/native/process interruption; public APIs and cutover
remain disabled, and no source root is replaced or history reclaimed.

MG4 qualification update (2026-10-27): [fault/interruption evidence](implementation/M2_EPOCH_MIGRATION_FAULT_VALIDATION.md)
now records observed H=1 before/after/partial-write sweeps and repeated H=3 process windows,
including actual native Linux private-copy/redo/publication interruption. This is not
physical power-loss or real ENOSPC certification. Next MG5 tests bounded explicit cutover/
rollback acceptance; no routing service, source replacement, public API or retirement.

MG5 implementation update (2026-10-27): [bounded acceptance harness](implementation/M2_MIGRATION_CUTOVER_ACCEPTANCE.md)
now models cooperating freeze/capture, exact live freshness and single-use observed route/
return decisions. It writes no route/configuration or store data during evaluation. Evidence
is process-local; no old-reader absence or persistent fencing claim is made. Next audit
compatibility/release evidence and explicit archived-binary gaps; no public exposure or
source retirement is authorized by completion of internal MG1-MG5 prototype gates.
