# Bosak.XmlDb — Coding Agent Handover

**Version:** 0.1 · 2026-10-26  
**Immediate assignment:** M0 repository bootstrap, then begin M1 immutable persistent fragment provider.  
**Status:** implementation instructions; no new repository or code has been created by this document.

## 1. Mission

Create **Bosak.XmlDb**, a standalone .NET 10 repository implementing a native XML database on top of the existing Bosak XPath/XQuery/XDM library. Preserve a single storage engine for embedded and future distributed deployment. The immediate deliverable is an **embedded, immutable, persistent, lazily navigable XML fragment provider**. Do not build the server, NATS integration, or Kubernetes cluster in M0/M1.

## 2. Read in this order

1. `Bosak_XmlDb_Agent_Handover_v0.1.md` — task scope and instructions (this file).
2. `Bosak_M1_Persistent_Fragment_Provider_Implementation_Plan_v0.2.md` — authoritative M0/M1 acceptance criteria and layout.
3. `Bosak_Native_XML_Storage_Engine_Technical_Design_v0.3.md` — long-term design; future proposals are not M1 requirements.
4. `OAGIS_Native_Distributed_Architecture_v0.2.md` — strategic context, not implementation requirements.
5. Bosak source at https://github.com/Fytala-Charles/Bosak, using supplied `Bosak-main.zip` as an offline baseline when needed.

## 3. Confirmed decisions versus proposals

| Confirmed for project setup | Deferred / requires proof |
|---|---|
| Separate `Bosak.XmlDb` repository | Native indexes and compiler/VM changes |
| .NET 10; Bosak is upstream dependency | WAL/MVCC, transactional updates |
| Same engine for embedded and server | Log-first JetStream durability model |
| M1 immutable persistent XDM provider | Leader election, fencing, failover |
| No changes to Bosak core for M1 unless justified | Production Docker/Kubernetes/operator |
| Local persistence is independent of NATS | Specific performance targets before measurement |

## 4. Agent operating constraints

- Inspect the real Bosak APIs before writing adapter code; do not invent `IXdmNode`, `XdmSequence`, or `XPath31Expression` signatures.
- Do not modify the Bosak repository as part of M0/M1. If a core limitation is found, write an issue/ADR with a minimal reproduction and request approval before changing upstream.
- Never claim compilation or test success without command output. If the SDK is missing, use a suitable approved SDK environment or mark execution blocked.
- Avoid introducing premature dependencies on NATS, JetStream, Kubernetes, ORMs, or external XML databases.
- Do not silently change fragment binary layout; version formats and test corrupt/truncated input.
- Treat the original XML infoset and XPath semantics as authoritative. Stable identity, document order, namespace nodes, and snapshot disposal require tests.
- No GitHub pushes, image publication, infrastructure provisioning, or secrets handling without explicit permission.

## 5. M0 — setup checklist

- [ ] Confirm repository location/permissions, Bosak dependency source, and license policy.
- [ ] Create solution (`Bosak.XmlDb.slnx`), `global.json` pinned to a verified .NET 10 SDK, `.editorconfig`, `Directory.Build.props`, `.gitignore`, `README.md`.
- [ ] Create `Core`, `Storage`, `Xdm` projects and `Storage.Tests`, `Xdm.Tests`; target `net10.0`.
- [ ] Keep project references acyclic: `Storage -> Core`; `Xdm -> Storage + Core + Bosak core dependencies`.
- [ ] Add Linux/Windows CI for restore, Release build, tests, formatting/analyzer checks.
- [ ] Add fixture-generator plan and an ADR explaining separate repository and dual hosting modes.
- [ ] Run and record `dotnet --info`, `dotnet restore`, `dotnet build -c Release`, `dotnet test -c Release`.
- [ ] Create `M0_STATUS.md` listing actual results, unresolved decisions, and next tasks.

## 6. M1 — implementation sequence

1. Specify and test binary format headers, version fields, checksums, length validation and manifest codec.
2. Implement importer and persistent node directory with parent/child/attribute/order/fragment pointers.
3. Implement fragment reader with bounded cache and instrumented payload reads.
4. Implement immutable read snapshot and deterministic use-after-dispose behavior.
5. Implement `PersistentXdmNode` against the real Bosak `IXdmNode` interface.
6. Integrate a snapshot-scoped document loader with the existing evaluation mechanism.
7. Run differential XPath tests versus Bosak in-memory provider, including namespace/attribute/reverse-axis cases.
8. Run warm/cold benchmarks and publish measurements, not unsupported speed claims.

### Non-negotiable M1 tests

```xpath
/SalesOrder/SalesOrderHeader/DocumentID
count(/SalesOrder/SalesOrderLine)
/SalesOrder/SalesOrderLine[10]/Item/ItemID
/SalesOrder/SalesOrderLine[last()]/ancestor::SalesOrder
```

Use namespace-bound equivalents for real OAGIS documents. Assert **zero line payload fragment reads** for header-only query, cross-process reopen, node identity/order parity, deterministic snapshot disposal, and corruption rejection.

## 7. Architecture reference

```mermaid
flowchart TB
  B["Bosak compiler / VM / XDM"] --> P["XmlDb persistent IXdmNode adapter"]
  P --> D["Node directory + fragment cache"]
  D --> F[("Versioned fragment files")]
  P --> S["Immutable read snapshot"]
  P --> A["Embedded application"]
  P -. future .-> H["XmlDb.Server / Docker"]
  H -. future .-> J["NATS / JetStream + Kubernetes"]
```

## 8. Agent completion report template

```markdown
# Bosak.XmlDb — M0/M1 Status
- Baseline Bosak commit / package versions:
- .NET SDK / OS:
- New repository path:
- Implemented files and APIs:
- Commands executed (exact):
- Tests passed / failed / skipped:
- Lazy fragment I/O evidence:
- Benchmarks and environment:
- Deviations from design (with rationale):
- Known limitations / blockers:
- Next recommended action:
```

## 9. Questions requiring owner decisions

1. Confirm new GitHub repository ownership/name and whether the agent may create it remotely; otherwise work locally.
2. Confirm license choice and whether Bosak is consumed through pinned NuGet packages or a pinned source reference.
3. Confirm SDK/CI environment and permissions for package restore.
4. Confirm whether M0 only or M0+M1 implementation is authorized in the initial agent run.

**Default if unanswered:** build locally, avoid publishing, document assumptions, and complete M0 before modifying any engine code.

## 10. Definition of done

**M0:** reproducible build/test skeleton, documented dependencies, CI configuration, and truthful status report.  
**M1:** all tests and acceptance criteria in the implementation plan pass with instrumented proof of lazy I/O. No JetStream, HA, Docker production server, or Kubernetes work is required.
