# ADR-007: Independent Recovery Descriptors and Conservative Retention Inventory

**Status:** Accepted  
**Date:** 2026-10-26  
**Deciders:** Bosak.XmlDb implementation, within the authorized M2 scope

## Context

[REQ-005](FEATURE_REQUESTS.md) needs independently verifiable recovery choices and
retention dependencies before retirement. ADR-006 retains every committed file. A
single optional CHECKPOINT selector can be damaged; older readers may hold no lease.

## Decision

Add explicit `CreateRecoveryAnchor()`: first create/validate a complete checkpoint,
then atomically publish `.transactions/anchors/<sequence-D20>.anchor`. Its bytes are
an unchanged BXCS pointer binding the complete BXCP anchor hash. Publication uses
the transaction storage seam, file flush and policy directory barriers. Descriptors
are immutable: identical retries succeed, conflicting identities fault the owner.
Sequence does not advance. Repeated calls at different commits retain separate
complete materializations, allowing an older copy to survive damage to the latest.
A descriptor shares its own checkpoint copy; it is not a second replica of that copy.

PreferCheckpoint checks CHECKPOINT first. If unavailable/invalid, scan canonical
descriptors in descending sequence order and verify document, name/sequence, envelope,
anchor hash and complete materialization. Invalid candidates are skipped. Once chosen,
the existing recovery pass validates every retained WAL record and the exact prefix.
A prefix mismatch falls back to full recovery; it does not search more descriptors.
FullJournal stays unchanged. A valid CHECKPOINT remains preferred even if descriptors
exist. Unpublished checkpoint directories are never inferred to be recovery choices.
CheckpointRejected now means any attempted optional choice was rejected, even when
another descriptor succeeds. Optional cache files never replace authoritative WAL.

Add `PlanRetention()`, a read-only point-in-time inventory under coordinator selection.
It classifies base files, WAL, generations, checkpoints, descriptors, stable reader
identities, staging and coordinator/unclassified files, and marks selected-root files.
It retains everything; `CanReclaim` is always false. No exclusive lease probes occur:
lease existence does not prove a reader is active, and lack of holders cannot prove
old binaries are absent. Reparse points fail the inventory; external concurrent changes
can invalidate any report. Stable lease identities must never be replaced or removed.

## Consequences

### Positive

- Recovery can use an independently copied older checkpoint after latest-copy damage.
- Existing formats, default recovery and older binary behavior remain compatible.
- Consumers can inspect retention reasons without receiving deletion authorization.

### Negative / Accepted Costs

- Descriptor checkpoints consume additional disk; complete WAL history is required.
- Inventory cannot detect uncooperative readers, guarantee backup consistency or reclaim.
- Physical power loss and real capacity exhaustion remain uncertified.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Discover every checkpoint directory | Could adopt an unpublished staging outcome |
| Treat an unlocked lease as reclaimable | Older readers may not own leases; reports race future readers |
| Automatically retire prefix WAL | Existing recovery and older binaries still require the complete chain |

## References

- [ADR-006](ADR-006-nondeleting-checkpoints-and-reader-leases.md)
- [M2 checkpoint format](implementation/M2_CHECKPOINT_FORMAT_V1.md)
- [M2 status](../M2_STATUS.md)

*Last updated: 2026-10-26*
