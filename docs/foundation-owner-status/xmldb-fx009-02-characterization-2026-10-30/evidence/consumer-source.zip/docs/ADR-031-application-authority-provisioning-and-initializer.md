# ADR-031: Explicit Application-Authority Provisioning and Live Initializer Reservation

**Status:** Accepted internal provisioning/live-reservation prototype with Windows/Linux process qualification; enrollment persistence pending
**Date:** 2026-10-29
**Deciders:** Authorized continuation of the internal embedded pilot

## Context

[REQ-007](FEATURE_REQUESTS.md#req-007-mutable-epoch-authority-and-recovery),
[ADR-029](ADR-029-separate-application-authority-journal-v1.md) and
[ADR-030](ADR-030-paired-read-only-application-authority-ownership.md) require an
explicit absent-root path separate from existing-root inspection. A valid empty log
cannot establish who initialized it or prove a real application baseline.

## Decision

Add an internal separate Provision factory using the actual exclusive parent inspection
registration. Bind configuration/root mappings to the live parent and require supplied
fresh controlled-provisioner/no-prior-authority assertions. Those assertions are caller
assumptions, not independently verified application facts. Validate absent target, existing
supported local parent, and lexical/native protected ancestry before creating anything.
For planned paths compare relative suffixes below shared native ancestor identities.

Create the directory, then CreateNew authority.lock with exclusive sharing before any
metadata/log creation. Transfer that exact owner handle into the lifetime. Use the existing
transaction storage seam for metadata/log creation, writes and barriers. Support only
ProcessCrash; explicitly reject stronger policies. Validate the exact three roles,
single-link native identities, expected metadata and empty history before return.
Any exception retains partial files/directories, including an empty root. No invocation
repairs, deletes, truncates, fills in or resumes an existing target.

Only the successful original live instance may reserve its initializer once. Claim under
the owner gate before read-only revalidation; failure consumes the claim and faults the
session. The opaque disposable reservation retains an actual parent/child operation lease
through owner disposal. It cannot append, enroll, carry a baseline, invoke a database,
recreate authority from serialized bytes or reopen the reserved privilege. OpenExisting
never receives this origin state. Every result keeps writers stopped.

## Consequences

No wire layout, fixture, public API or existing OpenExisting behavior changes. Provision
return and reservation are not enrollment or application work acceptance. Actual process
termination/acknowledgment loss and independent-creator qualification pass on Windows and
isolated Linux. Next bind real operational baseline evidence to live owner-bound first-
enrollment preparation, then implement conditional append/uncertain-save handling. Retain all administrative/application/store
histories; no routing, source replacement, automatic retry or reclamation is enabled.

## Validation

[Provisioning validation](implementation/M2_APPLICATION_AUTHORITY_PROVISIONING_VALIDATION.md)
records fault-boundary, retained-state, live-only reservation and regression evidence.
