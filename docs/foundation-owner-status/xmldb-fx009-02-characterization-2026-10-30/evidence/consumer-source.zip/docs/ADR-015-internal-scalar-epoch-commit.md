# ADR-015: Internal Scalar Epoch Commit and Complete-History Reopen

- Status: Accepted for the internal ET5 slice; public mutation and redo remain pending
- Date: 2026-10-27
- Related: [REQ-007](FEATURE_REQUESTS.md#req-007-mutable-epoch-authority-and-recovery), [ADR-014](ADR-014-admitted-empty-chain-epoch-coordinator.md)

## Context

ET4 proves admitted zero-head ownership. ET5 must stage one scalar, reject stale
transactions without persistence, preserve old readers and reopen the first committed
mutable epoch without weakening immutable or legacy profile gates.

## Decision

Add internal EpochScalarCoordinator alongside the unchanged empty-chain prototype.
Select only an independently verified complete WAL/materialization chain. Capture each
transaction's owner, epoch, transaction ID, sequence and selected manifest digest; the
selected digest differs from the permanent BASE digest after the first commit.

Validate one text or ordinary attribute replacement in memory. Before writing WAL,
materialize a private generation and verify its hashes, metadata and exact scalar
transition using explicit ScalarWal admission. Flush epoch-bound WAL, publish the
complete generation, publish/reuse its stable reader identity, then atomically publish
CURRENT and acknowledge. All persistent writes/publications use ITransactionStorage.
Persistence errors fault the owner; reopen is required. Stale/unsupported operations
reject before persistent work. No stable reader identity is replaced or removed.

Reopen validates every required WAL, unique transaction ID, sequence/hash link, generation
witness, metadata/value transition, reader identity and present CURRENT prefix. A complete
WAL/materialization may select the new head even if CURRENT lags or is absent. A corrupt
present pointer never authorizes fallback. A missing generation needs redo and is
explicitly unsupported; torn/corrupt WAL, gaps and orphan generations fail closed.
No tail classification, replay, pointer repair or cleanup is introduced in ET5.

Independent admission and generation handles belong to snapshots and transactions,
including after owner disposal. Exact existing profile/authority bytes and frozen reader
binaries remain fixed. Public readers still refuse ScalarWal; root production is internal
fixture infrastructure. This is not a user migration or public mutable API.

## Consequences

Complete-history validation is linear in retained history and reads all required payloads;
query metrics exclude that validation. Retention and the 10,000-commit limit remain.
A failed commit can have an uncertain outcome: a later opener may select the new complete
head. Callers cannot infer rollback from an exception. ET6 must implement exhaustive
storage-fault coverage and redo before a broader recovery claim. Epoch backup/migration,
retirement, physical power-loss and real ENOSPC evidence remain separate gates.

## Validation

See [runtime contract](implementation/M2_EPOCH_SCALAR_COMMIT.md) and
[validation](implementation/M2_EPOCH_SCALAR_VALIDATION.md). Tests cover repeated commits,
stale conflicts, scalar restrictions, pinned uncached values, exact node/order/URI parity,
complete-chain fresh-process reopen and selected publication kills/lost acknowledgment.
