# ADR-034: Stopped Enrollment Restart and Explicit Owner Handoff

**Status:** Accepted; SR1 and bounded SR2-A/B/C implemented internally; SR3/SR4 unimplemented
**Date:** 2026-10-30
**Deciders:** Authorized continuation of the internal embedded pilot

## Context

[REQ-007](FEATURE_REQUESTS.md#req-007-mutable-epoch-authority-and-recovery),
[ADR-033](ADR-033-retained-source-exclusion-and-first-enrollment.md) and ER-004 require a
boundary between validating persisted Enroll bytes and authorizing a new live owner.
First enrollment ends stopped. Its source latch is object-local; read-only reopen cannot
restore the initializer, a returned receipt, prior host facts or actual source exclusion.
ER-003 also shows that physical handle availability and confirmed logical release differ.

## Decision

Adopt the [stopped restart/handoff contract](implementation/M2_STOPPED_ENROLLMENT_RESTART_CONTRACT.md).
Implement a pure stopped assessment first, followed separately by actual owner-bound evidence,
one-shot preparation and a qualified conditional handoff writer. Every assessment remains
stopped and inert. Valid empty or unsupported histories require reconciliation, corruption
rejects without repair, and an exact correlated Enroll is an observation rather than a receipt.

A future handoff uses existing TransferOwner v1 semantics with a distinct session and checked
successor generation. It preserves all bindings/history and requires fresh retained source,
parent and authority exclusion. It never clears the original owner's source latch. This ADR
adds no runtime permission, new format, public surface, persistent source fence or work writer.

## Consequences

### Positive

- Restart findings remain useful without manufacturing execution authority or old acknowledgment.
- Actual source exclusion and paired ownership must span verification and later conditional output.
- Bounded implementation gates separate pure classification from capability and persistence changes.

### Negative / Accepted Costs

- Every uncertain or unsupported restart remains stopped pending explicit reconciliation.
- Fresh operational facts require host evidence beyond checksums, owner locks and zero recorded work.
- Handoff needs later fault/process qualification even though its wire transition already exists.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Treat a valid Enroll as its old successful return | Persisted bytes cannot prove acknowledgment delivery |
| Reopen empty authority as a fresh initializer | Loses original successful provisioning capability and unknown prior state |
| Resume the original source on guard disposal | Violates the permanent armed stop latch |
| Enable handoff from a pure assessment | Descriptive facts cannot retain real ownership/exclusion |
| Add a new fence or journal role now | Changes frozen formats and requires a separate persistent-fencing design |

## References

- [Readiness review](implementation/M2_ENROLLMENT_READINESS_REVIEW.md)
- [ER-003 release contract](implementation/M2_ENROLLMENT_ROLE_RELEASE.md)
- [Frozen authority v1](implementation/M2_APPLICATION_AUTHORITY_FORMAT_V1.md)
- [ER-004 review](implementation/M2_STOPPED_ENROLLMENT_RESTART_REVIEW.md)

SR1 follow-up (2026-10-30): [pure classifier and qualification](implementation/M2_ENROLLMENT_RESTART_CLASSIFIER_VALIDATION.md)
implement supplied-observation classification only. Original design-step evidence remains
historical. No actual owner-bound observation or handoff capability is implemented; next SR2.

SR2 design follow-up (2026-10-30): [owned observation design](implementation/M2_OWNED_RESTART_OBSERVATION_DESIGN.md)
requires a separate restart-only source child and actual paired observation, without fabricating
old capture associations or hiding live recovery. Next SR2-A; SR2 runtime remains unimplemented.

Readiness follow-up (2026-10-30): [SR1/SR2 review](implementation/M2_STOPPED_RESTART_READINESS_REVIEW.md)
updates the current implementation status while preserving dated design evidence. Before SR3,
define private successful-proof consumption, actual plan-child drain and successor binding;
no observer/descriptor becomes executable authority. All host/release/retirement gates remain open.


SR3-A design follow-up (2026-10-30): [preparation/lifetime contract](implementation/M2_STOPPED_HANDOFF_PREPARATION_CONTRACT.md)
resolves RR-002/003/004 at the design level only. Private proof, actual child drain and
paired-parent successor binding are specified, not implemented. Next SR3-B1 adds proof/lifetime
primitives; preparation/claim and SR4 output remain later gates. Original execution evidence
and all host/public/archive/fencing/retirement limitations remain unchanged.
