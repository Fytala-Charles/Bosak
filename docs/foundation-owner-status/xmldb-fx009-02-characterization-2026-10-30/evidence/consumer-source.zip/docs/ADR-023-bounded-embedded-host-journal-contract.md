# ADR-023: Bounded Embedded Host Journal Contract

**Status:** Accepted internal prototype design; pure codec implemented internally; ownership and persistence pending
**Date:** 2026-10-28
**Deciders:** Local implementation within the user-selected single-process embedded pilot

## Context

[ADR-022](ADR-022-single-process-embedded-pilot-host.md) selects a controlled embedded pilot
and proposes a local file ledger. [ADR-021](ADR-021-host-attempt-ledger-and-publisher-exclusion.md)
requires durable intent, uncertain-outcome preservation and no descriptor replay. Model and
integration tests do not specify actual bytes, append/flush boundaries or corruption recovery.
REQ-006/007 need a separate host authority contract before file-backed orchestration.

## Decision

Specify an internal, versioned host journal outside every store/artifact/candidate root.
Use bounded little-endian frame headers, canonical typed TLV snapshot payloads, a SHA-256
previous-frame chain and a complete-frame seal. Bind journal ID and configured deployment/scope
through immutable host metadata. Use explicit wire enum mappings, not runtime enum ordinals.
Retain all attempt transitions; enforce both frame ordering and per-attempt transition rules.

A single cooperative host lease and one serialized append operation protect conditional updates.
A commit returns only after a complete validated frame has been written and file-flushed with
Flush(true) under the selected ProcessCrash policy. Any write/flush/acknowledgment uncertainty
faults the live append session. Valid bytes are not proof that acknowledgment or invocation
occurred; restart always begins stopped. No journal read produces an executable plan.

Reject malformed, corrupt, unsupported, oversized, linked or scope-mismatched state. Retain
incomplete tails and block appends; do not truncate, resynchronize, rotate, compact, reset or
adopt a validated prefix as current authority automatically. Hash chaining cannot detect a
whole valid-prefix rollback without an independent anchor and does not authenticate writers.
Offline restore/rollback and hostile modification remain unsupported reconciliation cases.

Initial provisioning is explicit and separate from reopen. Partial provisioning is never
silently repaired. Metadata and ownership-file identities remain fixed; no deleting/recreating
active lock files. Stronger durability, production routing/work authority, physical loss and
public exposure remain separate gates. The [journal contract](implementation/M2_EMBEDDED_HOST_JOURNAL_CONTRACT.md)
defines bytes, semantic validation, commit/restart behavior and required evidence.

## Consequences

### Positive

- Codec and filesystem fault tests have concrete independent byte/transition expectations.
- Lost acknowledgments and incomplete tails cannot silently rearm dispatch.
- Host metadata remains separate from frozen store provenance and sealed inputs.

### Negative / Accepted Costs

- A partial tail stops append availability until separately reviewed reconciliation.
- Size limits stop writes; compaction and journal replacement are not introduced.
- Complete-prefix rollback requires independent evidence or manual reconciliation.
- ProcessCrash qualification does not establish physical durability or a production host.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Unbounded JSON lines or runtime object serialization | Ambiguous field/version policy, allocation bounds and runtime representation drift |
| Truncate any invalid final frame | Could discard committed authority or conceal corruption |
| Dispatch from a complete journal frame after restart | Bytes cannot recreate owner-bound plans or prove executor outcome |
| Trust hash chains as anti-rollback/authentication | A valid prefix can be replayed and hashes can be recomputed by a malicious writer |
| Reuse store WAL/FORMAT/provenance | Creates unintended recovery authority and changes frozen storage boundaries |

## References

- [Embedded profile](implementation/M2_EMBEDDED_HOST_PROFILE.md)
- [Journal contract](implementation/M2_EMBEDDED_HOST_JOURNAL_CONTRACT.md)
- [Attempt identity contract](implementation/M2_ADMINISTRATIVE_ATTEMPT_CONTRACT.md)
- [REQ-006/007](FEATURE_REQUESTS.md)


Codec follow-up: [internal validation](implementation/M2_HOST_JOURNAL_CODEC_VALIDATION.md)
adds bounded parsing/history semantics and independent fixtures. No durable writer or host
lease is implemented. Version 1 disallows independent-destination same-request retries because
the snapshot schema contains no such reasoning; preservation/exclusion gates remain mandatory.
