# ADR-002: Immutable M1 Format and Snapshot Contract

- Date: 2026-10-26
- Status: Implemented for the M1 experiment; not a published compatibility promise
- Request: REQ-002

## Context

M1 must reopen persisted XML without parsing source XML, navigate through unchanged
Bosak XDM interfaces and avoid reading line payloads for header queries.

## Decision

Use explicit little-endian format 1.0 with SHA-256 integrity for every file, numeric
IDs in paths, bounded lengths, an eager structural directory and lazy UTF-8 payload
fragments. See [format specification](implementation/BINARY_FORMAT_V1.md).

The new immutable store owns one imported document. Import publishes into a new
root and refuses replacement. Document/element values aggregate descendant text;
scalar values have fragment/offset/length pointers. Namespace bindings are explicit
per-element metadata nodes; the directory never embeds scalar text values.

A snapshot owns a byte-bounded LRU decoded-fragment cache. It is confined to one
evaluation thread, with no concurrent disposal contract. Node wrappers use logical
node ID plus snapshot identity for IsSameNode, CLR equality and hashing. Within one
snapshot the document ID is fixed. Cross-snapshot wrappers are distinct in M1.

Node IDs are canonical preorder IDs and also provide nonzero immutable document order.
This is safe for immutable M1; mutable insertion/order design remains M2 work. Directory
validation checks graph ownership, reachability, link order, pointers and depth.

Direct axes and the BindResult evaluation wrapper validate lifetime on each fetch.
Callers must use BindResult for VM-produced lazy sequences because the VM may own a
materialized sequence that cannot be retroactively made snapshot-aware. No compiler
or VM modifications are made.

## Consequences and Deviations

The importer currently materializes a bounded XDocument and metadata before writing;
reads are lazy, ingestion is not a streaming-memory claim. XML 1.0 untyped documents
are supported; DTD/external entities are rejected. Text/CDATA serialize as equivalent
text, without preserving lexical CDATA boundaries. Stored namespace axis order is
implementation defined and bindings are compared as sets.

An experiment found that Bosak 1.26.2 XDocumentNode.Attributes() includes xmlns
attributes, while Axis(Attribute) correctly excludes them. XmlDb follows XDM and
uses the latter as its differential oracle. Minimal reproduction:

```csharp
var root = XDocument.Parse("<r xmlns:p='urn:p' a='1'/>").Root!.ToXdmNode();
// Attributes() yields xmlns:p and a; Axis(XdmAxis.Attribute) yields only a.
```

No upstream fix is made. Namespace/attribute scalar serialization follows the actual
provider: namespace serialization is empty and attribute serialization is its value.

There is no WAL, transaction, locking, fsync durability or crash-safe publication
claim. Checksums detect corruption, not malicious replacement/authentication. Store
files are assumed immutable while snapshots are open. No format migration exists;
unsupported major/minor versions are rejected. Revise versions and fixtures explicitly
for future encoding changes before any persisted data is distributed.

*Last updated: 2026-10-26*
