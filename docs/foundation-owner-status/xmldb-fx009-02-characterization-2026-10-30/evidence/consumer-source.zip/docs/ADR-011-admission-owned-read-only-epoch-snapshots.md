# ADR-011: Admission-Owned Read-Only Epoch Snapshots

**Status:** Implemented experimental sequence-zero reader  
**Date:** 2026-10-27  
**Deciders:** Bosak.XmlDb implementation within authorized M2 work

## Context

[REQ-006](FEATURE_REQUESTS.md) and [ADR-010](ADR-010-mandatory-epoch-format-and-admission-primitives.md)
prove mandatory metadata and OS admission, but not actual lazy XML reads after owner
disposal. Integrating the existing immutable snapshot and XDM adapter is the next gate
before an epoch coordinator, migration or any retirement can be considered.

## Decision

Expose a separate ReadOnlyEpochDatabase.Open(root) and BeginRead(cacheBytes) entry point.
It accepts only complete immutable major-2 roots with a bound sequence-zero SNAPSHOT
record. Legacy ImmutableXmlSnapshot.Open and EmbeddedXmlDatabase.Open remain format-1
entry points and reject major 2. No automatic format guessing, writer or migration is added.

The root contains FORMAT/EPOCH/.epoch/admission.lease, SNAPSHOT (BXES 1.0), documents and
fragments. Reuse existing manifest/directory/fragment envelopes and exact bytes so node
IDs, topology/order, namespace metadata, document URI and scalar values are preserved.
There is no nested legacy FORMAT that could become an accidental private M1 entry point.
SNAPSHOT binds StoreId/EpochId/document, sequence zero, full FORMAT hash and manifest hash.
Nonzero sequence and any .transactions directory/file fail closed, preventing stale
base reads if an unsupported mutable layout is encountered.

Open acquires shared admission before descriptor/metadata selection. It owns only its
session handle. Each BeginRead forks a separate OS handle and transfers it to the returned
ImmutableXmlSnapshot, including failure cleanup. A child survives session disposal and
blocks exclusive maintenance until snapshot disposal/process exit. The existing snapshot
payload cache, lazy hash validation, metrics and PersistentXdmNode adapter are reused.
Open loads/validates structural metadata, not payloads; lazy corruption is detected on
payload access. No public data method writes to the epoch root.

Factor immutable metadata loading internally while keeping the legacy FORMAT check
unchanged. The epoch bypass requires a live shared token bound to the exact root/identity
and expected manifest digest. It is internal and takes ownership on success or failure.
The session gate serializes snapshot selection against its own disposal; it already owns
shared admission and the child fork is nonblocking. A future mutable coordinator must
still acquire admission before coordinator/generation locks, not copy a wait-under-gate
pattern from this immutable session.

Extend internal fixture bootstrap with a prepublication preparation callback. The fixture
producer accepts only unadopted immutable format-1 sources, copies canonical data without
FORMAT, writes SNAPSHOT, verifies every fragment digest/value and publishes the entire
root only after verification handles close. Existing roots and transactional sources are
refused. The original remains intact. There is no public epoch importer/exporter or
history-preserving migration API. Sample read-epoch demonstrates the public reader on a
prepared root; tests/probes are the only producer at this stage.

## Consequences

### Positive

- Actual uncached XPath reads remain valid after session disposal and hold maintenance exclusion.
- Existing XDM behavior and header-query avoidance of line I/O remain unchanged.
- Frozen format-1 readers reject fully populated epoch roots, not just metadata fixtures.
- Complete-root publication has fault sweeps and process-kill evidence before migration.

### Negative / Accepted Costs

- Only sequence zero is supported; epoch transactions, WAL recovery and backups are unsupported.
- No public creation/migration/cutover workflow exists. Full C1-C3/R1-R3 remain incomplete.
- Open validates metadata; callers must read payloads to detect lazy payload corruption.
- Admission is cooperative; no source history or stable lease may be removed.
- No physical power-loss/real ENOSPC or production-filesystem certification is added.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Teach every legacy Open to silently accept major 2 | Weakens explicit compatibility boundary |
| Return a wrapper without an independently owned snapshot lease | Session disposal could release a live lazy reader's protection |
| Place an entire M1 store under data/ | Would provide a private path with a legacy FORMAT and no admission |
| Ignore transaction state and read sequence zero | Could silently expose stale data from an unsupported mutable root |
| Expose the fixture producer as migration | It deliberately rejects transactional history and has no cutover contract |

## References

- [Descriptor and reader contract](implementation/M2_READONLY_EPOCH_SNAPSHOT.md)
- [Validation](implementation/M2_READONLY_EPOCH_VALIDATION.md)
- [Compatibility and retirement protocol](implementation/M2_COMPATIBILITY_BACKUP_RETIREMENT.md)

*Last updated: 2026-10-27*
