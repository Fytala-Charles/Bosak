# ADR-014: Admitted Empty-Chain Epoch Coordinator

**Status:** Implemented internal ET4 empty-chain ownership slice  
**Date:** 2026-10-27  
**Deciders:** Bosak.XmlDb implementation within authorized M2 work

## Context

[REQ-007](FEATURE_REQUESTS.md) and [ADR-013](ADR-013-epoch-profile-and-authority-codecs.md)
freeze explicit mutable profiles and authority bytes. Before scalar commits, prove a
real coordinator's admission/writer order, root authority validation and independently
owned snapshot/transaction handles. Nonempty WAL must not be mistaken for sequence zero.

## Decision

Implement internal EpochEmptyCoordinator and an isolated immutable-source fixture producer.
No public mutable open/creation or commit API is exposed. The coordinator accepts only
a complete ScalarWal 2.1 root with verified BASE/CONTROL, required canonical directories,
no WAL entries or published generations, and optional valid CURRENT at zero. Unknown
transaction state and positive reader/head state are unsupported. Corrupt required data
fails closed. Reject unsupported/nonempty state before creating the writer lock.

Admission APIs gain an explicit profile parameter defaulting to immutable. Tokens retain
their profile and ForkShared preserves it. Existing public readers/admission defaults
remain strict; mutable admission is an explicit internal path. Acquire shared admission,
validate role/base and all payloads, then acquire exclusive writer ownership and recheck
authority before runtime publication. Owner disposal closes only its writer/admission.

Atomically publish a canonical zero-sequence BXER reader identity through the storage
seam; validate/reuse it on reopen and never overwrite/unlink it. BeginRead acquires an
operation admission child before the coordinator gate, checks availability/empty state,
acquires a shared base-reader handle, and transfers both to ImmutableXmlSnapshot.
Snapshots retain the unchanged XDM/lazy-cache semantics after owner disposal. Errors
close only owned handles; an operation losing a race to Dispose cannot escape a snapshot.

BeginTransaction returns an internal ownership context with transaction ID, owner/epoch,
base sequence/hash and an independently protected snapshot. It supports base reads and
rollback/disposal, but no target staging or Commit. This proves pending-transaction handle
lifetimes without granting mutation. ET5 remains the scalar-operation boundary.

Stronger adoption explicitly skips writable flushes of the active admission identity,
as it already skips stable generation identities. Both were file-flushed before atomic
publication; their namespace and other data are still synchronized. The new skip path
is opt-in for admitted epoch roots; existing format-1 adoption behavior is unchanged.

The [ownership contract](implementation/M2_EMPTY_EPOCH_COORDINATOR.md) fixes initialization,
failure/reopen behavior and limits. No authority/WAL wire format, frozen fixture or
source history is changed. Existing public immutable APIs continue rejecting ScalarWal.

## Consequences

### Positive

- Empty-chain selection is protected by actual admission/writer/base-reader ownership.
- Snapshots and transaction contexts outlive owners without losing maintenance exclusion.
- Native Linux stronger reopen works while old snapshots remain alive.
- Fault/kill and deterministic disposal-race proof precede actual commits/replay.

### Negative / Accepted Costs

- Opening validates the entire base before returning; query counters exclude that work.
- Initialization creates writer.lock and the stable zero reader; private failed temporary
  identities may remain and are never promoted or automatically removed.
- Nonempty history, scalar staging/commit/replay, epoch backup and migration are unsupported.
- Complete historical-reader C1-C3, retirement and physical durability remain unproven.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Return the base when WAL/generation entries exist | Silently returns stale state |
| Implicitly widen immutable admission to mutable | Breaks explicit capability negotiation |
| Acquire admission while already selecting under the coordinator gate | Creates a disposal/maintenance lock-order risk |
| Share the owner's only handles with children | Owner disposal would release live-reader protection |
| Flush active admission identities by opening them for write | Conflicts with valid shared handles |
| Add scalar commits with ownership initialization | Would merge ET5+ publication/recovery work with ET4 review |

## References

- [Ownership/runtime contract](implementation/M2_EMPTY_EPOCH_COORDINATOR.md)
- [Validation](implementation/M2_EMPTY_EPOCH_VALIDATION.md)
- [Mutable behavior design](implementation/M2_MUTABLE_EPOCH_CONTRACT.md)

*Last updated: 2026-10-27*
