# ADR-024: Explicit No-Overwrite Host Provisioning

**Status:** Accepted controlled-scope internal implementation; durability/application release gates remain open
**Date:** 2026-10-28
**Deciders:** Authorized continuation of the user-selected single-process embedded pilot

## Context

[ADR-022](ADR-022-single-process-embedded-pilot-host.md) selects a controlled local embedded
host. [ADR-023](ADR-023-bounded-embedded-host-journal-contract.md) separates explicit provisioning
from reopen and preserves interrupted state. Existing-root lifetime ownership is qualified,
but creating the initial three roles and handing ownership to the caller needs a protocol.
REQ-006/007 must not gain an implicit reset/repair path through initialization.

## Decision

Require fresh bound operator/host assertions that this target has no prior host and that only
cooperating provisioners can mutate its namespace. Require an absent target and an existing,
stable, unlinked parent outside protected data roots. Reject every pre-existing target,
including empty directories, partial hosts, apparently healthy hosts and ordinary files.
These assertions are not authentication or facts inferred from missing files.

After absent-root preflight, cooperating contenders may race directory creation. Directory
creation is not an exclusive claim. Check for occupancy and atomically create owner.lock
with CreateNew/ReadWrite/FileShare.None; exactly one contender can own that file. All remaining
role creation also uses CreateNew. Never delete a failed contender's root/files or complete a
partial prior invocation. This protocol relies on the asserted stable controlled parent;
it does not protect against arbitrary foreign empty-directory creation, namespace replacement
or hostile actors between path checks.

While continuously holding the CreateNew owner handle, flush the empty owner file, write/flush
canonical host.meta and create/flush empty journal.bin using explicit ProcessCrash policy.
Request policy directory barriers, recheck namespace/lengths and read back exact metadata under
ownership. Transfer the same owner handle directly into EmbeddedHostLifetime, without an
unlock/reopen gap. Administrative admissions and all database writers remain stopped.

WasProvisionedHere records only that this live object came from successful explicit provisioning.
It is not serialized, not a writer/dispatch permit and is false on every OpenExisting call,
including valid empty roots left by unacknowledged creation. A callback/I/O/return-loss failure
may leave a valid root but cannot retroactively become an acknowledged provisioning result.

[Provisioning validation](implementation/M2_EMBEDDED_HOST_PROVISIONING_VALIDATION.md) records
checkpoint/storage faults and real process interruption/contention. Stronger policy requests
reject; physical power loss, hostile namespaces, durable journal append and application routing
remain outside this step.

## Consequences

### Positive

- Initial creation and reopen have separate, explicit authority boundaries.
- CreateNew protects role bytes and a continuous owner handle protects cooperative handoff.
- Interrupted/unknown outcomes preserve evidence instead of silently retrying or repairing.

### Negative / Accepted Costs

- Partial roots remain unavailable until separately reviewed reconciliation; no cleanup tool is added.
- Controlled namespace and no-prior-host assertions must come from the actual host/operator.
- No arbitrary-alias, adversarial-parent, physical-loss or distributed-fencing guarantee follows.
- Empty reopened journals carry no original-initializer diagnostic or automatic first-write permission.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| OpenOrCreate all missing roles | Could overwrite or complete unknown prior host state |
| Treat Directory.CreateDirectory as atomic ownership | It succeeds when another participant already created the directory |
| Close the owner file before constructing the lifetime | Introduces a cooperative acquisition gap during handoff |
| Delete partial roles on failure | Discards evidence and may affect another contender's state |
| Publish through a renamed staging root with an active lock | Requires separate platform-specific rename/identity proof not supplied here |

## References

- [Embedded profile](implementation/M2_EMBEDDED_HOST_PROFILE.md)
- [Existing ownership](implementation/M2_EMBEDDED_HOST_OWNERSHIP_VALIDATION.md)
- [Provisioning validation](implementation/M2_EMBEDDED_HOST_PROVISIONING_VALIDATION.md)
- [REQ-006/007](FEATURE_REQUESTS.md)
