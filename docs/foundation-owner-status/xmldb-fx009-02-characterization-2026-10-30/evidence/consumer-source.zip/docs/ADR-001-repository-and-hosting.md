# ADR-001: Separate Repository and Shared Engine

- Date: 2026-10-26
- Status: Accepted for setup, as recorded in the supplied M1 plan
- Request: REQ-001 and REQ-002 in FEATURE_REQUESTS.md

## Context

The persistent fragment provider must evolve without changing Bosak compiler/VM
or introducing infrastructure requirements into embedded applications.

## Decision

Use the product name Bosak.XmlDb in a separate repository. Core has no Bosak
reference; Storage references Core; Xdm references Core and Storage and later
minimal pinned Bosak dependencies. Embedded M1 is the first consumer. A future
server must reuse the same engine, physical format and query semantics.

Keep the existing checkout folder Bosal.XmlDb. Do not rename it implicitly.
No remote repository is created and no upstream source is modified.

## Consequences

M0 provides empty runtime projects and dependency guard tests. Pin and verify
upstream provenance before implementing the adapter. No server, NATS, Docker or
Kubernetes runtime is needed. License choice and publication remain owner decisions.

*Last updated: 2026-10-26*
