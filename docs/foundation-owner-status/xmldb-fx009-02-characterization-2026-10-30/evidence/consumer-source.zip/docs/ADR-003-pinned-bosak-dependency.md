# ADR-003: Pin Bosak 1.26.2 Packages

- Date: 2026-10-26
- Status: Implemented
- Request: REQ-002

## Decision and Evidence

Use exact NuGet references [1.26.2] for Bosak.XPath.Core in Xdm and for
Bosak.XPath.Api / Bosak.XPath.Providers in tests and the sample. Storage and Core
remain independent of Bosak. Generated packages.lock.json files pin transitive
resolution; CI restores with --locked-mode.

The installed package nuspec files identify repository commit
6a3372fc3b91e733b71a426cf40f26feaaeb3bcb. git cat-file verified this commit exists
in D:/Development/Bosak. Its IXdmNode source was inspected, and compilation and
differential tests validate actual package APIs. The local source checkout currently
points to d00a8fb0dcc2e6a0fe9a761838d15495bdba9808; it is not used as a moving dependency.
Untracked upstream documentation remains untouched.

The original design's archive baseline 927d7a458dd90a8b506840c045808f4f27e3c8d1
remains historical input, not the selected implementation baseline. No source
references, upstream source edits or compiler/VM changes are introduced.

The owner selected proprietary Fytala licensing for XmlDb. Bosak dependencies retain
their Apache-2.0 license; see [third-party notices](../THIRD-PARTY-NOTICES.md).
Packaging remains disabled for this experimental API.

## Consequences

To develop against source, create an immutable checkout of the recorded package
commit, verify its hash, and explicitly replace package references with matching
project references. Switching back requires restoring exact package pins and rerunning
restore, build and the full differential suite. Never silently reference main.

*Last updated: 2026-10-26*
