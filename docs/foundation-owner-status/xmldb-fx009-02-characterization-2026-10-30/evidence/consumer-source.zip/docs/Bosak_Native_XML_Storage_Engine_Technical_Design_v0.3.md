# Bosak Native XML Storage Engine — Technical Design v0.3

**Date:** 2026-10-26  
**Status:** Revised architecture proposal; distributed durability and fencing are unproven and require prototypes  
**Baseline:** User-supplied `Bosak-main.zip` (commit SHA not established)  
**Related:** OAGIS-Native Distributed Business Object Architecture v0.2

> This design separates **verified Bosak source findings** from **proposed C# interfaces**. The latter are illustrative, not yet compiled against Bosak.

## 1. Architectural decision

Use Bosak's existing XDM and XPath/XQuery compiler as the query layer over a snapshot-bound persistent XML node provider. Store logical XML documents in optimized, versioned fragments; introduce secondary indexes and an optional storage-aware planner after correctness is proven. The **same storage engine** supports embedded mode and distributed entity-service mode. In embedded mode the local WAL is authoritative; in the proposed distributed log-first mode an ordered, durably accepted transaction record is authoritative, with local fragments as a replayable materialization. NATS request/reply handles service communication and JetStream is a candidate replicated transaction log and event transport. These are deployment-specific commit protocols, not interchangeable durability guarantees.

```mermaid
flowchart TB
 A[Applications / BOD gateway] --> E[OAGIS entity services]
 E <--> N[NATS request/reply]
 E --> Q[Bosak XPath / XQuery / XSLT]
 Q --> P[Optional physical query planner]
 Q --> X[Existing IXdmNode / XDM]
 P --> D[Persistent XDM provider]
 X --> D
 D --> S[Versioned XML fragments]
 S --> I[Node directory / secondary indexes]
 S --> W[WAL / MVCC / manifests]
 E --> O[Transactional outbox]
 O --> J[JetStream]
```

**Initial non-goals:** full XQuery Update, adaptive fragmentation, cross-service ACID transactions, distributed XQuery joins, and full BaseX parity.

## 2. Verified source integration points

The following source paths and lines were inspected in the supplied ZIP.

| File | Verified behavior | Design impact |
|---|---|---|
| `src/Bosak.XPath.Core/Xdm/IXdmNode.cs` (41–190) | `Parent`, `Document`, `Children`, `Attributes`, `Axis`, `IsSameNode`, `DocumentOrder`, typed/schema properties | Persistent node adapter can implement existing interface |
| `src/Bosak.XPath.Compiler/Optimizer/XPathOptimizer.cs` (75–86) | `Optimize` entry points | Preserve storage-independent AST rewriting |
| `src/Bosak.XPath.Compiler/Ir/IrLowerer.cs` (1466–1518) | `PathStepMap` per-context predicates and `Normalize` | Preserve positional/context semantics in index plans |
| `src/Bosak.XPath.Compiler/Ir/IrLowerer.cs` (1541+) | Axis instruction followed by name/namespace tests | Candidate for fused index-backed access |
| `src/Bosak.XPath.Compiler/Ir/IrOpCode.cs` (64+) | Internal byte opcode enum | Avoid opcode modifications initially |
| `src/Bosak.XPath.Api/XPath31Expression.cs` (174–182) | Optimizer then IR lowerer | Potential planning integration point |
| `src/Bosak.XQuery/Api/XQueryCompiler.cs` (~182) | Optimizes query body | Shared query-planning approach |
| `src/Bosak.XPath.Runtime/Vm/VmEngine.cs` | VM execution implementation | Profile axis and normalization costs before changing |

This is a targeted source-level assessment, not a completed build, test run, or comprehensive compiler audit.

## 3. Existing `Bosak.XPath.Providers.Database`: source-level findings

### 3.1 Verified scope and code map

The existing package is a **remote XML database document and collection adapter**, not a native node-store engine. Source inspected in the supplied ZIP:

| File | Verified role | Recommendation |
|---|---|---|
| `src/Bosak.XPath.Providers.Database/DatabaseDocumentLoader.cs` | Public static `Load`, `LoadStreaming`, `Dispatch`, `DispatchStreaming`, `DispatchCollection`; integrates with `EvaluationContext` loaders | Preserve behavior and public API; reuse dispatch pattern |
| `DatabaseScheme.cs` | Scheme registry, BaseX/eXist-db/MarkLogic REST URI mapping and collection-listing hooks | Retain as remote-specific infrastructure |
| `DatabaseLoaderOptions.cs` | Remote connection configuration | Keep remote credentials separate from native storage options |
| `ResponseBoundStream.cs` | Response stream lifetime management | Keep for remote HTTP retrieval only |
| `tests/Bosak.XPath.Providers.Database.Tests/DatabaseDocumentLoaderTests.cs` | Document-loader tests | Run as regression gate |
| `tests/Bosak.XPath.Providers.Database.Tests/DatabaseCollectionLoaderTests.cs` | Collection-loader tests | Run as regression gate |

`DatabaseDocumentLoader.Dispatch(fallback, options)` (around lines 130–133) selects registered database schemes and otherwise calls the fallback. `DispatchStreaming` (around lines 146–149) is its streaming counterpart. `Load` and `LoadStreaming` (around lines 165 and 192) return `IXdmNode` through existing materialized or streaming providers. `DispatchCollection` (around line 321) resolves collection listings. The registry maps `basex`, eXist-db and MarkLogic schemes to HTTP REST endpoints. **No evidence in these files establishes native persistent fragments, MVCC, indexes, or query pushdown.**

### 3.2 Preserve, extend, or replace?

- **Preserve** `DatabaseDocumentLoader`, `DatabaseScheme`, `DatabaseLoaderOptions`, `ResponseBoundStream`, their remote URI behavior, and regression tests.
- **Extend by composition**, not by turning the remote loader into the storage engine: register a native resolver at the evaluation boundary.
- **Create separately** the native fragment store, snapshot-bound `IXdmNode` provider, index services, and physical query planner.
- **Do not assume** that a `doc()` loader delegate is sufficient for all database operations. `collection()` requires separate collection resolution; indexed queries require a planning capability; updates require write transactions.

### 3.3 Document resolution and lifetime design

A native URI such as `bosak://sales/orders/12345` is illustrative and must have a specified URI-to-database/document mapping, authorization checks, and stable document identity. Do not register `bosak` through the remote HTTP `DatabaseScheme` implementation.

```csharp
// Proposed API: not present in Bosak source and not compiled.
public interface IXdmReadContext
{
    IXmlReadSnapshot Snapshot { get; }
    CancellationToken CancellationToken { get; }
}

public interface IXdmDocumentSource
{
    bool CanResolve(Uri uri);
    IXdmNode Resolve(Uri uri, IXdmReadContext context);
}

public interface IXdmCollectionSource
{
    bool CanResolve(Uri uri);
    IReadOnlyList<IXdmNode> Resolve(Uri uri, IXdmReadContext context);
}

public interface IXdmSourceRegistry
{
    IXdmNode ResolveDocument(Uri uri, IXdmReadContext context);
    IReadOnlyList<IXdmNode> ResolveCollection(Uri uri, IXdmReadContext context);
}
```

These are **design contracts**, not drop-in declarations: `IXmlReadSnapshot` and `IXdmNode` types/namespaces must be reconciled with the final assembly layout. For the first milestone, use the existing `EvaluationContext.DocumentLoader` and `CollectionLoader` hooks through an adapter that **captures one read snapshot for the entire evaluation**. The evaluation owner opens and disposes that snapshot; the loader must never return a node whose snapshot has already been disposed. If the current context API cannot express the lifetime safely, add a scoped evaluation wrapper rather than hidden ambient state.

```mermaid
flowchart TD
 Q[XPath / XQuery evaluation] --> R[Scoped source registry]
 R -->|file URI| F[Existing file provider]
 R -->|basex / exist / marklogic| E[Existing remote DatabaseDocumentLoader]
 R -->|bosak URI| N[Native document resolver]
 E --> M[Materialized or streaming IXdmNode]
 N --> S[Read snapshot]
 S --> P[Persistent IXdmNode]
 P --> X[Fragment store + node directory]
 R --> C[Collection resolver]
 C -->|native| S
 C -->|remote| E
```

### 3.4 Migration and compatibility rules

1. No breaking changes to existing database URI schemes or remote loader delegates in the initial prototype.
2. Native URI handling must be opt-in and must not silently shadow a remote or file scheme.
3. `fn:doc()` must return stable logical document identity within an evaluation; `fn:collection()` must use the same snapshot for native documents.
4. Cross-document order, duplicate elimination, missing documents, URI errors, and fallback behavior need differential tests.
5. Streaming providers may have navigation restrictions; do not treat their behavior as proof that a random-access persistent provider is correct.
6. Credentials, remote HTTP client lifetime, and native storage authorization remain separate concerns.

### 3.5 Benchmark distinction

Benchmark these separately: (A) Bosak in-memory query, (B) Bosak evaluating XML fetched from BaseX via the existing connector, (C) BaseX executing the query server-side with its own indexes, and (D) Bosak querying the proposed native store. **B is not a fair proxy for C**; include transport and parsing costs explicitly. Compare equivalent query semantics, dataset size, warm/cold cache, and concurrent load.

## 4. Proposed project decomposition

```text
Bosak.XmlDb.Abstractions    DB, snapshot and storage contracts
Bosak.XmlDb.Storage         Fragment codec, manifests, WAL, caches
Bosak.XmlDb.Indexing        Node directory, name/path/value indexes
Bosak.XmlDb.Xdm             Persistent IXdmNode and cursors
Bosak.XmlDb.Resolution      Native URI/collection resolver and scoped evaluation adapter
Bosak.XmlDb.Query           Index capabilities and physical planning
Bosak.XmlDb.Transactions    MVCC, write sets, commits, recovery
Bosak.XmlDb.Oagis           Noun policies and BOD mapping
Bosak.XmlDb.Nats            Service transport and outbox publisher
Bosak.XmlDb.Tests           Differential, concurrency, crash tests
Bosak.XmlDb.Benchmarks      BaseX / JSONB comparison harness
```

Dependency rule: existing `Bosak.XPath.Core` must not depend on database implementation; the generic storage engine must not depend on OAGIS or NATS. Existing `Bosak.XPath.Providers.Database` remains the remote connector package and is not renamed or replaced.

## 5. Stable identity and snapshots

Distinguish durable **DocumentId**, stable **NodeId**, and snapshot-dependent **order token**. Fragment relocation must not change NodeId. Node IDs must not be reused after deletion. A read snapshot must provide a consistent view of header, lines, indexes and metadata.

```csharp
// Proposed types; IXdmNode is the existing Bosak contract.
public readonly record struct DocumentId(ulong Value);
public readonly record struct NodeId(ulong Value);
public readonly record struct FragmentId(ulong Value);
public readonly record struct CommitSequence(ulong Value);
public readonly record struct NodeAddress(
    DocumentId Document, NodeId Node, CommitSequence Snapshot);

public interface IXmlReadSnapshot : IDisposable
{
    CommitSequence Sequence { get; }
    IXdmNode OpenDocument(DocumentId document);
    bool TryOpenNode(NodeAddress address, out IXdmNode? node);
}
public interface IXmlDatabase : IAsyncDisposable
{
    IXmlReadSnapshot BeginRead();
    ValueTask<IXmlWriteTransaction> BeginWriteAsync(
        CancellationToken ct = default);
}
```

**Invariants:** lazy sequences cannot outlive their snapshot; a disposed snapshot fails predictably. `IsSameNode` must respect node identity, while node order can be rebalanced. Existing `DocumentOrder` is a `long` and may be zero if unknown; global multi-document ordering needs an explicit comparison policy. Preserve XPath namespace, attribute, ancestor, reverse-axis, and positional semantics.

## 6. Fragment physical design

```mermaid
flowchart LR
 M[Document manifest] --> H[Header fragment]
 M --> L1[Line group fragment 1]
 M --> L2[Line group fragment 2]
 M --> C[Cold extensions / blobs]
 H --> ND[Node directory]
 L1 --> ND
 L2 --> ND
 ND --> IX[Path / name / value indexes]
```

| Physical structure | Suggested fields | Purpose |
|---|---|---|
| Document manifest | magic, version, DocumentId, root NodeId, schema ID, commit, directory pointer, checksum | Atomic document root |
| Fragment header | FragmentId, DocumentId, born commit, codec, sizes, checksum | Immutable fragment generation |
| Node record | NodeId, parent, kind, QName symbol, child/sibling pointers, value pointer, order token | Compact navigation |
| QName dictionary | namespace URI, local name, prefix | Name interning with XML fidelity |
| Value arena | typed/UTF-8 bytes, offset, length | Avoid managed object per value |
| Node directory | document/node + visibility -> fragment offset | Identity-preserving relocation |
| Index posting | typed key -> NodeIds + visibility | Index-based candidate access |

Use versioned explicit binary encoding, checksums and bounds checks; never persist raw CLR struct layouts. Copy-on-write fragment generations permit readers to retain older snapshots. Reclamation occurs after old readers release their snapshots.

```csharp
public readonly record struct FragmentPointer(
    FragmentId Fragment, uint Offset, uint Length);
public readonly record struct NodeDirectoryEntry(
    DocumentId Document, NodeId Node, FragmentPointer Location,
    CommitSequence VisibleFrom, CommitSequence? VisibleUntil);

public enum FragmentPlacement { Inline, RepeatingCollection, ColdBlob }
public sealed record FragmentRule(
    string XPathPattern, FragmentPlacement Placement,
    int TargetBytes, string? IndexProfile);
public interface IFragmentPolicy
{
    string Version { get; }
    IReadOnlyList<FragmentRule> Rules { get; }
}
```

Fragmentation rules should be compiled when deploying a schema/profile, not interpreted on every node read. Policy migration must preserve node identity and logical document order. Initial SalesOrder policy: header, line groups, cold attachments and extensions.

## 7. Persistent XDM adapter

```csharp
// Skeleton only: all existing IXdmNode members must be implemented.
public sealed class PersistentXdmNode : IXdmNode
{
    private readonly IXmlReadSnapshot _snapshot;
    private readonly NodeAddress _address;
    private readonly INodeAccessor _accessor;
}
public interface INodeAccessor
{
    NodeMetadata Read(NodeAddress node);
    IEnumerable<NodeAddress> Children(NodeAddress parent);
    IEnumerable<NodeAddress> Attributes(NodeAddress element);
    IEnumerable<NodeAddress> Axis(NodeAddress context, XdmAxis axis);
}
public sealed record NodeMetadata(
    NodeId Id, NodeId? Parent, string LocalName,
    string NamespaceUri, string Prefix,
    long Order, FragmentPointer Location);
```

The adapter must return Bosak's actual `XdmSequence` from `Children`, `Attributes` and `Axis`. Lazy `StringValue` may aggregate descendant text. Typed values, `IsNilled`, schema annotations, base/document URIs, and namespace nodes require explicit conformance tests. Keep page cache, decoded-fragment cache, and node metadata cache bounded and snapshot-aware.

## 8. Indexing and query planning

Start with node-directory, QName, canonical path, typed-value, and document URI/business-key indexes. Index keys must encode expanded QNames, atomic types, collations and snapshot visibility. Hits are candidates until the planner can prove exact semantics or apply residual predicates.

```csharp
// Illustrative internal capability API; refine strong typing later.
public sealed record XdmQueryPattern(
    string CanonicalPath, XdmAxis Axis,
    string? ExpandedName, XdmPredicate? Predicate,
    bool RequiresDocumentOrder);
public sealed record XdmPredicate(
    string Operator, string AtomicType, object Constant);
public sealed record AccessPathEstimate(
    double Rows, double Cost, bool PreservesOrder,
    bool SnapshotConsistent);
public sealed record AccessPathCandidate(
    string IndexName, AccessPathEstimate Estimate,
    string OpaquePlanToken);
public interface IIndexedXdmSource
{
    IReadOnlyList<AccessPathCandidate> FindAccessPaths(
        XdmQueryPattern pattern, IXmlReadSnapshot snapshot);
}
```

```mermaid
flowchart TD
 A[Parsed AST] --> B[Existing XPathOptimizer]
 B --> C[Pattern extraction]
 C --> D{Safe index candidate?}
 D -- No --> E[Existing IrLowerer / axis traversal]
 D -- Yes --> F[Cost and order assessment]
 F -- Reject --> E
 F -- Accept --> G[Index cursor]
 G --> H[Residual XDM predicates]
 H --> I[Ordering / deduplication]
 E --> I
```

`IrLowerer.LowerStep` uses `PathStepMap` for per-context predicates. Never replace `/SalesOrderLine[1]` with a global first index hit. Reverse-axis order, context position/size, namespace tests and duplicate elimination must remain correct. Introduce planner support only after provider-only navigation and explicit indexed-query benchmarks. Avoid embedding snapshot-bound index handles into reusable compiled queries.

## 9. Transaction boundaries and APIs

A transaction atomically changes the logical state of its owned partition (documents, fragments, indexes, directory and outbox). **The authoritative commit point differs by deployment mode:** embedded commits are anchored in the local WAL; the distributed log-first proposal anchors commits in a durable partition-log record, then applies that record locally. JetStream publish acknowledgement is part of the distributed commit path, but it does not provide arbitrary database isolation, fencing, or multi-message atomicity. Cross-service ACID remains out of scope.

```csharp
public sealed record OutboxMessage(
    Guid EventId, string Subject, ReadOnlyMemory<byte> Payload,
    string SchemaVersion, string EntityKey);
public interface IXmlWriteTransaction : IAsyncDisposable
{
    CommitSequence ReadVersion { get; }
    ValueTask ReplaceNodeValueAsync(DocumentId document, NodeId node,
        string value, CancellationToken ct = default);
    ValueTask InsertDocumentAsync(DocumentId document, Stream xml,
        CancellationToken ct = default);
    ValueTask DeleteDocumentAsync(DocumentId document,
        CancellationToken ct = default);
    ValueTask AddOutboxMessageAsync(OutboxMessage message,
        CancellationToken ct = default);
    ValueTask<CommitSequence> CommitAsync(CancellationToken ct = default);
    ValueTask RollbackAsync(CancellationToken ct = default);
}
```

**Isolation:** start with snapshot isolation and optimistic write-write conflict checks. Serializable business invariants require extra predicate/range validation or aggregate-level locking to prevent write skew. XQuery Update Facility support is a later design layer.

**Embedded commit sequence:** stage immutable fragments and index deltas; validate conflicts; append checksummed WAL including outbox; durably flush WAL; atomically publish new manifest/root and commit sequence; acknowledge; reclaim old generations after snapshots close. Crash recovery replays only committed records and discards incomplete generations. Validate fsync/root-swap behavior on target filesystems. **Distributed commit sequence:** see §14; do not acknowledge a log-first transaction solely on a local WAL flush.

**The following sequence applies to embedded/local-first event publication, not to log-first distributed commits.**

```mermaid
sequenceDiagram
 participant C as Entity command
 participant T as Local transaction
 participant W as WAL / manifest
 participant O as Outbox publisher
 participant J as JetStream
 C->>T: Begin snapshot S
 T->>W: Stage fragments, indexes, outbox
 T->>W: Durable commit S+1
 W-->>C: Commit acknowledged
 O->>W: Read committed outbox
 O->>J: Publish stable EventId
 J-->>O: Ack
 O->>W: Mark delivered
```

**Failure handling:** crash before commit -> no visible changes; after commit before publish -> retry; lost publish acknowledgment -> possible duplicate; consumers deduplicate by EventId and make handlers idempotent. NATS request/reply suits low-latency queries; JetStream suits durable business events and replay. Neither supplies distributed ACID by itself.

## 10. Entity service contract

```csharp
public sealed record BodEnvelope(
    string Verb, string Noun, string SchemaVersion,
    string CorrelationId, ReadOnlyMemory<byte> Xml);
public sealed record BodResponse(
    bool Accepted, ReadOnlyMemory<byte> Xml, string? ErrorCode);
public interface IEntityBodHandler
{
    string Noun { get; }
    ValueTask<BodResponse> HandleAsync(
        BodEnvelope request, CancellationToken ct);
}
```

This is a transport wrapper, **not** a complete OAGIS BOD definition. Each service is authoritative for its own entity instances; partition by tenant/company and entity key, with one logical writer per instance. Read-only projections in other services are eventually consistent. Inventory reservation must use authoritative Inventory operations, not stale projections.

## 11. Validation and implementation plan

| Milestone | Deliverable | Exit criterion |
|---|---|---|
| M0 | Build Bosak, baseline tests, instrument VM | Reproducible baseline |
| M1 | Immutable fragments + persistent XDM | Differential XPath tests pass; header query skips line fragments |
| M2 | MVCC, WAL, copy-on-write commits | Crash-injection recovery and consistent snapshots |
| M3 | Name/path/value indexes | Correct candidate filtering and measured benefit |
| M4 | Optional storage-aware planner | Correct fallback, ordering, positional predicates |
| M5 | OAGIS SalesOrder service + outbox | Idempotent end-to-end BOD processing |
| M6 | Item/Inventory distributed prototype | Defined consistency and throughput measurements |

**Correctness tests:** compare Bosak in-memory and persistent providers for axes, namespaces, positional predicates, typed values, serialization, identity, error codes and ordering; randomize fragmentation boundaries. Inject crashes before/after every durability step. Test snapshot disposal and concurrent writers.

**Performance tests:** 1M Items and variable-length SalesOrders; header-only XPath, line lookup, full reconstruction, indexed predicates, FLWOR, partial updates, cold/warm caches and concurrency. Compare equivalent workloads and indexes against BaseX and PostgreSQL/JSONB. Record p50/p95/p99, throughput, allocations, CPU, disk space, write amplification and recovery time. No performance advantage is assumed until benchmarked.

## 12. Open design decisions

1. Exact semantics of `IsSameNode` across read snapshots and document rewrites.
2. Efficient document-order representation for insertions and cross-document queries.
3. Lifetime of `XdmSequence` enumerators and ownership of read snapshots.
4. Whether the planner attaches to compilation, binding, or runtime execution (likely a two-stage plan).
5. How schema annotations, extensions, mixed content, whitespace and lexical XML fidelity are preserved.
6. Whether transactions initially span one document or multiple documents within one service.
7. Which indexes are mandatory versus schema/profile configured.
8. Whether fragment compression helps or hurts latency on real workloads.
9. How OAGIS schema/profile migrations and rolling service upgrades interact with stored data.
10. Partition reassignment, replication, and recovery policies for independent entity services (expanded in §14).

## 13. Recommended next engineering task

Implement an **immutable SalesOrder fragment provider** with a snapshot-scoped `IXdmNode` adapter, no indexes or writes. Instrument fragment reads. Demonstrate that `/SalesOrder/SalesOrderHeader/DocumentID` loads no line fragments, while `count(/SalesOrder/SalesOrderLine)` and ancestor/position queries remain correct. Only then proceed to transactional persistence and index-aware compilation.


## 14. Deployment modes and resilience architecture (v0.3)

**Decision ADR-003:** A single Bosak native XML storage engine and XDM provider shall run in both **embedded** and **distributed** modes. Physical fragment encoding, node identities, indexing, MVCC snapshot semantics and XPath/XQuery results remain mode-independent. Commit coordination, durability source, replication and operational services are replaceable infrastructure. This decision supersedes any earlier implication that every commit must be local-first.

| Concern | Embedded mode | Distributed log-first mode (proposed) |
|---|---|---|
| Authoritative durability | Local checksummed WAL + fsync | Partition-ordered, quorum-accepted transaction log (candidate: JetStream R3) |
| Query execution | Local Bosak XDM/indexes | Local Bosak XDM/indexes on primary or replica |
| Writes | One process/transaction coordinator | Exactly one fenced leader per partition |
| Replication | Optional external backup | Log replay to local materialized replicas |
| Availability | Host/storage dependent | Requires quorum, leader election, fencing and catch-up |
| Recovery | WAL + local snapshot | Verified snapshot + contiguous log replay |
| Operational dependency | None on NATS | NATS/JetStream + coordinator + storage |

```mermaid
flowchart TB
  A[XPath / XQuery / XSLT + OAGIS BOD] --> E[Bosak XDM and query runtime]
  E --> F[Fragment store / indexes / MVCC]
  F --> C{Deployment adapter}
  C -->|Embedded| W[Local WAL + fsync]
  C -->|Distributed| L[Partition log / JetStream]
  L --> R1[Replica A: fragment materialization]
  L --> R2[Replica B: fragment materialization]
  L --> BK[Log archive + snapshot coordination]
  F --> S[Consistent local snapshots]
  S --> BK
```

**Separation of concerns:** NATS is the low-latency request/reply and discovery transport. JetStream may durably distribute ordered partition commits and business events. It is **not** the physical XML fragment store, not a transaction-isolation engine, and not a substitute for independent backup.

### 14.1 Partition ownership, routing and failover

Partition each entity service by a stable key, such as `(tenant, entity-type, entity-id)` mapped through a versioned partition function. Each partition has one authoritative writer, zero or more replicas, and one ordered commit sequence. A service instance may own multiple partitions. Cross-partition operations use workflows/sagas or explicit higher-level coordination, not implicit distributed ACID.

**Leader fencing is mandatory.** Queue groups and subject subscriptions are not a leader-election protocol. A coordinator must allocate a monotonic **leadership epoch**, and every accepted transaction must be checked against the current epoch and expected sequence by an authority that cannot be bypassed by a stale writer. A token embedded only in the payload is insufficient: JetStream does not inherently reject obsolete application epochs. A separate linearizable coordinator, or a rigorously validated conditional-append design, is required before claiming safe automatic failover.

```mermaid
sequenceDiagram
    participant Client
    participant Router as NATS router
    participant Coord as Fencing authority
    participant P as Partition leader
    participant Log as JetStream partition log
    participant R as Standby
    Client->>Router: ProcessSalesOrder (idempotency key)
    Router->>P: Route to current leader
    P->>Coord: Verify epoch and ownership
    Coord-->>P: Valid epoch E
    P->>Log: Append one transaction record (E, seq, hash)
    Log-->>P: Durable publish acknowledgment
    P->>P: Apply record; publish MVCC root
    P-->>Client: Commit position (partition, sequence)
    Log-->>R: Replay committed record
    R->>R: Idempotent apply + checkpoint
```

**Failover sequence:** stop or fence old writer; establish new epoch; choose a candidate that can access the authoritative log; replay through the latest durable commit; atomically activate new leadership; resume writes. During uncertain ownership or quorum loss, reject authoritative writes rather than accept split-brain commits. Read replicas may remain available with clearly labeled staleness.

### 14.2 Commit records, atomicity and recovery invariants

A logical transaction should be represented as **one indivisible log record** whenever size limits permit. If a transaction exceeds transport limits, use a staged-blob-plus-commit-marker protocol with verified immutable content hashes and no visibility until the marker is durable; never treat several unrelated JetStream messages as one atomic transaction.

```csharp
// Proposed contracts; illustrative, not compiled against Bosak.
public readonly record struct PartitionId(string Value);
public readonly record struct CommitPosition(PartitionId Partition, ulong Sequence);
public readonly record struct LeadershipEpoch(ulong Value);

public sealed record FragmentMutation(
    string DocumentId, string FragmentId, string Operation,
    ReadOnlyMemory<byte> EncodedDelta, string ContentSha256);

public sealed record TransactionRecord(
    Guid TransactionId, PartitionId Partition, LeadershipEpoch Epoch,
    ulong ExpectedPreviousSequence, string SchemaVersion,
    IReadOnlyList<FragmentMutation> Mutations,
    IReadOnlyList<OutboxMessage> Events);

public interface IPartitionCommitLog
{
    ValueTask<CommitPosition> AppendCommittedAsync(
        TransactionRecord transaction, CancellationToken ct = default);
    IAsyncEnumerable<(CommitPosition Position, TransactionRecord Record)> ReplayAsync(
        CommitPosition after, CancellationToken ct = default);
}

public interface IPartitionLeadership
{
    ValueTask<LeadershipLease> AcquireAsync(PartitionId partition, CancellationToken ct = default);
    ValueTask AssertCanCommitAsync(LeadershipLease lease, ulong expectedSequence,
        CancellationToken ct = default);
}

public sealed record LeadershipLease(PartitionId Partition, LeadershipEpoch Epoch,
    string OwnerId, DateTimeOffset ExpiresAt);
```

**Contract requirements beyond the signatures:** `AppendCommittedAsync` must be fenced and conditionally ordered, deduplicate stable transaction IDs, define durable-ack semantics, and reject stale epochs and sequence gaps. Merely calling `AssertCanCommitAsync` before an ordinary publish leaves a time-of-check/time-of-use race. The append protocol must close that race, or the design must adopt another consensus-backed commit mechanism. Local materialization must be deterministic and idempotent. Persist the last applied `(partition, sequence, transaction ID)` with the MVCC root.

**Crash matrix:** (a) crash before log acceptance: no committed transaction; client may retry using idempotency key; (b) log accepted, primary crashes before apply: new leader replays and applies; (c) primary applies, response lost: retry resolves original transaction ID and returns its commit position; (d) replica receives duplicate: ignore if already applied; (e) log retention removes unapplied records: replica requires verified snapshot and contiguous archive, never silently skips a gap.

### 14.3 Snapshots, backup, archive and point-in-time recovery

Backup is independent of replication. A backup set includes immutable fragment files, document manifests, schema/profile versions, node-directory metadata, index definitions, checksums, encryption/key references and the **exact committed sequence S** at which the snapshot is consistent. Index contents may be backed up or rebuilt, but the choice affects RTO.

```mermaid
flowchart LR
  A[Pin MVCC snapshot at S] --> B[Copy immutable fragments + manifest]
  B --> C[Verify checksums / upload object store]
  D[Archive contiguous commit log after S] --> E[Backup catalog: snapshot S + log ranges]
  C --> E
  E --> F[Restore snapshot]
  F --> G[Replay verified records to target commit]
  G --> H[Rebuild/verify indexes and expose reads]
```

**PITR:** restore the latest snapshot before the target commit position, replay a gap-free archive to the selected commit, validate fragment/root hashes, and open the database only after consistency checks. Wall-clock timestamps alone are not reliable commit boundaries; store both timestamps and authoritative positions. Keep archived logs until every dependent snapshot is retired. Schedule periodic restore drills. A JetStream stream backup is not a transactionally consistent backup of Bosak's separate fragment store by itself.

**Illustrative goals, not guaranteed SLAs:** RPO = 0 for acknowledged commits under the specified surviving-quorum and archival assumptions; RTO of minutes for a small partition with a recent snapshot. Test complete-site loss separately: R3 within one site does not imply cross-site disaster recovery.

### 14.4 Read consistency and replication

| Read class | Execution | Guarantee |
|---|---|---|
| `ReadLocal` | Any healthy replica | Potentially stale; snapshot-consistent locally |
| `ReadAtLeast(position)` | Replica with applied sequence >= requested position | Read-your-writes/monotonicity for that partition |
| `ReadLatest` | Fenced authoritative leader or barrier-verified replica | Includes all acknowledged commits before the read barrier |
| Analytical snapshot | Dedicated read replica | Stable local snapshot; possibly behind primary |

```csharp
public enum ReadConsistency { Local, AtLeastPosition, Latest }
public sealed record ReadRequest(ReadConsistency Consistency, CommitPosition? MinimumPosition);
public interface IReplicaProgress
{
    CommitPosition LastApplied(PartitionId partition);
    ValueTask WaitUntilAppliedAsync(CommitPosition position, CancellationToken ct = default);
}
```

Do not issue network requests per XPath node or fragment. Route the whole query to a node holding a local fragment store and indexes. Cross-partition queries require an explicit coordinator and documented consistency semantics.

### 14.5 Performance strategy and benchmark matrix

Performance priorities: local XDM navigation; index-aware query planning; bounded commit batching; per-partition ordered logs; asynchronous replica materialization; backpressure; cache-aware fragment layout; snapshot/checkpoint frequency tuned to replay cost. Commit batching must not blur individual transaction visibility or acknowledgments. JetStream is off the normal local read path.

| Benchmark | Embedded | Distributed log-first | Failure injection |
|---|---|---|---|
| Header-only XPath | p50/p95/p99, allocations, fragment reads | Primary vs replica, cache hot/cold | Replica lag |
| Indexed Item lookup | Index seeks and throughput | Routing overhead, read scaling | Primary unavailable |
| Single-fragment update | WAL/fsync latency | Log ack + apply latency | Crash before/after ack |
| Concurrent SalesOrder commits | Conflicts, write amplification | Commits/sec per partition | Duplicate/reordered delivery |
| 1M-Item ingest | CPU, disk, indexes | Partition distribution, backpressure | JetStream quorum loss |
| Backup and PITR | Snapshot/restore time | Snapshot + archive replay | Missing/corrupt log segment |
| Failover | N/A | Time to new fenced leader | Network partition, stale writer |

Track `commit_ack_latency`, `last_committed_sequence`, `last_applied_sequence`, `replication_lag`, `fencing_rejections`, `snapshot_age`, `archive_gap_count`, `recovery_duration`, `fragment_cache_hit_rate`, and `query_p99`. Establish performance targets only after a baseline is measured against embedded Bosak, BaseX server-side execution, and PostgreSQL/JSONB with comparable indexes.

### 14.6 Proposed project structure and incremental implementation

```text
Bosak.XmlDb.Core                 // XDM identities, snapshots, shared contracts
Bosak.XmlDb.Storage              // Fragment encoding, manifests, indexes, local WAL
Bosak.XmlDb.Query                // Optional index-aware physical planning
Bosak.XmlDb.Resolution           // Native doc()/collection() URI adapters
Bosak.XmlDb.Embedded             // Local WAL commit adapter, no NATS dependency
Bosak.XmlDb.Replication          // Partition commit/replay, replica checkpoints
Bosak.XmlDb.Replication.JetStream // JetStream log transport implementation
Bosak.XmlDb.Coordination         // Leader lease, epochs, fencing integration
Bosak.XmlDb.Backup               // Snapshot catalog, archive, restore/PITR
Bosak.Oagis.EntityRuntime        // Independent noun service, BOD semantics
```

**Milestones:** M1 immutable persistent provider; M2 embedded WAL + MVCC writes and recovery; M3 consistent snapshots and restore drills; M4 JetStream log prototype with deterministic replay; M5 safe leadership fencing and automatic failover (block production HA claims until verified); M6 replicas and read-consistency routing; M7 backup archive/PITR and cross-site recovery tests; M8 OAGIS module integration and comparative benchmarks.

### 14.7 Alternatives and unresolved decisions

1. **Local-first + outbox:** lowest write-path network overhead; accepts a nonzero loss window if primary storage is lost before replication. Retain as a benchmark and deployment option, not equivalent to log-first durability.
2. **Hybrid local WAL + replicated commit:** may improve latency/recovery, but requires precise two-log reconciliation rules; defer until measurements justify it.
3. **JetStream log-first:** attractive for reuse and replay, but conditional append, ordering, leadership fencing, retention, and quorum behavior must be demonstrated in a prototype. If not achievable safely, use a dedicated consensus-backed log and retain JetStream for BOD events.
4. **Backup format:** decide whether to store physical fragments for fast restore, logical XML for portability, or both.
5. **Partition rebalancing:** define ownership transfer, snapshot handoff, and index warming without concurrent writers.
6. **Cross-region recovery:** define desired RPO/RTO and whether asynchronous mirroring is acceptable.

## Appendix C. Revision history v0.3

- **v0.3 (2026-10-26):** Explicit embedded/distributed single-engine decision; deployment-specific durability models; JetStream log-first proposal; fencing/conditional-append caveats; transaction-record interfaces; replica consistency, backup/PITR, recovery, failure testing and milestones.

## Appendix A. Implementation work items introduced in v0.2

| Work item | Code surface | Acceptance criterion |
|---|---|---|
| DBP-01 Preserve remote adapters | `Bosak.XPath.Providers.Database` and tests | Existing document and collection loader tests remain green |
| DBP-02 Scoped native document resolver | Evaluation context adapter + `Bosak.XmlDb.Resolution` | `doc(bosak:...)` navigates persisted fragments with one live snapshot |
| DBP-03 Native collection resolver | Collection adapter + catalog | `collection(bosak:...)` yields stable document identities at the same snapshot |
| DBP-04 URI and error contract | Resolver registry | No scheme collisions; missing/invalid URI behavior tested |
| DBP-05 Query pushdown capability | `Bosak.XmlDb.Query` and compiler integration | Indexed predicate gives identical semantics to fallback traversal |
| DBP-06 Comparative benchmark | Benchmarks + remote connector | Distinguishes client-side BaseX fetch from server-side BaseX query |

## Appendix B. Revision history

- **v0.1 (2026-10-26):** Native XML engine proposal, fragment layout, MVCC and transaction design.
- **v0.2 (2026-10-26):** Added verified remote database-provider analysis, native/remote package boundaries, document and collection resolution contracts, snapshot lifetime rules, compatibility plan, and benchmark methodology. Existing sections are retained.
