# ADR-036: Stopped Handoff Preparation and Lifetime

**Status:** Accepted design; SR3 runtime implementation and SR4 writer remain pending  
**Date:** 2026-10-30  
**Deciders:** Bosak.XmlDb internal embedded pilot engineering

## Context

ER-004 and [ADR-034](ADR-034-stopped-enrollment-restart-and-owner-handoff.md) separate
stopped observation, handoff preparation and conditional owner publication. The
[SR1/SR2 review](implementation/M2_STOPPED_RESTART_READINESS_REVIEW.md) identifies three
integration gaps: no private successful-proof slot, immediate observation-resource drain,
and no live successor-session binding. Current observation results deliberately grant no
capability. This decision resolves RR-002/003/004 at the design level only.

## Decision

We will prepare handoff only from an actual paired observation's privately retained,
successful exact-Enroll proof, with fresh complete read-only validation. No public descriptor,
ObservationId, attempted flag, supplied GUID or reconstructed receipt can create that proof.
The successor will be the actual paired parent Context.SessionId: nonempty, distinct from
the recorded owner, with checked previous generation + 1. Exactly one legacy Enroll is the
initial supported history. All required host reconciliation facts must be Confirmed, but
remain host assumptions rather than independently established global facts.

We will extend the actual observation resource owner with explicit preparation/plan/executor
children over its existing single paired operation and actual source child. Closing stops new
admission immediately; it does not drain resources under active validation or an already
claimed executor. Closing before claim invalidates the plan. Claim wins only through brief
compatible lifetime gates after complete unlocked revalidation, with no I/O or callbacks in
the atomic transition. A claimed executor owns the real child until completion or explicit
before-output abandonment. A copied stream reference or separate pin is insufficient.

SR3 is a no-output protocol. It adds neither an append call nor a writer reservation file.
SR4 needs a separate reviewed implementation and qualification before a TransferOwner append.
The [contract](implementation/M2_STOPPED_HANDOFF_PREPARATION_CONTRACT.md) defines states,
close ordering, evidence and acceptance gates. Existing frozen formats remain unchanged.

## Consequences

### Positive

- Actual owner/session identity and successful verification have one private origin.
- Closing and claim have explicit outcomes without losing original usable handles.
- Existing single-read parent accounting and permanent source stop remain intact.

### Negative / Accepted Costs

- Observation lifetime code needs real child accounting and dedicated concurrency tests.
- Preparation repeats expensive full verification and refuses busy or stale state.
- A closed wrapper can have pending resource release; completion must expose actual drain
  separately from Dispose returning. Unknown close outcomes cannot be retried or hidden.
- This design grants no durable source fence, routing, work admission or release approval.

## Alternatives Considered

| Option | Why Rejected |
|---|---|
| Use returned description or attempted flag | Neither establishes successful private proof or ownership |
| Borrow observation or pin another handle | Caller disposal still drains the real paired operation/original writer |
| Reacquire source retention after closing | Violates the permanent stopped-source admission contract |
| Caller-selected successor GUID | Does not bind the successor to actual paired ownership |
| Append as part of preparation | Conflates no-output lifetime qualification with SR4 persistence uncertainty |

## References

- [ER-004 registry](FEATURE_REQUESTS.md)
- [ADR-035](ADR-035-owned-stopped-restart-observation.md)
- [SR3-A contract](implementation/M2_STOPPED_HANDOFF_PREPARATION_CONTRACT.md)
- [Design review](implementation/M2_STOPPED_HANDOFF_PREPARATION_REVIEW.md)
