# ADR-010: Mandatory Epoch Format and Admission Primitives

**Status:** Implemented internal primitives; data integration and migration pending  
**Date:** 2026-10-27  
**Deciders:** Bosak.XmlDb implementation within authorized M2 work

## Context

[REQ-006](FEATURE_REQUESTS.md), [ADR-008](ADR-008-reader-compatibility-backup-and-retirement.md)
and the implemented full-history backup slice require a mandatory old-reader boundary
before new-root migration. Optional format-1 markers cannot fence old binaries. Admission
must remain held by independently owned readers after their creating owner closes.

## Decision

Introduce internal EpochCodec and EpochAdmission primitives with isolated metadata-only
roots. FORMAT has magic BXDB and mandatory envelope major 2, minor 0. Its immutable body
binds random StoreId/EpochId, nonzero document identity, exact required reader/writer
contracts 2, reserved full-history recovery contract 1 and required admission bit 0.
Unknown versions, flags, requirements or bits fail closed. EPOCH (BXEP 1.0) and the stable
.epoch/admission.lease (BXEA 1.0) bind the same identity and full FORMAT digest.

Only internal CreateFixtureRoot publishes these three files into a new absent root.
It stages complete flushed metadata, then renames with requested directory barriers.
It never adopts, edits, renames or removes an existing format-1 root. Failures leave
unpublished private .xmldb-epoch-* staging or a complete unacknowledged final fixture.
No migration or new-format XML materializations are created.

Acquire validates all identities, opens the existing lease inode without creation,
and validates its bound bytes through the held handle. Shared handles use FileShare.Read;
exclusive maintenance handles use FileShare.None. Acquisition fails immediately on a
conflict, rather than waiting under an unrelated coordinator gate. Lease identities are
never unlinked/replaced/recreated. Disposal and process exit release ownership.

ForkShared creates a separate shared OS handle while its parent is live. A child survives
parent disposal. A disposed parent cannot fork and an exclusive token cannot spawn
shared readers. These are admission tokens only: actual new-format snapshots,
transactions, backups and coordinator lock-order integration remain future work.

Preserve the pre-epoch format-1 Storage/Core binaries as small immutable managed fixtures
with SHA-256 provenance. A subprocess loads them in a separate AssemblyLoadContext and
exercises raw/default/durability/recovery Open overloads against major-2 roots. Current
public format-1 entry points are checked too. Both must reject before adoption writes.
The captured baseline is the post-backup implementation from this checkout, not an
archived pre-lease or released binary. Those unavailable historical binaries remain an
open compatibility gate. Never rebuild the fixture from current source during tests.

## Consequences

### Positive

- A verifiable mandatory boundary cannot be ignored as an optional sidecar marker.
- Lease lifecycle and cross-process conflict/exit semantics can be proved before data migration.
- No public API or format-1 byte contract changes; all source history stays retained.

### Negative / Accepted Costs

- New-format roots contain metadata only; all existing public data APIs still reject them.
- C1-C3 are partially evidenced, not complete migration/admission support for real data.
- Copying a directory does not transfer admission ownership; a future epoch restore must
  choose fresh identity. Cooperative processes and unchanged root paths are required.
- No reclamation, WAL truncation, physical power-loss or real ENOSPC certification is added.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Optional epoch marker in format 1 | Old readers can ignore it |
| Modify generic BinaryEnvelope to accept every major | Would widen legacy readers and weaken the boundary |
| Reuse one parent handle for all children | Parent disposal would release another reader's protection |
| Block for exclusive admission while holding coordinator selection | Introduces a lock-order deadlock risk |
| Claim complete compatibility using a rebuilt current reader | Does not demonstrate behavior of frozen old bytes |
| Introduce data migration in the same slice | Requires snapshot/transaction integration and identity/value parity first |

## References

- [Epoch format](implementation/M2_EPOCH_FORMAT_V2.md)
- [Validation and limits](implementation/M2_EPOCH_VALIDATION.md)
- [Compatibility protocol](implementation/M2_COMPATIBILITY_BACKUP_RETIREMENT.md)

*Last updated: 2026-10-27*

Implementation update (2026-10-27): [ADR-011](ADR-011-admission-owned-read-only-epoch-snapshots.md)
now adds actual read-only sequence-zero data/snapshot admission with a separate public
entry point. Transaction/coordinator/backup and full-history migration remain pending.
The mandatory metadata bytes and frozen reader fixtures from this ADR are unchanged.
