# ADR-025: Owned Conditional Host Journal Append

**Status:** Accepted internal ProcessCrash implementation; production orchestration/release remain open
**Date:** 2026-10-28
**Deciders:** Authorized continuation after committing/pushing EP2/EP3

## Context

[ADR-023](ADR-023-bounded-embedded-host-journal-contract.md) defines journal bytes and uncertain
commit rules. [ADR-024](ADR-024-explicit-no-overwrite-host-provisioning.md) qualifies creation
and uninterrupted ownership handoff. EP4 must append actual frames under that lifetime while
preserving unknown outcomes, exact revisions and the separation from database publication.

## Decision

Serialize append and reconciliation reads within one retained host lifetime. Require explicit
bound fresh reconciliation evidence plus administrative admission before enabling append. A
reopened empty root cannot regain a live initializer's first-write eligibility. Healthy bytes,
a read position or an advisory writer-status value never enable append automatically.

Use exact journal ID/sequence/digest/byte-length expected positions. A stale position yields a
conflict without output. Require new snapshots to bind the current live owner session and
configured scope, validate paths and complete semantic extension with the existing codec, and
recheck actual metadata/history/EOF before write entry. Preserve frozen metadata/store formats.

A successful append writes exactly one frame, requests Flush(true), compares actual frame bytes
and validates complete history before returning a separate host append acknowledgment. This is
not a database publication receipt, execution permit, route decision or physical-loss promise.
Revalidate the whole bounded history in this prototype; no append-throughput claim is made.

After write entry, any write/flush/readback/checkpoint/return-path uncertainty irreversibly faults
the lifetime's append session and closes admissions. Reconciliation reads may inspect retained
bytes while ownership remains held, but never clear the fault, adopt a prefix or manufacture an
acknowledgment. Closing/disposal retains ownership through actual operation drain. A new owner
starts stopped and needs fresh reconciliation; old plans are never reconstructed or replayed.

The [append validation](implementation/M2_EMBEDDED_HOST_APPEND_VALIDATION.md) records exact-head
races, actual file/flush faults, process kills and test-only composition with planned publication.
EP5's production host orchestration, HA2 routing/work and stronger durability remain open.

## Consequences

### Positive

- Actual file append has explicit expected-state and acknowledged/unknown boundaries.
- Retained ownership covers write, flush, readback and acknowledgment, including shutdown races.
- Corrupt/partial data stops further mutation rather than triggering repair or replay.

### Negative / Accepted Costs

- Complete history is reread/revalidated several times per append; bounds do not imply performance suitability.
- Unknown outcomes require stopped reconciliation and a new owner, not session rearming.
- Local checks/leases do not prove authentication, anti-rollback or exclusion of arbitrary writers.
- Actual executor dispatch remains outside the backend and requires EP5 enforcement.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Enable from a healthy or empty reopened journal | Cannot establish original initialization/dispatch outcome |
| Return an acknowledged append after a failed flush | Falsifies the actual call's outcome |
| Retry automatically or reset a faulted session | Could overwrite uncertainty or drive duplicate work |
| Reclaim/truncate an invalid tail | Discards retained authority/evidence without a qualified repair protocol |
| Treat stored authorization as executable authority | Owner-bound plans are process-local and require separate live dispatch control |

## References

- [Host ledger contract](implementation/M2_HOST_ATTEMPT_LEDGER_CONTRACT.md)
- [Journal contract](implementation/M2_EMBEDDED_HOST_JOURNAL_CONTRACT.md)
- [Append validation](implementation/M2_EMBEDDED_HOST_APPEND_VALIDATION.md)
- [REQ-006/007](FEATURE_REQUESTS.md)
