# ADR-026: Live Plan-Bound Embedded Orchestration

**Status:** Accepted internal synchronous pilot; stopped restart/retry and application integration remain open
**Date:** 2026-10-28
**Deciders:** Authorized EP5 continuation after owned append qualification

## Context

[ADR-020](ADR-020-planned-administrative-attempt-correlation.md) defines process-local executable
plans distinct from persisted descriptors. [ADR-025](ADR-025-owned-conditional-host-journal-append.md)
provides actual acknowledged/uncertain host writes, but test branches alone do not enforce the
link between saved intent, authorization and a live executor. REQ-006/007 need that internal
boundary without enabling public mutable access or routing.

## Decision

Create tickets only by preparing a real plan through the orchestrator's own administration
instance. Bind tickets to an unexposed per-orchestrator reference token, actual plan, current
host owner session, business request ID and immutable descriptor. Tickets are sealed/private-
constructor objects, not serialized records. There is no descriptor-to-ticket/plan recreation API.

Record intent once, then atomically claim the recorded ticket for one execution. Verify the
exact latest stored snapshot, require an actually acknowledged authorization save and recheck it
before executor admission. Reserve one executor for the whole workflow across orchestrator
instances sharing the same host lifetime. Journal writes to that active attempt require its
opaque registration; unrelated attempt records may still be saved. No executor or route callback
runs under the append or lifetime lock.

The actual library invocation is separately admitted after authorization and stays registered
through completion. Shutdown before that admission prevents invocation. Once admitted, shutdown
retains ownership until execution/diagnostics finish; it may prevent a later receipt save, which
must preserve the actual returned pipeline receipt separately. Never replay the pipeline to
repair a host acknowledgment.

Return separate pipeline receipt, acknowledged host authorization/receipt save and original
errors. A library exception may leave publication and no receipt; save uncertainty best-effort
without masking the original error. Post-claim failures stop this orchestrator for reconciliation,
consume its ticket and close admissions. Read-only inspection requires exact persisted descriptor
binding and separate fresh supplied current-owner exclusion facts (without requiring the
publication outcome to be resolved first); it never rearms a ticket or resumes
writers. Lower-level direct callers remain outside this controlled pilot API boundary.

[Validation](implementation/M2_EMBEDDED_HOST_ORCHESTRATION_VALIDATION.md) records actual journal,
publication, concurrency, shutdown and process-restart gaps. Stopped persisted reconciliation/
fresh-attempt retry is next; public/application route/work, global fencing and release remain open.

## Consequences

### Positive

- Executable authority cannot be reconstructed from a healthy journal or matching descriptor.
- Single-use tickets and a host-wide reservation bound actual pilot executor admission.
- Pipeline and host persistence acknowledgments/errors remain independently reviewable.

### Negative / Accepted Costs

- Conservative uncertainty or conflicting use can stop the whole pilot and require reconciliation.
- Shutdown after publication may retain a real receipt only in memory if host saving is blocked.
- No direct-library/hostile-process fence or production router is introduced.
- Restarts lose every executable ticket and require new controlled decisions, not replay.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Accept arbitrary saved descriptors as execution handles | Recreates lost authority and risks duplicate publication |
| Dispatch from an observed authorization frame | Does not establish live owner, original plan or acknowledged save |
| Use one local boolean per orchestrator only | Another instance could reserve a concurrent executor on the same host |
| Permit low-level mutation of an active attempt | Could supersede its authorization between validation and invocation |
| Retry pipeline after receipt-save error | Can duplicate publication and falsifies single-use semantics |

## References

- [Attempt contract](implementation/M2_ADMINISTRATIVE_ATTEMPT_CONTRACT.md)
- [Owned append](implementation/M2_EMBEDDED_HOST_APPEND_VALIDATION.md)
- [Orchestration validation](implementation/M2_EMBEDDED_HOST_ORCHESTRATION_VALIDATION.md)
- [REQ-006/007](FEATURE_REQUESTS.md)
