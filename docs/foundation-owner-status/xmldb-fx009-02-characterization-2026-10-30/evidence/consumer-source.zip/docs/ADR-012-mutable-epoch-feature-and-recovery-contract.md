# ADR-012: Mutable Epoch Feature and Recovery Contract

**Status:** Accepted behavior design; ET1-ET3 codecs/proof implemented per ADR-013; mutable runtime pending  
**Date:** 2026-10-27  
**Deciders:** Bosak.XmlDb implementation within authorized M2 design work

## Context

[REQ-003](FEATURE_REQUESTS.md) implements format-1 scalar transactions.
[REQ-006](FEATURE_REQUESTS.md) and [ADR-011](ADR-011-admission-owned-read-only-epoch-snapshots.md)
now implement admission-owned immutable epoch snapshots. A mutable epoch must not be
mistaken for that sequence-zero layout, replay another epoch's records or release a
reader's admission when its coordinator closes. Recovery authority and lock ordering
must be specified before adding writes or history migration.

## Decision

Define a separate proposed mutable profile: BXDB 2.1, required reader/writer contract 3,
recovery contract 2, required feature bits 3 (admission plus scalar WAL). Keep immutable
BXDB 2.0/contracts 2/recovery 1/features 1 and its SNAPSHOT unchanged. Do not widen the
read-only decoder into an implicit mutable reader. The current read-only profile must
reject the mutable profile before lease/runtime-state creation, and still rejects any
transaction marker in a purported immutable root. Conversion uses a new root/fresh epoch,
never an in-place FORMAT rewrite. This is a design profile, not shipped bytes or a release.

Every proposed mutable authority record binds StoreId, EpochId, DocumentId, complete
FORMAT digest and base-manifest digest. Give control, WAL, current, generation and reader
identity distinct epoch-specific magics rather than reusing legacy BXWL/BXHD records.
Complete, contiguous, semantically valid retained WAL determines the committed head;
CURRENT must agree with a prefix and cannot select a stale base. A published generation
is a witness against discarding its required WAL, not an alternative commit source.
Retain base, full WAL, all generations and stable identities. No checkpoint optimization
or truncation is included in the initial mutable profile.

Preserve the existing one-document/one-scalar replacement semantics and optimistic stale
conflicts. Reconstruct missing generation materializations only from verified redo;
reject present corrupt materializations. Require exact resulting manifest hashes and
stable IDs/topology/order. A complete WAL can commit without a successful response.
Capture I/O/persistence failure faults the coordinator; reopen before retry decisions.

Acquire epoch admission before writer ownership, coordinator selection and generation
leases. Sessions, snapshots and transactions own distinct handles; child protection
outlives coordinator disposal. Maintenance is a separate session, taking exclusive epoch
admission only after all cooperative owners/readers have closed. Never wait for admission
while holding a coordinator gate, and never replace a stable lease inode.

The [mutable epoch contract](implementation/M2_MUTABLE_EPOCH_CONTRACT.md) specifies
semantic record fields, publication/recovery rules and acceptance gates. Exact record
encodings remain pending independent codecs/fixtures. No runtime behavior, public API,
existing versioned bytes, source history or proprietary license changes in this step.

## Consequences

### Positive

- Immutable readers cannot silently serve a mutable root's original base.
- Cross-epoch replay, stale CURRENT and missing required history have explicit failure rules.
- Snapshot admission and generation protection have a consistent acquisition order.
- New-format recovery can be proved while all independent history remains retained.

### Negative / Accepted Costs

- Full-prefix validation and complete generations retain current storage/write amplification.
- Mutable codecs, reader compatibility proof, coordinator, backup and migration are still unimplemented.
- The current frozen format-1 fixture is insufficient to prove old read-only epoch behavior;
  freeze today's read-only binary before widening any parser in the next implementation.
- Process/file-directory policies remain experimental, without physical durability certification.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Keep the immutable required-feature tuple for a mutable root | Older sequence-zero readers could miss future state |
| Reuse legacy WAL bytes unchanged | They carry no epoch/profile identity |
| Use CURRENT as the sole commit source | Publication can lag a committed WAL or contain a stale prefix |
| Discard a partial last WAL despite its published generation | Could silently roll back a previously published commit |
| Take admission only when the coordinator opens | A lazy snapshot can outlive that coordinator |
| Add migration or deletion with initial epoch writes | Removes the independent recovery oracle before the new chain is proved |

## References

- [Semantic contract and gates](implementation/M2_MUTABLE_EPOCH_CONTRACT.md)
- [Immutable epoch format](implementation/M2_EPOCH_FORMAT_V2.md)
- [Read-only snapshot contract](implementation/M2_READONLY_EPOCH_SNAPSHOT.md)
- [Legacy transaction format](implementation/M2_TRANSACTION_FORMAT_V1.md)

*Last updated: 2026-10-27*

Implementation update: [ADR-013](ADR-013-epoch-profile-and-authority-codecs.md) implements
ET1-ET3 internal profile/authority codecs and frozen-reader proof. Exact wire fields are
now fixed in its byte contract; this ADR's coordinator/commit/recovery behavior is still
unimplemented. No public mutable access is granted by successful parsing.
