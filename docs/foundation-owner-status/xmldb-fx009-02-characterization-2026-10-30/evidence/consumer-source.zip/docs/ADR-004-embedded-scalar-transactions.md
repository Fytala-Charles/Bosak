# ADR-004: Embedded Single-Document Scalar Transactions

- Date: 2026-10-26
- Status: Accepted for the first M2 implementation slice
- Request: REQ-003

## Context

M1 has immutable snapshot-bound XDM navigation, explicit bounded format 1.0, lazy
payloads and reproducible tests. Its remaining limits are explicit: eager ingestion,
thread-confined snapshots, snapshot-local wrappers, no catalog or durable update path.
The next gate is replacement of one scalar followed by commit/reopen and process
termination at every publication step. This does not complete all of M2.

## Decision

Use one exclusive coordinator per store (OS-backed FileShare.None writer lease).
Each transaction captures one document generation and may replace one text node or
ordinary attribute value. Reject element/document/namespace nodes, XML namespace
attributes, invalid XML characters and oversized values. Disposing without commit
rolls back. Commit from a stale document generation raises a conflict.

Keep stable DocumentId/NodeId and existing immutable preorder. No structural insertion
or deletion is supported, so document order does not change. Future structural writes
must separate stable IDs from mutable order before implementation. Existing snapshots
retain their old generation even after later commits/coordinator disposal. Generations
are retained; no garbage collection/checkpoint truncation is introduced in this slice.

Preserve all M1 file bytes/layouts. Add a versioned transaction sidecar under
.transactions with control identity, writer lease, bounded checksummed WAL records,
immutable full generation directories and an atomically replaced CURRENT pointer.
The base M1 store is sequence zero. Readers use EmbeddedXmlDatabase.BeginRead after
recovery; direct ImmutableXmlSnapshot.Open rejects a transactional root to prevent
silently reading the old base. Original already-open M1 snapshots stay valid.

A commit stages and flushes a complete generation, writes and flushes one logical
redo WAL record, renames the staged generation, flushes a temporary root pointer,
atomically replaces CURRENT, then returns its commit sequence. WAL is authoritative;
CURRENT is a publication/checkpoint hint. Records bind old/new manifest hashes,
sequence, transaction identity and the exact scalar replacement. A valid complete
record is replayable; an interrupted unacknowledged append may recover old or new.
After any persistence exception, fault the coordinator and require reopen/recovery.

Recovery validates the base and contiguous WAL chain. A final incomplete WAL record
may be discarded only when CURRENT does not reference it and no later record exists.
Complete checksum errors, missing committed records, identity/hash mismatches and
invalid generations fail closed. Replay reconstructs missing generations deterministically
and publishes the last committed root. Repeated recovery is idempotent.

## Consequences

Full generations copy unaffected files for a small, reviewable first implementation;
this deliberately favors correctness over write amplification. Reads still load only
needed payloads. The WAL, retained generations and source must stay together; no
independent backup/restore guarantee or log truncation is provided.

File Flush(true) and same-volume rename are used. OS process-kill tests establish
process-crash behavior on the tested platform, not power-loss durability. Directory
fsync, storage-controller behavior, disk-full matrices, production filesystem contracts,
insertion/deletion, multi-node/multi-document transactions, reclamation and performance
remain later M2 work. No upstream Bosak changes or server/replication work is authorized.

## Alternatives Considered

- Overwrite M1 files: rejected because lazy readers would observe changing bytes.
- Renumber/reimport XML: rejected because it would destroy stable node identity.
- Publish root before WAL: rejected because committed visibility would precede replay data.
- Shared fragment generations: deferred until correct reference retention is established.


Empty ordinary-attribute values are supported. Empty text replacement is rejected
because it requires structural removal rather than a scalar-only change.

*Last updated: 2026-10-26*
