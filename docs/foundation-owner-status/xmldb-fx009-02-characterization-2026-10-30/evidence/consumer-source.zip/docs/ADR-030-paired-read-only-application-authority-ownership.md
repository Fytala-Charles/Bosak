# ADR-030: Paired Read-Only Application-Authority Ownership

**Status:** Accepted internal existing-root/lifetime prototype; Windows full and Linux x64/overlayfs focused qualification complete; provisioning pending
**Date:** 2026-10-29
**Deciders:** Authorized continuation of the internal embedded pilot

## Context

[REQ-007](FEATURE_REQUESTS.md#req-007-mutable-epoch-authority-and-recovery),
[ADR-028](ADR-028-embedded-pilot-selection-and-work-authority.md) and
[ADR-029](ADR-029-separate-application-authority-journal-v1.md) require actual ownership
before consuming application-authority bytes. The pure codec grants no capability. The
existing administrative registry has no mutually exclusive application child lifetime;
its path checks reject reparse paths but do not enforce single-link authority files.

## Decision

Add one opaque owner-bound application inspection registration under EmbeddedHostLifetime.
Acquire it only with closed admissions, no active operations/executor/stopped session,
fresh exact host position and supplied controlled-writer/publisher/queue evidence. Validate
the retained administrative history before leaving the acquisition boundary. While registered,
block ordinary administrative operations/reconciliation reads/append/enablement/dispatch,
admission reopening, stopped sessions and another application registration. No mode enables work.

Open only the configured existing separate authority root, with exactly authority.lock,
authority.meta and authority.log. Bind expected configuration to the actual parent journal,
deployment and scope. Hold the real parent registration before authority-file ownership and
retain all authority role handles; close them before releasing that registration. Never create,
repair, flush, truncate, replace or delete any authority/admin/data file in this slice.

Require regular single-link authority roles and stable handle/path identities. Use Windows
file IDs/link counts and Linux statx device/inode/link data; no weak fallback. Restrict this
prototype to 64-bit Windows fixed NTFS and 64-bit Linux local ext-family/overlayfs/tmpfs,
with unsupported queries/filesystems rejected. The Linux implementation is not qualified by
Windows tests. Reject links, unknown roles, lexical/physical containment against the parent,
configured protected roots and retained administrative artifact/bundle roots. Bound inventories
and ancestor walks. These checks are cooperative namespace validation, not hostile rename or
global fencing proof; operator-controlled exclusion remains required.

Opening and repeat inspection validate exact metadata and complete bounded history. Repeat
inspection also requires the original log bytes/digest/length and role identities unchanged.
A changed/invalid owned observation faults this child permanently; it cannot be rearmed.
Empty reopened history remains stopped without initializer eligibility. Decoded records remain
observations, never acknowledged receipts or dispatch/write permission.

Parent shutdown blocks new inspections and retains its lease while the child is alive. Child
shutdown blocks new reads, lets actual registered reads finish, then closes authority log/meta/
owner handles before releasing the parent registration. Cancellation/timeout does not complete
work. Failed release faults completion and must not silently unlock the parent as confirmed.
No callbacks execute under parent lifetime/journal locks or the authority read serializer.

## Consequences

### Positive

- Read-only authority acquisition participates in real parent exclusion and actual operation drain.
- Single-link/identity validation catches copied hard-link roles and changed path bindings.
- Provisioning/append can later build on an explicit qualified ownership boundary.

### Negative / Accepted Costs

- Several host admission paths need consistent new-mode guards and regression coverage.
- Native identity support and bounded physical ancestry checks narrow supported platforms.
- Controlled namespaces and supplied operational facts remain assumptions; no anti-rollback or
  actual accepted-work authority is inferred from a readable history.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Reuse EP6 stopped registration | It authorizes restricted administrative append and has different lifetime/exclusion semantics |
| Hold a generic administrative token | Does not exclude competing admission or reserve the application mode |
| Accept path strings/reparse checks as complete identity proof | Does not detect regular-file hard links or physical ancestor aliases |
| Dispose parent ownership before child reads finish | Permits a successor to race still-live role handles |
| Provision missing roles during Open | Could initialize/repair unknown prior authority and reset work |

## References

- [Authority format](implementation/M2_APPLICATION_AUTHORITY_FORMAT_V1.md)
- [Codec evidence](implementation/M2_APPLICATION_AUTHORITY_CODEC_VALIDATION.md)
- [Windows handle information](https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-getfileinformationbyhandleex)
- [Windows file identity](https://learn.microsoft.com/en-us/windows/win32/api/winbase/ns-winbase-file_id_info)
- [Linux statx ABI](https://raw.githubusercontent.com/torvalds/linux/v6.6/include/uapi/linux/stat.h)
- [Linux statx semantics](https://man7.org/linux/man-pages/man2/statx.2.html)
- [Linux filesystem type query](https://man7.org/linux/man-pages/man2/statfs.2.html)

[Implementation validation](implementation/M2_APPLICATION_AUTHORITY_LIFETIME_VALIDATION.md) records
actual stopped ownership/drain and native Windows evidence. No provisioning/append is enabled.
