# Bosak M1 — Immutable Persistent Fragment Provider

**Implementation specification v0.2 · 2026-10-26**  
**Status:** Implementation-ready design, **not compiled or executed**.  
**Source baseline:** user-provided `Bosak-main.zip`, archive commit `927d7a458dd90a8b506840c045808f4f27e3c8d1` (from ZIP metadata).  
**Parent design:** `Bosak_Native_XML_Storage_Engine_Technical_Design_v0.3.md`.

## 1. Goal and scope

Implement an immutable, persistent XML document whose physical bytes are split into independently loadable fragments, and expose it through the existing `Bosak.XPath.Core.Xdm.IXdmNode` interface. **No compiler/VM changes in M1.** No WAL, transactions, NATS, indexes, or distributed operation. This is a correctness and lazy-I/O experiment, not a complete database.

### Acceptance criteria

1. A SalesOrder XML document is ingested and written as one header fragment, groups of line fragments, and a document manifest.
2. The manifest and node directory can be reopened in a new process without parsing the source XML.
3. `/SalesOrder/SalesOrderHeader/DocumentID` reads zero line payload fragments (instrumented assertion).
4. `count(/SalesOrder/SalesOrderLine)` returns the correct count; it may use the directory, without loading line payloads.
5. `/SalesOrder/SalesOrderLine[10]/Item/ItemID`, ancestor/parent/sibling/attribute axes, node identity, document order, and serialization agree with Bosak's in-memory provider.
6. Enumerating a lazy result after its snapshot has been disposed fails deterministically, rather than reading freed resources.
7. Randomly varying fragment boundaries does not change XPath results.

## 2. Repository integration map

| Existing source | M1 integration | Change |
|---|---|---|
| `src/Bosak.XPath.Core/Xdm/IXdmNode.cs` | Implement all required members and appropriate optional XDM semantics | **Do not edit** |
| `src/Bosak.XPath.Compiler/Ir/IrLowerer.cs` | Existing path/axis IR | **Do not edit** |
| `src/Bosak.XPath.Runtime/Vm/VmEngine.cs` | Existing VM axis navigation | **Do not edit** |
| `src/Bosak.XPath.Api/XPath31Expression.cs` | Existing XPath compilation/evaluation | **Do not edit** |
| `src/Bosak.XPath.Providers.Database/DatabaseDocumentLoader.cs` | Existing remote database connector | **Do not edit** |
| New `src/Bosak.XmlDb.Storage/` | Manifest, fragment reader/writer, directory, metrics | Add |
| New `src/Bosak.XmlDb.Xdm/` | Persistent `IXdmNode` adapter and snapshot | Add |
| New `tests/Bosak.XmlDb.Tests/` | Differential and lazy-load tests | Add |

**Implementation note:** Source-specific `XdmSequence` construction, `XdmValue` construction, namespace-node behavior and `XPath31Expression` invocation must be copied from existing provider/test patterns, not guessed from this document. The exact C# below is a design contract, not guaranteed drop-in code.

## 3. Physical model

```mermaid
flowchart TD
  M[Document manifest: document ID, root ID, format version] --> D[Node directory: ID, parent, order, fragment, offset]
  M --> H[Header fragment: document + SalesOrderHeader]
  M --> L1[Line fragment group 1]
  M --> L2[Line fragment group 2]
  M --> X[Cold fragment: attachments/extensions]
  D --> H
  D --> L1
  D --> L2
  D --> X
  Q[Persistent IXdmNode] --> D
  Q --> C[Bounded decoded-fragment cache]
  C --> H
  C --> L1
  C --> L2
```

**M1 simplification:** All structural metadata (node kind, expanded name, parent, ordered child IDs, attribute IDs, fragment pointer) is in a separately persisted node directory. Node text/value bytes reside in fragments. A header-only path therefore consults the directory and header fragment but not line payloads. The directory may be memory-mapped or loaded into memory in M1; quantify its size. A later milestone can page the directory.

### File layout

```text
<database-root>/
  FORMAT                    # version and compatibility marker
  documents/<document-id>/manifest.bin
  documents/<document-id>/directory.bin
  fragments/<fragment-id>.bin
```

Do not use a C# `struct` memory dump as the on-disk format. All files require explicit little-endian encoding, length limits and CRC/checksum. IDs are 64-bit unsigned; document identity and node identity are distinct. Node IDs never depend on fragment location. Format-version fields are mandatory even in M1.

### Proposed binary headers

| File | Field sequence | Notes |
|---|---|---|
| `manifest.bin` | magic `BXMF`, major/minor, DocumentId, RootNodeId, directory checksum, fragment count, fragment IDs/checksums | Immutable M1 |
| `directory.bin` | magic `BXND`, version, record count, records, checksum | Sorted by NodeId; child order stored explicitly |
| `fragment.bin` | magic `BXFG`, version, FragmentId, DocumentId, codec, uncompressed length, payload length, payload checksum, payload | M1 codec=none |

All variable lengths must be checked against configured maxima before allocation. Validate file references against the database root; reject path traversal and truncated files. The checksum algorithm and byte-level serialization fixtures must be fixed before implementation and tested across processes.

## 4. Proposed interfaces

```csharp
namespace Bosak.XmlDb.Storage;

public readonly record struct DocumentId(ulong Value);
public readonly record struct NodeId(ulong Value);
public readonly record struct FragmentId(ulong Value);

public readonly record struct FragmentPointer(
    FragmentId Fragment, ulong Offset, uint Length);

public readonly record struct NodeRecord(
    NodeId Id,
    NodeId? Parent,
    int DocumentOrder,
    byte Kind,
    uint ExpandedNameId,
    FragmentPointer? Value,
    IReadOnlyList<NodeId> Children,
    IReadOnlyList<NodeId> Attributes);

public interface IImmutableFragmentStore : IAsyncDisposable
{
    ValueTask<ReadOnlyMemory<byte>> ReadAsync(
        FragmentPointer pointer, CancellationToken cancellationToken = default);
    FragmentReadMetrics GetMetrics();
}

public readonly record struct FragmentReadMetrics(
    long PhysicalFragmentReads,
    long BytesRead,
    long CacheHits,
    long HeaderFragmentReads,
    long LineFragmentReads);

public interface INodeDirectory
{
    NodeRecord Get(NodeId id);
    bool TryGet(NodeId id, out NodeRecord record);
    NodeId Root { get; }
}

public interface IImmutableXmlSnapshot : IDisposable
{
    DocumentId DocumentId { get; }
    INodeDirectory Directory { get; }
    IImmutableFragmentStore Fragments { get; }
    void ThrowIfDisposed();
}
```

For M1, the storage API can be synchronous at the `IXdmNode` boundary: Bosak's `IXdmNode.Children()` and `Axis()` return `XdmSequence`, not `Task<XdmSequence>`. Do not block on arbitrary remote I/O in the node adapter. All fragments are local; use a bounded cache and synchronous file reads behind the adapter, or prefetch at a higher boundary. The async `ReadAsync` above is an optional ingestion/bulk API; **define a synchronous `Read` path for the adapter** before coding. Avoid `GetAwaiter().GetResult()` inside XPath evaluation.

```csharp
namespace Bosak.XmlDb.Xdm;

using Bosak.XPath.Core.Xdm;
using Bosak.XmlDb.Storage;

public interface IPersistentNodeFactory
{
    IXdmNode OpenDocument(IImmutableXmlSnapshot snapshot);
    IXdmNode OpenNode(IImmutableXmlSnapshot snapshot, NodeId id);
}

// Implement IXdmNode exactly as defined in Bosak.XPath.Core.
// The factory may cache wrappers within one snapshot, but correctness
// must rely on DocumentId + NodeId rather than CLR reference equality.
```

### Node semantics that cannot be deferred

- `IsSameNode`: compare logical `(DocumentId, NodeId)` **within one immutable snapshot**; cross-snapshot semantics must be documented before MVCC.
- `DocumentOrder`: consistent with XDM including document, element, namespace/attribute and child ordering. The existing interface uses `long` and accepts zero for unknown; M1 should supply nonzero order for normal nodes.
- `Parent`, `Document`, `Children`, `Attributes`, `Axis`: lazy enumerators must call `ThrowIfDisposed()` at enumeration time and on each fetch.
- `StringValue`: for elements, concatenate descendant text in document order; do not assume the element has one scalar payload.
- `TypedValue`, `SchemaTypeAnnotation`, `IsId`, `IsIdref`, `IsNilled`: preserve appropriate untyped semantics in M1; do not fabricate schema annotations.
- Namespace nodes, inherited namespaces, base URI, document URI, mixed content, whitespace, comments and processing instructions need differential fixtures.
- `ToXmlString()` must produce logically equivalent XML, not necessarily byte-identical source text; define lexical fidelity separately.

## 5. Import and read flows

```mermaid
sequenceDiagram
  participant I as Importer
  participant X as XML reader
  participant W as Fragment writer
  participant D as Node directory writer
  participant M as Manifest writer
  I->>X: Parse SalesOrder once
  X->>W: Write header and line groups
  X->>D: Assign stable NodeIds + order
  W-->>I: Fragment IDs + checksums
  D-->>I: Directory checksum
  I->>M: Write immutable manifest last
  Note over I,M: No mutation or crash recovery guarantee in M1
```

```mermaid
sequenceDiagram
  participant Q as Bosak XPath VM
  participant N as Persistent IXdmNode
  participant D as Node directory
  participant C as Fragment cache
  Q->>N: /SalesOrder/SalesOrderHeader/DocumentID
  N->>D: Resolve child IDs and names
  N->>C: Read header value payload
  C-->>N: Value bytes
  N-->>Q: XDM node/value
  Note over C: Line fragment read count = 0
```

**Important:** Publishing the manifest last does not by itself guarantee crash-safe import. In M1 use a temporary staging directory and explicit final rename only as a convenience. Crash-safe atomic publication, directory fsync and WAL belong to M2.

## 6. Tests and fixtures

Create SalesOrders with 0, 1, 10, 500 and 10,000 lines; include namespaces, nested elements, attributes, mixed content, comments, whitespace, and optional extensions. Generate random fragment grouping (1, 16, 128 lines/group). Compare the same XPath expression evaluated by Bosak's existing in-memory provider and by the persistent provider.

| Test | Required assertion |
|---|---|
| Header-only | Correct ID; `LineFragmentReads == 0` |
| Line selection | Correct 10th line; only needed group loaded (allow metadata reads) |
| Count | Correct number; no forced full payload load if directory has counts |
| Ancestor/parent | Same node identity and order as in-memory |
| Positional/reverse axes | Identical results for `[1]`, `[last()]`, preceding-sibling, ancestor |
| Attributes/namespaces | Same namespace and attribute semantics |
| Serialization | Equivalent XML infoset |
| Snapshot disposal | Predictable exception on late enumeration |
| Corruption | Reject bad magic, lengths, checksums and truncated data |
| Reopen | Identical results after closing and reopening store |

Example queries:

```xpath
/SalesOrder/SalesOrderHeader/DocumentID
count(/SalesOrder/SalesOrderLine)
/SalesOrder/SalesOrderLine[10]/Item/ItemID
/SalesOrder/SalesOrderLine[last()]/ancestor::SalesOrder
/SalesOrder/SalesOrderLine[1]/following-sibling::SalesOrderLine[1]
```

For namespaced OAGIS XML, use declared namespace prefixes in the actual XPath tests; the unprefixed expressions above assume a deliberately unnamespaced minimal fixture.

## 7. Benchmark gate

Run the same expressions against in-memory and persistent providers. Record warm/cold p50/p95/p99, allocations, fragment reads, bytes read, cache hits, and total directory memory. M1 success means correctness and demonstrable avoidance of unrelated fragment payload I/O, **not necessarily faster latency than in-memory XML**.

## 8. Ordered implementation tasks

1. Add `Bosak.XmlDb.Storage` and `Bosak.XmlDb.Xdm` projects targeting `net10.0`; reference existing Bosak Core only from Xdm.
2. Write fixed binary format fixtures and codec tests (including corrupt input).
3. Build importer and persisted directory/manifest reader.
4. Implement immutable snapshot and bounded fragment cache with metrics.
5. Implement `PersistentXdmNode` using actual `XdmSequence` patterns from existing providers.
6. Integrate a snapshot-scoped `fn:doc()` loader through the existing evaluation context, without modifying the remote Database provider.
7. Add differential tests and verify lazy I/O.
8. Run benchmarks and record findings before proceeding to M2.

## 9. Exit review / go-no-go

Proceed to M2 (MVCC + WAL) only if (a) the differential suite passes, (b) header-only queries demonstrably avoid line payload I/O, (c) snapshot disposal is safe, (d) file corruption is detected, and (e) the persisted format is explicitly versioned. If the existing `IXdmNode` sequence API causes unacceptable synchronous I/O or allocation overhead, profile and document the evidence before proposing compiler/VM changes.

## 10. Environment note

The source ZIP was inspected, but this environment does **not** have the `dotnet` CLI installed. Therefore no .NET compilation, test run or performance result is claimed. This document is an implementation specification, not a completed M1 prototype.


---

## 11. Project boundary and repository decision (approved for setup)

**Decision:** Create a separate repository named `Bosak.XmlDb`. Keep the existing [Bosak](https://github.com/Fytala-Charles/Bosak) repository independent and unchanged for M1. Bosak.XmlDb depends on version-pinned Bosak packages or source references; Bosak must not depend on Bosak.XmlDb. A local source-reference development workflow is acceptable, but document how it is switched to pinned NuGet releases. Never silently track the moving `main` branch.

**Product model:** one native fragment/XDM engine, two hosting modes: (1) embedded library, initially implemented in M1; (2) server/container and later distributed deployment. The *same persistent format and query semantics* must be used in both modes. Embedded mode must not require NATS, JetStream, Docker or Kubernetes.

### Proposed repository skeleton

```text
Bosak.XmlDb/
  README.md
  LICENSE                         # choose explicitly; do not assume Bosak license
  Directory.Build.props
  Directory.Packages.props         # if central package management is adopted
  global.json                      # pin tested .NET 10 SDK, roll-forward policy
  Bosak.XmlDb.slnx
  .editorconfig
  .gitignore
  .github/workflows/ci.yml
  src/
    Bosak.XmlDb.Core/
    Bosak.XmlDb.Storage/
    Bosak.XmlDb.Xdm/
    Bosak.XmlDb.Server/            # M4 placeholder only, no production API in M1
    Bosak.XmlDb.Nats/              # future, do not scaffold runtime dependency
    Bosak.XmlDb.Resilience/        # future, do not scaffold runtime dependency
  tests/
    Bosak.XmlDb.Storage.Tests/
    Bosak.XmlDb.Xdm.Tests/
    Bosak.XmlDb.IntegrationTests/
    Bosak.XmlDb.Benchmarks/        # may be deferred until M1 query path exists
  samples/
    EmbeddedQuickstart/           # add once public API is usable
  deploy/
    docker/
    compose/
    helm/                          # documentation placeholder, not production chart
    kubernetes/                    # documentation placeholder
  docs/
    architecture/
    implementation/
    operations/
```

The initial solution should include **Core, Storage, Xdm, Storage.Tests, Xdm.Tests**. Add an integration test project once the Bosak evaluator is wired. Empty future-project directories are optional; avoid generating code that cannot be exercised.

### Dependency boundaries

```mermaid
flowchart TD
  A["Bosak XPath/XQuery packages"] --> X["Bosak.XmlDb.Xdm"]
  C["Bosak.XmlDb.Core"] --> S["Bosak.XmlDb.Storage"]
  C --> X
  S --> X
  X --> E["Embedded consumer"]
  X --> V["Future XmlDb.Server"]
  V --> N["Future NATS/JetStream adapter"]
  V --> K["Future Kubernetes deployment"]
```

*Diagram shows conceptual usage, not literal project references.* The concrete project reference direction must be acyclic: `Core` has no Bosak dependency; `Storage` references `Core`; `Xdm` references `Core`, `Storage`, and the minimal necessary Bosak packages; consumers reference `Xdm`. The diagram's arrows from `Core` to other packages denote foundation-to-consumer relationships.

### SDK and reproducible builds

- Target `net10.0`; pin a **verified installed** .NET 10 SDK in `global.json` instead of inventing a patch version.
- Enable nullable reference types, implicit usings, analyzers, deterministic CI builds, and warnings-as-errors where practical.
- Pin package versions and source commit; record Bosak source baseline `927d7a458dd90a8b506840c045808f4f27e3c8d1` from the supplied archive metadata, but confirm against Git before treating it as a verified Git commit.
- Define stable public API namespace policy (`Bosak.XmlDb.*`), binary format versioning, and a migration policy before distributing persisted files.
- Run `dotnet restore`, `dotnet build -c Release`, and `dotnet test -c Release` in CI on Linux and Windows (macOS optional). A CI run must not claim success until the agent has actually executed it.

## 12. Docker and Kubernetes strategy

**M1:** library-only deliverable; no container required for production use. Docker may be used as a **build/test environment** when the local machine lacks .NET 10. Do not imply that a working database-server image exists.

**M4:** add a thin ASP.NET Core `Bosak.XmlDb.Server` host, with `/health/live`, `/health/ready`, and later a versioned query/document API. Mount persistent data at `/data`; run as non-root; do not put database files in the ephemeral container layer. Do not expose unauthenticated query/update endpoints publicly.

**M5:** introduce a separately packaged NATS/JetStream adapter and durable replication tests in Docker Compose. A Compose setup is a development and failure-test harness, not proof of production HA.

**M6:** use Kubernetes StatefulSets with PVCs and stable identities for database instances. Define resource requests/limits, startup/readiness/liveness probes, anti-affinity/topology spread, storage class requirements, PodDisruptionBudgets and restore procedures. Kubernetes pod restart is **not** database failover; leader fencing, replay, quorum, and recovery are engine responsibilities.

**M7 (optional):** a Kubernetes operator and `BosakXmlDatabase` CRD only after the server, replication, and operational contracts stabilize.

```mermaid
flowchart LR
  B["Bosak library"] --> E["XmlDb embedded engine: M1-M3"]
  E --> S["XmlDb.Server: M4"]
  S --> D["Docker image + Compose"]
  D --> R["JetStream replication: M5"]
  R --> K["Kubernetes StatefulSets: M6"]
  K --> O["Optional operator: M7"]
```

### Illustrative future container contract (NOT an M1 deliverable)

```yaml
services:
  xmldb:
    image: ghcr.io/OWNER/bosak-xmldb:VERSION # placeholder; image not published
    ports: ["127.0.0.1:8080:8080"]
    volumes: ["xmldb-data:/data"]
    environment:
      BOSAK_XMLDB_DATA_PATH: /data # proposed name; not yet implemented
volumes:
  xmldb-data: {}
```

The server must document shutdown behavior, disk permissions, backup/restore compatibility, and configuration validation before a deployment artifact is considered supported.

## 13. Expanded milestone plan and acceptance gates

| Stage | Scope | Gate |
|---|---|---|
| M0 — repository bootstrap | Separate repo, solution, dependencies, CI, ADRs, test fixtures | Clean restore/build/test on pinned SDK; no circular dependencies |
| M1 — immutable fragments | Import, manifest/directory, lazy persistent XDM, snapshot lifecycle | All criteria in §1 and §6 pass; no line payload I/O on header query |
| M2 — transactions | Local WAL, MVCC, crash recovery, atomic fragment commit | Fault-injection recovery and snapshot isolation tests |
| M3 — query acceleration | Structural/value indexes, index-aware physical plans | Correctness parity and repeatable measured wins |
| M4 — server | Authenticated API, Docker image, health and metrics | Persistence across restart, documented resource limits |
| M5 — replication | JetStream log prototype, replay, leadership/fencing | No split-brain writes in tested partitions; recovery tests |
| M6 — Kubernetes | StatefulSet, PVC, backups, runbooks | Restore drills, failover and SLO measurements |
| M7 — operator | Declarative lifecycle management | Upgrade/rollback and reconciliation tests |

**Important:** M1 is immutable; the write and HA design is a future direction, not an M1 requirement. Log-first JetStream remains a **candidate architecture**, not a proven commit protocol. A publish acknowledgment alone does not provide transactional fencing or snapshot isolation.

## 14. Agent execution instructions and deliverables

A coding agent should read the companion `Bosak_XmlDb_Agent_Handover_v0.1.md` **first**, then this plan and Technical Design v0.3. Execute M0 before M1. Make small commits, provide actual build/test logs, and report deviations rather than silently modifying Bosak core interfaces or implementing distributed infrastructure early.

The agent should deliver: repository tree; dependency pinning; build/test commands and outputs; source files; fixture-generation code; a README quickstart; design decision records; and a short `M0_STATUS.md` with completed, blocked and deferred work. Do not publish packages/images or create remote repositories without authorization and credentials.
