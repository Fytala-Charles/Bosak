# ADR-017: Epoch-Bound Full-History Backup and Independent Restore

**Status:** Accepted design; ET9-A/B/C/D internal metadata/capture/restore and observed fault qualification implemented  
**Date:** 2026-10-27  
**Deciders:** Bosak.XmlDb implementation within authorized M2 work

## Context

[REQ-006](FEATURE_REQUESTS.md) and [REQ-007](FEATURE_REQUESTS.md) require epoch backup
before full-history migration and retirement. ET1-ET8 now provide internal scalar epoch
ownership, deterministic recovery and bounded platform evidence. Format-1 backup binds
neither epoch identity nor the mutable profile and cannot be relabeled as an epoch backup.
Every scalar authority record binds FORMAT/base/epoch; changing only FORMAT during restore
would invalidate WAL, generation witnesses and readers. Copying source admission bytes
would not transfer OS ownership or provide an independent restored branch.

## Decision

Design a separate immutable artifact for exact ScalarWal 2.1 sources, captured at H under
an operation-owned shared admission child and the owning coordinator's writer/gate exclusion.
Seal the immutable base, complete retained WAL 1..H, complete generations, BASE/CONTROL,
FORMAT/EPOCH and exact CURRENT at H. Exclude runtime ownership and private temporaries by
schema. Refuse unknown dependencies and required corruption. Do not repair the source
inside capture or silently reduce H.

Use new epoch-specific inventory/completion roles rather than BXBI/BXBC. Verify copied
bytes and exact closure, then independently validate both complete materializations and
base-plus-full-WAL redo in private clones. A missing sealed generation fails before redo;
the redo oracle is additional verification, not permission to accept an incomplete artifact.

Restore preserves DocumentId, node IDs/order/URI/values, commit numbers, transaction IDs,
logical operations and every manifest/directory/fragment byte. Assign fresh StoreId and
EpochId for an independent branch. Re-encode FORMAT/EPOCH/BASE/CONTROL, each WAL binding and
predecessor-WAL digest, each generation FORMAT/witness, CURRENT and fresh reader/admission
identities. Recompute the WAL chain in order without changing its logical history.

Publish a new destination bundle containing store/ and origin.bin by one directory rename.
The returned StorePath explicitly identifies destination/store. The provenance sidecar
binds the source backup/inventory and both identities/initial heads; it is outside the
routable store and never recovery authority. This avoids adding an ignored mandatory
record to the existing ScalarWal profile. Close all private handles before rename; normal
Open reacquires handles and validates the published path. Never move/replace the original
source root or sealed backup. No public epoch backup/mutable API is enabled by this design.

The [semantic design](implementation/M2_EPOCH_BACKUP_DESIGN.md) fixes ownership, closure,
verification, transformation and failure behavior. The [candidate byte contract](implementation/M2_EPOCH_BACKUP_FORMAT_DESIGN.md)
reserved separate roles and bounds. ET9-A now freezes those metadata layouts with independent
fixtures in the versioned contract linked below. Callable capture/restore remains unimplemented.

## Consequences

### Positive

- A sealed artifact commits to one complete source epoch/history and a verified H.
- Independent restores cannot inherit source identity/ownership or alias live readers.
- Identity rebinding preserves all XML metadata and the complete logical transaction history.
- Atomic bundle publication binds initial provenance and the root without changing store profiles.
- Old public formats, existing backups, frozen readers and original roots remain untouched.

### Negative / Accepted Costs

- Capture blocks writes; full materializations and verification clones consume additional space/I/O.
- Fresh store/epoch identities change authority/WAL hashes; they are linked through origin metadata.
- Consumers must use the returned store/ path; a restore destination is a bundle, not the root.
- Provenance is an initial-restore audit claim, not authentication or a current-head selector.
- Runtime implementation, codec fixtures, faults/kills and migration/cutover proof remain pending.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Reuse format-1 inventory/completion | Cannot distinguish or bind epoch/profile/rebinding semantics |
| Copy FORMAT/admission and source-bound WAL as a restored live identity | Does not create an independent branch or transfer ownership |
| Retain source StoreId for independent restores | Fresh branch identity avoids treating a restore as source continuation; migration is a separate contract |
| Change FORMAT only | Every epoch-bound authority and WAL digest becomes inconsistent |
| Export only the selected snapshot or latest generation | Loses retained history and changes H/transaction provenance |
| Put mandatory provenance into unchanged mutable FORMAT | Existing entry points do not require that new dependency |
| Publish the store and provenance with separate renames | Can expose a routable root without completed provenance |
| Replace or route away from the original automatically | Violates old-reader lifetime, explicit routing and migration boundaries |

## References

- [ADR-008](ADR-008-reader-compatibility-backup-and-retirement.md)
- [ADR-009](ADR-009-verified-full-history-backup-and-restore.md)
- [ADR-016](ADR-016-internal-epoch-redo-and-publication-faults.md)
- [Compatibility/backup/retirement protocol](implementation/M2_COMPATIBILITY_BACKUP_RETIREMENT.md)
- [Mutable epoch contract](implementation/M2_MUTABLE_EPOCH_CONTRACT.md)
- [ET8 evidence](implementation/M2_EPOCH_NATIVE_DURABILITY_VALIDATION.md)

*Last updated: 2026-10-27*

Implementation update (2026-10-27): ET9-A implements pure bounded BXEI/BXEZ/BXEO metadata
codecs and header-context checks, frozen with independent fixtures in the
[versioned contract](implementation/M2_EPOCH_BACKUP_FORMAT_V1.md) and
[validation](implementation/M2_EPOCH_BACKUP_CODEC_VALIDATION.md). This is not artifact/data
verification or runtime capture/restore. Next: ET9-B fixed-H capture and both private oracles.

ET9-B implementation update (2026-10-27): [internal capture](implementation/M2_EPOCH_BACKUP_CAPTURE.md)
now pins H under admission/writer/gate ownership, validates exact closure and both private
oracles, then seals/publishes an artifact without source mutation. See
[validation](implementation/M2_EPOCH_BACKUP_CAPTURE_VALIDATION.md). No public API or restore
is enabled. Next ET9-C implements rebinding/restore; ET9-D exhaustive fault proof remains pending.

ET9-C implementation update (2026-10-27): [independent restore](implementation/M2_EPOCH_BACKUP_RESTORE.md)
now verifies/rebinds complete history with fresh identities and publishes an atomic store/origin
bundle. [Validation](implementation/M2_EPOCH_BACKUP_RESTORE_VALIDATION.md) proves per-sequence
parity, provenance, independent writes and selected process/failure windows. No public API,
migration or retirement is enabled. Next ET9-D provides exhaustive capture/restore fault proof.


ET9-D qualification update (2026-10-27): capture/restore persistence sweeps now enumerate
every observed before/after call and actual partial-write position on a one-commit history.
Process-crash and modeled strong ordering are separate from actual native Linux delegation.
Repeated process interruption covers private publication windows, published outcomes and
acknowledgment loss. Source/backup bytes, historical reads, provenance and released handles
are checked. See [fault qualification](implementation/M2_EPOCH_BACKUP_FAULT_VALIDATION.md).
Next: design full-history migration/cutover acceptance criteria under ADR-008 before runtime
implementation. Public mutable APIs, source replacement and history reclamation remain disabled.
