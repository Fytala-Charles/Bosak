<div align="center">
  <img src="../assets/logos/fytala-logo-color-dark.svg" width="100" alt="Fytala Bosak.XmlDb Architecture">
  <br><br>
  <h1>Bosak.XmlDb Architecture</h1>
  <p>Embedded native XML fragment storage and persistent XDM navigation.</p>
</div>

## SR3-A Stopped Handoff Preparation Design (2026-10-30)

[ADR-036](ADR-036-stopped-handoff-preparation-and-lifetime.md) and
[contract](implementation/M2_STOPPED_HANDOFF_PREPARATION_CONTRACT.md) define private success-only
proof, actual preparation/plan/executor child drain and the actual paired parent session as
successor. Closing before claim refuses; claim-before-close retains original usable handles
through completion. No runtime or format change. Readiness checkpoint `069332c` is committed
and pushed; this design is local/uncommitted. Next SR3-B1 implements private proof and child
lifetime before SR3-B2 preparation/claim, SR3-C qualification and the separate SR4 writer.
Prior Windows 2,752 and focused Linux 394 cases remain retained evidence, not fresh execution.
Host/public/archive/durable-fence and all retirement gates remain open; CanReclaim=false.

## SR1/SR2 Stopped Restart Readiness Review (2026-10-30)

[Review](implementation/M2_STOPPED_RESTART_READINESS_REVIEW.md) verifies 64 retained
artifacts, 15 historical source inputs and complete Windows test-ID growth from 2,529 to 2,752.
All 223 additions appear in the latest 394-case focused Linux catalog; platform bodies/guards
remain distinct. Initial restore timeouts stay separate from passing project rechecks.
No runtime changes or fresh execution. Next SR3-A defines success-only proof consumption,
actual plan-child drain and successor/session binding before preparation code. Existing
observation/descriptor success grants no handoff or write authority. Host/public/archive and
all retirement gates remain open. Checkpoint `7da1b17` is committed/pushed; this review is local.

## SR2-C Native, Process and Disposal Qualification (2026-10-30)

[Validation](implementation/M2_OWNED_RESTART_QUALIFICATION_VALIDATION.md) adds 38 cases
without product source changes. Eleven native roles/roots are replaced with identical bytes
at two boundaries: 22 actual Linux executions, separately recorded as 22 Windows guards.
Ordered and repeated concurrent disposal, 14 process kills and 14 fresh observations and independent
holders/races preserve bytes/inventory and keep every result stopped. Final focused runs pass
189 Windows and 394 Linux cases.
All 2,752 Windows cases pass across complete project runs. The initial restore timeouts are
retained and pass focused plus complete Integration rechecks. Next consolidate SR1/SR2
readiness before SR3 handoff preparation. Host/public/archive/retirement gates remain open.
Checkpoint `de5c9a4` is committed/pushed; SR2-C qualification is local/uncommitted.

## SR2-B Paired Stopped Restart Observation (2026-10-30)

[Implementation and validation](implementation/M2_OWNED_RESTART_OBSERVATION_VALIDATION.md)
bind actual parent/authority/source retention through read-only complete source/sealed-capture
proof and fresh exact journal/native identity checks. All results stay stopped and inert;
no capture association, receipt, initializer or handoff capability is recreated. Nonterminal
administrative history forces reconciliation despite caller assertions. All 58 new cases and
282 focused Windows cases pass; 356 focused Linux cases pass, including all 58 new bodies.
All 2,714 Windows cases pass across complete project runs. The initial restore timeout is
retained and passes focused plus complete Integration rechecks. Next SR2-C native/process/race
qualification; SR3/SR4 and host/public/archive/retirement gates remain open. Checkpoint `a31203b`
is committed/pushed; SR2-B is local/uncommitted. Public and frozen formats remain unchanged.

## SR2-A Actual Restart Source Retention (2026-10-30)

[Implementation and validation](implementation/M2_RESTART_SOURCE_RETENTION_VALIDATION.md)
add a separate restart-only actual source child, permanent stopped admission and original
usable writer retention through real drain. No old capture association or initializer is
recreated. Native source inspection runs outside its gate; close uncertainty never retries or
clears the stop. All 38 new cases and 152 focused Windows cases pass; 268 focused Linux cases
also pass, including all 38 new bodies. All 2,656 Windows cases pass across complete project runs. The initial restore timeout is
retained and passes focused plus complete Integration rechecks.
This source-only slice does not implement paired restart observation. Next SR2-B full actual
parent/authority/source-bound proof and freshness; SR2-C/SR3/SR4 and host/public/archive/retirement
gates remain open. Checkpoint `bc5e490` is committed/pushed; SR2-A is local/uncommitted.

## SR2 Actual Ownership Integration Design (2026-10-30)

[ADR-035](ADR-035-owned-stopped-restart-observation.md),
[design](implementation/M2_OWNED_RESTART_OBSERVATION_DESIGN.md) and
[review](implementation/M2_OWNED_RESTART_OBSERVATION_REVIEW.md) specify a separate
restart-only retained source child and paired stopped observation. Existing freeze/capture
association and initializer checks remain strict. Verification must not hide live recovery
writes or confuse the inventory commitment with the manifest hash. Design only; no runtime
change. Next SR2-A source lifetime primitive, then SR2-B/C observation and qualification;
SR3/SR4 and all host/public/archive/retirement gates remain open.
Checkpoint `b0c94bd` is committed/pushed. SR2 design is local/uncommitted; prior 2,618 Windows
passing cases across complete project runs and 451 focused Linux cases are retained evidence,
not new execution. All source/candidate/WAL histories remain retained, CanReclaim=false.

## SR1 Pure Stopped Enrollment Assessment (2026-10-30)

[Implementation and validation](implementation/M2_ENROLLMENT_RESTART_CLASSIFIER_VALIDATION.md)
add an internal pure classifier of supplied exact-head, source/capture and stopped-host facts.
Every result remains stopped and inert. Empty/unsupported/missing observations require
reconciliation; invalid history or contradictory facts refuse. No receipt, initializer, live
ownership, handoff plan or execution permission is recreated. All 89 new cases and 335 focused
Windows cases pass; 451 focused Linux cases also pass, including all 89 new bodies.
All 2,618 Windows cases pass across complete project runs. The initial restore timeout is
retained and passes focused plus complete Integration rechecks. Public/frozen formats and
actual source/authority lifetimes remain unchanged. Next SR2 actual owner-bound stopped
evidence; SR3/SR4 capability/output and host/public/archive/retirement gates remain open.
Checkpoint `100b39d` is committed/pushed; SR1 is local/uncommitted.

## ER-004 Stopped Restart and Owner Handoff Design (2026-10-30)

[ADR-034](ADR-034-stopped-enrollment-restart-and-owner-handoff.md) and the
[contract](implementation/M2_STOPPED_ENROLLMENT_RESTART_CONTRACT.md) define inert stopped
assessment, fresh actual ownership/exclusion and a separately gated future TransferOwner.
[Review](implementation/M2_STOPPED_ENROLLMENT_RESTART_REVIEW.md) records design checks;
no runtime, public API or frozen format changes. Valid Enroll bytes never recreate a receipt
or initializer. Empty/unsupported/uncertain restarts require reconciliation; corruption rejects
without repair. All histories remain retained. Next SR1 implements only the pure stopped
classifier; SR2-SR4 actual evidence, capability and output qualification remain unimplemented.
ER-003 checkpoint `edf0b72` is committed/pushed. Its 2,529 Windows passing cases across complete
project runs and 740 focused Linux cases remain prior execution evidence, with initial
Integration timeouts preserved separately. This design adds no runtime test cases.

## ER-003 Authority and Parent Release Qualification (2026-10-30)

[Contract](implementation/M2_ENROLLMENT_ROLE_RELEASE.md) and
[validation](implementation/M2_ENROLLMENT_ROLE_RELEASE_VALIDATION.md) add an actual-owner,
internal close seam and 42 direct role-close cases. Before/after/no-op errors suppress required
cleanup acknowledgment, preserve bytes and keep release uncertainty separate from physical
handle availability. All 2,529 Windows cases qualify across complete project runs and 740 broad
Linux cases pass, including all 42 new bodies per platform. Two initial restore timeouts are
retained and pass focused plus complete Integration rechecks. Production null/default close delegation and public/frozen contracts remain
unchanged. Next ER-004 defines stopped restart/enrollment reconciliation and owner handoff;
no further writer, work/routing admission, source replacement or reclamation is enabled.
Historical sections below retain their dated scope.

## ER-002 Retained Preflight Boundary (2026-10-30)

[Implementation](implementation/M2_RETAINED_ENROLLMENT_PREFLIGHT.md) and
[validation](implementation/M2_RETAINED_ENROLLMENT_PREFLIGHT_VALIDATION.md) move retained
protected-path inspection outside authority serialization. Actual source/parent/authority
ownership spans the unlocked phases; exact roles/metadata/empty head are checked again after
the last placement pass. All 2,487 Windows cases pass across complete project runs; 698 broad
Linux cases pass, including all 19 new bodies per platform. Two initial restore timeouts are
retained and pass focused plus complete Integration rechecks. Generic readers and frozen/public
contracts remain unchanged. Next ER-003 qualifies direct authority/parent close errors;
ER-004 and all host/public/archive/retirement gates remain open. Historical sections below
retain their dated scope.

## EF1-EF4 Consolidated Readiness Review (2026-10-30)

[Review](implementation/M2_ENROLLMENT_READINESS_REVIEW.md) verifies 51 retained TRX
artifacts, 256 unchanged source/build/fixture inputs and all 2,468 Windows test IDs; 679 Linux
focused IDs are retained separately. Fresh public metadata remains 95/95, with no additions.
No runtime suite or feature is added by the review. ER-002 identifies protected-ancestor I/O
under the shared authority monitor during retained preflight; next harden that boundary under
ADR-033. Direct authority/parent close-fault qualification and stopped restart/owner handoff
remain later gaps. No public API, application admission, routing or reclamation is enabled.
Historical sections below retain their dated scope.

## EF4 Enrollment Fault and Process Qualification (2026-10-30)

[Qualification](implementation/M2_FIRST_ENROLLMENT_FAULT_VALIDATION.md) adds observed
call-edge/all-prefix fault sweeps, actual Linux inode substitutions, cross-thread I/O closing,
repeated process/ACK-loss boundaries and independent competing publishers. The 387-byte frame
produces 393 sweep attempts; 34 new catalog cases include eight Windows host guards. Each
focused process run uses 48 workers. Production runtime/format/public surface is unchanged.
All 2,468 Windows and 679 isolated Linux focused cases pass; eight new Windows rows are
explicit host guards. Formatting/docs/portability and frozen fixture checks pass. Next consolidate
EF1-EF4 readiness and remaining host/restart contracts before another authority writer.
No application admission, actual routing or reclamation is enabled. Historical sections below
retain their dated scope.

## EF3 Conditional First Enrollment (2026-10-30)

[Implemented contract](implementation/M2_FIRST_ENROLLMENT_APPEND.md) and
[validation](implementation/M2_FIRST_ENROLLMENT_APPEND_VALIDATION.md) add one terminal
stopped Enroll append from the actual retained preparation. Exact empty-head/native-role checks,
flush/readback/full-history validation and cleanup confirmation precede acknowledgment.
Possible output or release uncertainty retains bytes and prevents receipt synthesis/retry.
All 2,434 Windows and 645 isolated Linux focused cases pass, including all 45 new cases per
platform. Formatting/docs/portability and frozen fixture checks pass. No application work admission or public API is enabled. Next EF4 qualifies observed
persistence positions, process interruption/ACK loss and competing owners. Real host/archive/
retirement gates remain open. Historical sections below retain their dated scope.

## EF2 Retained Enrollment Admission (2026-10-29)

[Implemented contract](implementation/M2_RETAINED_ENROLLMENT_ADMISSION.md) adds a
separate owner-bound retained preparation, resource transfer to actual execution and a
nonblocking authority/parent/source arm decision. Wrapper disposal retains all three original
owners through actual execution; unknown source close retains authority/parent operations.
All 2,389 Windows and 600 isolated Linux focused cases pass, including 29 new cases per
platform. Formatting/docs/portability and frozen fixture checks pass. No authority output or application admission is enabled. Next EF3 implements the
conditional first Enroll frame; EF4 persistence qualification and real host/public/archive/
retirement gates remain open. Historical sections below retain their dated scope.

## EF1 Retained Source Lifetime (2026-10-29)

[Implemented contract](implementation/M2_ENROLLMENT_SOURCE_RETENTION.md) and
[validation](implementation/M2_ENROLLMENT_SOURCE_RETENTION_VALIDATION.md)
add opt-in source/freeze children, deferred original writer-stream close and a source-owner
stop latch. Native identity, actual drain and release uncertainty remain explicit. All 2,360
Windows tests and 571 isolated Linux focused cases pass, including 29 new cases per platform.
Formatting/docs/portability and frozen fixture checks pass. No authority output or application admission is enabled. Next EF2 integrates a
separate retained preparation and atomic dispatch admission, still without authority writes.
Historical design/qualification blocks below retain their dated scope.

## Retained Source Exclusion and First-Enrollment Design (2026-10-29)

[ADR-033](ADR-033-retained-source-exclusion-and-first-enrollment.md) and
[contract](implementation/M2_APPLICATION_AUTHORITY_ENROLLMENT_APPEND_DESIGN.md)
specify opt-in source/freeze retention, one atomic arm decision, a stopped original-source
latch and exact one-frame conditional append with terminal uncertainty. This is design only;
current preparation remains read-only. The [review](implementation/M2_APPLICATION_AUTHORITY_ENROLLMENT_APPEND_DESIGN_REVIEW.md)
records 24 future acceptance scenarios, not test passes. Runtime/build inputs remain at the
qualified 2,331-case Windows / 542-case focused Linux baseline. Next EF1 implements source
retention/deferred close/stop-latch qualification with no authority writes. EF2-EF4, actual
host control, public APIs, archived compatibility and all reclamation remain open.

## Owner-Bound First-Enrollment Preparation (2026-10-29)

[ADR-032](ADR-032-owner-bound-first-enrollment-preparation.md) and
[validation](implementation/M2_APPLICATION_AUTHORITY_ENROLLMENT_VALIDATION.md)
add read-only preparation against a real frozen legacy store and its registered sealed
capture, actual source owner identity and scoped reconciliation assertions. The actual
owner-bound preparation is single-use and retains authority/admin leases. All 2,331 Windows
cases pass across full project runs; 542 isolated Linux cases pass, including all 35 new cases
per platform. One existing Windows kill case failed once and passed focused/complete reruns;
the validation report retains the observation. Operational
assertions remain supplied assumptions; no enrollment/append or application work is enabled.
Next design conditional first-enrollment save/uncertainty with continuing real ownership and
fresh explicit operational evidence. Historical next-action blocks retain their dated scope.

## EP7-C Explicit Authority Provisioning Slice (2026-10-29)

[ADR-031](ADR-031-application-authority-provisioning-and-initializer.md) and
[provisioning validation](implementation/M2_APPLICATION_AUTHORITY_PROVISIONING_VALIDATION.md)
add separate no-overwrite absent-root creation, direct exclusive-owner handoff, retained
partial state and a single-use live initializer reservation that holds actual paired leases.
All 2,296 Windows cases pass across full project runs; 475 focused Linux cases pass, including
46 new cases per platform. One existing Windows release case failed once and passed focused
and complete reruns; the validation report retains that observation.
All writers stay stopped. No enrollment/append or real application baseline is established.
Actual process interruption, acknowledgment loss and independent creators are now qualified.
Next bind a real operational baseline to owner-bound first-enrollment preparation before
conditional append. Historical next-action sections below retain their dated scope.

## EP7-C Paired Existing-Root Authority Inspection (2026-10-29)

[ADR-030](ADR-030-paired-read-only-application-authority-ownership.md) and
[lifetime validation](implementation/M2_APPLICATION_AUTHORITY_LIFETIME_VALIDATION.md)
add opaque parent-mode exclusion, real authority ownership/native identity checks, read-only
full-history inspection and actual-read drain. All 429 focused Windows cases pass, including
71 new cases (three Windows FIFO guards). Full Windows passes all 2,250 tests; fresh isolated
Linux passes 429 focused cases with actual FIFO bodies. Formatting/docs/portability and fixture
checks pass; exact scope and XML-only final test documentation are recorded in the report. Next explicit no-overwrite provisioning/initializer
qualification before append; no authority writes, routing or application admission is added.

## Application-Authority Pure Codec (2026-10-29)

[Codec validation](implementation/M2_APPLICATION_AUTHORITY_CODEC_VALIDATION.md) records
strict metadata/frame/TLV decoding and complete-history transitions with retained work obligations.
Four independent frame/history vectors and 166 focused cases pass. Successful Windows project
runs cover all 2,179 tests after a full Integration rerun cleared two initial timeouts. The
report retains those failures and the Docker-blocked Linux result; docs/formatting/portability pass. All decoded results stay stopped;
existing formats/public APIs remain unchanged. Next EP7-C starts with the new owner-bound
application child lifetime/existing-root boundary before provisioning and persistence.

## EP7-B Application-Authority Format Specification (2026-10-29)

[ADR-029](ADR-029-separate-application-authority-journal-v1.md) and the
[v1 contract](implementation/M2_APPLICATION_AUTHORITY_FORMAT_V1.md) specify separate
metadata/frames, retained work transitions, no-overwrite provisioning and uncertain-save rules.
[Validation](implementation/M2_APPLICATION_AUTHORITY_FORMAT_VALIDATION.md) records two
independent metadata-only vectors and 13 passing Python checks. No production codec or
persistence is implemented. Existing C# remains at the passing 2,013-test Windows baseline.
Next implement the pure codec/full-history validator with independent frame/history vectors
before EP7-C owned persistence. Existing host/store bytes and all histories remain protected.

## EP7-A Pure Pilot Authority Classification (2026-10-29)

[Classification validation](implementation/M2_EMBEDDED_PILOT_AUTHORITY_CLASSIFICATION_VALIDATION.md)
records the internal supplied-evidence model: exact authority/root/baseline/publication bindings,
nullable branch accounting, retained acceptance obligations and stopped-only outcomes.
All 119 focused Windows cases pass; the fresh full Windows regression passes 2,013 tests.
Formatting, strict docs and portability pass; Linux execution remains Docker-blocked. Next EP7-B specifies separate application-authority bytes/transitions
and provisioning/commit rules. No authority persistence, routing, work execution or public API
is implemented; existing host/store formats and all histories remain protected.

## Internal Embedded Pilot Authority Design (2026-10-29)

The user selected the internal embedded pilot. [ADR-028](ADR-028-embedded-pilot-selection-and-work-authority.md)
and its [authority contract](implementation/M2_EMBEDDED_PILOT_AUTHORITY_CONTRACT.md) define
separate selected-root/work accounting with acceptance before mutation, retained obligations
and stopped restart. This is design only; existing journal/store bytes and public APIs stay
unchanged. Next EP7-A is a pure supplied-evidence classifier with no I/O or write authority;
format, persistence and actual consuming-host execution remain later gates. The preceding
1,894-test Windows regression covers unchanged runtime, not this proposed backend.

## Post-EP6-D Readiness Review (2026-10-29)

The [current audit](implementation/M2_POST_EP6_READINESS_REVIEW.md) reviews checkpoint `4598346` and confirms that the next gate is
a consuming-host selected-root/work-authority contract. Administrative operation drain and
publication reconciliation do not establish application selection or accepted-work accounting.
Fresh Windows full regression passes all 1,894 tests; Linux execution is blocked by the
unavailable Docker engine. Formatting, strict documentation and portability pass. Historical
RC/EP reports retain their original scope; no runtime/API/format or release gate changes here.

## 1. Status, Sources and Scope

## Host Restart Checkpoint (2026-10-29)

EP6-C is pushed as `5977451`; this checkpoint includes the completed EP6-D process tests and
documentation. All 1,055 focused cases passed per Windows/Linux platform (732 Storage,
323 Integration), including 72 new process cases. Formatting and strict documentation/portability
checks passed. No production source, public API, package pin or wire format changed in EP6-D.
Hosted run `40822530134` was blocked before runner execution by account payment/spending limits.

The [XDM 4.0 assessment](implementation/M2_XDM40_COMPATIBILITY_ASSESSMENT.md)
records existing Bosak foundations and proposed provider qualification (REQ-009). It does not
claim full current-draft conformance or introduce persistent JSON/general XDM storage.

After restart, inspect `git status --short` and `git log -1`, then read this handover and
[EP6-D evidence](implementation/M2_EMBEDDED_HOST_RESTART_PROCESS_VALIDATION.md).
Next: audit consuming-host selected-root authority and accepted-work accounting before adding
application integration. Reopened stores/host journals stay stopped; no automatic retry, route
change, writer resumption or reclamation is authorized by these tests. Proprietary licensing,
Bosak 1.26.2 pins and disabled packaging remain fixed. Earlier sections are historical step
records; this checkpoint supersedes their delivery status and next-action wording.

## EP6-D Restart/Retry Process Qualification (2026-10-29)

EP6-C is pushed as `5977451`. [EP6-D validation](implementation/M2_EMBEDDED_HOST_RESTART_PROCESS_VALIDATION.md)
adds 72 actual process-kill cases across both roles at H=1, covering transfer, known/absent
outcomes, fresh retry intent and execution acknowledgment gaps. Reopen remains stopped;
separate reconciliation retains data and never recreates execution tickets. All 1,055 focused
cases pass per Windows/Linux platform. EP6-D is included in this restart checkpoint. Next audit the consuming application's selected-root/work-accounting gate;
production routing, writer resumption, public release and physical durability remain open.

## EP6-C Explicit Fresh-Plan Retry (2026-10-29)

EP6-A/B is pushed as `8d38762`. [EP6-C validation](implementation/M2_EMBEDDED_HOST_RETRY_VALIDATION.md)
adds explicit retry preparation with a fresh real plan/attempt ID after exact qualified absence.
It retains request/pin/destination, reinspects before recording and uses an exact-position save
to exclude duplicate retry intents across fronts. 22 new cases cover success, changed facts,
concurrency and lost intent acknowledgment. All 983 focused cases pass per Windows/Linux platform.
EP6-C remains local/uncommitted. Next qualify
process termination across the combined restart/retry workflow; automatic retry/writer resume
and application routing remain disabled.

## EP6-B Stopped Restart Inspection (2026-10-29)

[EP6-B validation](implementation/M2_EMBEDDED_HOST_RESTART_INSPECTION_VALIDATION.md)
adds actual pinned-operation inspection with acknowledged owner transfer and separate known
observation/qualified absence saves. Admissions stay closed; saved receipts cannot be synthesized
or replaced from inspection. 26 new Integration cases cover both roles/heads, contradictory
terminal facts and uncertain saves. All 961 focused cases pass on Windows and Linux.
Next: explicit fresh-plan retry after qualified absence;
retry runtime and process-kill qualification remain pending. EP6-A/B remain local/uncommitted.

## EP6-A Stopped Append Boundary (2026-10-29)

The EP6 contract is pushed as `22eeddf`. [EP6-A validation](implementation/M2_EMBEDDED_HOST_STOPPED_APPEND_VALIDATION.md)
adds exclusive stopped-session registration and restricted transfer/observation/absence saves,
without opening administrative admissions. 25 new cases cover evidence, stale/foreign tokens,
concurrency, uncertainty and shutdown drain. All 935 focused cases pass on Windows and Linux.
Inspector composition, explicit fresh-plan retry
and process-kill qualification remain pending. EP6-A changes are local/uncommitted.

## EP6 Stopped Restart Design (2026-10-29)

EP4/EP5 is committed and pushed as `24feda2`. The [EP6 contract](implementation/M2_EMBEDDED_HOST_RESTART_CONTRACT.md)
specifies a restricted reconciliation session with admissions closed, exact owner transfer,
separate known-operation observations and qualified absence before an explicit fresh-plan retry.
This is design only; restart persistence and retry runtime remain pending. Next implement the
stopped lifetime registration/append path and qualify its uncertainty and concurrency boundaries.
Existing 910 focused tests per platform remain the baseline; no new runtime coverage is claimed.
Hosted run `40793748444` could not start runner steps due to GitHub payment/spending limits.

## EP5 Live Plan-Bound Orchestration (2026-10-28)

[ADR-026](ADR-026-live-plan-bound-embedded-orchestration.md) and
[validation](implementation/M2_EMBEDDED_HOST_ORCHESTRATION_VALIDATION.md) add
opaque live tickets, exact acknowledged intent/authorization and one registered executor per
host. Actual receipts and host acknowledgments/errors remain separate; no saved plan is
reconstructed. 56 new cases qualify process gaps, duplicate use, active-attempt mutation and
shutdown; 910 focused cases pass per platform. Public metadata/wire formats stay unchanged.
Next: stopped persisted restart reconciliation and explicit new-ID retry after qualified
absence. HA2 application, global fencing, release and physical durability gates remain open.
EP4/EP5 was subsequently committed/pushed as `24feda2`; hosted CI remains billing-blocked.

## EP4 Owned Conditional Append (2026-10-28)

EP2/EP3 is committed/pushed as `4642b09`. [ADR-025](ADR-025-owned-conditional-host-journal-append.md)
and [append validation](implementation/M2_EMBEDDED_HOST_APPEND_VALIDATION.md)
now qualify exact-head append, actual file flush/readback and permanently faulted uncertain
sessions. 47 new cases cover write/flush failures, process interruption and test-only planned
publication composition; focused runs pass 854 cases per platform. Public Storage metadata
and wire formats stay unchanged. Reopened history remains stopped and never recreates a plan.
Next EP5 binds acknowledged ledger transitions to one registered live executor in an internal
orchestrator. HA2 application, release and physical durability gates remain open. EP4 is local.

## EP3 Explicit No-Overwrite Provisioning (2026-10-28)

[ADR-024](ADR-024-explicit-no-overwrite-host-provisioning.md) and
[validation](implementation/M2_EMBEDDED_HOST_PROVISIONING_VALIDATION.md) qualify
controlled absent-root creation, continuous CreateNew owner handoff and retained interrupted
state. 60 new tests cover partial writes, checkpoint/process kills and synchronized contenders;
807 focused cases pass per platform. Existing roots are never adopted or repaired by provision.
Reopened empty roots remain stopped; the live initializer diagnostic is not durable authority.
Next EP4 implements bounded conditional journal append and unknown-flush fault handling.
Physical durability, hostile namespace/global fencing, HA2 and release gates remain open.
Changes remain local/uncommitted; pushed baseline `2141eac` is unchanged.

## EP3 Existing Host Lifetime Ownership (2026-10-28)

[Ownership validation](implementation/M2_EMBEDDED_HOST_OWNERSHIP_VALIDATION.md)
adds existing-root cooperative exclusion, stopped administrative admissions and token-drained
shutdown. 50 new catalog cases cover process exit/active drain, aliases, invalid roots and
real publisher lifetimes. Focused runs pass 747 cases per platform; three FIFO rows execute
only on Linux. Public Storage metadata remains unchanged. No host files are provisioned,
repaired or appended by this implementation, and no global fence or writer resume is implied.
Next: explicit no-overwrite provisioning and interruption/contender tests before EP4 append.
EP2/EP3 work remains local/uncommitted; the pushed baseline remains `2141eac`.

## EP2 Internal Journal Codec (2026-10-28)

[Codec validation](implementation/M2_HOST_JOURNAL_CODEC_VALIDATION.md) now covers
strict bounded metadata/frame/TLV encoding, complete history checks and four independently
authored host-only vectors. 117 new codec cases pass; focused Windows/Linux runs pass 697
cases each. All 168 prior runtime/test/fixture files and public Storage metadata are unchanged.
Decoded history always keeps writers stopped; no codec output grants execution or proves
flush, anti-rollback or fencing. Next EP3 qualifies stable host-root lifetime ownership with
explicit provisioning boundaries and real process tests. EP4 durable append, HA2 application
integration and release gates remain open. EP2 design/codec changes remain local/uncommitted.

## Current Delivery and EP2 Journal Contract (2026-10-28)

The embedded profile is committed/pushed as `2141eac`. [ADR-023](ADR-023-bounded-embedded-host-journal-contract.md)
and the [journal contract](implementation/M2_EMBEDDED_HOST_JOURNAL_CONTRACT.md)
now define bounded canonical host-only frames, conditional transitions and explicit append/flush
uncertainty. Damaged tails are retained and block appends; restart never replays a plan.
No codec/writer, anti-rollback authority or durable-host proof is implemented. Next: a pure
internal codec with independent byte vectors, before filesystem persistence. This contract
is local/uncommitted; earlier delivery notes below retain their original scope.

## Current Delivery and Embedded Pilot Selection (2026-10-28)

RC2 through test-only HA1 integration is committed/pushed as `5d23ba2` on `origin/main`.
The user selected single-process embedded integration first. [ADR-022](ADR-022-single-process-embedded-pilot-host.md)
and the [pilot profile](implementation/M2_EMBEDDED_HOST_PROFILE.md) define one
controlled process, a dedicated host-state root, lifetime ownership and stopped restart
reconciliation. A local file journal is proposed; no backend or host is implemented yet.
Next EP2 defines its bounded codec, commit and corruption/rollback contract. M4 server,
HA2 application routing/work, public/archived-reader/release and retirement gates stay open.
This post-push profile is local; older uncommitted statements below describe their original
milestones. No runtime/test/fixture source changes or new runtime runs occur in this step.

## HA1 Ledger and Planned Execution Tests (2026-10-28)

[Test-only integration](implementation/M2_HOST_LEDGER_PLANNED_EXECUTION_VALIDATION.md)
now connects memory-ledger intent/authorization/receipt transitions to real owner-bound
migration and restore. 34 new cases cover lost-save acknowledgments, actual publication
uncertainty, new-ID retry after reconciled absence, concurrent authorizers and an active
publisher that defeats absence-based retry. Focused runs pass 448 cases per platform.
All prior runtime/test/fixture files are unchanged; no production adapter is introduced.
The bounded model/library integration is complete. Next: identify the actual consuming host,
durable backend, effective publisher exclusion and route/work authorities before HA2.
No memory commit proves durability or fencing. Changes remain local and uncommitted.

## HA1 Conditional Transition Harness (2026-10-28)

The internal [in-memory transition harness](implementation/M2_HOST_LEDGER_TRANSITION_VALIDATION.md)
now models exact-revision commits, single dispatch authorization, explicit read reconciliation
of lost acknowledgments and supplied-exclusion ownership transfer. 83 new tests cover commit
boundaries, concurrent winners, stale owners and preservation of receipts/observations;
414 focused cases pass per platform. Public Storage metadata remains unchanged.
No durable backend, executable permit, effective fence, routing or writer resume is supplied.
Next: test-only integration of these transitions with actual planned execution and lost-save
acknowledgments. Actual host selection and HA2 remain open; changes are uncommitted.

## HA1 Internal Ledger Model (2026-10-28)

The [ledger decision model](implementation/M2_HOST_ATTEMPT_LEDGER_MODEL_VALIDATION.md)
now checks supplied request/attempt/revision/owner bindings, durable-intent assumptions,
publication/receipt identity and prior-executor exclusion. All 180 new model tests pass;
focused validation covers 331 cases per platform, retaining earlier full-suite evidence at
its original scope. Every output keeps writers stopped and grants no executable authority.
Actual host selection, persistence and HA2 integration remain open. Next: an internal
conditional-transition harness for revision/CAS and lost-acknowledgment protocol tests.
Changes remain local and uncommitted; proprietary licensing and release gates are unchanged.

## HA1 Host Ledger Contract (2026-10-28)

[ADR-021](ADR-021-host-attempt-ledger-and-publisher-exclusion.md) and the
[host ledger contract](implementation/M2_HOST_ATTEMPT_LEDGER_CONTRACT.md) define
durable intent before dispatch, revision-checked ownership, separate acknowledgment and
observation records, and prior-executor exclusion before any fresh attempt. A ledger lease
cannot fence the current publication path; an old publisher must be stopped or effectively
excluded before takeover/retry. The 24 design scenarios are requirements, not runtime tests.
Actual host selection and HA2 integration remain open. Next: an internal pure supplied-evidence
ledger decision model and adversarial tests. No persistent backend, routing, public API or
writer resume is enabled. RC2/RC3 and this contract remain local and uncommitted.

Earlier milestone notes below retain their dated scope; the HA1 next step above is current.

RC2 implementation (2026-10-28): [planned administrative execution](implementation/M2_ADMINISTRATIVE_ATTEMPT_EXECUTION_VALIDATION.md) claims once, revalidates pinned intent before output and publishes the preknown ID in unchanged provenance fields. 31 new cases cover identity, early rejection and publication uncertainty. Next: RC3 process/restart and competing-publisher qualification; no public API or routing is enabled.

RC1 implementation (2026-10-28): [read-only preparation and single-dispatch state](implementation/M2_ADMINISTRATIVE_ATTEMPT_PLAN_VALIDATION.md) add bound attempt descriptors and owner/policy checks with 28 new cases. Claim is a pure local primitive; pipeline execution remains deferred. Next: RC2 planned execution with exact preknown IDs and publication-outcome tests.

Administrative attempt design (2026-10-28): [ADR-020](ADR-020-planned-administrative-attempt-correlation.md) and the [identity/retry contract](implementation/M2_ADMINISTRATIVE_ATTEMPT_CONTRACT.md) define preknown library-created attempt IDs, single-use process-local plans and descriptor-only restart inspection. No runtime API or caller-ID parameter is implemented. Next: RC1 read-only prepare and plan ownership/concurrency tests.

Current review (2026-10-28): [consolidated regression and API readiness](implementation/M2_CONSOLIDATED_API_READINESS_REVIEW.md) covers internal CA/HC/PA prototypes, fresh fault matrices, public metadata and documentation portability. Public mutable access, actual host routing, archived compatibility and release remain open. Next: request-to-publication operation correlation.

**Unreleased M1 and experimental M2 with internal epoch/migration/administrative and authority retained-source/terminal first-enrollment prototypes.** Target net10.0,
SDK 10.0.301. See [current execution evidence](../M2_STATUS.md).

This document consolidates the [agent assignment](Bosak_XmlDb_Agent_Handover_v0.1.md),
[M1 plan v0.2](Bosak_M1_Persistent_Fragment_Provider_Implementation_Plan_v0.2.md) and
[technical design v0.3](Bosak_Native_XML_Storage_Engine_Technical_Design_v0.3.md).
The M1 plan governs immediate implementation. Source findings marked verified in
the design refer to its ZIP inspection. M1 separately verified the selected 1.26.2 package commit and inspected its XDM contract.
Source-document C# proposals remain illustrative; implemented APIs are described in [integration](INTEGRATION.md).

The goal is native persistent XML exposed through Bosak's existing XDM/query runtime.
Initial non-goals include full XQuery Update, adaptive fragmentation, cross-service
ACID, distributed XQuery joins and full BaseX parity. M1 also excludes WAL,
transactions, secondary indexes and distributed operation.

## 2. Product Model and Dependencies

One engine supports embedded and future server/distributed hosting. Physical format,
node identities and query semantics stay consistent; commit coordination and
operational infrastructure vary. Embedded mode requires no NATS or containers.

| Project | Direct product references | Responsibility and status |
|---------|---------------------------|---------------------------|
| Core | None | Implemented StorageNode metadata, node kinds and metrics |
| Storage | Core | Implemented importer, format 1.0 codecs, snapshots/cache, scalar transactions and WAL recovery |
| Xdm | Core, Storage | Implemented node adapter, result lifetime binding and exact-URI resolver; pinned Core 1.26.2 |
| Storage.Tests | Storage | Format golden fixtures, corruption, cache, import/reopen and dependency checks |
| Xdm.Tests | Xdm | Differential corpus, all axes, URI integration and lifetime checks |

Arrows mean direct project references. Core, Storage and Xdm are implemented; the selected Bosak dependency is now active. An integration test project and runnable sample complete the solution.

<a id="architecture-project-dependencies"></a>

```mermaid
flowchart BT
    X["Xdm adapter"] --> S["Storage"]
    X --> C["Core metadata"]
    S --> C
    X --> B["Bosak XDM packages"]
    classDef current fill:#F0FFF0,stroke:#518D8F,color:#2F4F4F,stroke-width:2px
    classDef external fill:#FFFFFF,stroke:#293F5F,color:#2F4F4F
    class X,S,C current
    class B external
```

<p class="fytala-figure-caption">Project dependencies: implemented source packages and the pinned upstream integration boundary.</p>

Bosak must never depend on XmlDb. Preserve upstream interfaces and the remote Database
provider. Future Resolution, Query/Indexing, Transactions, Server, Replication,
Coordination and Backup packages are candidate boundaries, not M0 projects. Generic
storage must remain independent of OAGIS and NATS. See [ADR-001](ADR-001-repository-and-hosting.md).

## 3. M1 Physical Storage

Parse a SalesOrder once into header, repeating line-group and optional cold extension
fragments. Persist structural metadata separately from value payload bytes. The
node directory may be loaded or memory-mapped in M1; measure its memory cost.

```text
<database-root>/
  FORMAT
  documents/<document-id>/manifest.bin
  documents/<document-id>/directory.bin
  fragments/<fragment-id>.bin
```

This layout is implemented as experimental format 1.0. The exact byte contract and bounds are in [BINARY_FORMAT_V1.md](implementation/BINARY_FORMAT_V1.md); [ADR-002](ADR-002-immutable-format-and-snapshot.md) records concrete M1 decisions.

| Structure | Proposed content |
|-----------|------------------|
| FORMAT | Version and compatibility marker |
| Manifest, BXMF | Major/minor version, document/root IDs, directory checksum, fragment IDs/checksums |
| Directory, BXND | Versioned node records: ID, parent, kind, expanded name, order, ordered children/attributes and value pointer |
| Fragment, BXFG | Version, fragment/document IDs, codec, lengths, checksum, payload; M1 codec=none |

Use explicit little-endian encoding, unsigned 64-bit IDs, checksums and configured
length limits before allocation. Never persist CLR struct memory. Reject bad magic,
versions, checksums, truncation and references escaping the database root. Fix the
checksum algorithm and golden byte fixtures before implementing codecs.

DocumentId, NodeId and FragmentId have distinct roles. Node identity must survive
fragment relocation, with no ID reuse after deletion when mutation is introduced.
Order is a separate property from physical location.

Write fragments/directory before the manifest. Staging and final rename are an M1
convenience; manifest-last publication alone does not guarantee crash-safe import.
Durable atomic publication and WAL belong to M2.

## 4. Persistent Navigation and Snapshot Lifetime

Implement the actual upstream IXdmNode contract, copying XdmSequence, typed-value
and evaluator patterns from existing providers rather than guessing signatures.
A header path resolves names and children through the directory and loads only
header values. Counts may use metadata; line selection loads its containing group
through a bounded decoded-fragment cache. Track physical reads, bytes, cache hits
and header/line payload reads.

Use synchronous local reads or higher-level prefetch at the synchronous XDM
boundary. Do not call GetAwaiter().GetResult() on arbitrary async/remote I/O inside
node evaluation. Async ingestion/bulk APIs can remain separate.

| Invariant | Required behavior |
|-----------|-------------------|
| Snapshot ownership | One evaluation snapshot remains live through lazy result consumption |
| Disposal | Check at enumeration start and every fetch; late access fails deterministically |
| Identity | Compare logical document/node IDs within a snapshot; define cross-snapshot semantics before MVCC |
| Order | Match XDM order, including namespace/attribute placement; normal-node order is nonzero |
| Element string value | Concatenate descendant text in document order |
| Types | Preserve appropriate untyped semantics without fabricated schema annotations |
| XML fidelity | Preserve namespaces, attributes, mixed content, whitespace, comments, PIs and base/document URIs |

Serialization must preserve the logical XML infoset. Byte-identical lexical fidelity
is a separate decision. Axes, per-context positions, identity and results must stay
correct when fragment boundaries change.

## 5. Query Runtime, Native Resolution and Indexes

Keep the existing optimizer, IR lowerer and VM unchanged for M1. Compose native
fn:doc() resolution through existing evaluation-context hooks, capturing the same
snapshot for the query. Native fn:collection() requires a separate resolver/catalog
and shared snapshot when added. Use a scoped wrapper if context hooks cannot safely
express ownership; avoid hidden ambient lifetime state.

The remote Bosak.XPath.Providers.Database connector remains responsible for BaseX,
eXist-db and MarkLogic HTTP document/collection retrieval. Preserve schemes,
credentials, response stream lifetimes, fallback behavior and regression tests.
Native URI handling is opt-in and must not shadow file/remote schemes. Do not route
native storage through the remote HTTP scheme implementation.

The illustrative URI bosak://sales/orders/12345 is not an implemented contract.
Define mapping, authorization, missing-document errors, stable identities,
cross-document ordering and duplicate elimination before exposing native resolution.

Later candidates include QName, canonical path, typed-value and URI/business-key
indexes. Account for expanded names, atomic types, collations and visibility. Treat
hits as candidates until exact semantics are proven; retain residual predicates and
traversal fallback. Preserve reverse axes, context position/size, ordering and
deduplication. A global first index hit cannot replace per-context [1] semantics.
Do not embed snapshot-bound index handles in reusable compiled queries.

## 6. Embedded Transactions: Implemented Slice and Future Scope

The first M2 slice implements EmbeddedXmlDatabase and XmlWriteTransaction in Storage.
One coordinator holds an OS-backed exclusive writer lease. A transaction captures a
document sequence and stages one text or ordinary attribute replacement. Commit rejects
stale base sequences; rollback/disposal writes no WAL. XML namespace attributes,
structural changes and multiple targets are unsupported.

The base M1 files stay unchanged. A versioned .transactions sidecar contains base
identity, immutable full generations, one logical redo record per sequence and a
published CURRENT pointer. Commit flushes a complete staging generation, writes and
flushes WAL, renames the generation, atomically replaces the flushed root pointer,
then returns its sequence. WAL is authoritative and binds old/new manifest hashes.
Recovery checks the contiguous chain and replays missing generations deterministically.
Corrupt committed state fails closed; only an unreferenced incomplete final append
can be discarded. Persistence exceptions fault the coordinator until reopen.

BeginRead pins a generation; old snapshots survive later commits and coordinator
disposal. IDs/topology/order remain unchanged for scalar edits. Generation/WAL history
is retained, with no reclamation. Direct ImmutableXmlSnapshot.Open rejects a transactional
root to prevent stale base reads. Cross-snapshot wrapper identity remains distinct.

Recovery currently verifies all retained materialized generations and may read all
payloads during startup. Snapshot query metrics exclude that recovery I/O. Full
copy-on-write generations also copy unchanged fragments; optimizing startup and write
amplification is future M2 work.

The [process-crash matrix](implementation/M2_CRASH_MATRIX.md) passed locally on Windows.
The experimental Linux directory adapter passed native overlayfs execution; physical power-loss guarantees remain unverified. See [ADR-004](ADR-004-embedded-scalar-transactions.md)
and the [transaction format](implementation/M2_TRANSACTION_FORMAT_V1.md).

### Filesystem Barriers and Injected I/O Failures

Transaction mutation operations now use an internal storage seam. The unchanged
Open(root, documentId) API defaults to ProcessCrash; the explicit durability overload
also supports FileAndDirectoryFlush on Linux. Unsupported requests fail before adoption,
without falling back. Native Linux execution now passes in an isolated Docker overlayfs run; physical power-loss certification remains open.

The stronger policy probes directory fsync, takes writer ownership, flushes existing
store files/directories and root ancestors, then recovers. New file/namespace operations
have ordered parent-directory barriers. WAL content/close and directory persistence
precede generation publication; generation rename syncs both parents; CURRENT's
parent barrier precedes acknowledgment. The policy is per coordinator, not a stored
SLA for later sessions. Binary fields and versioned fixtures are unchanged.

Fault sweeps cover actual partial temporary-file writes and before/after create,
flush, close, move, deletion and barrier failures. The current transaction/checkpoint/backup gate passes 669 tests per platform and expanded descriptor publication fault sweeps. Recovery must release ownership, return a complete old/new state
and accept a later commit. See [validation](implementation/M2_FILESYSTEM_FAULT_VALIDATION.md).

### Non-Deleting Checkpoints and Reader Leases

CreateCheckpoint copies a complete validated materialization, writes an immutable
anchor binding document/sequence, manifest and exact WAL prefix, then publishes a
selector through the configured barriers. FullJournal remains default. PreferCheckpoint
checks the anchor and every retained WAL record, uses the checkpoint at S and validates/
replays the suffix. Optional corruption falls back to full history; required WAL
corruption still fails. LastRecovery exposes which path and work were used.

Each BeginRead/BeginWrite snapshot owns a shared OS-backed per-sequence lease acquired
under coordinator selection. Its handle survives coordinator disposal and blocks an
exclusive probe in another process until the last holder disposes/exits. Canonical
lease identities are published atomically and never replaced/unlinked. Stronger-mode
synchronization skips writes to live lock identities while still syncing their names.

All committed WAL, materializations, base data and lease files remain retained. Old
M1/older experimental snapshots were never retroactively registered; private nested
data paths are not a supported way around the coordinator. No public retirement or
GC API exists. See [ADR-006](ADR-006-nondeleting-checkpoints-and-reader-leases.md),
[format](implementation/M2_CHECKPOINT_FORMAT_V1.md) and [validation](implementation/M2_CHECKPOINT_VALIDATION.md).
### Remaining Transaction and Outbox Design

M2 proposes immutable copy-on-write generations, snapshot isolation and optimistic
write-write conflict checks. Intended atomic state includes fragments, roots,
directory, indexes and optional outbox. Decide initial document/partition transaction
span. Serializable invariants need extra range/predicate validation or aggregate
locking to prevent write skew.

Embedded commit stages generations/deltas, validates conflicts, appends checksummed
WAL including outbox, durably flushes, publishes root/commit sequence and acknowledges.
Reclaim old generations after readers close. Recovery replays only committed records
and discards incomplete work. Inject crashes around every durability step and verify
root-swap/flush behavior on target filesystems.

A local-first outbox publishes after local commit. Stable event IDs, retries and
idempotent consumers handle crash/retry duplicates. This flow has different durability
from the distributed log-first proposal.

## 7. Distributed Commit and Read Consistency â€” Proposal

Technical design v0.3 proposes an ordered, durably accepted partition transaction log
as the distributed authority; local fragments become replayable materializations.
JetStream is a candidate transport. A publish acknowledgment alone establishes
neither fencing nor isolation nor arbitrary multi-message transaction atomicity.

| Concern | Embedded proposal | Distributed log-first proposal |
|---------|-------------------|--------------------------------|
| Authority | Local checksummed WAL and durable flush | Ordered quorum-accepted partition record |
| Writer | Local coordinator | One fenced leader per partition |
| Queries | Local XDM/indexes | Local XDM/indexes on leader or replica |
| Recovery | Snapshot and WAL | Verified snapshot and contiguous log replay |
| Infrastructure | No NATS requirement | Log, coordinator and durable local materialization |

Use a stable versioned partition mapping of tenant, entity type and entity key.
Cross-partition operations need workflows/sagas or explicit higher coordination.
Route the whole query to local data, avoiding network requests per XPath node.

Authoritative append must atomically enforce monotonic leadership epoch and expected
sequence. Checking ownership then publishing normally leaves a race. Queue groups
and epoch fields in payloads do not fence stale writers. Prove conditional append
or adopt a suitable consensus-backed mechanism before claiming safe failover.

Prefer one indivisible transaction record. Oversized transactions need verified
staged content plus a durable commit marker before visibility. Deduplicate stable
transaction IDs; replay deterministically; persist applied position with the MVCC
root. Failover fences the old writer, establishes a new epoch, catches up through
durable commits and activates ownership. Reject authoritative writes during uncertain
ownership/quorum loss. Replicas may serve explicitly stale reads.

| Planned read class | Guarantee |
|--------------------|-----------|
| ReadLocal | Snapshot-consistent local view, potentially stale |
| ReadAtLeast(position) | Wait for the required partition position |
| ReadLatest | Fenced leader or verified barrier including prior acknowledged commits |
| Analytical snapshot | Stable local replica view with documented lag |

NATS supplies request/reply transport; JetStream may carry commits/events. Neither
replaces physical XML storage, isolation or independent backup. OAGIS BOD/entity
services are a separate layer: authoritative entity operations enforce business
invariants; projections elsewhere can be eventually consistent.

## 8. Backup, Recovery and Hosting â€” Future

A backup includes fragments, manifests, directory, schema/profile versions, index
definitions, checksums, key references and the exact committed sequence. Decide
whether indexes are copied or rebuilt. PITR restores a verified snapshot and replays
a gap-free archive to a commit position; timestamps alone are insufficient. Reject
missing/corrupt ranges, retain dependent log ranges and run restore/site-loss drills.
Replication is not backup. The source RPO/RTO examples are goals, not measured SLAs.

The future ASP.NET Core host needs authenticated versioned APIs, health/live and
health/ready endpoints, metrics, validated configuration and shutdown behavior.
Containers run as non-root with persistent storage at /data. Compose supports
failure testing. Kubernetes proposes StatefulSets, PVCs, stable identities, resource
requests/limits, probes, topology spread, disruption budgets and restore runbooks.
Pod restart alone is not engine failover. An operator/CRD is optional after these
contracts stabilize.

## 9. Validation and Performance Gates

Compare actual Bosak in-memory and persistent providers over 0, 1, 10, 500 and
10,000-line SalesOrders, groups of 1, 16 and 128 lines and random boundaries.
Include namespace, attribute, URI, whitespace and mixed-content cases. Follow the
[fixture plan](implementation/FIXTURE_PLAN.md).

Prove header queries read zero line payloads; line selection/counts, identity/order,
axes and serialization agree; disposal is safe; corruption is rejected; a new
process reopens without parsing source XML. M2 requires all M1 gates and explicit
format versioning to pass first.

Measure cold/warm p50/p95/p99, allocations, directory memory, reads, bytes and cache
hits. Later add large Item sets, FLWOR, indexes, partial updates and concurrency,
recording throughput, CPU, disk, write amplification and recovery time. Distinguish
in-memory Bosak, Bosak over remotely fetched XML, server-side BaseX and native-store
queries. Compare PostgreSQL/JSONB with comparable indexes where useful. [Initial measurements](../benchmarks/m1/README.md) record local warm/fresh-cache behavior; no general performance advantage is established.

## 10. Implemented M1 Scope and Open Contracts

M1 uses one immutable document per new root, eager bounded XDocument ingestion, eager
structural metadata and lazy payloads. Namespace nodes are persisted explicitly.
Node IDs also provide immutable preorder; cross-snapshot wrappers are distinct.
Use BindResult for VM-owned lazy sequences. DTDs are prohibited, CDATA boundaries are
not retained during serialization. M2 adds one-scalar updates through a separate coordinator; collections and structural edits are not implemented.
See ADR-002 for the upstream Attributes() helper discrepancy and the exact supported scope.


| Topic | Position |
|-------|----------|
| Repository/hosting | Separate repository; one engine; embedded first; ADR-001 |
| Scalar transactions | Single document/node, retained generations, WAL-led recovery; ADR-004 |
| Filesystem barriers | Explicit policy, injected fault sweeps, native Linux overlayfs validation; ADR-005 |
| Checkpoints/readers | Non-deleting anchors, optional recovery and snapshot-owned cross-process leases; ADR-006 |
| Compatibility/backup | ADR-009 implements fixed-H backup/restore; ADR-010 adds internal epoch metadata/admission primitives; ADR-011 adds read-only epoch data; transactional migration/retirement pending |
| Namespace | Bosak.XmlDb.* |
| Build | net10.0, pinned SDK, nullable/XML docs/analyzers, MinVer, FYTALA kit |
| Upstream | Bosak 1.26.2, package commit 6a3372fc3b91e733b71a426cf40f26feaaeb3bcb verified in Git; ADR-003 |
| License/dependency | Proprietary Fytala license, matching Bosak.Braid; upstream pinned to 1.26.2; packaging disabled |
| Format | Encoding/checksum fixed in format 1.0 and golden fixtures; no migration or distributed compatibility promise |
| Identity/order | M1 wrappers are snapshot-local with immutable preorder; mutable insertion/global order remain open |
| XML/schema | Decide lexical fidelity, annotations, profile migrations and rolling upgrades |
| Planning | Decide compile/bind/runtime integration and required/configurable indexes after evidence |
| Operations | Compression, transaction span, partition transfer, backup portability and cross-region recovery remain open |

The [roadmap](../ROADMAP.md) uses the M1 plan's expanded schedule and maps differing
later numbering in the technical design. This consolidation does not approve future
protocols or alter source documents. The referenced OAGIS strategy document and
source ZIP are not supplied here.



(c) Fytala. All rights reserved.

## Recovery Descriptors and Retention Inventory

Implemented in [ADR-007](ADR-007-recovery-descriptors-and-retention-inventory.md):
`CreateRecoveryAnchor()` publishes an immutable descriptor after a verified complete
checkpoint. Publish at separate commits to retain independent older recovery copies.
`PreferCheckpoint` tries canonical descriptors newest-first when CHECKPOINT is invalid
or absent; every retained WAL record and selected prefix must still validate.
`PlanRetention()` reports file dependencies and selected-root files without mutation.
Its `CanReclaim` is always false: older readers, base compatibility, stable lease
identities and full WAL history remain protected. The report is a point-in-time
inventory, not a backup or permission to delete files. The compatibility transition and backup/retirement protocol are now specified in
ADR-008 (design only). Verified full-history backup/restore is now implemented per ADR-009; migration and
reclamation remain disabled.


The [compatibility/backup/retirement protocol](implementation/M2_COMPATIBILITY_BACKUP_RETIREMENT.md)
keeps format 1 non-deleting. A future mandatory format major fences supported older
open paths; an optional marker cannot do so. Restore targets are new roots. Epoch
admission belongs to snapshots/transactions and uses one lock order before maintenance.
Full-history backup is implemented per ADR-009; internal admission primitives are
implemented per ADR-010, while epoch data integration, migration and retirement remain
unimplemented. WAL-prefix/base removal is outside the first retirement scope.



CreateBackup holds the source coordinator gate; BackupStorage selects canonical full
history and verifies a disposable clone before sealing BXBI inventory/BXBC completion.
RestoreBackup rejects invalid closure/hashes, verifies exact H/head with zero replay,
then publishes a fresh data root. ITransactionStorage also owns deletion of private
verification clones/workspaces; it never deletes source history. BackupCodec limits
inventory entries to 100,000 and uses separately versioned envelopes/golden fixtures.
See [ADR-009](ADR-009-verified-full-history-backup-and-restore.md).



[ADR-010](ADR-010-mandatory-epoch-format-and-admission-primitives.md) adds internal
EpochCodec/EpochAdmission in Storage only. Metadata-only bootstrap publishes major-2
FORMAT plus bound EPOCH/BXEP and stable BXEA identity. Shared child handles independently
outlive owners; maintenance is exclusive and acquisition fails immediately on contention.
The existing BinaryEnvelope/public data readers are unchanged and reject major 2.
Actual read-only epoch snapshots now own admission per ADR-011; future transaction,
backup and coordinator paths
must acquire admission before coordinator selection and generation identities. Tests use
frozen pre-epoch managed reader bytes; unavailable pre-lease binaries are an open gate.



[ADR-011](ADR-011-admission-owned-read-only-epoch-snapshots.md) adds public
ReadOnlyEpochDatabase with BeginRead returning the existing ImmutableXmlSnapshot and
unchanged XDM adapter. Only this explicit major-2 entry point can use the internal
admitted metadata loader; legacy format checks remain unchanged. SNAPSHOT/BXES binds
identity, sequence zero, FORMAT and manifest. A .transactions marker is refused to
avoid stale base reads. Session and snapshots own separate shared handles; all failure
paths release only their own handles. Payloads stay lazy and checksum-checked.

Internal immutable-source fixture production copies documents/fragments without a
nested M1 FORMAT, verifies the staged data before publication and retains source bytes.
It refuses adopted transactional sources. No supported data-history migration or epoch
writer/recovery/backup exists. ADR-012 now defines the mutable epoch authority/feature gate; its runtime codecs and
coordinator remain unimplemented.



[ADR-012](ADR-012-mutable-epoch-feature-and-recovery-contract.md) specifies a proposed
mutable BXDB 2.1 profile (contracts 3/3, recovery 2, required admission+scalar-WAL bits)
with explicit entry-point capability selection. It does not alter the shipped 2.0
allowlist. Epoch-specific control/WAL/current/generation/reader records bind store,
epoch, document, FORMAT and base identity. Full valid retained WAL determines commits;
CURRENT must match a prefix, and published generations witness required WAL. The
[semantic contract](implementation/M2_MUTABLE_EPOCH_CONTRACT.md) defines admission-before-
writer/gate/generation order and recovery rejection rules. ADR-013 now implements internal codecs; no mutable open/commit API is added.



[ADR-013](ADR-013-epoch-profile-and-authority-codecs.md) implements ET1-ET3 in Storage:
EpochCodec.DecodeProfile recognizes exact tuples, RequireProfile gates capability and
legacy DecodeFormat stays immutable-only. EpochAuthorityCodec serializes six bounded
record roles against expected identity/FORMAT/base bindings with canonical names.
These are pure byte codecs: no persistence, tail cleanup, mutable admission or recovery
is enabled. Both frozen reader generations are pinned and probed in isolated subprocesses.
See [wire contract](implementation/M2_EPOCH_AUTHORITY_FORMAT_V1.md).



[ADR-014](ADR-014-admitted-empty-chain-epoch-coordinator.md) implements internal
EpochEmptyCoordinator for verified zero-head ScalarWal roots. Profile is explicit on
admission tokens/forks; public immutable defaults remain strict. Initialization validates
roles/data/empty state before writer creation, rechecks after ownership, then atomically
publishes/reuses a stable zero-reader BXER identity. BeginRead acquires child admission
before the gate and attaches both admission and base-reader handles to the snapshot.
EpochTransactionContext captures owner/epoch/base identity and lifetime only, no staging
or Commit. Strong adoption skips writable opens of the active admitted identity through
an explicit path; format-1 default adoption behavior is unchanged. No new wire bytes or
public mutable API is introduced. See [runtime contract](implementation/M2_EMPTY_EPOCH_COORDINATOR.md).

[ADR-015](ADR-015-internal-scalar-epoch-commit.md) adds internal EpochScalarCoordinator
and EpochScalarTransaction alongside the unchanged ET4 prototype. Transactions capture
the selected manifest rather than permanent BASE for stale validation. Staging reuses
scalar encoding under explicit admission and verifies exact metadata/value parity before
WAL publication. WAL precedes generation, stable reader identity and CURRENT publication.
Complete-history validation checks every role/hash/sequence/transition; a lagging pointer
may select the latest complete head, while missing redo materializations and corrupt tails
fail closed. Snapshots own independent epoch/generation handles. No public API or format
change is introduced. See [runtime contract](implementation/M2_EPOCH_SCALAR_COMMIT.md).

[ADR-016](ADR-016-internal-epoch-redo-and-publication-faults.md) extends internal Open with
EpochScalarRecovery. Preflight verifies all WAL and published witnesses before mutation,
including present materializations against the logical base/WAL projection. Missing
generations are deterministically rebuilt from verified predecessors and require exact
recorded manifest hashes before publication. Only a supported physically incomplete final
WAL without any publication witness may be removed through the storage seam and barrier.
After full validation, absent/lagging CURRENT is republished. Corrupt existing generations,
present invalid CURRENT and witnessed missing/torn WAL fail closed. BeginRead remains a
non-mutating verifier. See [runtime contract](implementation/M2_EPOCH_RECOVERY.md).

ET7 now qualifies these recovery rules with a paired adversarial state matrix and
multi-generation process interruptions. Invalid bindings/roles/chains/publications and
resealed logical mismatches reject without recovery writes or evidence changes, including
when an earlier generation is absent. Valid multi-step redo preserves exact bytes and old
reader lifetimes. No engine or binary/public API change is needed. See
[classification evidence](implementation/M2_EPOCH_CLASSIFICATION_VALIDATION.md).
ET8 now qualifies native fault delegation; ET9 backup/migration remains pending.

ET8 extends only the test adapter: explicit native durability delegates the exact requested
policy to LocalTransactionStorage while existing modeled tests retain ProcessCrash as their
underlying delegate. Shared sweep helpers assert the effective policy and run native Linux
commit/redo/tail faults. A real procfs fsync error propagates without fallback; Windows
rejects unsupported native policy before epoch mutation. The Linux runner now records
actual temporary-filesystem provenance. No storage-engine or binary/public API change is
needed. See [native qualification](implementation/M2_EPOCH_NATIVE_DURABILITY_VALIDATION.md).
ET9 backup/independent-restore design is now accepted per ADR-017; runtime work remains
separate from full-history migration and retirement.

[ADR-017](ADR-017-epoch-full-history-backup-and-independent-restore.md) defines ET9's design:
an epoch-specific sealed inventory/completion, full-history fixed-H capture under independent
admission and coordinator exclusion, complete-materialization and base-plus-WAL verification,
and independent restore with fresh StoreId/EpochId. Restore preserves document/node/transaction
IDs, H and data bytes while rebinding authority and WAL digest chains. Atomic publication
of a bundle containing store/ and an external origin.bin keeps provenance outside the
unchanged store profile/recovery authority. Applications use the returned store/ path.
[Semantic design](implementation/M2_EPOCH_BACKUP_DESIGN.md) and
[original candidate roles](implementation/M2_EPOCH_BACKUP_FORMAT_DESIGN.md) record design
provenance. ET9-A now implements internal pure codecs; runtime/public APIs remain pending.

ET9-A adds EpochBackupCodec and three internal metadata records with no file/ownership I/O.
Bounded parsers validate count/remaining-byte budgets before allocation; portable path,
identity/head and role/version checks apply on encoding and decoding. Pure completion,
source and origin header-context checks require matching expected digests/identities/profile/
CURRENT. They do not verify physical closure or grant admission. The
[metadata1.0 contract](implementation/M2_EPOCH_BACKUP_FORMAT_V1.md) is frozen with independent
Python-assembled vectors and [validation](implementation/M2_EPOCH_BACKUP_CODEC_VALIDATION.md).
ET9-B now implements internal capture and both data/history verification oracles.

ET9-B adds internal EpochScalarCoordinator.CreateBackup and EpochBackupStorage. An operation
admission child precedes the gate; writer/gate exclusion pins exact H through source closure,
private verification, sealing and publication. Unknown dependencies and missing/stale source
state fail without repair. Complete-data/no-repair and base-plus-full-WAL redo clones own
fresh private admission and must reproduce exact source bytes at every sequence. ReadArtifact
is read-only seal/closure/header validation; full logical proof still requires both oracles.
No sealed data is adopted, and only contained operation-owned clones/empty workspace are
cleaned. Source roots and snapshot identities remain intact. See
[capture contract](implementation/M2_EPOCH_BACKUP_CAPTURE.md) and
[validation](implementation/M2_EPOCH_BACKUP_CAPTURE_VALIDATION.md). ET9-C restore is now implemented.

ET9-C adds internal EpochBackupRestore. It verifies source closure/history, copies unchanged
XML data into a new bundle/store, generates fresh store/epoch IDs and rebuilds all FORMAT/
EPOCH/BASE/CONTROL, WAL predecessor digests, generation witnesses and CURRENT. An ephemeral
destination inventory drives both verification oracles; it is not published as another backup.
Fresh admission/readers0..H are initialized and staging handles close before one bundle rename.
External origin.bin binds initial source/destination commitments without changing store profile
or recovery authority. Repeated restores and branch writes are independent. See
[restore contract](implementation/M2_EPOCH_BACKUP_RESTORE.md) and
[validation](implementation/M2_EPOCH_BACKUP_RESTORE_VALIDATION.md). ET9-D fault qualification is now implemented; next: MG2 legacy verification.

*Last updated: 2026-10-30*


ET9-D qualification update (2026-10-27): capture/restore persistence sweeps now enumerate
every observed before/after call and actual partial-write position on a one-commit history.
Process-crash and modeled strong ordering are separate from actual native Linux delegation.
Repeated process interruption covers private publication windows, published outcomes and
acknowledgment loss. Source/backup bytes, historical reads, provenance and released handles
are checked. See [fault qualification](implementation/M2_EPOCH_BACKUP_FAULT_VALIDATION.md).
Full-history migration/cutover acceptance is now specified by ADR-018; runtime implementation remains pending. Public mutable APIs, source replacement and history reclamation remain disabled.


Migration/cutover design update (2026-10-27): [ADR-018](ADR-018-full-history-legacy-migration-and-cutover.md)
now specifies internal conversion of a sealed format-1 full-history backup into a fresh
ScalarWal 2.1 bundle. [Acceptance criteria](implementation/M2_EPOCH_MIGRATION_DESIGN.md)
require complete-history and full-redo verification on both sides, exact sequence/data
parity, separate migration provenance and explicit operator-controlled cutover. The
converter never opens the live legacy root. Source paths/history are retained; cutover
requires a write freeze and source/candidate freshness checks. No runtime migration,
routing API or retirement is implemented. MG1 codecs/fixtures are now implemented; next: MG2 legacy verification. The design-only step retained the 669-case runtime baseline; the MG1 update below records
fresh codec/regression coverage separately, without claiming runtime migration proof.


MG1 implementation update (2026-10-27): internal EpochMigrationCodec now encodes the
separate 350-byte BXEM 1.0 migration-origin role, frozen with independent H0/H2 vectors in
[the byte contract](implementation/M2_EPOCH_MIGRATION_FORMAT_V1.md). Pure
source/destination header checks preserve legacy H0 CURRENT omission and reject malformed
bounds and substituted commitments. They perform no I/O and grant no closure/history,
admission, migration or cutover capability. See [validation](implementation/M2_EPOCH_MIGRATION_CODEC_VALIDATION.md).
MG2 legacy verification is now implemented; next: MG3 conversion and verified bundle publication.
No runtime converter, routing API, source replacement or retirement is enabled.


MG2 implementation update (2026-10-27): internal [LegacyMigrationVerifier](implementation/M2_LEGACY_MIGRATION_VERIFICATION.md)
now validates sealed legacy closure, every scalar transition and exact fixed-H authority
before workspace writes, then verifies complete and independent full-WAL-redo clones.
Only private clones can initialize runtime files or republish byte-identical CURRENT;
sealed input and live source roots are not recovered or rewritten. No destination store
is published. [Validation](implementation/M2_LEGACY_MIGRATION_VERIFICATION_VALIDATION.md)
distinguishes 33 new cases/738 fresh filtered regressions per platform from retained ET9-D
evidence. MG3 internal conversion is implemented; next: MG4 exhaustive fault qualification.
Public migration/mutable APIs, cutover and retirement remain disabled.


MG3 implementation update (2026-10-27): internal [EpochLegacyMigration](implementation/M2_EPOCH_MIGRATION_CONVERSION.md)
now verifies sealed legacy full history through MG2, assigns fresh epoch identity and
re-encodes every authority/WAL link while preserving H, transaction/document/node IDs and
XML data bytes. Both destination history oracles and fresh runtime/provenance checks must
pass before atomic store/ plus migration.bin bundle publication; staging handles close first.
Source paths/artifact stay intact. [Validation](implementation/M2_EPOCH_MIGRATION_CONVERSION_VALIDATION.md)
records 27 new Storage and six process cases with 771 fresh filtered regressions per platform,
separately retaining the unchanged 18-case ET9-D matrix. MG4 observed fault/native/process qualification is now recorded. Public APIs, actual cutover and retirement stay disabled.


MG4 qualification update (2026-10-27): [conversion fault evidence](implementation/M2_EPOCH_MIGRATION_FAULT_VALIDATION.md)
now covers every observed H=1 persistence call before/after and actual partial writes,
with immutable input and valid/absent publication checks. Process probes repeat 12 windows
three times per supported policy, including private legacy copy/redo, epoch redo and ACK
loss, with actual native Linux delegation separate from modeled ordering. Production
algorithms and bytes are unchanged. Fresh regressions cover 798 cases per platform, with
18 unchanged ET9-D cases retained separately. Next: MG5 source/candidate freshness and
explicit cutover/rollback acceptance harness. Public APIs, routing service, source
replacement and all retirement remain disabled.


MG5 acceptance update (2026-10-27): [internal cutover harness](implementation/M2_MIGRATION_CUTOVER_ACCEPTANCE.md)
now freezes cooperating mutations, registers capture under that freeze, and revalidates
exact source/candidate commitments for session-bound single-use routing observations.
It models known/uncertain outcomes and verified no-work return versus reconciliation,
without changing any route/configuration or store path. [Validation](implementation/M2_MIGRATION_CUTOVER_ACCEPTANCE_VALIDATION.md)
records 32 Storage/two process cases and 823 fresh filtered regressions per platform, with
27 unchanged fault-matrix cases retained separately. MG1-MG5 are internal prototype gates;
next: compatibility/release-readiness evidence audit. Archived-reader gaps, public API/
shipping qualification and retirement remain open; all source data stays retained.


Compatibility audit (2026-10-28): [release-readiness evidence](implementation/M2_RELEASE_READINESS_AUDIT.md) verifies both frozen local reader families and records C1-C3 gaps. No shipping gate is closed. Next: CA1 rejection/nonmutation coverage for actual published migration bundles and every nested generation; archived release provenance remains unavailable locally.


CA1 update (2026-10-28): [real migrated-bundle compatibility validation](implementation/M2_MIGRATED_BUNDLE_COMPATIBILITY_VALIDATION.md) adds 12 local frozen/current rejection cases for H0/H3 wrapper, store and every generation, including exact file/directory and runtime identity preservation. Complete archived C1 and actual routing remain open. Next: CA2 migrated-candidate child/owner disposal races and cross-process lifetime checks.


CA2 update (2026-10-28): [migrated ownership validation](implementation/M2_MIGRATED_OWNERSHIP_VALIDATION.md) adds 12 repeated child/owner race cases and four cross-process holder-release cases. Local ownership proof is stronger; archived compatibility, actual routing and shipping remain open. Next: define supported public API and host cutover/restart contracts before implementing real routing.


API/host contract design (2026-10-28): [ADR-019](ADR-019-explicit-mutable-api-and-host-cutover-boundary.md) and the [contract](implementation/M2_PUBLIC_API_AND_HOST_CUTOVER_CONTRACT.md) separate explicit mutable access from host-owned writer exclusion, revision-checked routing and restart reconciliation. Proposed names are not public APIs; no host adapter or durable routing record is implemented. Next: HC1 pure restart/reconciliation classifier. Archived compatibility and release gates remain open.


HC1 update (2026-10-28): [pure restart classification](implementation/M2_RESTART_CLASSIFICATION_VALIDATION.md) adds internal supplied-observation decisions and 79 Storage cases. Every result keeps writers stopped, including new-workflow eligibility; no host observation, route change or durable receipt is created. Next: PA1 explicit mutable facade prototype and ownership/profile/diagnostic tests, remaining internal until release gates pass.


PA1 prototype update (2026-10-28): [internal mutable facade](implementation/M2_SCALAR_EPOCH_FACADE_VALIDATION.md) wraps explicit options, independent snapshots/transactions, scalar commits and fixed-head backup. An optional expected identity rejects before admission/recovery. 22 new internal consumer cases preserve diagnostics and uncertainty semantics; public exposure remains disabled. Next: PA2 separate administrative facade prototype and publication-outcome tests.


PA2 prototype update (2026-10-28): [separate administration facade](implementation/M2_SCALAR_EPOCH_ADMINISTRATION_VALIDATION.md) adds sealed legacy/epoch verification and independent restore/migration receipts. 29 new cases cover bound results, input preservation, strict proof and publication uncertainty. No public API or automatic routing/retry is enabled. Next: PA3 read-only publication inspection and reconciliation observations.


PA3 update (2026-10-28): [read-only publication inspection](implementation/M2_PUBLICATION_INSPECTION_VALIDATION.md) adds pinned-artifact and optional known-operation correlation, with reconciliation for changed/incomplete inputs and no adoption/recovery. 43 new cases preserve bytes/runtime identities; every observation keeps writers stopped. Next: consolidated cross-platform regression and API/readiness review. Public/host/archive/release gates remain open.


## RC3 Process and Contention Qualification (2026-10-28)

RC3 now qualifies preannounced IDs across publisher process death, independent plans racing
one destination and concurrent dispatch of one plan. See [validation](implementation/M2_ADMINISTRATIVE_ATTEMPT_PROCESS_VALIDATION.md).
The focused Windows/Linux runs cover 71 cases each, including 12 new RC3 cases; prior
full-suite evidence retains its dated scope. This supersedes earlier “next RC3” statements.
RC2/RC3 remain local; a3b578c contains work through RC1. No public API, host routing,
durable replay, source replacement or reclamation is enabled. Next HA1 defines the host
attempt-ledger and fencing contract; local inspection alone never authorizes retry.
