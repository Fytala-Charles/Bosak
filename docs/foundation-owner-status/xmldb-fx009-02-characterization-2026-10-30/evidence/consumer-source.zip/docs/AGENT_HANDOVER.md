# Bosak.XmlDb Agent Handover

## SR3-A Stopped Handoff Preparation Design (2026-10-30)

[ADR-036](ADR-036-stopped-handoff-preparation-and-lifetime.md) and
[contract](implementation/M2_STOPPED_HANDOFF_PREPARATION_CONTRACT.md) define private success-only
proof, actual preparation/plan/executor child drain and the actual paired parent session as
successor. Closing before claim refuses; claim-before-close retains original usable handles
through completion. No runtime or format change. Readiness checkpoint `069332c` is committed
and pushed; this design is local/uncommitted. Next SR3-B1 implements private proof and child
lifetime before SR3-B2 preparation/claim, SR3-C qualification and the separate SR4 writer.
Prior Windows 2,752 and focused Linux 394 cases remain retained evidence, not fresh execution.
Host/public/archive/durable-fence and all retirement gates remain open; CanReclaim=false.

## SR1/SR2 Stopped Restart Readiness Review (2026-10-30)

[Review](implementation/M2_STOPPED_RESTART_READINESS_REVIEW.md) verifies 64 retained
artifacts, 15 historical source inputs and complete Windows test-ID growth from 2,529 to 2,752.
All 223 additions appear in the latest 394-case focused Linux catalog; platform bodies/guards
remain distinct. Initial restore timeouts stay separate from passing project rechecks.
No runtime changes or fresh execution. Next SR3-A defines success-only proof consumption,
actual plan-child drain and successor/session binding before preparation code. Existing
observation/descriptor success grants no handoff or write authority. Host/public/archive and
all retirement gates remain open. Checkpoint `7da1b17` is committed/pushed; this review is local.

## SR2-C Native, Process and Disposal Qualification (2026-10-30)

[Validation](implementation/M2_OWNED_RESTART_QUALIFICATION_VALIDATION.md) adds 38 cases
without product source changes. Eleven native roles/roots are replaced with identical bytes
at two boundaries: 22 actual Linux executions, separately recorded as 22 Windows guards.
Ordered and repeated concurrent disposal, 14 process kills and 14 fresh observations and independent
holders/races preserve bytes/inventory and keep every result stopped. Final focused runs pass
189 Windows and 394 Linux cases.
All 2,752 Windows cases pass across complete project runs. The initial restore timeouts are
retained and pass focused plus complete Integration rechecks. Next consolidate SR1/SR2
readiness before SR3 handoff preparation. Host/public/archive/retirement gates remain open.
Checkpoint `de5c9a4` is committed/pushed; SR2-C qualification is local/uncommitted.

## SR2-B Paired Stopped Restart Observation (2026-10-30)

[Implementation and validation](implementation/M2_OWNED_RESTART_OBSERVATION_VALIDATION.md)
bind actual parent/authority/source retention through read-only complete source/sealed-capture
proof and fresh exact journal/native identity checks. All results stay stopped and inert;
no capture association, receipt, initializer or handoff capability is recreated. Nonterminal
administrative history forces reconciliation despite caller assertions. All 58 new cases and
282 focused Windows cases pass; 356 focused Linux cases pass, including all 58 new bodies.
All 2,714 Windows cases pass across complete project runs. The initial restore timeout is
retained and passes focused plus complete Integration rechecks. Next SR2-C native/process/race
qualification; SR3/SR4 and host/public/archive/retirement gates remain open. Checkpoint `a31203b`
is committed/pushed; SR2-B is local/uncommitted. Public and frozen formats remain unchanged.

## SR2-A Actual Restart Source Retention (2026-10-30)

[Implementation and validation](implementation/M2_RESTART_SOURCE_RETENTION_VALIDATION.md)
add a separate restart-only actual source child, permanent stopped admission and original
usable writer retention through real drain. No old capture association or initializer is
recreated. Native source inspection runs outside its gate; close uncertainty never retries or
clears the stop. All 38 new cases and 152 focused Windows cases pass; 268 focused Linux cases
also pass, including all 38 new bodies. All 2,656 Windows cases pass across complete project runs. The initial restore timeout is
retained and passes focused plus complete Integration rechecks.
This source-only slice does not implement paired restart observation. Next SR2-B full actual
parent/authority/source-bound proof and freshness; SR2-C/SR3/SR4 and host/public/archive/retirement
gates remain open. Checkpoint `bc5e490` is committed/pushed; SR2-A is local/uncommitted.

## SR2 Actual Ownership Integration Design (2026-10-30)

[ADR-035](ADR-035-owned-stopped-restart-observation.md),
[design](implementation/M2_OWNED_RESTART_OBSERVATION_DESIGN.md) and
[review](implementation/M2_OWNED_RESTART_OBSERVATION_REVIEW.md) specify a separate
restart-only retained source child and paired stopped observation. Existing freeze/capture
association and initializer checks remain strict. Verification must not hide live recovery
writes or confuse the inventory commitment with the manifest hash. Design only; no runtime
change. Next SR2-A source lifetime primitive, then SR2-B/C observation and qualification;
SR3/SR4 and all host/public/archive/retirement gates remain open.
Checkpoint `b0c94bd` is committed/pushed. SR2 design is local/uncommitted; prior 2,618 Windows
passing cases across complete project runs and 451 focused Linux cases are retained evidence,
not new execution. All source/candidate/WAL histories remain retained, CanReclaim=false.

## SR1 Pure Stopped Enrollment Assessment (2026-10-30)

[Implementation and validation](implementation/M2_ENROLLMENT_RESTART_CLASSIFIER_VALIDATION.md)
add an internal pure classifier of supplied exact-head, source/capture and stopped-host facts.
Every result remains stopped and inert. Empty/unsupported/missing observations require
reconciliation; invalid history or contradictory facts refuse. No receipt, initializer, live
ownership, handoff plan or execution permission is recreated. All 89 new cases and 335 focused
Windows cases pass; 451 focused Linux cases also pass, including all 89 new bodies.
All 2,618 Windows cases pass across complete project runs. The initial restore timeout is
retained and passes focused plus complete Integration rechecks. Public/frozen formats and
actual source/authority lifetimes remain unchanged. Next SR2 actual owner-bound stopped
evidence; SR3/SR4 capability/output and host/public/archive/retirement gates remain open.
Checkpoint `100b39d` is committed/pushed; SR1 is local/uncommitted.

## ER-004 Stopped Restart and Owner Handoff Design (2026-10-30)

[ADR-034](ADR-034-stopped-enrollment-restart-and-owner-handoff.md) and the
[contract](implementation/M2_STOPPED_ENROLLMENT_RESTART_CONTRACT.md) define inert stopped
assessment, fresh actual ownership/exclusion and a separately gated future TransferOwner.
[Review](implementation/M2_STOPPED_ENROLLMENT_RESTART_REVIEW.md) records design checks;
no runtime, public API or frozen format changes. Valid Enroll bytes never recreate a receipt
or initializer. Empty/unsupported/uncertain restarts require reconciliation; corruption rejects
without repair. All histories remain retained. Next SR1 implements only the pure stopped
classifier; SR2-SR4 actual evidence, capability and output qualification remain unimplemented.
ER-003 checkpoint `edf0b72` is committed/pushed. Its 2,529 Windows passing cases across complete
project runs and 740 focused Linux cases remain prior execution evidence, with initial
Integration timeouts preserved separately. This design adds no runtime test cases.
Current local/uncommitted work: ER-004 documentation and evidence only. HEAD/origin/main are
`edf0b72`; next SR1 pure classifier. Dated earlier sections retain historical checkpoint states.

## ER-003 Authority and Parent Release Qualification (2026-10-30)

[Contract](implementation/M2_ENROLLMENT_ROLE_RELEASE.md) and
[validation](implementation/M2_ENROLLMENT_ROLE_RELEASE_VALIDATION.md) add an actual-owner,
internal close seam and 42 direct role-close cases. Before/after/no-op errors suppress required
cleanup acknowledgment, preserve bytes and keep release uncertainty separate from physical
handle availability. All 2,529 Windows cases qualify across complete project runs and 740 broad
Linux cases pass, including all 42 new bodies per platform. Two initial restore timeouts are
retained and pass focused plus complete Integration rechecks. Production null/default close delegation and public/frozen contracts remain
unchanged. Next ER-004 defines stopped restart/enrollment reconciliation and owner handoff;
no further writer, work/routing admission, source replacement or reclamation is enabled.
Historical sections below retain their dated scope.

Checkpoint `1fc13c4` is committed and pushed to `origin/main`. ER-003 is local/uncommitted. Next ER-004 stopped restart/enrollment and owner-handoff contract. Docker remains running.

## ER-002 Retained Preflight Boundary (2026-10-30)

[Implementation](implementation/M2_RETAINED_ENROLLMENT_PREFLIGHT.md) and
[validation](implementation/M2_RETAINED_ENROLLMENT_PREFLIGHT_VALIDATION.md) move retained
protected-path inspection outside authority serialization. Actual source/parent/authority
ownership spans the unlocked phases; exact roles/metadata/empty head are checked again after
the last placement pass. All 2,487 Windows cases pass across complete project runs; 698 broad
Linux cases pass, including all 19 new bodies per platform. Two initial restore timeouts are
retained and pass focused plus complete Integration rechecks. Generic readers and frozen/public
contracts remain unchanged. Next ER-003 qualifies direct authority/parent close errors;
ER-004 and all host/public/archive/retirement gates remain open. Historical sections below
retain their dated scope.

Checkpoint `4283316` is committed and pushed to `origin/main`. ER-002 is local/uncommitted. Next ER-003 release-fault qualification, then ER-004 restart/owner-handoff design. Docker remains running.

## EF1-EF4 Consolidated Readiness Review (2026-10-30)

[Review](implementation/M2_ENROLLMENT_READINESS_REVIEW.md) verifies 51 retained TRX
artifacts, 256 unchanged source/build/fixture inputs and all 2,468 Windows test IDs; 679 Linux
focused IDs are retained separately. Fresh public metadata remains 95/95, with no additions.
No runtime suite or feature is added by the review. ER-002 identifies protected-ancestor I/O
under the shared authority monitor during retained preflight; next harden that boundary under
ADR-033. Direct authority/parent close-fault qualification and stopped restart/owner handoff
remain later gaps. No public API, application admission, routing or reclamation is enabled.
Historical sections below retain their dated scope.

Checkpoint `b7b6215` is committed and pushed to `origin/main`. This review is local/uncommitted. Next address ER-002 preflight serialization, then ER-003 close-fault qualification. Docker remains running.

## EF4 Enrollment Fault and Process Qualification (2026-10-30)

[Qualification](implementation/M2_FIRST_ENROLLMENT_FAULT_VALIDATION.md) adds observed
call-edge/all-prefix fault sweeps, actual Linux inode substitutions, cross-thread I/O closing,
repeated process/ACK-loss boundaries and independent competing publishers. The 387-byte frame
produces 393 sweep attempts; 34 new catalog cases include eight Windows host guards. Each
focused process run uses 48 workers. Production runtime/format/public surface is unchanged.
All 2,468 Windows and 679 isolated Linux focused cases pass; eight new Windows rows are
explicit host guards. Formatting/docs/portability and frozen fixture checks pass. Next consolidate
EF1-EF4 readiness and remaining host/restart contracts before another authority writer.
No application admission, actual routing or reclamation is enabled. Historical sections below
retain their dated scope.

Checkpoint `bec0eee` is committed and pushed to `origin/main`. EF4 qualification is subsequent local/uncommitted work. Docker remains running.

## EF3 Conditional First Enrollment (2026-10-30)

[Implemented contract](implementation/M2_FIRST_ENROLLMENT_APPEND.md) and
[validation](implementation/M2_FIRST_ENROLLMENT_APPEND_VALIDATION.md) add one terminal
stopped Enroll append from the actual retained preparation. Exact empty-head/native-role checks,
flush/readback/full-history validation and cleanup confirmation precede acknowledgment.
Possible output or release uncertainty retains bytes and prevents receipt synthesis/retry.
All 2,434 Windows and 645 isolated Linux focused cases pass, including all 45 new cases per
platform. Formatting/docs/portability and frozen fixture checks pass. No application work admission or public API is enabled. Next EF4 qualifies observed
persistence positions, process interruption/ACK loss and competing owners. Real host/archive/
retirement gates remain open. Historical sections below retain their dated scope.

Checkpoint `ec1dead` is committed and pushed to `origin/main`. EF3 is subsequent local/uncommitted work. Docker remains running.

## EF2 Retained Enrollment Admission (2026-10-29)

[Implemented contract](implementation/M2_RETAINED_ENROLLMENT_ADMISSION.md) adds a
separate owner-bound retained preparation, resource transfer to actual execution and a
nonblocking authority/parent/source arm decision. Wrapper disposal retains all three original
owners through actual execution; unknown source close retains authority/parent operations.
All 2,389 Windows and 600 isolated Linux focused cases pass, including 29 new cases per
platform. Formatting/docs/portability and frozen fixture checks pass. No authority output or application admission is enabled. Next EF3 implements the
conditional first Enroll frame; EF4 persistence qualification and real host/public/archive/
retirement gates remain open. Historical sections below retain their dated scope.

Checkpoint `d644db5` is committed and pushed to `origin/main`. EF2 is subsequent local/uncommitted work. Docker remains running.

## EF1 Retained Source Lifetime (2026-10-29)

[Implemented contract](implementation/M2_ENROLLMENT_SOURCE_RETENTION.md) and
[validation](implementation/M2_ENROLLMENT_SOURCE_RETENTION_VALIDATION.md)
add opt-in source/freeze children, deferred original writer-stream close and a source-owner
stop latch. Native identity, actual drain and release uncertainty remain explicit. All 2,360
Windows tests and 571 isolated Linux focused cases pass, including 29 new cases per platform.
Formatting/docs/portability and frozen fixture checks pass. No authority output or application admission is enabled. Next EF2 integrates a
separate retained preparation and atomic dispatch admission, still without authority writes.
Historical design/qualification blocks below retain their dated scope.

Checkpoint `5237ee3` is committed and pushed to `origin/main`. EF1 is subsequent
local/uncommitted work. Docker remains running; ordinary borrowed preparation is unchanged.

## Retained Source Exclusion and First-Enrollment Design (2026-10-29)

[ADR-033](ADR-033-retained-source-exclusion-and-first-enrollment.md) and
[contract](implementation/M2_APPLICATION_AUTHORITY_ENROLLMENT_APPEND_DESIGN.md)
specify opt-in source/freeze retention, one atomic arm decision, a stopped original-source
latch and exact one-frame conditional append with terminal uncertainty. This is design only;
current preparation remains read-only. The [review](implementation/M2_APPLICATION_AUTHORITY_ENROLLMENT_APPEND_DESIGN_REVIEW.md)
records 24 future acceptance scenarios, not test passes. Runtime/build inputs remain at the
qualified 2,331-case Windows / 542-case focused Linux baseline. Next EF1 implements source
retention/deferred close/stop-latch qualification with no authority writes. EF2-EF4, actual
host control, public APIs, archived compatibility and all reclamation remain open.

HEAD `3f722da` is already pushed. Prior read-only preparation and this design remain
local/uncommitted. No runtime or build input changes in this design step.

## Owner-Bound First-Enrollment Preparation (2026-10-29)

[ADR-032](ADR-032-owner-bound-first-enrollment-preparation.md) and
[validation](implementation/M2_APPLICATION_AUTHORITY_ENROLLMENT_VALIDATION.md)
add read-only preparation against a real frozen legacy store and its registered sealed
capture, actual source owner identity and scoped reconciliation assertions. The actual
owner-bound preparation is single-use and retains authority/admin leases. All 2,331 Windows
cases pass across full project runs; 542 isolated Linux cases pass, including all 35 new cases
per platform. One existing Windows kill case failed once and passed focused/complete reruns;
the validation report retains the observation. Operational
assertions remain supplied assumptions; no enrollment/append or application work is enabled.
Next design conditional first-enrollment save/uncertainty with continuing real ownership and
fresh explicit operational evidence. Historical next-action blocks retain their dated scope.

Provisioning checkpoint `3f722da` is committed and pushed to `origin/main`. This
enrollment preparation is subsequent local work; Docker remains running.

## EP7-C Explicit Authority Provisioning Slice (2026-10-29)

[ADR-031](ADR-031-application-authority-provisioning-and-initializer.md) and
[provisioning validation](implementation/M2_APPLICATION_AUTHORITY_PROVISIONING_VALIDATION.md)
add separate no-overwrite absent-root creation, direct exclusive-owner handoff, retained
partial state and a single-use live initializer reservation that holds actual paired leases.
All 2,296 Windows cases pass across full project runs; 475 focused Linux cases pass, including
46 new cases per platform. One existing Windows release case failed once and passed focused
and complete reruns; the validation report retains that observation.
All writers stay stopped. No enrollment/append or real application baseline is established.
Actual process interruption, acknowledgment loss and independent creators are now qualified.
Next bind a real operational baseline to owner-bound first-enrollment preparation before
conditional append. Historical next-action sections below retain their dated scope.

Checkpoint `21a33af` was committed and pushed to `origin/main`. This provisioning slice
is subsequent local work. Docker remains running for isolated Linux qualification.

## EP7-C Paired Existing-Root Authority Inspection (2026-10-29)

[ADR-030](ADR-030-paired-read-only-application-authority-ownership.md) and
[lifetime validation](implementation/M2_APPLICATION_AUTHORITY_LIFETIME_VALIDATION.md)
add opaque parent-mode exclusion, real authority ownership/native identity checks, read-only
full-history inspection and actual-read drain. All 429 focused Windows cases pass, including
71 new cases (three Windows FIFO guards). Full Windows passes all 2,250 tests; fresh isolated
Linux passes 429 focused cases with actual FIFO bodies. Formatting/docs/portability and fixture
checks pass; exact scope and XML-only final test documentation are recorded in the report. Next explicit no-overwrite provisioning/initializer
qualification before append; no authority writes, routing or application admission is added.

HEAD remains `4598346`; audit/design/earlier prototypes and this lifetime step remain
uncommitted. Read this section before historical next-action notes. Native Windows checks
are actual x64 NTFS evidence; fresh Linux x64/overlayfs identity/process/FIFO bodies also pass.
Docker was started detached with its cached pinned image and remains running. ARM64, other
filesystems and a new full Linux suite remain unqualified. Existing frozen formats/fixtures/public APIs and all histories are preserved.

## Application-Authority Pure Codec (2026-10-29)

[Codec validation](implementation/M2_APPLICATION_AUTHORITY_CODEC_VALIDATION.md) records
strict metadata/frame/TLV decoding and complete-history transitions with retained work obligations.
Four independent frame/history vectors and 166 focused cases pass. Successful Windows project
runs cover all 2,179 tests after a full Integration rerun cleared two initial timeouts. The
report retains those failures and the Docker-blocked Linux result; docs/formatting/portability pass. All decoded results stay stopped;
existing formats/public APIs remain unchanged. Next EP7-C starts with the new owner-bound
application child lifetime/existing-root boundary before provisioning and persistence.

HEAD remains `4598346`; earlier audit/design/EP7-A/specification and this codec are local
and uncommitted. Fresh Linux execution is Docker-blocked. This section supersedes historical
next-action wording; no authority writer, application execution or automatic resume is added.

## EP7-B Application-Authority Format Specification (2026-10-29)

[ADR-029](ADR-029-separate-application-authority-journal-v1.md) and the
[v1 contract](implementation/M2_APPLICATION_AUTHORITY_FORMAT_V1.md) specify separate
metadata/frames, retained work transitions, no-overwrite provisioning and uncertain-save rules.
[Validation](implementation/M2_APPLICATION_AUTHORITY_FORMAT_VALIDATION.md) records two
independent metadata-only vectors and 13 passing Python checks. No production codec or
persistence is implemented. Existing C# remains at the passing 2,013-test Windows baseline.
Next implement the pure codec/full-history validator with independent frame/history vectors
before EP7-C owned persistence. Existing host/store bytes and all histories remain protected.

HEAD remains `4598346`; prior audit/design/EP7-A and this specification are uncommitted.
No new full .NET/Linux run is claimed for this specification-only step. Follow this section
before historical next-action notes. No actual routing or automatic writer resume is enabled.

## EP7-A Pure Pilot Authority Classification (2026-10-29)

[Classification validation](implementation/M2_EMBEDDED_PILOT_AUTHORITY_CLASSIFICATION_VALIDATION.md)
records the internal supplied-evidence model: exact authority/root/baseline/publication bindings,
nullable branch accounting, retained acceptance obligations and stopped-only outcomes.
All 119 focused Windows cases pass; the fresh full Windows regression passes 2,013 tests.
Formatting, strict docs and portability pass; Linux execution remains Docker-blocked. Next EP7-B specifies separate application-authority bytes/transitions
and provisioning/commit rules. No authority persistence, routing, work execution or public API
is implemented; existing host/store formats and all histories remain protected.

HEAD remains `4598346`; audit, design and EP7-A changes are local/uncommitted. This section
supersedes historical next-action wording. Linux fresh execution remains Docker-blocked.

## Internal Embedded Pilot Authority Design (2026-10-29)

The user selected the internal embedded pilot. [ADR-028](ADR-028-embedded-pilot-selection-and-work-authority.md)
and its [authority contract](implementation/M2_EMBEDDED_PILOT_AUTHORITY_CONTRACT.md) define
separate selected-root/work accounting with acceptance before mutation, retained obligations
and stopped restart. This is design only; existing journal/store bytes and public APIs stay
unchanged. Next EP7-A is a pure supplied-evidence classifier with no I/O or write authority;
format, persistence and actual consuming-host execution remain later gates. The preceding
1,894-test Windows regression covers unchanged runtime, not this proposed backend.

Reviewed HEAD: `4598346`. Audit and design remain uncommitted; no commit/push performed.
Fresh Linux remains blocked by the unavailable Docker engine. Read this section before
historical next-action notes. No application writes or automatic restart resume are enabled.

## Post-EP6-D Readiness Review (2026-10-29)

The [current audit](implementation/M2_POST_EP6_READINESS_REVIEW.md) reviews checkpoint `4598346` and confirms that the next gate is
a consuming-host selected-root/work-authority contract. Administrative operation drain and
publication reconciliation do not establish application selection or accepted-work accounting.
Fresh Windows full regression passes all 1,894 tests; Linux execution is blocked by the
unavailable Docker engine. Formatting, strict documentation and portability pass. Historical
RC/EP reports retain their original scope; no runtime/API/format or release gate changes here.

Reviewed HEAD: `4598346`; this review is uncommitted. No commit or push was performed.

## Host Restart Checkpoint (2026-10-29)

EP6-C is pushed as `5977451`; this checkpoint includes the completed EP6-D process tests and
documentation. All 1,055 focused cases passed per Windows/Linux platform (732 Storage,
323 Integration), including 72 new process cases. Formatting and strict documentation/portability
checks passed. No production source, public API, package pin or wire format changed in EP6-D.
Hosted run `40822530134` was blocked before runner execution by account payment/spending limits.

The [XDM 4.0 assessment](implementation/M2_XDM40_COMPATIBILITY_ASSESSMENT.md)
records existing Bosak foundations and proposed provider qualification (REQ-009). It does not
claim full current-draft conformance or introduce persistent JSON/general XDM storage.

After restart, inspect `git status --short` and `git log -1`, then read this handover and
[EP6-D evidence](implementation/M2_EMBEDDED_HOST_RESTART_PROCESS_VALIDATION.md).
Next: audit consuming-host selected-root authority and accepted-work accounting before adding
application integration. Reopened stores/host journals stay stopped; no automatic retry, route
change, writer resumption or reclamation is authorized by these tests. Proprietary licensing,
Bosak 1.26.2 pins and disabled packaging remain fixed. Earlier sections are historical step
records; this checkpoint supersedes their delivery status and next-action wording.

## EP6-D Restart/Retry Process Qualification (2026-10-29)

EP6-C is pushed as `5977451`. [EP6-D validation](implementation/M2_EMBEDDED_HOST_RESTART_PROCESS_VALIDATION.md)
adds 72 actual process-kill cases across both roles at H=1, covering transfer, known/absent
outcomes, fresh retry intent and execution acknowledgment gaps. Reopen remains stopped;
separate reconciliation retains data and never recreates execution tickets. All 1,055 focused
cases pass per Windows/Linux platform. EP6-D is included in this restart checkpoint. Next audit the consuming application's selected-root/work-accounting gate;
production routing, writer resumption, public release and physical durability remain open.

## EP6-C Explicit Fresh-Plan Retry (2026-10-29)

EP6-A/B is pushed as `8d38762`. [EP6-C validation](implementation/M2_EMBEDDED_HOST_RETRY_VALIDATION.md)
adds explicit retry preparation with a fresh real plan/attempt ID after exact qualified absence.
It retains request/pin/destination, reinspects before recording and uses an exact-position save
to exclude duplicate retry intents across fronts. 22 new cases cover success, changed facts,
concurrency and lost intent acknowledgment. All 983 focused cases pass per Windows/Linux platform.
EP6-C remains local/uncommitted. Next qualify
process termination across the combined restart/retry workflow; automatic retry/writer resume
and application routing remain disabled.

## EP6-B Stopped Restart Inspection (2026-10-29)

[EP6-B validation](implementation/M2_EMBEDDED_HOST_RESTART_INSPECTION_VALIDATION.md)
adds actual pinned-operation inspection with acknowledged owner transfer and separate known
observation/qualified absence saves. Admissions stay closed; saved receipts cannot be synthesized
or replaced from inspection. 26 new Integration cases cover both roles/heads, contradictory
terminal facts and uncertain saves. All 961 focused cases pass on Windows and Linux.
Next: explicit fresh-plan retry after qualified absence;
retry runtime and process-kill qualification remain pending. EP6-A/B remain local/uncommitted.

## EP6-A Stopped Append Boundary (2026-10-29)

The EP6 contract is pushed as `22eeddf`. [EP6-A validation](implementation/M2_EMBEDDED_HOST_STOPPED_APPEND_VALIDATION.md)
adds exclusive stopped-session registration and restricted transfer/observation/absence saves,
without opening administrative admissions. 25 new cases cover evidence, stale/foreign tokens,
concurrency, uncertainty and shutdown drain. All 935 focused cases pass on Windows and Linux.
Inspector composition, explicit fresh-plan retry
and process-kill qualification remain pending. EP6-A changes are local/uncommitted.

## EP6 Stopped Restart Design (2026-10-29)

EP4/EP5 is committed and pushed as `24feda2`. The [EP6 contract](implementation/M2_EMBEDDED_HOST_RESTART_CONTRACT.md)
specifies a restricted reconciliation session with admissions closed, exact owner transfer,
separate known-operation observations and qualified absence before an explicit fresh-plan retry.
This is design only; restart persistence and retry runtime remain pending. Next implement the
stopped lifetime registration/append path and qualify its uncertainty and concurrency boundaries.
Existing 910 focused tests per platform remain the baseline; no new runtime coverage is claimed.
Hosted run `40793748444` could not start runner steps due to GitHub payment/spending limits.

## EP5 Live Plan-Bound Orchestration (2026-10-28)

[ADR-026](ADR-026-live-plan-bound-embedded-orchestration.md) and
[validation](implementation/M2_EMBEDDED_HOST_ORCHESTRATION_VALIDATION.md) add
opaque live tickets, exact acknowledged intent/authorization and one registered executor per
host. Actual receipts and host acknowledgments/errors remain separate; no saved plan is
reconstructed. 56 new cases qualify process gaps, duplicate use, active-attempt mutation and
shutdown; 910 focused cases pass per platform. Public metadata/wire formats stay unchanged.
Next: stopped persisted restart reconciliation and explicit new-ID retry after qualified
absence. HA2 application, global fencing, release and physical durability gates remain open.
EP4/EP5 was subsequently committed/pushed as `24feda2`; hosted CI remains billing-blocked.

## EP4 Owned Conditional Append (2026-10-28)

Pushed-baseline CI run 40771851255 did not start build/tests because GitHub account payment/
spending limits blocked both jobs. Local EP4 validation is separate; account-owner action is
needed for hosted runners. No billing/settings change or automatic rerun was made.

EP2/EP3 is committed/pushed as `4642b09`. [ADR-025](ADR-025-owned-conditional-host-journal-append.md)
and [append validation](implementation/M2_EMBEDDED_HOST_APPEND_VALIDATION.md)
now qualify exact-head append, actual file flush/readback and permanently faulted uncertain
sessions. 47 new cases cover write/flush failures, process interruption and test-only planned
publication composition; focused runs pass 854 cases per platform. Public Storage metadata
and wire formats stay unchanged. Reopened history remains stopped and never recreates a plan.
Next EP5 binds acknowledged ledger transitions to one registered live executor in an internal
orchestrator. HA2 application, release and physical durability gates remain open. EP4 is local.

## EP3 Explicit No-Overwrite Provisioning (2026-10-28)

[ADR-024](ADR-024-explicit-no-overwrite-host-provisioning.md) and
[validation](implementation/M2_EMBEDDED_HOST_PROVISIONING_VALIDATION.md) qualify
controlled absent-root creation, continuous CreateNew owner handoff and retained interrupted
state. 60 new tests cover partial writes, checkpoint/process kills and synchronized contenders;
807 focused cases pass per platform. Existing roots are never adopted or repaired by provision.
Reopened empty roots remain stopped; the live initializer diagnostic is not durable authority.
Next EP4 implements bounded conditional journal append and unknown-flush fault handling.
Physical durability, hostile namespace/global fencing, HA2 and release gates remain open.
Changes remain local/uncommitted; pushed baseline `2141eac` is unchanged.

## EP3 Existing Host Lifetime Ownership (2026-10-28)

[Ownership validation](implementation/M2_EMBEDDED_HOST_OWNERSHIP_VALIDATION.md)
adds existing-root cooperative exclusion, stopped administrative admissions and token-drained
shutdown. 50 new catalog cases cover process exit/active drain, aliases, invalid roots and
real publisher lifetimes. Focused runs pass 747 cases per platform; three FIFO rows execute
only on Linux. Public Storage metadata remains unchanged. No host files are provisioned,
repaired or appended by this implementation, and no global fence or writer resume is implied.
Next: explicit no-overwrite provisioning and interruption/contender tests before EP4 append.
EP2/EP3 work remains local/uncommitted; the pushed baseline remains `2141eac`.

## EP2 Internal Journal Codec (2026-10-28)

[Codec validation](implementation/M2_HOST_JOURNAL_CODEC_VALIDATION.md) now covers
strict bounded metadata/frame/TLV encoding, complete history checks and four independently
authored host-only vectors. 117 new codec cases pass; focused Windows/Linux runs pass 697
cases each. All 168 prior runtime/test/fixture files and public Storage metadata are unchanged.
Decoded history always keeps writers stopped; no codec output grants execution or proves
flush, anti-rollback or fencing. Next EP3 qualifies stable host-root lifetime ownership with
explicit provisioning boundaries and real process tests. EP4 durable append, HA2 application
integration and release gates remain open. EP2 design/codec changes remain local/uncommitted.

## Current Delivery and EP2 Journal Contract (2026-10-28)

The embedded profile is committed/pushed as `2141eac`. [ADR-023](ADR-023-bounded-embedded-host-journal-contract.md)
and the [journal contract](implementation/M2_EMBEDDED_HOST_JOURNAL_CONTRACT.md)
now define bounded canonical host-only frames, conditional transitions and explicit append/flush
uncertainty. Damaged tails are retained and block appends; restart never replays a plan.
No codec/writer, anti-rollback authority or durable-host proof is implemented. Next: a pure
internal codec with independent byte vectors, before filesystem persistence. This contract
is local/uncommitted; earlier delivery notes below retain their original scope.

## Current Delivery and Embedded Pilot Selection (2026-10-28)

RC2 through test-only HA1 integration is committed/pushed as `5d23ba2` on `origin/main`.
The user selected single-process embedded integration first. [ADR-022](ADR-022-single-process-embedded-pilot-host.md)
and the [pilot profile](implementation/M2_EMBEDDED_HOST_PROFILE.md) define one
controlled process, a dedicated host-state root, lifetime ownership and stopped restart
reconciliation. A local file journal is proposed; no backend or host is implemented yet.
Next EP2 defines its bounded codec, commit and corruption/rollback contract. M4 server,
HA2 application routing/work, public/archived-reader/release and retirement gates stay open.
This post-push profile is local; older uncommitted statements below describe their original
milestones. No runtime/test/fixture source changes or new runtime runs occur in this step.

## HA1 Ledger and Planned Execution Tests (2026-10-28)

[Test-only integration](implementation/M2_HOST_LEDGER_PLANNED_EXECUTION_VALIDATION.md)
now connects memory-ledger intent/authorization/receipt transitions to real owner-bound
migration and restore. 34 new cases cover lost-save acknowledgments, actual publication
uncertainty, new-ID retry after reconciled absence, concurrent authorizers and an active
publisher that defeats absence-based retry. Focused runs pass 448 cases per platform.
All prior runtime/test/fixture files are unchanged; no production adapter is introduced.
The bounded model/library integration is complete. Next: identify the actual consuming host,
durable backend, effective publisher exclusion and route/work authorities before HA2.
No memory commit proves durability or fencing. Changes remain local and uncommitted.

## HA1 Conditional Transition Harness (2026-10-28)

The internal [in-memory transition harness](implementation/M2_HOST_LEDGER_TRANSITION_VALIDATION.md)
now models exact-revision commits, single dispatch authorization, explicit read reconciliation
of lost acknowledgments and supplied-exclusion ownership transfer. 83 new tests cover commit
boundaries, concurrent winners, stale owners and preservation of receipts/observations;
414 focused cases pass per platform. Public Storage metadata remains unchanged.
No durable backend, executable permit, effective fence, routing or writer resume is supplied.
Next: test-only integration of these transitions with actual planned execution and lost-save
acknowledgments. Actual host selection and HA2 remain open; changes are uncommitted.

## HA1 Internal Ledger Model (2026-10-28)

The [ledger decision model](implementation/M2_HOST_ATTEMPT_LEDGER_MODEL_VALIDATION.md)
now checks supplied request/attempt/revision/owner bindings, durable-intent assumptions,
publication/receipt identity and prior-executor exclusion. All 180 new model tests pass;
focused validation covers 331 cases per platform, retaining earlier full-suite evidence at
its original scope. Every output keeps writers stopped and grants no executable authority.
Actual host selection, persistence and HA2 integration remain open. Next: an internal
conditional-transition harness for revision/CAS and lost-acknowledgment protocol tests.
Changes remain local and uncommitted; proprietary licensing and release gates are unchanged.

## HA1 Host Ledger Contract (2026-10-28)

[ADR-021](ADR-021-host-attempt-ledger-and-publisher-exclusion.md) and the
[host ledger contract](implementation/M2_HOST_ATTEMPT_LEDGER_CONTRACT.md) define
durable intent before dispatch, revision-checked ownership, separate acknowledgment and
observation records, and prior-executor exclusion before any fresh attempt. A ledger lease
cannot fence the current publication path; an old publisher must be stopped or effectively
excluded before takeover/retry. The 24 design scenarios are requirements, not runtime tests.
Actual host selection and HA2 integration remain open. Next: an internal pure supplied-evidence
ledger decision model and adversarial tests. No persistent backend, routing, public API or
writer resume is enabled. RC2/RC3 and this contract remain local and uncommitted.

Earlier milestone notes below retain their dated scope; the HA1 next step above is current.

## 1. Session State

2026-10-28: RC2 explicit planned execution implemented after requested commit/push. Workspace
D:/Development/Bosal.XmlDb; product Bosak.XmlDb. Commit a3b578c pushes validated work through RC1 to private Fytala-Charles/Bosak.XmlDb.
RC2 is subsequent local uncommitted work. No release, deployment or upstream change. Proprietary license,
Bosak 1.26.2 pins, disabled packaging and all frozen binary formats/fixtures remain fixed.

## 2. What Changed

ExecuteAttempt claims the original owner/policy-bound plan before filesystem I/O. A private
one-entry execution context binds role/absolute roots/policy and cannot be recreated from
descriptive data or replayed. Both pipelines accept optional internal context, check original
inventory SHA/source selection before verification output and after source-proof callbacks,
then use the preknown ID in the existing MigrationId/RestoreId field. Legacy verifier also
checks the optional pin before its private output. Default unplanned behavior remains fixed.

No public API, provenance layout/version change, durable plan/descriptor codec, automatic
retry/routing or source replacement. Plan state stays Dispatched on success or failure;
normal receipt versus exception conveys acknowledgment. Post-rename/cleanup errors can
leave a valid known candidate with no receipt. PA3 observes it without synthesizing success.
See docs/implementation/M2_ADMINISTRATIVE_ATTEMPT_EXECUTION_VALIDATION.md and result JSON.

## 3. Validation

Latest RC2 focused runs pass 449 cases/platform (255 Storage, 194 Integration), including
31 new execution cases plus prior proof/facade/plan/observation/restart/compatibility tests.
Catalog 1,110 is not a new full run. Native planned execution runs on Linux; Windows
asserts unsupported policy. Frozen four DLLs and 15 metadata vectors remain unchanged.

Latest RC1 focused runs pass 287 cases/platform (124 Storage, 163 Integration), including
28 new plan cases. Eight synchronized workers per role produce one claim/seven rejections.
The link branch executes on Linux, not Windows. Catalog 1,079 is not a new full run; prior
consolidated evidence below retains its original scope. Four DLLs/15 metadata vectors fixed.

Unfiltered source-baseline runs passed all 1,050 cases per platform: 753 Storage, 270
Integration, 27 Xdm, including all 27 expensive ET9-D/MG4 matrix rows freshly. Final HC1
hardening batches pass 80 cases per platform and replace the previous 79 classifier rows.
Aggregate unique coverage is 1,051 (754/270/27), not one unfiltered 1,051-case run. Runtime
source fingerprints show only the classifier and its test changed after baseline capture.
Windows final tests used an isolated identical-source build to preserve active full-run
assemblies; the default workspace was subsequently rebuilt successfully with zero warnings.

Matrix output separates ProcessCrash, modeled strong and actual Linux native positions;
Windows native early returns are not execution. Full per-case traces and process repetitions
are in results JSON. Four frozen DLL hashes and 15 metadata fixture hashes remain verified.
Windows and actual Linux PowerShell hygiene/hidden/link checks and Git LF checkout simulation
pass; formatting passes. SDK 10.0.301, Windows runtime 10.0.11, Linux 10.0.9 on WSL2/overlayfs.
These are local process/fault boundaries, not physical power-loss or actual ENOSPC proof.

## 4. Required Boundaries and CI State

Read AGENTS.md, ADR-018/019 and the PA/HC contracts. No public mutable APIs, routing service,
external writer fence, durable receipt journal, source replacement or reclamation. Every
HC1/PA3 output keeps writers stopped. Artifact/operation matching is correlation, not
acknowledgment/authenticity or a capability. Do not open sealed inputs as live roots.
Keep original paths, stable runtime identities and every committed history; CanReclaim=false.

Historical CA1 hosted run 40651032546 failed only Documentation hygiene on Ubuntu/Windows;
Restore/Build/Test/Formatting passed there for that older code. Both portability fixes
are included in a3b578c; its hosted run is separate from later local RC2 source. No hosted
RC2 success is claimed. Actual archived releases, supported public signatures/diagnostics, real host
writer exclusion/work accounting/routing/restart proof and physical/release gates stay open.

## 5. Next Work

RC3 next: process-level preannounced attempt descriptors, failure/kill before/after publish,
read-only restart inspection with known IDs and no descriptor replay, competing same/different
plans, and explicit new-ID retry only after executor exit/outcome reconciliation. Preserve
separate unknown artifact-only versus known-attempt observations and no false acknowledgments.

Actual host ledger/exclusion/accepted work/routing/restart, public signature/consumer,
archived release and physical/release gates remain open. No automatic retry, source path
replacement, public API or reclamation; keep all histories and CanReclaim=false.

*Last updated: 2026-10-30*


## RC3 Process and Contention Qualification (2026-10-28)

RC3 now qualifies preannounced IDs across publisher process death, independent plans racing
one destination and concurrent dispatch of one plan. See [validation](implementation/M2_ADMINISTRATIVE_ATTEMPT_PROCESS_VALIDATION.md).
The focused Windows/Linux runs cover 71 cases each, including 12 new RC3 cases; prior
full-suite evidence retains its dated scope. This supersedes earlier “next RC3” statements.
RC2/RC3 remain local; a3b578c contains work through RC1. No public API, host routing,
durable replay, source replacement or reclamation is enabled. Next HA1 defines the host
attempt-ledger and fencing contract; local inspection alone never authorizes retry.
