# ADR-029: Separate Application-Authority Journal Version 1

**Status:** Accepted internal specification with pure codec/full-history validation; persistence pending
**Date:** 2026-10-29
**Deciders:** Authorized continuation of the internal embedded pilot

## Context

[REQ-006](FEATURE_REQUESTS.md#req-006-backup-restore-and-compatibility-transition) and
[REQ-007](FEATURE_REQUESTS.md#req-007-mutable-epoch-authority-and-recovery), under
[ADR-028](ADR-028-embedded-pilot-selection-and-work-authority.md), require an authoritative
selection/work history separate from the administrative attempt journal. EP7-A classifies
supplied assumptions; it cannot validate persistent transitions or create executable authority.
The next implementation needs unambiguous bytes, cumulative bounds and uncertain-save rules.

## Decision

Specify new host-only BXAM0001 metadata and BXAJ0001 frames in a separate application-authority
root containing authority.lock, authority.meta and authority.log. Bind metadata to the configured
scope, canonical administrative/authority root keys and administrative journal ID. Bind every
frame to that metadata digest, exact predecessor and authority identity. Preserve all existing
BXHM/BXHJ, store, migration and backup bytes, fixture hashes and administrative-root roles.

Version 1 contains one immutable enrollment baseline, one optional candidate registration,
conditional selection, globally unique work acceptances, retained outcomes, explicit observations
and exact owner transfer. Derive counts from every acceptance; no reset, rotation, pruning or
new baseline inside the history. Any acceptance permanently blocks a no-work selection change
in this baseline, even after completion or confirmed no effect. Replayed bytes never dispatch.

Use bounded canonical TLVs and explicit wire values rather than runtime enum ordinals. Metadata
is exactly 112 bytes; frame envelope is 144 bytes plus bounded payload. Author independent
Python metadata vectors with pinned hashes; they establish byte-level examples only. They are
not stores, complete histories, provisioned authority roots or runtime qualification.

Provisioning remains explicit/no-overwrite under real retained administrative ownership and
a new qualified child mode. Reopen never initializes or repairs. Only a live successful
initializer may attempt enrollment; empty reopened history stays stopped. Any uncertain append
faults the entire paired admission context. Restart validates the complete history, then
requires independent freshness/exclusion and explicit reconciliation; no prior acknowledgment
or permission to resume work can be reconstructed from a valid frame.

## Consequences

### Positive

- One chain orders selection and durable acceptance obligations without cross-journal atomicity claims.
- Exact bounds, mappings and malformed-history rules are reviewable before a codec or writer exists.
- A separately pinned metadata baseline leaves existing frozen artifacts unchanged.

### Negative / Accepted Costs

- A separate codec/history validator and owned lifetime/persistence implementation are still required.
- Capacity exhaustion or uncertain tails stop the pilot; no automatic compaction or repair exists.
- Local files lack intrinsic anti-rollback/fencing authority; operational gaps require reconciliation.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Add events to BXHJ v1 | Changes frozen administrative semantics and conflates independent authorities |
| Persist mutable counters or replace a selected-root file | Can erase obligations and loses one retained conditional history |
| Serialize EP7-A records directly | Runtime object/enum layouts are not a canonical versioned format |
| Treat matching root H or intent digest as proof of work outcome | Neither identifies the specific operation or authenticates acknowledgment |
| Clean an incomplete tail and continue | Could discard unacknowledged-but-complete authority or hide corruption |

## References

- [Version 1 format and commit contract](implementation/M2_APPLICATION_AUTHORITY_FORMAT_V1.md)
- [Specification validation](implementation/M2_APPLICATION_AUTHORITY_FORMAT_VALIDATION.md)
- [Pilot contract](implementation/M2_EMBEDDED_PILOT_AUTHORITY_CONTRACT.md)
- [EP7-A evidence](implementation/M2_EMBEDDED_PILOT_AUTHORITY_CLASSIFICATION_VALIDATION.md)

Codec follow-up (2026-10-29): [validation](implementation/M2_APPLICATION_AUTHORITY_CODEC_VALIDATION.md)
adds strict pure byte/history handling and four independently pinned frame/history vectors.
No ownership/provisioning/persistence is implemented. Next EP7-C begins with the paired lifetime mode.

EP7-C existing-root follow-up: [ADR-030](ADR-030-paired-read-only-application-authority-ownership.md)
and [validation](implementation/M2_APPLICATION_AUTHORITY_LIFETIME_VALIDATION.md) add paired
read-only ownership/drain without provisioning or append. Next no-overwrite initializer qualification.
