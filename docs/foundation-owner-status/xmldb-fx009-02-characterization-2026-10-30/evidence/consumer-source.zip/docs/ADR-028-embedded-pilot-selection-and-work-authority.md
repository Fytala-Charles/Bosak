# ADR-028: Embedded Pilot Selection and Accepted-Work Authority

**Status:** Accepted internal design with EP7-A pure classification implemented; EP7-B format/codec implemented; persistence and application integration pending
**Date:** 2026-10-29
**Deciders:** User-selected continuation of the internal single-process embedded pilot

## Context

[REQ-006](FEATURE_REQUESTS.md#req-006-backup-restore-and-compatibility-transition) and
[REQ-007](FEATURE_REQUESTS.md#req-007-mutable-epoch-authority-and-recovery) require cutover
and restart decisions to distinguish publication, root selection and accepted application work.
The [post-EP6-D audit](implementation/M2_POST_EP6_READINESS_REVIEW.md) confirms that EP6
qualifies stopped administrative reconciliation, while ActiveOperations is an administrative
lifetime count. Neither it nor the existing host journal establishes application work absence.
The user chose an internal embedded pilot rather than an external consuming application.

## Decision

Design an internal controlled single-process consuming host with an independent, bounded,
append-only application-authority journal. It owns authoritative selected-root revisions and
retained work-acceptance obligations under a lifetime bound to the existing administrative
host owner. Use a separate disjoint authority root; preserve the exact existing host-root
roles, BXHM/BXHJ v1 bytes and store/provenance formats. This decision selects the logical
backend only: no new byte layout, codec, file role names or runtime API is frozen here.

Every selection change compares the complete expected authority position and prior target.
Every work acceptance binds a fresh work ID, exact selected-root revision and immutable intent
commitment before database mutation or any acknowledgment that work was accepted. Retain
acceptance even after completion; completion is not proof that no work was accepted.
Database commit, authority append and administrative publication remain separate operations.
Unknown outcomes stop admission and require reconciliation; saved records never execute work.

Enrollment requires stopped controlled ingress/writers and actual pending-work drain, with
an explicit baseline covering prior work and both branches. No new empty log or caller flag
establishes that baseline. Local checksums/leases cannot detect arbitrary rollback or fence
uncooperative writers. Every restart stays stopped pending independently established freshness,
selection, work and publication agreement. No automatic writer resume or rollback is authorized.

Implement in gates: EP7-A pure classification with no I/O or callbacks and all outputs stopped;
EP7-B separate bounded format/transition specification and independent fixtures; EP7-C owned
persistence/provisioning and fault qualification; EP7-D actual internal consumer composition and
process tests. None closes public/release/archived-reader/physical-durability or retirement gates.

## Consequences

### Positive

- Selection and accepted work have one serialization order without changing frozen admin bytes.
- Unknown work stays visible across completion, lost acknowledgment and process exit.
- The next pure model can expose missing facts before persistence or routing code is added.

### Negative / Accepted Costs

- A separate authority lifetime/backend and cross-journal reconciliation need qualification.
- Uncertain saves or database outcomes can stop the entire pilot and require intervention.
- Restored valid prefixes have no intrinsic freshness proof; offline rollback remains outside
  the qualified controlled scope and requires independent reconciliation.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Reuse ActiveOperations as accepted-work count | It tracks administrative lifetime, not durable application acceptance |
| Extend the existing BXHJ v1 event set | Changes frozen mappings and conflates publication with application authority |
| Use configuration path plus in-memory counters | Does not resolve conditional selection or accepted work after restart |
| Atomically commit database and host journals | No shared atomic transaction exists; would conceal uncertainty |
| Introduce a server or distributed consensus backend | Outside the selected single-process embedded scope |

## References

- [Pilot authority contract](implementation/M2_EMBEDDED_PILOT_AUTHORITY_CONTRACT.md)
- [ADR-019 host boundary](ADR-019-explicit-mutable-api-and-host-cutover-boundary.md)
- [ADR-022 embedded profile](ADR-022-single-process-embedded-pilot-host.md)
- [ADR-027 stopped reconciliation](ADR-027-stopped-embedded-restart-reconciliation.md)

EP7-A now implements the pure supplied-evidence classifier; see
[classification validation](implementation/M2_EMBEDDED_PILOT_AUTHORITY_CLASSIFICATION_VALIDATION.md).
No authority backend or actual application execution is added. Next EP7-B defines the byte contract.

EP7-B follow-up: [ADR-029](ADR-029-separate-application-authority-journal-v1.md) specifies
the separate v1 bytes/transitions and independent metadata vectors. No production codec or
authority persistence is implemented; codec/full-history validation is next before EP7-C.

Pure codec/full-history validation is now implemented under ADR-029; see
[codec evidence](implementation/M2_APPLICATION_AUTHORITY_CODEC_VALIDATION.md). EP7-C owner-bound
application lifetime/persistence and EP7-D actual execution remain pending.

EP7-C existing-root follow-up: [ADR-030](ADR-030-paired-read-only-application-authority-ownership.md)
and [validation](implementation/M2_APPLICATION_AUTHORITY_LIFETIME_VALIDATION.md) add paired
read-only ownership/drain without provisioning or append. Next no-overwrite initializer qualification.
