# ADR-020: Planned Administrative Attempts and Lost-Acknowledgment Correlation

**Status:** Accepted design; RC1 preparation/claim and RC2 planned execution implemented internally; RC3 process/contention qualified locally; actual host integration remains open
**Date:** 2026-10-28
**Deciders:** Bosak.XmlDb implementation within authorized M2 contract design work

## Context

REQ-006/007 and [ADR-019](ADR-019-explicit-mutable-api-and-host-cutover-boundary.md) separate
storage publication from application routing. PA2 returns an acknowledged publication receipt;
PA3 can inspect an initial candidate without recovery. The [consolidated review](implementation/M2_CONSOLIDATED_API_READINESS_REVIEW.md)
identifies AR-004: migration/restore IDs are allocated inside their pipelines, so a caller
losing its first acknowledgment has no preknown attempt ID. Artifact match cannot establish
that an unknown request published a candidate and does not provide idempotency.

## Decision

Design a read-only preparation step that returns an opaque executable attempt plan plus an
immutable descriptive copy. The library allocates a fresh nonempty attempt ID before any
publication dispatch. Bind the plan to its creating administration instance, publication role,
canonical artifact and bundle paths, original inventory SHA-256, source backup/document/H/
optional source epoch identity, destination profile and explicit durability policy.
Preparation verifies bounded artifact seal/closure/header and destination preconditions,
not full redo, freshness permission, target reservation or routing readiness.

An executable plan is single-use and process-local. Its creating administration instance
atomically consumes it before any execution filesystem I/O. Every subsequent execution
failure leaves it consumed and uncertain; no reset, cloning, serialized replay or implicit
retry exists. Full history proof and exact bound-input/destination checks still run before
publication. A future planned pipeline writes the preknown attempt ID into the existing
MigrationId or RestoreId provenance field, with unchanged record layouts and role rules.
Existing unplanned entry points keep their current behavior until separately integrated.

Distinguish a host/business request from a physical attempt. A retry allocates a new attempt
ID after the caller establishes that the prior executor stopped or is fenced and reconciles
its outcome under single-dispatch ownership. The library creates no global execution registry,
reservation, persistent journal or exactly-once guarantee. An absent observation alone cannot
authorize retry because the prior executor might still publish.

A descriptive copy permits caller-owned pre-dispatch persistence and post-restart read-only
inspection. It cannot recreate executable authority. Matching a known attempt remains
correlation, not an acknowledgment receipt, authenticated provenance, write resume or routing
permission. Actual host persistence/exclusion and public API qualification remain open.

The [attempt contract](implementation/M2_ADMINISTRATIVE_ATTEMPT_CONTRACT.md) defines state,
retry rules and RC1-RC3 acceptance gates. The design introduced no runtime implementation;
RC1 is now recorded below. No existing codec, pipeline, public signature, data root or
retention policy changes; RC2/RC3 remain open.

## Consequences

### Positive

- A caller can know the physical attempt identity before publication can become uncertain.
- Known-attempt observations remain distinct from artifact-only matches and acknowledged results.
- Process-local double dispatch can be rejected before any filesystem effects.
- Frozen provenance fields/layouts and full-history proof remain intact.

### Negative / Accepted Costs

- The caller must retain the descriptor before dispatch if restart correlation is required.
- Target absence at preparation is not a reservation; competing publishers remain possible.
- Uncertain attempts require inspection/executor reconciliation, not transparent retries.
- A new attempt may encounter a valid candidate that must be retained and inspected.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Infer the request ID from matching artifact/H/path | Different attempts can publish equivalent independent candidates |
| Accept an arbitrary caller-selected provenance ID now | Requires collision/reuse/idempotency policy not supplied by current pipelines |
| Replay a saved executable plan after restart | Could duplicate a prior publisher or conflict with an unobserved publication |
| Treat absent destination or an exception as safe retry | The prior executor or uncertain publication may still exist |
| Return a successful receipt for a matching existing destination | Falsifies pipeline acknowledgment semantics and silently adopts existing output |
| Add a persistent attempt registry/root record | Introduces new authority, recovery and wire-format obligations beyond this design |

## References

- [REQ-006 and REQ-007](FEATURE_REQUESTS.md)
- [ADR-018](ADR-018-full-history-legacy-migration-and-cutover.md)
- [PA2 administration](implementation/M2_SCALAR_EPOCH_ADMINISTRATION_VALIDATION.md)
- [PA3 observation](implementation/M2_PUBLICATION_INSPECTION_VALIDATION.md)
- [Attempt contract](implementation/M2_ADMINISTRATIVE_ATTEMPT_CONTRACT.md)


RC1 update (2026-10-28): [internal preparation and claim](implementation/M2_ADMINISTRATIVE_ATTEMPT_PLAN_VALIDATION.md)
now implement read-only bounded input binding, immutable descriptive copies and owner-bound
atomic single-dispatch state. Existing publication methods remain unplanned and unchanged.
No execution API, persistent replay authority, caller IDs or frozen field/layout changes.


RC2 update (2026-10-28): [explicit planned execution](implementation/M2_ADMINISTRATIVE_ATTEMPT_EXECUTION_VALIDATION.md)
now consumes the owner-bound plan and one-entry execution context, pins source intent before
output and selects the preknown ID without changing provenance layouts or unplanned defaults.
Selected publication/cleanup uncertainty is qualified; RC3 process/restart and real host
protocols remain open. No receipt replay, public exposure or routing is enabled.


## RC3 Process and Contention Qualification (2026-10-28)

RC3 qualifies preannounced IDs across publisher process death, independent plans racing
one destination and concurrent dispatch of one plan. See [validation](implementation/M2_ADMINISTRATIVE_ATTEMPT_PROCESS_VALIDATION.md).
Focused Windows/Linux runs pass 71 cases each, including 12 new RC3 cases; earlier
full-suite evidence retains its dated scope. This supersedes earlier next-RC3 statements.
RC2/RC3 remain local; a3b578c contains work through RC1. No public API, host routing,
durable replay, source replacement or reclamation is enabled. Next HA1 defines the host
attempt-ledger and fencing contract; local inspection alone never authorizes retry.


HA1 follow-up: [ADR-021](ADR-021-host-attempt-ledger-and-publisher-exclusion.md) specifies
host persistence/exclusion requirements; actual host selection and HA2 enforcement remain open.
