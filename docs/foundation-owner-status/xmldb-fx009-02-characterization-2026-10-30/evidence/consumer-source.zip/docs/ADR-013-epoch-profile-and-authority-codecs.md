# ADR-013: Explicit Epoch Profiles and Bound Authority Codecs

**Status:** Implemented ET1-ET3 codec/compatibility slice; mutable opens remain unavailable  
**Date:** 2026-10-27  
**Deciders:** Bosak.XmlDb implementation within authorized M2 work

## Context

[REQ-007](FEATURE_REQUESTS.md) and [ADR-012](ADR-012-mutable-epoch-feature-and-recovery-contract.md)
define mutable epoch authority, but no bytes or parser existed. The next bounded slice
must freeze codecs and prove rejection before introducing coordinator ownership/writes.

## Decision

Freeze the existing immutable-epoch Storage/Core binaries before parser changes.
Preserve both frozen reader generations, their provenance and SHA-256 pins. Add explicit
EpochProfile parsing for exactly immutable 2.0/contracts 2/2/recovery 1/features 1 and
scalar-WAL 2.1/contracts 3/3/recovery 2/features 3. Generic parsing returns identity/profile;
RequireProfile gates capability. Existing DecodeFormat/admission/read-only entry points
still require immutable profile. No mutable admission/open/coordinator API is introduced.

Implement internal epoch-bound BASE, CONTROL, CURRENT, WAL, GENERATION and reader-identity
codecs with distinct magics and role bytes. All records bind StoreId/EpochId/document,
complete FORMAT digest and original base-manifest digest. Decoding requires the expected
binding. Fix exact envelope/field layout in the [byte contract](implementation/M2_EPOCH_AUTHORITY_FORMAT_V1.md)
and independent Python fixtures. Validate bounded sequences/digests, canonical BASE
binding, zero/head witnesses, first predecessors, GUID/node/value bounds and XML/UTF-8.
Canonical name helpers allow only twenty invariant decimal digits with the correct role
suffix and sequence range. No filesystem record persistence or recovery is implemented.

Test both frozen reader generations in isolated subprocess/load contexts against root
and private-generation fixtures. The current public read-only reader must reject the
mutable profile even when the stable admission lease is already exclusively held:
that proves the profile gate occurs before acquisition. Raw legacy readers may reject
an existing transaction sidecar before checking FORMAT; that is their existing refusal
path, not a new capability. Exact frozen rejection types and unchanged bytes are required.

The authority codec is not a commit verifier: it cannot validate target node kind,
transaction-ID uniqueness across a chain, materialization result or actual predecessor
WAL digest without the future coordinator/recovery context. It rejects every truncated
record; it does not classify or delete incomplete tails. ET4-ET9, full C1-C3 and all
retirement remain unimplemented. Existing public APIs/2.0 bytes stay unchanged.

## Consequences

### Positive

- Mutable byte parsing is separated from permission to open a store.
- Root/profile/base/role substitution fails before a record is used as authority.
- Independent fixtures and frozen binaries establish compatibility against exact old bytes.

### Negative / Accepted Costs

- New mutable records are internal codecs only; synthetic role fixtures are not writable stores.
- Frozen fixtures are local baseline captures without release/Git provenance, not archived pre-lease binaries.
- Fixed limits and reserved zero WAL witness constrain supported encodings.
- No new persistence fault claims, native mutable writes, migration or reclamation is enabled.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Widen DecodeFormat to accept both profiles for existing callers | Would grant capability implicitly |
| Reuse legacy authority records | They do not bind epoch/profile/base |
| Rely solely on a magic string | Explicit role checks and expected bindings also prevent substitutions |
| Rebuild the compatibility fixture during tests | Could silently replace old behavior with current code |
| Add the coordinator while freezing codecs | Would merge ET4+ ownership/recovery work with byte-contract review |

## References

- [Exact format](implementation/M2_EPOCH_AUTHORITY_FORMAT_V1.md)
- [Validation](implementation/M2_EPOCH_AUTHORITY_VALIDATION.md)
- [Mutable behavior design](implementation/M2_MUTABLE_EPOCH_CONTRACT.md)

*Last updated: 2026-10-27*

Implementation update: [ADR-014](ADR-014-admitted-empty-chain-epoch-coordinator.md)
now adds explicit internal ScalarWal admission and an empty-chain coordinator with
snapshot/transaction lifetime ownership. No public mutable API or scalar commit/recovery
is enabled; codec layouts and frozen-reader bytes from this ADR remain unchanged.
