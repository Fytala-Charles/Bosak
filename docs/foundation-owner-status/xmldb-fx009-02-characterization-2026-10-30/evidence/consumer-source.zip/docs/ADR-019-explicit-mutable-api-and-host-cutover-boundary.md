# ADR-019: Explicit Mutable API and Host-Owned Cutover Boundary

**Status:** Accepted boundary and safety requirements; proposed API shapes, implementation and host integration remain deferred
**Date:** 2026-10-28
**Deciders:** Bosak.XmlDb implementation within authorized M2 contract design work

## Context

REQ-006 and REQ-007 have internal conversion, ownership and modeled cutover evidence through
MG5, CA1 and CA2. Existing public entry points intentionally reject ScalarWal 2.1. Reusing
them through automatic detection would weaken frozen compatibility and obscure recovery
writes. The repository contains Core, Storage, Xdm and EmbeddedQuickstart; it has no actual
application router, request queue, external writer fence or server host implementation.

An owner lease excludes cooperating local writers; it cannot stop applications using old
binaries or establish global writer quiescence. MG5 decisions and receipts are memory-only,
caller-thread confined and cannot be replayed after a process restart. A public mutable
API and a production route change therefore require separate contracts and evidence.

## Decision

Keep legacy and immutable entry points profile-specific. Design a separately named,
explicitly opted-in mutable epoch facade and separate administrative migration operations.
Names/signatures in the [API and host contract](implementation/M2_PUBLIC_API_AND_HOST_CUTOVER_CONTRACT.md)
are proposals, not new public members or a promised release surface. Preserve current
bytes, namespaces, public signatures, proprietary licensing and disabled packaging.

The library owns profile validation, local admission, scalar transaction/recovery rules,
full-history verification and separate-root publication. The consuming host owns routing,
external writer stop/drain, accepted-work accounting and restart reconciliation. The library
must not select a host technology, rewrite application configuration or treat operator
attestation as an enforced cross-application fence.

Require exact source/candidate identity commitments, revision-checked routing and a host
mechanism that keeps both writers stopped during uncertainty and across host restart.
Unknown acknowledgment, missing work accounting, lost ownership or contradictory observations
require reconciliation. No automatic failback or source path replacement is permitted.
A durable host record, if introduced, needs a separately specified integrity/atomicity and
fault contract; this ADR introduces no persistent record, codec or journal authority.

## Consequences

### Positive

- Existing readers keep strict profile and lifetime behavior.
- Public storage access and application routing have distinct release gates.
- Restart decisions require fresh observations rather than reusing process-local receipts.
- Host-neutral requirements can be tested without manufacturing an application integration.

### Negative / Accepted Costs

- A real host adapter and external writer exclusion mechanism must be selected and qualified.
- Public naming, diagnostics and release policy remain provisional until dedicated review/tests.
- Unknown outcomes can prolong write downtime and require explicit operator reconciliation.
- Archived release compatibility, controller durability and all retirement remain open.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Auto-detect ScalarWal in existing public Open | Widens current profile gates and hides recovery/admission changes |
| Make MG5 enums or receipts durable routing authority | They represent trusted prototype inputs and lose validity on restart |
| Add an assumed web/configuration backend now | No such consuming host exists in this repository |
| Fall back to source after timeout or process exit | Neither event proves routing outcome or absence of accepted work |
| Use StoreId/EpochId to fence every old writer | Legacy sources have no such IDs and old applications do not honor new fencing |

## References

- [REQ-006 and REQ-007](FEATURE_REQUESTS.md)
- [ADR-018](ADR-018-full-history-legacy-migration-and-cutover.md)
- [Readiness audit](implementation/M2_RELEASE_READINESS_AUDIT.md)
- [CA2 ownership evidence](implementation/M2_MIGRATED_OWNERSHIP_VALIDATION.md)
- [Public API and host contract](implementation/M2_PUBLIC_API_AND_HOST_CUTOVER_CONTRACT.md)


HC1 implementation update (2026-10-28): [pure classification](implementation/M2_RESTART_CLASSIFICATION_VALIDATION.md)
now implements supplied-fact restart/uncertainty decisions without I/O or routing authority.
Every result keeps writers stopped. Public API shapes, actual host integration, durable
record design and release gates remain deferred.


PA1 prototype update (2026-10-28): [internal facade](implementation/M2_SCALAR_EPOCH_FACADE_VALIDATION.md)
now exercises explicit mutable options, independent children and preserved diagnostics.
Public names and consumer release qualification remain provisional; no public API or routing
is enabled. Optional expected identity is checked before local admission/adoption.


PA3 update (2026-10-28): [read-only publication inspection](implementation/M2_PUBLICATION_INSPECTION_VALIDATION.md)
now separates artifact correlation, known-operation correlation and uncertain/changed
observations without recovery/adoption. Neither match authenticates provenance or resumes
writers. Public, actual host/restart, archive and release gates remain open.


Consolidated review update (2026-10-28): [API/readiness review](implementation/M2_CONSOLIDATED_API_READINESS_REVIEW.md)
retains the internal boundary and flags caller-known request/attempt correlation before
public administrative diagnostics. Existing operation IDs are allocated inside publication
pipelines; a matching artifact does not establish an unknown request ID or idempotency.
No new caller-ID policy, durable journal or public API is decided by this review.
