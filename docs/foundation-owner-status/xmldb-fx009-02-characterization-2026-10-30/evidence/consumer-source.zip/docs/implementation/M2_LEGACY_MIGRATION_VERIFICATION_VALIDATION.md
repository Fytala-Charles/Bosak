# MG2 Legacy Verification Validation

Date: 2026-10-27. Internal verification only; no migration conversion/cutover capability.
See [contract](M2_LEGACY_MIGRATION_VERIFICATION.md) and
[machine results](m2-legacy-migration-verification-results.json).

33 new Storage cases cover:

- H0/H1/H3 with text and empty ordinary-attribute edits, namespaces/document URI/xml:base,
  exact input byte preservation, independently retained uncached readers, repeated success
  and cleanup of owned copies without publishing the destination hint.
- Thirteen malformed-history classes before any storage calls: partial/gapped WAL, absent
  generation, mixed base/generation profile, stale CURRENT, wrong CONTROL, duplicate TxId,
  predecessor mismatch, extra file/directory, corrupt fragment and unsupported scalar kind.
- A coherently resealed hidden second scalar edit: the declared target is correct but the
  unchanged-node projection is wrong. Strict preflight rejects before workspace allocation.
- Hash-consistent unused payload bytes: complete logical verification succeeds, but exact
  deterministic redo cannot reproduce the committed manifest and rejects the artifact.
- Exceptions at all five high-level checkpoints; before/after and actual partial writes
  inside redo; input preservation, released exclusive-file handles and a fresh retry while
  old failed workspaces remain. These are selected fault positions, not exhaustive MG4 proof.
- Input/private-copy changes after preflight; overlapping/existing destination refusal;
  Linux source-file/destination-ancestor links; actual native FileAndDirectoryFlush delegate.

Three host-conditional branches return on Windows (two link tests and native strong-policy
execution); they are not native Windows evidence. All existing frozen wire/metadata/reader
fixtures are preserved. MG1 parsing and exact-tree/owned-clone cleanup are shared by changing
internal visibility only; their encodings and algorithms remain unchanged.

Fresh filtered regressions run 738 cases per platform (588 Storage, 27 Xdm, 123 Integration),
including all 33 new cases. The unchanged expensive 18-case EpochBackupFaultTests matrix
retains its prior [ET9-D evidence](m2-epoch-backup-fault-results.json); the catalog is 756,
not a fresh unfiltered 756-case run. Linux uses the isolated pinned SDK runner, read-only
source/cache and no network. Formatting, strict documentation and frozen fixture hashes
are checked separately. Exact final counts/status are in the machine report.

No real ENOSPC, physical power-loss certification, exhaustive MG4 fault coverage, conversion
or routing support is claimed. MG3 destination transformation/publication and broader
archived C1-C3 remain open; CanReclaim=false and all original history remains retained.
