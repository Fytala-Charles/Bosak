# Stopped Restart Inspection and Outcome Validation

Date: 2026-10-29. EP6-B composes [ADR-027](../ADR-027-stopped-embedded-restart-reconciliation.md)
with the [EP6-A stopped append boundary](M2_EMBEDDED_HOST_STOPPED_APPEND_VALIDATION.md).

## 1. Runtime Behavior

EmbeddedHostRestartReconciler acquires the exclusive stopped registration at the exact expected
journal position. It requires the exact latest snapshot for the latest recorded attempt of the
business request. Updates to older attempts cannot make an older intent current again. It transfers
owner session/generation and revision with checked arithmetic, preserving all saved facts; only
Recorded/DispatchAuthorized change to Uncertain on transfer. Every transfer/outcome save must be
actually acknowledged by the existing flush/readback path.

The reconciler invokes the real read-only inspector using the persisted operation ID and artifact
pin, outside journal/lifetime locks. KnownOperationMatched is persisted as ObserveKnown, never as
a synthetic execution receipt. Existing acknowledged/observed terminal state must agree with the
full fresh observation. An absent candidate with a saved receipt/observation is contradictory.

NotObserved alone returns EvidenceRequired. Saving ReconcileAbsent additionally requires fresh
host-context/exact-original-snapshot-bound assertions of stable destination namespace and no
retained publication evidence, alongside the controlled publisher/writer exclusion used to acquire
the session. It reinspects immediately before saving absence. These facts are trusted host input,
not independent proof against hostile/manual publishers. The caller must maintain them throughout
the synchronous session. Unavailable, malformed, artifact-only and foreign-operation inspection
cannot qualify absence. Previously absent state still needs fresh absence facts; no outcome frame
is replayed for an already terminal snapshot owned by the current session.

The session remains registered through actual inspection/saves and releases on completion or
exception. A post-entry save failure faults the lifetime and propagates without manufacturing an
acknowledgment. Completed bytes may remain on disk and require fresh stopped reconciliation.
No admissions are opened, old tickets recreated, plans dispatched or database writers resumed.
Transfer and outcome acknowledgments are separate from the inspector observation and saved facts.

## 2. Qualification

26 new Integration cases cover both publication roles at H=0/H=3 for known, acknowledged and
absent outcomes; six invalid absence facts; malformed artifacts in both roles; lost transfer and
outcome acknowledgments; changed snapshots; contradictory missing acknowledged publications;
and repeated terminal absence without another outcome frame. The initial Windows test run found
a test-only incompatible read-sharing mode; byte comparison now occurs outside host ownership.
All 961 focused cases pass per platform (732 Storage and 229 Integration), zero failures/skips.
Formatting and Windows/Linux strict documentation/portability checks pass. Public Storage
metadata remains at 95 signatures; all four EP6-A source/test fingerprints are unchanged.
The final focused suite and platform counts are recorded in the
[machine evidence](m2-embedded-host-restart-inspection-results.json). This is not an unfiltered
full-suite run or new process-kill/physical durability evidence.

## 3. Delivery and Next Step

EP6 design is pushed as `22eeddf`; EP6-A/B implementation remains local/uncommitted.
Next implement explicit fresh-plan retry after qualified acknowledged absence, retaining the
business request and exact v1 input/destination while allocating a fresh attempt ID. It must
recheck the latest absent snapshot and artifact commitment before recording. No retry runtime
or automatic admission/routing is added in this step. Process-kill qualification, production
application authority, global fencing, public release and reclamation gates remain open.
