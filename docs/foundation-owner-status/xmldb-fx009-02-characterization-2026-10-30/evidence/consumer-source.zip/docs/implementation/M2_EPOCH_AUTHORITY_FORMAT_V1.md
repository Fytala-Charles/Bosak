# M2 Epoch Profile 2.1 and Authority Format 1.0

Implemented internal codecs per [ADR-013](../ADR-013-epoch-profile-and-authority-codecs.md).
Parsing/encoding these bytes grants no mutable admission, root open, commit or recovery
capability. Existing read-only/public admission entry points still require profile 2.0.

## FORMAT Profiles

Both profiles retain the 99-byte BXDB layout from M2_EPOCH_FORMAT_V2.md: major 2, body
length 55, flags=1, StoreId/EpochId/document, required reader/writer/recovery/features,
then SHA-256. Immutable has minor=0, contracts 2/2/1 and feature mask 1. ScalarWal has
minor=1, contracts 3/3/2 and feature mask 3. Only those exact tuples parse. Unknown/mixed
requirements fail even with a correct digest. DecodeProfile returns identity plus
profile; RequireProfile checks the caller's explicit capability. DecodeFormat retains
its original immutable-only contract. BXEP/BXEA bind complete FORMAT bytes unchanged.

Independent fixture: epoch-mutable-format-v2.hex. Existing immutable fixture is unchanged.

## Common Authority Envelope and Binding

Every role uses BinaryEnvelope 1.0: four ASCII magic bytes, LE u16 major=1/minor=0,
LE i32 body length, body, SHA-256 of complete header/body. Existing 64 MiB complete-file
limit and strict trailing/checksum/version rules apply. No partial-record success result
or tail-discard decision exists in these decoders.

Every body begins with this 104-byte expected binding, then one role byte:

| Body offset | Field | Encoding |
|-------------|-------|----------|
| 0 | StoreId | 16 bytes, .NET Guid.ToByteArray order; nonzero |
| 16 | EpochId | 16 bytes, same order; nonzero |
| 32 | DocumentId | LE u64; nonzero |
| 40 | FORMAT digest | 32-byte SHA-256 of complete ScalarWal FORMAT |
| 72 | Base manifest digest | 32-byte SHA-256 of complete immutable base manifest |
| 104 | Record role | u8, exact role below |

Body fields after offset 104 are below. The caller creates expected binding from a
validated ScalarWal FORMAT and 32-byte base digest; each decoder requires that binding
and compares every identity/digest. Direct encoding validates binding syntax, not on-disk
base validity. Hash fields are exactly 32 bytes. Empty IDs or malformed lengths fail.

## Role Bodies

| Role / magic | Role byte | Fields after role, in order | Complete size |
|--------------|-----------|-----------------------------|---------------|
| BASE / BXEB | 1 | LE u64 sequence=0 | 157 |
| CONTROL / BXEC | 2 | LE u64 sequence=0; canonical BASE file digest (32); LE u16 scalar contract=1; LE u16 recovery contract=2 | 193 |
| CURRENT / BXEH | 3 | LE u64 sequence; manifest digest (32); complete WAL digest (32) | 221 |
| WAL / BXEW | 4 | LE u64 sequence; transaction GUID (16); LE u64 NodeId; replacement string; predecessor manifest (32); result manifest (32); preceding complete WAL digest (32) | 281 + UTF-8 value bytes |
| GENERATION / BXEG | 5 | LE u64 sequence; predecessor manifest (32); result manifest (32); complete WAL digest (32) | 253 |
| Reader / BXER | 6 | LE u64 sequence; expected manifest digest (32) | 189 |

The common base digest supplies BASE's manifest identity. CONTROL's referenced digest
must equal SHA-256 of canonical EncodeBase with the same binding; base/control encodings
are deterministic and contain no circular digest. A role cannot decode as another role,
even when another magic/role is substituted and the envelope resealed.

## Semantic Bounds

All sequences are at most 10,000. WAL/generation require sequence 1..10,000; current and
reader allow zero. CURRENT at zero requires the bound base manifest and zero WAL digest;
positive current/generation WAL digests must not be all-zero (reserved no-WAL sentinel).
A zero reader binds the base manifest. Sequence-one WAL/generation predecessor manifest
must equal base; sequence-one preceding WAL digest is zero. Subsequent chain digests
are compared against actual history by future recovery, not by a standalone codec.

WAL TransactionId is nonempty; NodeId is 1..1,000,000. Strings use LE i32 UTF-8 byte
length, maximum 1 MiB, strict UTF-8 plus XML character validity. Empty scalar is encodable
for ordinary attributes; empty-text/kind/namespace semantics require a materialization
context and are deferred. Transaction-ID chain uniqueness and exact materialized result
are also deferred. Reject invalid Unicode, negative/oversized string lengths and malformed
bounds before allocation or authority use.

## Canonical Names

WAL is <sequence-D20>.wal, generation directory is <sequence-D20>, reader identity is
<sequence-D20>.lease. Case, padding, suffix and bounds are exact; no signs, separators,
absolute/relative paths or traversal can parse. Reader zero is valid; WAL/generation
zero is invalid. Name helpers do not resolve or write filesystem paths.

## Fixtures and Scope

Independent Python struct/UUID/SHA-256 encoding produced epoch-base/control/current/
wal/generation/reader-v1.hex plus the mutable FORMAT fixture. Fixtures use deterministic
GUIDs, base digest bytes 1..32, result bytes 33..64, transaction ID
20314253-6475-8697-a8b9-cadbecfd0e1f, NodeId 3 and value new. WAL/generation/current hashes
bind complete encoded records. Tests compare exact bytes, roundtrip, every truncation,
roles, contexts, malformed bodies and canonical names.

Synthetic integration fixtures have real copied base data and bound role records, but
are not production mutable roots or evidence of commit/recovery. No mutable writer,
replay, tail cleanup, checkpoint/truncation, migration or deletion API is introduced.

*Last updated: 2026-10-27*
