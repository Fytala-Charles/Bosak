# XDM 4.0 Compatibility Assessment

Date: 2026-10-29. Documentation assessment only; no dependency, provider or format change.

## 1. Evidence and Conclusion

Bosak has substantial 4.0 foundations; complete conformance to the moving current draft has
not been established by this assessment. Local Bosak checkout `029be319` and the XmlDb-pinned
1.26.2 source baseline (`6a3372fc3b91e733b71a426cf40f26feaaeb3bcb`) were inspected. The pinned
baseline already contains XdmValueKind.JNode. Current source also contains XdmJNode, ordered
map key tracking, record annotations and opt-in XPath 4.0 support. Do not confuse current
upstream source inspection with complete qualification of the pinned package or latest draft.

XmlDb depends on Bosak.XPath.Core exactly 1.26.2. Storage/Core remain independent of Bosak's
XDM implementation; PersistentXdmNode adapts immutable XML snapshots to IXdmNode. Supporting
4.0 queries over this XML profile does not inherently require a disk-format migration. Persisting
arbitrary XDM values, JSON/JNode trees or schema annotations is a separate scope/format decision.
No upstream checkout or package pin was changed during this assessment.

The [QT4CG XDM 4.0 draft](https://qt4cg.org/specifications/xpath-datamodel-40/Overview.html)
was inspected on 2026-10-29 (displayed draft date 2026-10-22). Its GNode model covers XML and
JSON-oriented nodes while retaining the seven XML node kinds. Its record/map, atomic comparison
and character-model changes warrant compatibility tests rather than assuming that existing
4.0 syntax support establishes full data-model conformance. Location information can be absent;
location support alone does not require persisting new mandatory XML metadata.

## 2. XmlDb Compatibility Work to Qualify

| Boundary | Current observation | Proposed qualification |
|----------|---------------------|------------------------|
| Node kinds | PersistentXdmNode directly casts persisted StorageNodeKind to upstream XdmNodeKind | Test exact mappings; prefer explicit translation when changing the adapter, without renumbering persisted kinds |
| Typing | TypedValue currently returns a string; storage has an untyped XML scope | Document/test atomization and untyped semantics; schema persistence remains separate REQ-008 |
| Identity/order | Identity is snapshot-relative; document order uses persisted node IDs | Differential tests for axes, order and identity within the declared snapshot profile |
| Composite results | BindResult guards outer enumeration | Test maps/arrays/records/JNodes and deferred values retaining persistent nodes, including access after snapshot disposal |
| Query semantics | Pinned upstream runtime is the dependency boundary | Compare the same 3.1/selected-4.0 expressions over in-memory and persistent providers, including atomization, numeric comparisons and map ordering |
| Persistent JSON/general XDM | No such storage contract is implemented | Separate feature/design/migration decision; do not encode JNodes as new XML node kinds |

Typing, identity and nested-result lifetimes are existing provider boundaries, not exclusively
4.0 changes or newly demonstrated defects. This assessment identifies tests to add; it does
not claim failures, complete conformance or a new published provider capability.

## 3. Recommendation and Delivery

Retain the XML-only store and current package pin. Register an explicit compatibility matrix
against a chosen dated Bosak/specification baseline before advertising XDM 4.0 provider support.
REQ-009 tracks that proposed qualification; it does not authorize a dependency upgrade, persistent
JSON or general XDM storage. The next embedded-host task remains the consuming application's
selected-root and accepted-work authority audit after EP6-D process qualification.
