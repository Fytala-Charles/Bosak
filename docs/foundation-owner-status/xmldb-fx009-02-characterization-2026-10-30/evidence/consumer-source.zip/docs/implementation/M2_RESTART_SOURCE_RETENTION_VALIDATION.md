# SR2-A Restart-Only Source Retention

Date: 2026-10-30. Parent checkpoint bc5e490 is committed/pushed. Implements only the source
primitive in [ADR-035](../ADR-035-owned-stopped-restart-observation.md) and the
[SR2 design](M2_OWNED_RESTART_OBSERVATION_DESIGN.md). See
[machine evidence](m2-restart-source-retention-results.json). SR2-B/C actual paired observation
and its broader qualification remain unimplemented.

## Actual Owner, Permanent Stop and Drain

EmbeddedXmlDatabase.RetainedRestartSource is internal, private-constructed and caller-thread
confined. Acquire requires the actual already-open source and supplied controlled/stopped-scope
attestation. It rejects unavailable/faulted owners, existing freeze/enrollment/restart modes and
any permanent stopped owner. It never accepts a capture, descriptor, receipt or initializer.
Acquisition uses only a brief source lifetime gate, sets the actual child and permanent owner
stop atomically, and performs no filesystem I/O or callback. Caller-held source-gate entry is
rejected. This source-only Acquire may wait for the source gate; SR2-B must not call it while
holding peer lifetime gates and must separately qualify combined admission.

The existing internal _enrollmentStopLatched now also represents this opt-in restart owner's
permanent stop. Reuse keeps all existing mutation/publisher entry checks intact: BeginWrite,
preexisting optimistic transaction Commit, CreateCheckpoint, CreateRecoveryAnchor, CreateBackup
and new MigrationSourceFreeze acquisition reject. A second restart child rejects both before
and after drain. A successful acquisition remains stopped even when later inspection fails.
Original armed enrollment objects remain ineligible; no original freeze/capture association
or enrollment condition is weakened. External/old binaries remain outside this cooperative
scope; attestation does not prove their absence.

The existing owner-release task/status and once-only original-stream close path are shared.
HasRetainer includes either actual child kind; owner Dispose defers its original usable
FileStream close for either. The restart child never closes/reopens or substitutes a pinned
handle. Draining it while the owner is live leaves that owner stopped and physically owning
its stream. Draining after owner Dispose closes the original once. Existing independent
snapshots survive. No-retainer/default close and original enrollment behavior remain unchanged.
Qualification uses default ProcessCrash source owners. This lifetime-only primitive neither
certifies stronger write durability nor selects/falls back between policies; SR2-B must enforce
the pilot ProcessCrash policy before paired observation.
An explicit later source Open is a separate workflow and inherits no persistent fence.

## Source Inspection and Closing

InspectState copies root/document/H/manifest memory under a brief source gate, then checks
native root identity and original writer handle/path identity plus empty owner-file length
outside that gate. It rechecks actual registration and unchanged memory state before returning
another copied description. Source/capture/full-history verification is not implemented here;
SR2-B must compare native identities across its complete unlocked verification. An inspection
failure poisons the child and leaves the permanent stop intact. Dispose can still drain a
faulted child.

A test-only before-native probe executes outside the gate, including an explicit post-probe
gate check. Production InspectState supplies no callback. Closing after child admission may
finish actual reads using the original retained stream; the returned description marks
OwnerClosing. RequireCurrent requires this exact live source, active child and caller thread,
and rejects closing/faulted/released/foreign state. Neither a successful check nor description
is an execution or handoff capability. Future paired final admission must recheck current state.

## Release Faults

The existing internal qualification close seam can be bound once by AcquireCore to the actual
source's original stream. Default Acquire supplies null and directly uses existing FileStream
Dispose behavior. Before-close and after-close exceptions, plus return without closing the
original managed handle, remain unconfirmed. After owner closing, a failed child drain leaves
the actual registration retained, ReleaseUnknown and a faulted owner-release task. Repeated
Dispose never retries. Physical availability after an after-close error does not clear logical
uncertainty. Managed checks do not certify native kernel-close failure behavior.

If the child already drained while its owner was live, a later owner Dispose failure leaves
the child Released but faults the owner task/status; it does not recreate a child or erase the
stop. Fresh fixture teardown may manually close its own captured handle to remove its private
workspace; this does not alter production logical state or retry the adapter.

## Qualification and Audit

All 38 new Storage cases and 152 focused Windows cases pass. New bodies have no platform
early-return guards. Cases cover both owner/child disposal orders; all seven cooperating
mutation/publisher entries before/after child drain; false attestation, existing freeze,
closed/faulted owner, caller-held source gate, original enrollment association/armed stop,
exact owner/wrong thread, unlocked native phase, close during inspection, actual nonempty
writer rejection without repair, copied positive-H state and retained snapshots, all three
close-fault modes at required drain and later independent disposal, and explicit new-owner
non-fencing. Eight repeated simultaneous acquire/close schedules complement ordered endpoints;
these do not prove every possible interleaving.

Source faulted-state admission uses explicit test reflection, not a fresh persistence-fault
claim. Byte comparisons exclude the actively exclusively held runtime writer.lock and include
all other files plus the full file/directory inventory; native checks qualify that actual role
separately. Fixed snapshot setup precedes measurements. Initial compile/helper and fixture
setup corrections are retained in the evidence; production assertions/timeouts were not weakened.
Formatting/analyzers pass. Isolated Linux passes 268 focused cases (264 Storage + 4 Integration),
including all 38 new bodies; Xdm has no matching rows. SDK 10.0.301 on x64 overlayfs uses
read-only source/cache mounts, no network and isolated outputs. Seven Git-free MINVER1001
warnings are expected. All 2,656 Windows cases pass across complete project runs. The initial restore timeout is
retained and passes focused plus complete Integration rechecks. Storage passes 1,973, Integration 656 and Xdm 27.
All 2,618 previous test IDs remain with exactly 38 new Storage IDs.
The initial full command fails its Published-stage restore process timeout; all six restore
cases and the complete 656-case Integration rerun pass with unchanged 50-second limits.
The failed artifact is retained; no cause is inferred and the initial command is not green.

Fresh public metadata remains 95/95 entries, zero additions/removals; this is local metadata
evidence, not archived release qualification. Ten frozen vector/binary files match recorded
read-only hashes. Strict documentation, actual hidden/link portability and diff hygiene pass.
Three final C# hashes match qualified inputs. No fixture-generation scripts are executed.

## Next Step

SR2-B must add the real parent/authority/source-bound observation with full source/sealed
capture proof, exact inventory commitment, placement outside serializers and freshness rechecks.
This source-only slice does not complete SR2. SR2-C broader race/process/native identity
qualification and SR3/SR4 handoff remain later. No new public API, bytes, live recovery, capture,
source replacement, writer resume, work/routing admission or reclamation. CanReclaim=false.

SR2-B follow-up (2026-10-30): [actual paired stopped observation](M2_OWNED_RESTART_OBSERVATION_VALIDATION.md)
binds complete read-only legacy/capture proof to real retained owners, with no acknowledgment
or handoff authority. Earlier evidence retains its dated scope; next SR2-C qualification.
