# HA1 Ledger and Planned Execution Integration Validation

Date: 2026-10-28. Test-only integration under
[ADR-021](../ADR-021-host-attempt-ledger-and-publisher-exclusion.md), the
[ledger contract](M2_HOST_ATTEMPT_LEDGER_CONTRACT.md) and the
[in-memory transition harness](M2_HOST_LEDGER_TRANSITION_VALIDATION.md).

## 1. Test-Only Integration

HostLedgerPlannedExecutionTests binds each ledger intent to an actual opaque library plan,
canonical artifact/bundle selection and preknown attempt ID. Both legacy migration and
independent epoch restore execute through the creating administration instance. Actual returned
receipts and read-only inspection observations flow separately into the memory harness.
No production source or orchestration adapter changes in this step.

For intent, authorization and receipt saves, tests inject no fault, BeforeCommit or AfterCommit.
Before execution, they assert destination absence and a still-prepared original plan. After
exceptions, explicit reads determine the modeled commit state. Only the still-live original
owner holding the exact uninvoked plan proceeds after confirmed intent/authorization. A failed
receipt save can be conditionally retried with the retained actual receipt; the pipeline is
never replayed. Candidate file/directory snapshots and sealed input bytes remain unchanged by
ledger operations, inspection and duplicate-execution rejection.

Pipeline exceptions after proof and after publication consume the plan but return no receipt.
A completed synchronous executor with explicit private test-scope exclusion can reconcile
actual absence, retain the old attempt and prepare a fresh attempt with a new ID. A second
memory harness retains the same host request relation for the new attempt; these two test
objects do not implement a persistent append-only request registry. Published candidates are
saved as ObservedKnown, never synthesized acknowledgments. Discarded actual returns similarly
leave only known-operation observations when inspected through another administration instance.

An eight-worker race allows only the successful conditional authorizer to call ExecuteAttempt.
Another test pauses the actual publisher at ProofVerified: inspection sees no destination, but
correctly supplied active-executor evidence rejects absence reconciliation and takeover. The
publisher is then released and awaited even if an assertion fails, before test-owned cleanup.
A real receipt from another plan/destination cannot acknowledge the original ledger intent.

These tests explicitly control the dispatch branch. They do not install an enforced ledger
check inside ExecuteAttempt or prove global single dispatch: direct callers, independent
harnesses and old processes remain outside this test orchestration. Host evidence is scoped
to each test's GUID-owned temporary root, not a manufactured production fence. Memory saves
remain protocol assumptions, not durable persistence. Every ledger outcome keeps writers stopped.

## 2. Executed Evidence

34 new integration cases cover 18 role/save/fault combinations, four H0/H3 complete-history
publications, four pipeline exceptions, two lost-return observations, two concurrent dispatch
races, two actual active-publisher cases and two other-attempt receipt rejections.

The final focused runs pass 448 cases per platform: 343 Storage (83 transition + 180 ledger
model + 80 HC1) and 105 Integration (34 new + 28 RC1 + 31 RC2 + 12 RC3). Windows uses Debug;
network-disabled isolated Linux uses Release, both SDK 10.0.301. All 34 new cases execute
ProcessCrash on both hosts. Existing RC2 native cases run on Linux and assert unsupported
policy on Windows; RC3 process cases retain their original scope. This is not a new full-suite
or physical-durability run. Earlier broad/fault reports remain valid only at their dated scope.

SHA-256 comparison confirms all 167 prior non-build runtime/test/fixture files unchanged;
only the new integration test source is added. Public Storage metadata remains 95 signatures,
without additions/removals against the frozen local baseline. Formatting, strict docs and
actual hidden/link portability checks pass on Windows and Linux. Frozen binaries/metadata,
wire formats, dependency pins, proprietary license and disabled packaging remain unchanged.

## 3. Remaining Integration Gate

The bounded library/model integration step is complete. HA1 actual-host selection and HA2
production integration remain open: no consuming application, durable backend/commit semantics,
executor/queue inventory, effective publisher fence or route/work authority has been selected.
Existing modeled lease/generation changes still cannot fence filesystem publication. No
persistent ledger, executable descriptor replay, route switch, writer resume, source replacement,
release or reclamation is introduced. CanReclaim=false. Changes remain local and uncommitted.

Next work requires identifying the actual consuming host and its persistence, publisher-exclusion,
route-revision and accepted-work mechanisms. Use the contract's open inputs to select those
mechanisms before adding a production adapter or claiming HA2 qualification. Additional model
runs cannot establish these external guarantees.

[Machine evidence](m2-host-ledger-planned-execution-results.json).
