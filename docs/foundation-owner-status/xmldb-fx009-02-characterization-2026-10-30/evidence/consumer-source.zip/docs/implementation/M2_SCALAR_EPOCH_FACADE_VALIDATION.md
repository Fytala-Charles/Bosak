# PA1 Internal Mutable Facade Prototype

Date: 2026-10-28. Internal prototype under
[ADR-019](../ADR-019-explicit-mutable-api-and-host-cutover-boundary.md). No new public type,
member, wire format, host adapter or release permission is introduced. Proposed naming
and public diagnostic/result shapes remain subject to review.

## 1. Proposed Consumer Surface

ScalarEpochDatabase is internal and owns exactly one existing EpochScalarCoordinator.
Open requires explicit ScalarEpochOpenOptions: requested durability, FullHistory recovery
(the only supported recovery policy), and an optional exact expected EpochIdentity.
No existing legacy/immutable Open changes profile. Invalid options reject before storage
access; native policy never silently falls back. Open may perform existing recovery and
runtime publication and is not a read-only inspection call.

An optional expected identity is checked inside coordinator Open immediately after profile/
identity decoding and before admission, writer acquisition or recovery. Admission rechecks
the decoded identity as before. This is local store selection validation, not a fence for
uncooperative writers or protection from arbitrary concurrent external namespace replacement.
Existing callers omit the optional argument and retain their previous path.

| Internal prototype operation | Semantics |
|------------------------------|-----------|
| Identity / Durability | Immutable owner selection metadata, still readable after Dispose |
| CommitSequence | Current owned selection; disposed/faulted owner rejects |
| BeginRead | Selected-head independent immutable snapshot, configurable cache |
| BeginTransaction | Wrapper of existing single-scalar transaction with independent snapshot/admission |
| CreateBackup | Existing fixed-H complete history pipeline; no routing callback exposed |
| Dispose | Idempotently disposes owner; does not dispose independent children |

ScalarEpochWriteTransaction exposes transaction/epoch identity, base sequence, ReadValue,
ReplaceNodeValue, Commit, Rollback and Dispose internally. It delegates existing scalar
restrictions, stale validation and handle release without retrying or translating errors.
Snapshot single-evaluation-thread/concurrent-disposal limitations remain unchanged.

OpenCore is an internal test seam for persistence callbacks/storage injection, not a proposed
consumer extension point. It rejects storage whose advertised durability differs from the
explicit options. Verify/restore/migration administrative operations are not included in this
prototype and are not implicitly invoked by mutable Open.

## 2. Diagnostics and Unacknowledged Outcomes

| Trigger | Preserved diagnostic / required caller behavior |
|---------|------------------------------------------------|
| Null/empty root/options or unknown policy | Argument exception before storage work |
| Unsupported native policy | PlatformNotSupportedException without weaker fallback |
| Wrong profile, expected identity or corrupt authority | InvalidDataException; no automatic adoption/migration |
| Writer/admission contention or storage I/O | IOException; message/category is not converted into a contention guarantee |
| Disposed owner / completed transaction | ObjectDisposedException; no automatic owner recreation |
| Stale selected head | Existing TransactionConflictException; edit not automatically retried |
| Faulted coordinator after persistence failure | InvalidOperationException until explicit dispose/reopen |
| Commit IOException after possible publication | Preserve exception; explicit reopen/recovery/history inspection resolves outcome |

The same injected I/O exception is returned before WAL publication, after flushed WAL and
after CURRENT publication. Reopen observes respectively H0, H1 and H1. A failed call alone
cannot distinguish those outcomes. The facade does not claim no commit, retry the edit or
provide durable idempotency from TransactionId. No cancellation/async API or new exception
hierarchy is introduced. Public uncertain-outcome result design remains open.

## 3. Qualification

ScalarEpochFacadeTests runs in the existing friend IntegrationTests assembly; it is an
internal consumer prototype, not a real external public consumer API compatibility test.
21 new cases cover H0/H3 migrated read/commit/reopen, old values and stale conflicts;
snapshot/transaction lifetime after owner disposal; legacy/immutable profile refusal;
expected store/epoch/document mismatch even with occupied admission; argument/policy errors;
contention/corruption and released admission; three unacknowledged commit boundaries;
fixed-head backup/independent restore; and explicit native policy. Reflection checks ensure
the facade/transaction stay invisible and no ScalarEpoch public type is exported.

Native policy executes a commit on Linux. The Windows branch proves unsupported-policy
rejection; it is not native directory-flush execution. No physical power-loss, real ENOSPC
or production filesystem/controller certification follows from these cases.

[Results](m2-scalar-epoch-facade-results.json) distinguish new cases, focused coordinator/
cutover/restart/compatibility regressions and retained earlier broad/fault reports. Catalog
978 is the prior 957 plus 21 and is not a new full run. All frozen binary hashes and existing
formats remain fixed. Formatting and strict documentation are checked before handover.

## 4. Remaining Gates and Next Work

PA1's internal runtime prototype is implemented; complete PA1 public signature/diagnostic
review and actual consumer qualification remain open. No public exposure, routing or release
is enabled. HA1/HA2 actual host/external writer exclusion/restart evidence, REL archived
readers/platform/release approval and all reclamation remain open; CanReclaim=false.

Next PA2: prototype a separate internal administrative facade for bounded verification,
independent restore and legacy migration with explicit destination/publication outcomes.
Preserve source/artifact histories and distinguish an acknowledged result from possible
publication after failure; do not infer routing authority or invent a durable receipt codec.
Keep public API shapes provisional until all relevant release gates are satisfied.
