# M2 Mutable Epoch Feature, Commit and Recovery Contract

## 1. Status and Initial Scope

Behavioral design per [ADR-012](../ADR-012-mutable-epoch-feature-and-recovery-contract.md).
ET1-ET3 profile/authority codecs and compatibility proof are now implemented in
[ADR-013](../ADR-013-epoch-profile-and-authority-codecs.md). [ADR-014](../ADR-014-admitted-empty-chain-epoch-coordinator.md) adds an internal admitted
empty-chain coordinator and transaction lifetime contexts. ADR-015 implements internal scalar
commit; ADR-016 implements internal redo and narrow uncommitted-tail recovery. Public mutable
APIs, epoch backup/migration and reclamation remain unavailable.
The current public ReadOnlyEpochDatabase remains an immutable sequence-zero reader.
Existing format-1 transactions/backup and all versioned fixtures are unchanged.

The first mutable experiment keeps one document and one nonempty text or ordinary
attribute replacement per transaction. Empty attribute values are allowed; namespace
attribute changes, empty text requiring removal, insertion/deletion, structural/order
changes, multiple targets and read-your-writes queries are excluded. Preserve the
existing XML character/value bounds. The initial retained chain is limited to 10,000
commits with the existing 64 MiB file / 1 MiB strict UTF-8 string / metadata limits.
No checkpoint-based skipping, base/WAL truncation, reclamation or reduced-history backup.

## 2. Explicit Feature Profiles

| Profile | FORMAT | Required reader / writer | Recovery | Feature bits | Entry behavior |
|---------|--------|--------------------------|----------|--------------|----------------|
| Implemented immutable epoch | BXDB 2.0 | 2 / 2 | 1 reserved | 1: admission | ReadOnlyEpochDatabase, complete SNAPSHOT at sequence zero; no transactions |
| Internal mutable epoch | BXDB 2.1 | 3 / 3 | 2 | 3: admission + scalar WAL | Internal EpochScalarCoordinator; recover full chain before reads |

The proposed profile keeps the 99-byte FORMAT structure and offsets from the immutable
metadata contract: flags=1, nonzero StoreId/EpochId/document, required contracts and
feature mask, plus envelope checksum. Values above are an exact recognized tuple, not
an open-ended minimum comparison. Unknown major/minor, feature bits, recovery contract,
flags or inconsistent combinations fail before creating writer locks, control files,
reader identities or other runtime state. Parsing bytes is not granting write capability.

Profile parsing returns identity plus capabilities; each entry point must explicitly
require its own recognized profile before admission. A generic parser being able to
read a profile does not make the immutable reader capable of opening it. No fallback
from a failed mutable open to an immutable/base reader is permitted.

FORMAT/EPOCH/admission are immutable for an epoch. BXEP/BXEA continue binding identity
and the full FORMAT digest; their existing binding layout can be reused for a newly
created profile. Never rewrite the current immutable root's FORMAT or replace its
admission inode. New mutable roots use fresh epoch identity; source roots remain intact.
A minor profile number here is not a promise of automatic forward compatibility.

Preserve today's format-1 and immutable-epoch binaries before changing parsers. Test
both against the candidate mutable profile in separate processes/load contexts. The
immutable reader must reject even a new root with no commits, and a rechecksummed
unknown requirement must not trigger a fallback. Any future materialization directory
also carries major-2 FORMAT, never a nested M1 FORMAT or an independent admission root.
Generation directories lack root BASE/CONTROL/admission and must fail public root open
without being adopted. Archived pre-lease binaries are still unavailable: do not turn
this new compatibility evidence into a claim that complete C1 has passed.

## 3. Proposed Root and Record Semantics

```text
<root>/FORMAT, EPOCH, .epoch/admission.lease
<root>/BASE, documents/<document>/, fragments/     # Immutable sequence-zero materialization
<root>/.transactions/
  CONTROL                                       # Immutable epoch/base authority
  writer.lock                                   # Exclusive coordinator OS handle
  CURRENT                                       # Published prefix, never sole authority
  readers/<sequence-D20>.lease                   # Stable epoch-bound generation identities
  wal/<sequence-D20>.wal                         # Full retained chain 1..H
  generations/<sequence-D20>/FORMAT, GENERATION, documents/, fragments/
  staging/<operation-guid>/                      # Unpublished; never a recovery root
```

Record roles below now have frozen internal codecs and independent fixtures in
[M2_EPOCH_AUTHORITY_FORMAT_V1.md](M2_EPOCH_AUTHORITY_FORMAT_V1.md). Runtime publication and recovery are now implemented internally through ET6;
ET7 classification and local ET8 native qualification are recorded; public access remains pending.
Require bounded checksummed envelopes
and exact canonical names before any record is used as authority. Do not reinterpret legacy BXWL/BXHD/BXTC/BXRL bytes.

Each authority/reader record has a common binding: StoreId, EpochId, DocumentId, complete
FORMAT digest and base-manifest digest. All identities agree with FORMAT/EPOCH/admission
and immutable base. Digests are SHA-256 of complete referenced files, not decoded bodies.

| Role | Codec magic | Additional required semantic fields |
|------|-----------------|-------------------------------------|
| BASE | BXEB | Sequence zero; base manifest digest; explicit root role |
| CONTROL | BXEC | Sequence zero; BASE record digest; supported scalar/recovery contract |
| CURRENT | BXEH | Published sequence; corresponding manifest and WAL digest (zero WAL digest at zero) |
| WAL | BXEW | Nonzero sequence; nonempty unique TransactionId; NodeId/value; predecessor/result manifest digests; preceding complete WAL digest (zero at sequence one) |
| GENERATION | BXEG | Sequence; expected predecessor/result manifest digests; complete WAL digest; materialization role |
| Reader identity | BXER | Pinned sequence and expected manifest digest; immutable lease identity |

BASE/CONTROL must validate before creating runtime files or acquiring the writer lock.
Admission must already be held before selecting/validating data or recovery authority.
CURRENT may be absent in a recoverable publication window; reconstruct it only from
the full verified chain and checked publication witnesses. A present invalid or
inconsistent CURRENT fails closed. Absence never permits ignoring complete WAL. Common
bindings prevent mixing same-numbered files from different epochs/profiles/bases.
Transactions capture epoch identity, base sequence and base manifest in memory; validate
all three under coordinator selection before staging any commit data.

## 4. Admission and Lock Ownership

Use one order: shared epoch admission, exclusive writer ownership where needed,
coordinator gate, then generation identities in ascending sequence order. All OS lock
acquisition is nonblocking; contention returns without creating a wait-under-gate cycle.
An operation must not first take the gate and then wait for admission.

Opening the future coordinator acquires its own shared admission, validates root role,
then takes writer ownership and performs recovery. Initial scope retains a single
coordinator across all reads/writes, matching the format-1 model. There is no concurrent
independent read-only mutable-head selector that trusts CURRENT without recovery.

BeginRead/BeginWrite first acquire an independent shared admission child outside the
coordinator gate. Under the gate, check owner availability, select the verified head and
acquire its shared generation identity before exposing a snapshot/transaction. If disposal
races after the child is acquired, release that child's handles and fail. Generation
identities are published once through the storage seam and never replaced or removed.
A transaction owns protection until commit completion, rollback or disposal; failure must
not release another snapshot's protection. A disposed coordinator cannot accept commits,
but disposing it cannot invalidate already-returned snapshots. Thread confinement remains.

A maintenance session is separate: acquire exclusive epoch admission, then writer
ownership, then any maintenance gate/generation identities. A live coordinator's own
shared admission blocks it even when idle. Failed exclusive admission does not grant
partial maintenance permission. After process exit reacquire all handles and revalidate
identity; never treat saved lease files or previous-process ownership as active ownership.
This protocol adds no maintenance mutation or deletion method.

## 5. Scalar Commit and Publication

1. With operation admission and writer ownership, enter the coordinator gate. Reject
   stale epoch/base sequence/manifest, invalid node/kind/value or unavailable owner
   before writing. A validation conflict is not a persistence fault.
2. Build a complete uniquely staged generation: major-2 FORMAT, unchanged structural
   IDs/order/namespace topology, repacked touched fragment, copied untouched fragments,
   directory and manifest. Compute the exact result manifest digest.
3. Encode the epoch-bound WAL in memory and compute its digest; write a staged GENERATION
   descriptor binding that WAL and predecessor/result. Validate the full staged
   materialization and flush files plus directory entries according to the selected policy.
4. Create canonical WAL N with CreateNew, write the bounded record, flush file content
   and synchronize WAL directory before publishing a generation. No later record may
   overtake an incomplete predecessor. A persistence error faults the coordinator.
5. Rename the stage to generations/N without overwrite, synchronize both rename parents,
   and require the final descriptor/materialization to agree with the committed WAL.
6. Write/flush a temporary CURRENT for N and atomically replace the selector; synchronize
   the parent. Install the verified in-memory head under the gate and acknowledge N.
   Release transaction-owned protection according to its completion contract.

A complete valid WAL is recoverable commit authority even if no response was delivered.
A kill during a write may leave old state or a complete new record; never promise an
unflushed write cannot survive. Acknowledgment occurs after required publication barriers.
ProcessCrash remains the default; FileAndDirectoryFlush is explicit Linux-only without
silent fallback. Policies are per session, not a persisted hardware SLA. Preserve the
existing distinction between injected disk-full errors and real capacity/power-loss tests.

If any persistence operation fails, stop using the owner and reopen. Do not automatically
retry the replacement: it can already be committed. TransactionId uniqueness detects
chain duplicates; it is not a caller-facing idempotency-key API or retry result service.

## 6. Recovery and Failure Classification

After profile/root validation, shared admission and exclusive writer ownership, validate
base plus BASE/CONTROL, then scan all canonical WAL names in order. Verify framing,
checksum, limits, common bindings, unique transaction IDs, exact sequence, predecessor
manifest/WAL digests and scalar semantics. A complete invalid record anywhere fails
closed; never skip a bad record to find a later plausible head.

Require each existing generation to match its epoch-bound descriptor, WAL, manifest,
directory and all fragments, and the target scalar to equal the recorded value. Rebuild
an absent generation from the verified predecessor and logical operation in new staging;
require exact recorded manifest digest before publishing. Do not rewrite a present
corrupt generation or stable identity that a snapshot may still use. Recovery itself
may be interrupted; repeated recovery must reproduce the same verified head.

An incomplete-tail candidate must have supported framing: all available magic/version
prefix bytes agree, a complete header declares bounded lengths and the physical file
is shorter than that declared complete envelope. An invalid header, unsupported version,
excess/trailing bytes or a complete bad checksum is corruption, not a discardable tail.

Validate every canonical published generation as a witness, including sequences beyond
the WAL prefix. A published generation's WAL digest is not enough to invent a missing
WAL or commit, but it prevents treating that missing/torn WAL as harmless. Unknown names,
unbound roles, wrong epochs or unexplained published generations fail closed. Retain
unpublished staging without adopting it as authority.

| Observed state | Required result |
|----------------|-----------------|
| Intact base/control, no WAL/publication | Select sequence zero |
| Complete valid WAL N, no generation/current N | Validate semantics, redo exact N, publish recovered head |
| CURRENT is an older verified prefix | Recover through the latest complete contiguous WAL; do not return stale prefix |
| CURRENT references a missing/invalid record or wrong hash/epoch | Fail closed |
| Present corrupt CURRENT | Fail closed; do not silently substitute base |
| Missing generation with valid WAL/predecessor | Redo exact materialization; never change IDs/order |
| Present corrupt generation or mismatched descriptor | Fail closed without overwrite |
| Missing/partial WAL with a published generation witness or later WAL | Fail closed; witness is not a substitute WAL |
| Physically incomplete final WAL, no later WAL and no CURRENT/generation/other publication witness for it | May discard only that uncommitted tail after canonical path checks and required directory barrier |
| Complete invalid final WAL | Fail closed; a checksum error is not an incomplete tail |
| Unpublished stage or temporary selector only | Retain/ignore it; never infer a commit or promote it by directory name |

Only the narrowly classified physically incomplete uncommitted tail may be removed;
this is not committed-history reclamation. CURRENT must match the validated hash at its
sequence and supplies a lower-bound publication witness. There is no guarantee of detecting
arbitrary simultaneous destruction of all WAL/publication witnesses; state that trust
boundary rather than claiming redundancy proves protection against all media loss.

## 7. Compatibility, Backup and Migration Boundaries

Current immutable 2.0 roots/SNAPSHOT remain unchanged and readable. They are not upgraded
in place. New mutable roots must be created and independently verified before explicit
application routing; the original root stays available for existing readers. Data-history
migration requires a later implementation that proves original sequence H, exact base and
all retained operations/IDs/values against independent full recovery. Do not reduce a
transactional source to its sequence-zero base or silently renumber history.

The current format-1 backup artifact/restore and immutable epoch reader do not support
the proposed mutable profile. Reject unsupported input before writing output artifacts;
no mixed-profile backup, fallback export or implicit feature downgrade. Epoch-aware
backup must own admission and capture a verified fixed head under coordinator exclusion
in a separate slice. Checkpoint optimization and retirement remain later gates; all base,
WAL, generations and stable identities are retained by initial mutable recovery.

## 8. Acceptance Gates and Next Implementable Slice

| Gate | Required evidence before shipping that behavior |
|------|------------------------------------------------|
| ET1 | Exact profile tuples; independent descriptor/binding fixtures; all truncations and rechecksummed unknown fields rejected; no existing bytes change |
| ET2 | Freeze current immutable-reader bytes before parser changes; frozen format-1 and immutable readers reject mutable profile/root/generation opens before mutation |
| ET3 | New epoch-bound control/WAL/current/generation/reader codecs with bounded canonical paths, independent fixtures and cross-epoch/base/role substitution rejection |
| ET4 | Fresh admitted mutable coordinator opens empty chain; lock-order/raced disposal tests; snapshots/transactions retain independent handles across owners/processes |
| ET5 | First scalar commit/reopen matches exact ID/order/value/URI parity; stale transactions reject without writes; immutable old readers keep old uncached values |
| ET6 | Every write/flush/close/rename/barrier fault before/after, real partial writes, process kills and lost acknowledgment recover verified old/new state; owners fault on persistence errors |
| ET7 | Full recovery classification matrix above, including published-generation witnesses, foreign epochs, gaps, corrupt CURRENT, duplicate transaction IDs and repeated interrupted redo |
| ET8 | Windows ProcessCrash and native Linux stronger-policy evidence with actual supported failure model; no physical durability or ENOSPC overclaim |
| ET9 | Separate fixed-head epoch backup and full-history migration/cutover parity before those APIs are enabled; retain original roots and all history |

ET1-ET3 are implemented and evidenced for the bounded codec/compatibility slice in
M2_EPOCH_AUTHORITY_VALIDATION.md. No public mutable open or scalar commit/recovery API is enabled.
ET4 internal empty-chain ownership is now implemented and evidenced in
M2_EMPTY_EPOCH_VALIDATION.md, including actual snapshots and transaction contexts.
ADR-015 now adds internal ET5 scalar staging/conflict/commit and complete-history reopen.
See [ET5 implementation](M2_EPOCH_SCALAR_COMMIT.md) and [ET6 recovery](M2_EPOCH_RECOVERY.md).
ET6 publication-fault/redo tests and [ET7 classification](M2_EPOCH_CLASSIFICATION_VALIDATION.md)
are implemented; [ET8 local native durability qualification](M2_EPOCH_NATIVE_DURABILITY_VALIDATION.md)
is now recorded.
[ADR-017](../ADR-017-epoch-full-history-backup-and-independent-restore.md) now accepts ET9
[backup/restore design](M2_EPOCH_BACKUP_DESIGN.md). ET9-A now implements the
[frozen metadata codecs](M2_EPOCH_BACKUP_FORMAT_V1.md), and ET9-B now implements
[internal capture and two-oracle verification](M2_EPOCH_BACKUP_CAPTURE.md). ET9-C now adds
[independent restore](M2_EPOCH_BACKUP_RESTORE.md) and ET9-D fault qualification.
Migration runtime, complete C1-C3 and retirement R1-R3 remain pending. Nonempty histories are still
rejected by the ET4 prototype; ownership contexts are not a Commit API.

*Last updated: 2026-10-27*


Migration design update (2026-10-27): [ADR-018](../ADR-018-full-history-legacy-migration-and-cutover.md) and
[MG1-MG5 acceptance criteria](M2_EPOCH_MIGRATION_DESIGN.md) now specify sealed
legacy-backup conversion, four verification oracles, fresh epoch authority and separate
migration provenance. Cutover requires an operator-held write freeze, exact source and
candidate freshness checks and explicit routing; original roots/history stay intact.
ET9-D backup/restore qualification is complete for its recorded scope. No migration codec,
runtime converter, route switch or retirement is implemented. Next: MG1 codecs/fixtures.

The original ET9 migration/cutover requirement remains open under ADR-018 MG1-MG5 even
though ET9 backup/restore subgates A-D are qualified. Complete C1-C3 and retirement remain
independent; do not interpret completion of backup subgates as completion of migration.
