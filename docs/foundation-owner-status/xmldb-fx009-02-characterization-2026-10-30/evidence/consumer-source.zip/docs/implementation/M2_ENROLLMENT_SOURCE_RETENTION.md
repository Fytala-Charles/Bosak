# EF1 Retained Legacy-Source Lifetime

Date: 2026-10-29. Internal source-only implementation under
[ADR-033](../ADR-033-retained-source-exclusion-and-first-enrollment.md).
No authority journal, append, prepared writer, route or application admission is added.

## 1. Actual Registration and Native Identity

MigrationSourceFreeze.RetainForEnrollment requires the actual live source owner, active freeze
and its exact registered nonnull sealed capture. The source gate serializes registration,
closing, arming and release. A freeze registers at most one real child; releasing it does not
make that freeze reusable. Wrong/absent capture, wrong thread, closed/faulted owner/freeze,
another child or an existing stop latch reject without replacing the current registration.
No capture, coordinator open, source recovery, lease reopening or file creation occurs here.

RetainedEnrollmentSource.InspectState checks the registered object/token and original source
writer stream/path identity, requiring a regular/single-link zero-byte admission role and
supported native root identity. It returns a cloned state/identity observation, not a data
history proof or write capability. A successful native inspection is required before Arm.
Full data/capture verification remains a later retained-preparation obligation in EF2.

Arm is source-local and memory-only under the source gate: require a live non-closing actual
owner/freeze, the same registered capture and prior native check; mark once and latch the
original source owner stopped. It is not the authority/parent/source atomic dispatch decision
specified for EF2 and does not grant permission to publish. Identity-inspection failure faults
the child and conservatively latches source stopped even before arm. There is no reset API.

## 2. Disposal and Completion

With an actual child, EmbeddedXmlDatabase.Dispose immediately makes ordinary operations
unavailable but leaves the exact original writer FileStream open. Freeze disposal rejects new
borrowing/retention immediately while keeping its mutation token active until actual drain.
No-retainer owners preserve ordinary immediate close; ordinary borrowed preparation is unchanged.

A pending child cannot inspect or arm after owner/freeze closure. An already armed registered
child may inspect its retained original stream/state after wrapper disposal; public methods
still reject. This is an internal admitted path, not resurrection or reopening of a public owner.
All inspection is synchronous under the source gate, so owner close cannot pass its actual I/O.
Children/freeze stay caller-thread confined; owner Dispose remains safe from another thread.

Child Dispose completes exactly once. A closing owner closes the original stream at final
actual drain; a live owner continues to own it. If freeze disposal was requested, its old token
may clear after successful drain. An unarmed, nonfaulted child allows that explicit release
request to restore the earlier source behavior. An armed or faulted owner keeps its stop latch.

EnrollmentOwnershipStatus separates Owned, RetainedClosing, Released and Unknown. Released
means confirmed close of this managed original stream, not global ownership/reader absence.
WhenEnrollmentOwnershipReleased observes that actual close. A narrowly internal test close
seam can fail before/after delegation; returning without closing the original safe handle is
also unconfirmed. On close error keep the logical child, report Unknown/ReleaseUnknown and
fault completion. Do not retry close, rearm, claim definitely held/released or resume mutation.

## 3. Source Stop and Compatibility

The original live owner's stop latch blocks new and pending commits, checkpoints, recovery
anchors, new freezes/retentions and backup publication. An active child blocks backup even
before arming; this is opt-in because ordinary MG5 deliberately permits capture under freeze.
Read-only operations on a live owner and independently owned snapshots retain existing behavior.
Retained state never proves reader absence and never authorizes history deletion.

The latch is memory-only on its original owner. An explicit new owner after actual release
is not fenced by it, and process exit loses it. Host-controlled ingress/executor/publisher
exclusion remains mandatory and unverified by EF1. No format/profile, public API, durable
fence, public epoch mutation, source replacement or reclamation is introduced. Keep every
source/candidate/WAL/journal history and CanReclaim=false.

## 4. Next Gate

EF2 integrates a distinct retained first-enrollment preparation, exact owner-bound authority
mode and atomic authority -> parent -> source admission. Existing borrowed preparations cannot
be upgraded. It must transfer actual execution ownership so caller disposal cannot release a
running operation. EF2 still performs no authority output. EF3/EF4 later implement/qualify the
one-frame terminal stopped writer, persistence uncertainty and process boundaries.

EF1 Arm takes only the source gate. EF2 must not simply call a blocking source-gate
acquisition while holding authority/parent lifetime gates: ordinary source inspection can
hold that gate for I/O. Its combined admission must use nonblocking acquisition/refusal or
an equivalently qualified state-gate protocol, then preserve the specified lock order and
actual registrations. No callback or long I/O wait belongs to the combined arm decision.
