# M2 Internal ET6 Epoch Recovery

Date: 2026-10-27. Decision: [ADR-016](../ADR-016-internal-epoch-redo-and-publication-faults.md).
This extends [ET5](M2_EPOCH_SCALAR_COMMIT.md) using unchanged
[authority bytes](M2_EPOCH_AUTHORITY_FORMAT_V1.md). Public mutable access remains unavailable.

## Preflight under ownership

Open holds shared explicit ScalarWal admission and exclusive writer ownership before
EpochScalarRecovery runs. Verify base and BASE/CONTROL first. Bound and sort canonical WAL
names; validate supported complete envelopes, epoch/base/role, sequence, unique transaction
IDs, predecessor WAL/manifest digests and one-scalar semantics. Never skip a bad complete
record to find a later plausible head. Published generations must bind an intact record,
match FORMAT/descriptor/manifest/directory/fragments and exactly project base metadata and
all preceding scalar values. A missing earlier generation does not excuse later corruption.

Validate all generation names, present CURRENT and stable reader records against the intact
WAL prefix before recovery mutations. CURRENT must match the manifest and WAL at its
sequence. A missing or lagging pointer is recoverable; a corrupt present pointer is not.
Stable reader identities are publication witnesses and must never be replaced or unlinked.

## Deterministic redo

For each absent generation in order, synchronize its intact WAL and WAL directory through
the storage seam, open the verified predecessor under admission, and build a fresh
GUID-named staging materialization. Require exact recorded result-manifest digest. Write
the WAL-bound GENERATION descriptor and validate complete files and exact scalar transition
before publishing. Rename without overwrite, synchronize both parents and publish/reuse the
stable reader identity. Never rewrite an existing corrupt generation or repair a stable identity.

After complete history validation, atomically publish CURRENT only when absent or lagging.
Publish/reuse base/head reader identities before returning an owner. All recovery writes,
flushes, closes, renames, deletion and directory barriers use ITransactionStorage. Faults
return no open owner and release admission/writer handles. New staging may remain; repeated
recovery rebuilds in fresh staging and validates already-published generations.

## Incomplete-tail classification

A supported incomplete final append has a matching available BXEW/envelope-1.0 prefix;
when its header is complete, body length is bounded by the scalar layout/string limits and
physical length is below the declared envelope size. Available common-binding/role/sequence
bytes must match the expected epoch and position. Empty and short supported prefixes may
represent interruption immediately after CreateNew. Invalid/unsupported header, excess
bytes and a complete checksum failure are corruption.

Removal is allowed only for the final record and only if no later WAL, published generation,
CURRENT or stable reader identity refers to it. Preflight excludes all such witnesses
before storage.DeleteFile and a WAL-directory barrier. Failure before/after deletion is
safe to reopen: it either repeats classification or finds the already-removed uncommitted
append. Committed WAL/base/generations and stable identities are never removed.

## Failure and lifetime behavior

A live owner faults on commit persistence failure and requires reopen; old snapshots keep
their independent epoch and generation handles and uncached data. Returned commits have
completed publication; an exception can still leave a committed full WAL/new state.
No retry/idempotency service is implied by transaction IDs. BeginRead does not redo or
remove files; it revalidates complete owned selection and faults on unexpected damage.

This implementation retains full history, private failure debris and a 10,000-record
limit. It changes no public API or profile/authority byte layout. It performs no epoch
backup/migration, checkpoint skipping, committed-history deletion or WAL-prefix truncation.
[ET7 now qualifies the adversarial classification matrix](M2_EPOCH_CLASSIFICATION_VALIDATION.md);
ET8 broader platform evidence,
ET9 backup/migration, archived reader C1-C3 and retirement remain pending. Native Linux
execution is filesystem evidence, not physical power-loss or real capacity-exhaustion proof.
