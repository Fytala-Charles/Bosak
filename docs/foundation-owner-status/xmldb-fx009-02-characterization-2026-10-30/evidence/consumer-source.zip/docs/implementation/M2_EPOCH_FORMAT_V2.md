# M2 Epoch Metadata Format 2.0 and Admission Identity 1.0

Implemented internal contracts per [ADR-010](../ADR-010-mandatory-epoch-format-and-admission-primitives.md).
Metadata-only fixtures remain unsupported as XML databases. ADR-011 now adds a separate
read-only data API requiring SNAPSHOT and validated XML metadata; legacy import/read/write/
backup entry points remain format-1-only. No old format/fixture bytes change.

## Mandatory FORMAT: BXDB 2.0

Exactly 99 bytes: the usual 12-byte header, 55-byte body, then SHA-256 over header/body.
Header: ASCII BXDB, little-endian u16 major=2, u16 minor=0, i32 body length=55. Decode
requires exact size, magic, version, body length and SHA-256 before fields are read.
The generic format-1 BinaryEnvelope decoder is unchanged and rejects major 2.

| Absolute byte offset | Field | Encoding / accepted value |
|----------------------|-------|---------------------------|
| 12 | Mandatory flags | u8 = 1 |
| 13 | StoreId | 16 bytes, .NET Guid.ToByteArray order; nonzero |
| 29 | EpochId | 16 bytes, same order; nonzero |
| 45 | DocumentId | u64 little endian; nonzero |
| 53 | Required reader contract | u16 little endian = 2 |
| 55 | Required writer contract | u16 little endian = 2 |
| 57 | Reserved recovery contract | u16 little endian = 1 |
| 59 | Required feature bits | u64 little endian = 1; bit 0 admission |
| 67 | Integrity digest | 32-byte SHA-256 over bytes 0..66 |

Required contract fields are exact allowlists in this primitive, not a promise that an
XML reader/writer already implements them. Unknown major/minor, flags, requirements or
bits are rejected even when their envelope digest is valid. StoreId/EpochId/document
must be bound before admission. No arbitrary filesystem paths occur in the descriptor.

## Bound Identity: EPOCH / BXEP and .epoch/admission.lease / BXEA

Each is exactly 116 bytes using the existing envelope major=1/minor=0, body length=72:
StoreId (16), EpochId (16), DocumentId (u64), SHA-256 of the complete 99-byte FORMAT (32).
The magic distinguishes epoch metadata from stable OS admission identity. All fields,
format hash, framing, checksum and trailing-data rules must agree. Missing/corrupt
identity files are never recreated by acquisition. Root plus the bound identities is
the admission namespace; copying bytes does not share an OS inode or lease ownership.

## Bootstrap and Admission

Internal bootstrap requires a new absent root and existing unlinked parent. Flush FORMAT,
then EPOCH, then the .epoch directory and admission identity in unique sibling staging.
Synchronize namespace entries through ITransactionStorage, rename staging to the final
root and synchronize both parents before acknowledgment. Failures can leave private
.xmldb-epoch-* staging; no discovery, adoption, overwrite or cleanup scan is provided.
No original store is removed. ProcessCrash is default; native Linux directory policy
can be requested explicitly without unsupported-platform fallback.

Acquire reads FORMAT/EPOCH, validates expected identity, rejects links/ancestors, then
opens admission.lease with FileMode.Open. Shared uses Read/FileShare.Read; exclusive
uses ReadWrite/FileShare.None without modifying bytes. Validate the 116 bytes through
that held handle; close on failure. Conflicts return immediately as IOException.
Closing the creating owner does not close forked handles. Exclusive admission cannot
fork ordinary shared readers. Stable identity inodes must never be unlinked or replaced.

Future data paths must acquire admission before coordinator selection and generation
leases. ADR-011 integrates admission into actual read-only snapshots; there is not yet an
epoch mutable coordinator. Current format-1 coordinators/snapshots/backup operations do not acquire
epoch admission. Maintenance here grants only exclusive admission to metadata fixtures,
not permission to delete history or migrate a store. CanReclaim remains false.

## Independent Fixtures and Legacy Evidence

Python struct/UUID/SHA-256 produced epoch-format-v2.hex, epoch-identity-v1.hex and
epoch-admission-v1.hex. Tests compare exact bytes, all truncation boundaries and
rechecksummed unsupported fields. Frozen format-1 Storage/Core DLLs and provenance in
tests/TestData/legacy-format1-reader independently prove four public Open rejection
paths without mutation. They predate epoch code, but are not unavailable pre-lease
releases. Preserve their hashes; do not regenerate them during a normal build.

*Last updated: 2026-10-27*

Read-only data update: [ADR-011](../ADR-011-admission-owned-read-only-epoch-snapshots.md)
adds SNAPSHOT/BXES and the explicit ReadOnlyEpochDatabase entry point. See the
[read-only contract](M2_READONLY_EPOCH_SNAPSHOT.md); FORMAT/EPOCH/admission bytes above
remain unchanged. Epoch transaction/recovery and history migration are still pending.

Explicit profile update: [ADR-013](../ADR-013-epoch-profile-and-authority-codecs.md)
adds generic recognition of the exact 2.1 ScalarWal tuple (contracts 3/3/2, features 3)
without widening default DecodeFormat or existing public admission/data paths. Existing
2.0 bytes above remain unchanged. See [authority format](M2_EPOCH_AUTHORITY_FORMAT_V1.md)
for the internal-only codecs; no mutable store is enabled.

ET4 update: [ADR-014](../ADR-014-admitted-empty-chain-epoch-coordinator.md) adds explicit
internal ScalarWal admission and profile-preserving forks; immutable defaults and all
wire bytes remain unchanged. Only complete zero-head roots are supported by that
internal prototype; public mutable operations and nonempty recovery remain unavailable.
