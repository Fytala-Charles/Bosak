# M2 Internal ET8 Native Durability Qualification

Date: 2026-10-27. Qualifies the existing
[recovery contract](M2_EPOCH_RECOVERY.md) and
[ET7 classification](M2_EPOCH_CLASSIFICATION_VALIDATION.md) on the recorded local platforms.
This step changes test infrastructure and provenance capture, not storage-engine behavior,
wire formats, public APIs, proprietary licensing, package pins or frozen reader bytes.

## Native fault delegation

FaultingTransactionStorage retains its default modeled stronger-policy behavior: it
advertises the requested ordering but delegates to LocalTransactionStorage(ProcessCrash).
An explicit useNativeDurability option instead constructs LocalTransactionStorage with the
exact requested mode. Tests assert EffectiveDurability against that actual delegate. Native
FileAndDirectoryFlush construction rejects unsupported hosts; no fallback is introduced.

The existing ET6 sweep bodies are reused through shared helpers, preserving the original
scenarios and labels. Twelve new Linux sweep cases inject before/after each observed
persistence call and real partial file writes for:

- Commits from sequence zero and a positive head, with an old uncached snapshot retained.
- Recovery from intact WAL without its generation, including repeated reopen and unchanged WAL.
- Unwitnessed incomplete-tail removal while retaining the committed prefix.

The native adapter delegates actual Linux directory open/fsync/close calls as well as file
flushes, renames and deletion. A before failure prevents the operation; an after failure
occurs after the real operation returns. This is application-boundary fault injection,
not injection inside a kernel fsync or device/controller. Reopen also requests native
stronger barriers. Partial writes physically write a prefix before throwing. The tail
partial variant has no eligible write positions when CURRENT is already correct; that
zero-position case remains explicit.

A separate Linux test calls SyncDirectory on procfs and verifies the real fsync errno
propagates, with only a before event and no weaker retry. This is a native syscall failure,
not injected disk-full, real capacity exhaustion or power loss. A platform-policy test
verifies Windows rejection before epoch mutation and distinguishes modeled/native delegates.

## Final platform evidence

| Platform | Storage | Xdm | Integration | Total | Failed / skipped |
|----------|---------|-----|-------------|-------|------------------|
| Windows / NTFS test temp | 352 | 27 | 112 | 491 | 0 / 0 |
| Ubuntu 24.04.4 / overlayfs test temp | 352 | 27 | 112 | 491 | 0 / 0 |

Fourteen new cases add twelve native sweeps, a platform-policy test and a kernel-error test.
On Windows the twelve Linux sweeps and kernel-error branch return with explicit output;
these thirteen passing test entries are not native Linux evidence. Windows executes the
unsupported-policy assertion and the full existing ProcessCrash/modeled suites. Linux
executes all native branches. The structured report records actual native fault positions
separately from retained modeled/process sweeps. Linux verifies **481 new native fault
positions** across twelve cases, yielding **2,579 total positions / 78 sweeps** including
the retained process/modeled cases. Windows retains **2,162 positions / 66 sweeps** and
executes no new Linux-native positions. The observed procfs failure is errno22.

SDK10.0.301; Windows dotnet host/runtime10.0.11 on Windows10.0.26300/x64, test temp NTFS.
Linux dotnet runtime10.0.9, Ubuntu24.04.4, WSL2 kernel6.6.114.1-microsoft-standard-WSL2/x64,
Docker overlayfs. The pinned SDK image ID is
sha256:ea8bde36c11b6e7eec2656d0e59101d4462f6bd630730f2c8201ed0572b295d5.
Source/cache mounts are read-only and container network is disabled. SDK/runtime evidence
comes from dotnet --info; the separate PowerShell host runtime is not the test runtime.

Final TRX: .tools/et8-windows-results and .tools/et8-linux-results.
[Structured evidence](m2-epoch-native-durability-results.json) includes observed sweep
counts, native kernel-error output and host/filesystem provenance. The active Linux runner
was inspected read-only to capture /tmp and /proc filesystem types; tools/test-linux.ps1
now records these plus OS release and /tmp-/work filesystem diagnostics for future runs.
Formatting and strict documentation checks pass. Seven known MINVER1001 warnings remain
because the checkout has no commit. Prior ET6/ET7 reports remain historical.

## Reproduce

```powershell
dotnet test Bosak.XmlDb.slnx -c Release --no-restore --logger 'trx;LogFilePrefix=windows' --results-directory .tools/et8-windows-results
$env:DOTNET_ROLL_FORWARD = 'Major'
& ./.tools/pwsh.exe -NoProfile -File tools/test-linux.ps1 -ResultsDirectory .tools/et8-linux-results
dotnet format Bosak.XmlDb.slnx --no-restore --verify-no-changes
& ./.tools/pwsh.exe -NoProfile -File tools/check-docs.ps1 -ProjectPath . -Strict
```

## Limits and next work

This qualifies the recorded local Windows ProcessCrash and Linux native-barrier failure
models. It does not certify physical power loss, real ENOSPC, arbitrary media destruction,
other filesystems/controllers, bare-metal Linux or remote CI. Simultaneous loss of all
journal/publication witnesses remains outside what the surviving base can establish.
No public mutable access, committed-history deletion or WAL-prefix truncation is enabled.

Next: ET9 fixed-head epoch backup design and its first bounded implementation slice.
Bind the epoch/profile/base/full retained WAL and selected head, verify through independent
full recovery, and restore to a separate root with fresh runtime epoch/provenance. Do not
reuse format-1 backup bytes or collapse transactional history to sequence zero. Full-history
migration, public mutable APIs, archived-reader C1-C3 and retirement remain separate gates.
