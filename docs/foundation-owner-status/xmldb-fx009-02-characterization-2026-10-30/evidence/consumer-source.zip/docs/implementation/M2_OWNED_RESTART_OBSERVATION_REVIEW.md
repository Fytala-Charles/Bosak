# SR2 Owned Restart Observation Design Review

Date: 2026-10-30. SR1 checkpoint b0c94bd is committed/pushed. This is a design/integration
review, not an implemented SR2 adapter. See [design](M2_OWNED_RESTART_OBSERVATION_DESIGN.md),
[ADR-035](../ADR-035-owned-stopped-restart-observation.md) and
[machine evidence](m2-owned-restart-observation-design-results.json).

## Findings and Dispositions

| ID | Inspected boundary | Disposition |
|---|---|---|
| SO1 | MigrationSourceFreeze.RequireRetentionBinding checks owner/token/capture reference; ClaimRetention is single-use | Preserve it; sealed artifacts are verified anew, never registered as the original capture |
| SO2 | RetainedEnrollmentSource.Acquire rejects the permanent stopped latch and requires a live capture | New restart-only child from a fresh explicit source owner, not a relaxed enrollment path |
| SO3 | CreateBackup calls RejectEnrollmentPublisher; standalone cutover freeze permits it | New child admission must permanently exclude all cooperating publishers as well as mutations |
| SO4 | Source Dispose defers original writer close only for the current enrollment child | Extend opt-in child accounting explicitly; retain the actual usable stream and once-only error semantics |
| SO5 | Generic authority Inspect opens/closes its own operation within the call | New paired observation mode spans unlocked source/capture verification and final rechecks |
| SO6 | Generic ReadOwned visits protected placement under its serializer | Preserve generic behavior; observation uses a separate unlocked-placement/authority-only phase boundary |
| SO7 | Legacy recovery republishes CURRENT even for valid positive-H history | Accept an explicit already-open source; prohibit hidden OpenCore/recovery in SR2 verification |
| SO8 | InspectRetainedBaseline hashes exact inventory bytes into PilotRootBinding.InitialHistoryDigest | Preserve that definition; require complete live-source matching before deriving actual baseline facts |
| SO9 | ER-003 shows logical release can fault after physical close | New exclusive open alone cannot mark prior release reconciled or justify cleanup retry |
| SO10 | SR1 accepts supplied facts and yields only inert results | Derive storage/retention facts in the adapter; keep actual host assertions separately scoped |

These findings identify required integration work, not new executed fault results. No existing
freeze, enrollment, source or authority code is modified in this step. Proposed names and
lifecycle rules remain internal design until each slice has new implementation evidence.

## Acceptance Review

The source child needs mutual exclusion with existing freeze/retained enrollment modes, an
atomic permanent stop, preexisting transaction Commit rejection and real deferred stream
close. Source state copying under a gate must not become a callback into capture/history I/O.
The paired scope needs exact actual operation registrations rather than counts supplied by a
caller. Closing can let admitted reads drain but prevents publication/consumption of live
owner-bound evidence. A later disposal error must invalidate the scope without rewriting a
previous legitimate point-in-time description as a historical receipt.

Observation must cover exact identity/head and protected-placement phases before and after
unlocked full-history checks. Empty reopen and valid unsupported later history stay stopped;
no initializer, new capture, prefix repair, adopted head or prior acknowledgment follows.
The expected/acquisition pin detects local change, not coherent offline rollback; supplied
fresh deployment/work facts are still an explicit external limitation.

The restart source primitive is sufficiently cross-cutting to warrant ADR-035 before code:
source Dispose, mutation/publisher admission and actual stream lifetime all participate.
SR2-A is the next bounded implementation. It alone must not be labeled completed SR2.
SR2-B/C observation/races and SR3/SR4 handoff preparation/output remain pending.

## Validation Scope

Read-only checks verify inspected-source fingerprints, both final SR1 C# hashes, ten frozen
vector/binary file hashes and retained execution-artifact hashes. Runtime/build/test inputs
remain exactly at b0c94bd. The prior 2,618 passing Windows cases across complete project runs
and 451 focused Linux cases are retained evidence, not fresh execution for this design step.
The initial one-case Integration restore timeout and its passing six-case/full-656 rechecks
remain separate; no clean initial full-command claim is made. No tests or fixtures are generated.

Strict documentation, actual hidden/link portability and diff hygiene pass for this step.
No public/format change, new runtime capability, persistent fence, source replacement,
work/routing admission or retirement is enabled. Preserve CanReclaim=false and all history.

SR2-A follow-up (2026-10-30): [source-only retention](M2_RESTART_SOURCE_RETENTION_VALIDATION.md)
adds actual source lifetime retention and permanent stopped admission. Original design evidence
remains historical. Full paired SR2 observation is not implemented; next SR2-B.
