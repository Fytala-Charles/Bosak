# SR2-C Owned Restart Qualification

Date: 2026-10-30. Checkpoint de5c9a4 through SR2-B is committed/pushed. This local step adds
qualification only under [ADR-035](../ADR-035-owned-stopped-restart-observation.md) and the
[SR2-B implementation](M2_OWNED_RESTART_OBSERVATION_VALIDATION.md). Product source is unchanged.
[Machine evidence](m2-owned-restart-qualification-results.json) binds exact test/worker inputs,
production fingerprints, raw TRX hashes, counters and executed/guarded markers.

## Native Identity Evidence

There are 22 cases for eleven same-byte substitutions at BaselineVerified and BeforeFinalValidation:
source writer; authority lock/metadata/log; parent owner/metadata/journal; and source, capture,
authority and parent directories. Each Linux body moves the actual retained role/root into a
named private fixture location and creates byte-identical replacement state at the trusted path.
It explicitly confirms the native identity differs while namespace shape/content remain plausible.
The original live handles still reference the retained inodes. Exact ownership/proof checks refuse
with InvalidDataException, preserve post-fault bytes/full inventory, fault the authority and keep
the source stopped. Old snapshot values remain readable. Scope disposal does not repair, adopt,
restore names or delete histories. Only fresh fixture teardown removes its owned test area.

Windows sharing prevents these open-file inode substitutions. Those 22 Windows rows explicitly
emit SR2C_NATIVE_GUARD and return; they are catalog passes, not native substitution execution.
All 22 Linux rows emit SR2C_NATIVE_EXECUTED. Existing suite guards remain in their prior scope.
These two observed unlocked boundaries do not prove every malicious namespace timing or fence
an uncooperative external writer. No new production provider, format or persistence seam is added.

## Disposal Schedules

Five ordered cases close all wrappers on another thread at each exposed acquisition/proof stage.
After source retention wins, all three actual owner roles stay exclusively held until the real
scope drains. Closed-before-source-admission is a separate safe endpoint. Every resulting
observation refuses, actual tasks complete successfully after drain and bytes/inventory stay exact.

One catalog case repeats twelve simultaneous final-phase close attempts. Each may return an
inert point-in-time ObservedEnrolledStopped description before closing wins, or refuse; none
grants work/write authority. Every actual operation drains, all roles release, snapshot data
survives and bytes/inventory remain unchanged. Observed/refused counts are recorded per run;
repetition does not enumerate every scheduler interleaving.

## Actual Process Boundaries

A new current-test worker branch opens actual source/parent/authority owners, initializes its
snapshot, then reports OPENED. Explicit legacy recovery can republish CURRENT before that
marker. Read-only observation measurements begin after it; those earlier opens are not hidden
inside the observer or certified write-free. Source prepare bytes are also compared with the
seeded exact files; byte-identical recovery is not represented as absence of I/O.

Two holder cases keep a successfully observed scope alive, with caller wrappers either live or
closed. A separate process cannot acquire its owners. Only actual scope drain plus explicit
wrapper disposal releases the three roles. The original process stays alive with an independent
old snapshot while a fresh observer succeeds; this proves snapshot survival, not reader absence.

Seven process-kill cases pause at actual Registered, SourceRetained, BaselineVerified,
BeforeFinalValidation and post-Observe/pre-delivery boundaries, with selected closed-wrapper
variants. Each repeats twice. Kill releases OS resources; it does not recreate a logical release
receipt. Fourteen fresh independent workers then perform only new stopped observations. A
complete frame/digest remains retained history, never replayed scope, initializer or old delivery
acknowledgment. Source/admin/authority/capture bytes and full inventory stay exact across kills
and fresh observations. The same first Enroll remains the only authority frame.

Two repeated independent-process races allow exactly one holder and one blocked contender.
No scope or snapshot is shared between worker threads/processes. Each qualified ten-case process
run launches 38 workers: six in holder cases, 28 in kill/fresh cases and four in owner races.
The 14 killed workers are included in that total. This is actual process termination and local
ProcessCrash policy execution, not physical power-loss, real ENOSPC or native strong-policy proof.

## Regression and Integrity

The final focused Windows run passes 189 cases (179 Storage + 10 Integration), including all
38 new catalog cases: 28 Storage and 10 Integration. Twenty-two are the explicit Windows native
guards above; sixteen new Windows bodies execute their qualification. Isolated Linux passes
394 focused cases (380 Storage + 14 Integration), including all 38 new bodies, all native
substitutions and the 38-worker process run. Xdm has no matching cases. SDK 10.0.301 on x64
overlayfs uses read-only source/cache mounts, no network and isolated outputs; seven Git-free
MINVER1001 warnings are expected. These are focused Linux cases, not a full Linux catalog run.

Initial executable storage/process runs pass within their own separately retained input scope.
Formatting/analyzers pass. All 2,752 Windows cases pass across complete project runs. The initial restore timeouts are
retained and pass focused plus complete Integration rechecks. Storage passes 2,059, Integration 666 and Xdm 27.
All 2,714 previous test IDs remain with exactly 38 new IDs (28 Storage + 10 Integration).
The initial full command fails its Published/normal restore process timeouts. All six restore
cases and the entire 666-case Integration rerun pass with unchanged 50-second limits. Retain
the failed artifact, infer no cause and do not label the initial full command green.

Fresh public metadata is unchanged at 95/95 entries;
ten frozen file hashes and unchanged production fingerprints verify read-only. Strict docs,
actual hidden/link portability and diff hygiene pass. Frozen fixtures and governed kit files
are unchanged. No fixture-generation scripts are executed.

## Next Gate

Next consolidate SR1/SR2 readiness and retained evidence before SR3 handoff preparation. Review
remaining host freshness/control assumptions, unsupported histories, required release uncertainty
and archived release gaps; qualification alone grants no next writer. SR3/SR4 preparation/output,
actual host/public/archive release and all source replacement/retirement/reclamation remain open.
Keep every history and CanReclaim=false. No public API, wire bytes or product runtime changes.

Readiness follow-up (2026-10-30): [consolidated SR1/SR2 review](M2_STOPPED_RESTART_READINESS_REVIEW.md)
verifies retained input/catalog evidence and separates current observation from future success-only
proof consumption and plan-child retention. Next SR3-A contract; no new writer is enabled.
