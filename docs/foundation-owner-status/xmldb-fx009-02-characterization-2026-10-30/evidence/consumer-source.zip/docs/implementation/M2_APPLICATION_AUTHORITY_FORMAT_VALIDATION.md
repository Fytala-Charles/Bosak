# EP7-B Application-Authority Specification Validation

Date: 2026-10-29. Specification and independent metadata examples under
[ADR-029](../ADR-029-separate-application-authority-journal-v1.md) and the
[version 1 contract](M2_APPLICATION_AUTHORITY_FORMAT_V1.md).
No .NET codec, journal writer, filesystem ownership or application authority is implemented.

## 1. Deliverables and Review Scope

The contract defines separate authority.lock/authority.meta/authority.log roles, exact trusted
scope/ID binding, 112-byte BXAM0001 metadata, 144+N BXAJ0001 frames, canonical bounded nested
TLVs, explicit wire mappings and complete-history transition rules. Metadata digest binding
prevents silently mixing frames with different configured metadata. Hashes are damage checks,
not authentication, anti-rollback, receipt or physical durability proof.

Review checked offset totals (80 metadata prefix + 32 digest; 104 frame prefix + N payload +
32 digest + 8 seal), network-order GUIDs versus little-endian integers, exact prior-head/owner/
selection matching, one immutable baseline/candidate, globally unique work IDs, retained counts,
unknown outcomes, owner transfer, terminal-observation contradictions and cumulative bounds.
No executable complete-frame/history validator or transition test coverage is claimed here.

Provisioning/commit rules require absent-root no-overwrite creation, continuous real ownership,
new child-mode integration, exact EOF append, file flush/readback before acknowledgment, faulted
paired admissions after uncertain output and stopped reopen with no repair. These are requirements
for EP7-C qualification, not implemented or observed storage traces. Work admission/execution is
still EP7-D. No extra role is added to the existing administrative host root or any store root.

## 2. Independent Metadata Vectors

The Python reference uses struct, uuid and hashlib without invoking or importing any .NET codec.
The two decoded binary vectors are exactly 112 bytes each; .hex files encode those bytes as ASCII.
Their pinned manifest is tests/TestData/pilot-authority-fixtures-v1.json. They are metadata-only,
not enrolled histories, full roots, backup/store artifacts or executable capabilities.

| Vector | Decoded bytes | SHA-256 of decoded bytes |
|--------|---------------|-------------------------|
| pilot-authority-meta-ascii-v1.hex | 112 | 01ba1f0ec326970000c545210045d8031036fa53859e1b1ba000bf389505d5ff |
| pilot-authority-meta-utf8-v1.hex | 112 | 5183793f7aeb034f7b5ec4c3ecdc4d99caa1fa8358e1786abcad7d5a9c99c26a |

Run `python tests/TestData/pilot-authority-fixtures-v1.py` for read-only checks. The optional
initial --create mode refuses any existing new fixture/manifest; normal checks never rewrite
pinned data. Preserve these hashes and all earlier frozen vectors/binaries independently.

13 Python unittest methods pass, covering both pinned examples, every short metadata length
and an extra byte, checksum corruption, resealed wrong magic/policy/flags/reserved/empty GUIDs,
foreign trusted IDs, all four configured scope keys, mixed-endian GUID rejection, UTF-8 byte
bounds/invalid canonical strings, and refused fixture overwrite with unchanged original bytes.
Subtests and truncation positions are not reported as extra top-level test cases. These checks
validate the independent metadata reference only; they do not qualify a future production codec.

## 3. Source and Regression Accounting

Existing production/test/sample C# and prior fixtures remain unchanged. Both EP7-A source hashes
match its recorded full-regression inputs. The prior fresh Windows run passed 2,013 tests (1,393
Storage, 593 Integration, 27 Xdm), including 119 EP7-A cases. That exact-code evidence is retained;
it is not relabeled as a new full-suite execution or format/runtime qualification in this step.
New files are documentation, the two metadata examples, their manifest and reference/check script.

Strict documentation, actual hidden/link portability, whitespace and all 13 independent
metadata-reference checks pass. Exact results are recorded in
[machine evidence](m2-application-authority-format-results.json). Linux's last attempted execution
was blocked by the unavailable Docker engine; no new Linux or hosted run is claimed. No package,
public signature, existing wire bytes, owner admission or mutable API changes are introduced.

## 4. Next Work

Implement the pure application-authority codec and complete-history validator before EP7-C
persistence. Add independent full-frame/history vectors plus malformed TLV/envelope, illegal
transition, cumulative bound, overflow and short-read tests. Metadata examples alone cannot
establish closure, accepted-work history or authority. Every decoded result remains stopped;
no I/O, callbacks, root creation, replayed work or write capability may come from the codec.

The audit/design/EP7-A/EP7-B work remains local/uncommitted on HEAD 4598346; no commit or push
was performed. Public/external-consumer/release, archived-reader provenance, physical power-loss/
real ENOSPC, hostile/global fencing and all retirement gates remain open. CanReclaim=false.
