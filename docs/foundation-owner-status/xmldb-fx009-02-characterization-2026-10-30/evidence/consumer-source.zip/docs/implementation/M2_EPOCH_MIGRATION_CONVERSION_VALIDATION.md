# MG3 Legacy Conversion Validation

Date: 2026-10-27. Internal runtime conversion only. See
[contract](M2_EPOCH_MIGRATION_CONVERSION.md), [ADR-018](../ADR-018-full-history-legacy-migration-and-cutover.md)
and [machine results](m2-epoch-migration-conversion-results.json).

27 new Storage cases cover:

- H0/H1/H3 every retained sequence/node/operation and exact manifest/directory/fragment
  bytes, namespace/URI/xml:base/Unicode values and empty ordinary attributes. Compare
  every destination WAL field and predecessor digest against original legacy operations.
- Exact provenance/header commitments and final returned store path; current public entry
  rejection; old uncached source readers and independent published-path snapshot lifetime.
- Repeated fresh identities, independent source/A/B branch writes, immutable artifact and
  unchanged initial-prefix migration.bin after later destination commits.
- Exceptions at all seven high-level checkpoints, absent versus complete unacknowledged
  publication, closed file handles, fresh retry with private debris and existing-path refusal.
- Five invalid source classes rejected before writes; three destination guards; observed
  source/transformed-byte mutations; coherently resealed BackupId/MigrationId substitutions;
  missing initial reader; actual native Linux strong policy and two Linux link branches.

Six new Integration cases run conversion in a new process: normal completion, Rebound,
OriginFlushed, BundleVerified, Published and ACK. Kills before rename leave no final path;
published/lost-ack bundles reopen repeatedly with exact H and support an independent next
commit while source, backup and initial origin stay unchanged. Unpublished paths can be
retried; existing published paths reject unchanged. Process probes use default ProcessCrash;
native-policy evidence comes from the separate actual Linux strong-policy Storage case.

Fresh filtered regressions cover 771 cases per platform (615 Storage, 27 Xdm, 129 Integration),
including all 33 new cases. The unchanged expensive 18-case EpochBackupFaultTests matrix
retains prior [ET9-D evidence](m2-epoch-backup-fault-results.json); 789 is the catalog count,
not a new unfiltered full run. Three new host-conditional branches return on Windows and
do not establish native execution there. Linux is the pinned isolated SDK/overlayfs runner
with read-only source/cache and no network. Record exact final status in the machine report.

Formatting, strict documentation and retained fixture hashes are checked. No existing
wire bytes/public APIs were changed; shared restore helper algorithms are unchanged.
Proprietary license/pins/disabled packaging remain intact. This gate does not prove full
MG4 fault coverage, real ENOSPC, physical power loss, archived-release compatibility or
safe application cutover. Public mutable/migration APIs, actual routing and retirement are
disabled. Next: MG4 exhaustive observed persistence faults and repeated interruption proof.
