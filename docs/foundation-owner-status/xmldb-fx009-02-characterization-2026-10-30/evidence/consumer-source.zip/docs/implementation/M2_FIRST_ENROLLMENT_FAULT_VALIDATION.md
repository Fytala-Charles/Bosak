# EF4 First-Enrollment Fault and Process Qualification

Date: 2026-10-30. Parent checkpoint bec0eee is committed/pushed. EF4 is subsequent local work.
Implements qualification under [ADR-033](../ADR-033-retained-source-exclusion-and-first-enrollment.md)
and the [first-writer contract](M2_FIRST_ENROLLMENT_APPEND.md). Production runtime code,
public APIs, authority/data formats and frozen fixtures are unchanged by EF4.

## Observed I/O Sweep

A successful real H=1 fixture records six actual append-seam call edges: Write before/after,
Flush before/after and ReadBack before/after. The observed frame is 387 bytes. Each edge is
faulted in its own fresh same-depth store; all 386 physically incomplete prefixes (1 through
386 bytes) are also written to the real retained FileStream and then interrupted by an injected
exception. One baseline plus 392 fault attempts yields 393 independent fixture attempts per
sweep. Attempts are not catalog test cases. Every request is checked against its own prepared
frame and the observed length/trace, avoiding a synthetic fixed frame-length assumption.

All fault outcomes are terminal/stopped Uncertain, even Write-before delegation: PossibleOutput
was already set before the seam. No receipt is inferred. Exact empty/prefix/full survivors and
all other source/capture/admin bytes remain unchanged after cleanup and read-only reopen.
Partial histories reject twice without truncation, repair or prefix adoption. Empty/complete
histories reopen read-only but cannot reserve an initializer or recreate acknowledgment.
Old real source snapshots remain usable. Each attempt retains all store history.

The adapter delegates real FileStream.Write, Flush(true) and ReadExactly. Partial injection
uses an actual prefix write and buffer flush; it is not a simulated successful full write.
This is ProcessCrash qualification only. FileAndDirectoryFlush is not accepted by this writer;
Linux execution of real flush calls is not a stronger-policy or power-loss certification.

## Closing and Native Identity

Three ordered cross-thread schedules close source/authority/parent wrappers while actual
Write, Flush or ReadBack is paused. The closing thread completes without waiting for journal
serialization, all real operations remain retained, and the append drains only after I/O.
Source freeze/plan thread confinement is preserved; those scopes are never shared with the
closing worker. Existing readers remain usable. These endpoints do not prove every interleaving.

Eight Linux bodies substitute actual inodes for owner, metadata, log or root, both before output
and after flush. Otherwise valid replacement bytes cannot substitute native ownership. Before
output refuses; after output is uncertain. Both preserve the exact invalid bytes and full file/
directory inventory without adopting or repairing replacements. Windows has eight explicit
host guards for these Linux unlink/rename bodies; those catalog rows are not native Windows
substitution execution. Existing Windows identity/sharing tests remain separate evidence.

## Repeated Process Boundaries

Twenty-one process cases each run twice: 42 independently killed publishers per focused run.
They pause at all eight append phases, all six seam edges, an actual 17-byte partial write,
returned-before-delivery and ACK delivery. Four cases also close all wrappers immediately after
arm, covering pre-release and released outcomes. The announced exact frame is inert correlation,
never reconstructed execution authority. Kill waits for actual exit before inspecting bytes.

The parent checks all three original owner roles. They remain excluded while actual execution
or live owners retain them; closing-wrapper Returned/ACK cases expose confirmed drain while
the publisher and old snapshot are still alive. Source/admin and sealed capture bytes and
inventories remain unchanged. Two fresh restart observations preserve authority bytes/inventory;
partial logs fail closed, and complete logs still have no in-memory confirmed receipt. No
restart replay, cleanup or work admission occurs. Returned-before-delivery proves the lost
acknowledgment gap without pretending an emitted ACK was absent.

A separate case repeats three simultaneous independent two-process starts (six workers).
Each process owns its own scopes. Exactly one acquires the original source, provisions/captures
and acknowledges one exact Enroll frame. The loser reports only actual source-admission I/O
failure, without reaching provisioning. The winner holds ownership until explicit release;
reopen remains read-only. These three runs do not exhaust all schedules.

## Counts and Integrity

New catalog cases: 12 Storage + 22 Integration = 34. Windows executes four new Storage bodies
and eight host guards; Linux executes all 12 bodies. Each process run uses 48 workers (42 killed
publishers + six racing publishers). Do not add dynamic fault attempts or process repetitions
to catalog totals. Exact final per-platform counters, traces, durations, source hashes and raw
TRX hashes are recorded in [machine evidence](m2-first-enrollment-fault-results.json).

Initial Windows focused cases and initial Linux cases pass after fixture setup corrections.
Broad isolated Linux passes 679 cases (603 Storage + 76 Integration), including
all 34 new catalog bodies and eight actual inode substitutions. Xdm has no matching cases.
The sweep records 393 actual attempts; its elapsed time is retained in machine evidence.
The fresh unfiltered full Windows command passes all 2,468 cases (1,785 Storage,
656 Integration and 27 Xdm) with no failures, skips or reruns needed in this attempt.
All 2,434 previous test names remain, with exactly 12 new Storage and 22 new Integration
cases. Eight new Windows rows are the explicit native-substitution guards.
The final Windows sweep records 393 attempts; exact elapsed time and trace are retained
in machine evidence. All test bodies and five runtime hashes remain unchanged. Two primary-constructor XML
parameter comments were added after test compilation; exact raw deltas and before/after
source hashes are retained in machine evidence. Final build/format checks verify the comments. Early development
checks caught xUnit assertion-style compilation errors and a fixture final-reader lease not
initialized before inventory capture; final setup creates that lease before the measured
operation. Assertions still compare complete inventories/bytes; runtime behavior was not changed.
Nonfinal runs are retained separately from final-source evidence.

The Linux runner uses cached pinned SDK 10.0.301, x64 overlayfs, read-only source/cache mounts,
no network and isolated outputs. Seven expected MINVER1001 warnings reflect Git-free copied
sources. No full Linux, ARM64, other allowed filesystem, real ENOSPC or physical power-loss
qualification is claimed. No frozen vector is regenerated. Governed documentation-kit files
and generation provenance remain untouched.

## Next Gate

Consolidate EF1-EF4 readiness and remaining host/restart boundaries before designing another
authority writer. Qualification does not enable general post-enrollment append, actual host
routing, application work admission, public APIs, archived release compatibility, persistent
fencing, source replacement or any retirement/reclamation. Keep CanReclaim=false and all
source/candidate/WAL/journal histories.

Readiness follow-up (2026-10-30): [consolidated review](M2_ENROLLMENT_READINESS_REVIEW.md)
verifies these artifacts and preserves their bounded scope. ER-002 preflight lock conformance
and ER-003 direct authority/parent close-error injection remain open before further writers.
