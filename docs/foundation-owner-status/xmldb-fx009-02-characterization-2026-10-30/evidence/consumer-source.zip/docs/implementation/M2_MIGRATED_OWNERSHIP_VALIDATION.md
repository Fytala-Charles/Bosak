# CA2 Migrated-Candidate Ownership Validation

Date: 2026-10-28. Scope: internal local ownership/lifetime evidence on real MG3 candidates.
No production storage code, wire formats, public API, routing or packaging changes.

## 1. Race Matrix

MigratedOwnershipTests builds real H0/H3 candidates and tests snapshot and transaction child
creation against owner disposal in child-first, owner-first and simultaneous schedules.
The 12 theory rows repeat 12 times each: 144 attempts per platform, comprising 48 per
schedule. The simultaneous case does not require or claim that both scheduler winners
occur; ordered rows establish both endpoints deterministically. Waits are bounded.

Successful children retain independent admission after owner disposal and still read the
captured value. A new coordinator can reopen and read while those children survive, but
exclusive maintenance admission must fail. Transaction children preserve identity/base
sequence, allow an uncommitted edit, and reject Commit after owner disposal; failed Commit
releases the snapshot. No edit is published. A losing creation must throw ObjectDisposedException
without returning a child. After child release exclusive admission must succeed.

Every attempt preserves source/backup/bundle file bytes, file/directory inventory and
candidate runtime physical file identities. The identity oracle shared with CA1 uses
Windows volume/file IDs or Linux device/inode values; frozen reader binaries are untouched.

## 2. Cross-Process Matrix

Four cases hold an uncached snapshot or transaction in a subprocess after its coordinator
has been disposed, then close normally or kill the holder. Parent-process exclusive epoch
admission and the exact H3 generation reader lease must remain excluded. A replacement
coordinator can reopen/read without disturbing the child. Graceful release performs a lazy
read after owner disposal; killing releases ownership without a successful read/exit claim.
After either exit, exclusive admission and all four generation reader leases are available.
Runtime identities, all file bytes and directory inventory remain unchanged throughout.

The ca2-hold CrashProbe command is test-only and cannot change configuration or routing.
No child creation is raced with disposal of that same child; the race is creation versus
coordinator disposal. No holder-exit result proves that uncooperative pre-lease readers are
absent. These cases are not physical power-loss or durability qualification.

## 3. Validation and Limits

[Machine-readable results](m2-migrated-ownership-results.json) record Windows and isolated
Linux focused runs: 16 new CA2 cases plus 24 CA1/synthetic compatibility cases. The CA1
matrix is rerun because its physical identity oracle was extracted into a shared test helper.
Prior broad MG5 and expensive fault-matrix evidence remain separately scoped. The catalog
is now 878 cases; no new unfiltered 878-case run is claimed. Formatting, strict documentation
and four frozen reader DLL hashes are checked before handover.

CA2 strengthens local C3 ownership evidence. Complete archived C1/C3, actual application
routing/external writer fencing/restart reconciliation, supported public APIs and broader
release qualification remain open. CanReclaim=false; retain every source and candidate
history and stable runtime identity. No retirement or source path replacement is enabled.

## 4. Next Work

Define the supported public API and host cutover contract before implementing real routing.
Specify ownership, writer stop/drain, route observations, unknown acknowledgments and restart
reconciliation, and distinguish caller attestations from enforced guarantees. Inventory the
actual host integrations and archived binary acquisition needs; do not invent a host or
turn MG5 modeled decisions into production routing. Changes to persistent cutover authority
or public APIs require an explicit design/ADR before implementation.
