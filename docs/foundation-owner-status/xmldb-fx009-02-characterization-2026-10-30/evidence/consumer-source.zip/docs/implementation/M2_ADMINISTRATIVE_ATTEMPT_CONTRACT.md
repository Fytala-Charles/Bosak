# Administrative Attempt Identity and Retry Contract

Date: 2026-10-28. Design under [ADR-020](../ADR-020-planned-administrative-attempt-correlation.md).
This specifies the internal attempt contract. RC1 preparation/claim and RC2 planned execution
and RC3 process/contention qualification are implemented internally; arbitrary caller IDs
and durable replay remain unimplemented. See [RC1 validation](M2_ADMINISTRATIVE_ATTEMPT_PLAN_VALIDATION.md) and
[RC2 validation](M2_ADMINISTRATIVE_ATTEMPT_EXECUTION_VALIDATION.md).

## 1. Identities and Binding

| Identity | Meaning and owner |
|----------|-------------------|
| Host request ID | Caller-owned business/workflow correlation; may group several attempts; not added to store provenance |
| Attempt ID | Fresh nonempty library-generated GUID for one physical dispatch; known before execution |
| Backup ID / inventory SHA-256 | Exact selected sealed input; same BackupId/H alone cannot establish unchanged bytes |
| Destination StoreId/EpochId | Fresh identities still allocated by the existing transform pipeline, not preassigned by preparation |
| MigrationId / RestoreId | Existing provenance role field that a future planned execution fills with its preknown attempt ID |

GUID generation is not authentication, a global uniqueness registry or a deduplication service.
A caller cannot set arbitrary provenance IDs through this contract. Legacy source descriptors
contain document/H/backup commitments and no invented source epoch IDs. An epoch source
also carries its actual store/epoch/document identity. Different roles never share a plan.

The immutable descriptive copy contains attempt ID, publication kind, canonical absolute
artifact path and bundle path, inventory SHA-256, source BackupId/document/H/optional epoch,
target ScalarWal profile and explicit durability policy. The bundle path is the requested
publication destination; returned store/ remains distinct. Do not include arbitrary transient
workspace names as reusable authority. Values are descriptive copies, with no mutable
inventory buffers or execution tokens. Names/signatures remain provisional.

A future descriptor-to-inspection helper supplies the pinned inventory, kind, bundle and
known attempt ID to PA3. It may add an expected destination identity only after that identity
has been independently learned/pinned; it does not fabricate one from the attempt ID.
Descriptors do not prove authenticity, complete source history or freshness after their creation.

## 2. Read-Only Preparation

Preparation requires explicit role, source, destination and options. It normalizes paths
using existing portable/unlinked/disjoint-root rules, requires an existing destination parent
and absent destination, and checks the bounded artifact seal/closure/hash/header context.
Pin original inventory bytes/hash and source identity, with an unchanged-inventory check
around preflight. It may read substantial bounded artifact data; no private clones, runtime
identities, coordinator Open, namespace writes or barriers are performed.

Preparation does not run both complete/full-redo oracles and cannot qualify a publication.
A logically invalid but well-sealed artifact may prepare and must fail later full proof.
The prepared plan stores the exact intent and a reference-bound owner token, and holds no
store leases or file handles. It is not a destination reservation, global writer fence,
source-inode guarantee or time-based freshness certificate. No expiration timestamp implies
safe execution; all execution checks are repeated.

The caller can obtain the descriptive copy immediately. If correlation must survive a crash,
the host must durably and access-safely retain it before dispatch using its own defined
persistence/ownership protocol. A failed host save means do not dispatch. This contract
implements no host ledger, serialization schema, fsync policy or authenticated descriptor.

## 3. Single-Dispatch State and Execution

| State / action | Required behavior |
|----------------|-------------------|
| Prepared | Immutable intent and preknown ID available; no effects or reservation implied |
| Null/foreign-owner plan supplied | Reject before consuming a valid plan or performing I/O |
| First dispatch through creating administration instance | Atomically consume Prepared before any execution filesystem I/O |
| Concurrent/repeated dispatch of the same plan object | Exactly one local claim; all others reject before I/O |
| Claimed execution returns normally | Acknowledged result uses that attempt ID and actual published store path |
| Any exception after claim | Plan remains consumed; outcome is uncertain even if a particular test observes no publication |
| Owner/process or executable plan lost | No reconstruction/rearming from a descriptor; inspect and reconcile |

An implementation may expose diagnostic Dispatched/Acknowledged/Uncertain states, but no
state after claim becomes Prepared again. Only pure ownership/shape checks precede claim;
mutable filesystem preconditions are rechecked afterward. A storage-policy mismatch or
wrong creating administration instance cannot repurpose the plan. A new administration
instance cannot execute a foreign plan even with equal option values.

The chosen pipeline must require exact original inventory commitment, role, canonical paths,
source selection and explicit policy before any output writes. Destination existence or
changed/linked/overlapping paths reject. Run the existing strict complete/full-redo proofs,
fresh destination epoch allocation, runtime validation and atomic two-role publication.
Use the attempt ID in the unchanged MigrationId/RestoreId field. Preserve all source/history
bytes and existing frozen BXEM/BXEO semantics. Do not open sealed input as a live root.

Successful pipeline return, including normal cleanup, creates an acknowledged receipt.
A callback/I/O/cleanup failure after rename can leave a valid candidate with no receipt.
Do not catch that failure and claim NotPublished, issue a successful receipt from inspection,
retry automatically, delete output or route traffic. Preserve original exception diagnostics
until the separate public result/exception contract is qualified.

Single-use is local to the opaque plan/creating instance. Different plans or processes can
race for the same target; there is no global path registry. Existing atomic no-overwrite
publication remains the final namespace guard. A host requiring one active attempt must
serialize/fence publishers itself. This contract adds no lock file or persistent root role.

## 4. Lost Acknowledgment, Observation and Retry

| Observed situation | Caller rule |
|--------------------|-------------|
| Failure/timeout after dispatch, prior executor may still run | Keep writers stopped; no retry, absence inference or descriptor replay |
| Known attempt and initial candidate match pinned artifact/role/destination | PA3 KnownOperationMatched observation; retain it as observed, not an acknowledged receipt or routing permission |
| Artifact matches but caller lost/never retained attempt ID | ArtifactMatched only; cannot infer ownership or assign the observed ID retroactively to the lost request |
| Existing publication has another ID/identity or changed/advanced history | Reconciliation; keep both histories; no overwrite or automatic rollback |
| No target observed while prior executor is active/unknown | NotObserved is inconclusive; the old executor may publish after observation |
| Prior executor proved completed/stopped/fenced, host owns dispatch, no target observed after that, input/paths still match | Eligible to prepare a new attempt with a new ID; old plan is never replayed |
| Matching existing publication but receipt was lost | Retain and reconcile the observation; execution still refuses existing destination |
| Restart with a retained descriptor | Inspect with known ID after establishing exclusion; cannot reconstruct executable plan |
| Restart without retained descriptor | Use artifact-only observations and explicit reconciliation; never manufacture a known request ID |

A completed synchronous call or awaited process exit can be relevant executor evidence;
a timeout, unlocked file, PID reuse or a lease probe alone cannot prove no publisher remains.
Actual host fencing/exclusion scope must include all publishing processes, queued work and
retries. Preparing another plan for another destination creates another independent attempt,
not an exactly-once recovery of the earlier request. Preserve the relation in the host ledger
if the host needs it. Never rewrite the old sidecar to assign a new attempt ID.

Even a known initial candidate cannot resume database writes without the separate ownership,
freshness, route and accepted-work workflow under ADR-019. HC1/PA3 outputs keep writers stopped.
A durable host may record observed reconciliation outcomes under its own contract, but it
must not relabel an inspection result as a library pipeline acknowledgment.

## 5. Compatibility and Implementation Gates

Existing unplanned ConvertLegacyBackup/RestoreEpochBackup and internal pipelines remain
unchanged now. A future planned path is explicit; existing callers must retain internally
allocated IDs and current publication/error behavior. No frozen fixture/layout/version,
mandatory root file or provenance role changes are needed to select the existing GUID field.
Actual planned integration still needs dedicated tests; design compatibility is not proof.

| Gate | Required tests / result | Current status |
|------|-------------------------|----------------|
| RC1 | Read-only prepare and immutable descriptor, pinned input/role/paths/policy, owner-bound atomic single-use claim, no I/O on duplicate claim | Internal RC1 implemented |
| RC2 | Planned pipeline uses exact preknown ID for both roles at H0/H3, full proof, fresh epochs, unchanged old entry points/bytes; invalid plan/input rejects before output | Internal RC2 implemented |
| RC3 | Concurrent same-plan claim, different-plan competing target, failures before/after rename and cleanup, process death/restart inspection, unknown-ID limits and explicit new-attempt retry rules | Internally qualified; see RC3 evidence |

RC1 should first prototype plan state/descriptor plus bounded read-only preparation internally,
with happy/failure/ownership/concurrency tests. RC2 then wires existing pipelines through a
validated plan without widening their public surface. RC3 qualifies lost acknowledgments
and retry observations; real host ledger/fencing remains HA1/HA2, not inferred from local tests.
Keep source/artifact/candidate histories and CanReclaim=false throughout.

## 6. Evidence for the Original Design Step

The original design step changed no runtime code/formats and ran no new runtime tests. The prior
[consolidated evidence](m2-consolidated-api-readiness-results.json) remains 1,050 baseline
cases plus final 80 classifier cases, replacing 79 rows for 1,051 unique cases/platform;
this is not a new unfiltered 1,051-case run. Current runtime/test fingerprints, four frozen
DLL hashes and 15 independent metadata fixtures are checked unchanged. Strict documentation
and portable hidden/link checks validate the new local documents on Windows and Linux.
Public naming, external consumers, archived releases, physical durability and release approval
remain open; no new commit/push, public API, persistent host record or routing is performed.


RC1 implementation follow-up (2026-10-28): local preparation/claim is qualified separately
in [validation](M2_ADMINISTRATIVE_ATTEMPT_PLAN_VALIDATION.md). The original design-step
no-runtime-change statement above refers to its own dated scope; RC2/RC3 remain open.


RC2 implementation follow-up (2026-10-28): explicit ExecuteAttempt uses a claimed one-entry
context and rechecks pinned input before publication. Selected uncertainty tests do not
complete RC3 process/restart/competing-publisher qualification.


## RC3 Process and Contention Qualification (2026-10-28)

RC3 qualifies preannounced IDs across publisher process death, independent plans racing
one destination and concurrent dispatch of one plan. See [validation](M2_ADMINISTRATIVE_ATTEMPT_PROCESS_VALIDATION.md).
Focused Windows/Linux runs pass 71 cases each, including 12 new RC3 cases; earlier
full-suite evidence retains its dated scope. This supersedes earlier next-RC3 statements.
RC2/RC3 remain local; a3b578c contains work through RC1. No public API, host routing,
durable replay, source replacement or reclamation is enabled. Next HA1 defines the host
attempt-ledger and fencing contract; local inspection alone never authorizes retry.


HA1 persistence/exclusion requirements are specified in the [host ledger contract](M2_HOST_ATTEMPT_LEDGER_CONTRACT.md).
A lease or ledger generation cannot fence current filesystem publication; actual host selection
and enforcement remain open. Next is a pure supplied-evidence model, not a durable adapter.
