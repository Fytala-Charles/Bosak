# MG5 Internal Cutover Acceptance Harness

Date: 2026-10-27. Implements bounded prototype acceptance under
[ADR-018](../ADR-018-full-history-legacy-migration-and-cutover.md). No application route,
configuration, store path or retirement operation is performed by this harness.

## 1. Freeze and capture lifetime

MigrationSourceFreeze.Acquire requires explicit operator writer-stop/drain attestation and
an already owned, recovered EmbeddedXmlDatabase. It sets a cooperating in-memory freeze
under the coordinator gate. BeginWrite, pending Commit, CreateCheckpoint and
CreateRecoveryAnchor reject before writes while frozen. Read/snapshot and capture remain
allowed. Existing lazy readers keep their own immutable files and lifetimes.

Capture must be performed through that active freeze, exactly once. It creates a sealed
legacy backup using the existing capture pipeline and strictly checks its history; the
registered receipt retains private cloned inventory bytes. A separately constructed receipt,
a receipt from another freeze or a disposed freeze cannot authorize inspection. Capture,
conversion and owner Open are explicit preceding operations and can write/recover as their
existing contracts allow; they are not implicit actions of freshness validation.

Convert through MG3, explicitly open the returned candidate, then attach a
MigrationCutoverSession with an explicit prototype compatibility-review attestation. Attach
forks shared candidate admission before taking any coordinator inspection gate, then freezes
candidate new/pending transaction mutations and callback-bearing backups, preventing a
backup callback from reversing inspection gate order. Source and candidate OS writer handles stay
with their existing owners. Inspection locks source then candidate, never acquires initial
admission under a gate, and performs no recovery or persistent writes.

Scopes are caller-thread confined and use no monitor held across caller awaits. Disposal
releases only its matching freeze token and the candidate child admission. Owner disposal
invalidates readiness; candidate child admission remains independent until session disposal.
Process exit releases OS handles and all in-memory evidence is lost. No persistent marker
or fence is written. These mechanisms cannot exclude old/uncooperative writers or prove an
operator stopped every application; attestations are prototype assumptions, not facts
inferred from locks. Complete archived-release compatibility remains unproven.

## 2. Read-only freshness validation

Attach, Prepare and every Evaluate validate current disk contents under active owner gates:

- Exact captured artifact inventory bytes/seal, supported complete closure and strict
  every-transition legacy history; no replacement inventory is silently accepted.
- Source owner's document/H/manifest selection, all canonical captured file lengths/SHA-256,
  actual canonical closure and unexpected committed-file refusal. Compare FORMAT/base,
  CONTROL, every WAL and all materializations, not H or head alone. Runtime/checkpoint/staging
  exclusions follow existing legacy capture rules and remain retained/protected; traversal
  is bounded and links reject. A valid live zero-head CURRENT is allowed and checked even
  though the sealed H0 file set omits it. Nothing synthesizes a missing authority file.
- Disjoint unlinked source/artifact/bundle paths; candidate owner/result must select exactly
  the returned store/ and initial H/identity. Require exactly migration.bin plus store/.
- MG1 provenance/header context plus exact MigrationId/result identity, current authority,
  EPOCH/admission binding, expected initial reader set and absence of publication debris.
- Exact original document-data commitments, byte-identical mapped WAL operations and new
  predecessor digests, all generation FORMAT/witness bytes and full read-only epoch history.
  Source/candidate advancement, same-H changed bytes or substituted provenance reject.

This cross-check runs no private redo clone, creates no runtime reader identities and does
not call a coordinator Open. The prior MG2-MG4 copy/redo evidence is retained; a provenance
record or receipt by itself is not history, routing or source-authenticity authority.

## 3. Single-use evidence and observed routing model

Prepare returns an opaque reference tied to that active session. Only the most recently
prepared reference is accepted, once; consumed, superseded and cross-session references
reject. Validation is repeated when evidence is consumed. Prepare validation failure marks
reconciliation terminal and invalidates prior evidence; an Evaluate freshness/owner failure
returns ReconciliationRequired. Evidence cannot survive session restart or process exit.

The caller supplies an observed route (Legacy, Candidate, Unknown or Other) and explicit
work-drained/no-work-accepted assertions. These are acceptance-test inputs, not callbacks
that perform routing or a library inspection of real application configuration.

| Request / observation | Result |
|-----------------------|--------|
| ProposeCandidate from LegacyObserved with observed Legacy and both sides fresh/drained | CandidateProposed; no route is changed |
| ObserveCandidateOutcome after proposal: Candidate | CandidateObserved |
| ObserveCandidateOutcome after proposal: Legacy | LegacyObserved; a known failed switch |
| Either outcome: Unknown or Other | RoutingUncertain; never guess success/failback |
| ProposeLegacyReturn from CandidateObserved with observed Candidate, fresh data and no accepted work | LegacyReturnProposed |
| ObserveLegacyOutcome: Legacy | LegacyObserved; verified modeled no-write return |
| ObserveLegacyOutcome: Candidate | CandidateObserved; known failed return |
| Unresolved outcome later has an explicit known observation | Resolve only the corresponding outstanding intent, with fresh single-use evidence |
| Accepted/undrained work or changed source/candidate/owner | ReconciliationRequired; terminal for this session |
| Wrong action order, stale/foreign evidence or wrong thread | Reject; no external state mutation |

An attempted proposal against an unknown/contradictory route yields RoutingUncertain and
cannot invent an outstanding successful intent. After real destination commits or accepted
application work, rollback is not a path swap. Preserve both histories and require an
explicit reconciliation/export decision. Disposing a session unfreezes the candidate;
source freeze is separately caller-owned. Ending a scope is not permission to resume both
writers. Actual routing/draining/freeze across applications is still operator responsibility.

## 4. Evidence and remaining boundaries

[Validation](M2_MIGRATION_CUTOVER_ACCEPTANCE_VALIDATION.md) records 32 Storage cases and two
process cases, including read-only decisions, pending writes, hidden same-H changes,
uncertain routes, stale evidence, disposal, thread confinement and process termination.
This is not an automatic routing service, production cutover authorization or complete C1-C3.
No public mutable/migration API, source replacement, history deletion or reclamation.

Next: audit the complete compatibility/release-readiness evidence against original C1-C3
and M2 requirements, distinguish frozen local readers from missing actual archived
pre-lease binaries, and record the exact remaining prerequisites before public exposure.
Do not manufacture historical binaries, remove source data or declare the full M2 product
complete from internal MG1-MG5 prototype acceptance.
