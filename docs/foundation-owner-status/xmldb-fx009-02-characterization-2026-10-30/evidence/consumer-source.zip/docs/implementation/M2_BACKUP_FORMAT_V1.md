# M2 Full-History Backup Format 1.0

Implemented per [ADR-009](../ADR-009-verified-full-history-backup-and-restore.md).
The source M1/WAL/checkpoint formats remain unchanged. These are additional artifact
files, not a new mandatory store FORMAT major.

## Artifact Layout and Selection

A completed artifact has exactly inventory.bin, COMPLETE and data/ containing declared
store files. Every directory must be an ancestor of a declared data file. Missing,
extra, case-substituted files and unrelated empty directories fail verification. All
paths/ancestors must be free of symbolic links or reparse points.

The file closure is the base FORMAT, documents/<document>/manifest.bin and directory.bin,
manifest-referenced fragments/<id>.bin, .transactions/CONTROL, canonical WAL 1..H,
complete generations/1..H (each its own FORMAT/documents/fragments), and CURRENT for
H>0. Checkpoint copies/selectors/descriptors and all process locks/readers/staging are
omitted together. H=0 has no required CURRENT or WAL. Capture refuses unknown source
files rather than guessing their dependency semantics.

## Common Envelope

Use the existing BinaryEnvelope: four ASCII magic bytes, little-endian u16 major=1,
u16 minor=0, i32 body length, body, then 32-byte SHA-256 over header plus body. Maximum
complete file is 64 MiB. Reject unknown versions, inconsistent lengths, trailing bytes,
invalid UTF-8, checksum mismatches and truncation before interpreting content.

## Inventory: BXBI

| Field | Encoding |
|-------|----------|
| BackupId | 16 bytes, .NET Guid.ToByteArray order; nonzero |
| DocumentId | u64 little endian; nonzero |
| CommitSequence H | u64 little endian; 0..10,000 |
| Base manifest hash | 32 bytes SHA-256 of complete base manifest |
| Head manifest hash | 32 bytes SHA-256 of complete manifest at H |
| Entry count | i32 little endian; 1..100,000 |
| Each entry path | i32 UTF-8 byte length followed by bytes |
| Each entry length | i32 complete file size; 44..64 MiB |
| Each entry digest | 32-byte SHA-256 of complete file |

Entries are strictly ordinal-sorted and unique also under OrdinalIgnoreCase. Paths
are relative with / separators, maximum 512 characters and ASCII letters/digits plus
., -, /. Reject empty, dot and dot-dot components. Decode is followed by exact canonical
file-closure validation derived from the copied manifests and declared document/H;
syntactic path validity alone cannot authorize a path. No inventory data supplies an
absolute target or arbitrary restore location. The inventory envelope is also bounded
by the 64 MiB limit; it does not allocate from unbounded counts or lengths.

## Completion: BXBC

The entire body is the 32-byte SHA-256 of the complete BXBI file, including its envelope
checksum. The complete completion file is 76 bytes. There is no independent completion
flag that can excuse missing or corrupt data. BackupId/H are transitively bound by the
inventory digest. Independent fixtures are backup-inventory-v1.hex and
backup-completion-v1.hex in tests/TestData.

## Verification and Publication

Capture holds the source coordinator lease/gate. Create a unique sibling workspace on
the destination filesystem, copy data, and verify full recovery on a separate clone.
Require exact H/head, matching base and zero replayed generations. Read all snapshot
values to force lazy payload verification. Verification uses the operation's selected
durability policy and storage seam. Remove only that private clone after closing its
coordinator and snapshot. Flush inventory, then completion, validate the sealed artifact,
rename the artifact to the absent final destination and synchronize both rename parents.
Clean the private empty workspace before returning BackupResult.

Restore verifies the sealed inventory and exact closure before creating its workspace.
Rehash copied bytes against the inventory, full-verify a clone, then publish only the
copied data root. Restore has no copied OS ownership, backup marker or inventory inside
the resulting store. Future Open creates new runtime locks/readers. The sealed artifact
stays immutable. Existing destinations are refused, including a previous successful
operation; use a new destination for retries.

Only a fully verified published root is returned. Failure after rename may leave a
valid final root without acknowledgment. Incomplete sibling workspaces remain unroutable
and are never guessed to be backups/restores. No automatic cleanup scans are provided.
The source/backup must not be externally mutated during operations. ProcessCrash is the
default; Linux FileAndDirectoryFlush is explicit with no unsupported-platform fallback.
Neither policy implies certified physical power-loss durability.

*Last updated: 2026-10-27*
