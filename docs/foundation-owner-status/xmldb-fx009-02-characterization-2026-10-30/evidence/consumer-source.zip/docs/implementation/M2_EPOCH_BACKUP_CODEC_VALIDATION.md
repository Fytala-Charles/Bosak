# M2 ET9-A Epoch Backup Codec Validation

Date: 2026-10-27. Implements the first bounded gate in
[ADR-017](../ADR-017-epoch-full-history-backup-and-independent-restore.md).
The [metadata1.0 contract](M2_EPOCH_BACKUP_FORMAT_V1.md) is frozen by this evidence;
[backup/restore runtime design](M2_EPOCH_BACKUP_DESIGN.md) remains partially unimplemented.
No epoch capture/restore, public API, admission bypass or store/backup-format mutation is added.

## Independent byte evidence

EpochBackupCodec contains internal immutable record shapes with bounded encode/decode and
pure completion/source/origin header-context checks. Expected bytes are independently
assembled in tests/TestData/epoch-backup-fixtures-v1.py with Python struct/uuid/hashlib,
without invoking production codecs. The script documents fixed inputs and fixture digests
in epoch-backup-fixtures-v1.json. Existing fixtures/frozen binaries are never rewritten.

| Role | Complete bytes | SHA256 |
|------|----------------|--------|
| BXEI inventory | 332 | 5847abe5c14bcbe2fe7df72b40f8a40493baea77445e1c38aa94532f904049c3 |
| BXEZ completion | 92 | 7106e4f2081fc347942f39d97e481ed9a7a0faf68fb08970c05e7a7f21befd00 |
| BXEO origin | 380 | 3690253d1fcbce489f2fd5b29d733d2c4e333bfdfa4b04816fd348336bbcadb4 |

The golden inventory has two illustrative metadata entries, not a complete H=2 backup
closure. Decoding it must not be interpreted as accepting an artifact. Complete closure,
file/directory/fragment hashing and full-WAL recovery remain ET9-B/C runtime work.

## New checks

Seventy-eight new Storage cases cover:

- Exact independently authored encode/decode bytes and all 804 truncated prefixes across
  the three roles. Reject wrong roles, legacy metadata, unsupported versions, malformed
  lengths/checksums and both raw and rechecksummed body trailing data.
- Required identities, zero/max sequence/head relations, unsupported closure contract,
  hostile counts/lengths before collection/path allocation, invalid UTF-8, file/digest
  bounds and reused source/destination identities.
- Unsafe/device/alias/non-ASCII paths, unordered/duplicate/case-colliding names; valid 512-
  byte paths, 64 MiB declared files, 100,000-entry inventories and H=10,000 boundaries.
- Completion BackupId plus complete inventory digest binding. Source FORMAT/profile/current
  matching; all origin source-inventory and fresh-destination/current commitments. Foreign,
  stale, malformed or unsupported contexts fail closed. Zero-head contexts are checked too.

The production codec performs no file I/O or ownership operations. Header consistency is
not verification of file closure, data, history, bundle provenance or authenticity. Decode
returns metadata DTOs, not an admitted root or verified-artifact token. Mutable public
profile gates and format-1 BXBI/BXBC remain unchanged.

## Full regression evidence

| Platform | Storage | Xdm | Integration | Total | Failed / skipped |
|----------|---------|-----|-------------|-------|------------------|
| Windows | 430 | 27 | 112 | 569 | 0 / 0 |
| Ubuntu24.04.4 / Docker overlayfs | 430 | 27 | 112 | 569 | 0 / 0 |

Final TRX: .tools/et9a-windows-results and .tools/et9a-linux-results.
[Structured evidence](m2-epoch-backup-codec-results.json) records counts, fixtures and scope.
SDK10.0.301, Windows runtime10.0.11, Linux runtime10.0.9. Linux uses the pinned existing image,
read-only source/cache and no network. Formatting and strict documentation hygiene pass.
Seven known MINVER1001 warnings remain because this checkout has no initial commit.

The full suites retain 2,162 Windows / 2,579 Linux I/O fault positions, including 481 native
ET8 Linux positions. These are regression evidence, not new backup capture/restore fault
coverage. Thirteen Linux-only branches return on Windows without native-execution claims.
Existing frozen reader baselines and fixture bytes remain unchanged.

## Reproduce and next gate

```powershell
dotnet test Bosak.XmlDb.slnx -c Release --no-restore --logger 'trx;LogFilePrefix=windows' --results-directory .tools/et9a-windows-results
$env:DOTNET_ROLL_FORWARD = 'Major'
& ./.tools/pwsh.exe -NoProfile -File tools/test-linux.ps1 -ResultsDirectory .tools/et9a-linux-results
dotnet format Bosak.XmlDb.slnx --no-restore --verify-no-changes
& ./.tools/pwsh.exe -NoProfile -File tools/check-docs.ps1 -ProjectPath . -Strict
```

Next: ET9-B internal fixed-H capture, strict actual file closure and both private verification
oracles. ET9-C independent rebinding/restore bundles and ET9-D fault/process/platform proof
follow. ET9 remains incomplete. Public mutable APIs, full-history migration/cutover, complete
archived-reader C1-C3 and retirement remain pending. No source-root replacement, committed-
history deletion, physical power-loss or real ENOSPC certification follows from ET9-A.
