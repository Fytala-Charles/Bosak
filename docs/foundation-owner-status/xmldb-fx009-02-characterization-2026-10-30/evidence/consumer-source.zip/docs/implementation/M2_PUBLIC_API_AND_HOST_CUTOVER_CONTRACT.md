# M2 Public API and Host Cutover Contract

Date: 2026-10-28. Design under [ADR-019](../ADR-019-explicit-mutable-api-and-host-cutover-boundary.md).
No public API, host adapter, persistent routing record or production cutover is implemented.
Proposed names below are descriptive, not compiled or versioned promises.

## 1. Available Integration and Scope

Repository source projects are Bosak.XmlDb.Core, Storage and Xdm. EmbeddedQuickstart uses
the existing embedded API. There is no web/server project, application route registry,
queue-drain service or external writer fence. M4 hosting remains deferred in ROADMAP.
A contract can require host capabilities; it cannot claim they exist or infer which
application deployment the owner intends to migrate.

| Existing surface | Current contract retained |
|------------------|---------------------------|
| ImmutableXmlSnapshot.Open | Legacy immutable roots; transaction guard; does not select/recover a mutable epoch |
| EmbeddedXmlDatabase.Open overloads | Format-1 scalar owner, explicit recovery/durability; rejects mandatory epoch profiles |
| ReadOnlyEpochDatabase.Open | Explicit immutable epoch profile, complete sequence-zero SNAPSHOT; rejects ScalarWal |
| EmbeddedXmlDatabase.CreateBackup / RestoreBackup | Existing format-1 full-history artifact contract |
| Internal EpochScalarCoordinator / migration / MG5 | Test/prototype access only; no consumer routing authority |

No existing Open gains fallback probing or automatic migration. Open on a mutable root is
an owning operation that may recover/publish state; it is never an inspect-only API.

## 2. Proposed Mutable API Responsibilities

| Proposed operation | Required behavior before public exposure |
|--------------------|------------------------------------------|
| ScalarEpochDatabase.Open | Explicit mutable profile, durability/recovery selection, admission before coordinator gates, exact identity validation; return owning session |
| BeginRead | Independent snapshot at the selected committed head; immutable lazy reads survive owner disposal; deterministic snapshot disposal |
| BeginTransaction | Snapshot-based single-scalar replacement, stale-head validation and independent admission; no multi-document/structural semantics |
| Commit | Return acknowledged sequence only after required publication/barriers; post-publication errors/cancellation can have unknown outcome |
| CreateBackup | Fixed-H complete sealed history, excluding runtime identities; original and existing snapshots remain usable |
| VerifyLegacyBackup / VerifyEpochBackup | Explicit workspace and resource bounds for complete/full-redo clones; input is read-only, private workspace may be written |
| ConvertLegacyBackup / RestoreEpochBackup | Explicit disjoint fresh destination and policy; return published store path plus operation/identity commitments; never route or overwrite source |

Proposed facade belongs in Storage and must not make Xdm depend on host services. Existing
Xdm navigation should consume admitted snapshots with its current lifetime requirements.
Public import/creation, optional schema adapters, async APIs and structural operations are
separate decisions; an internal fixture builder is not a public creation implementation.

The public result must distinguish rejection before publication from an unacknowledged
possible publication. A missing return value is not proof of no commit or no candidate.
After uncertain commit, reopen/recovery and authoritative history inspection determine
what committed; no API automatically retries the scalar edit. TransactionId alone does
not provide a durable idempotency service. Administrative retries never adopt/delete an
unidentified abandoned workspace or overwrite a destination.

Keep unsupported profile, invalid history, contention, disposed owner, unsupported native
policy and uncertain publication outcomes distinct in the documented diagnostics. Exact
public exception/result types require API tests before names are frozen. Disposal is
idempotent, releases owned handles only, and is not permission to resume a different writer.
Cancellation cannot undo a publication or authorize a route reversal.

## 3. Ownership Boundary and Exact Commitments

The library provides local cooperating admission and bounded integrity validation. The host
must independently exclude every application writer, including old binaries, background
jobs, retries and queued work. Read-only old snapshots may remain at their original paths.
No lease probe proves old-reader absence; all source/candidate history remains retained.

A host operation identifies the legacy source by canonical unlinked path, document ID and
captured inventory/FORMAT/history commitments. Legacy sources have no StoreId/EpochId;
never fabricate them. Candidate identity includes canonical returned store path, MigrationId,
BackupId, StoreId, EpochId, document/H, format/base/head and full-history commitments.
H or path alone is insufficient. Provenance hashes bind bytes; they do not prove authenticity
or grant routing/recovery authority. Host operation ID and route revision are separate from
store/epoch IDs and must not be encoded into unchanged storage formats.

## 4. Required Host Capabilities

| Capability | Required observation / guarantee |
|------------|----------------------------------|
| Writer exclusion | Stop and fence all application writers across capture, conversion, observation and restart; report scope and explicit gaps |
| Drain and work accounting | Account for queued, in-flight, accepted-but-uncommitted and retried work, on both routes; unknown is not zero |
| Route observation | Identify exact target and routing revision from authoritative host state; classify missing, foreign and contradictory state |
| Conditional route change | Compare expected revision/target and apply one explicit target change; report known applied, known not applied or unknown |
| Restart control | Keep writes disabled until fresh authoritative route, operation, work and history observations agree; no automatic service-start write enablement |
| Reconciliation | Preserve both branches and obtain an explicit export/reconcile decision after divergence or unknown work |

A host lacking conditional update or a revision mechanism needs an equivalent proven
exclusive configuration protocol before implementation. A static config string or successful
callback return alone cannot establish global routing. The host must define what constitutes
accepted work and how that accounting survives failure. In-memory booleans cannot discharge
that requirement. No NATS, web framework, orchestrator or distributed consensus dependency
is introduced by this contract.

## 5. Cutover and Return Protocol

1. Establish external writer exclusion and drain/account for accepted work. Observe the
   authoritative legacy route and revision. If any scope is unknown, keep writes stopped.
2. Explicitly open/recover the owned legacy coordinator, acquire a cooperating freeze and
   capture through that freeze. Convert the sealed artifact into a separate verified bundle.
   Explicit candidate Open may recover/write; this precedes read-only readiness validation.
3. Validate exact source, artifact and initial candidate history with both owners active.
   Keep every writer stopped, including the candidate. No actual route change is implied.
4. The host conditionally changes the route from the observed legacy revision to the exact
   candidate identity. Do not hold storage inspection locks while invoking host callbacks.
   Host exclusion must preserve freshness over the gap between validation and route change.
5. Observe authoritative route/revision again. Known unchanged legacy permits remaining
   stopped or explicitly resuming source after revalidation. Unknown/foreign/conflicting
   observations enter reconciliation; do not infer success from timeout or local process state.
6. Candidate writes may resume only after explicit host confirmation of routing, ownership,
   exclusion of source writers and required release qualification. MG5 modeled acceptance
   is not that confirmation, and this design does not authorize production write enablement.

A no-work return requires exact fresh initial histories, complete accounting proving neither
side accepted work, and a conditional route change followed by authoritative observation.
Any accepted work, advancement, stale commitment or lost ownership prevents automatic return.
Keep both histories and require reconciliation. A successful candidate read does not prove
that a route changed; a failed route request does not prove that it did not change.

MG5 scopes/receipts are thread-confined. An async host adapter cannot hold them across awaits
or serialize/replay their object references. A future orchestration implementation needs an
explicit lifetime/exclusion design; this contract does not retrofit async safety into MG5.

## 6. Restart and Unknown Outcomes

On restart, discard all MG5 receipts and readiness decisions. Do not reconstruct a valid
freeze from a saved enum, expired process ID, unlocked lease or provenance file. Establish
external exclusion before any owning Open/recovery, then collect fresh read-only observations
and perform explicit owned recovery only where its mutation effects are authorized.

| Observations after restart/failure | Required result |
|------------------------------------|-----------------|
| Missing operation provenance, unavailable route revision, contradictory target or work status | Reconciliation; both writers stopped |
| Candidate published but no route change recorded/observed | Retained independent candidate; no automatic route switch or deletion |
| Route says candidate, initial histories fresh, work accounting complete | Eligible for a new readiness workflow after ownership/exclusion checks; not automatic resume |
| Route says legacy, candidate switch known not applied, exact freshness/no work proven | Eligible for new source readiness; not automatic fallback |
| Either branch advanced or accepted work is nonzero/unknown | Reconciliation/export; no path swap or automatic return |
| Host change acknowledgment lost | Observe authoritative revision/target; unresolved state stays stopped |
| Both writers may have been active | Treat as possible divergence even if H happens to match |

If host operation records are required, specify their durable storage, integrity, revision,
atomicity, access control, retention and crash recovery separately. Until such host evidence
exists, restart is an operator reconciliation workflow, not an implemented journal replay.
Never use a newly invented record as authority to repair a store or reclaim history.

## 7. Qualification Gates

| Gate | Evidence required before enabling the corresponding behavior |
|------|-------------------------------------------------------------|
| HC1 | Pure internal restart/reconciliation classification with missing/stale/contradictory observations and no I/O or routing |
| PA1 | Reviewed explicit facade shapes and consumer compile/lifetime/profile/diagnostic tests; no widening existing entry points |
| HA1 | Identify actual consuming host, external exclusion/work/route revision mechanisms and restart ownership model |
| HA2 | Adapter faults before/after conditional update, acknowledgment loss, concurrent revision changes and process restart with authoritative work accounting |
| REL | Archived reader provenance/compatibility, supported platform/durability limits, license/dependency/API release policy and explicit release decision |

HC1 is now implemented as an internal supplied-observation classifier only; see
[classification validation](M2_RESTART_CLASSIFICATION_VALIDATION.md). PA1/HA1/HA2/REL remain open. CA1/CA2 strengthen
local compatibility/ownership but do not substitute for those gates. No new runtime run is
claimed in this documentation step; retain CA2's 40 focused cases per platform and previous
broad/fault reports at their original scope. Packaging stays disabled; CanReclaim=false.

HC1 now supplies the pure internal classifier and table-driven tests without route callbacks,
owning Open or durable writes. Next bounded implementation is PA1 internal facade prototyping
with ownership/profile/diagnostic tests before any public exposure.
Actual host selection and archived binary acquisition remain explicit external inputs.


HC1 follow-up (2026-10-28): the pure classifier performs no I/O or route callbacks and every
result keeps writers stopped. Its evidence is separate from this original design step.
Next is PA1 internal facade prototyping with explicit ownership/profile/diagnostic tests.


PA1 follow-up (2026-10-28): [internal mutable facade prototype](M2_SCALAR_EPOCH_FACADE_VALIDATION.md)
implements explicit options, ownership and scalar semantics with friend-consumer tests.
Public signature/diagnostic review and external consumer/release qualification remain open.
Next PA2 prototypes separate administrative verification/restore/migration outcomes internally.


PA2 follow-up (2026-10-28): [internal administrative prototype](M2_SCALAR_EPOCH_ADMINISTRATION_VALIDATION.md)
now separates sealed proof, independent restore and migration with acknowledged-result
receipts. Exceptions retain possible-publication uncertainty. No public signatures or
durable host/receipt authority are added. Next PA3 is read-only publication inspection.


PA3 follow-up (2026-10-28): [publication inspection](M2_PUBLICATION_INSPECTION_VALIDATION.md)
now observes pinned-artifact and optional known-operation matches without recovery/adoption.
Observed metadata is separate from an acknowledged publication receipt. No observation
resumes writers or supplies actual host/accepted-work evidence. Next is consolidated
cross-platform regression and API/readiness review before further API work.


Administrative identity follow-up (2026-10-28): [ADR-020](../ADR-020-planned-administrative-attempt-correlation.md)
adds the design-only [attempt/retry contract](M2_ADMINISTRATIVE_ATTEMPT_CONTRACT.md). A host
request differs from a physical attempt; executable plans are never restored from saved
descriptors. RC1-RC3 must qualify implementation before public exposure.


HA1 contract follow-up (2026-10-28): [ADR-021](../ADR-021-host-attempt-ledger-and-publisher-exclusion.md)
and the [host ledger contract](M2_HOST_ATTEMPT_LEDGER_CONTRACT.md) specify durable intent,
conditional ownership and effective publisher exclusion. This satisfies the host-neutral design
step only; the HA1 actual-host gate above and HA2 integration remain open. Next is a pure
supplied-evidence decision model; no durable backend, host adapter or routing is implemented.


HA1 model follow-up (2026-10-28): [pure classification validation](M2_HOST_ATTEMPT_LEDGER_MODEL_VALIDATION.md)
qualifies supplied-evidence rules internally with 180 new cases. This implements no backend
CAS, persistence or effective fence. Actual host selection and HA2 remain open. Next is an
internal conditional-transition harness for revision and lost-acknowledgment protocol tests.


HA1 transition follow-up (2026-10-28): [in-memory protocol validation](M2_HOST_LEDGER_TRANSITION_VALIDATION.md)
adds exact-revision transitions and simulated lost acknowledgments with 83 new cases. It
provides no durability or effective fence. Next is test-only integration with planned execution;
actual host/backend selection and HA2 remain open. Earlier next-step notes retain their scope.


HA1 test integration follow-up (2026-10-28): [actual planned execution tests](M2_HOST_LEDGER_PLANNED_EXECUTION_VALIDATION.md)
qualify modeled save boundaries with real library publication. This closes the bounded local
integration step, not HA1 host selection or HA2. Next identify actual host/backend, exclusion
and route/work authorities. No production orchestration or durable ledger is implemented.
