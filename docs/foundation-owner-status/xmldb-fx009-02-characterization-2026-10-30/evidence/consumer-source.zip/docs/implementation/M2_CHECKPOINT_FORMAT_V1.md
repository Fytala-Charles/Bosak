# M2 Checkpoint and Reader-Lease Format 1.0

## 1. Additive Files

M1 materialization and existing WAL/control/root encodings remain unchanged.
New files use the existing little-endian, strict bounded SHA-256 envelope version 1.0.
All sequence references are canonical twenty-digit unsigned decimal names.

```text
<root>/.transactions/
  CHECKPOINT                          # Optional selected anchor, BXCS
  checkpoints/<sequence>/
    FORMAT                            # Complete independent M1 materialization
    documents/<document-id>/manifest.bin
    documents/<document-id>/directory.bin
    fragments/<fragment-id>.bin
    anchor.bin                        # Immutable identity, BXCP
  readers/<sequence>.lease             # Immutable stable lock identity, BXRL
  readers/<sequence>.lease.tmp-<id>     # Unpublished identity preparation
  staging/checkpoint-<id>/             # Unpublished complete checkpoint preparation
  checkpoint-<id>.tmp                  # Unpublished selector preparation
```

No additional commit sequence is created by checkpointing. A checkpoint requires
at least one commit; sequence zero remains the original base. No checkpoint, WAL,
generation or stable lease is deleted/replaced by this implementation.

## 2. Envelope and Bodies

The common envelope is four ASCII magic bytes, u16 major=1, u16 minor=0, i32 body
length, body, then 32-byte SHA-256 of header/body. Unsupported versions and trailing,
truncated, oversized or checksum-mismatched data are rejected.

| File | Magic | Body fields in order |
|------|-------|----------------------|
| Anchor | BXCP | u64 DocumentId; u64 sequence S; 32-byte materialization manifest hash; 32-byte WAL-record-at-S hash; 32-byte WAL-prefix digest; u16 referenced format major=1; u16 minor=0 |
| Selector | BXCS | u64 DocumentId; u64 sequence S; 32-byte SHA-256 of the entire anchor file |
| Lease identity | BXRL | u64 DocumentId; u64 sequence (zero is permitted for imported base readers) |

Anchor size is 160 bytes including envelope; selector is 92 bytes; lease identity is
60 bytes. Anchors require S between 1 and the current retained-journal limit, 10,000.
The format reference describes the copied M1 files, independently of the anchor version.

Let P0 be 32 zero bytes and Wi the complete checksummed WAL-file bytes at sequence i.
The prefix digest is Pi = SHA256(P(i-1) || SHA256(Wi)). This binds exact record bytes,
including transaction identity and redo value, not just the logical resulting manifest.
All hashes detect corruption, not malicious authenticated replacement.

Golden hexadecimal fixtures checkpoint-v1.hex, checkpoint-selector-v1.hex and
reader-lease-v1.hex were independently encoded from this layout and are compared
byte-for-byte in tests. Anchor truncation is tested at every byte boundary.

## 3. Publication

Under exclusive coordinator ownership, recompute the current WAL prefix and require
it matches the already-recovered state. Copy a complete materialization into a fresh
staging directory and validate every payload/directory/manifest. Flush anchor content
and namespace, publish the checkpoint directory, flush its parents, then write/flush
and atomically replace the selector, finishing its parent barrier before returning.
The selected DurabilityMode determines whether directory barriers are native or
process-only; no stronger per-store SLA is inferred.

Same-sequence publication reuses only an identical validated immutable checkpoint.
A failure faults the coordinator until reopen. A kill before selector publication leaves
the old selected checkpoint or none; an unselected higher-numbered directory is not
authoritative. A selector that was acknowledged remains selected in the process-crash tests.

## 4. Optional Recovery

FullJournal validates all generation history as before. PreferCheckpoint first validates
the selector, anchor and complete checkpoint materialization. It then validates every
retained WAL record: canonical names, framing/checksum, document/sequence, unique
transaction IDs and predecessor manifest linkage. At S it requires exact prefix/record/
manifest hashes. Prefix binding failure restarts full validation.

Once bound, the checkpoint provides the state at S, so earlier materializations can be
skipped. The suffix is independently validated or replayed against that state. CURRENT
must still be represented by the intact accepted WAL chain. Optional cache corruption
falls back to full history; required committed-data corruption still fails closed.
This mode does not audit unused old generation payloads, and is not WAL truncation.

LastRecovery reports checkpoint sequence, complete records checked, materializations
validated/replayed and whether an optional candidate was rejected. It describes the
completed selected recovery pass, not rejected candidate prevalidation, directory synchronization or later commit/query I/O. Query snapshot metrics still exclude startup work.

## 5. Reader Lifetime

Publish an immutable canonical lease identity before acquiring FileAccess.Read /
FileShare.Read ownership. Snapshot Dispose releases that handle; disposing its creating
coordinator does not. Transactions own their base snapshot's shared handle until commit,
rollback or disposal. Reopening another coordinator cannot bypass active shared holders.

The lease inode/path is never unlinked or replaced, even after its holders close.
An exclusive open is an internal validation primitive, not authorization to reclaim a
generation: live root, checkpoint/replay dependencies, old readers and compatibility
must also be addressed. Stable lease identities are not opened for write during stronger
adoption; directory entries still receive barriers. Unpublished temporary files can be
ignored/retried after a failed create without splitting a canonical lock identity.

Old M1 snapshots and older binaries are not retroactively registered. All history and
the base remain retained, and no public reclamation API exists. Physical power-loss,
actual bounded-volume ENOSPC and production-filesystem certification remain separate gates.

*Last updated: 2026-10-26*

## Additive Independent Recovery Descriptors

`CreateRecoveryAnchor()` publishes `anchors/<sequence-D20>.anchor` within .transactions.
Each descriptor is exactly the existing 92-byte BXCS selector envelope, with identical
hash binding and no new encoding version. It is published only after a complete
checkpoint and CHECKPOINT selector, using flushed temporary bytes and atomic rename
with policy barriers. Same-sequence descriptors are immutable and validated on retry.
Older binaries ignore the new directory. See [ADR-007](../ADR-007-recovery-descriptors-and-retention-inventory.md)
for discovery ordering, candidate rejection and conservative retention semantics.
