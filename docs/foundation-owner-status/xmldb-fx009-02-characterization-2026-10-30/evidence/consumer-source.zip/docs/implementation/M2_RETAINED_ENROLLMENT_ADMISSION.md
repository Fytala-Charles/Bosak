# EF2 Retained Enrollment Admission

Date: 2026-10-29. Implements the no-output EF2 boundary of
[ADR-033](../ADR-033-retained-source-exclusion-and-first-enrollment.md).
See [validation](M2_RETAINED_ENROLLMENT_ADMISSION_VALIDATION.md).

## Ownership and Preparation

PrepareRetainedFirstEnrollment is internal and separate from borrowed PrepareFirstEnrollment.
Only the actual newly provisioned authority owner with its unused initializer and drained
inspection mode can prepare. It retains the actual parent/authority operation and the original
source/freeze child. Reopened empty authorities and borrowed preparations cannot upgrade.
Preparation binds real H=0 or positive-H legacy source history, registered sealed capture,
native root/admission identity, authority configuration, administrative position and supplied
reconciliation evidence. It validates complete capture and source histories without repair.
Its proposed Enroll frame is encoded and decoded in memory only.

The actual preparation is owner/reference-bound, caller-thread confined and single-use.
Descriptions and equal-valued forged objects cannot dispatch. Generic inspection is excluded
through pending, executing and terminal retained mode; the acquisition snapshot is unchanged.

## Dispatch and Arm

TryArmRetainedFirstEnrollment consumes the actual plan and transfers resources to a distinct
actual execution before validation. Caller plan disposal cannot release transferred ownership.
It rechecks the exact supplied intent, complete baseline, held parent history and empty authority.
Those reads and test scheduling hooks run outside the combined lifetime gates.

Admission uses nonblocking Monitor.TryEnter in authority -> parent -> source order. The brief
combined decision performs no I/O or callbacks. Busy gates refuse admission and consume the
plan; no automatic retry exists. Closing or changed state rejects. Successful arm latches the
original source owner stopped. Protocol entry rejects caller-held source/authority/parent gates
to prevent reentrant reverse lock order. The source latch remains local to that original owner.

After arm, source/freeze/authority/parent wrapper disposal stops new admission while the actual
execution retains all original ownership. Execution Inspect verifies the still-held baseline
and parent while keeping writers stopped. Pending or admitted cleanup releases source first,
then authority/parent operations. Unconfirmed source close retains those operations and reports
uncertainty; it cannot silently complete release or retry the same close. Fixture-only cleanup
of deliberately faulted handles is not a production recovery path.

## Limits and Next Step

No authority metadata/log output, host append, source write, recovery, migration or application
admission occurs. Capture and provisioning precede preparation and are outside this no-output
boundary. Operational assertions are supplied assumptions, not measured host facts. This is
not persistent fencing, reader-absence proof, durability certification or routing authority.
No public surface, frozen bytes or retained history changes.

Next EF3 implements the conditional single-frame first-enrollment writer and terminal stopped
outcomes using actual retained execution. EF4 persistence fault/process qualification, real
host integration, archived release compatibility and all retirement remain open.
