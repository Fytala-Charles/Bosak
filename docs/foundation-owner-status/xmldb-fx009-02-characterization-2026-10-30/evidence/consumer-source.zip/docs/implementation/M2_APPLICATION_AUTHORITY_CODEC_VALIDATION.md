# Application-Authority Codec and Complete-History Validation

Date: 2026-10-29. Internal pure codec under [ADR-029](../ADR-029-separate-application-authority-journal-v1.md)
and the [v1 contract](M2_APPLICATION_AUTHORITY_FORMAT_V1.md), following the EP7-B specification.
No authority-root owner, provisioner, writer, admission adapter or application executor is added.

## 1. Implemented Boundary

ApplicationAuthorityCodec and its two partial files encode/decode exact 112-byte BXAM0001
metadata, 144+N BXAJ0001 frames and canonical nested TLVs with explicit wire mappings. Trusted
configuration includes authority/admin IDs, all four scope keys and ProcessCrash-only policy.
Every frame binds the exact metadata digest and authority ID; whole-history decoding also
requires exact global sequence and predecessor. Runtime enum ordinals are never wire values.

Typed inputs and bytes enforce strict UTF-8, GUID network order, little-endian integers,
positive IDs/counters, exact field sizes, ordered mandatory/optional schemas and cumulative
bounds. Invalid root epoch/document identity cannot be silently re-encoded under a different
root document. Unsupported policies and enum values fail closed without fallback.

The complete-history validator retains one enrollment baseline/source, at most one candidate,
conditional selection, exact owner/generation and every globally unique work acceptance. It
checks preserved document/H, separate root/admission/epoch identities and publication role.
Selection is forbidden after any acceptance, including committed or no-effect work. Outcomes
retain original accepting owner/target/selection/reference; owner transfer cannot rewrite them.

Unknown outcomes and unknown-work observations require explicit reconciliation rather than a
later direct WorkOutcome. Terminal observations may repeat agreeing evidence but cannot conflict
or downgrade a terminal fact. Fresh caller-supplied proof is still required by the future host;
this codec validates structural transitions, not the truth/authenticity of evidence commitments.

Every decoded metadata/frame/history result declares WritersMustRemainStopped=true. A frame
validates shape/hash only; full history requires DecodeJournal/ReadJournal. No result reconstructs
an execution handle, acknowledges a historic save, sets EP7-A selection acknowledgment facts,
opens admissions, routes data, repairs a store or grants a write capability.

## 2. Stream and Damage Handling

ReadJournal reads only its caller-owned stream and never seeks, closes it, opens a file, writes
or calls application/executor callbacks. Short non-seekable reads are supported. Header and
cumulative bounds are checked before allocating/reading declared payloads. Malformed, partial,
extra or illegal later bytes throw without returning a usable prefix. Whole valid prefixes and
empty logs remain structurally possible and stopped; no newest-head/zero-work proof is inferred.

Accepted work is bounded at 1,024, frames at 65,536, payloads at 65,536 bytes, complete log at
64 MiB and strings at 4,096 encoded bytes. Tests accept exact work/frame limits and reject the
next work/byte; oversized payload declarations stop after exactly 104 header bytes. Overflowing
input counters/declarations reject; legitimate bounded histories never wrap counters. No history
is truncated, reset, compacted or reclaimed. A passed codec test is not persistence durability.

## 3. Independent Frame and History Vectors

The new application-authority reference uses independent Python struct/uuid/hashlib assembly
without production encoder calls. It checks the two original pinned metadata vectors but does
not rewrite them. Default execution verifies pinned bytes; --create refuses existing targets.
New vectors are separate from all earlier metadata/store/backup/migration/frozen-reader evidence.

| New vector | Bytes | Frames | SHA-256 of decoded bytes |
|------------|-------|--------|-------------------------|
| application-authority-enroll-v1.hex | 392 | 1 | 40fc1d71c82ef75dd4f3b623ba3440aba9eef32e5fa15bfe5f0d37a4fc106d38 |
| application-authority-legacy-chain-v1.hex | 4,136 | 11 | 769fb7f5a9458d94cd89080e5a31ad438355fca372eb061c7cb7ebe110c95e8c |
| application-authority-restore-chain-v1.hex | 3,610 | 9 | 50a240a487ae0e14ec2d84da152380853ec88dfc7e7179e9dd81b80b383597e5 |
| application-authority-zero-chain-v1.hex | 2,527 | 7 | 1905a3fc11319f89de0c3eab5ec0d33998c81bb486105fdd2836de60a7b96b90 |

The histories exercise legacy migration with candidate work/unknown outcome/owner transfer,
independent restore at H=0 with source work and reconciliation, and zero-work selection/return
at H=10,000. They include all seven event kinds, three outcome and four observation mappings.
They are canonical host-only examples, not provisioned roots, real operation receipts or proof
that underlying XML/artifact histories actually exist. Metadata-only examples remain metadata-only.

## 4. Executed Tests and Source Accounting

166 focused Windows cases pass, zero failures/skips. These include independent metadata (2)
and frame/history (4) vectors; empty/prefix behavior (1); metadata mutations (16); typed input
rejections (13); UTF-8 byte boundary (1); all truncated enrollment positions plus invalid tails
(1 looping case); non-seekable short reads (3); oversized declarations (3); resealed malformed
frames/TLVs (36); discontinuous chains (3); illegal transitions (49); outcome/profile/branch
combinations (12); exact work/frame/byte bounds (3); additional invalid event shapes (19).
Loop positions are not counted as additional top-level tests. Every new case executes its body.

The two Python references also pass: 13 metadata-reference unittest methods and four new pinned
vector checks. .NET tests decode expected identities/outcomes/counts and compare re-encoded bytes
to the independent vectors; they do not generate golden output through the production encoder.

Windows qualification passes across three successful project executions: 1,559 Storage,
593 Integration and 27 Xdm, totaling 2,179 cases with zero failures/skips in those runs. The
166 new codec cases are included, not added again. Storage completed in 49 m 58 s. Restore/build
also pass; all five new C# source hashes match the focused/full-run inputs.

The first unfiltered solution command exited 1: Integration passed 591 and timed out in two
existing EpochBackupRestoreProcessTests cases (Published and normal). Concurrent heavy test
runners in another workspace were observed, but the timeout cause is not established. After
those runners exited, a full Integration project rerun using unchanged binaries/timeouts passed
all 593 cases in 4 m 52 s; its exact test-ID set matches the original. Initial failures remain
in the TRX/machine evidence. This is not a single green unfiltered solution command. Existing
full-suite catalog passes include host-only guard returns; all new codec bodies execute.
Fresh isolated Linux focused execution was attempted but failed before container execution
because Docker Desktop's Linux engine named pipe is unavailable. No current Linux pass is claimed.
Solution formatting/analyzers, strict documentation, actual hidden/link portability and
whitespace checks pass. Final results are recorded in the machine evidence.

Only three new runtime C# files, two new test C# files and six new reference/vector/manifest
files implement this step. Existing C# source, public APIs, package pins, existing formats and
all previous fixture bytes stay unchanged. The old 2,013-case baseline is not relabeled as this
step's full execution. [Machine evidence](m2-application-authority-codec-results.json) records final
source hashes, TRX references and platform scope. Work remains uncommitted on HEAD 4598346.

## 5. Next Gate

Next EP7-C should first define/qualify the new owner-bound application child lifetime mode and
existing-root inspection while admissions remain closed. Keep administrative dispatch, EP6
stopped sessions and incompatible application/selection work excluded; retain actual operations
through drain and release owners in reverse order. No implicit initialization of empty/damaged
roots is allowed. Explicit provisioning and conditional persistence/fault qualification follow
that boundary before EP7-D consuming-host execution. Do not jump from a codec result to a writer.

Public/external-consumer/release, archived-reader provenance, physical power-loss/real ENOSPC,
hostile/global fencing and retirement remain open. Keep all histories and CanReclaim=false.
