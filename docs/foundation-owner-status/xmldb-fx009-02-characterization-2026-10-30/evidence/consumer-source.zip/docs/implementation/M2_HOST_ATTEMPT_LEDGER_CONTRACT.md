# Host Attempt Ledger and Publisher Exclusion Contract

Date: 2026-10-28. HA1 design under [ADR-021](../ADR-021-host-attempt-ledger-and-publisher-exclusion.md).
This defines requirements, not an implemented ledger or satisfied actual-host HA1 gate.
The repository contains no consuming application, durable host backend or external fence.

## 1. Scope and Authorities

The library owns sealed input proof, single-use process-local plans and separate-root
publication. The host owns request identity, durable attempt records, publisher exclusion,
queue cancellation/drain, database-writer exclusion, route revision and accepted-work accounting.
These authorities are independent. A ledger lease is not a store writer lease, source freeze,
publication fence, route revision or permission to resume writes. Every outcome here keeps
writers stopped until a separate, freshly qualified ADR-019 workflow authorizes otherwise.

Store the ledger outside source, artifact, candidate and library-owned temporary roots.
Do not add a mandatory store role or use ledger contents for storage recovery, WAL authority
or reclamation. Retain source, candidate and all prior attempt evidence. CanReclaim=false.

## 2. Logical Record and Trust

The following is a logical host model, not a frozen wire schema or library serialization API.
An implementation must select versioning, canonical encoding, bounds and validation before I/O.

| Record | Required content |
|--------|------------------|
| Request | Host-generated stable request ID; operation role; deployment/namespace and canonical resource scope; revision; current owner session/generation; append-only attempt relation |
| Attempt intent | Full immutable library descriptor: AttemptId, role, canonical artifact/bundle paths, inventory SHA-256, BackupId, document/H, actual optional source epoch, ScalarWal profile and durability |
| Dispatch evidence | Exact attempt/request revision, authorizing owner session/generation, unique dispatch decision, executor incarnation and acknowledged durable transition |
| Execution evidence | Returned library receipt or exception/timeout/exit evidence; preserve the difference between receipt and observation |
| Observation | Request and attempt binding, inspection status/reason, actual observed identity/ID/H/path if any; scope and authority of input; never promoted into a library receipt |
| Reconciliation | Prior-executor stop evidence, remaining reachable workers/queued jobs, fresh authoritative observations, decision and conditional revision |
| Route/work references | Separate authoritative route revision and accepted-work accounting references, with scope and completeness; unknown is never encoded as zero |

Reject missing/unknown versions, duplicate IDs, descriptor mutation, mismatched request scope,
regressing revisions or inconsistent identity/role/path bindings. Treat a reused request ID
with different intent as conflict, not deduplication. Distinct attempts get library-generated
IDs; a retry may use a new destination only as an explicitly recorded independent attempt.
Host path strings require a defined deployment namespace; equal text on another machine does
not prove the same resource. Ownership/session IDs must not be inferred from reusable PIDs.

Protect records with host access controls and bounded decoding. A checksum detects damage,
not malicious alteration or rollback. The backend must prevent stale/rolled-back authority
and define recovery from partial records, lost writes and unavailable quorum/storage. If it
cannot establish current authoritative state, stop and reconcile. Wall-clock timestamps are
diagnostics only, not proof of ordering, executor death or observation freshness.

## 3. Persistence and Dispatch Protocol

A host implementation must document its acknowledged durable-commit semantics and supported
failure domain. Conditional updates must be linearizable within the request/resource scope;
allocation of a dispatch permit and binding of its immutable descriptor must be atomic, or
have a proved protocol with equivalent invariants. No particular database/fsync recipe is
selected here. A successful in-memory write or buffered file write is insufficient evidence.

1. Acquire authoritative request/resource ownership and external exclusion. Enumerate old
   executors and queued work. An unknown prior outcome prevents new dispatch.
2. Prepare one plan through its creating administration instance. Persist its descriptive
   copy and request binding conditionally, and confirm durable success before dispatch.
3. Conditionally transition Recorded to DispatchAuthorized under the current revision and
   owner. Confirm durable success. Only the one live owner holding the original plan may
   invoke ExecuteAttempt once. Do not send executable plans through durable queues.
4. Recheck effective ownership immediately before invocation. This check alone is not a
   fence across the check/call gap: takeover must remain prohibited while this executor can
   still publish. On ownership loss do not start more work; already running work is uncertain.
5. On normal return, persist the actual receipt conditionally. If that save fails/has unknown
   outcome, retain publication uncertainty and read authoritative ledger state. A timeout or
   callback/cleanup error never becomes a negative publication receipt.
6. After failure/restart, obtain fresh exclusion, reconcile prior execution and inspect with
   the retained descriptor. Persist observations separately under a current revision.

Lost ledger-write acknowledgments require authoritative read by immutable attempt ID and
revision. If the exact transition is confirmed, continue only with its still-live original
owner/plan and single-dispatch ownership. If state is absent/stale/unavailable or a different
owner holds it, do not dispatch. Following process loss, no recorded transition reconstructs
a plan; even Recorded state requires reconciliation before a fresh attempt is considered.

There is an unavoidable gap between DispatchAuthorized and invoking the library, and another
between publication and recording the receipt. Do not label DispatchAuthorized as proof of
invocation, publication or nonpublication. A durable outbox may deliver notifications about
attempts, but redelivery must never replay ExecuteAttempt.

## 4. State and Restart Decisions

| State / new evidence | Conditional host action |
|----------------------|-------------------------|
| No durable attempt | Do not dispatch; a live prepared plan has no restart authority |
| Recorded | Retain intent; only original live owner can authorize first dispatch |
| DispatchAuthorized | Execution may or may not have started; no second permit or replay |
| Returned receipt persisted | Record Acknowledged with actual identity; routing still separate |
| Exception, timeout, lost owner or lost receipt-save acknowledgment | Mark/reconcile Uncertain; do not invent absence or acknowledgment |
| KnownOperationMatched after exclusion | Record ObservedKnown, not Acknowledged; retain candidate and require new readiness |
| ArtifactMatched, wrong ID, advanced history, corrupt/unavailable evidence | ReconciliationRequired; preserve histories and stay stopped |
| NotObserved but executor/queue reachability unknown | Remain Uncertain; no retry |
| NotObserved after effective prior-executor exclusion and fresh pinned input check | Record ReconciledAbsent conditionally; eligible to prepare a new attempt, never rearm old plan |
| Owner/revision changes during observation | Discard decision eligibility, keep evidence as historical and reacquire/reobserve |

States are conceptual. An implementation may represent them differently but must retain the
same distinctions. Acknowledged and ObservedKnown are not interchangeable. A stale observation
cannot be applied to a later revision; a later missing candidate cannot erase earlier matching
publication evidence. Conflicting history is reconciliation, not an automatic absent decision.
A reconciled-absent decision grants no exactly-once business guarantee or routing permission.

## 5. Effective Exclusion and Takeover

The scope must include every process that can publish from the artifact, every queued/delayed
job and every destination previously associated with the request. Per-destination rename
prevents overwrite but does not prevent two independent outputs for one request. The host
must serialize overlapping scopes and account for old hosts, old binaries and manual workers.
A cooperating local writer lock or a free ledger lease does not establish this global fact.

Current publication does not consume a host generation/token. Increasing a ledger generation
can fence ledger updates, but cannot stop an old process renaming its staged candidate.
Therefore automatic lease takeover while an old executor may run is forbidden. Supported
future mechanisms could include awaited termination of every owned executor plus drained
queues on a single-host deployment, or independently enforced removal of publication access
covering already-open handles and all workers. Their effectiveness must be tested on actual
supported hosts. No claim that a generic ACL change/network partition closes existing handles
is accepted. Token-enforced publication would require a new reviewed runtime contract.

After exclusion is lost, a completed old publisher may still leave a valid candidate. Keep it,
observe it and reconcile; rejecting its ledger write does not undo namespace publication.
A process exit proves only that exact process exited, not that child/remote/queued workers
were drained. RC3 owns its simple child process scope; it is not a production host fence.

## 6. Route and Work Boundary

Publication, ledger persistence and route compare-and-swap are three separate operations.
Keep database writers stopped across their uncertainty. Before any route proposal, perform
fresh identity/history/ownership checks under continuing exclusion and use the authoritative
expected route revision. Resolve a lost route acknowledgment from that authority, not the
attempt ledger. Accepted-work accounting must cover both branches and all ingress/queues.
Unknown accounting forbids automatic return even if initial H values match.

Never hold an MG5 thread-confined freeze/session across awaits. A future adapter must provide
an explicit lifetime design rather than serializing those objects. This contract enables no
actual route operation, automatic failback, writer resume or source path replacement.

## 7. Fault Review and Implementation Gates

[Machine-readable scenarios](m2-host-attempt-ledger-contract.json) enumerate design expectations,
not executed runtime tests. Exercise each against a selected backend and real executor before
claiming integration. In particular, kill at every durable-intent/dispatch/publication/receipt
boundary, lose write acknowledgments, race revisions, restart old workers after takeover,
redeliver queue work and test stale/rolled-back/malformed records and resource aliases.

| Gate | Required evidence | Current state |
|------|-------------------|---------------|
| HA1 contract | Logical records, uncertain boundaries, effective exclusion, restart and retry rules | Specified here |
| HA1 host selection | Actual consuming application, canonical resource scope, durable backend/commit semantics, executor/queue inventory, enforceable exclusion and route/work authorities | Open; no host supplied |
| HA1 model | Internal pure supplied-evidence transition model, revision/binding checks, adversarial scenario tests; every output keeps writers stopped | Implemented internally; see model validation |
| HA2 integration | Selected host adapter with real persistence/fencing/restart/route/work fault qualification | Open; model tests cannot close it |
| REL | Public API/consumer, archived-reader, supported durability and explicit release review | Open |

The next repository action is an internal pure host-ledger decision model and tests against
these scenarios. It must perform no persistence, dispatch, owning Open or route calls and
must not manufacture trusted host evidence. Actual host selection remains necessary before
choosing a backend or implementing real orchestration.

## 8. Design-Step Validation

Strict documentation and actual hidden/link portability checks pass on Windows and Linux.
SHA-256 comparison of all 163 non-build files under src/ and tests/ confirms that runtime,
tests and frozen fixtures are unchanged in this step. The machine record has 24 unique design
scenarios, each requiring writers to remain stopped. These structural checks do not execute
the proposed state machine or qualify a durable backend. No runtime tests were run for this
documentation-only change; RC3 retains its 71 focused cases per platform at its original scope.


HA1 model follow-up (2026-10-28): [pure classification validation](M2_HOST_ATTEMPT_LEDGER_MODEL_VALIDATION.md)
qualifies supplied-evidence rules internally with 180 new cases. This implements no backend
CAS, persistence or effective fence. Actual host selection and HA2 remain open. Next is an
internal conditional-transition harness for revision and lost-acknowledgment protocol tests.


HA1 transition follow-up (2026-10-28): [in-memory protocol validation](M2_HOST_LEDGER_TRANSITION_VALIDATION.md)
adds exact-revision transitions and simulated lost acknowledgments with 83 new cases. It
provides no durability or effective fence. Next is test-only integration with planned execution;
actual host/backend selection and HA2 remain open. Earlier next-step notes retain their scope.


HA1 test integration follow-up (2026-10-28): [actual planned execution tests](M2_HOST_LEDGER_PLANNED_EXECUTION_VALIDATION.md)
qualify modeled save boundaries with real library publication. This closes the bounded local
integration step, not HA1 host selection or HA2. Next identify actual host/backend, exclusion
and route/work authorities. No production orchestration or durable ledger is implemented.


Selected pilot follow-up: [embedded profile](M2_EMBEDDED_HOST_PROFILE.md) records the user
choice. Earlier host-neutral design statements retain their scope; the target is now selected,
while actual host/backend/fence and route/work integration remain unimplemented. Next EP2
defines the proposed file-journal contract before implementation.
