# M1 Binary Format 1.0

## 1. Common Envelope

Every file uses the following encoding. All integers are little-endian. The decoder
rejects versions other than exactly 1.0. Paths contain invariant unsigned decimal IDs;
no file paths are decoded from persisted strings. Symlink/junction traversal is rejected.

| Offset | Width | Field |
|--------|-------|-------|
| 0 | 4 bytes | ASCII magic: BXDB, BXMF, BXND or BXFG |
| 4 | u16 | Major = 1 |
| 6 | u16 | Minor = 0 |
| 8 | i32 | Body byte length, nonnegative |
| 12 | body length | Body |
| 12 + body length | 32 bytes | SHA-256 of the entire preceding header and body |

A file is at most 64 MiB, including envelope. Trailing or truncated bytes are rejected.
Strings are strict UTF-8 with an i32 byte length, maximum 1 MiB. Counts are bounded
before allocation. The source XML character limit is 16 Mi characters; import depth
is at most 256. Directory count is at most 1,000,000 including namespace nodes.
No compression is supported. Empty values still point to a real fragment.

## 2. Files and Bodies

```text
<root>/FORMAT
<root>/documents/<document-id>/manifest.bin
<root>/documents/<document-id>/directory.bin
<root>/fragments/<fragment-id>.bin
```

| File | Magic | Body fields, in order |
|------|-------|-----------------------|
| FORMAT | BXDB | u8 flags=0 |
| Manifest | BXMF | u64 DocumentId; u64 root NodeId=1; string DocumentUri; 32-byte SHA-256 of complete directory file; i32 fragment count; entries |
| Manifest entry | — | u64 FragmentId; i32 decoded payload length; 32-byte SHA-256 of complete fragment file |
| Directory | BXND | i32 node count; ordered node records |
| Fragment | BXFG | u64 FragmentId; u64 DocumentId; u8 codec=0; i32 payload length; raw UTF-8 value arena |

Codec 0 has identical stored/uncompressed lengths, so a separate uncompressed-length
field is unnecessary in this M1 encoding. This concretizes the source plan's proposed
headers; it is not asserted to be a pre-existing format.

Fragment IDs are consecutive from 1. Fragment 1 holds header and non-line content.
Subsequent fragments group direct root SalesOrderLine elements by configurable
lines-per-fragment. Cold extensions stay in the header in this initial policy.
Each store root currently contains one immutable imported document; append/update
and multi-document catalog support are not implemented.

## 3. Node Records

Fields: u64 NodeId; u64 ParentId (zero only for document); u8 kind; four strings
(LocalName, NamespaceUri, Prefix, effective BaseUri); u64 value FragmentId; i32 byte
offset; i32 byte length; then three ID lists (children, attributes, namespaces).
Each list is i32 count followed by count u64 IDs.

Kind values: document=1, element=2, attribute=4, text=8, comment=16,
processing-instruction=32, namespace=64. Namespace nodes use LocalName for the bound
prefix and empty NamespaceUri/Prefix; their URI is their scalar fragment value.

Node IDs start at 1 and follow canonical preorder: owner, its in-scope namespace
nodes, attributes, then child subtrees. IDs supply immutable nonzero document order.
Document/element scalar pointers are zero; other values point into fragment payloads.
Ordered links must match node kind, ownership and canonical preorder. Every non-root
node has exactly one incoming link. Pointers must fit manifest-declared payload bounds.
There must be one document root with one element child; graph depth is bounded.

## 4. Fixtures, Integrity and Compatibility

Fixed hexadecimal fixtures in tests/TestData cover FORMAT, manifest, directory and
fragment for `<r/>`. They were encoded independently from the product codecs and
are compared byte-for-byte by tests. Corruption tests cover framing, versions,
checksums, lengths, truncation, graph errors and lazy payload validation.

Metadata is checked at Open; payload checksums are checked when the fragment is first
read. The cache assumes store files remain immutable during snapshot use. SHA-256
provides integrity detection, not authenticity. There is no migration or crash-safe
commit protocol. Change the version and golden fixtures deliberately when evolving
encoding; reject unsupported files rather than guessing compatibility.

*Last updated: 2026-10-26*
