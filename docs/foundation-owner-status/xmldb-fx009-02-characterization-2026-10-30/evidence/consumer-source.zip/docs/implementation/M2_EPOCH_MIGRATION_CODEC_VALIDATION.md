# MG1 Migration-Origin Codec Validation

Date: 2026-10-27. Scope: pure provenance and header/seal consistency under
[ADR-018](../ADR-018-full-history-legacy-migration-and-cutover.md), frozen in the
[1.0 byte contract](M2_EPOCH_MIGRATION_FORMAT_V1.md). No migration runtime is implemented.

The 54 new Storage cases cover independent H0/H2 vectors and their pinned SHA-256,
all 700 origin prefixes and 1,101 context header/inventory/completion prefixes,
resealed unsupported magic/major/minor/length/role and required identities, invalid
zero/positive heads, inclusive maximum H and digest sizes, cross-role rejection, every
source/destination commitment substitution, coherent resealed wrong control/current
documents and immutable destination profile, strict H0 CURRENT omission, source count/path
allocation bounds, traversal/device/duplicate/order/length cases and missing header roles.

Golden vectors are independently assembled by the Python stdlib generator with no product
encoder calls. Twelve new hex files are metadata/header context, not complete migration
bundles or source artifacts. Decoder tests pin both origin hashes and exercise their
cross-linked context. Existing fixture files, reader binaries, codecs and profiles remain
unchanged. No production persistence path calls the new codec yet.

The runtime regression command excludes EpochBackupFaultTests: its 18 expensive ET9-D
cases exercise unchanged capture/restore persistence paths, with prior proof retained in
[ET9-D evidence](m2-epoch-backup-fault-results.json). Fresh MG1 regression coverage is 705
cases per platform (555 Storage, 27 Xdm, 123 Integration), including all 54 new cases.
The combined test catalog is 723 cases; this is not a fresh 723-case full run. Exact final
counts and platform status are recorded in [machine results](m2-epoch-migration-codec-results.json).

Windows command: dotnet test Bosak.XmlDb.slnx --no-restore --filter
FullyQualifiedName!~EpochBackupFaultTests --logger trx. Linux uses tools/test-linux.ps1 with
the same filter, isolated read-only source/cache and no network. ProcessCrash/native
persistence evidence remains in the retained ET9-D report; MG1 introduces no native I/O.
Formatting, strict documentation and independent fixture hash checks complete this gate.

Header-context acceptance does not prove file closure, WAL contents/chain, actual store
materialization, full-history parity, source authenticity/freshness, admission or cutover.
MG2-MG5 and broader archived C1-C3 remain open. Next: MG2 legacy complete/redo verifier only.
