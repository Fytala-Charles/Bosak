# M2 Empty-Chain Epoch Coordinator Validation

Date: 2026-10-27. Scope: [ADR-014](../ADR-014-admitted-empty-chain-epoch-coordinator.md), internal ET4.
**323 tests pass on Windows and 323 on Linux**, zero failures/skips in either full run:
202 Storage, 27 Xdm and 94 Integration. Release builds use SDK 10.0.301; Windows runtime
10.0.11 and Ubuntu 24.04 runtime 10.0.9 / Docker overlayfs. Seven existing MINVER1001
warnings remain. Formatting and strict FYTALA checks pass.

Forty-two persistence sweep cases verify **1,310 Windows / 1,262 Linux positions**;
six ET4 initialization cases account for **82 / 74**. Per-scenario counts and platform
provenance are in [structured results](m2-empty-epoch-results.json). Current TRX is
.tools/et4-windows-results and .tools/et4-linux-results. Native Linux stronger reopen
with live snapshots executes successfully; no native Windows directory-fsync is claimed.

## Evidence

Twenty Storage cases cover independent snapshots across owners, writer/maintenance/base
exclusion, unsupported nonempty/current/unknown state refused without mutation, corrupt
authority/data and stable-reader refusal, exact-profile forks, transaction-context base
capture/rollback, deterministic dispose-after-admission races, stronger adoption with a
live old snapshot and six process/strong before/after/partial initialization fault sweeps.
Every injected initialization failure must release ownership, allow exclusive admission
and support repeated valid reopen. No failed canonical identity is overwritten.

Twelve Integration cases cover six initialization kill/ack boundaries, live writer and
maintenance exclusion, four snapshot/transaction-context close/kill lifetimes after
owner disposal and XPath/identity/lazy-I/O parity. Reader contexts perform actual uncached
line reads after their coordinator has closed. A later coordinator can coexist with
those children while exclusive epoch and base-reader probes remain blocked.

Existing profile/authority golden fixtures and both frozen reader baselines are unchanged.
The complete suite includes prior v1 transactions/backup/read-only epoch/fault tests.
No scalar mutation/replay durability claim is made by this empty-chain slice.

## Reproduction

```powershell
dotnet build Bosak.XmlDb.slnx -c Release --no-restore
dotnet test Bosak.XmlDb.slnx -c Release --no-build --logger 'trx;LogFilePrefix=et4' --results-directory .tools/et4-windows-results
pwsh tools/test-linux.ps1 -ResultsDirectory .tools/et4-linux-results
```

Linux runner uses SDK 10.0.301, read-only source/cache mounts, no network and isolated
overlayfs. Native Linux stronger adoption executes; Windows is ProcessCrash plus modeled
stronger policy. Physical power loss/real bounded-volume ENOSPC, production controller/
filesystem certification, remote CI, public epoch creation/migration and reclamation
remain unproved/unimplemented. All source history and stable lease identities are retained.

*Last updated: 2026-10-27*
