# M2 Empty-Chain Epoch Coordinator Contract

Implemented internal ET4 slice per [ADR-014](../ADR-014-admitted-empty-chain-epoch-coordinator.md).
All public APIs retain their previous capability gates. No public ScalarWal coordinator,
root creation, scalar staging, commit, recovery or migration API is added.

## Accepted Root

Require exact ScalarWal 2.1 FORMAT, matching EPOCH/BXEA admission, BASE and CONTROL bound
to the actual base manifest. Require .transactions/wal, generations, readers and staging
directories without links. WAL and published generation directories must be completely
empty, including unknown files/directories. An existing CURRENT must decode with the
same binding and sequence zero; nonzero is unsupported and corruption fails closed.
Unknown top-level transaction entries and wrong file/directory roles are refused.

Readers may contain only the stable zero-sequence identity or recognizable unpublished
zero-identity .tmp-<guid-N> files from failed initialization. Never adopt temporary bytes.
Staging is retained/ignored as unpublished scratch, never used as a head. Required data,
manifest/directory metadata and every fragment are verified before writer creation.
Private generation paths lack root authority/admission and cannot be adopted as roots.

## Open and Selection Order

1. Parse the explicit ScalarWal profile and acquire shared epoch admission. Immutable
   defaults do not accept it. Bind tokens/forks to the exact profile and root identity.
2. Validate BASE/CONTROL, canonical empty state, metadata and all base payloads. Refuse
   invalid/nonempty state before writer.lock creation; release admission on failure.
3. Acquire nonblocking FileShare.None writer.lock ownership and recheck the authority and
   bound base/profile. A competing owner cannot be bypassed by a second coordinator.
4. Synchronize according to policy. Strong mode skips writable opens of the held admission
   identity and validated stable reader identities while synchronizing namespace entries,
   other data and ancestry. Format-1 callers do not opt into the new admission skip.
5. If absent, write/flush a private temporary BXER zero identity, rename without overwrite
   to readers/00000000000000000000.lease and synchronize the parent. Existing canonical
   identity must validate and is never replaced. Return the initialized internal owner.

Only the OS writer-lock entry and stable reader identity are runtime changes. No CURRENT,
WAL, generation, control or base rewrite occurs. FileStream creates the OS writer handle
as in the existing coordinator; namespace barriers and all data/identity writes use the
transaction storage seam. An initialization exception returns no owner and closes all
acquired handles. It can leave a writer file, private temporary identity or complete
stable identity; reopen validates/reuses supported state. No orphan cleanup or deletion.

## Snapshot and Transaction Ownership

BeginRead forks an independent explicit-profile admission outside the coordinator gate.
Under the gate, reject disposed/faulted owners, revalidate empty authority against the
captured base/profile and acquire the canonical shared BXER base handle. Transfer both
handles into the returned ImmutableXmlSnapshot. The internal loader requires a live
shared token with the exact expected profile/root/identity and manifest digest.

Closing the coordinator releases writer ownership and its parent admission, not children.
A later coordinator may reopen while old snapshots remain. Each snapshot blocks both
exclusive epoch maintenance and exclusive base-reader access until disposal/process exit.
A deterministic test pauses after admission but before the gate; if Dispose wins, the
operation releases its own child without returning a snapshot or leaking a handle.
Failures after selection release their handles; I/O/invalid/unsupported state faults
that live owner and requires reopen. Negative cache arguments do not acquire a child.

BeginTransaction captures an internal lifetime-only context: unique transaction ID,
owner reference, epoch identity, base sequence zero and cloned base hash, plus its own
snapshot/handles. Base reads remain valid after owner disposal; Rollback/Dispose releases
only that context. No staging, target replacement, Commit or read-your-writes behavior
exists. ET5 must add scalar validation/conflicts/persistence and actual transaction
completion; it must not mistake this ownership context for a completed commit API.

## Durability and Fixture Production

ProcessCrash is default. FileAndDirectoryFlush is explicit Linux-only with no silent
fallback; modeled Windows stronger-policy tests do not certify native directory fsync.
Strong reopen while old snapshots are alive must not open shared identity files for
write. Their bytes were already file-flushed at publication; sync their directories.

Internal EpochEmptyRoot.CreateFixture accepts only an immutable unadopted M1 source and
new destination. It creates fresh identities/profile in staging, copies canonical data
without nested M1 FORMAT, writes BASE/CONTROL and empty required directories, and verifies
base integrity under explicit admission before publishing the whole root. Source bytes
are retained. This is test infrastructure, not a public conversion or full-history migration.

## Remaining Gates

ET4 now covers internal empty-chain ownership, real snapshots and transaction contexts.
ET5 scalar staging/commit and ET6-ET8 publication/replay/fault recovery remain unimplemented,
as do ET9 epoch backup/migration, complete C1-C3 and retirement. Any nonempty WAL/generation
or positive CURRENT is rejected rather than replayed, cleaned or silently downgraded.
No lease inode or original committed history may be removed.

*Last updated: 2026-10-27*
