# M2 Epoch Backup Metadata Format 1.0

Implemented for internal ET9-A per
[ADR-017](../ADR-017-epoch-full-history-backup-and-independent-restore.md) and
[semantic design](M2_EPOCH_BACKUP_DESIGN.md). Exact metadata bytes are frozen with independent
fixtures. ET9-B/C now implement internal capture/restore; exhaustive faults and public APIs remain pending.
The [candidate document](M2_EPOCH_BACKUP_FORMAT_DESIGN.md) records design provenance.

## 1. Envelope and limits

Use BinaryEnvelope framing: four ASCII magic bytes, LE u16 major=1/minor=0, LE i32 body
length, exact body, then 32-byte SHA256 of header+body. Reject unsupported versions,
truncation, negative/oversized lengths, trailing bytes, invalid UTF-8 and bad checksums.
All complete files/inventories are bounded to 64 MiB. GUIDs are 16 bytes in .NET
Guid.ToByteArray order, not a newly introduced network byte order. Digests are SHA256 of
complete referenced files, including their envelope checksum. No record contains absolute
paths, a supplied destination, timestamps, live handles or ownership claims.

The frozen magic values are BXEI (inventory), BXEZ (completion) and BXEO (restore origin).
They are distinct from format-1 BXBI/BXBC and every existing epoch authority role.
Wrong-role/legacy bytes must fail; no parser fallback, alias or magic rewriting is allowed.
All integers below are little endian and all fixed digests are exactly 32 bytes.
The tables define entire bodies; do not insert the existing authority codec's role byte.

## 2. Inventory: inventory.bin / BXEI 1.0

| Field, in order | Encoding and validation |
|-----------------|-------------------------|
| ClosureContract | u16, exactly 1: fully materialized complete retained history |
| BackupId | GUID, nonzero |
| SourceStoreId | GUID, nonzero |
| SourceEpochId | GUID, nonzero |
| DocumentId | u64, nonzero |
| SourceFormatHash | digest of exact data/FORMAT |
| BaseManifestHash | digest of complete base manifest |
| CommitSequence H | u64, 0..10,000 |
| HeadManifestHash | digest of manifest at H |
| SourceHeadWalHash | digest of complete source WAL H; zero when H=0, nonzero otherwise |
| EntryCount | i32, 1..100,000 |
| Each Entry.Path | i32 strict UTF-8 byte length then path bytes |
| Each Entry.Length | i32 complete file size, 44..64 MiB |
| Each Entry.Hash | digest of the complete declared file |

The fixed body prefix including EntryCount is 198 bytes. Each entry adds 40 bytes plus
its UTF-8 path length. Complete file length is 242 + sum(40 + path byte length).
Bound counts by remaining body bytes before allocating collections; use checked aggregate
arithmetic and stream file copying/hashing rather than allocating the whole data closure.

Paths are relative to data/, use / separators, contain only ASCII letters/digits plus
., - and /, and are at most 512 bytes/characters. Components cannot be empty, dot or
dot-dot. Reject device/portable aliases and trailing dot/space rules consistent with
BackupStorage, colon, backslash, rooted/drive/UNC paths and case collisions. Entries are
strictly ordinal sorted and unique also under OrdinalIgnoreCase.

Syntactic path acceptance does not authorize restore I/O. Semantic verification derives
and compares the exact closure from the supported source FORMAT, DocumentId, H and copied
manifests. Only the paths specified by M2_EPOCH_BACKUP_DESIGN.md section 4 are accepted.
A valid digest cannot excuse unknown, missing or extra files/directories. Require source
ScalarWal 2.1 identity/FORMAT/base bindings throughout. H=0 requires equal base/head manifest
hashes and no WAL/generations; canonical CURRENT at zero is still mandatory in this format.

## 3. Completion: COMPLETE / BXEZ 1.0

| Field, in order | Encoding |
|-----------------|----------|
| BackupId | nonzero GUID matching the inventory |
| InventoryHash | digest of complete BXEI file |

The body is 48 bytes; complete file length is 92 bytes. Both fields must match the
verified inventory before any artifact is accepted. There is no independent completion
flag. Publication follows data/inventory/completion file and directory barriers, exact
closure verification and both private recovery oracles. COMPLETE alone authorizes nothing.

## 4. Restore origin: origin.bin / BXEO 1.0

| Field, in order | Encoding and validation |
|-----------------|-------------------------|
| RestoreId | fresh nonzero GUID for the restore attempt |
| BackupId | source inventory GUID |
| InventoryHash | digest of complete source BXEI |
| SourceStoreId | source GUID |
| SourceEpochId | source GUID |
| DestinationStoreId | fresh nonzero GUID, different from SourceStoreId |
| DestinationEpochId | fresh nonzero GUID, different from SourceEpochId |
| DocumentId | preserved nonzero u64 shared by source/destination |
| CommitSequence H | preserved u64, 0..10,000 |
| SourceFormatHash | exact source FORMAT digest |
| DestinationFormatHash | exact rebound destination FORMAT digest |
| BaseManifestHash | shared unchanged base manifest digest |
| HeadManifestHash | shared unchanged manifest digest at H |
| SourceHeadWalHash | source-chain head digest; zero at H=0, nonzero otherwise |
| DestinationHeadWalHash | rebound-chain head digest; zero at H=0, nonzero otherwise |

The body is 336 bytes; complete file length is 380 bytes. H=0 additionally requires equal
base/head manifest hashes. Validate all source fields against the sealed inventory and
source data, and all destination fields against the independently verified transformed
store before publishing or acknowledging a restore bundle. Hashes alone do not establish
a source/destination identity relation without those checks.

Origin is mandatory for restore-bundle acceptance and lies outside store/. It is neither
a store-root marker nor a current recovery selector. Its H describes the initial restored
prefix; later commits do not rewrite it. It contains no relative-root field: the bundle
schema fixes store/ literally, so a decoded record cannot redirect opening to another path.
Publishing the entire bundle makes origin and store visible together. Ordinary existing
ScalarWal open/recovery remains independent of this audit sidecar. Deleting/changing origin
can invalidate bundle provenance without introducing a fallback or changing WAL authority.

## 5. Implemented pure codecs and header checks

EpochBackupCodec is internal and performs no file I/O, admission acquisition, recovery,
publication or capability grant. It enforces both encoding and decoding invariants.
DecodeInventory checks EntryCount against the remaining body's minimum per-entry size
before allocating, and each path byte count against 512 and remaining bytes before reading.
Encoding checks the complete projected inventory size before constructing the envelope.

ValidateCompletion compares BackupId and SHA256 of complete inventory bytes.
ValidateSourceHeaders compares inventory identity/FORMAT digest and H/head/WAL against an
explicit ScalarWal FORMAT and bound CURRENT. ValidateOriginHeaders compares every source
inventory commitment and destination identity/FORMAT/current-head commitment. Unsupported
profiles and foreign roles/bindings fail closed.

These checks establish metadata/header consistency only. They do not derive manifest file
closure, verify physical data/files or WAL chains, redo history, prove source authenticity,
verify a restore bundle or grant admission. ET9-B/C now supply internal capture/restore proof; exhaustive faults remain the ET9-D gate. Unknown
but syntactically portable paths can decode as metadata; future closure validation must
reject undeclared semantic paths before I/O. Parsing a ClosureContract value is not proof
that its promised closure exists. Raw DTOs are not verified-artifact or ownership tokens.

## 6. Independent fixtures and version boundary

The three fixtures and their documented independent Python standard-library generator are
in tests/TestData. No production encoder is invoked to author expected bytes. The inputs
include independently assembled ScalarWal FORMAT digests and fixed GUID/digest vectors.
The fixtures are metadata records, not complete store/backup artifacts: the inventory's
two sample file entries do not satisfy the later full-history closure. Preserve existing
format-1/epoch fixtures and both frozen reader families unchanged.

| Role | Fixture | Complete bytes | SHA256 |
|------|---------|----------------|--------|
| Inventory | epoch-backup-inventory-v1.hex | 332 | 5847abe5c14bcbe2fe7df72b40f8a40493baea77445e1c38aa94532f904049c3 |
| Completion | epoch-backup-completion-v1.hex | 92 | 7106e4f2081fc347942f39d97e481ed9a7a0faf68fb08970c05e7a7f21befd00 |
| Origin | epoch-restore-origin-v1.hex | 380 | 3690253d1fcbce489f2fd5b29d733d2c4e333bfdfa4b04816fd348336bbcadb4 |

[Validation](M2_EPOCH_BACKUP_CODEC_VALIDATION.md) covers all 804 truncated prefixes, exact
bytes, framing/role rejection, bounded hostile fields, portable aliases/case collisions,
zero/max head/count/path/file boundaries and foreign completion/origin/header contexts.
These new layouts are frozen for metadata1.0; future incompatible changes require a new
version and independent fixtures. Existing store/backup formats are unchanged. ET9-A alone enables no runtime or public API. ET9-B/C now add internal capture/restore; public
APIs remain pending.

*Last updated: 2026-10-27*
