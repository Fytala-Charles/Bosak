# EP7-A Embedded Pilot Authority Classification Validation

Date: 2026-10-29. Internal implementation of the pure classification gate in
[ADR-028](../ADR-028-embedded-pilot-selection-and-work-authority.md) and the
[pilot contract](M2_EMBEDDED_PILOT_AUTHORITY_CONTRACT.md).

## 1. Implemented Boundary

EmbeddedPilotAuthorityClassifier accepts immutable supplied evidence and returns either
ReconciliationRequired or descriptive new-source/new-candidate readiness eligibility.
Every result has WritersMustRemainStopped=true. There is no I/O, path resolution, callback,
registration, authority acquisition, recovery, route mutation, work execution or write permit.
All evidence flags are caller assumptions, not verified ownership, freshness or host facts.

Exact contexts bind authority/admin journal IDs, deployment/resource, owner session, baseline,
source/candidate roots and admission keys, initial histories, publication attempt/artifact/admin
position, authority sequence/digest, selected branch and selection revision. Observations must
match the entire expected context. Freshness, enrollment, full-history validity, actual drain,
writer/publisher exclusion, selection acknowledgment, exact publication match and administrative
agreement are separately required supplied facts. Unknown selection acknowledgment stays stopped
for reconciliation; reading a complete record cannot manufacture a prior acknowledgment.

Legacy roots carry no fabricated epoch identity. Epoch roots require actual nonempty store/epoch
and matching document IDs. Source/candidate roots and admission keys must differ; epoch source
and destination cannot reuse either identity. Both initial heads/document IDs agree, while
independent history digests bind their different encodings. H=0 and H=10,000 are supported model
boundaries. Canonical keys are opaque: alias/namespace and physical identity verification remain
later host responsibilities. Case-insensitive collision rejection is conservative, not path proof.

## 2. Retained Work Accounting

Both branch summaries are nullable; unknown is never zero. A complete immutable acceptance
inventory is mandatory. Validate nonempty globally unique work IDs, exact baseline/target,
branch, selection revision, intent digest and known outcome enum before comparing exact counts.
A current-revision acceptance must match the current selected branch. Older revisions are
supplied history claims, not independently reconstructed selection transitions.

Unknown outcomes remain obligations requiring reconciliation. Committed and confirmed-no-effect
acceptances also require reconciliation and never produce zero-work eligibility. Duplicate IDs
across either branch reject even if fields/outcomes agree. Counts cannot be reset to erase work.
The 1,024-record bound applies to this model input only, not a future on-disk format; over-limit
inputs reject without truncation. Exhausted UInt64 positions reject before any increment.

## 3. Test Evidence

119 focused Windows cases pass with zero failures/skips. Coverage includes both selected
branches with legacy and epoch sources; missing/stale/foreign/contradictory evidence; exact
scope/position/attempt/artifact/target binding; null identities; overflow and record bounds;
unknown branch counts; pending, committed and no-effect work; duplicate IDs within/across
branches; counter-reset rejection; equal preserved heads and supported H boundaries.
Every tested result asserts stopped writers. These are actual pure model bodies, not
host-specific early-return scenarios or process/persistence qualification.

Fresh unfiltered Windows Debug full-solution regression passes all 2,013 cases, with zero
failures/skips: 1,393 Storage, 593 Integration and 27 Xdm. The 119 new cases are included,
not added again. Storage duration is 42 m 9 s. Restore/build also pass, and final source
hashes match the files used by the focused run. Existing full-suite catalog passes include
host-only guard returns; all new pure classifier cases execute their actual test bodies.
The Linux focused command could not start because Docker Desktop's Linux engine named pipe
is unavailable. No current Linux execution/pass is claimed. Prior 1,894-case full Windows
readiness evidence remains dated baseline evidence rather than this implementation's result.
Solution formatting/analyzer verification, strict documentation and actual hidden/link
portability checks pass on Windows. No new persistent byte vectors are introduced by EP7-A.
[Machine evidence](m2-embedded-pilot-authority-classification-results.json) records file hashes,
TRX references and exact completed validation scope.

## 4. Delivery and Next Gate

Only two new C# files implement/test EP7-A; no existing production/test C# file, frozen fixture,
public signature, package pin, host/store format or API admission behavior changes. Documentation
is synchronized with the preceding audit/design work, which remains uncommitted on HEAD 4598346.
No commit/push is performed. This model does not close release, archived-reader, real consumer,
physical power-loss/real ENOSPC, external fencing or retirement gates. CanReclaim remains false.

Next EP7-B specifies the separate bounded application-authority byte/transition and provisioning/
commit contract before codec/persistence. Preserve BXHM/BXHJ v1 and the existing host-root roles.
Do not infer full-history validation or authority from this classifier; do not append new records,
recreate work/tickets, resume writers or reclaim histories from its descriptive classifications.
