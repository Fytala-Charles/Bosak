# M2 Internal ET6 Epoch Recovery Validation

Date: 2026-10-27. Decision: [ADR-016](../ADR-016-internal-epoch-redo-and-publication-faults.md).
Runtime: [ET6 contract](M2_EPOCH_RECOVERY.md). Internal validation does not enable a public
mutable API, epoch migration, backup or committed-history reclamation.

## Final suite

| Platform | Storage | Xdm | Integration | Total | Failed / skipped |
|----------|---------|-----|-------------|-------|------------------|
| Windows | 248 | 27 | 108 | 383 | 0 / 0 |
| Ubuntu 24.04 / Docker overlayfs | 248 | 27 | 108 | 383 | 0 / 0 |

SDK10.0.301; Windows runtime10.0.11; Linux runtime10.0.9. Linux uses the existing pinned
mcr.microsoft.com/dotnet/sdk:10.0.301 image, source/cache read-only and network disabled.
Native Linux stronger-policy reopen/redo executes after modeled storage failures. The
faulting seam models stronger barrier ordering on both platforms; it does not inject into
actual kernel fsync. Earlier native strong commit tests remain included. Seven known
MINVER1001 warnings persist because this checkout has no commit.

TRX: .tools/et6-windows-final and .tools/et6-linux-results.
[Structured evidence](m2-epoch-recovery-results.json) contains observed per-scenario fault
positions, counts and provenance. Formatting and strict documentation hygiene pass.
An exploratory Windows build collided with a focused testhost's DLL lock; the final full
run started after that runner exited. Earlier ET5 evidence remains historical.

## New evidence

Forty-two new cases add 34 Storage and eight Integration tests:

- Twelve sweeps inject each observed before/after persistence call and partial file write
  for commits from zero and positive heads, under process and modeled stronger policies.
  Faulted owners refuse further reads. Reopen twice selects exact old/new sequence and
  value according to complete WAL authority; old uncached snapshots remain readable.
- Six redo sweeps cover every observed open/rebuild/publication persistence call and partial
  write. Failed open releases admission/writer ownership. Two later opens reproduce exact
  recorded state while preserving WAL bytes.
- Six tail-removal sweeps cover before/after persistence calls and any observed write
  calls. Partial-write variants have zero eligible positions when recovery only removes
  an unwitnessed append and does not need to write CURRENT. Committed prefix WAL is unchanged.
- Every truncation of a valid epoch WAL is exercised with root-matching available binding
  bytes. Supported unwitnessed physical prefixes are removed and the base is selected.
  Bad complete checksums, magic/version/length corruption, later WAL, CURRENT, published
  generation and stable reader witnesses are retained/refused. A resealed wrong result
  digest cannot publish a substitute generation.
- Five process cases kill before WAL, after WAL flush, after reader/CURRENT publication
  and after in-memory completion. Three recovery cases kill after staging, generation
  and CURRENT publication, including two consecutive staging kills. Repeated reopen
  reproduces the expected sequence/value and preserves complete WAL. Existing lost-
  acknowledgment and exact node/order/value/URI/namespace/XPath tests remain included.

The observed sweep inventory comprises 24 new ET6 cases plus 42 prior cases. Zero-position
partial variants are reported explicitly, not counted as tested I/O sites. The final totals are **2,162 Windows / 2,098 Linux fault positions**, including
**852 / 836 new ET6 positions**. The JSON report records each scenario independently.

## Reproduce

```powershell
dotnet test Bosak.XmlDb.slnx -c Release --no-restore --logger 'trx;LogFilePrefix=windows' --results-directory .tools/et6-windows-final
$env:DOTNET_ROLL_FORWARD = 'Major'
& ./.tools/pwsh.exe -NoProfile -File tools/test-linux.ps1 -ResultsDirectory .tools/et6-linux-results
dotnet format Bosak.XmlDb.slnx --no-restore --verify-no-changes
& ./.tools/pwsh.exe -NoProfile -File tools/check-docs.ps1 -ProjectPath . -Strict
```

## Remaining gates

ET7 must complete combined adversarial classification for foreign epochs/roles, gaps,
duplicate IDs, resealed pointers, published witnesses and multi-step interrupted redo.
ET8 broader platform qualification, ET9 fixed-head epoch backup/history migration, full
archived reader C1-C3 and retirement remain pending. No public mutable API or deletion of
committed history is enabled. Private failure stages are retained. Full-history I/O has
no performance promise. Simultaneous destruction of every journal/publication witness is
beyond what the remaining base can prove.

Injected disk-full errors are not real capacity exhaustion; local overlayfs execution is
not physical power-loss, production-controller/filesystem or remote CI certification.
