# M2 ET9 Epoch Backup and Restore Design

Date: 2026-10-27. [ADR-017](../ADR-017-epoch-full-history-backup-and-independent-restore.md)
defines backup/restore behavior. ET9-A now implements pure metadata codecs with independent
fixtures in the frozen [byte contract](M2_EPOCH_BACKUP_FORMAT_V1.md). ET9-B now implements
[internal capture and full verification](M2_EPOCH_BACKUP_CAPTURE.md); ET9-C now implements
[independent restore](M2_EPOCH_BACKUP_RESTORE.md). ET9-D now qualifies observed persistence faults and repeated process boundaries. Existing format-1
operations and all public profile gates remain unchanged. The
[candidate document](M2_EPOCH_BACKUP_FORMAT_DESIGN.md) preserves design provenance. A [machine-readable work plan](m2-epoch-backup-design.json)
records the design/implementation boundary and next gate.

## 1. Scope and identities

First support one exact ScalarWal 2.1 document with full retained history 0..H, H<=10,000.
Immutable 2.0 and format-1 inputs fail before output creation through this entry point;
existing format-1 backup/restore remains separate. Full-history migration/cutover requires
later work and cannot be inferred from backup/restore success.

A backup preserves source StoreId/EpochId, DocumentId, profile/FORMAT digest, base and head
manifest hashes, H, head WAL digest and exact declared source bytes. A restore assigns
fresh nonzero StoreId and EpochId, each different from the source, and a fresh RestoreId.
DocumentId, node IDs/topology/order, expanded names, prefixes, URI/base URI, scalar values,
sequence numbers and transaction IDs stay unchanged. It is an independent writable branch,
not replication or continuation under the source identity.

## 2. Artifact and restore layouts

```text
<backup>/inventory.bin                # Candidate BXEI inventory
<backup>/COMPLETE                     # Candidate BXEZ completion
<backup>/data/...                     # Only exact declared source files

<restore-destination>/origin.bin      # Candidate BXEO, initial restore provenance
<restore-destination>/store/          # Fresh ScalarWal root; returned StorePath
```

Neither backup root nor backup/data is an admitted live store: no source admission/lock
files are copied. A restore destination is explicitly a bundle. Applications route only
to the returned store/ path after successful publication and independent Open. They must
not treat the bundle itself as a root. No path comes from inventory/origin content.

Origin binds BackupId, inventory digest, RestoreId, source/destination identities, H,
FORMAT digests, base/head manifest hashes and source/destination head WAL digests. It
records the initial restored prefix, not the branch's later current head. Subsequent
commits append normally; origin is not rewritten and cannot excuse recovery corruption.
It is outside the store's recovery authority and changes no FORMAT/profile requirement.
A subsequent backup binds its immediate source epoch; recursive ancestry/authenticity is
not promised. Full source-to-destination provenance verification requires the referenced
sealed artifact; origin plus destination alone establishes only local consistency, not source
authenticity. Restore acknowledgment requires a valid origin and root in the same bundle.

```mermaid
flowchart LR
  S["Admitted source at H"] --> A["Sealed exact source artifact"]
  A --> V["Complete-data and full-WAL verification"]
  V --> R["Fresh identities and rebound WAL chain"]
  R --> B["Verified store plus origin bundle"]
  B --> P["Atomic publication then explicit store path"]
```

## 3. Fixed-head capture and ownership

1. Validate an absent, nonoverlapping destination and existing unlinked parent using the
   portable path rules. Resolve/select durability without unsupported-platform fallback.
2. Fork shared ScalarWal admission before taking the coordinator gate. Under the gate,
   require a live unfaulted owner and its existing exclusive writer handle. Capture holds
   that gate, writer and operation child admission until completion/failure. Dispose races
   release only the operation's handles; existing snapshots keep their own protection.
3. Revalidate complete history against the cached owned head and select H. Require exact
   canonical CURRENT for H, all WAL 1..H and all generations 1..H. Missing/corrupt authority,
   uncommitted tails or missing materializations fail capture. Reopen/recover outside this
   operation before retrying; capture never repairs or reduces the source.
4. Derive the exact file closure below, bound counts/sizes and reject unknown dependencies.
   Copy bytes through ITransactionStorage to a newly owned sibling workspace on the
   destination filesystem. The source root and all its history remain untouched.
5. Hash copied files, validate exact closure and run both verification oracles in section 5.
   No gate release between selection, copying, verification and publication is allowed.
6. Flush inventory then COMPLETE, validate the sealed artifact, close clone handles, then
   publish to the absent destination by rename and synchronize affected directories.
   Return BackupId/source identity/H/hashes only after publication barriers.

Pure argument/destination rejection does not fault an owner. After capture persistence or
history verification begins, I/O/verification failures fault the owner; close/reopen before
retrying. The operation closes only its admission/clone handles, never another snapshot.
The operation is implemented internally by ET9-B; no public capture API is added.

## 4. Exact source closure

Include only:

- Root FORMAT, EPOCH and BASE.
- Base documents/<DocumentId>/manifest.bin and directory.bin, and every manifest-referenced
  fragments/<id>.bin.
- .transactions/CONTROL and canonical CURRENT exactly selecting H, including H=0.
- Canonical WAL 1..H and complete generations 1..H, each with FORMAT, GENERATION,
  document manifest/directory and every referenced fragment.

Root and generation FORMAT bytes must agree exactly and match the explicit ScalarWal tuple.
Every descriptor binds that source epoch, FORMAT and base. H=0 has no WAL/generation entries,
head manifest equals base and head WAL digest is zero. A lagging selector is not sealed as H.

Exclude .epoch/admission.lease, writer.lock, all stable reader identities and reader
publication temporaries, staging trees and recognized current publication temporaries.
Required empty runtime directories are not artifact entries; verification/restore creates
them privately. Root .epoch may contain only the recognized admission identity; no ignored
future authority may hide there. Reject unknown root/transaction/generation dependencies,
checkpoint/retirement extensions and unsupported versions rather than guessing a closure.
Private staging is ignored only as the existing runtime contract permits; linked ancestors
or entries are rejected. Never copy a source link or reuse a source inode as a destination file.

Entries use ordinal-sorted portable relative paths and are unique also ignoring case.
Reject extra/case-substituted files and unrelated empty directories in the artifact. Every
artifact data directory must be an ancestor of a declared file. Limits are 100,000 files,
64 MiB per complete file/inventory, 1 MiB scalar strings and 10,000 retained commits. Reject
excess history; do not silently omit generations to meet limits. Current cooperative/no
external-mutation assumptions remain; hashes are integrity checks, not authentication.

## 5. Independent verification

Verify completion/inventory binding, bounded parsing, strict source profile, exact schema
closure and all file lengths/digests before creating a verification clone or restore workspace.
Do not let a successful redo make an incomplete sealed artifact acceptable.

Use separate private clones made from verified bytes; their admission files and OS handles
are newly created at their own paths. A source-identity clone is nonroutable verification
infrastructure, not copied source ownership. Do not adopt the sealed data/ directory.

- Complete clone: create required runtime directories/fresh admission, validate complete
  history before Open, require exact H/head and no redo/tail deletion/CURRENT repair. New
  private writer/reader files are permitted; sealed files must remain identical.
- Redo clone: construct from the verified base, FORMAT/EPOCH/BASE/CONTROL, full WAL and
  CURRENT, omitting materializations only in this owned clone. Redo every generation and
  require exact manifest and data bytes for every sequence against the sealed artifact.
  This independently exercises logical history rather than trusting copied generations.

Force all lazy payload reads. Compare node metadata/order/URI/values and each WAL operation,
sequence and transaction ID. Generation FORMAT/witness bytes must match their expected source
binding/digest. No lower or later head, changed IDs, repaired sealed data or changed logical
operation is acceptable. Close all handles before cleaning only operation-owned clone paths.
Never scan or clean unrelated workspaces or store history.

## 6. Restore transformation

After read-only artifact verification, reserve fresh IDs once for the attempt and create
an unpublished sibling workspace containing a bundle/store root. Recheck copied source
bytes against inventory before transforming them. Keep the backup immutable throughout.

| Destination content | Required transformation |
|---------------------|-------------------------|
| Root FORMAT | Encode exact ScalarWal 2.1 with fresh StoreId/EpochId and preserved DocumentId |
| EPOCH and admission identity | Encode destination FORMAT/identity binding; create a fresh file/OS namespace |
| Base manifest/directory/fragments | Byte-identical source data |
| BASE | Re-encode destination binding with the unchanged base manifest digest |
| CONTROL | Re-encode destination binding and digest of canonical destination BASE |
| WAL N | Preserve N/TransactionId/NodeId/value/predecessor/result manifest digests; change common binding and preceding complete WAL digest |
| Generation N | Copy all document/fragment bytes; write destination FORMAT and a witness referencing destination WAL N |
| CURRENT | Bind H/head manifest to destination WAL H digest, or zero at H=0 |
| Readers/runtime directories | Create fresh stable identities for 0..H and required runtime directories; no source handles/inodes |
| origin.bin outside store | Bind source inventory/identity and destination initial identity/head; never select recovery from it |

Compute the destination chain in ascending order: previousWalHash is zero for N=1, then
SHA256 of the complete rebound record N-1. Re-encode each generation witness only after
its destination WAL digest is known. Base and all result-manifest digests remain unchanged
because manifest/directory/fragment bytes are copied verbatim. H and transaction IDs are
never renumbered or regenerated. Destination FORMAT changes no profile features.

Verify both source-identity artifact and transformed destination using the two oracles.
Check exact source/destination logical-history parity and deterministic transformed bytes;
source WAL digests and destination WAL digests intentionally differ. An old source token
must not admit the destination. Repeat restores use different fresh identities. A write
to either branch must not affect the other or the immutable artifact.

Write/flush origin, verify the complete bundle and all initial commitments, close every
private admission/writer/snapshot handle, then atomically rename the bundle to the absent
destination and synchronize parents. No root is returned before completion. Future Open
reacquires admission using the published store path; never retain a staging-path token.

## 7. Failure, retries and limits

All persistent writes, flushes, moves, directory barriers and owned cleanup use the storage
seam. Stage on the destination filesystem; no cross-volume atomic rename is assumed.
Only recognized operation-owned unpublished workspaces/clones may be cleaned after exact
path containment checks. Never remove a published destination, original store, sealed
backup or stable identity. Existence/overlap/alias/link checks reject before output creation.
The same portable case-insensitive overlap/device-name guards as format-1 apply.

Kill or I/O failure can leave a private workspace or a fully published unacknowledged
artifact/bundle. Neither exception nor acknowledgment loss implies rollback. Existing
destinations are always refused; retry into a fresh path. Read-only inspection may verify
a previously published BackupId/RestoreId, but must not merge, overwrite or adopt a guessed
workspace. No automatic routing, cutover, cleanup scans or idempotency service is added.

ProcessCrash remains default; FileAndDirectoryFlush is explicit Linux-only with no fallback.
Local NTFS/overlayfs evidence is not power-loss, real ENOSPC or controller certification.
No online/incremental backup, encryption/authenticity, remote object storage, reduced-history
restore, history migration/cutover, public mutable API or reclamation is part of this slice.

## 8. Implementable gates

| Gate | Concrete work and evidence |
|------|----------------------------|
| ET9-A | Internal inventory/completion/origin codecs; freeze candidate bytes only with independently authored fixtures, every truncation, rechecksummed unsupported/role/binding/limit/path rejection; no persistence/public API |
| ET9-B | Internal capture at H=0/1/multiple commits, exact closure, both private verification oracles, old-reader lifetime and commit exclusion, byte-identical source/artifact preservation |
| ET9-C | Internal independent restore/rebinding/bundle publication, exact per-sequence history parity, fresh identities/handles, repeat restores and independent branch writes |
| ET9-D | Every observed capture/restore write/flush/close/rename/barrier fault before/after, real partial writes, kills/lost acknowledgment and repeated verification; native Linux and Windows supported-policy proof |
| Later migration | Separate ADR and original-history/cutover/rollback C1-C3 evidence; keep source roots and all history; no retirement implied |

ET9-A codecs/fixtures, ET9-B capture, ET9-C independent restore and ET9-D observed persistence
fault qualification are implemented. See [fault evidence](M2_EPOCH_BACKUP_FAULT_VALIDATION.md)
for the exact fixture, fault and platform scope. Public entry points remain disabled.
Next: full-history migration/cutover acceptance design under ADR-008; no source replacement,
history reduction or reclamation is authorized. Existing formats and fixtures stay fixed.


Migration design update (2026-10-27): [ADR-018](../ADR-018-full-history-legacy-migration-and-cutover.md) and
[MG1-MG5 acceptance criteria](M2_EPOCH_MIGRATION_DESIGN.md) now specify sealed
legacy-backup conversion, four verification oracles, fresh epoch authority and separate
migration provenance. Cutover requires an operator-held write freeze, exact source and
candidate freshness checks and explicit routing; original roots/history stay intact.
ET9-D backup/restore qualification is complete for its recorded scope. No migration codec,
runtime converter, route switch or retirement is implemented. Next: MG1 codecs/fixtures.
