# SR1/SR2 Stopped Restart Readiness Review

Date: 2026-10-30. Checkpoint 7da1b17 is committed/pushed. This is a documentation/evidence
review only. Product/build/test source is unchanged; no new execution or handoff permission.
[Machine evidence](m2-stopped-restart-readiness-review-results.json) verifies 64 unique retained
artifacts and 15 historical source inputs. [ADR-034](../ADR-034-stopped-enrollment-restart-and-owner-handoff.md)
and [ADR-035](../ADR-035-owned-stopped-restart-observation.md) remain controlling.

## 1. Conclusion and Findings

SR1/SR2 implement a bounded internal stopped-observation prototype with meaningful local source,
paired ownership, native identity and process evidence. They do not implement SR3 plan ownership,
atomic claim or SR4 output. Proceed with an SR3-A preparation/lifecycle design before code;
this review does not authorize a writer, host cutover, release or retirement.

| ID | Finding | Disposition |
|---|---|---|
| RR-001 | ADR-034 current status still says SR2 unimplemented | Correct its status in this review; preserve dated original design evidence |
| RR-002 | Observe is single-attempt and returns an inert description; its retained _attempted flag does not distinguish success from refusal/failure | Before SR3, define an owner-private successful-proof state and fresh revalidation; never promote a descriptor or _attempted=true to authority |
| RR-003 | StoppedRestartObservation.Dispose immediately drains source and the paired operation; there is no plan/executor child retention | Before SR3, design actual child drain or explicit ownership transfer across claim; borrowing a scope/stream reference is insufficient |
| RR-004 | First Enroll uses the actual parent Context.SessionId, while SR1's optional successor is only a supplied GUID description | Decide live successor/session binding and checked generation rules explicitly before preparation; codec validity alone grants no owner identity |
| RR-005 | Exact local handles/bytes are verified, but global freshness/work/executor/publisher/release facts remain supplied assumptions | Actual host authority/reconciliation gate remains open; do not turn a Confirmed flag into independent proof |
| RR-006 | Initial unfiltered Windows commands retain recurring restore timeouts; complete project reruns pass | Preserve failed artifacts and passing rechecks; CI repeatability/root-cause work remains open; no clean initial-command claim |

RR-002/003 are future integration gaps, not newly failing current APIs: the current observer
intentionally grants no executable authority. No runtime fix or contract relaxation is made here.

## 2. Catalog and Raw Evidence

| Stage | Passing Windows catalog | Added IDs | Focused Linux |
|---|---:|---:|---:|
| Pre-SR1 role-release baseline | 2,529 | Baseline | Separate prior evidence |
| SR1 pure assessment | 2,618 | 89 | 451 |
| SR2-A source retention | 2,656 | 38 | 268 |
| SR2-B paired observation | 2,714 | 58 | 356 |
| SR2-C qualification | 2,752 | 38 | 394 |

Each complete Windows catalog retains every prior UnitTestResult.testId, adding exactly the
stated delta; together SR1/SR2 add 223 IDs. Use IDs, not truncated display names. Latest Linux
394 IDs are a subset of Windows 2,752 and include all 223 additions. Linux filters differ
between stages, so their totals are not cumulative growth or full Linux regression claims.
Matching IDs do not equate executed platform branches.

Every stage's selected complete project runs pass without skipped rows. Each initial full
Windows command in this series has one or two existing restore-process timeout failures;
none is relabeled green. Selected counts use passing complete Storage/Xdm runs and complete
Integration reruns, with six-case restore rechecks retained at unchanged 50-second limits.
Latest SR2-C selection is 2,059 Storage + 666 Integration + 27 Xdm. Its Published/normal failures
remain in the original full-command artifacts. No cause is inferred by hash verification.

The 64 unique retained artifacts include development, failed and selected execution reports
and local metadata records. Verification checks their exact SHA-256 values; it does not turn
an earlier input or failure into current qualification. Fifteen qualified source fingerprints
match their recorded committed stage trees exactly or through explicit Git LF-to-working-CRLF
checkout conversion under text=auto. No comments/code normalization or source rebuilding is
used to explain differences. Current test/worker hashes and four current production hashes
match the latest qualification. This review changes none of those inputs.

## 3. What the Runtime Evidence Establishes

| Boundary | Available evidence and limit |
|---|---|
| Pure assessment | Deterministic missing/contradictory/unsupported handling; every result stopped. Inputs alone remain assumptions |
| Source registration | Exact actual owner, permanent stop and original usable writer retained; no capture reconstruction or old latch clear |
| Cooperating exclusion | BeginWrite, pending Commit, checkpoint, recovery anchor, backup and new freeze/restart admission blocked after retention and drain |
| Pairing | Real parent/authority reads precede source inspection; exact scope reference/readiness rejects forgery and acquisition reentry |
| Source/capture proof | Complete bounded artifact/source checks and inventory commitment, no live open/recovery or clone publication during observation |
| Serializer boundary | Placement/source/capture callbacks and reads outside gates; final placement before complete second proof, then exact journals and nonblocking ownership validation |
| Parent/authority identity | Actual original handle/path pins and complete exact acquired journals; no head adoption or prefix repair |
| Administrative obligations | Latest nonterminal attempt stages force reconciliation even with caller Confirmed prior-work assertions |
| Missing/mismatched input | Missing whole capture/source stays missing; valid newer/different baseline reconciles; corruption/changed identity fails without repair |
| Required cleanup | Source/authority/parent before/after/no-op errors remain logically unknown without close retry; physical availability is a separate fact |
| Process death/delivery loss | Old scope disappears; explicit fresh opens yield only new stopped evidence, not old receipt, initializer, scope replay or write resume |
| Readers | Independent snapshots survive owner release; this is positive lifetime evidence, never reader-absence authority |

SR2-C includes eleven same-byte roles/roots at two unlocked phases: 22 actual Linux substitutions
and 22 explicit Windows guards. Windows has 16 other new executed bodies; Linux executes all
38 new bodies. Older guards retain their previous scopes. Five ordered cross-thread closures
and twelve simultaneous attempts provide bounded schedules, not every interleaving. Ten process
cases launch 38 workers per qualified run: six in holders, 28 in kill/fresh pairs (14 killed,
14 fresh), and four in two repeated owner races. Source open/recovery occurs explicitly before
OPENED; byte-identical CURRENT republication is not absence of I/O. Fresh verification while
a still-live original process retains its old snapshot explicitly prevents reader-absence inference.

Native execution is local x64 overlayfs/isolated Linux with pinned SDK/cache/source and no
network. Windows sharing guards are distinct. No fresh complete Linux, ARM64, other filesystem,
real ENOSPC, kernel-close error or physical power-loss certification follows. Managed close
qualification and old native strong-policy runs retain their dated limits.

## 4. Gate Before SR3 Preparation

Current Observe sets _attempted before verification and cannot run again. It does not retain a
private successful-proof receipt for later consumption. A classifier Refused/ReconciliationRequired
result may leave the scope alive; a successful description is externally constructible and inert.
Consequently, neither existence of the scope nor _attempted=true nor matching description fields
can establish that a future preparation is admissible.

SR3-A must define the success-only private state and exact immutable pins, plus fresh source/
capture/admin/authority proof and newly scoped host facts at preparation/consumption time.
A prior _evidence record or RequireCurrent memory check alone cannot replace complete freshness.
An externally supplied description/ObservationId must never recreate a guard or executable plan.

It must also define plan/claimed-executor retention. The existing caller Dispose drains actual
source/paired operations once; a future plan cannot outlive that disposal by borrowing a reference
or pinning a separately disposed stream. If claim wins, actual children must retain original
usable ownership through their real completion. If closing wins before claim, refuse without
output. Preserve the one actual parent read/operation counts, compatible brief authority ->
parent -> source admission and nonblocking source checks; no I/O or callbacks inside these gates.
Any source retention added for a plan must preserve the existing permanent latch and cannot
reacquire a retainer on the already stopped object or relax enrollment capture association.

The live successor policy is unresolved. First enrollment binds the actual parent session;
SR1's descriptive distinct-GUID check is not a live identity assignment. Define whether and how
the successor binds that actual session, previous tuple and checked generation before code.
Keep exactly one legacy Enroll as the initial supported handoff prefix; empty/later/ScalarWal
source histories remain separate gates. Existing TransferOwner v1 codec/vector evidence does
not qualify preparation, dispatch, source fencing or output.

Preparation must remain no-output. SR4 needs its own conditional append, flush/readback,
possible-publication uncertainty, drain/fault/process qualification and terminal stopped result.
No current receipt, description or successful preparation may enable source writes, selection,
work execution or routing. These requirements need a concrete SR3-A contract and lifetime design;
this review accepts no new live capability or wire extension.

## 5. Release and Operational Limits

Public metadata remains locally equal at 95/95 exported entries with zero additions/removals.
That is signature-level evidence, not full nullability/default/behavior/ABI or public DTO review.
Both frozen reader families and six authority vectors retain ten checked file records. The
reader manifests still lack original archived release/commit provenance; local hashes are not
archived pre-lease reader qualification. This review generates or replaces no fixture.

Actual selected-root routing, durable accepted-work host accounting, globally authenticated
freshness, exclusion of uncooperative/old binaries, persisted source fencing and prior-release
reconciliation across different objects/processes remain host/release gates. Native locks and
hashes do not detect coherent offline rollback or prove zero historical work. Synthetic supplied
facts remain distinct from real host integrations.

All source/candidate/WAL histories remain retained; CanReclaim=false. No source replacement,
rollback after divergence, old-reader absence, prefix trimming, retirement or cleanup capability
is inferred. Packaging remains disabled; no public mutable surface or release is approved.

## 6. Next Bounded Step

Define SR3-A's owner-bound, success-only handoff preparation and child-drain/atomic-claim contract
before implementing it. Resolve RR-002 through RR-004 with explicit state/closing/freshness and
failure acceptance tables. Use an ADR for the cross-cutting lifetime/session decision. Preserve
SR1/SR2 stopped/read-only behavior and frozen v1 formats. No runtime tests are rerun for this
review; strict documentation, actual hidden/link portability, diff hygiene and read-only hash/
catalog verification validate this step. The prior passing runtime evidence remains separate.


SR3-A design follow-up (2026-10-30): [preparation/lifetime contract](M2_STOPPED_HANDOFF_PREPARATION_CONTRACT.md)
resolves RR-002/003/004 at the design level only. Private proof, actual child drain and
paired-parent successor binding are specified, not implemented. Next SR3-B1 adds proof/lifetime
primitives; preparation/claim and SR4 output remain later gates. Original execution evidence
and all host/public/archive/fencing/retirement limitations remain unchanged.
