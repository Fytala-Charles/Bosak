# RC1 Read-Only Attempt Preparation and Single-Dispatch State

Date: 2026-10-28. Implements the internal RC1 slice of
[ADR-020](../ADR-020-planned-administrative-attempt-correlation.md). RC2 pipeline execution
and RC3 publication/restart qualification remain deferred. No public API or wire change.

## 1. Preparation and Immutable Description

ScalarEpochAdministration.PrepareAttempt accepts role, artifact and bundle destination.
It uses the service's explicit durability and private instance token. Existing portable,
unlinked, disjoint path validation requires an absent destination and existing parent.
Bounded legacy/epoch ReadArtifact validates seal, exact closure, file hashes and headers;
original/canonical/final inventory bytes must agree. No complete/full-redo clones or live
coordinator are opened. A well-sealed logically invalid history can prepare and still
fail full verification; preparation never grants publication/readiness authority.

The opaque sealed plan has a private constructor. Its library-created nonempty GUID and
immutable descriptor are available before claim. Descriptor fields bind role, canonical
absolute roots, raw inventory SHA-256, BackupId/document/H/optional actual source epoch,
ScalarWal target profile and requested durability. Legacy has no invented source epoch.
Describe returns a detached record; changing it with a record copy cannot alter the plan.
ToInspectionRequest supplies the known attempt ID and pinned input/destination without
inventing a future destination epoch. The descriptor has no executable restoration API.

Plans retain no file handle or lease and need no resource disposal. They are neither a
destination reservation, full proof, freshness capability, host fence nor global attempt
registry. Multiple plans for the same destination can prepare with distinct generated IDs.
Random GUID generation is not authentication or a global uniqueness/idempotency guarantee.

## 2. Local Claim Primitive

ClaimAttempt is an internal primitive for RC1 tests and future RC2 integration, not an
Execute or publish API. It verifies the creating administration token and unchanged policy
before Interlocked.CompareExchange changes Prepared to Dispatched. State reads use Volatile.
Exactly one claim can succeed for the same object; subsequent/concurrent claims throw.
There is no reset, clone, rearm or descriptor replay. A foreign administration, even with
equal options, cannot consume the real owner's plan. Invalid preclaim input preserves state.

Claim performs no filesystem access and returns a detached descriptor only. It can therefore
succeed even if inputs disappeared or a target appeared after preparation. This deliberately
requires RC2 to revalidate all mutable context after claim and before output writes. RC1
cannot acknowledge or mark uncertain a pipeline it never executes; Dispatched is consumed
local state. Real post-claim execution-failure/outcome tests belong to RC2/RC3.

Existing unplanned publication entry points still allocate their own operation IDs. Preparing
a plan neither reserves its target nor injects the plan's ID into those old methods. An
unplanned publication can win that target while the plan stays Prepared. That plan's known-ID
inspection then reconciles rather than retroactively attributing the old publication to it.

## 3. Validation

28 new friend-consumer cases cover both profiles at H0/H3; exact descriptor/hash/path/policy
binding; defensive copies and private construction; null/foreign/policy rejection without
consumption; eight synchronized claim workers per profile (one winner/seven rejections);
filesystem-independent claim and replay refusal; independent plans/unplanned publication;
invalid roles/arguments/seals/placement; actual Linux linked input; and logically inconsistent
but resealed epoch input that prepares then fails full verification.

Throwing storage observes zero mutation/barrier calls during prepare/claim. Byte/file/directory
snapshots remain unchanged, output remains absent, and exclusive opens after preparation
verify no retained file handles. The Linux link case is not executed by the Windows guard.
The policy-mismatch test uses injected storage; it does not claim native durability execution.

[Results](m2-administrative-attempt-plan-results.json) record focused Windows/isolated Linux
RC1 plus scalar/facade/administration/inspection/restart/cutover/compatibility regressions.
Catalog 1,079 adds 28 to the prior 1,051. This is not a new full run; retain the
[consolidated baseline and hardening evidence](m2-consolidated-api-readiness-results.json)
at their exact scope, including its fresh fault matrices. Formatting, strict documentation,
portable hidden/link checks and frozen DLL/metadata fixture hashes are checked before handover.

## 4. Next Gate and Limits

Next RC2: an explicit planned execution path must claim once, bind/recheck original inventory,
role/paths/policy before output, run existing complete/full-redo proofs and publish with the
preknown attempt ID in the unchanged MigrationId/RestoreId field. Keep unplanned behavior
unchanged. Test failures before/after namespace publication, consumed state, original inputs
and known-ID inspection. RC1 alone cannot execute a plan or qualify those behaviors.

RC3 real process/restart/retry qualification, public surface/diagnostic review, actual host
ledger/exclusion/work accounting/routing, archived releases and physical/release approval
remain open. No durable descriptor codec, arbitrary caller IDs, implicit retry, routing,
source replacement or reclamation is introduced. CanReclaim=false; retain every history.
