# M2 Read-Only Epoch Snapshot Validation

Date: 2026-10-27. Scope: [ADR-011](../ADR-011-admission-owned-read-only-epoch-snapshots.md).
**250 tests pass on Windows and 250 on Linux**, zero failures/skips in either full run:
153 Storage, 27 Xdm, 70 Integration. Both Release builds use SDK 10.0.301; Windows runtime
10.0.11 and Ubuntu 24.04 runtime 10.0.9 / Docker overlayfs. Seven existing MINVER1001
warnings per build remain. No warnings were suppressed or release tag created.

Thirty-six fault sweep cases validate **1,228 Windows / 1,188 Linux positions**;
new read-only epoch publication accounts for **128 / 120**. Actual scenario counts and
platform provenance are in [structured evidence](m2-readonly-epoch-results.json).
Current TRX: .tools/epoch-readonly-windows-results and .tools/epoch-readonly-linux-results.
Native Linux barriers pass. Formatting and strict FYTALA documentation checks pass.

Public sample read-epoch smoke on an internally prepared root returns SO-1, 20 lines,
sequence zero, one header payload read and zero line payload reads. Ignored
.tools/epoch-readonly-example.json records its identity and metrics. The internal probe
prepared the root; this is not a public creation/migration workflow.

## New Coverage

- Seventeen Storage cases cover full metadata/node/value parity, source/root byte
  preservation, actual independent snapshot admission after owner disposal, multiple
  holders, malformed metadata/descriptor cleanup, lazy payload corruption, descriptor
  fixtures/truncation/nonzero sequence, wrong-root token use, legacy/incomplete roots,
  transactional source refusal, unsupported transaction markers, native Linux barriers
  and before/after/partial-write publication sweeps.
- Fifteen Integration cases cover XPath axes/namespace/value parity, zero line payload
  reads for header/count, disposal enforcement, four frozen-reader Open overloads on
  populated roots, eight publication kill/ack cases and two actual uncached snapshot
  close/kill lifetime cases after session disposal.

The frozen managed format-1 reader fixtures are unchanged. Broader archived pre-lease
compatibility remains unproven. Actual epoch snapshot lifetime is now integrated; epoch
transactions/backups/coordinator and data-history migration are not. C1-C3 and retirement
R1-R3 are not declared complete. Source retention and CanReclaim=false remain unchanged.

## Reproduction

```powershell
dotnet build Bosak.XmlDb.slnx -c Release --no-restore
dotnet test Bosak.XmlDb.slnx -c Release --no-build --logger 'trx;LogFilePrefix=epoch-readonly' --results-directory .tools/epoch-readonly-windows-results
pwsh tools/test-linux.ps1 -ResultsDirectory .tools/epoch-readonly-linux-results
```

The isolated Linux helper uses SDK 10.0.301, read-only source/package mounts, no network
and overlayfs. Windows stronger-mode tests are modeled; Linux directory fsync is native.
There is no physical power-loss/actual ENOSPC, production filesystem/controller or
remote CI certification. No user store migration, release or history deletion occurs.

*Last updated: 2026-10-27*
