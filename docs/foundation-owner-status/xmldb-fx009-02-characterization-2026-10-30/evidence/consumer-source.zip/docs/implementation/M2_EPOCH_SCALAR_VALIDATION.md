# M2 Internal ET5 Scalar Epoch Validation

Date: 2026-10-27. Scope: [ADR-015](../ADR-015-internal-scalar-epoch-commit.md) and
[scalar runtime contract](M2_EPOCH_SCALAR_COMMIT.md). This is internal implementation
validation, not a public mutable release or a complete recovery certification.

## Final evidence

| Platform | Storage | Xdm | Integration | Total | Failed / skipped |
|----------|---------|-----|-------------|-------|------------------|
| Windows ProcessCrash | 214 | 27 | 100 | 341 | 0 / 0 |
| Ubuntu 24.04 / Docker overlayfs | 214 | 27 | 100 | 341 | 0 / 0 |

SDK10.0.301; Windows runtime10.0.11; Linux runtime10.0.9. Linux runs use the existing pinned
mcr.microsoft.com/dotnet/sdk:10.0.301 image with source/cache mounted read-only and network
disabled. Native FileAndDirectoryFlush commit/reopen executes on Linux; the Windows-native
branch returns without invoking unsupported directory barriers. Existing Windows stronger
policy sweeps remain modeled. Seven known MINVER1001 warnings persist because the checkout
has no commit. No fixture binaries, wire contracts, license or package pins were changed.

Final artifacts: .tools/et5-windows-final and .tools/et5-linux-final. Earlier exploratory
runs are not the final evidence: one initial XPath parity assertion requested StringValue
on an integer result; the query now explicitly converts count to string. The final runs
include all eighteen new cases. [Structured evidence](m2-epoch-scalar-results.json).

## New checks

- Repeated scalar commits/reopen, transaction ID/epoch/sequence/selected manifest capture,
  stale conflict without new WAL, old snapshots after disposal and independent maintenance protection.
- No-op/empty text/multiple-target refusal, rollback, empty ordinary attributes and disposed-owner commits.
- Exact node IDs, topology/order, URI, namespaces and unchanged scalar values; old uncached
  XPath/header/line reads and updates to a non-header fragment.
- Exceptions before WAL, after WAL flush, after generation publication and around CURRENT
  publication. Owners fault; reopen selects old or complete new materialization, or
  refuses missing-generation redo. Required WAL/CURRENT/GENERATION corruption is retained/refused.
- Fresh-process normal commits, kills after generation/before CURRENT, lost acknowledgment,
  repeated independent reopen and source-byte preservation.
- Native Linux stronger-policy commit/reopen and the complete existing compatibility,
  corruption, transaction, checkpoint, backup, ownership and process suites.

The 42 existing sweep cases still cover 1,310 Windows / 1,262 Linux injected positions,
including ET4's 82 / 74 initialization positions. New ET5 boundary tests are not an exhaustive
storage-call sweep. Frozen format-1 and immutable epoch reader binaries remain untouched;
complete archived-release C1-C3 compatibility remains pending.

## Reproduce

```powershell
dotnet test Bosak.XmlDb.slnx -c Release --no-restore --logger 'trx;LogFilePrefix=windows' --results-directory .tools/et5-windows-final
$env:DOTNET_ROLL_FORWARD = 'Major'
& ./.tools/pwsh.exe -NoProfile -File tools/test-linux.ps1 -ResultsDirectory .tools/et5-linux-final
dotnet format Bosak.XmlDb.slnx --no-restore --verify-no-changes
& ./.tools/pwsh.exe -NoProfile -File tools/check-docs.ps1 -ProjectPath . -Strict
```

## Limits and next work

No redo, incomplete-tail classification/deletion, public mutable creation/open/commit API,
epoch backup/migration, reclamation or WAL truncation is implemented. Required incomplete
histories fail closed. A thrown commit can have published a complete new head. Full-history
validation has no performance promise. ET6 must exhaustively cover storage-call faults,
partial WAL writes, redo and repeated interrupted recovery. ET7-ET9 and retirement remain
separate. These local runs do not establish physical power-loss, real ENOSPC, production
filesystem/controller behavior or remote CI certification.
