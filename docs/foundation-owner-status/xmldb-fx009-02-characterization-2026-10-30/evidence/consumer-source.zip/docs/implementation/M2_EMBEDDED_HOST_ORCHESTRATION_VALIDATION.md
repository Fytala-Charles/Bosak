# EP5 Live Plan-Bound Orchestration Validation

Date: 2026-10-28. Internal synchronous pilot under
[ADR-026](../ADR-026-live-plan-bound-embedded-orchestration.md), following
[EP4 owned append](M2_EMBEDDED_HOST_APPEND_VALIDATION.md).

## 1. Ticket, Journal and Executor Binding

EmbeddedHostOrchestrator owns its administration instance and an unexposed ticket-owner token.
Prepare returns a sealed private-constructor ticket containing the real library plan, immutable
preknown descriptor and current host/request context. Describe returns data only; no ticket or
plan is loaded from a journal or reconstructed from a descriptor. Read-only preparation holds
a registered host operation; it creates no destination or host journal record.

Record atomically claims a Prepared ticket, saves exact intent once and publishes Recorded
state only after an acknowledged host save. Execute atomically claims Recorded once, verifies
its exact latest persisted snapshot, saves authorization with actual acknowledgment, and checks
that authorization again before actual executor admission. Null/foreign/repeated tickets reject
without consuming valid foreign plans. Failed claimed tickets never return to Prepared/Recorded.

One host-wide executor registration covers the workflow across multiple orchestrator instances.
It also reserves that attempt's journal mutations: only its opaque registration can append to
the active attempt. Public-to-the-internal-layer low-level appends cannot supersede its state
between authorization and invocation. Other attempts' records remain separate; direct raw file
writes/arbitrary library callers are outside this controlled API boundary and are not fenced.

Actual execution happens outside journal/lifetime/flow locks, with a separately admitted token.
Fault or shutdown before executor admission prevents invocation; after admission, tokens retain
host ownership through actual completion. The outer reservation remains until metadata/error
handling finishes. No caller timeout, repeated request, saved enum or observed frame can finish
an operation or grant another dispatch. MG5 thread confinement remains unchanged.

## 2. Separate Outcomes and Stopped Inspection

Execution results retain actual pipeline receipt, positive authorization acknowledgment,
positive receipt-save acknowledgment, original error and secondary ledger error separately.
Succeeded requires normal workflow completion and both component acknowledgments. An exception
at a later control/return boundary can yield ReconciliationRequired while preserving already
known component successes. NotInvoked retains a still-prepared library plan diagnostically but
the consumed orchestration ticket cannot replay it. No result resumes database writers.

Library failures return PipelineFailed with the original exception object and no fabricated
receipt. An Uncertain transition is attempted while possible; any failure to save it is retained
as a separate ledger error. Published-before-error candidates remain inspectable, not negative
publication receipts. If execution returns normally but host saving/shutdown fails, the actual
pipeline receipt remains in the result; no second library call is made.

Post-claim failure closes admissions and irreversibly stops that orchestrator. Journal I/O
uncertainty also retains EP4's permanent lifetime fault. Inspect is read-only, requires exact
persisted descriptor binding and separate fresh supplied current-owner/excluded-publisher facts,
and registers a read operation through the actual publication inspector. Matches do not clear
faults, consume saved plans, persist new decisions, select routes or enable writers. Publication may still be unresolved: inspection evidence deliberately has no write-readiness
or already-reconciled-outcome flag. Facts remain trusted host assertions, not authenticated/external evidence.

## 3. Executed Evidence

56 new Integration cases: four H0/H3 role successes, four invalid ticket uses, six lost host saves,
four pipeline errors, six control-boundary failures, two concurrent ticket executions, two
shutdown-during-publisher cases, one cross-instance executor reservation, one changed persisted
attempt, five invalid inspection contexts, one private/sealed ticket check, two concurrent
intent saves, one pipeline-plus-ledger error, one shutdown-before-invocation, one changed sealed
artifact, one active-attempt mutation guard and 14 actual process interruption rows.

The process rows cover both roles at intent acknowledgment, authorization acknowledgment,
before invocation, actual pipeline return, before receipt save, before workflow return and
caller-return loss. The parent retains the preannounced ID before dispatch, awaits actual exit,
reopens stopped and inspects without modifying source/artifact/candidate/host bytes or creating
a ticket. Known publication and receipt-present host history remain distinct from a new return.
Concurrency tests produce one intent/one execution for a shared ticket; another orchestrator
cannot reserve a publisher on the same host. A direct active-attempt mutation is refused without
poisoning the valid caller's execution. Shutdown can leave acknowledged authorization and no
invocation, or a completed actual publisher with no later receipt-save acknowledgment.

Final focused Windows Debug and isolated Linux Release runs pass 910 cases/platform:
707 Storage (unchanged focused set) and 203 Integration (56 new + 147 prior). SDK remains
10.0.301. All 56 new bodies execute on both hosts. The prior three FIFO rows are actual Linux
tests and guarded returns on Windows; prior native-policy branches keep their original scope.
This is not an unfiltered full-suite, physical-loss, real ENOSPC, hostile-process or release run.

Public Storage metadata remains 95 signatures with no additions/removals. Journal/store wire
bytes, independent fixtures, frozen reader binaries and dependency pins are unchanged. Shared
lifetime registration now enforces irreversible fault/closing admission and exclusive executor
ownership; append checks active-attempt registration. CrashProbe adds a test command/header.
Formatting, strict docs and actual hidden/link portability checks pass on Windows and Linux.

## 4. Remaining Work and Delivery

This is an internal controlled orchestration prototype, not a shipped consuming application,
production route/work authority, authentication system or global exactly-once service. Low-level
bypass, hostile namespace replacement and malicious workers remain outside the proved scope.
CanReclaim=false; public/archived-reader/release and physical-durability gates remain open.

Next implement stopped restart reconciliation that persists a fresh owner transfer and exact
known-operation observation or reconciled absence under fresh exclusion, without recreating
old tickets. Only after qualified absence may a new live plan with a fresh attempt ID be
recorded; existing candidates remain retained. Current Inspect supplies read-only correlation
only and does not yet persist that workflow or enable fresh retries automatically.

Pushed baseline is 4642b09 (EP2/EP3); EP4/EP5 remain local/uncommitted. Hosted baseline run
40771851255 was blocked before runner steps by GitHub account payment/spending limits; local
results above are independent. No account settings or billing changes are performed.
Proprietary licensing and disabled packaging remain fixed.

[Machine evidence](m2-embedded-host-orchestration-results.json).
