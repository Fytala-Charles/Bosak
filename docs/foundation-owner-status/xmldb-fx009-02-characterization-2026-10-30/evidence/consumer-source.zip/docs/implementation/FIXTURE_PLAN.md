# M1 Fixture Generator Plan

## Corpus

Generate deterministic SalesOrders with 0, 1, 10, 500 and 10,000 lines. Use fixed
recorded random seeds and fragment groups of 1, 16 and 128 lines plus randomized
boundaries. Store shared fixtures in tests/TestData and retain provenance/notices
for imported fixtures. Implemented in PersistentQueryTests (seeded corpus/group selection) and the EmbeddedQuickstart sample; golden binary fixtures live in tests/TestData.

## Semantics

Include unnamespaced and namespace-bound XML, inherited namespaces, attributes,
base/document URI, mixed content, whitespace, comments, processing instructions
and optional extensions. Compare actual Bosak in-memory and persistent providers
using identical XPath expressions. Cover identity, document order, parent/ancestor,
reverse and sibling axes, attributes/namespaces, string values and serialization.

## I/O and Lifetime

Assert header-only queries load zero line payloads and tenth-line selection loads
only the needed group. Verify directory-based counts, bounded cache metrics, late
enumeration after disposal, and reopen in a separate process without source XML.

## Format and Failures

Fix byte-level encoding, checksum algorithm, version and compatibility policy before
codec implementation. Add golden binary fixtures and invalid magic/version/length,
checksum, traversal and truncation cases. Rejected allocations must be bounded.

## Measurement

Record cold/warm p50/p95/p99, allocations, directory memory, fragment reads, bytes
and cache hits against in-memory Bosak. Do not claim a performance win without data.

*Last updated: 2026-10-26*
