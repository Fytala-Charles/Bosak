# Embedded Host Journal Format and Commit Contract

Date: 2026-10-28. EP2 internal design under [ADR-023](../ADR-023-bounded-embedded-host-journal-contract.md).
No codec, journal writer, repair mechanism or host is implemented by this document. These are
new host-only bytes, not new store FORMAT/WAL/provenance versions or public APIs.

## 1. Scope, Namespace and Provisioning

The controlled single-process deployment in [EP1](M2_EMBEDDED_HOST_PROFILE.md) is mandatory.
The host root has exactly owner.lock, host.meta and journal.bin; all must be regular unlinked
files in a reviewed disjoint local directory. No root-role enumeration may be unbounded. The
host root is outside every source/artifact/candidate/workspace; path/alias and lifetime ownership
proof belongs to EP3. Reject unknown root roles, links and unsupported storage. The owner file
is stable and must never be deleted/replaced to obtain ownership. An OS handle excludes only
cooperating instances, not arbitrary manual/legacy writers.

Provisioning is explicit under exclusive operator-controlled scope, not implicit Open behavior.
Create each file with no-overwrite semantics; use a fresh nonempty journal GUID, configured
scope commitment and policy. Complete file flushes and policy-required namespace barriers before
acknowledging provisioning. Partial creation is retained and refused on reopen; do not overwrite
or fill missing roles automatically. Concurrent provisioning and root-path replacement must be
qualified by EP3 before any initializer ships. New-directory creation alone is not an exclusive
claim. No unreviewed staging-directory rename/bootstrap algorithm is prescribed here.

A live initializer may append the first intent only after known successful provisioning and
while holding the original lease. Reopen of even a valid empty journal begins stopped and
requires explicit initialization/outcome reconciliation; empty bytes are not proof of newness.

## 2. Metadata and Frame Envelope

All integer fields are unsigned little-endian. GUIDs use 16 RFC 4122/network-order bytes,
independent of default .NET Guid byte ordering. Hashes are 32 raw SHA-256 bytes. No implicit
padding, host-endian fields or unchecked size arithmetic is allowed.

host.meta is exactly 88 bytes: ASCII BXHM0001 (8), journal GUID (16), scope digest (32), then
SHA-256 of the preceding 56 bytes (32). Scope digest is SHA-256 of canonical TLVs with tag 1
for the configured deployment UTF-8 string and tag 2 for the configured resource-scope string.
The reader compares this commitment to trusted configuration, not to values selected from the
file itself. Empty GUIDs, wrong size/magic, checksum or configured scope fail closed.

| Frame offset | Field | Size |
|--------------|-------|------|
| 0 | ASCII BXHJ0001 | 8 |
| 8 | Version, exactly 1 | 2 |
| 10 | Flags, exactly 0 | 2 |
| 12 | Payload byte length N | 4 |
| 16 | Global frame sequence, starts at 1 | 8 |
| 24 | Journal GUID, equal to host.meta | 16 |
| 40 | Previous frame digest; zero for first frame | 32 |
| 72 | Canonical snapshot payload | N |
| 72 + N | SHA-256 of header bytes 0..71 followed by payload | 32 |
| 104 + N | ASCII HJEND001 | 8 |

Total frame length is 112 + N. The next frame's previous digest is the stored/computed digest
of this frame, excluding its digest/seal. Require exact sequence +1, nonempty payload, same
journal ID, matching digest and seal. Decode lengths and remaining bytes before allocations.
Never search ahead for another magic value after invalid data.

Limits for version 1: payload at most 1,048,576 bytes; journal at most 67,108,864 bytes;
at most 65,536 frames, 1,024 attempts and 4,096 UTF-8 bytes per string. Bounds apply cumulatively,
before allocation/enumeration. Sequence/revision/generation overflow rejects append. Historical
source H is capped at 10,000 to match the current internal plan/history bound. Reaching limits
stops append; no automatic rotation, deletion or compaction is defined.

## 3. Canonical Payload Schema

A TLV is UInt16 tag, UInt32 byte length, then exactly that many bytes. Tags are strictly
increasing with no duplicates. Unknown tags, missing required tags, wrong scalar lengths,
trailing bytes or unknown enum values reject the payload. Nested records are exact canonical
TLV sequences, not serializer objects. Strings are strict valid UTF-8, nonempty/non-whitespace,
without BOM or NUL; reject unpaired-surrogate inputs when encoding. Do not Unicode-normalize,
case-fold or resolve host resource keys during decoding. Canonical configured keys and portable
root placement are validated separately. Optional absence is omission, never an empty/null tag.

| Snapshot tag | Meaning / encoding |
|--------------|--------------------|
| 1 | Event kind, 1 byte |
| 2 | Host request GUID, 16 bytes |
| 3 | Deployment string |
| 4 | Resource-scope string |
| 5 | Immutable attempt descriptor, nested TLV |
| 6 | Per-attempt revision, UInt64 |
| 7 | Owner session GUID, 16 bytes |
| 8 | Owner generation, UInt64 |
| 9 | Resulting stage, 1 byte |
| 10 | Actual acknowledged receipt, optional nested TLV |
| 11 | Known-operation observation, optional nested TLV |

Tags 1..9 are required. Descriptor tags: 1 AttemptId GUID, 2 publication kind byte,
3 artifact path string, 4 bundle path string, 5 inventory hash (32 bytes), 6 BackupId GUID,
7 document UInt64, 8 H UInt64, 9 optional source epoch, 10 destination profile byte,
11 durability byte. Epoch records have tags 1 StoreId GUID, 2 EpochId GUID, 3 document UInt64.
All identities are nonempty and document IDs nonzero. Legacy has no source epoch; independent
restore requires its actual source epoch. Destination profile is ScalarWal and initial policy
is ProcessCrash only. Unknown/stronger policy requests reject, never silently downgrade.

Receipt/observation records each have tags 1 publication kind, 2 operation GUID,
3 BackupId GUID, 4 optional source epoch, 5 destination epoch, 6 H UInt64, 7 store path string.
Their encodings are structurally parallel but top-level tags 10 and 11 carry different meanings.
Do not relabel inspection as a receipt. Preserve exact role/ID/backup/source/H/path bindings
and distinct destination store/epoch IDs for restore. Receipts require the actual return value
at the live append boundary; serialization cannot authenticate that claim after the fact.

Wire values are explicit, not C# enum ordinals: publication kind 1 legacy migration,
2 independent epoch restore; profile 1 ScalarWal; durability 1 ProcessCrash.
Event kinds: 1 RecordIntent, 2 AuthorizeDispatch, 3 MarkUncertain, 4 Acknowledge,
5 ObserveKnown, 6 ReconcileAbsent, 7 TransferOwner. Stages: 1 Recorded, 2 DispatchAuthorized,
3 Uncertain, 4 Acknowledged, 5 ObservedKnown, 6 ReconciledAbsent. An implementation must map
these values explicitly and reject every other value, including zero.

## 4. Semantic Replay and Conditional Updates

Validate the complete bounded chain and every transition, not just each snapshot in isolation.
Maintain an attempt map and append-only request-to-attempt relation within the configured
resource scope. RecordIntent introduces a fresh nonempty attempt ID with revision 1, Recorded
stage, no receipt/observation and an immutable descriptor. Reusing any attempt ID rejects,
even for identical bytes. Request IDs may group attempts but cannot change operation role,
source selection or resource intent silently. A destination change requires explicit retained
independent-attempt reasoning; it is not exactly-once business retry. Version 1 has no field
for that reasoning and conservatively rejects same-request retries unless the prior attempt
is ReconciledAbsent and input/destination are identical apart from the fresh attempt ID.

For existing attempts, each event must conditionally match the current exact descriptor,
owner, generation, revision and chain head before append. Increment revision exactly once.
Only TransferOwner changes owner session/generation, using a distinct session and strictly
increasing generation after fresh supplied effective exclusion. Transfer preserves receipt,
observation and terminal stages; Recorded/DispatchAuthorized becomes Uncertain. Persisted
transfer is evidence of the host's decision, not proof that exclusion occurred.

Transitions follow the [harness](M2_HOST_LEDGER_TRANSITION_VALIDATION.md): only Recorded can
AuthorizeDispatch; only DispatchAuthorized can MarkUncertain; Acknowledge accepts actual
matching returns from DispatchAuthorized/Uncertain/ObservedKnown; ObserveKnown accepts actual
bound inspection from DispatchAuthorized/Uncertain; ReconcileAbsent accepts Recorded/
DispatchAuthorized/Uncertain only after exact fresh exclusion/absence and no retained known
publication. Never overwrite a receipt or erase known observation. Acknowledged requires a
receipt; ObservedKnown requires an observation and no receipt. An observation may remain on
Acknowledged after an actual matching return; other stages permit neither. ReconciledAbsent
is not Prepared and cannot authorize again. Every new retry gets a new attempt ID.

The initial provisioning epoch and each new owner session start with admissions closed.
No replayed state produces a dispatch permit, plan object, source freeze or route authority.
Recorded/DispatchAuthorized are historic intent, not proof of invocation/nonpublication.
Saved evidence must retain its provenance/scope outside this minimal snapshot schema before
production audit requirements are claimed; this codec is not a signed host-attestation format.

## 5. Append and Acknowledged Commit

Under the lifetime lease, serialize one append at a time. Validate configured scope, current
complete history, exact expected per-attempt state and chain head. Construct/validate the whole
bounded frame in memory. Check resulting file/frame/attempt limits before opening append.
Write exactly at the known current EOF without overwriting existing bytes; check actual EOF
and file identity again. Complete all frame bytes, then FileStream.Flush(flushToDisk: true).
Only after successful completion may the live backend publish the new confirmed revision and
return acknowledgment. Do not invoke the executor while holding the append lock.

ProcessCrash is the first target policy: file-flush behavior and cooperative process-exit
namespace visibility need actual EP4 tests. It does not prove controller/power-loss behavior.
Namespace provisioning/creation barriers must follow the selected policy explicitly; stronger
file-and-directory guarantees require separate supported implementations and qualification.
No supported durability claim is established by writing this contract.

Any write/flush/return-path exception after append starts faults the live append session. Stop
new mutations/dispatch and retain bytes. A subsequent exact read can show a complete new frame,
old head or damaged tail; none alone proves which flush/acknowledgment occurred. Complete new
frames are retained as observed history during stopped reconciliation. Do not acknowledge the
original call retroactively or automatically execute/retry. Before-append validation rejection
can leave the session usable only if no bytes were attempted and ownership is unchanged.

## 6. Restart, Damage and Rollback

Acquire stable cooperative ownership, keep admissions closed and validate metadata plus the
complete bounded journal. Clean EOF at a frame boundary permits structural replay only, not
execution eligibility. A lost process-local plan is never recreated. An unknown prior executor,
foreign writer, route, accepted work or retained publication contradiction requires reconciliation.

Partial header/payload/hash/seal, wrong digest/sequence/version/flags, malformed TLV, invalid
transition, extra bytes, identity mismatch or exceeded bounds blocks authoritative reopen and
all appends. A diagnostic validated prefix may be reported as partial evidence, never adopted
as current authority. Preserve the whole file and all source/artifact/candidate history; no
automatic truncation, resynchronization, missing-file replacement or root reset is permitted.

Hash chains detect damage to retained frames but cannot detect removal of complete final frames,
replay of an earlier whole journal/metadata pair or hostile recomputation. There is no independent
anti-rollback anchor in this pilot. Offline restore, operator rollback, hostile writers and
uncertain storage persistence are outside the supported automatic workflow. Restart's stopped
state is mandatory even for a valid-looking prefix; external inventory/evidence is needed to
resolve such cases. Never claim a healthy checksum proves freshness, no prior publication or
zero accepted work. Journal absence is not permission to initialize after a prior host existed.

## 7. Implementation and Fault Gates

| Gate | Required proof | Current state |
|------|----------------|---------------|
| EP2 contract | Byte bounds/schema, transition/commit semantics, damage/rollback limits | Defined here |
| EP2 codec | Pure internal canonical encoder/strict decoder plus independently authored vectors; malformed lengths, tags, enums, Unicode, chains and transitions | Internally implemented; see codec validation |
| EP3 ownership | Initial provisioning/root placement, stable OS handle, actual process contention/crash release and admission drain | Open |
| EP4 persistence | Real append/flush fault positions, partial tails, before/after commit kills, unknown acknowledgments and stopped reopen | Open |
| EP5 pilot | Real internal orchestration under proven ownership/persistence; no replay or automatic resume | Open |
| HA2 application | Actual consuming app, external writer exclusion, route/work authorities | Open |

No fixture may be generated solely by the encoder under test: define hand-authored byte/header
vectors and compare exact hashes/layouts independently. Qualify all length prefixes before
allocating, cumulative limits, arbitrary chunking/short reads and no skipped corruption.
Test duplicate attempt IDs, revision/owner races, different request/scope, illegal stage edges,
receipt-vs-observation separation and preserved publication evidence. Codec tests are not durable
file, process-fence or physical-durability tests. Existing frozen store fixtures remain unchanged.

## 8. Delivery and Evidence

The embedded profile is committed/pushed as 2141eac; work through test-only HA1 is in 5d23ba2.
This EP2 contract is a local documentation continuation. Runtime/test/fixture fingerprints are
unchanged and no new runtime tests are run. Prior 448 focused cases/platform retain their original
scope. Strict documentation and hidden/link portability checks validate this step separately.
Proprietary licensing, Bosak pins, public API, disabled packaging and CanReclaim=false are fixed.

[Machine contract](m2-embedded-host-journal-contract.json).


EP2 codec follow-up (2026-10-28): [validation](M2_HOST_JOURNAL_CODEC_VALIDATION.md) now
qualifies internal bytes/history parsing with independent vectors. The design-step no-code
statements above describe their original scope; EP3 ownership and EP4 persistence remain open.


EP3 follow-up (2026-10-28): [existing-root lifetime validation](M2_EMBEDDED_HOST_OWNERSHIP_VALIDATION.md)
qualifies cooperative ownership, closed admissions and token-drained release. Existing root
checks/read handles perform no creation or repair. Next is explicit no-overwrite provisioning;
EP4 journal append and broader namespace/global exclusion qualification remain open.


Provisioning follow-up (2026-10-28): [ADR-024](../ADR-024-explicit-no-overwrite-host-provisioning.md)
and [validation](M2_EMBEDDED_HOST_PROVISIONING_VALIDATION.md) now qualify explicit absent-root
creation within a controlled cooperating scope. Existing opens do not initialize/repair.
Directory creation is not exclusive; CreateNew owner handoff has no unlock gap. Next EP4
implements conditional journal append and faulted sessions, not automatic resume or routing.


EP4 follow-up (2026-10-28): [owned append validation](M2_EMBEDDED_HOST_APPEND_VALIDATION.md)
now qualifies actual conditional file writes/flushes and stopped uncertain sessions under
retained lifetime ownership. Reconciliation is read-only and cannot rearm a faulted session.
Next EP5 binds live plans to acknowledged transitions and registered executors; broader
application/physical durability and release gates stay open. Pushed EP2/EP3 baseline: 4642b09.


EP5 follow-up (2026-10-28): [live plan-bound orchestration](M2_EMBEDDED_HOST_ORCHESTRATION_VALIDATION.md)
now binds exact positive host saves to registered single dispatch with opaque tickets. New owner
restart remains stopped; Inspect never recreates authority. Next persist owner/observation/absence
reconciliation before explicit fresh-ID retries. No production route/work/global fence is added.
