# Retained Source Exclusion and First-Enrollment Design Review

Date: 2026-10-29. Documentation-only continuation of
[ADR-032 preparation](M2_APPLICATION_AUTHORITY_ENROLLMENT_VALIDATION.md), under
[ADR-033](../ADR-033-retained-source-exclusion-and-first-enrollment.md).
The [design contract](M2_APPLICATION_AUTHORITY_ENROLLMENT_APPEND_DESIGN.md) is prospective;
EF1-EF4 runtime work, new APIs and new test execution are not claimed.

## 1. Findings from Current Code

| Current behavior | Consequence addressed by the design |
|---|---|
| MigrationSourceFreeze.Dispose immediately clears the source token | Borrowed preparation cannot retain mutation exclusion across append |
| EmbeddedXmlDatabase.Dispose immediately closes the original writer stream | Keeping only an authority operation does not preserve source ownership |
| Source CreateBackup is allowed under the current migration freeze | New opt-in retention must exclude publishers as well as data commits |
| CheckFirstEnrollment consumes a read-only object and returns a stopped description | Its result cannot be upgraded or executed as an append plan |
| Authority inspection validates an immutable acquired length/digest | First write needs a distinct mode; generic Inspect cannot adopt a new head |
| Parent/authority disposal waits on actual child operations | Retained source lifetime should follow actual execution, not caller timeout |

Decisions: coordinator-owned deferred original-stream close, exact retained source/freeze
registration, one memory-only arm decision, permanent original-owner stop latch after arm,
no source I/O under authority serialization, single existing-v1 Enroll frame and terminal
stopped success/uncertainty. No durable source fence, profile change or cleanup is introduced.

## 2. Reviewed Acceptance Scenarios

These 24 rows are design obligations, not newly passing runtime tests. Ordered schedules
must prove endpoints; stress schedules alone cannot establish every interleaving.

| ID | Schedule/input | Required result |
|---|---|---|
| DR01 | Owner closes before source retention | No new guard or write; do not reopen ownership |
| DR02 | Foreign token/capture, forged guard or wrong thread | Reject without changing another live registration |
| DR03 | Pending guard, then freeze disposal | Mutation token stays effective until the real pending child drains |
| DR04 | Pending guard, then source-owner disposal | Ordinary owner unavailable; original stream held until real child drain |
| DR05 | Source closing races arm | One ordered winner; closing first refuses, arming first retains admitted execution |
| DR06 | Parent/authority closes before arm | No write; pending registrations drain safely |
| DR07 | Arm wins, then parent/authority/source closes | Actual handles retained; private admitted validation can complete without resurrecting public owners |
| DR08 | Pending old transaction/new write/checkpoint/anchor/backup | Block each cooperating mutation/publisher in opt-in mode; no-retainer behavior preserved |
| DR09 | Old or new independent reader | Existing reader rules remain; no reader-absence or reclamation inference |
| DR10 | Borrowed/consumed/disposed/copied preparation | Never executable; exact live retained plan is required |
| DR11 | Generic inspection races retained prepare/write | Reject or drain before arming; never compare a written head with an old empty snapshot |
| DR12 | Capture/WAL/data/staging changes | Strict no-write rejection; no repair, cleanup or new capture |
| DR13 | Stale expected position but otherwise valid log | No-write conflict; no adoption or known-head replacement |
| DR14 | Metadata/role/native identity/link corruption | Preserve bytes/inventory; no source or authority repair |
| DR15 | Zero/partial/full delegated write throws | Possible-output uncertainty and sticky stop; no replay or truncation |
| DR16 | Flush/readback/length/checksum/identity failure | Retain possible publication; no acknowledgment inferred from a complete-looking frame |
| DR17 | Caller timeout/cancellation or failure before observing acknowledgment | Actual execution registration persists; no cancellation-based lease release or receipt synthesis |
| DR18 | Source/app/parent release cannot be confirmed | Report release unknown; no unqualified acknowledgment or physical-ownership assertion |
| DR19 | Qualified one-frame success | Receipt records exact v1 head, source latch remains, application admission stays closed |
| DR20 | Freeze/plan disposed after acknowledged or uncertain execution | Stop latch cannot clear; no automatic original-owner mutation resume |
| DR21 | Process dies before/during/after append | Preserve empty/torn/complete outcomes; restart is read-only/reconciliation, never replay |
| DR22 | Existing MG5/borrowed preparation without new guard | Existing normal closing, source APIs and snapshot-owned readers remain compatible |
| DR23 | Refusal before arm versus after arm | Only unarmed cleanup can honor an earlier explicit freeze-release request; armed latch remains |
| DR24 | Windows/Linux persistence/process qualification | Separate actual native execution, modeled faults, host guards and counts; no power-loss or ENOSPC certification |

## 3. Verification Scope

No C# or build input is changed by this design step. Compare current runtime/build hashes
with the captured start-of-step inventory and the five pinned qualified-source fingerprints.
Verify the prior TRX artifacts/counters against their recorded hashes before reusing them as
a baseline. The existing source baseline is 2,331 passing Windows cases across project runs
and 542 focused Linux cases; the earlier failed Windows kill case remains recorded. These
are retained runtime results, not fresh runs for this documentation-only step.

Run strict documentation, portability and diff-whitespace checks. No new codec/schema/vector
exists, so no golden fixture is generated or replaced. Shared documentation-kit files and
provenance remain unchanged. Static review does not qualify source retention, arming,
publication, fault traces, deadlock freedom or actual host control.

## 4. Delivery and Next Gate

HEAD remains 3f722da (already pushed). Prior read-only preparation and this design remain
local/uncommitted; no commit/push is requested in this turn. No public API, persistence,
actual route, work admission, source replacement or history deletion is enabled.

Next EF1 implements and qualifies only the opt-in source/freeze retainer, deferred exact
original-stream close and owner stop latch. Include pending/armed disposal schedules,
source mutation and backup rejection, no-retainer compatibility, independent reader lifetime
and unconfirmed-release behavior. It must perform no authority append. EF2-EF4 remain later
explicit gates; keep all histories and CanReclaim=false.

## 5. Completed Static Review Evidence

[Machine review record](m2-enrollment-append-design-review-results.json) confirms 156
runtime/build inputs unchanged from the start of this step, all five qualified-source
fingerprints unchanged, and eight retained TRX artifacts matching their recorded SHA-256.
The existing selected runtime baseline remains 2,331 Windows / 542 focused Linux cases;
no runtime test was rerun and no new test count is claimed. Strict documentation,
actual hidden/link portability and diff-whitespace checks pass. The 24 scenarios above
remain future implementation obligations. All EF1-EF4 runtime gates are still open.
