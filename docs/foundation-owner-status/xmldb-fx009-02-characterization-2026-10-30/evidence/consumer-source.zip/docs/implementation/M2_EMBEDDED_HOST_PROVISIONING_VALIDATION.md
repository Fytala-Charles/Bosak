# EP3 Explicit Host Provisioning Validation

Date: 2026-10-28. Internal controlled-scope provisioning under
[ADR-024](../ADR-024-explicit-no-overwrite-host-provisioning.md), following
[existing-root ownership](M2_EMBEDDED_HOST_OWNERSHIP_VALIDATION.md).

## 1. Creation and Ownership Boundary

EmbeddedHostLifetime.Provision requires fresh evidence bound to the canonical root, deployment
and scope, asserting controlled cooperating provisioners and no prior host. Root absence alone
cannot establish those facts. Parent must exist and remain stable/unlinked; target and protected
root placement use the existing bounded checks. Every existing target rejects before storage
mutation, including healthy/partial hosts, empty directories and ordinary files. OpenExisting
still never creates/repairs anything.

Cooperating participants can both pass absent-root preflight before directory creation. Under
that declared scope they race an exclusive CreateNew owner.lock; directory creation/empty-root
observation alone never establishes ownership. A loser leaves all state retained. A foreign
occupied root discovered after preflight rejects. Foreign empty directories, parent deletion,
unlink/replacement and malicious namespace mutations are outside the controlled-scope proof;
this is not an atomic directory-create primitive or a global/adversarial fence.

The winner retains its original owner stream while flushing owner bytes, writing and flushing
88-byte metadata through no-overwrite storage, creating/flushing the empty journal, requesting
policy namespace barriers and validating namespace/readback. Metadata/journal read handles are
opened under that still-held owner. Before return, recheck all roles, exact lengths, metadata
bytes/ID/scope and empty journal. The same owner stream enters the lifetime constructor; no
close/reopen gap is used. File checksums/lengths and stable namespace assumptions are unchanged.

WasProvisionedHere is true only on the returned live initializer object and false on all
reopens. It is an in-memory origin diagnostic, not persisted authority or executable permission.
Its value alone never enables database writes or journal append. All returned lifetimes start
with admissions closed and WritersMustRemainStopped=true.

## 2. Failure and Acknowledgment Rules

Eleven synchronous test checkpoints span preflight, directory/owner creation, owner flush,
metadata creation/write/flush, journal creation/flush, namespace validation and before return.
Any failure retains all created bytes/roles and closes acquired handles. No deletion, truncation,
resume, reset, overwrite or automatic repair occurs. A preflight exception before mutation can
leave the target absent; only an explicit new call under still-valid no-prior-host evidence can
provision it. Existing partial roots reject every later provisioning call.

Once all three roles are structurally valid, an exception/kill may leave a valid empty host
that OpenExisting can read while stopped. That observation never reconstructs a successful
provisioning return, original owner session, plan or first-write authority. Parent/child data
roots and their contents remain unchanged. ProcessCrash requests actual file flushes; directory
barriers follow the selected weak policy and do not establish physical power-loss durability.
Stronger policy requests reject without fallback.

## 3. Executed Tests

60 new cases comprise 46 Storage and 14 Integration. Storage covers successful continuous
handoff (one), all checkpoint exceptions (11), injected create/partial-write/flush/dispose/
directory-barrier failures (13), every pre-existing target shape (five), invalid evidence/
placement/policy before mutation (12), occupied-after-preflight root (one), concurrent threads
(one), corrupt full-length metadata readback (one) and final extra-role recheck (one).

Integration kills actual provisioning processes at all 11 checkpoints and after return before
acknowledgment (12), synchronizes two absent-root preflights in distinct processes to prove one
CreateNew winner (one), and holds a child immediately before/after return to prove continuous
exclusion across handoff (one). Every case verifies retained partial or valid-stopped state,
closed admissions, and rejection of implicit provisioning replay as appropriate. These 60 new
cases execute on both hosts; they do not use host-only early returns.

Final focused Windows Debug and isolated Linux Release runs pass 807 cases/platform:
673 Storage (46 new + 627 prior) and 134 Integration (14 new + 120 prior). SDK remains 10.0.301.
The prior three FIFO rows are actual Linux tests and guarded returns on Windows; prior native
policy/process branches retain their original scope. This is not an unfiltered full-suite,
physical-loss, real ENOSPC, hostile-namespace or archived-reader qualification run.

Public Storage metadata remains 95 signatures with no additions/removals. Journal/store wire
formats, four new host vectors, prior metadata fixtures and frozen reader binaries are unchanged.
Existing lifetime code shares placement validation and adds a local initializer-origin diagnostic;
CrashProbe adds a test command/header. Formatting, strict docs and actual hidden/link portability
checks pass on Windows and Linux. No new dependency or public API is introduced.

## 4. Next Gate

EP3's controlled provisioning/lifetime slice is implemented. Next EP4 implements serialized
bounded journal append, exact expected-head/revision checks, flush acknowledgment and faulted
append-session behavior under the retained owner. Complete or damaged bytes after a failed
write must not become implicit success, repair or dispatch permission. Reopened empty roots
remain stopped and cannot acquire first-write eligibility merely from healthy structure.
EP5 actual owned orchestration, HA2 application route/work, archived compatibility, physical
durability, public/release and all retirement remain open. CanReclaim=false.

The provisioner and prior EP2/EP3 changes remain local/uncommitted; baseline 2141eac is pushed.
Proprietary licensing, package pins and disabled packaging remain unchanged.

[Machine evidence](m2-embedded-host-provisioning-results.json).
