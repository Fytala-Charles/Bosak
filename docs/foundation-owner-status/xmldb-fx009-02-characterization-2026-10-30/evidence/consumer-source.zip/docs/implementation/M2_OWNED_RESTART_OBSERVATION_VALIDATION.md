# SR2-B Actual Paired Stopped Restart Observation

Date: 2026-10-30. Checkpoint a31203b through SR2-A is committed/pushed. This is subsequent
internal implementation under [ADR-035](../ADR-035-owned-stopped-restart-observation.md) and
[design](M2_OWNED_RESTART_OBSERVATION_DESIGN.md). See
[machine evidence](m2-owned-restart-observation-results.json). SR2-C qualification remains open.

## Ownership and Single-Use Scope

BeginRestartObservation requires an unused existing-root ApplicationAuthorityLifetime, actual
paired parent ownership, exact fresh stopped-scope assertions and ProcessCrash policy without
fallback. It rejects provisioned initializer sessions, active reads, enrollment/restart modes,
wrong context/authority/capture mapping and unsafe control assertions. It reserves the actual
parent read and authority operation before source inspection. Source acquisition is outside
all peer gates; it may wait there, never while holding parent/authority lifetime gates.

For a single legacy Enroll with a supplied source, the scope acquires SR2-A's real restart child.
It never reconstructs FrozenMigrationCapture, clears an old latch or opens/recovers live data.
Source binding is installed even if closing wins just after admission, so cleanup still owns
that actual child. A separate owner-held scope reference rejects forged scope objects before
I/O or release. Acquisition readiness prevents reentrant Observe before publication. Scope
and source are caller-thread confined; Observe is one-attempt, including failures. Dispose
is once-only. Generic Inspect and another protocol cannot reuse this terminal owner mode.

The scope retains actual operations until Dispose. Returned ApplicationRestartDescription
contains only an ID, inert facts/assessment and an administrative-reconciliation diagnostic.
It retains no handles and recreates no receipt, initializer, live capability or handoff plan.
WritersMustRemainStopped remains true. Scope retention itself is not write authority.

## Native Pins, Verification and Serializer Boundaries

Capture the parent root plus original owner/metadata/journal identities from the real retained
streams outside lifetime/serializer gates. Require their actual paths to name those handles.
Compare the immutable pin before and after exact complete parent journal reads. Authority-only
verification uses the original held role streams, exact acquired length/full-log hash, metadata,
complete bounded history and EOF. It adopts no later head. Parent and authority serializers
are separate; neither contains source/capture inspection or callbacks.

Protected placement/native ancestor checks run outside all gates while real children remain
held. For exact single legacy Enroll, resolve its source key through trusted mappings and the
capture through an explicit configured key. Validate exact sealed artifact closure, bytes and
every transition using ReadArtifact/ValidateHistory; do not invoke live OpenCore, recovery,
CreateBackup or clone/oracle publishers. The original captured inventory SHA-256 is the Enroll
InitialHistoryDigest, not a manifest hash. Match source document/H/manifest, complete source
closure/history and every retained file against that inventory. Reject staging and temporary
publications without cleaning them. Compare source root/original writer identities and exact
capture directory/inventory bytes before and after proof, and recheck sealed file closure.

Repeat placement before a complete second source/capture proof. Compare both proofs, including
native identities and inventory digest; then re-read parent/authority journals after all unlocked
source work. No placement callback follows the last complete source proof. Final brief admission
checks use authority -> parent -> nonblocking source gates and no I/O/callbacks. Busy/closing/
faulted/changed ownership refuses; admitted actual reads still drain normally. A description is
point-in-time and becomes no future execution authority if closing wins after it returns.

The observer begins after explicit caller source open/recovery and fixed reader initialization.
Legacy open can republish CURRENT; that earlier preparation is not hidden or relabeled read-only.
Observation preservation covers all other data/journal/capture bytes and full inventory, excluding
actively locked runtime owner-file content; native handle/path checks qualify those roles.
No reader-absence, coherent offline rollback detection or physical power-loss proof is implied.

## Deriving Facts Conservatively

Derive parent/authority structural and ownership facts from actual checks. SourceExcluded is
Confirmed only with actual registered source exclusion and fresh native identity evidence;
missing source/capture proof never becomes an exact baseline. Fresh scope, prior work, executor/
publisher drain and release reconciliation remain supplied scoped host assertions. The library
cannot authenticate facts about prior different objects/processes or resolve an external old
release error merely from a new exclusive open. Referenced closing/faulted owners reject.

Replay the complete administrative history only for structural accounting, never dispatch.
Latest per-attempt stages other than Acknowledged/ReconciledAbsent force administrative
reconciliation; Recorded, DispatchAuthorized, Uncertain and ObservedKnown cannot be hidden by
a caller's Confirmed prior-work flag. Preserve contradictory host facts as Refused rather than
masking them with a weaker baseline-mismatch or unsupported-history result. Terminal records
do not manufacture old acknowledgment delivery or independently prove fresh host assertions.

Empty and valid later histories remain stopped reconciliation without source association or
initializer. Missing source/key or unavailable whole capture is missing evidence; create nothing.
Incomplete/corrupt present artifact, invalid role/history or changed head fails without prefix
repair. A coherent newer source or valid different sealed inventory is BaselineMismatch with no
fabricated actual history commitment. Scalar-source single enrollment is outside this legacy
adapter and stays unsupported. No actual-baseline record escapes unless complete proof passes.

## Release and Qualification

Release source before authority/parent operations. Unknown source close retains the actual
pair through the owner-held quarantined scope. Authority close failure retains its parent
registration; parent-only error stays separately visible. Scope ReleaseUnknown reports required
cleanup error without retry; earlier inert descriptions are not rewritten as acknowledgments.
The actual acquired streams use lifetime-bound qualification closers only; defaults stay direct
FileStream.Dispose. Fixture-only raw-handle teardown neither retries production nor changes tasks.

There are 58 new cases with no platform guards. Final focused Windows passes 282 cases. They
cover real reopened H0/H1 Enroll; empty/later history; complete current administrative stages;
missing/unavailable source/capture; unknown/contradictory host facts; coherent baseline mismatch;
corrupt source/capture/journals/metadata/roles/staging with byte/inventory preservation; changes
at last unlocked stage/placement; all five closing boundaries; context/control rejection;
forged/consumed/wrong-thread scopes; acquisition reentry; a busy nonblocking source check; and
nine actual before/after/no-op source/authority/parent close faults. Existing lifetime/source/
classifier cases remain in the focused run. Parent nonterminal fixture histories and later
TransferOwner bytes are pure test construction before open, not real dispatch/handoff proof.

A compile-only fixture overload error was corrected before executable qualification. Earlier
executable development runs pass within their own input scope and remain separately retained.
Review hardening preceded final-source
freeze. Formatting/analyzers pass. Isolated Linux passes 356 focused cases (352 Storage + 4
Integration), including all 58 new bodies with no new host guards. Xdm has no matching rows.
SDK 10.0.301 on x64 overlayfs uses read-only source/cache mounts, no network and private outputs;
seven expected MINVER1001 warnings reflect Git-free copied inputs. All 2,714 Windows cases pass across complete project runs. The initial restore timeout is
retained and passes focused plus complete Integration rechecks. Storage passes 2,031, Integration 656 and Xdm 27.
All 2,656 previous test IDs remain with exactly 58 new Storage IDs.
The initial full command fails its Published-stage restore process timeout. All six restore
cases and the entire 656-case Integration rerun pass with unchanged 50-second limits. Retain
the failed artifact, infer no cause and do not label the initial full command green.

Fresh public metadata remains 95/95 entries with zero additions/removals, not archived release
proof. Ten frozen vector/binary files match read-only hashes. Strict docs, actual hidden/link
portability and diff hygiene pass. Five final C# hashes match qualified inputs. Earlier
development runs have separate input scope; no frozen fixture is generated or replaced.

## Next Gate

Next SR2-C qualifies broader native identity substitutions, ordered/repeated ownership races and
cross-process holders/restart observation, keeping modeled and actual platform bodies separate.
Current boundary/fault rows do not exhaust concurrency or every inode substitution timing.
SR3/SR4 handoff preparation/output, actual host/public/archive release, physical durability and
all retirement/reclamation remain open. Preserve every history and CanReclaim=false.

SR2-C follow-up (2026-10-30): [native/process/disposal qualification](M2_OWNED_RESTART_QUALIFICATION_VALIDATION.md)
adds bounded local identity, actual holder/interruption and closing evidence without product
source changes. Original evidence retains its dated inputs; next SR1/SR2 readiness consolidation.
