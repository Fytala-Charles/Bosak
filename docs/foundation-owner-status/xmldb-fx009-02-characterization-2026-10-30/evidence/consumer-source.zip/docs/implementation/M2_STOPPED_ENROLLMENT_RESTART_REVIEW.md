# ER-004 Stopped Restart and Handoff Design Review

Date: 2026-10-30. ER-003 checkpoint edf0b72 is committed/pushed. This step adds design and
documentation only. [ADR-034](../ADR-034-stopped-enrollment-restart-and-owner-handoff.md) and
[contract](M2_STOPPED_ENROLLMENT_RESTART_CONTRACT.md) address the ER-004 design gate;
SR1-SR4 runtime implementation remains open. See [machine evidence](m2-stopped-enrollment-restart-results.json).

## Contract Review

| Boundary | Design obligation and existing-code comparison |
|---|---|
| Empty restart | OpenExisting does not set the private provisioned flag; no initializer revival is permitted |
| Complete Enroll | History/Inspect validate acquisition state; they do not return an append receipt or confirmed enrollment |
| Changed head | Inspect compares exact acquisition length/digest and faults on change; SR2 must preserve this rule |
| Source fencing | The original retained source stop latch is object-local; no authority event clears it or fences a newly opened source |
| Ownership and closing | Actual parent child and role handles must span inspection; error cases retain the existing drain/release semantics |
| Lock boundary | Source/capture/protected placement inspection remains outside authority serialization; actual registrations span the gap |
| Release uncertainty | ER-003 confirms physical close can occur while logical release faults; exclusive reopen cannot certify the old task |
| History validation | Existing complete-history codec validates TransferOwner shape without providing live handoff permission |
| Owner transfer | Existing v1 previous-owner tuple, distinct successor and checked generation increment are preserved; broader histories remain outside the first slice |
| Work accounting | Recorded zero work does not prove prior executor absence; unsupported later events remain valid-but-unhandled rather than corrupt |
| Failure and ACK loss | Complete persisted bytes remain observations, partial bytes reject without prefix adoption, and no old plan is retried |
| Retirement | No inference about old readers, source replacement or history deletion; CanReclaim=false |

The design deliberately leaves actual host observations supplied until SR2 and consuming-host
qualification. A pure SR1 result can express assumptions and missing facts but cannot validate
files or create retained ownership. An ObservedEnrolledStopped result must therefore remain
inert even if all supplied facts are true. Missing facts and valid unsupported histories are
reconciliation states; independently invalid history must still reject. Handoff proposal checks
are separate from observation of the current owner: a new session is chosen only for an explicit
future proposal, not inferred during restart.

## Evidence and Validation Scope

No src/, tests/, tools/, project or build input changes are part of this step. Five final ER-003
C# source hashes, ten frozen vector/binary file hashes and the retained raw TRX hashes are
checked read-only. The selected prior Windows project runs cover 2,529 passing test IDs;
the broad prior Linux subset passes 740 cases. The initial full Windows command still has its
two separately retained restore process timeouts, followed by passing six-case and complete
656-case Integration rechecks. Hash verification is not a fresh execution or a claim that the
initial command passed. No new runtime cases or platform branches are claimed here.

Strict documentation, actual documentation portability and git diff hygiene are checked for
this documentation step. Frozen fixtures, governed documentation kit, public API metadata and
wire formats remain unchanged. No fixture-generation scripts are executed. A future runtime
step must run its new happy/failure cases and required full regression; these prior results
cannot qualify changed runtime source.

## Next Bounded Work

Implement SR1 only: a pure internal stopped classifier with explicit unknown/invalid/unsupported
observations, deterministic reason precedence and every result stopped. Cover the exact-Enroll
happy path, empty reopen, incomplete/corrupt history, missing or contradictory scope facts,
source/capture mismatch, unsupported later history, ACK loss and separate handoff proposal
identity/overflow checks. Assert absence of receipts, capabilities and execution permissions.
No filesystem adapter, owner-transfer append, retry, work admission or routing belongs in SR1.
SR2-SR4 and actual host/public/archive/physical-durability/retirement gates remain open.

SR1 follow-up (2026-10-30): [pure classifier and qualification](M2_ENROLLMENT_RESTART_CLASSIFIER_VALIDATION.md)
implement supplied-observation classification only. Original design-step evidence remains
historical. No actual owner-bound observation or handoff capability is implemented; next SR2.
