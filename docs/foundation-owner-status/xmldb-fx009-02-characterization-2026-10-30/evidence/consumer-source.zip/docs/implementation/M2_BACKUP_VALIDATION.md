# M2 Full-History Backup and Restore Validation

Date: 2026-10-27. Implemented scope: [ADR-009](../ADR-009-verified-full-history-backup-and-restore.md).
**186 tests pass on each of Windows and Linux**, zero failures/skips in either full run:
117 Storage, 27 Xdm, 42 Integration. Both Release builds and locked Linux restore pass;
SDK 10.0.301, Windows host/runtime 10.0.11, Ubuntu 24.04 runtime 10.0.9 / overlayfs.
Seven existing MINVER1001 warnings remain per build because the checkout is uncommitted
and the isolated Linux source copy intentionally excludes Git. No warning is suppressed.

Thirty storage fault sweep cases validate **1,039 Windows / 1,015 Linux positions**.
Six new capture/restore sweeps account for **456 Windows / 440 Linux positions**.
Before/after counts and per-scenario totals are in
[structured results](m2-backup-results.json); differing path ancestry explains counts.
Twelve new kill/acknowledgment cases include active verification-clone coordinators,
sealing, final publication and acknowledged results. Repeated opens retain exact H.
Native Linux directory fsync and linked-ancestor refusal run successfully. The Unix-only
symlink-creation test returns on Windows; no Windows junction execution is claimed.

Formatting verification and strict FYTALA checks pass, including immutable kit hashes,
branding, provenance, links, dates and section numbering. Public sample capture at H=2,
later source H=3 and restore at H=2 succeeds with matching BackupId, SO-3 and 20 lines.
The source remains SO-4/H=3. Ignored .tools/backup-smoke-result.json records the smoke.

## Acceptance Coverage

| Gate | Implemented evidence | Limits |
|------|----------------------|--------|
| B1 | H=0 and H=2; full reopen, all metadata/value parity, unchanged source bytes, independent restored writes | Bounded experimental single-document format |
| B2 | A capture held at an internal boundary excludes a concurrent later commit; old uncached snapshot reads old value | Cooperative callers; no uncooperative writers |
| B3 | Before/after every observed persistence call and real partial writes for capture and restore; failed owner faults; published results verify | Injected disk-full HRESULT, not a physically full volume |
| B4 | Kills after copy, during clone verification, after verification, seal/publication and acknowledgment; repeated reopen at exact H | Process termination, not power loss |
| B5 | Damaged inventory/completion/data/WAL, wrong resealed head, missing history and extra files refused | SHA-256 integrity, not authenticity |
| B6 | Existing/overlapping destinations and portable aliases/device names refused; Linux linked ancestors refused; decoder traversal/case duplicates rejected | Cooperative filesystem; Windows junction creation not exercised |
| D1 | Windows ProcessCrash/model tests and native Linux FileAndDirectoryFlush capture/restore | Docker overlayfs is not universal filesystem certification |

Independent Python struct/UUID/SHA-256 encoding produced backup-inventory-v1.hex and
backup-completion-v1.hex. The codec tests compare bytes, reject every inventory truncation
and invalid canonical paths/duplicates. Existing fixture bytes remain unchanged.

All new writes, namespace changes, barriers and operation-owned clone/workspace cleanup
use ITransactionStorage. Verification occurs on a clone to keep sealed data immutable.
Source writer ownership persists throughout capture; the coordinator gate serializes
commits/checkpoints. Runtime lock files are not copied as ownership into restores.

## Reproduction

```powershell
dotnet build Bosak.XmlDb.slnx -c Release --no-restore
dotnet test Bosak.XmlDb.slnx -c Release --no-build --logger 'trx;LogFilePrefix=backup' --results-directory .tools/backup-windows-verified
pwsh tools/test-linux.ps1 -ResultsDirectory .tools/backup-linux-verified
```

The Linux helper uses the pinned SDK 10.0.301 image, read-only source/package-cache
mounts, isolated /work and no container network. Test processes/artifacts are isolated
from Windows build outputs. No remote CI run, release, migration of a user store or
committed-history deletion is performed. C1-C3 and R1-R3 remain unimplemented.

*Last updated: 2026-10-27*
