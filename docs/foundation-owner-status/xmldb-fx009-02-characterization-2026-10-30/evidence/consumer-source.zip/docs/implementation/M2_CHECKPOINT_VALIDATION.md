# M2 Checkpoint and Reader-Lease Validation

## 1. Results

2026-10-26: the complete suite passed **144 tests on Windows and 144 on Linux**,
zero failures or skips on either platform: 87 Storage, 27 Xdm, 30 Integration.
[Structured evidence](m2-checkpoint-results.json) contains exact per-platform totals
and storage-fault counts extracted from TRX output.

| Environment | SDK | Runtime | Filesystem exercised | Injected positions |
|-------------|-----|---------|----------------------|--------------------|
| Windows 10.0.26300 x64 | 10.0.301 | 10.0.11 | Host temporary stores | 457 |
| Ubuntu 24.04 Linux container | 10.0.301 | 10.0.9 | Docker overlayfs | 449 |

Counts differ because directory ancestry differs between the two environments.
Both runs include 21 observed-boundary sweeps, including the new checkpoint and reader
publication paths. Native Linux directory fsync was executed for scalar commits,
checkpoint/reopen and adoption while another snapshot retained its reader handle.
This is local Docker Desktop Linux execution, not a remote CI or physical power-loss
certification. Windows directory mode remains explicitly unsupported.

## 2. Checkpoint Correctness and Failure Tests

A complete independent materialization is checked against its anchor and selected
only after exact WAL-prefix/record binding. Tests compare it with FullJournal, verify
that old generation materializations are skipped, and reconstruct a missing suffix
from the checkpoint copy. Missing original generation directories do not invalidate
an otherwise independent checkpoint copy; no production code deletes them.

Corrupt selectors, anchors, copied format/directory/fragments and false prefix digests
fall back to full history. Required WAL removal/corruption and rechecksummed semantic
mutations still fail closed. A missing selector does not cause directory guessing;
idempotent publication validates/reuses an existing same-sequence checkpoint.
Golden fixtures cover anchor/selector/lease bytes, with every anchor truncation boundary.

Six real process-kill points cover stage creation, copied files, anchor flush,
directory publication, selector temporary flush and selector publication. A prior
checkpoint remains selected until the replacement selector is published. Every case
retains complete committed data and WAL; recovery is repeated in new processes.
An additional kill immediately after acknowledgment verifies the selected anchor persists
under the process-crash model.

## 3. Reader Lifetime Tests

Multiple snapshots and transactions share a stable per-sequence OS lease. Tests verify
that exclusive opens remain blocked until all snapshot/transaction holders dispose,
including after the creating coordinator has closed and another coordinator commits
and checkpoints. An uncached old reader continues returning its original value.

Independent processes verify the same lifetime. A holder disposes its coordinator,
retains the snapshot and blocks another process's exclusive probe. It then either
reads/disposes or is killed; the OS releases ownership and a new exclusive probe
succeeds. These tests passed on both Windows and Linux. Corrupt stable identities
fail closed without replacement; partial identity publication can recover/retry.
Stronger-mode adoption does not open shared stable lease files for writing.

## 4. Public Sample Evidence

Executed import (20 lines), two updates, checkpoint at S=2, another update, then full
and checkpoint reads. Both return SO-4, 20 lines and commit sequence 3. The completed full recovery pass
reports 3 WAL records/3 materializations; checkpoint recovery reports S=2,
3 WAL records/2 materializations. Snapshot header reads report zero line payload reads;
those counters exclude startup/anchor validation.

```sh
dotnet run --project samples/EmbeddedQuickstart -c Release -- import order-store 20
dotnet run --project samples/EmbeddedQuickstart -c Release -- update order-store SO-2
dotnet run --project samples/EmbeddedQuickstart -c Release -- checkpoint order-store
dotnet run --project samples/EmbeddedQuickstart -c Release -- read-checkpoint order-store
```

## 5. Reproduction and Platform Isolation

Windows/local commands:

```sh
dotnet restore Bosak.XmlDb.slnx --locked-mode
dotnet build Bosak.XmlDb.slnx -c Release --no-restore
dotnet test Bosak.XmlDb.slnx -c Release --no-build --logger "trx;LogFilePrefix=checkpoints" --results-directory .tools/checkpoint-windows-results
dotnet format Bosak.XmlDb.slnx --verify-no-changes --no-restore
pwsh tools/check-docs.ps1 -ProjectPath . -Strict
```

Linux container helper (requires Docker and restored host NuGet cache):

```powershell
docker pull mcr.microsoft.com/dotnet/sdk:10.0.301
./tools/test-linux.ps1 -ResultsDirectory .tools/checkpoint-linux-results
```

The helper copies read-only source into /work on the container filesystem, excludes
host bin/obj/tools artifacts and uses a read-only package fallback cache with no
container network. It builds with the project's actual global.json SDK pin; no pin
is edited. Results are written to the selected in-workspace directory and the
container is removed afterward. The helper itself was additionally verified using
the native checkpoint/live-reader barrier test filter.

Full Linux TRX evidence is in ignored .tools/checkpoint-linux-results; Windows evidence
is in .tools/checkpoint-windows-results. The image manifest digest and kernel/filesystem
context are recorded in the structured summary. No other services or host toolchains
were changed; no image or package was published.

## 6. Remaining Gates

All committed WAL and generations remain retained; PreferCheckpoint still validates
the complete prefix. There is no truncation or garbage-collection API. Old M1/older
experimental readers are not retroactively leased. Validate redundant anchors,
reader compatibility, retirement/backup contracts and deletion fault matrices before
reclaiming anything. Physical power-loss, real bounded-volume ENOSPC and production
filesystem/controller validation remain separate. Linux overlayfs success is not a
universal durability claim or a performance benchmark.

*Last updated: 2026-10-26*
