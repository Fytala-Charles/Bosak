# M2 Checkpoint and History Retention Design

## 1. Status and Invariants

Non-deleting checkpoints, optional verified recovery, shared reader leases, independent
recovery descriptors and conservative retention inventory are implemented.
[ADR-007](../ADR-007-recovery-descriptors-and-retention-inventory.md) defines descriptor discovery
and the report that retains every file. WAL truncation and committed-generation deletion remain design-only. [ADR-005](../ADR-005-filesystem-barriers-and-checkpoint-gates.md)
records the barrier contract. [ADR-006](../ADR-006-nondeleting-checkpoints-and-reader-leases.md), the [byte format](M2_CHECKPOINT_FORMAT_V1.md) and [validation report](M2_CHECKPOINT_VALIDATION.md) describe the implemented checkpoint/lease gate. Complete histories remain required.

A checkpoint must independently reconstruct a committed document at sequence S,
validate its manifest/directory/fragments and bind the accepted WAL prefix. Later
recovery starts from a verified anchor and requires a contiguous suffix. Missing
or corrupt required state must fail closed; no guessing from CURRENT or directory names.

## 2. Proposed Immutable Anchor

The versioned/checksummed checkpoint record is implemented and fixed in byte fixtures; see M2_CHECKPOINT_FORMAT_V1.md. The following retention extensions still require their own codecs/contracts.
It should include document identity, S, exact generation manifest hash, a digest of
the WAL record at S and explicit format/compatibility metadata. Reuse numeric bounded
references; never decode arbitrary filesystem paths. Snapshot files must be a complete
verified materialization, not merely a pointer to data scheduled for deletion.

Initially publish non-deleting checkpoints while preserving the original base and
all WAL/generations. Compare checkpoint-based replay with full replay for every
fault scenario before permitting a truncated history. Independently validate each
anchor before selection; a checkpoint cannot be trusted just because CURRENT names it.

## 3. Publication and Recovery

Prepare an immutable checkpoint, flush its content and namespace dependencies, validate
it and bind its exact sequence/hash. Publish the selector atomically and durably before
acknowledging checkpoint completion. CURRENT remains a visibility hint; checkpoint
anchors and contiguous retained WAL determine recovery authority.

Before deletion, use redundant independently verified anchors and retain the log suffix
needed by every fallback anchor. The deletion cutoff cannot exceed the oldest usable
anchor. Never remove prefix records based solely on the newest selector. Define/test
behavior for one corrupt anchor, torn selector, stale CURRENT, missing log ranges and
termination during repeated checkpoint replacement. The first non-deleting byte layout, selector and explicit independent descriptors are implemented.
Deletion cutoffs and epoch admission remain future implementation work.

## 4. Protect Lazy Readers Before Reclamation

Every generation-backed snapshot and transaction must acquire a stable per-generation
shared OS lease before exposing nodes. A snapshot must retain its lease until Dispose,
including after its creating coordinator has been disposed. The lease registry must
work across successive coordinators and processes; a local in-memory count is insufficient.

Coordinator selection plus lease acquisition must be serialized with reclamation. To
reclaim a generation, acquire exclusive ownership of its stable lease and recheck it
is neither a checkpoint anchor nor the live root nor required by retained replay.
Do not unlink/recreate lock files while leases may exist: that can split lock identity.

Base M1 snapshots predating lease adoption do not hold such leases. Keep the base
indefinitely in the first checkpoint implementation. Older experimental binaries also
lack these protections; require an explicit compatibility/reader-quiescence transition
before any new reclamation mode, rather than assuming no old readers exist.

## 5. Deletion Protocol and Fault Matrix

Determine the protected set before any unlink. Delete only canonical, resolved paths
inside the store; never remove a live root, checkpoint dependency or reader-pinned
generation. Flush directory changes and record a replayable/recognizable retirement
state so interruption cannot make retained data appear missing. Release exclusivity
only after the retention decision and namespace operations are complete.

Tests must interrupt every checkpoint write/flush/rename, every selector/barrier and
every generation/log deletion. Include active uncached lazy readers, transactions,
coordinator disposal, process termination, anchor corruption, disk-full/short writes,
missing suffixes and repeated recovery. Old readers must continue reading their original
values while new readers observe complete committed state. Failure must preserve a
verifiable recovery route or fail closed; it must never silently return older data.

## 6. Go/No-Go for Reclamation

Require all of the following before deleting committed history:

- Native filesystem barrier execution and a stated supported failure model; Windows
  process mode alone does not establish directory/power-loss guarantees.
- Non-deleting checkpoint replay parity with the current full-journal recovery.
- Cross-process snapshot leases with old-reader compatibility addressed.
- Crash/I/O-fault coverage for the complete checkpoint/retirement protocol.
- A retention/backup contract and a format/version migration decision.

Non-deleting checkpoint parity, reader leases and native Linux overlayfs tests now pass. These do not establish physical power-loss certification, old-reader compatibility or checkpoint reclamation; those gates remain open.

The [compatibility/backup/retirement protocol](M2_COMPATIBILITY_BACKUP_RETIREMENT.md)
specifies the transition and acceptance gates (ADR-008). Verified full-history
backup/restore is implemented in [ADR-009](../ADR-009-verified-full-history-backup-and-restore.md);
mandatory-format metadata/admission primitives are now implemented internally in
[ADR-010](../ADR-010-mandatory-epoch-format-and-admission-primitives.md). Epoch data
integration and migration come next. Optional format-1 markers cannot protect
against older binaries; migration must use a separate mandatory-format root. Keep
base and WAL prefix intact in the first future generation-retirement scope.

*Last updated: 2026-10-27*
