# SR3-A Stopped Handoff Preparation Contract

Date: 2026-10-30. Design only, following committed/pushed readiness checkpoint 069332c.
[ADR-036](../ADR-036-stopped-handoff-preparation-and-lifetime.md) supplements ADR-034/035.
No new runtime API, capability, append, format or qualification is implemented here.

## 1. Supported Input and Private Success

Initial preparation supports exactly one valid legacy Enroll, no later authority events,
no candidate/work transition and no ScalarWal source. Parent, authority, source and sealed
capture must be the actual paired objects/mapping already retained by the observation.
The successor is the paired parent's actual Context.SessionId, nonempty and different from
the exact recorded owner; checked previous owner generation + 1 must not overflow. For the
supported first Enroll generation 1, the proposed successor generation is 2. Codec acceptance
of a GUID or transition does not establish live authority. No caller-selected successor exists.

A successful Observe must install an owner-private immutable proof only after its complete
second baseline verification, exact journal/native identity checks and final compatible gate
checks succeed. Installation and caller closing are serialized. Store exact object identities,
configured context/authority IDs, observation nonce, administrative position, authority length
and digest, metadata bytes, recorded owner/generation, baseline/selection/source binding,
capture mapping/inventory commitment and native identity pins. Use actual verified values.
Returned descriptions remain inert. _attempted=true is never eligibility. Refused, missing,
unsupported, contradictory, exceptional or closing outcomes install no proof. A later supplied
description cannot repair them. Successful observation alone still grants no executable plan.

Preparation requires fresh controlled-scope, prior-work, executor, publisher and release
reconciliation facts all Confirmed, with the same actual context/mapping. Nonterminal admin
history overrides optimistic prior-work assertions as in SR2. These facts remain supplied
host assumptions; no native lock proves global freshness or the absence of old work/readers.

## 2. Preparation and Revalidation

Names below describe proposed internal responsibilities, not implemented methods.

1. Check caller thread, exact authority/scope/source references, open admission, successful
   private proof and no prior preparation. Under compatible brief gates acquire an actual
   preparation child before any unlocked validation. Reserve the sole preparation attempt
   and consume its eligibility; failure is terminal for this observation, without retry.
2. Outside peer gates repeat complete read-only source and sealed-capture closure/history
   verification, exact inventory.bin commitment and native identities, both exact parent and
   authority journals/metadata and administrative reconciliation. No live Open/recovery,
   clone publication, capture, file reservation, directory creation or host callback occurs.
3. Compare against the private successful proof. Changed native identities, heads, bytes,
   mapping, baseline, owner or selection refuse. Fresh supplied facts cannot replace actual
   proof. Missing facts require reconciliation; corrupt histories fail closed.
4. Briefly enter authority then nonblocking parent then nonblocking source gates. Compare
   exact live references, admission/generation/version tokens and the revalidated pins.
   Busy peer gates refuse without waiting under an earlier gate. No native/file I/O,
   serialization, hashing, disposal or callback runs inside these gates.
5. Atomically turn the preparation child into the sole prepared-plan child; retain all exact
   expected values and proposed successor tuple privately. Return only that opaque live plan.
   Any closing/failure path releases its actual preparation child outside peer gates.

Before claim, repeat step 2 using fresh required facts and compare to the prepared values.
Hold a real validation child through that unlocked work so concurrent disposal cannot close
usable handles. Final claim repeats step 4 and atomically changes Prepared to Claimed,
transferring the actual plan child to one executor. The in-memory transition performs no I/O
or callback and cannot be replayed. A stale/busy/failed claim consumes the plan and grants no
executor; release its child after active validation drains. No automatic retry is introduced.

Read-only checks are point-in-time. Cooperating ownership protects the critical interval;
uncooperative external replacement cannot be globally fenced by these gates. SR4 must check
its own exact append preconditions before output and qualify the remaining uncertainty.

## 3. Actual Resource Ownership and Closing

Implement one resource owner behind the observation. It owns the existing single parent read,
authority operation and actual restart-source child. Track wrapper admission/closing, active
validation, the unique plan/executor child and actual release outcome separately. Internal
children do not call BeginRead again: preserve parent operations=2 and reads=1 invariants.
Do not synthesize a second source child, reopen streams, rearm the stopped source or replace
actual child ownership with an object reference/native identity pin. No-plan SR2 retains its
existing immediate-drain behavior when closing and no operation is active.

| Event | Required transition and lifetime |
|---|---|
| Scope/authority/parent/source closes before preparation admission | Refuse; no child or output |
| Any participating wrapper closes during unlocked validation | Mark closing; final publication/claim refuses; validation child keeps original handles usable until exit |
| Scope closes with Prepared plan | Invalidate plan immediately; detach its child under gates, release outside gates after active validations drain; stale plan cannot claim |
| Plan disposed before claim | Cancel plan once; release its real child after active validations; wrapper may remain open but no second preparation |
| Claim wins before competing wrapper close | Executor keeps actual paired operation and original source writer usable through completion; wrapper closing prevents new operations |
| Claimed plan wrapper disposed | Does not revoke executor or release its child; only executor completion/explicit no-output abandonment releases it |
| Executor completes without output in SR3 | Terminal stopped result; child released once outside peer gates; no append route exposed |
| Process dies | All in-memory proofs/plans lost; fresh stopped ownership and reconciliation required; no descriptor replay |

Authority/source/parent closing must serialize with claim at the same compatible gates.
Do not let a closing wrapper's current RequireCurrent rejection invalidate an already claimed
executor's private retained-use access; introduce narrowly checked claimed-child access only.
It must not admit any ordinary source mutation. Source stop stays latched after every outcome.
No source data access or append occurs under the atomic gate transition.

Wrapper Dispose closes admission synchronously. Separate release completion reports actual
drain and close status; returning from Dispose with live children is not release acknowledgment.
After wrapper closing and last active child, release source then paired operation exactly once,
outside peer gates, preserving existing dependency order and failure retention. Unknown source
close retains the operation/dependencies; unknown authority close retains its parent admission.
Do not retry an unknown close or mark downstream ownership released. Make retained unknown
state reachable for diagnostics. Wrong-thread/ref operations refuse without consuming a valid
owner's state. Public descriptors remain unable to access claimed-child methods.

## 4. Output Boundary and Acceptance Gates

SR3's executor is a no-output capability used only to qualify retention, single claim and
terminal release. It must expose no TransferOwner writer or callback that can mutate a journal.
SR4 separately implements conditional existing-v1 TransferOwner, marks possible output before
delegation, exact flush/readback and complete-chain validation. It preserves baseline, selection,
source/candidate/work bindings and all history. Any possible-output uncertainty suppresses
acknowledgment, retains real operations through actual drain and forbids automatic retry.
A future stopped acknowledgment changes recorded owner only; no routing or source resume.

| Implementation slice | Required acceptance before completion |
|---|---|
| SR3-B1 private proof and actual child lifetime | Happy private successful proof; missing/refused/exception never eligible; default SR2 drain unchanged; preparation cancellation; active validation versus every wrapper close; actual original stream usability and counts; unknown release ordering/retention |
| SR3-B2 no-output preparation and atomic claim | Exact Enroll happy path; same/empty successor and overflow; wrong thread/object; stale heads/native identities/data/capture; unsupported histories; busy gates; one plan/one claim; no write delegation or byte/inventory change |
| SR3-C local qualification | Ordered close-before/claim-before schedules for every participating owner; repeated concurrency with bounded claims; cross-process ownership and restart/no replay; Windows guards separated from actual native Linux execution |
| SR4 separate gate | Reviewed append design plus actual fault/partial-write/ACK-loss/process qualification; never inferred from SR3 passing |

Tests must cover both successful and failure/edge paths, real retained operations rather than
mock pins, historical snapshot survival and unchanged inventories. Full repository tests must
pass for implementation steps. Keep earlier restore timeouts separate from passing reruns.
No SR3 runtime cases were added or executed for this design step.

## 5. Remaining Gates

Host-controlled scope/freshness and durable accepted-work accounting are not implemented by
this internal pilot. Public mutable API, actual host routing, archived pre-lease release
provenance, durable source fencing, physical power-loss/real ENOSPC and all source replacement,
retirement/reclamation remain open. CanReclaim=false; preserve every source/candidate/WAL history,
existing wire bytes and frozen fixtures. Next implement SR3-B1 before preparation/claim code.
