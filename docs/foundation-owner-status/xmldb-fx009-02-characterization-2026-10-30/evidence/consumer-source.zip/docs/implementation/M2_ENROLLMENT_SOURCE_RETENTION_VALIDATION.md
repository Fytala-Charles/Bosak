# EF1 Enrollment Source Retention Validation

Date: 2026-10-29. Parent checkpoint 5237ee3 is committed/pushed. EF1 is subsequent local work.
See [ADR-033](../ADR-033-retained-source-exclusion-and-first-enrollment.md) and
[implemented contract](M2_ENROLLMENT_SOURCE_RETENTION.md).

## Implemented Boundary

Opt-in actual source/freeze child registration retains the original writer FileStream and
mutation token through owner/freeze disposal. Source-local memory-only arming after native
inspection latches the original owner stopped. Ordinary disposed owner paths remain strict;
an actual armed child can inspect its still-held stream. Final actual drain closes that same
stream, with explicit unknown-release state on error. No journal or authority file is involved.

Native inspection verifies the actual source root and regular/single-link empty writer role.
It is not complete-history verification or a source-baseline acknowledgment. EF2 remains open.

## Focused Windows Qualification

98 cases pass: 92 Storage + 6 Integration. This includes 25 new Storage cases and four new
process cases, with existing 35 borrowed enrollment-preparation and 32 cutover cases unchanged.
The two old cutover process cases also pass. Ordered pending/armed, owner-first/freeze-first
schedules prove endpoints; a separate case repeats simultaneous owner-close/arm 12 times.
Those repetitions do not prove every possible interleaving.

New cases cover exact native handle continuity after disposed wrappers, prior/new transaction
and checkpoint/anchor/backup rejection, original-owner latch after drain, live readers and
independent snapshots, no-retainer backup/close compatibility, explicit new-owner non-fencing,
missing/foreign/duplicate capture, required native inspection, repeated arm, wrong thread,
corrupt admission, and three close-confirmation failures: before delegation, after actual
close, and returning without closing. Unknown close is retained and never retried. Real
fixture handle cleanup by injected test adapters does not rearm production state.

Four process cases each run twice (eight independent processes per focused run). Pending and
armed children retain ownership after both owner and freeze dispose. A contender remains
excluded until actual graceful child drain or awaited process death. Graceful drain exposes
release while the holder process and its old snapshot remain alive. Source bytes and file/
directory inventory remain unchanged; no commits or authority publication occur. Setup/import,
source open and sealed capture precede retention and are outside its no-write claim.

## Isolated Linux and Full Regression

Fresh isolated Linux passes 571 (521 Storage + 50 Integration), including all 29 new bodies.
Xdm has no matching cases in this filter. Cached pinned SDK 10.0.301 runs with read-only source/
cache mounts, no network and isolated outputs on x64 overlayfs. Seven expected MINVER1001
warnings reflect the copied Git-free source. Docker remains running. No full Linux, ARM64,
other allowed filesystem or physical durability/real ENOSPC certification is claimed.

The fresh unfiltered full Windows command exits zero: all 2,360 tests pass (1,703 Storage,
630 Integration and 27 Xdm), with no failures/skips or reruns needed in this full attempt.
Storage takes 41 minutes 30 seconds; Integration takes 9 minutes 34 seconds. All 2,331 prior
test names remain, with exactly 25 new Storage and four new Integration cases. Existing
post-kill source/host cases pass in this full attempt; that does not diagnose or erase the
failures retained in earlier baseline reports.

Formatting/analyzers, strict documentation, actual hidden/link portability and frozen fixture
checks pass. Final source hashes and TRX paths/hashes are recorded in machine evidence.
The earlier 2,331-case/542-case baseline is not execution evidence for changed EF1 inputs.
Windows catalog totals include existing host-only guarded bodies; do not reinterpret those
rows as native Linux execution.

## Limits and Next Step

Source-local arming has no authority/parent admission integration. Observations are not
execution capabilities; operational assumptions are not verified host facts. The original
owner latch is not a persistent fence or permission to remove history. Source/store/public
formats, frozen fixtures and all committed histories remain unchanged.

Next EF2 adds a distinct retained preparation and atomic dispatch admission, with no authority
writes. It must not wait on source I/O while holding authority/parent lifetime gates; source-only
EF1 Arm does not qualify that combined protocol. General append, EF3/EF4, actual host control, public APIs, archived release evidence,
source replacement and all retirement/reclamation remain open.

## Machine Evidence and Delivery

[Machine evidence](m2-enrollment-source-retention-results.json) records eight final C# source
hashes, exact full/focused counters, unchanged prior catalogs, process repetitions, native
Linux environment and close-fault positions. Earlier focused runs are separate evidence and
are not added to full totals. Hashes describe raw validation checkout bytes, not archived
release provenance. C# inputs remain unchanged since the passing full build.

Checkpoint 5237ee3 is committed and pushed to origin/main. EF1 code/docs are subsequent local,
uncommitted work; Docker remains running. No authority bytes, public API, wire format, frozen
fixture or retained source/candidate/WAL/journal history is changed by EF1 execution. Next EF2
retained preparation/atomic admission must remain no-output and qualify source-gate contention
without waiting on I/O while holding authority/parent lifetime gates.
