# M2 ET9-C Internal Independent Epoch Restore

Date: 2026-10-27. Implements restore in
[ADR-017](../ADR-017-epoch-full-history-backup-and-independent-restore.md), using unchanged
[metadata1.0](M2_EPOCH_BACKUP_FORMAT_V1.md) and
[capture verification](M2_EPOCH_BACKUP_CAPTURE.md). Internal operations only; public epoch
APIs, migration/cutover and ET9-D exhaustive fault qualification remain pending.

## Input and ownership boundary

EpochBackupRestore.Restore validates an absent, nonoverlapping destination and unlinked
existing parent, then reads the immutable backup seal/closure/headers before output creation.
It pins canonical inventory bytes, creates a fresh operation-owned sibling workspace and
runs both source complete-data and full-WAL-redo verification oracles. A resealed logical
mismatch fails before SourceVerified/rebinding. Sealed data is never admitted or repaired.

The source store is not reopened, renamed or written. Existing source readers/writers can
continue against their own root; the backup is fixed at H. All copied document data and
read source WAL bytes are checked against expected source entry lengths/digests. The final
source seal/data is rechecked before publication. External/malicious mutation is outside
the cooperative contract, but observed changed bytes fail instead of being silently mixed.

## Fresh identity and exact rebinding

Reserve fresh nonzero RestoreId, StoreId and EpochId once per attempt, with destination
store/epoch IDs different from the source. Preserve DocumentId, H, every transaction ID,
node identity/order/topology/URI/base URI/namespaces/value, and all manifest/directory/fragment
bytes. An independent restore is a new writable branch, not source continuation or replication.

- Copy document data to bundle/store through fresh-file byte copies, never links/inodes.
- Encode exact ScalarWal2.1 destination FORMAT/EPOCH/BASE/CONTROL using the unchanged base
  manifest hash and canonical destination BASE digest.
- Re-encode WAL1..H with destination binding and predecessor-WAL digests in order, starting
  with zero at sequence1. Every operation/transaction/sequence and predecessor/result manifest
  digest is preserved. Check exact rebound bytes against the original operation records.
- Encode each generation's destination FORMAT and witness referencing the new WAL digest;
  write canonical CURRENT at the original H. H=0 retains zero WAL and equal base/head hashes.

An ephemeral destination verification inventory records expected transformed bytes; it is
not published as a new backup inventory or added to the store. Both complete-data/no-repair
and exact full-WAL-redo oracles must also pass for this destination representation. Every
copied document byte is checked against its original source entry.

## Runtime readiness and provenance

After data verification, create fresh admission and stable reader identities for every
sequence0..H, plus required runtime directories. Open the private destination without
permitting redo/tail/CURRENT repair, check exact H/head and force all head values, then
close every private-path writer/admission/snapshot handle. Initial reader names must match
exactly and private staging/current-publication debris is not permitted at publication.

Write/flush external bundle/origin.bin as BXEO, binding original BackupId/inventory digest,
source identity/FORMAT/head, fresh destination identity/FORMAT/head and initial H. Validate
it against the original inventory and destination FORMAT/CURRENT, validate the exact bundle
shape (origin.bin file and store directory), and recheck runtime/data readiness. A resealed
origin substitution or missing initial reader fails before publication.

Origin is initial-prefix provenance, not a recovery selector. Later independent commits do
not rewrite it. The existing store profile changes no requirements; normal open/recovery
operates on store/ without treating its parent's audit sidecar as authority. Full source
provenance validation requires the referenced immutable backup; hashes are not authentication.

## Atomic publication and failures

Close all staging-path handles before renaming the whole bundle to the absent destination
and synchronizing both parents. Return internal EpochRestoreResult with RestoreId, BackupId,
source/destination identities, H and the literal published destination/store StorePath.
Never return or retain a staging-root token. Applications must explicitly select StorePath;
the bundle itself is not a database root. Existing public format-1/immutable APIs still reject
ScalarWal2.1 and do not gain a fallback route.

All writes, flushes, file/directory operations and owned cleanup use ITransactionStorage.
The existing .xmldb-epoch-backup-<guid> private-workspace infrastructure is shared with
capture; only contained verification clones and an empty operation workspace are cleaned.
Failed workspaces can remain. No discovery, automatic routing, merge, overwrite, original
root replacement, source/backup deletion or committed-history reclamation is added.

Failures before publication leave no final bundle. Failure/kill after rename can leave a
complete published bundle without acknowledgment; exceptions do not imply rollback. Retry
into a fresh destination. Publication is within the destination filesystem, not a cross-volume
rename. ProcessCrash remains default; native Linux FileAndDirectoryFlush is explicit with
no silent fallback. Local filesystem execution is not physical power-loss/real ENOSPC proof.

## Next gate

[Validation](M2_EPOCH_BACKUP_RESTORE_VALIDATION.md) proves initial parity, branching,
representative rejection/failure states, native restore and process publication boundaries.
Next ET9-D must inject every observed capture/restore persistence call before/after, real
partial writes and repeated process/native failures. ET9 remains incomplete. Public APIs,
full-history migration/cutover, archived-reader C1-C3 and retirement remain separate gates.
