# EF2 Retained Enrollment Admission Validation

Date: 2026-10-29. Parent checkpoint d644db5 is committed and pushed. EF2 is subsequent local work.
See [implemented contract](M2_RETAINED_ENROLLMENT_ADMISSION.md) and
[ADR-033](../ADR-033-retained-source-exclusion-and-first-enrollment.md).

## Focused Qualification

All 29 new Windows cases pass: 27 Storage and two Integration. Real source/capture histories
cover H=0, H=1 and H=3. Tests assert unchanged role/source bytes, exact actual-owner binding,
single consumption, generic-inspection exclusion and compatibility of old borrowed preparation.
Closing schedules cover source, freeze, authority and parent. Three deterministic gate-busy
schedules prove refusal without waiting behind the held gate; they do not prove every possible
interleaving. Reentrant source callbacks cannot prepare, arm, inspect or dispose this protocol.

Negative tests cover changed capture inventory, corrupt WAL, unpublished staging, changed or
invalid evidence, forged plans, wrong threads and preexisting generic inspections. Ownership
transfer survives caller plan disposal and all wrapper closes. Before/after-delegation source
close faults retain authority/parent operations and report unknown release rather than success.

Two process cases each repeat three times (six workers per focused run). Actual execution
retains all three original owner roles after wrappers close. Contenders remain excluded until
graceful execution drain or awaited process death. Graceful drain is observed while the child
and its old read snapshot remain alive. Empty authority bytes stay empty; reopening cannot
recreate initializer authority. These are lifecycle tests, not authority-write crash tests.

## Regression Evidence

Isolated Linux passes 600 cases (548 Storage and 52 Integration), including all 29 new bodies.
Xdm has no matching cases. Pinned SDK 10.0.301 runs on x64 overlayfs with read-only source/cache,
no network and isolated outputs. Seven expected MINVER1001 warnings reflect Git-free sources.
No full Linux or physical durability qualification is claimed.

Formatting/analyzers, frozen fixture verification (13 Python cases and four authority vectors),
strict documentation and actual hidden/link portability checks pass.

The fresh unfiltered full Windows command passes all 2,389 cases: 1,730 Storage,
632 Integration and 27 Xdm. No failure, skip or rerun occurs in this full attempt.
All 2,360 prior test names are retained, with exactly 27 new Storage and two Integration cases.
Earlier focused runs are not added to these totals. Windows totals include existing
host-only guarded bodies; they are not proof of native Linux execution.

Final counters, eight unchanged C# source hashes and raw TRX hashes are recorded in [machine evidence](m2-retained-enrollment-admission-results.json).
Focused runs are separate evidence and are not added to full totals.

## Limits

No authority output, application writer, route decision or persistent fence is enabled.
Operational assertions remain supplied assumptions. Frozen layouts and fixtures, all committed
history and CanReclaim=false remain unchanged. EF3 first-frame output and EF4 persistence
qualification remain open, as do public APIs and archived release/real host acceptance.
