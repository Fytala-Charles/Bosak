# CA1 Published Migration Compatibility Validation

Date: 2026-10-28. Internal local-baseline compatibility evidence only. No production code,
public API, format, routing, licensing or packaging change.

## 1. Coverage

MigratedBundleRejectionTests creates real legacy H=0 and H=3 stores, captures sealed backups
and invokes MG3 conversion. It tests the published wrapper, returned store and all three
positive-H generation roots. Each fixture is opened successfully through explicitly internal
coordinator/history APIs before rejection probes and afterward, reading every sequence.

Ten frozen-reader cases exercise raw, coordinator, durability, recovery and immutable Open
at both history lengths. Two current-reader cases exercise those five paths plus default
EpochAdmission at every location. Across these 12 cases there are 35 frozen subprocess
probes and 42 current calls. Each call must reject and preserve all source/backup/bundle
file bytes, file names and directory inventory. Runtime admission, writer and generation
reader physical file identities are compared too: volume/file ID on Windows and device/inode
using stat on Linux. These identity observations do not establish absence of old readers.

Current read-only entry points on store/generation must report profile rejection. Raw store
open rejects transaction state. The bundle wrapper intentionally lacks FORMAT; current
paths may reject with FileNotFoundException or the existing link-validation InvalidDataException.
The frozen immutable probe additionally recognizes exactly those missing-wrapper outcomes
only when migration.bin and store/ exist and wrapper FORMAT is absent. It does not treat
arbitrary process failure as successful rejection. Existing hash checks still run before
loading either frozen binary family. No frozen binaries/manifests are changed.

The current synthetic occupied-admission matrix remains retained and is rerun alongside
CA1. New tests do not hold admission exclusively during public probes; the occupied-lock
proof remains the existing synthetic test, not a claim of this real-bundle matrix.

## 2. Validation Scope

[Results](m2-migrated-bundle-compatibility-results.json) record focused Windows and isolated
Linux runs: 12 new cases plus 12 existing mutable-profile rejection cases. This is not a
new full regression run. Previous MG5 evidence retains its original 823 selected cases and
27 previously qualified expensive matrix cases. Adding CA1 makes the catalog 862 cases;
no new unfiltered 862-case execution is claimed. Frozen four-DLL hashes remain unchanged.
Formatting and strict documentation checks are required before handover.

## 3. Remaining Gates and Next Work

CA1 closes the repository-local real-bundle rejection coverage gap identified by the
[readiness audit](M2_RELEASE_READINESS_AUDIT.md). Complete C1 still needs actual archived
release bytes/provenance; local captures have no release/commit identity. Complete C2
still requires actual application routing and external writer-stop/restart contracts.
C3 admission observations do not fence uncooperative pre-lease processes. No result grants
retirement or reclamation; CanReclaim=false and all histories remain retained.

Next CA2: test actual migrated-candidate snapshot/transaction ownership while child creation
races owner disposal, with bounded cross-process maintenance exclusion and holder release.
Keep this internal and preserve exact runtime identities, failure outcomes and lock order.
Actual archived release acquisition remains an independent external evidence task.
