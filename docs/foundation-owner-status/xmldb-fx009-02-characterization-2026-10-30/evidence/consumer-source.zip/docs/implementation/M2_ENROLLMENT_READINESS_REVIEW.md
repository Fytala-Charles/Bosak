# EF1-EF4 Enrollment Readiness Review

Date: 2026-10-30. Checkpoint b7b6215 is committed/pushed. This is a documentation/evidence
review of the internal embedded pilot. No runtime, test, format or build input changes.
[Machine evidence](m2-enrollment-readiness-review-results.json) verifies 256 tracked inputs
and 51 retained TRX artifacts. This review approves neither another writer nor a public release.

## 1. Conclusion and Findings

The bounded first-enrollment implementation has substantial local evidence for original-handle
retention, one-shot admission, exact one-frame publication and terminal stopped outcomes. The
output phase has an authority-only reader. Consolidation also exposes a preflight conformance
gap and incomplete close-failure qualification; these must remain explicit before extending it.

| ID | Finding | Disposition |
|---|---|---|
| ER-001 | One truncated display name represents two distinct test IDs | Corrected evidence accounting in this review; 2,468 IDs, 2,467 display names. No test was lost. |
| ER-002 | Retained preflight performs protected-ancestor filesystem inspection while holding the shared authority read/append monitor | Open conformance hardening; next bounded change. Output delegation itself uses the authority-only path. |
| ER-003 | Source close faults are qualified, but direct authority/parent role-close failures have no controlled fault-injection evidence | Open qualification gap. Faulted release tasks are checked in code; do not claim DR18 is fully qualified. |
| ER-004 | Read-only restart exists, but post-enrollment owner handoff and verified stopped reconciliation are not implemented | Design/implementation gate before general post-enrollment operations; receipts/descriptors never restore execution authority. |

ER-002 follows a concrete call chain: PrepareRetainedFirstEnrollment, TryArmRetainedFirstEnrollment
and admitted execution inspection call ValidateEmptyEnrollmentAuthority. That helper locks
_readGate and calls ReadOwned. ReadOwned calls CheckPlacement, which visits protected root
ancestors through directory checks and native path identities. _readGate is also the first
writer's serializer. This is protected-path metadata I/O, not a source coordinator callback,
and no failing execution or deadlock is demonstrated here. Nevertheless it falls outside the
literal [ADR-033](../ADR-033-retained-source-exclusion-and-first-enrollment.md) cross-phase rule
excluding source/capture inspection under authority serialization. Do not broaden the clean
output-phase result into a claim about every preflight call.

Relevant source: [preparation](../../src/Bosak.XmlDb.Storage/ApplicationAuthorityRetainedEnrollment.cs),
[empty validation](../../src/Bosak.XmlDb.Storage/ApplicationAuthorityEnrollment.cs),
[owned reader/placement](../../src/Bosak.XmlDb.Storage/ApplicationAuthorityLifetime.cs) and
[authority-only output reader](../../src/Bosak.XmlDb.Storage/ApplicationAuthorityEnrollmentAppend.cs).
No contract relaxation or runtime fix is made by this review.

## 2. Case Identity and Retained Execution Evidence

| Stage | Windows catalog | Linux focused | Added Windows IDs |
|---|---:|---:|---:|
| Borrowed preparation baseline | 2,331 | 542 | Baseline |
| EF1 source retention | 2,360 | 571 | 29 |
| EF2 retained admission | 2,389 | 600 | 29 |
| EF3 conditional first writer | 2,434 | 645 | 45 |
| EF4 fault/process qualification | 2,468 | 679 | 34 |

Every previous Windows test ID is retained at each stage; EF1-EF4 add 137 unique IDs. The
borrowed baseline selects passing project runs after its separately recorded failure/rechecks;
it is not a single unfiltered command. EF1-EF4 each have retained fresh unfiltered full Windows
commands. This review reruns none of those suites and adds no cases. All counters and artifact
SHA-256 values are independently checked against the retained raw TRX files. The 51 artifacts
include retained failed/development runs; hash verification does not relabel those as passes.
Only the selected qualified runs provide the stated runtime totals.

Use UnitTestResult.testId, not truncated testName, for uniqueness. Two TransactionTests
Recovery_CorruptCommittedData_FailsClosed rows share one truncated display name. Their IDs
remain distinct and both are retained. Earlier stage name-based checks are useful checksums
of additions but cannot alone prove complete catalog identity. The 679 latest Linux IDs are
a subset of the 2,468 Windows IDs; matching IDs do not mean identical executed platform branches.

EF4 has eight new Windows host guards and eight actual Linux inode-substitution bodies.
Additional preexisting host-only guards remain in the full Windows catalog. Linux is a focused
679-case run, not a full current-source 2,468-case Linux qualification. Keep old ET9/MG native
policy runs and their dated inputs separate; do not relabel them as fresh EF1-EF4 execution.

The EF4 sweep observes a 387-byte frame, six seam edges and all 386 incomplete prefixes: 393
fresh fixture attempts including baseline. Those attempts are one catalog case. Its final
Windows elapsed time is 911,460 ms and Linux elapsed time is 161,294 ms; these are recorded run
costs, not controlled performance comparisons. Twenty-one process cases repeat twice, plus
three two-process races: 48 workers per qualified process run. Repetitions do not exhaust
scheduling. All source/capture/admin bytes and relevant inventories are checked as specified
by [EF4 qualification](M2_FIRST_ENROLLMENT_FAULT_VALIDATION.md).

Latest source/runtime hashes match. Two XML primary-constructor parameter comments added after
test compilation are verified as exact raw-byte-only deltas: removing each added comment
reproduces its recorded full-run source hash. Test bodies did not change, and the final build
passed. This review freshly builds the committed tree with zero warnings/errors and reflects
its public metadata; those actions are not a new runtime-suite result or archived binary proof.

## 3. Design Acceptance Coverage

Rows refer to the 24 obligations in the [design review](M2_APPLICATION_AUTHORITY_ENROLLMENT_APPEND_DESIGN_REVIEW.md).
The table describes bounded evidence, not blanket closure of every possible schedule/input.

| Obligation | Available evidence / limit |
|---|---|
| DR01 closed before retention | Acquire checks source availability and exact live freeze; pending close/dispatch rejection is tested. A dedicated closed-before-acquire row is not identified. |
| DR02 object/thread identity | EF1 foreign/duplicate capture and wrong-thread cases; EF2/EF3 forged/reused plans and thread rejection. |
| DR03 pending freeze close | EF1 PendingFreezeDisposed_ActualDrain_ReleasesOnlyUnarmedExclusion. |
| DR04 pending source close | EF1 Closing_RetainedChild_KeepsOriginalHandle and process holder tests. |
| DR05 closing versus arm | EF1 repeated/ordered race endpoints; EF2/EF3 closing-before/after admission; not every interleaving. |
| DR06 parent/authority close first | EF2 Arm_ClosingWins_NoOutput and EF3 Append_ClosingBeforeArm_RefusesWithoutOutput. |
| DR07 arm wins then closing | EF2 actual execution retention; EF3 wrapper closing; EF4 three I/O closing and process cases. |
| DR08 mutation/publisher exclusion | EF1 six original-owner mutation/publisher entries and pending backup rejection; normal no-retainer behavior preserved. |
| DR09 independent readers | Old/new source snapshots and process-held readers remain usable; no reader-absence inference. |
| DR10 descriptions are inert | Borrowed/already-armed/forged/consumed/thread cases preserve actual registrations. |
| DR11 generic inspection | Preexisting reads must drain; retained mode excludes generic Inspect and preserves immutable acquisition History. |
| DR12 changed source/capture | Direct capture/WAL/staging/evidence cases plus complete-history validators; not every mutation timing. |
| DR13 conditional head | Valid stale/torn authority head refusal, exact empty head and held parent-position checks; no head adoption. |
| DR14 native roles/corruption | EF3 corrupt roles; EF4 eight Linux inode substitutions and exact inventory preservation; Windows guards remain separate. |
| DR15 delegated write faults | Zero/short/extra/full targeted faults plus every observed incomplete prefix and seam edge. |
| DR16 flush/readback/final proof | Targeted failures, metadata/namespace/log changes and observed before/after I/O faults. |
| DR17 caller observation loss | Returned-before-delivery/process loss and retained actual operations; synchronous thread-confined API has no cancellation parameter. Existing host release-wait cancellation test is supporting scope only. |
| DR18 unconfirmed release | Source before/after/no-op close and retained parent/authority operations; direct authority/parent close-error injection remains ER-003. |
| DR19 qualified success | Exact prepared frame, flush/readback/full one-frame history, stopped receipt and confirmed cleanup. |
| DR20 no armed resume | Original-owner stop latch persists after drain; explicitly opened later owner does not inherit a durable fence. |
| DR21 process/restart | Empty/partial/full cases, two read-only restarts and no synthesized receipt/initializer; ER-004 remains. |
| DR22 old behavior | Borrowed preparation/no-retainer compatibility and every prior Windows ID retained. |
| DR23 before versus after arm | Unarmed explicit freeze-release behavior and sticky armed stop; no automatic retry. |
| DR24 platform accounting | Separate raw traces, guarded/native cases, policy and repetition counts; no stronger durability certification. |

The output-phase lock checks cover write/flush/readback and show no lifecycle/source gate held
there. They do not observe all protected-ancestor lookups in preflight: ER-002 prevents closing
the broader lock/I/O claim. Release-task checks are implemented, but code inspection is not a
substitute for ER-003 fault evidence. No async enrollment/cancellation contract is introduced.

## 4. Public Metadata, Compatibility and Operational Gates

Fresh Windows reflection finds 95 public Storage type/member/enum entries, exactly equal to
the pinned local immutable-epoch reader baseline: zero added/removed. The
[metadata record](m2-enrollment-public-api-review.json) records compared entries and binary
hashes. It does not independently validate nullability, optional defaults, behavior, XML docs,
ABI/API version policy or public DTO design. No fresh Linux reflection is claimed here.
All four frozen managed-binary file records match their two manifests; both manifests lack
archived release commit/provenance. They are local immutable baseline evidence, not C1 release
qualification. No fixture was rebuilt or replaced.

| Boundary | Current limit |
|---|---|
| Host facts | Fresh/queue-free/executor/publisher/work reconciliation flags remain supplied assertions. No library proof of real ingress or remote exclusion. |
| Source ownership | Original usable writer stream/token retained; latch is process-local, not persistent fencing of a later owner or old binary. |
| Application authority | Only initial legacy-source Enroll output is implemented; terminal stopped result, no further selection/work/owner-transfer writer. |
| Restart | Complete history may be inspected read-only; bytes do not prove old acknowledgment or revive initializer/plan capability. |
| Actual host | Internal pilot only. No production selected-root routing, durable accepted-work accounting or external writer fence. |
| Public release | Internal types remain internal; public consumer/DTO/default/diagnostic/version/packaging gates remain open. |
| C1-C3 | Local binary/ownership/migration evidence remains distinct from archived releases, actual cutover and pre-lease reader absence. |
| Durability/platform | First enrollment is ProcessCrash only. No full current Linux/ARM64/other-filesystem, real ENOSPC or physical power-loss certification. |
| Retirement | All histories retained, CanReclaim=false; no source replacement, WAL truncation or committed-history deletion. |

## 5. Next Bounded Change

Address ER-002 before another authority writer. Partition retained preflight so protected-path
placement/native-ancestor inspection occurs outside _readGate; keep exact authority role,
metadata and empty-head checks serialized through an authority-only reader. Actual retained
source/parent/authority registrations must span the unlocked phases. Preserve exact object/
thread/scope binding, terminal uncertainty and source stop latch. Do not weaken generic
OpenExisting/Inspect semantics globally, or change frozen formats/public surfaces.

Add targeted qualification showing protected-path work occurs outside authority serialization,
authority-role checks remain conditional, and closing/stale/corrupt inputs still refuse safely.
Then qualify direct authority/parent close-error reporting (ER-003), including physical-release
uncertainty with no unqualified acknowledgment. A separate stopped restart/enrollment and
owner-handoff contract (ER-004) must precede post-enrollment selection/work writers.

No new ADR is needed for this review: it identifies conformance work under ADR-033 rather than
accepting a different lock policy. Checkpoint b7b6215 is pushed; this review remains local.

ER-002 implementation follow-up (2026-10-30): [preflight separation](M2_RETAINED_ENROLLMENT_PREFLIGHT.md)
and [qualification](M2_RETAINED_ENROLLMENT_PREFLIGHT_VALIDATION.md) address the retained lock
boundary and add a direct closed-before-source-registration case for DR01. This dated review
and its hash inventory remain historical; changed runtime needs its own fresh regression.
ER-003 direct authority/parent close-fault qualification is next. No broader writer is enabled.

ER-003 implementation follow-up (2026-10-30): [direct role-release qualification](M2_ENROLLMENT_ROLE_RELEASE.md)
and [validation](M2_ENROLLMENT_ROLE_RELEASE_VALIDATION.md) cover authority/parent before/after/
no-op closes and required-cleanup versus later-disposal outcomes. Dated evidence above retains
its original scope. Next ER-004 stopped restart/owner-handoff contract; no new writer is enabled.

ER-004 design follow-up (2026-10-30): [stopped restart/handoff contract](M2_STOPPED_ENROLLMENT_RESTART_CONTRACT.md)
separates pure stopped assessment from actual retained evidence and future owner transfer.
Next SR1 pure classifier. No additional writer, resumed source or new capability is implemented.
