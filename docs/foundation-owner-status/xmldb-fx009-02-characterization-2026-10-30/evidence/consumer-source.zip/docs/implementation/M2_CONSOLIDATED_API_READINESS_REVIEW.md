# Consolidated M2 Regression and API Readiness Review

Date: 2026-10-28. Scope: internal ET/MG/CA/HC/PA prototypes and repository hygiene.
This review does not approve public mutable access, application cutover or M2 shipping.

## 1. Execution and Source Accounting

[Machine-readable results](m2-consolidated-api-readiness-results.json) separate the unfiltered
1,050-case source baseline from the final 80-case HC1 hardening batch. The latter replaces
79 baseline classifier rows and adds one case, yielding 1,051 unique validated catalog cases
per platform (754 Storage, 270 Integration, 27 Xdm). It is not a single unfiltered 1,051-case
run. Runtime source fingerprints show exactly the two classifier/test files changed after
baseline capture; all other runtime/test sources and fixtures remain at the tested baseline.

Case uniqueness uses TRX test IDs; two existing long-parameter cases share a truncated
display name but have distinct IDs and are not collapsed.

The unfiltered runs include all 18 ET9-D and nine MG4 expensive fault-matrix rows freshly;
they are no longer retained-only evidence for this review. Parsed test output records
observed persistence positions by process, modeled-strong and actual native Linux policy.
Old dated reports remain historical evidence and are not rewritten as new runs.

A passing catalog case may return early on an unsupported host. Matrix output explicitly
identifies Windows native nonexecution (six ET9-D plus three MG4 rows). Linux executes those
native sweeps. Other link/native guards and Windows unsupported-policy assertions remain
separately documented; the source guard inventory is a branch-site list, not a count of
executed scenarios. Local overlayfs/WSL2 and NTFS results are not physical/controller
power-loss or real bounded-volume ENOSPC qualification.

## 2. API and Boundary Review

| Area | Review result / remaining boundary |
|------|------------------------------------|
| Existing public Storage surface | 95 reflected type/member/enum entries match the pinned local immutable-epoch reader baseline; no additions/removals |
| PA1 mutable facade | Internal, explicit policy/recovery/optional expected identity, independent children, preserved failures; not public consumer qualification |
| PA2 administration | Separate sealed proof and separate-root publication; acknowledged receipts only, failed calls may have published |
| PA3 observation | Read-only existing handles and strict initial-history/artifact correlation; no recovery, automatic retry or routing |
| HC1 restart classification | Supplied assertions only; every classification keeps writers stopped; no durable host authority |
| CA1/CA2 | Local binary rejection and ownership/holder lifetime evidence; not actual archived release or old-reader absence proof |

[API metadata manifest](m2-public-storage-api-review.json) includes the exact compared entries
and binary hashes. Reflection comparison covers type/member signatures and enum constants;
it does not independently approve nullability, optional parameter defaults, semantic/API
compatibility, XML documentation or a public release. The baseline has pinned local bytes
but no archived release provenance. No frozen DLL was rebuilt or replaced.

## 3. Findings and Corrections

| ID | Finding | Disposition |
|----|---------|-------------|
| AR-001 | Malformed HC1 context with null candidate identity dereferences instead of classifying invalid evidence | Fixed with a null guard and a regression case; 80 classifier cases validate final source |
| AR-002 | Linux documentation resolver cannot inspect hidden dotfiles with ordinary Get-Item | Local helper now uses -Force; actual hidden file/directory/root and link/traversal tests run on both hosts |
| AR-003 | Windows Git CRLF checkout changes README bytes relative to LF governed FYTALA statement | README text eol=lf rule added before final governed block; Git checkout simulation preserves exact statement |
| AR-004 | Lost first administrative acknowledgment leaves caller without a preknown request operation ID | Open public-API design prerequisite; artifact match must not become request ownership or idempotency |

AR-001 hardens malformed internal input; it does not add a host/deserialization contract.
AR-002 changes only the local helper; governed kit files, kit hashes/version and generation
provenance remain unchanged. A new portable helper regression script is included in the CI
hygiene step. Actual Linux checks use a separate PowerShell container with source read-only
and no container network; the SDK test runner isolation remains unchanged.

AR-004 requires a request-to-publication operation correlation contract before public
administration exposure. Current pipelines allocate operation IDs internally. A future design
must decide how a caller knows an attempt ID before possible publication, binds it to artifact,
role and destination, and distinguishes correlation from exactly-once/idempotent execution.
This review does not invent a durable journal, accept caller IDs or change frozen codecs.

## 4. Local and Remote CI Evidence

The [latest pushed CA1 run](https://github.com/Fytala-Charles/Bosak.XmlDb/actions/runs/40651032546)
for b1f2c0b failed Documentation hygiene on both hosts: Linux hidden marker inspection and
Windows canonical FYTALA bytes. Its Restore/Build/Test/Formatting steps succeeded. That run
contains older committed source and does not qualify the current working tree.

Both faults are corrected locally. Windows and actual Linux PowerShell portability checks
exercise hidden paths plus real junction/symlink rejection. Full strict documentation checks
and formatting are recorded with the final review. No remote rerun, new commit or push is
performed here, so no green current-source hosted CI result is claimed. Initial and CA1
commits remain the only pushed project commits; later prototypes/review are local.

## 5. Release Gates and Next Work

Public surface/signature/diagnostic review and external consumer tests remain open. Facades
currently return internal epoch/receipt DTOs through friend assemblies; a public API needs
an explicit DTO/visibility contract rather than blanket promotion of internal authority types. HA1/HA2
need an actual consuming host, comprehensive external writer exclusion, durable accepted-work
accounting, authoritative route revisions and conditional-update/restart fault qualification.
C1 still needs actual archived release binaries/provenance; local reader captures are not
substitutes. Production filesystem/controller, physical power-loss and real ENOSPC evidence
remain separate. Proprietary licensing, Bosak 1.26.2 pins and disabled packaging are fixed.
No source replacement, history reclamation, retirement or write resume is enabled.

Next bounded work: define request-to-publication operation identity/correlation before
implementing public administrative diagnostics. Bind a known attempt to the requested
artifact, role and destination, including lost-acknowledgment and retry rules, while keeping
IDs/receipts distinct from routing authority, authentic provenance and idempotency promises.


AR-004 design follow-up (2026-10-28): [ADR-020](../ADR-020-planned-administrative-attempt-correlation.md)
and the [attempt contract](M2_ADMINISTRATIVE_ATTEMPT_CONTRACT.md) define preknown library-created
IDs, single-dispatch plans and reconciliation/new-ID retry rules. Implementation is still
open: RC1-RC3. This records the design direction without relabeling prior runtime evidence.
