# M2 Process-Crash Validation

## 1. Tested Environment

2026-10-26, Windows 10.0.26300 x64, .NET SDK 10.0.301/runtime 10.0.11, Release.
The integration suite starts independent dotnet processes and kills the probe's own
OS process at an internal checkpoint. Probe termination bypasses managed disposal
and finally blocks. Each test then starts new recovery/read processes twice.
No system power interruption, filesystem-specific durability certification or Linux
execution is claimed.

## 2. Writer Crash Matrix

| Checkpoint | Required recovery |
|------------|-------------------|
| StageCreated | Old state, sequence 0 |
| FragmentsFlushed | Old state, sequence 0 |
| DirectoryFlushed | Old state, sequence 0 |
| ManifestFlushed | Old state, sequence 0 |
| BeforeWal | Old state, sequence 0 |
| WalPrefixWritten | Old state; discard incomplete final append |
| WalWritten, before explicit flush | Complete old or complete new state |
| WalFlushed | New state, sequence 1 |
| GenerationPublished | New state, sequence 1 |
| RootTemporaryFlushed | New state, sequence 1 |
| RootPublished | New state, sequence 1 |
| Commit returned, immediately killed | Acknowledged new state, sequence 1 |

For each recovered state, XPath must return the corresponding complete header
(SO-1 or SO-2), all twenty original lines, and zero line payload fragment reads for
header/count queries. A second process must see the identical recovered sequence.

## 3. Interrupted Recovery

A writer is first killed at WalFlushed, leaving committed redo without a published
generation. A recovery process is then killed at each of StageCreated,
FragmentsFlushed, DirectoryFlushed, ManifestFlushed, GenerationPublished,
RootTemporaryFlushed and RootPublished. Subsequent processes must reconstruct/select
sequence 1 repeatedly. A separate cross-process lease test kills the owner and
verifies a new coordinator can acquire ownership and recover.

## 4. Other Evidence

Storage tests cover rollback, stale conflicts, same-snapshot data retention, stable
IDs/topology, ordinary/empty attributes, Unicode text, rejected empty-text removal, invalid XML/oversized edits,
unsupported kinds, disposal, faulted-owner behavior, complete corruption, truncated
acknowledged logs, incomplete non-final logs, broken chains, wrong control identity,
semantic redo corruption and deterministic replay of missing generations.

The initial scalar slice passed 90 tests (42 Storage, 27 Xdm, 21 Integration), zero failures
or skips. This includes the previous M1 checks. Detailed local TRX files are emitted
under the ignored .tools/m2-test-results directory by:

```sh
dotnet test Bosak.XmlDb.slnx -c Release --no-build --logger "trx;LogFilePrefix=m2" --results-directory .tools/m2-test-results
```

These are deterministic checkpoint tests, not exhaustive torn-sector/disk-full testing.
The subsequent [filesystem fault gate](M2_FILESYSTEM_FAULT_VALIDATION.md) adds 333 injected before/after/partial-write positions and brings the complete suite to 110 passing tests. Native Linux/physical filesystem/power-loss testing remains open.

*Last updated: 2026-10-26*
