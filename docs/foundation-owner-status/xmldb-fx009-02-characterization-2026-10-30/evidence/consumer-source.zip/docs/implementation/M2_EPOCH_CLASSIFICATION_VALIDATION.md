# M2 Internal ET7 Adversarial Recovery Classification

Date: 2026-10-27. Qualifies the recovery behavior specified by
[ADR-012](../ADR-012-mutable-epoch-feature-and-recovery-contract.md) and implemented by
[ADR-016](../ADR-016-internal-epoch-redo-and-publication-faults.md).
This step adds tests and internal process probes; storage-engine behavior, wire formats,
public APIs, pinned package versions, proprietary license and frozen reader bytes are unchanged.

## Classification matrix

Each of 43 invalid scenarios runs with a complete history and with generation one missing:
86 cases, with two rejected opens each. Every attempt asserts InvalidDataException or
NotSupportedException, identical file bytes/path inventory and directory inventory, no
CreateFile/WriteFile/CreateDirectory/MoveFile/MoveDirectory/DeleteFile/DeleteDirectory
through the persistence seam, and released admission. Existing writer.lock is present
before corruption. Runtime file synchronization is not counted as a content mutation.

| Family | Scenarios | Required result |
|--------|-----------|-----------------|
| Foreign epoch | BASE, CONTROL, WAL, CURRENT, GENERATION, stable reader | Reject expected-binding mismatch |
| Wrong role | WAL, GENERATION, CURRENT, stable reader | Reject role/framing mismatch |
| Chain | Wrong base/FORMAT binding, sequence, predecessor WAL/manifest, duplicate transaction ID, missing middle/final WAL | Reject; never substitute a generation witness for a WAL |
| Publication | Torn final WAL with published witnesses, reader beyond head, wrong/ahead CURRENT, wrong generation digest/sequence/predecessor | Reject and preserve evidence |
| Required data | Corrupt generation directory or fragment | Reject without overwriting a published generation |
| Unknown state | WAL/generation/reader names, unknown transaction authority | Reject before recovery writes |
| Invalid operation | Element target, empty text replacement | Reject unsupported logical operation |
| Resealed semantics | Changed WAL value with matching generation/CURRENT WAL digests; changed manifest URI with all affected digests resealed | Reject logical projection/metadata mismatch despite valid checksums |
| Incomplete framing | Foreign torn record, unsupported version, trailing bytes, unwitnessed torn binding/role/sequence mismatch | Reject; physical shortness alone never authorizes removal |

The last three unwitnessed-tail cases remove the generation/head-reader witness and set a
valid earlier CURRENT. Their rejection therefore exercises available binding/role/sequence
validation rather than relying on another publication witness. The prior ET6 suite retains
all supported-truncation and safe-tail-removal tests.

## Recoverable states and repeated interruption

Four Storage cases combine absent/valid-prefix CURRENT with all three generations missing
or an already-published third generation. Recovery twice selects the exact head, restores
byte-identical materializations/retained authority and reader identities, and retains bad
private stage/current/reader temporaries without adopting or deleting them.

Four process cases repeat kills after successive generation publications for three-record
histories. They exercise complete missing history and retained later witnesses, updates to
both header and line values, and an old uncached snapshot held after its coordinator closes.
Recovered files match the original full history exactly; pinned old values, node count and
URI remain intact. Two cases use native Linux FileAndDirectoryFlush; on Windows these two
branches return without claiming native directory barriers. No skips are reported by xUnit.

## Final evidence

| Platform | Storage | Xdm | Integration | Total | Failed / skipped |
|----------|---------|-----|-------------|-------|------------------|
| Windows | 338 | 27 | 112 | 477 | 0 / 0 |
| Ubuntu 24.04 / Docker overlayfs | 338 | 27 | 112 | 477 | 0 / 0 |

Ninety-four new cases: 90 Storage and four Integration. Existing 66 fault sweeps retain
2,162 Windows / 2,098 Linux positions (ET6: 852 / 836); this step adds adversarial state
coverage, not a new I/O-position sweep. SDK10.0.301, Windows runtime10.0.11 and Linux
runtime10.0.9. The pinned isolated Linux runner uses read-only source/cache and no network.
Formatting and strict documentation checks pass. Seven known MINVER1001 warnings remain
because the checkout has no commit. Exploratory valid-redo assertions initially attempted
to inspect an exclusively held writer.lock; verification now occurs after coordinator close.

Final TRX: .tools/et7-windows-results and .tools/et7-linux-results.
[Structured evidence](m2-epoch-classification-results.json) records cases and provenance.
Prior ET6 validation remains historical. Frozen format-1 and immutable epoch readers are
unchanged and remain part of the full suites.

## Reproduce

```powershell
dotnet test Bosak.XmlDb.slnx -c Release --no-restore --logger 'trx;LogFilePrefix=windows' --results-directory .tools/et7-windows-results
$env:DOTNET_ROLL_FORWARD = 'Major'
& ./.tools/pwsh.exe -NoProfile -File tools/test-linux.ps1 -ResultsDirectory .tools/et7-linux-results
dotnet format Bosak.XmlDb.slnx --no-restore --verify-no-changes
& ./.tools/pwsh.exe -NoProfile -File tools/check-docs.ps1 -ProjectPath . -Strict
```

## Limits and next work

This is bounded recovery classification evidence, not proof against arbitrary simultaneous
loss of every WAL/publication witness or malicious concurrent filesystem mutation. Full
history validation remains expensive and private failure stages are retained. ET8 broader
platform/durability qualification is next; ET9 epoch backup/history migration, public mutable
APIs, full archived-reader C1-C3 and retirement remain pending. No committed-history deletion
or WAL-prefix truncation is enabled. Native overlayfs runs do not certify physical power
loss, real ENOSPC, production controllers/filesystems or remote CI.
