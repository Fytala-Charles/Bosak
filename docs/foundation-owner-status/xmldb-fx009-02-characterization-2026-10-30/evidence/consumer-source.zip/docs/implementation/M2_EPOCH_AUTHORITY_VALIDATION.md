# M2 Epoch Profile and Authority Codec Validation

Date: 2026-10-27. Scope: [ADR-013](../ADR-013-epoch-profile-and-authority-codecs.md), ET1-ET3.
**291 tests pass on Windows and 291 on Linux**, zero failures/skips in either full run:
182 Storage, 27 Xdm and 82 Integration. SDK 10.0.301; Windows runtime 10.0.11, Ubuntu
24.04 runtime 10.0.9 / Docker overlayfs. Existing seven MINVER1001 warnings per build
remain. Formatting verification and strict FYTALA checks pass.

[Structured evidence](m2-epoch-authority-results.json) preserves both frozen manifests,
actual per-suite counters, platform and existing persistence sweeps (1,228 Windows /
1,188 Linux positions across 36 cases). No new mutable-write durability claim is made.
Current TRX: .tools/epoch-authority-windows-results and .tools/epoch-authority-linux-results.

## Implemented Evidence

- Twenty-nine Storage cases cover exact 2.0/2.1 tuples, immutable default capability
  rejection, independent profile/role golden files, every record truncation, invalid
  checksum/version/trailing bytes, resealed role/body substitution, foreign store/epoch/
  document/profile/base, XML/UTF-8/value bounds, canonical BASE binding and file names.
- Twelve Integration cases cover frozen format-1 and immutable-epoch reader rejection
  on root/private generation paths, plus current public entry points with an occupied
  stable admission lease proving rejection before acquisition. All persistent bytes
  remain unchanged. Raw readers may reject the existing transaction marker first;
  private-generation tests exercise direct format rejection without that marker.

Both frozen readers are loaded by subprocess probes in isolated AssemblyLoadContexts,
with pinned Storage/Core SHA-256 before reflection. The new immutable Storage hash is
3dcc349ecdf97053f46e5df69f42dd519c7c00f4c22d22e89ac62538e1ff818b;
Core remains 60a9af0eed267cb20d55ffb507ed3ae2c5102a5c18c0151d45e99b701e590804.
It was captured before any profile parser changes. The older format-1 fixture is
unchanged. Both are local uncommitted baseline captures, not archived pre-lease releases.

All existing format/read-only/transaction/backup/fault/process tests remain in the full
suite. No new persistence fault scenario is claimed for these pure codecs; ET4-ET9
mutable ownership/commit/recovery/backup/migration remain unimplemented, as do complete
C1-C3 and retirement. Existing physical power-loss/ENOSPC limits remain unchanged.

## Reproduction

```powershell
dotnet build Bosak.XmlDb.slnx -c Release --no-restore
dotnet test Bosak.XmlDb.slnx -c Release --no-build --logger 'trx;LogFilePrefix=epoch-authority' --results-directory .tools/epoch-authority-windows-results
pwsh tools/test-linux.ps1 -ResultsDirectory .tools/epoch-authority-linux-results
```

Linux uses pinned SDK 10.0.301 in an isolated no-network container with read-only source/
package-cache mounts. No source history, frozen fixture or existing versioned byte
encoding is overwritten. No public mutable API, remote CI, release or migration occurs.

*Last updated: 2026-10-27*
