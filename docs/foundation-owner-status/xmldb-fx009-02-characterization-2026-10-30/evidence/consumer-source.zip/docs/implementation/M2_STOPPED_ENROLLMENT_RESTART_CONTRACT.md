# ER-004 Stopped Enrollment Restart and Owner Handoff Contract

Date: 2026-10-30. Design only under [ADR-034](../ADR-034-stopped-enrollment-restart-and-owner-handoff.md).
Implements the design gate from the [readiness review](M2_ENROLLMENT_READINESS_REVIEW.md).
[Review and evidence](M2_STOPPED_ENROLLMENT_RESTART_REVIEW.md) separate existing execution
results from proposed behavior. All names and assessment states below are internal proposals.
No restart classifier, handoff capability or additional authority writer is implemented here.

## 1. Controlled Scope and Three Distinct Facts

Continue the one-process, cooperative internal pilot, ProcessCrash only. The host must stop
all ingress, writers, executors and publishers before opening for reconciliation. Library
ownership does not establish those external facts or fence an old binary. Missing ownership,
unknown prior work or uncertain deployment freshness keeps every application admission stopped.

A complete journal proves a structurally valid retained history under configured identities.
It does not prove the latest globally existing history, an earlier returned acknowledgment,
actual source exclusion or permission to dispatch. A new live owner needs actual acquired
registrations and fresh verification. Neither an old receipt nor an assessment reconstructs them.

The original source owner's armed stop latch is permanent for that object. Releasing leases,
reopening the authority or recording a future TransferOwner must never clear it. A separately
opened source owner has no inherited persistent fence: acquire and retain its own real mutation
and publisher exclusion before reading its baseline. An acquired authority lock proves neither
source ownership nor absence of pre-lease readers. CanReclaim remains false.

## 2. Stopped Acquisition and Observation

Use trusted configured deployment/resource keys, administrative/authority IDs and protected
root mappings. Do not discover replacements, provision a new empty authority to reset state,
or infer identity from path spelling alone. Acquire administrative ownership and its actual
application child before the authority owner. Hold both through full inspection and actual
drain. Existing OpenExisting/Inspect remain read-only with respect to persistent content;
roles may require read/write handles for ownership without authorizing content mutation.

Check strict directory/role closure, native identities, exact metadata, complete bounded
administrative and application histories, exact EOF and unchanged acquisition head. Reject
partial/torn tails, extra bytes, unknown transitions, missing/replaced roles and corruption.
Never scan to a plausible prefix, repair, truncate, overwrite or adopt a changed head. Preserve
bytes and inventory. Acquisition/release failures follow existing lifetime drain semantics;
no automatic close retry or clearing a retained parent registration after unknown release.

Complete source and sealed capture verification runs outside authority serialization. Retain
actual source exclusion and actual parent/authority operation registrations across that gap.
Then recheck the exact observed authority/admin positions and role identities. A changed input
invalidates the whole assessment, even if its new history is independently valid. Reopening
explicitly for a new observation is a new stopped workflow, not an in-place head update.

## 3. Bounded Assessment and Decision Table

The first implementation, SR1, will be a pure classifier of supplied observations. It performs
no filesystem I/O, callbacks, ownership acquisition, replay or writes. Inputs describe explicit
validation outcomes, exact head/owner/baseline pins, supported history shape, source/capture
correlation and fresh host reconciliation assertions. Unknown is represented explicitly;
default/absent facts never count as successful verification. A caller-supplied claim is not
independent verification. SR2 must later bind observations to actual retained handles.

Every result carries WritersMustRemainStopped=true and grants no initializer, receipt,
ConfirmedEnrollment, transfer capability, routing, work acceptance or data execution. Suggested
result names are Refused, ReconciliationRequired and ObservedEnrolledStopped. A reason code
explains the result; no result is a Boolean write permission.

| Observation | Required assessment and consequence |
|---|---|
| Invalid arguments or internally contradictory observations | Refused; no side effect or adopted state |
| Invalid identity, namespace, chain, bounds, tail or changed expected head | Refused; preserve all state, no prefix result |
| Missing/unavailable observation, unknown prior executor/work, freshness or release | ReconciliationRequired; absence is not zero work or known release |
| Valid empty reopened authority | ReconciliationRequired; no initializer recreation or Enroll retry |
| Valid exact single Enroll, but source/capture/host facts missing or mismatched | ReconciliationRequired; bytes alone cannot establish the controlled baseline |
| Exact single Enroll, matching baseline/source/capture, retained head pins and supplied fresh stopped scope facts | ObservedEnrolledStopped; still no historical acknowledgment or write authority |
| Structurally valid history containing any later event | ReconciliationRequired for this first slice; full codec validation does not enable a broader runtime |
| Observed complete frame after publication/ACK loss | Same stopped classification as any exact frame; never synthesize a receipt or replay the old plan |
| Owner generation exhausted or proposed successor repeats current owner | Refused handoff proposal; never wrap generation or reuse the current session |

Structural rejection takes precedence over missing operational facts; contradictions must not
be hidden by a successful-looking field. Valid but unsupported history is distinct from corrupt
history. Administrative pending/uncertain publications, unexpected newer source data or capture
mismatch require explicit reconciliation; no automatic migration, rollback or recapture is allowed.
The single-Enroll slice expects source document/H/history to equal the retained enrollment
binding. It does not generalize initial H equality to later histories containing accepted work.

## 4. Evidence and Freshness Binding

An observation dossier binds configured scope/IDs; administrative and authority sequence/digest;
authority metadata digest; last owner session/generation; immutable baseline; selection
revision/branch; exact source binding and capture inventory commitment; and each supplied host
fact with its scope. Legacy source identity has no StoreId/EpochId. Preserve the established
history commitment definition and exclude runtime lock files. No new record or hash algorithm
is frozen by this design. Evidence commitments are references, not signatures or authenticated truth.

Evidence is point-in-time and descriptive. A serialized dossier can support manual reconciliation
but cannot be deserialized into a live plan. A future SR2 owner-bound observation must be
thread/object/session confined, single-use for a particular action, and invalidated by closing,
fault, changed bytes/identities, changed host scope or loss of exclusion. SR1 supplies none of
those ownership guarantees. Recheck freshness at consumption, not only preparation.

## 5. Proposed Handoff Boundary

Handoff is a future explicit stopped operation. It is not Dispose/OpenExisting and is not
implicit recovery of an uncertain first append. Before a handoff writer is implemented:

1. Acquire fresh real parent/authority ownership and source exclusion with admission stopped.
   Verify the complete histories and controlled scope, retaining all registrations through
   preparation, dispatch, append and cleanup. Reconcile any prior executor or publication.
2. Bind an owner-only opaque plan to exact configured IDs, metadata/admin/authority heads,
   baseline, owner and selection, source/capture facts and retained handles. Descriptors and
   receipts cannot create the plan. Revalidate outside serialization, then compare exact
   authority state inside it. Closing before atomic claim refuses without output.
3. Choose a fresh distinct successor session, checked previous generation + 1 and evidence
   commitment. Use only existing v1 TransferOwner fields, preserving baseline, selection,
   source/candidate bindings and every work record. For an initial bounded writer require
   exactly one Enroll and no later events. Broader histories need separate reconciliation.
4. Append only after a separately reviewed implementation establishes actual lifetime and
   serializer behavior. It must mark possible output before delegation, flush, exact-readback
   and validate the complete resulting chain before returning a new stopped acknowledgment.
   No source/capture I/O or host callback runs under journal/lifetime serialization.
5. Both a qualified return and any possible-output failure terminate that writer session
   stopped. On uncertainty preserve bytes, suppress acknowledgment, retain real operations
   until drain and never retry the same plan or infer release. Before-output refusal also
   grants no source resume or replacement workflow. A later workflow needs a new assessment.

Even a future acknowledged TransferOwner changes only the recorded logical owner. It proves
neither a durable source fence nor selection acknowledgment, work admission, actual routing or
permission to mutate data. Old sessions/capabilities remain unusable. Future use of the new owner
requires separately qualified operations. No source handle is transferred by serializing its ID.
An in-process release failure cannot be overridden merely because a new exclusive open succeeds;
physical availability does not resolve the original logical uncertainty. After process death,
new ownership still requires independent stopped reconciliation and fresh exclusion.

## 6. Implementation and Acceptance Gates

| Step | Scope and required qualification |
|---|---|
| SR1 next | Pure internal stopped assessment; deterministic reason precedence; happy exact-Enroll path and each missing/invalid/unsupported/contradictory edge; all results stopped and no capabilities; no I/O/callbacks |
| SR2 later | Actual paired-owner/source-bound observation, complete verification and freshness rechecks; source exclusion across unlocked inspection; disposal/identity/head races; source/capture/admin bytes and inventory preserved |
| SR3 later | Separate owner-bound one-shot handoff preparation/atomic claim; no output; wrong thread/object/owner, closing and stale-plan rejection |
| SR4 later | Separately reviewed conditional TransferOwner append; every observed I/O/partial-write fault, release before/after/no-op, exact acknowledged frame, ACK loss and process/competing-owner qualification |

SR1 inputs must include a supported-history discriminator rather than deriving an enrolled
permission from a nonempty log. Tests must distinguish zero work recorded from unknown prior
work, source mismatch from corrupted authority, complete-but-unacknowledged output from an
actual returned receipt, and invalid history from unsupported valid history. SR2-SR4 require
Windows/Linux accounting with host guards separate from actual native execution. Full-history
codec TransferOwner vectors already exist; they are byte/transition evidence, not live handoff.

Public release, actual consuming-host facts, archived release provenance, persistent fencing,
work execution, candidate registration/selection writers, physical power-loss/real ENOSPC and
all source replacement/retirement/reclamation remain separate gates. Retain every history.

SR1 follow-up (2026-10-30): [pure classifier and qualification](M2_ENROLLMENT_RESTART_CLASSIFIER_VALIDATION.md)
implement supplied-observation classification only. Original design-step evidence remains
historical. No actual owner-bound observation or handoff capability is implemented; next SR2.

SR2 design follow-up (2026-10-30): [owned observation design](M2_OWNED_RESTART_OBSERVATION_DESIGN.md)
requires a separate restart-only source child and actual paired observation, without fabricating
old capture associations or hiding live recovery. Next SR2-A; SR2 runtime remains unimplemented.

Readiness follow-up (2026-10-30): [consolidated SR1/SR2 review](M2_STOPPED_RESTART_READINESS_REVIEW.md)
verifies retained input/catalog evidence and separates current observation from future success-only
proof consumption and plan-child retention. Next SR3-A contract; no new writer is enabled.


SR3-A design follow-up (2026-10-30): [preparation/lifetime contract](M2_STOPPED_HANDOFF_PREPARATION_CONTRACT.md)
resolves RR-002/003/004 at the design level only. Private proof, actual child drain and
paired-parent successor binding are specified, not implemented. Next SR3-B1 adds proof/lifetime
primitives; preparation/claim and SR4 output remain later gates. Original execution evidence
and all host/public/archive/fencing/retirement limitations remain unchanged.
