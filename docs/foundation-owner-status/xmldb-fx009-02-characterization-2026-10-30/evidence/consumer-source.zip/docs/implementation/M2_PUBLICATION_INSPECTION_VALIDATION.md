# PA3 Read-Only Publication Inspection

Date: 2026-10-28. Internal observation under
[ADR-019](../ADR-019-explicit-mutable-api-and-host-cutover-boundary.md). This is not a
publication acknowledgment, recovery operation, host observation or routing decision.

## 1. Request and Observation

EpochPublicationInspector accepts the publication role, sealed artifact path, requested
bundle path, pinned original inventory SHA-256 and optional previously known operation ID
and destination epoch identity. Administrative InspectPublication delegates to it without
using the injected storage seam. Arguments and disjoint paths are checked explicitly.

| Status | Meaning |
|--------|---------|
| NotObserved | No bundle at the requested path at this instant; not proof publication never occurred |
| ArtifactMatched | Exact initial candidate history/provenance correlates with the pinned artifact, but the request operation ID is unknown |
| KnownOperationMatched | The same correlation also matches the caller's supplied operation ID |
| ReconciliationRequired | Changed, incomplete, foreign, unsupported or invalid input/candidate; no recovery or cleanup attempted |
| Unavailable | I/O/access prevents observation; cause is not asserted to be contention or corruption |

Every observation has WritersMustRemainStopped=true. Observed publication metadata uses a
separate type from PA2's acknowledged receipt. A matching optional destination does not
turn an unknown operation ID into a known one. IDs, checksums and artifact hashes are
correlation, not authenticated provenance; a resealed changed operation ID can still produce
ArtifactMatched for a caller who did not already know the request's ID.

## 2. Read-Only Validation and Lifetime

The inspector validates the sealed artifact against the caller's pinned inventory, checks
exact two-role bundle layout and unchanged-profile provenance header context, then acquires
existing shared ScalarWal admission and a read-only FileMode.Open handle on the existing
writer.lock with read sharing. A cooperating writer owning that file prevents inspection;
the probe prevents a new cooperating writer while held. Both handles release on every exit.
It does not create missing admission/writer/reader identities or acquire a coordinator.

Bounded unlinked traversal precedes authority/runtime enumeration. Candidate validation
requires exact initial reader set, empty staging/no temporary CURRENT, exact document data
bytes from the artifact, mapped WAL operations and predecessor digests, generation FORMAT/
witnesses, current authority and strict every-transition epoch history. Legacy history is
also preflighted directly; epoch source chain/witnesses are checked against exact mapped
candidate history. Original inventory, artifact closure/content and sidecar are rechecked
before matching observation return. Advanced candidates are reconciled, not treated as
initial publications or rolled back. Partial WAL/missing generations are never repaired.

This operation uses no ITransactionStorage mutation/barrier, coordinator Open, private
verification clone, directory creation, namespace publication, cleanup or native fsync.
It validates complete history and byte correspondence, not independent full-redo reproduction.
PA2 and earlier two-oracle publication qualification remain separate; inspection is not a
replacement verifier or a reusable capability. Changes can occur after the observation.

The read-only writer probe excludes cooperating local owners, not old/uncooperative
applications or external namespace replacement. Shared admission protects current-runtime
lifetime, not proof of old-reader absence. No globally atomic filesystem snapshot, actual
route observation, accepted-work accounting, external writer fence or authentication is
provided. A missing parent/required internal file can conservatively reconcile instead of
being classified as a clean absent publication.

## 3. Validation

43 new friend-consumer cases cover H0/H3 migration/restore with known and unknown operation
IDs; two lost publication acknowledgments; 26 incomplete/changed/foreign cases; active
owners and handle release; resealed operation identity limits; absent bundle; invalid
request arguments; and actual Linux link rejection. Windows's link case returns without
executing the Linux boundary and is not counted as actual link qualification there.

Candidate damage includes missing generation/reader/writer, corrupt provenance, extra
bundle roles, staging, advancement, changed fragment, wrong inventory/operation/destination,
partial WAL and coherently resealed destination transaction substitution. The latter remains
a valid-looking candidate chain but must fail exact artifact operation mapping.

Byte/file/directory inventory snapshots prove no mutations. Successful cases compare physical
runtime identities and use storage that throws on any mutation/barrier, asserting zero calls.
[Results](m2-publication-inspection-results.json) record the final cross-platform focused
runs. A final inspector-only batch covers the namespace-bound guard added during review
and replaces earlier inspector rows in aggregate counts. No test is double counted.
The catalog is 1,050; no new unfiltered full run or expensive fault-matrix rerun is claimed.
Four frozen DLL hashes, public signatures and wire formats remain fixed. Formatting and
strict documentation checks are required before handover.

## 4. Remaining Gates and Next Work

PA3 remains internal, with no production routing, write resume, source replacement, public
API or reclamation. All history and stable identities remain retained, CanReclaim=false.
Public signature/diagnostic review, actual host/external writer exclusion/restart proof,
archived release compatibility and physical/controller durability remain open.

Next: consolidated cross-platform regression and API/readiness review across PA1-PA3,
HC1 and CA1-CA2 before further API work. Keep actual execution, retained matrix evidence,
platform-only branches and external host/archive prerequisites distinct; do not declare
M2 shipping complete from local prototype counts.
