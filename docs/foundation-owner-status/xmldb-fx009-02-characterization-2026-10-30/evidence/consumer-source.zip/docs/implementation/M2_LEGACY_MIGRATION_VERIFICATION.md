# MG2 Strict Legacy History Verification

Date: 2026-10-27. Internal LegacyMigrationVerifier implements the legacy verification gate
of [ADR-018](../ADR-018-full-history-legacy-migration-and-cutover.md), before migration
conversion. Source formats, backup bytes, MG1 BXEM and public APIs are unchanged.

## 1. Entry point and scope

Verify accepts a sealed BXBI/BXBC artifact, an absent destination used only to place an
owned sibling workspace, optional storage policy and internal checkpoints. It returns the
verified legacy inventory. It never publishes that destination, creates an epoch, writes
migration.bin, returns a migrated StorePath, routes an application or opens a live source.
The caller chooses a workspace placement outside any live roots it owns; metadata contains
no source path and the verifier cannot infer an unknown original root from a backup.

The artifact must have exact supported full-history closure, canonical file names, complete
base data, CONTROL, every WAL/generation 1..H and CURRENT at H>0. H0 omits CURRENT entirely.
Inventory decoding reuses MG1's remaining-byte/count/path bounds. Exact tree traversal is
bounded to 400,000 entries/depth64 and rejects links, case substitutions, unexpected files
and unrelated empty directories before materialization reads. Match all declared lengths/
SHA-256 and the canonical file set; verify the exact inventory/completion binding.
ReadArtifact alone checks seal/closure/file commitments, not logical history capability.

## 2. Strict preflight before writes

Verify checks all history read-only before invoking any storage write/barrier or allocating
a workspace. Require exact legacy FORMAT flags at the base and byte-identical FORMAT in
every generation. Validate CONTROL's document/zero/base binding and every materialization's
manifest, directory, referenced fragments and readable values. Require canonical contiguous
WAL 1..H, nonempty unique transaction IDs, correct document/sequence/predecessor hashes and
supported scalar operations. A partial artifact WAL is corruption; never discard a tail.

For every sequence, compare the prior/current snapshots' node counts, document URI, all
node metadata and structural lists, and every scalar value. Only the declared target's
replacement may differ; repacked value offsets/lengths may change. Reuse the profile-neutral
transition comparison from EpochScalarHistory without widening epoch admission. Finally
require exact captured head and byte-canonical CURRENT at H>0; no stale-prefix promotion.

Missing/corrupt present generations, hidden second edits, wrong control/head/format,
unsupported operations, duplicate transaction IDs or missing closure fail before writes.
The source root is not an argument and is never recovered. Sealed input is never opened
as a coordinator, and no source lock/admission identity is copied.

## 3. Two independent private oracles

Create a fresh nonce workspace through the storage seam only after strict preflight.
The existing exact-tree and contained clone cleanup helpers are reused with their existing
nonce/child-name guards; no cleanup scan or broader deletion permission was added.

1. Complete clone: copy all declared files, compare copy commitments and re-run strict
   preflight before FullJournal Open. Require exact H and zero replay/publication of any
   generation. Only legacy Open's normal RootTemporaryFlushed/RootPublished callbacks are
   allowed. Its positive-H CURRENT republication must be byte-identical to the inventory;
   H0 stays without CURRENT. Fresh runtime reader/writer/staging state is private only.
2. Redo clone: copy base/CONTROL/CURRENT/WAL but no positive generations. Verify copied
   commitments before Open, then require exactly H replayed and published generations under
   FullJournal, with no checkpoint shortcut. Compare every regenerated declared file,
   including FORMAT, manifest, directory, fragments, WAL and CURRENT, against original
   lengths/SHA-256. Re-run the strict every-sequence logical validator after replay.

All clone owners/snapshots are closed before contained clone removal. On success remove
both owned clones and the empty workspace. Recheck the original artifact and exact initial
inventory bytes before returning. On error, private debris may remain; handles close and a
fresh verification uses a new nonce. No abandoned workspace is adopted or cleaned on retry.

Checkpoints: PreflightVerified, CompleteCopied, CompleteVerified, RedoCopied, RedoVerified.
The final checkpoint is still before the final immutable-input recheck; it is not a
migration acknowledgment. Cooperative immutable artifacts are required; integrity checks
are not authentication or protection from malicious concurrent administrators.

## 4. Validation and next work

[Validation](M2_LEGACY_MIGRATION_VERIFICATION_VALIDATION.md) records H0/H1/H3, logical and
physical adversarial cases, interruption/retry, real partial redo writes, exact cleanup,
old uncached reader lifetime and native Linux policy execution.

Next MG3: convert verified legacy full history into fresh epoch authority, re-encode every
WAL binding/predecessor digest, verify destination complete/redo oracles, initialize fresh
runtime namespaces and atomically publish store/ plus external migration.bin. Preserve
all source data and every sequence. MG4 exhaustive qualification and MG5 cutover acceptance
remain later; public mutable/migration APIs and all retirement remain disabled.
