# Retained Source Exclusion and Conditional First-Enrollment Append

Date: 2026-10-29. Cross-stage contract under
[ADR-033](../ADR-033-retained-source-exclusion-and-first-enrollment.md).
EF1 source lifetime is now [implemented separately](M2_ENROLLMENT_SOURCE_RETENTION.md).
EF2 retained admission is [implemented separately](M2_RETAINED_ENROLLMENT_ADMISSION.md).
EF3 first enrollment is [implemented separately](M2_FIRST_ENROLLMENT_APPEND.md).
EF4 is [locally qualified](M2_FIRST_ENROLLMENT_FAULT_VALIDATION.md). Borrowed preparation stays read-only;
no application writer admission or public API is enabled.

## 1. Scope and Invariants

The first writer is legacy-source only, ProcessCrash only, and emits exactly one v1 Enroll
frame into the separate authority's existing empty log. Keep the three existing authority
roles, administrative roles, data-store formats, frozen vectors and every retained history.
Reject stronger authority durability without fallback. No source/checkpoint/WAL write,
coordinator open/recovery, import, capture, rename, directory creation or cleanup belongs to
this operation. Sealed capture must already be registered under the actual live source freeze.

The proof has two parts: strict real source/capture/native-identity validation, and supplied
scope-bound operational assertions. Retention does not verify ingress, prior-task inventory,
remote publishers, old binaries or pre-lease reader absence. All outcomes keep writers stopped.
A hash or an acknowledged enrollment records an observation; it is not work/routing admission.

## 2. Source Retention and Stop Latch

Proposed RetainedEnrollmentSource is an actual registered child of the existing source owner
and freeze, bound to their exact objects/token and registered capture. It is caller-thread
confined, bounded to one first-enrollment guard per freeze, and cannot be created from a DTO,
path, GUID, unlocked-file probe or native file ID. Acquire under the source gate only while
owner/freeze are live, healthy and non-closing, with the existing capture already registered.
Do not create a second capture or reopen source ownership.

The coordinator retains the original writer FileStream and the freeze's exclusion. A source
owner Dispose marks ordinary operations unavailable immediately, but defers calling that
stream's Dispose until real retained children finish. Freeze Dispose rejects new borrowing/
retention immediately, but cannot clear mutation exclusion while its child still needs it.
A native handle reference alone is insufficient: a disposed FileStream is not a usable
coordinator-owned stream. Sessions that never install the opt-in guard keep existing closing behavior. Once a
guard has armed, draining its last child does not clear the stop latch.

The source gate serializes registration, closing, arming and final release. An admitted child
uses a private retained inspection path, not a public owner method whose ordinary disposed
check must reject. It validates the actual registered armed child and retained stream before
reading frozen state/native identity. No source object is resurrected or reopened.

All cooperating data mutation paths, including transactions selected before freezing, remain
blocked. Audit commit, checkpoint, recovery-anchor and other namespace publishers. In this
opt-in mode also reject new CreateBackup/capture publishers while the guard is retained;
ordinary MG5 permits backup and must retain that behavior when no new guard exists. Existing
readers/snapshots remain independent; their leases never prove global reader absence.

Arming sets an owner-session stop latch distinct from a data-commit fault. It blocks mutations,
new freezes/retentions and new cooperating backup/publisher admission after the attempt, even
if the caller already disposed its freeze. Reads may continue on a live owner under existing
reader rules. No latch-clear or source-write-resume API is included. If source owner closes,
its original handle closes only after actual operations drain. A subsequent explicitly opened
owner does not inherit an in-memory latch: host-controlled exclusion is still mandatory.

If an original handle close cannot be confirmed, report release as unknown and retain faulted
logical ownership state. Never claim the physical handle is definitely held or released, retry
close/reopen ownership automatically, or use that uncertainty to authorize source mutation.

## 3. Preparation, Admission and Disposal Races

Proposed PrepareRetainedFirstEnrollment selects a distinct mode from PrepareFirstEnrollment.
Both consume the same original initializer's single-use privilege. Existing borrowed plans,
including unconsumed ones, cannot be upgraded: source exclusion may already have been lost.
Read-only CheckFirstEnrollment remains unchanged and can never be a writer's predecessor.

First reserve the actual authority/admin operation; then register source retention before
source inspection. Install a private retained-preparation slot under the authority lifetime.
Block new generic Inspect calls in this mode, require other actual inspections to have drained,
and reject conflicting modes rather than waiting under a gate. Preserve the exact prepared
baseline GUID, owner/selection tuple, source/capture fingerprints, evidence intent and admin
position. Validate the bounded candidate frame in memory before possible output.

AppendFirstEnrollment takes the actual retained preparation and fresh evidence equal to its
bound scope/reconciliation intent. Wrong-thread/foreign/forged/disposed/already-consumed plans
reject without consuming another valid plan. A real dispatch claims once before filesystem
I/O; timeout, cancellation or retry cannot make it executable again. Descriptions are inert.

The arm decision acquires only short state gates, in this fixed order:

1. Authority lifetime gate.
2. Actual parent's lifetime gate through a private typed admission method.
3. Source coordinator gate through its actual registered retained child.

Check every closing/fault flag, actual registration reference, expected admin position,
closed application/admin admission, absence of conflicting operations/publishers, and exact
source freeze/capture association. Register the executing child and latch source stopped
in the same decision. Perform no filesystem work, callbacks, serializer waits or user code.
Do not add a general delegate-under-parent-lock extension point.

| Ordered race | Required outcome |
|---|---|
| Authority or parent closes before arm | No write; reject new dispatch; drain pending registration safely |
| Source owner or freeze closes before arm | No write; no new child; retain existing handle/token until its pending guard drains |
| Arm wins before any close | Actual operation survives later closing; original source/authority/parent handles remain held |
| Permitted caller-thread plan disposal or external waiter cancellation | Mark caller-facing object closed; executing child keeps its own actual registration |
| An armed attempt is refused before output | No authority content write; source owner stop latch remains set |
| Last guard drains while an owner is closing | Release only after real I/O ends; propagate unknown release without claiming success |

Before arm, a no-write refusal may release an unarmed guard and honor an earlier explicit
freeze-release request; it does not publish enrollment or grant application admission. After
arm, no cleanup path may clear the source stop latch or resume writes. Idempotent plan disposal
must never decrement an executing child twice. Separate caller plan ownership from execution
ownership, preferably by moving the actual registration into the private executor at arm,
so disposing the plan cannot release its leases. Wrong-thread plan/freeze disposal still
rejects; this design does not remove caller-thread confinement or permit await across scopes.

## 4. Lock and I/O Phases

Never wait for the authority serializer while holding any lifecycle/source gate. Never acquire
a source gate or call data/capture validators while holding the authority serializer. No path
may acquire authority/parent lifecycle gates from a held source inspection gate.

| Phase | Locks and permitted activity |
|---|---|
| Reserve/arm | Brief authority -> parent -> source state gates; memory-only registration/flags |
| Verify source | Retained source inspection gate; exact data/capture/native checks; no authority/parent locks |
| Verify admin | Retained admitted parent path and its existing serializer; no source or authority serializer |
| Validate/write authority | Authority serializer only for authority roles/EOF/frame/write/flush/readback |
| Final state/release | Leave serializer first; report result and release children under their own lifetime gates |

Source exclusion spans the unlocked phases by actual registration, not a monitor. After arm,
private admitted-operation checks allow completion despite owner closing; ordinary RequireCurrent,
BeginRead and source public methods remain strict and must not be weakened globally. Tests must
prove absence of lock inversion and that no user callback or data inspection occurs in journal I/O.

## 5. Conditional Frame Publication

1. Claim/arm once. Revalidate real source against the exact registered immutable capture:
   complete closure/history, document/H/head, source root/admission identity, no unpublished
   staging/temporary state, exact original capture inventory and seal. Check capture commitment
   again at the end of inspection; sealed input must remain immutable under deployment control.
2. Revalidate actual administrative ownership/metadata/full history against the prepared position
   through the retained admitted path. Administrative mode exclusion remains active throughout.
3. Outside data gates, construct the complete existing-v1 frame in memory. Use the prepared
   library baseline ID, actual parent session, generation one, source revision one and exact
   prepared source/evidence. Validate whole history and size bounds; no arbitrary caller entry.
4. Acquire authority serializer and verify exact role set, regular/single-link native path/handle
   identities, metadata/configuration digest, expected empty length/EOF, sequence zero and zero
   predecessor. Expected authority/admin IDs and baseline/selection intent must match. Stale
   valid state may be reported as a no-write conflict; never adopt its head or update known state.
5. Set possible-output uncertainty before entering the write seam. Write exactly the frame at
   expected EOF on the retained log. No overwrite/truncate or append to a discovered other head.
   Use a narrowly internal retained-file append/flush seam analogous to the existing host seam;
   no public storage provider or callback is introduced. No raw write outside the audited seam.
6. Flush file content to disk. Require exact new length, metadata/native identities, exact full
   frame readback/checksum and independently decoded complete one-frame history/EOF. Source
   remains frozen by its admitted guard; no data I/O is performed inside this serializer.
7. Publish the confirmed in-memory receipt only after all required checks. Leave serializer,
   complete/transfer actual operation ownership and confirm cleanup status before returning a
   qualified acknowledgment. A close/release failure cannot be silently lost in a WhenReleased
   task while the append call reports an unqualified successful result.

Only ProcessCrash is proposed. Existing-file flush/readback is not physical power-loss proof;
no directory-fsync fallback or extra namespace publication is added. Test-only write/flush
instrumentation can inject real partial writes/process death, but is not a consumer callback
extension and may not reenter lifetime/source APIs under the serializer.

## 6. Results and Terminal State

| Result | Required facts | Permitted next action |
|---|---|---|
| RefusedBeforeWrite | No possible-output call entered; authentic plan consumed if dispatched | Inspect diagnostics/reconcile; no automatic retry or writer admission |
| AcknowledgedStopped | Exact frame flushed, complete history/readback verified, cleanup confirmed or legitimately retained by live owners | Observe receipt; all source/application writers remain stopped |
| Uncertain | Possible-output call entered and write/flush/readback/acknowledgment or required cleanup could not be confirmed | Poison session, retain bytes, require fresh stopped reconciliation |

No-write describes this authority append only, not global no-effect or proof of valid source
state. Corrupt input/identity changes can fault the session even before writing. Release-unknown
is reported separately and always requires reconciliation; it is never evidence that ownership
is absent. Mark uncertainty before a potentially output-capable hook/call, even if it later
claims no bytes were delegated. No automatic replay with the same or new baseline ID.

This first writer session is terminal after acknowledged enrollment as well as after possible
publication failure. Record a new confirmed receipt position separately from the immutable
acquisition snapshot; do not mutate the meaning of the existing History property or let
Inspect compare the new frame to the old empty digest. Block generic inspections in retained
pending/executing/terminal mode. After disposal, OpenExisting may inspect a valid complete frame
read-only and stays stopped. General post-enrollment append/selection/work needs a later gate.

Source stop latch persists in its original live owner after any armed result. Current supplied
operational flags and no-work observations never become durable work-admission capabilities.
No first-enrollment result invokes a data-store transaction, changes a route or accepts work.

## 7. Restart and Lost Acknowledgment

A killed process loses live plans, armed registrations and stop latches. Retain every surviving
role byte. A valid empty root cannot initialize again; a partial/torn/corrupt frame fails closed
without repair/truncation/prefix adoption; a complete one-frame log can be inspected but does
not prove its old caller received acknowledgment. Never replay its enrollment or reconstruct
execution authority from its baseline ID, receipt or metadata. Existing host restart rules and
fresh independently scoped reconciliation remain mandatory. No source reopen, source path
replacement, automatic rollback or cleanup is part of restart inspection.

## 8. Implementation Gates and Required Qualification

EF1-EF4 implementation/qualification evidence is recorded separately.
This cross-stage table does not itself claim passing runtime counts.

| Gate | Concrete deliverable | Required qualification |
|---|---|---|
| EF1 (implemented) | Opt-in retained source/freeze child, original-stream deferred close and stop latch; no authority writes | Pending and armed closing schedules, exact handle continuity, pending transaction/checkpoint/backup rejection, normal no-retainer compatibility, independent readers and release-error handling |
| EF2 (implemented) | Separate retained first-enrollment preparation and atomic arm | Exact-object/thread/scope capture, conflicting read drain, forged/reused/borrowed rejection, closing-before/after-arm schedules and no data callbacks under lifetime gates |
| EF3 (implemented internally) | Single-frame terminal stopped append through audited seam | Exact conditional empty head, stale/corrupt no-write inventory/bytes, actual partial output, flush/readback/cleanup faults and acknowledged receipt with all admissions stopped |
| EF4 (locally qualified) | Cross-platform observed trace/process qualification | Enumerate actual before/after/partial positions, repeated kill/ACK-loss/closing windows and independent contenders; retain every failed attempt and distinguish native execution from guards/models |

EF1-EF3 are implemented with separate contracts/validation. Existing borrowed preparations
cannot append or upgrade. The separate retained preparation supports only one terminal stopped
Enroll frame. EF4 now qualifies actual persistence positions and repeated interruption/ACK-loss/
contention windows. Next consolidate readiness and the remaining host/restart contracts. General append, public API, actual host control, archived compatibility and
all retirement remain open; keep CanReclaim=false and every retained history.

Readiness review follow-up (2026-10-30): [EF1-EF4 review](M2_ENROLLMENT_READINESS_REVIEW.md)
identifies ER-002 retained preflight placement inspection under the shared authority monitor.
The output phase is authority-only; the broader preflight boundary needs hardening under this
contract. ER-003 direct authority/parent close-fault qualification remains open. No contract
relaxation or additional writer is enabled; address ER-002 next.

ER-002 implementation follow-up (2026-10-30): [retained preflight](M2_RETAINED_ENROLLMENT_PREFLIGHT.md)
now keeps protected inspection outside authority monitors with actual ownership retained.
Generic inspection is unchanged. Next ER-003 direct authority/parent close-fault qualification;
all restart/host/public/archive/retirement gates remain open.

ER-003 implementation follow-up (2026-10-30): [direct role-release qualification](M2_ENROLLMENT_ROLE_RELEASE.md)
and [validation](M2_ENROLLMENT_ROLE_RELEASE_VALIDATION.md) cover authority/parent before/after/
no-op closes and required-cleanup versus later-disposal outcomes. Dated evidence above retains
its original scope. Next ER-004 stopped restart/owner-handoff contract; no new writer is enabled.
