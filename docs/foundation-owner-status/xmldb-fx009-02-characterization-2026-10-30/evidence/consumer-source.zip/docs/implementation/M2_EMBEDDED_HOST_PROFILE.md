# Single-Process Embedded Host Pilot Profile

Date: 2026-10-28. User-selected target under [ADR-022](../ADR-022-single-process-embedded-pilot-host.md).
The target is selected; the host, durable backend and external writer exclusion are not implemented.
No existing production application was supplied. This profile guides an internal pilot rather
than treating EmbeddedQuickstart as a qualified migration host.

## 1. Selected Deployment and Resources

| Concern | Pilot requirement |
|---------|-------------------|
| Host | One controlled application process on one machine; no server, remote publisher, durable job queue or HA |
| Scope | Explicit configured deployment/resource key covering all source/artifact/destination paths and every prior attempt for the request |
| Host state | Dedicated local root, disjoint from all data/artifact/candidate/workspace roots; no additional mandatory store role |
| Ownership | One exclusive lifetime handle on stable host ownership state; no deletion/recreation of an active lock file or timeout takeover |
| Storage policy | Initial ProcessCrash qualification on explicitly tested local filesystems; no network share, cross-host or physical-durability claim |
| Publisher inventory | In-process owned operations only; no untracked fire-and-forget jobs or child/remote publishers |
| Database writers | All controlled by the same stopped admission gate; independent old/manual/foreign writers disqualify the pilot scope |
| Route/work | Unavailable until the actual application supplies authoritative selection and accepted-work accounting; keep writers stopped |
| Public surface | Existing profile-specific entry points unchanged; pilot remains internal until separate public/consumer release review |

Configured resource identity must cover aliases and all paths used by every attempt, not just
the current destination. Reject links/overlap/unsupported paths according to a reviewed bounded
host-path contract. OS/file identity and cooperating-process tests are required; text path equality
alone does not establish global exclusion. Do not claim a lock excludes arbitrary hard-link aliases,
old applications or writers that do not honor it. File ownership is not a cryptographic trust anchor.

## 2. Ownership, Admission and Shutdown

Start with admissions closed. Establish deployment control over every writer before acquiring
pilot ownership; inability to enumerate/stop a foreign writer requires reconciliation. Acquire
the stable host-root lease before parsing authoritative ledger state or doing owning Open/recovery.
Contending cooperative processes fail closed. Do not replace/move the owned root or unlink/recreate
its lock while live. Retain ownership through intent/dispatch/publication and receipt reconciliation.

A managed operation registry tracks all admitted work, including publication whose caller timed out.
Timeout/cancellation of the caller does not remove a running operation from that registry. Close
admissions first during shutdown; await actual completion and dispose child transaction/snapshot
handles before releasing the lifetime lease. If shutdown cannot establish completion, keep stopped
state and require process termination/restart reconciliation; never hand ownership to a new worker
based on elapsed time. Final process exit is evidence only within the proved all-in-process scope.

The library still owns local store leases and plan single use. Host ownership does not replace
them. Never hold MG5 thread-confined scopes across awaits or use a saved plan/descriptor to create
execution authority after restart. The future adapter needs an explicit synchronous/async lifetime
design rather than assuming those scopes are transferable.

## 3. Proposed Local Ledger Backend

The preferred next prototype is a bounded append-only host file journal outside data roots.
This choice is provisional until codec/durability review. Use no new server dependency and do
not reuse store WAL or provenance for host authority. The next contract must define:

- Versioned bounded frames and canonical immutable request/attempt/context fields, with strict
  decoding and unambiguous hash/integrity coverage. Checksums detect damage, not hostile edits.
- Revision/owner/transition rules under the lifetime lease, retaining prior attempt histories
  and separating actual receipts, observations and reconciled absence.
- A concrete acknowledged commit boundary, file flush behavior, namespace creation and parent
  barriers for each supported policy. A buffered write is not confirmed durable intent.
- Treatment of interrupted frames, unknown write/flush acknowledgments, corruption, truncated
  committed history, wrong scope and unavailable evidence. Do not invent a repair/truncation
  rule before proving that it cannot discard committed authority.
- Startup validation of the complete bounded history before decisions; restart always begins
  stopped. Local files have no inherent anti-rollback authority. Offline restore/rollback,
  malicious mutation, network storage and uncertain durability require explicit reconciliation;
  they must not silently authorize a new dispatch from a stale valid-looking prefix.

Backend design must avoid claiming that ProcessCrash proves power-loss durability. Requested
stronger policies must be supported explicitly or rejected. No host record format, codec,
filesystem write, journal recovery or new package is added by this profile.

## 4. Restart and Publication Boundary

After process exit, discard every executable plan, owner session, prior readiness result and
in-memory route decision. Acquire fresh pilot ownership under the controlled deployment scope;
validate retained host history and all uncertain attempts before preparing anything new. A fresh
owner generation rejects stale cooperating updates but does not itself fence publication.

Inspect retained descriptors with exact attempt/artifact/path commitments. A known match remains
an observation unless an actual acknowledged return was retained. An absent candidate permits
new-attempt consideration only after every prior executor/queue scope is proved excluded and
no prior publication evidence conflicts. A fresh attempt gets a fresh library ID; the old history
stays retained. Missing/corrupt/unavailable host state enters reconciliation, not automatic reset.

Until a real application supplies authoritative route/work facts, the pilot can qualify stopped
administrative publication/reconciliation only. It cannot resume application writes, infer zero
accepted work, swap source paths or automatically route to a published candidate. HA2's production
route/work gate remains open even after file-ledger process tests pass.

## 5. Sequenced Acceptance Gates

| Gate | Required evidence | Status |
|------|-------------------|--------|
| EP1 profile | User-selected host, controlled scope, lifetime and restart requirements | Defined here |
| EP2 journal contract | Versioned bounded codec/commit/corruption/rollback limits and fault plan for the proposed file backend | Contract defined; codec next |
| EP3 ownership | Actual cooperative process contention, aliases/links/root placement, crash release, admission close/drain and reader lifetime tests | Open |
| EP4 persistence | Actual file/journal append/flush faults, process kills, lost acknowledgment reads, strict malformed/corrupt history rejection | Open |
| EP5 stopped pilot | Actual internal orchestrator binds EP3/EP4 to plans, retains attempts and reconciles restart without dispatch replay | Open |
| HA2 application | Real consumer, route revision, complete work accounting, external writer exclusion and end-to-end faults | Open |

Ownership prototype and journal contract must agree on their initial root-creation and lock
lifetime rules before implementation. None of these gates closes public API, archived-reader,
physical durability, release or retirement requirements. Proprietary licensing, Bosak 1.26.2 pins,
SDK 10.0.301 and disabled packaging remain unchanged. CanReclaim=false.

## 6. Delivery and Design Validation

Work through test-only HA1 integration is committed/pushed as 5d23ba2. Its hosted CI run is
40749049745 (observed in progress); the previous a3b578c run 40731887346 completed successfully.
This profile is a local post-push documentation continuation. Runtime/tests/fixtures remain
unchanged in this step; no new runtime tests or durable-host proof are claimed. Previous 448
focused cases/platform retain their dated scope. Strict documentation and hidden/link checks
are used for this design step; machine evidence records their actual results.

[Machine profile](m2-embedded-host-profile.json).


EP2 follow-up: the profile is pushed as 2141eac; [journal contract](M2_EMBEDDED_HOST_JOURNAL_CONTRACT.md)
now defines the proposed backend bytes/commit/reopen boundaries. It is not an implementation
or durability proof. Next is the pure codec with independent vectors; EP3/EP4 remain open.


EP2 codec follow-up: [pure codec validation](M2_HOST_JOURNAL_CODEC_VALIDATION.md) completes
the bounded byte/history implementation. Next EP3 addresses existing-host-root lifetime
ownership and process qualification; provisioning remains explicit and EP4 append is unimplemented.


EP3 follow-up (2026-10-28): [existing-root lifetime validation](M2_EMBEDDED_HOST_OWNERSHIP_VALIDATION.md)
qualifies cooperative ownership, closed admissions and token-drained release. Existing root
checks/read handles perform no creation or repair. Next is explicit no-overwrite provisioning;
EP4 journal append and broader namespace/global exclusion qualification remain open.


Provisioning follow-up (2026-10-28): [ADR-024](../ADR-024-explicit-no-overwrite-host-provisioning.md)
and [validation](M2_EMBEDDED_HOST_PROVISIONING_VALIDATION.md) now qualify explicit absent-root
creation within a controlled cooperating scope. Existing opens do not initialize/repair.
Directory creation is not exclusive; CreateNew owner handoff has no unlock gap. Next EP4
implements conditional journal append and faulted sessions, not automatic resume or routing.


EP4 follow-up (2026-10-28): [owned append validation](M2_EMBEDDED_HOST_APPEND_VALIDATION.md)
now qualifies actual conditional file writes/flushes and stopped uncertain sessions under
retained lifetime ownership. Reconciliation is read-only and cannot rearm a faulted session.
Next EP5 binds live plans to acknowledged transitions and registered executors; broader
application/physical durability and release gates stay open. Pushed EP2/EP3 baseline: 4642b09.


EP5 follow-up (2026-10-28): [live plan-bound orchestration](M2_EMBEDDED_HOST_ORCHESTRATION_VALIDATION.md)
now binds exact positive host saves to registered single dispatch with opaque tickets. New owner
restart remains stopped; Inspect never recreates authority. Next persist owner/observation/absence
reconciliation before explicit fresh-ID retries. No production route/work/global fence is added.


Current audit (2026-10-29): EP2-EP6-D are implemented internally; the gate table above
retains its original design-time scope. The [post-EP6-D review](M2_POST_EP6_READINESS_REVIEW.md)
identifies selected-root authority and application accepted-work accounting as the next contract
gate. HA2 application integration remains open; administrative drain is not work accounting.


User-selected continuation (2026-10-29): the consuming target remains an internal embedded
pilot. [ADR-028](../ADR-028-embedded-pilot-selection-and-work-authority.md) and the
[authority contract](M2_EMBEDDED_PILOT_AUTHORITY_CONTRACT.md) specify a separate application
authority journal without changing this profile's existing host-root roles. EP7-A pure
classification is next; no selection/work persistence or actual consumer is implemented.


EP7-A now implements pure pilot authority classification; see
[validation](M2_EMBEDDED_PILOT_AUTHORITY_CLASSIFICATION_VALIDATION.md). Every output stays
stopped and all host facts remain supplied assumptions. Next EP7-B specifies separate bytes
and transitions; existing admin-root roles and BXHM/BXHJ mappings are unchanged.


EP7-B specification: [ADR-029](../ADR-029-separate-application-authority-journal-v1.md)
and [v1 contract](M2_APPLICATION_AUTHORITY_FORMAT_V1.md) define separate application-authority
roles/bytes and retained work transitions. Two metadata-only vectors are independent examples,
not provisioned roots. Next pure codec/full-history validation; EP7-C/D authority persistence
and actual consumer remain pending. Existing administrative root roles/bytes are unchanged.


Application-authority codec follow-up: [validation](M2_APPLICATION_AUTHORITY_CODEC_VALIDATION.md)
adds pure metadata/frame/history handling without file opening, root creation or dispatch.
Next EP7-C new paired application lifetime/existing-root boundary, then persistence; EP7-D
consumer execution remains pending. Preserve all previous bytes and new independent vector pins.

EP7-C existing-root follow-up (2026-10-29): [ADR-030](../ADR-030-paired-read-only-application-authority-ownership.md)
and [validation](M2_APPLICATION_AUTHORITY_LIFETIME_VALIDATION.md) implement actual paired
read-only ownership/inspection with native identity and actual drain. Explicit provisioning,
initializer-only first enrollment and append remain pending; empty reopen stays stopped.
