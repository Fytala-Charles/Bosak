# EF3 First-Enrollment Append Validation

Date: 2026-10-30. Parent checkpoint ec1dead is committed/pushed. EF3 is subsequent local work.
See [implemented contract](M2_FIRST_ENROLLMENT_APPEND.md) and
[ADR-033](../ADR-033-retained-source-exclusion-and-first-enrollment.md).

## Focused Windows Evidence

All 45 new cases pass: 43 Storage and two Integration. Real source histories at H=0, H=1 and
H=3 produce exactly the prepared frozen-v1 Enroll frame; all other source/capture/admin and
metadata bytes remain unchanged. Immutable acquisition History stays empty while the separate
confirmed receipt records the new head. Reopened authority inspection remains stopped.

Tests cover all eight instrumented phase failures; actual partial/short/extra/zero output;
write-before/after, flush-before/after, readback-before/after and mismatched readback; final
metadata/namespace/log corruption; valid stale and torn heads; owner length and namespace
changes; unsupported durability; forged/wrong-thread/already-armed dispatch; source capture
change after arm; and four closing-before-arm schedules. Invalid histories/bytes are retained,
never repaired or adopted. No output delegation occurs after a conditional prewrite refusal.

A checking I/O adapter asserts authority serialization and absence of source/authority/parent
lifecycle gates during write, flush and readback. Closing all wrappers after arm still permits
actual execution and confirmed drain. Four source-close fault schedules cover before/after
actual handle close both before arm (no possible output) and after arm (possible output).
Unknown release retains authority/parent operations and suppresses acknowledgment in each case.
Fixture-only handle cleanup neither clears uncertainty nor retries production close.

Two independent publisher processes cover H=0 and H=2. After acknowledgment, all three owner
roles remain excluded until explicit graceful wrapper drain. The caller then reopens and
verifies the exact one-frame journal while the publisher and its old snapshot remain alive.
Source/admin bytes remain unchanged. These are graceful lifecycle/publication cases, not
interruption, acknowledgment-loss or competing-first-publisher sweeps.

## Regression and Integrity

Isolated Linux passes all 645 focused cases (591 Storage and 54 Integration), including all
45 new bodies; Xdm has no matching cases. SDK 10.0.301 runs on x64 overlayfs with read-only
source/cache mounts, no network and isolated build outputs. Seven expected MINVER1001 warnings
reflect Git-free copied sources. No full Linux/ARM64/other-filesystem qualification is claimed.

The fresh unfiltered full Windows command passes all 2,434 cases: 1,773 Storage,
634 Integration and 27 Xdm, with no failures, skips or reruns needed in this full attempt.
All 2,389 previous case names remain, with exactly 43 new Storage and two new Integration
cases. Five final C# source hashes remain unchanged from the passing focused/full builds.

Final counters and raw TRX/source
hashes are recorded in [machine evidence](m2-first-enrollment-append-results.json). Earlier
focused results are not added to full totals. Initial development runs exposed a test reader
sharing-mode error and an integration test field-name compilation error; both were corrected
before final qualification. Retained nonfinal TRX records do not describe final source inputs.

Formatting/analyzers, four frozen authority vectors, 13 Python metadata cases and actual
hidden/link documentation portability checks pass. Governed documentation-kit files and
frozen fixtures are unchanged. Windows catalog totals include existing host-only guards;
Linux native execution must be reported independently. No physical durability certification
or real ENOSPC proof is claimed.

## Next Step

EF4 observed persistence trace/process qualification remains open. No general post-enrollment
append, application work admission, route changes, public API, source replacement, archived
release qualification or committed-history reclamation is enabled.
