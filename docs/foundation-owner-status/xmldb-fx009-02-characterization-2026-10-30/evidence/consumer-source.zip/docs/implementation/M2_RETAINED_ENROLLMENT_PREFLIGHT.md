# Retained Enrollment Preflight Lock Boundary

Date: 2026-10-30. Implements ER-002 under
[ADR-033](../ADR-033-retained-source-exclusion-and-first-enrollment.md) and the
[readiness review](M2_ENROLLMENT_READINESS_REVIEW.md).
See [validation](M2_RETAINED_ENROLLMENT_PREFLIGHT_VALIDATION.md).

## Retained Protocol

PrepareRetainedFirstEnrollment now registers the actual source child before its first
protected-path placement inspection. The actual authority/parent operation is already held.
All three original owners therefore span every unlocked placement pass. If that initial
validation fails, the initializer and this freeze's one-shot child registration are consumed;
cleanup releases the unarmed child without adding retry authority or a new capture.

Every retained empty-authority validation uses this sequence:

1. Check protected placement/native ancestry outside authority, parent and source monitors.
2. Serialize exact authority role/metadata/empty-head checks under _readGate.
3. Recheck protected placement outside those monitors.
4. Serialize exact authority checks again after the last unlocked placement pass.

The second authority check catches a valid stale head or corrupt role inserted during the
last unlocked interval. No observed head is adopted. Actual registrations span the gaps;
the sequence is not an atomic fence against an uncooperative filesystem actor.

Prepare, dispatch and admitted execution inspection all use this retained helper. It calls
the authority-only reader through RequireEmptyAppendHead rather than ReadOwned. The helper
requires a real source child, rejects caller-held library monitors and enforces authority
serialization before exact empty-head checks. Source/capture complete-history validation and
held-parent verification remain outside authority serialization. Source stop-latch, uncertain
publication, actual execution ownership and release-unknown behavior remain unchanged.

## Observation and Existing Readers

A narrowly internal, default-null IRetainedEnrollmentPreflightProbe observes protected paths
immediately before ancestor inspection and the unlocked authority-read boundary. It is bound
to actual preparation resources and transfers with execution. It is test infrastructure,
not a consumer callback/provider, descriptor capability or public extension point. No observer
runs under a lifecycle/source/authority monitor. Production installs no observer.

CheckPlacement retains its existing generic behavior when no observer is supplied. Generic
OpenExisting, Inspect, borrowed preparation and ordinary source ownership are unchanged.
The retained protocol alone replaces generic ReadOwned preflight. Generic read-only inspection
still performs its established placement checks; the fix does not claim that every generic
reader has the retained writer's phase contract.

## Outcomes and Limits

Pre-arm failure produces no authority output and can honor an explicit unarmed freeze release.
After arm, refusal retains the original source-owner stop latch. Closing during inspection
cannot release original handles until actual child drain. Stale/corrupt role and capture bytes
are preserved without repair, recapture, namespace cleanup or head adoption. No new journal
operation, public API, wire layout, durability mode, source replacement or reclamation is added.
Keep all histories and CanReclaim=false.

Next ER-003 qualifies direct authority/parent close-error paths. ER-004 stopped restart and
owner handoff, actual host controls/routing/work admission, public/archive release and all
retirement remain separate gates.
