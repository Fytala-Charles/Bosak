# Stopped Reconciliation Append Validation

Date: 2026-10-29. EP6-A implements the first boundary of
[ADR-027](../ADR-027-stopped-embedded-restart-reconciliation.md).

## 1. Implemented Boundary

BeginStoppedReconciliation requires an exact current position, complete nonempty history,
fresh session-bound stopped/exclusion facts, closed admissions and no registered operations
or executor. The returned private registration retains host ownership and excludes ordinary
admissions until disposal. It is not an executable ticket or proof against hostile publishers.

AppendStopped accepts only TransferOwner, ObserveKnown and ReconcileAbsent. It reuses EP4's
full history/semantic validation, current owner/scope checks, exact expected position, frame
flush/readback and sticky post-entry uncertainty. It does not require journal enablement or
already-reconciled outcome facts. Ordinary append keeps its existing admission requirements.
A foreign/disposed registration is rejected; a stale position returns conflict without bytes.
Disposal is serialized with actual saves and rejects disposal from an append callback. Shutdown
holds ownership until both actual append work and the session registration drain.

This is a low-level persistence boundary. Its trusted caller still must establish actual
inspection/absence evidence before proposing outcomes. Inspector composition, explicit new-plan
retry, repeated process-kill qualification and production application integration remain pending.
No writer routing/resumption, receipt synthesis, public mutable API or reclamation is added.

## 2. Validation

25 new Storage cases cover transfer/absence with admissions closed; four forbidden events;
nine invalid acquisition facts; empty reopen; stale/disposed and foreign registrations;
callback disposal/admission rejection; concurrent same-head saves; five checkpoint failures;
lost flush acknowledgment and actual shutdown drain with retained-owner contention.
Existing ownership, append, orchestration, codec, ledger and planned execution tests form the
focused regression suite. Results are recorded in the [machine evidence](m2-embedded-host-stopped-append-results.json).
All 935 focused cases pass per platform (732 Storage and 203 Integration), with zero failures
or skips. Formatting and Windows/Linux strict documentation/portability checks pass.
The focused runs are not an unfiltered full-suite run or physical power-loss qualification.
Windows retains three existing FIFO guard rows; Linux executes those bodies.

Existing v1 wire mappings, frozen fixtures/readers, proprietary license and disabled packaging
are unchanged. The public Storage API remains at 95 signatures. Formatting and strict docs/
portability checks must pass before this step is handed over.

## 3. Delivery and Next Work

The EP6 design is pushed as `22eeddf`; EP6-A code/evidence is local until separately committed.
Next compose actual read-only inspection with exact owner transfer and outcome saving, then
add explicit fresh-plan retry only after qualified absence. Preserve saved observations as
observations and never reconstruct an executable ticket or synthesize a pipeline receipt.
