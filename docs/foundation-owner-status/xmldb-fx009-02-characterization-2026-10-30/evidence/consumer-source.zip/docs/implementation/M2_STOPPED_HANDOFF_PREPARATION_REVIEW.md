# SR3-A Handoff Preparation Design Review

Date: 2026-10-30. Parent checkpoint 069332c is committed/pushed. Design review only.
[ADR-036](../ADR-036-stopped-handoff-preparation-and-lifetime.md) and
[contract](M2_STOPPED_HANDOFF_PREPARATION_CONTRACT.md) define the next internal slices.
[Machine record](m2-stopped-handoff-preparation-design-results.json) pins reviewed inputs.

| Readiness finding | Design disposition | Remaining runtime gate |
|---|---|---|
| RR-002: attempted flag and inert result cannot prove success | Private immutable proof installed only after full successful observation and final gate checks; single consumed preparation eligibility | SR3-B1 private slot and negative-path tests |
| RR-003: current Dispose immediately drains actual operation | Shared actual resource owner; validation/plan/executor children; close/claim linearization; explicit pending/unknown release | SR3-B1 counts/drain plus SR3-B2/C claim/race qualification |
| RR-004: supplied successor is not live identity | Actual paired parent session, distinct/nonempty, checked generation | SR3-B2 actual binding/transition tests |
| RR-005: supplied global facts remain assumptions | Preserve explicit host gate, no independent global freshness claim | Actual consuming-host authority and reconciliation |
| RR-006: initial restore timeouts | Retain failed artifacts and successful project reruns without relabeling | CI root cause/repeatability work |

No implementation is claimed by accepting the design. Preparation reads cannot occur under
peer lifetime gates, and memory claim cannot perform I/O/callbacks. Actual child registration
precedes unlocked validation; closing prevents publication but defers underlying release.
Claimed private access must survive wrapper closing without reopening ordinary source mutation.
SR3 exposes no append callback. These are acceptance requirements requiring implementation tests.

Review checks source behavior against the actual first-Enroll session binding, current
single-attempt observation and immediate disposal, real restart-source retention and paired
parent accounting. The design keeps default no-plan SR2 semantics and permanently stopped
source admission. Frozen v1 authority formats need no change. No new archived-release,
physical-durability, host-routing, work-accounting or reader-absence evidence is introduced.

Source/test/build/tool inputs are unchanged. Prior full Windows 2,752 and focused Linux 394
passing-case evidence is retained with its original timeout/platform qualifications; no runtime
suite was rerun for documentation-only changes. Strict documentation, portability, diff and
read-only pinned-input integrity checks are recorded separately from runtime qualification.
Next SR3-B1 implements private proof and child lifetime, then tests full repository behavior.
