# EP3 Existing Host Lifetime Ownership Validation

Date: 2026-10-28. Internal existing-root qualification under
[ADR-022](../ADR-022-single-process-embedded-pilot-host.md) and the
[embedded profile](M2_EMBEDDED_HOST_PROFILE.md). This is the cooperative lifetime slice of
EP3; explicit provisioning and durable append remain unimplemented.

## 1. Existing-Root Ownership

EmbeddedHostLifetime.OpenExisting requires an existing fully qualified host directory, trusted
deployment/scope and a bounded inventory of protected data roots. Reject overlap in either
direction, relative/oversized paths, missing or non-directory protected ancestors, links/junctions
and unknown/missing/directory roles. The root must contain exactly owner.lock, host.meta and
journal.bin. Namespace enumeration stops after four entries. No role or root is created/repaired.

Acquire owner.lock with Open/ReadWrite/FileShare.None before reading authoritative metadata or
journal bytes. It must be empty and seekable. Retain that exact handle through shutdown/drain.
Metadata and journal handles are also retained; they must be seekable and obey the codec's size,
integrity, scope and complete-history rules. Read/write opens avoid a Linux FIFO's potentially
blocking read-only open; no Write, SetLength, flush, replacement or deletion is performed.
This pilot therefore requires appropriate local read/write permissions on the existing files.
Directories/reparse/device attributes and non-seekable streams reject. Supported roots remain
operator-controlled regular local files, not arbitrary device namespaces.

Before returning the owner, validate all unique artifact/bundle paths retained in journal
frames as fully qualified, unlinked and disjoint from host state, in addition to the configured
source/data-root inventory. Failed validation closes all acquired handles. The in-memory session
ID is fresh on every successful acquisition; no persisted owner is adopted automatically.

Pre/post namespace checks are not a defense against hostile rename/unlink/replacement or every
hard-link alias. The deployment must prohibit those mutations while owned. Actual owner-file
hard-link contention is tested, but a copied metadata/journal namespace sharing that inode is
not qualified as a second authoritative host. There is no global path registry, native file-ID
attestation, exclusion of arbitrary old/manual writers or anti-rollback proof.

## 2. Administrative Admissions and Drain

Acquisition starts with administrative admissions closed, including valid empty journals.
Opening admissions requires separately supplied fresh evidence bound to the exact session,
journal ID, deployment and resource scope: all writers/publishers controlled, prior executors
excluded, reconciliation complete and no external queue. These are caller assertions, not
independently authenticated host facts or permission to enable database writes.

BeginOperation returns a private idempotent registration token while admissions are open.
The registry is bounded at 1,024 tokens. Every actual operation and retained child handle must
hold a token until its work really completes; the lifetime object does not discover background
tasks or automatically attach store snapshots. Tokens may complete across threads. MG5 freeze/
session thread-affinity rules remain unchanged.

CloseAdmissions pauses new work. Dispose requests shutdown, closes admissions permanently and
retains handles while any registered token remains. Await WhenReleased to confirm successful
release; Dispose itself is a nonblocking shutdown request. Caller cancellation/timeout does not
complete tokens or release ownership. The final token closes journal/metadata then ownership
handles. All close attempts run even if one fails; an unconfirmed release faults WhenReleased
and does not set IsReleased. Process exit releases OS handles but proves no wider worker scope.
Every output/property still keeps database writers stopped. No execution or journal mutation
is dispatched by this type.

## 3. Executed Evidence

50 new cases: 35 Storage cover stopped startup, bound evidence, malformed namespaces/no repair,
protected-root/policy bounds, token limits, duplicate disposal and admission/shutdown races.
Fifteen Integration cases cover four process modes (normal exit, kill, graceful drain, kill
during active drain), four actual linked placements, one owner hard-link alias, three Linux
FIFO roles, persisted journal path containment and two actual migration/restore publisher drains.
Each process mode repeats three times with awaited exit and byte-identical host roles. Graceful
drain permits reacquisition after the token closes while the old process remains alive but idle.

The actual publisher tests register a token, pause the real pipeline at ProofVerified, request
shutdown and prove a contender remains excluded while destination absence is observed. They
then release/await publication and dispose the token before confirming ownership release and
unchanged host bytes. They are lifetime integration tests, not a complete durable-intent adapter.
No host journal records are written. Test setup creates isolated host files explicitly and is
not a qualified production provisioner.

Final focused Windows Debug and isolated Linux Release runs pass 747 cases/platform:
627 Storage (35 new plus the prior 592) and 120 Integration (15 new plus the prior 105).
The three FIFO theory rows execute on Linux and return without exercising a FIFO on Windows;
Windows instead executes actual junction and hard-link tests. Thus 50 new catalog cases map
to 50 actual new-case executions on Linux and 47 plus three host guards on Windows. TRX reports
zero failures/skips; do not interpret guards as native FIFO evidence. Existing RC2 native-policy
and RC3 process cases keep their original host branches. This is not a full-suite/physical-loss run.

Public Storage metadata remains 95 signatures with no additions/removals. Existing codec/vector,
reader and store bytes are unchanged; only the new lifetime/tests and the test-only CrashProbe
command/header change. Formatting, strict docs and actual hidden/link portability checks pass on
both hosts. SDK 10.0.301, Bosak dependency pins, proprietary license and packaging policy stay fixed.

## 4. Remaining Gates

Next implement/qualify explicit no-overwrite host provisioning, including interrupted root/file
creation and contention, before EP4 durable append. OpenExisting must never become an implicit
initializer or repair path. Stable controlled namespace, effective exclusion and complete root
inventory remain requirements. Unsupported filesystem alias/device/adversarial mutation cases
must not be advertised as qualified by these cooperative tests.

EP4 real append/flush faults and stopped reopen, EP5 owned orchestration, HA2 application route/
work authority, archived compatibility, public/release, physical durability and all retirement
remain open. CanReclaim=false. This step and prior EP2 work remain local and uncommitted; pushed
baseline 2141eac is unchanged.

[Machine evidence](m2-embedded-host-ownership-results.json).
