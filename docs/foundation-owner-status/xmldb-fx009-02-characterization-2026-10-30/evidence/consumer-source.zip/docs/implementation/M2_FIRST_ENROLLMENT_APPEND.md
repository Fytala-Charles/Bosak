# EF3 Conditional First Enrollment

Date: 2026-10-30. Implements the bounded first writer in
[ADR-033](../ADR-033-retained-source-exclusion-and-first-enrollment.md).
See [validation](M2_FIRST_ENROLLMENT_APPEND_VALIDATION.md).

## Actual Dispatch and Retention

AppendFirstEnrollment takes the actual unconsumed RetainedEnrollmentPreparation and fresh
supplied evidence equal to its bound intent. It rejects wrong-thread, forged, disposed,
previously consumed or already armed preparations before consuming another plan. It cannot
upgrade borrowed preparation or a prior no-output execution. ProcessCrash is the only policy;
stronger policies fail before consumption without fallback.

The real dispatch transfers resources through EF2's atomic arm. All actual source, authority
and parent ownership survives wrapper disposal. It revalidates the complete frozen source,
registered capture, native identity and administrative history outside authority serialization.
An armed source owner stays stopped after every result. Operational evidence remains supplied
assumptions; these checks do not measure ingress or fence uncooperative publishers.

## Conditional Output

The writer builds and independently decodes the complete frozen-v1 Enroll frame in memory:
prepared baseline/evidence/source, actual owner session, generation one, selection revision one,
sequence one and zero predecessor. No caller-supplied arbitrary event is accepted.

Under the authority serializer only, an authority-only reader checks exact three-role namespace,
regular single-link native path/handle identities, expected metadata/configuration and empty
acquisition head/EOF. The general ReadOwned reader also visits protected paths and is deliberately
excluded from this phase. Stale valid or corrupt state is refused without adoption or repair.

PossibleOutput is set before entering any output-capable hook or write seam. The narrowly
internal IApplicationAuthorityAppendIo writes the exact frame on the original retained stream,
flushes to disk and reads it back. Exact length, bytes, EOF and independently decoded complete
one-frame history must agree; metadata and native identities are checked again. Production
uses FileStream.Write, Flush(true) and ReadExactly. Test instrumentation is not a consumer
provider/callback extension. Source/lifetime APIs must not be reentered from journal I/O.

No source/capture/admin inspection, source gate, lifecycle gate, directory publication or
cleanup runs under the authority serializer. Exit serialization before releasing real resources.
Source release precedes authority/parent operation release; an unconfirmed source close retains
those operations. Cleanup failure cannot become unqualified acknowledgment through a faulted
release task.

## Terminal Stopped Outcomes

| Disposition | Meaning |
|---|---|
| RefusedBeforeWrite | No output-capable call entered; the actual dispatched plan is consumed. Corruption can still fault the session. |
| AcknowledgedStopped | Exact frame was flushed/read back/fully verified and cleanup confirmed or ownership legitimately remains with live owners. Receipt is an observation; writers remain stopped. |
| Uncertain | Output was possible or required cleanup/release is unknown. No receipt is synthesized; retain bytes and require stopped reconciliation. |

PossibleOutput and ReleaseUnknown are separate facts. Cleanup can be unknown without any
possible authority output. Result Error preserves the underlying failure. ConfirmedEnrollment
is set only for acknowledgment, separately from immutable acquisition History. Generic Inspect
remains excluded in retained pending/executing/terminal mode. All dispatched outcomes are
terminal: no retry, truncate, overwrite, prefix adoption or source-latch clearing.

After disposal, a fresh OpenExisting can inspect a complete one-frame log read-only, cannot
initialize an empty root, and rejects partial/corrupt histories without repair. A complete
frame on reopen does not prove that its prior caller received acknowledgment.

## Remaining Gates

EF4 must enumerate observed persistence positions and qualify repeated process interruption,
ACK loss, closing windows and competing owners across Windows/Linux. EF3's targeted faults and
graceful process tests are not that exhaustive qualification. Existing-file flush/readback is
not physical power-loss or real ENOSPC evidence. No public API, work acceptance, real routing,
source replacement, persistent fencing, archived-release compatibility or retirement is enabled.
Frozen fixtures/formats and every committed history remain intact; CanReclaim remains false.
