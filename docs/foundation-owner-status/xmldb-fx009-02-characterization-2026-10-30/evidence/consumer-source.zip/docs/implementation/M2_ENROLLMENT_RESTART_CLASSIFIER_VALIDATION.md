# SR1 Pure Enrollment Restart Classification

Date: 2026-10-30. Parent checkpoint 100b39d is committed/pushed. SR1 is subsequent local work
under [ADR-034](../ADR-034-stopped-enrollment-restart-and-owner-handoff.md) and the
[ER-004 contract](M2_STOPPED_ENROLLMENT_RESTART_CONTRACT.md).
[Machine evidence](m2-enrollment-restart-classifier-results.json) records exact input hashes
and qualification results. SR2-SR4 remain unimplemented.

## Implemented Boundary

EnrollmentRestartClassifier accepts immutable internal descriptions only. Expected/observed
positions bind deployment/resource scope, configured root keys, administrative and authority
IDs, metadata digest, both journal positions, owner tuple, baseline and selection. A separate
legacy-source/capture baseline binds root/admission keys, document/H/history and sealed capture
commitment. Canonical key shape, strict UTF-8 byte bound, hash shape, nonempty identities,
sequence limits and owner/selection shape are checked without touching a filesystem.

Structural facts separately describe namespace, identities, complete administrative/authority
history and unchanged head. Host facts separately describe fresh controlled scope, reacquired
owners, source exclusion, reconciled prior work, drained executors/publishers and reconciled
release. Each defaults Unknown; supplied Confirmed is an assumption, never library verification.
SR2 must acquire actual retained owners, prove complete history and bind fresh facts. SR1
cannot determine that a checksum came from a real root or that a caller told the truth.

The result contains only Decision, Reason and WritersMustRemainStopped=true. Refused,
ReconciliationRequired and ObservedEnrolledStopped are diagnostic states. No filesystem,
callback, recovery, data execution, receipt, initializer, ConfirmedEnrollment or live capability
is accepted or returned. No existing open, append or lifecycle path calls this classifier yet.

## Deterministic Classification

Malformed enum/text/hash/identity/bound inputs refuse. Known structural contradiction refuses
before missing evidence. A changed expected position or explicitly changed head refuses;
contradictory host facts and inconsistent shape/position refuse. A separate optional successor
description rejects empty/reused sessions and exhausted owner generation. It never creates a
transfer plan, computes a wrapping generation or changes observed owner state. Exhaustion is a
proposal rejection, not corruption of an otherwise valid later history.

After those refusal checks, missing structure/pins/shape requires reconciliation. Valid empty
reopen never recreates the initializer; valid later history is unsupported by this slice and
requires reconciliation rather than being labeled corrupt. An exact single-Enroll shape
requires sequence/generation/revision 1 with source selected. Missing or changed source/capture
facts require reconciliation; zero recorded work cannot substitute for unknown prior work.
Only an exact baseline plus every supplied fresh host fact yields ObservedEnrolledStopped.
Complete output after ACK loss follows the same observation rule and never recreates a receipt.
Physical owner availability never substitutes for ReleaseReconciled. The source stop latch and
all actual retained-lifetime semantics remain untouched.

## Qualification

There are 89 new Storage cases with no platform guards. They cover the exact-Enroll and inert
successor cases; each of 12 unknown/contradictory facts; missing descriptions; empty and later
history; all source/capture correlations; every pinned field; malformed identities/enums/hashes/
text; strict UTF-8 byte limits and runtime unpaired surrogates; source H0/H10000 boundaries;
successor identity/overflow; refusal precedence; deterministic repeated results; and no receipt
or capability property on the assessment. Existing codec tests supply independent byte/chain
qualification, separate from these assumed structural facts.

Final focused Windows passes 335 cases: 89 new, plus 246 existing restart/codec cases. A prior
development run failed one surrogate-in-attribute case because attribute encoding changed its
input; it is retained and corrected by constructing the malformed string at runtime. Product
refusal behavior was not weakened. Formatting/analyzers pass on both new files.
Isolated Linux passes 451 focused cases (447 Storage + 4 Integration), including all 89 new
bodies without host guards. Xdm has no matching cases. SDK 10.0.301 on x64 overlayfs uses
read-only source/cache mounts and no network; seven Git-free MINVER1001 warnings are expected.
All 2,618 Windows cases pass across complete project runs. The initial restore timeout is
retained and passes focused plus complete Integration rechecks. Storage passes 1,935, Integration 656 and Xdm 27.
All 2,529 previous test IDs remain with exactly 89 new Storage IDs.
The Published-stage restore timeout is retained; rechecks use the unchanged 50-second limit. No cause is inferred.

Fresh public metadata
is unchanged at 95/95 entries, zero additions/removals; this is local metadata evidence, not
archived release qualification. Ten frozen vector/binary files match their read-only hashes.
Strict docs, actual hidden/link portability, formatting/analyzers and diff hygiene pass. Both
final C# source hashes remain unchanged from qualified runs. No fixture generation scripts
are executed.

## Next Gate

Next SR2 designs/implements actual stopped paired-owner/source-bound observation with complete
verification, retained exclusion across unlocked inspection, exact freshness rechecks and
closing/identity/head-race qualification. Reuse SR1 only as an inert assessment of those facts.
SR3 single-use handoff preparation and SR4 separately reviewed conditional TransferOwner remain
later. Actual host/public/archive/physical-durability and all retirement gates remain open.

SR2 design follow-up (2026-10-30): [owned observation design](M2_OWNED_RESTART_OBSERVATION_DESIGN.md)
requires a separate restart-only source child and actual paired observation, without fabricating
old capture associations or hiding live recovery. Next SR2-A; SR2 runtime remains unimplemented.
