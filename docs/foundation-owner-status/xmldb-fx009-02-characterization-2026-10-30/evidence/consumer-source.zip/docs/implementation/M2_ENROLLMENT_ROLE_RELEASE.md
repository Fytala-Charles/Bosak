# ER-003 Authority and Parent Role Release

Date: 2026-10-30. Implements the direct release-fault qualification identified by the
[readiness review](M2_ENROLLMENT_READINESS_REVIEW.md) under
[ADR-033](../ADR-033-retained-source-exclusion-and-first-enrollment.md).
See [validation](M2_ENROLLMENT_ROLE_RELEASE_VALIDATION.md).

## Actual-Lifetime Close Seam

IRetainedRoleLeaseClose is an internal qualification seam bound once to actual acquired role
streams through an owning lifetime's private constructor. The authority's internal ProvisionCore
and parent's separate internal OpenExistingCore accept it for tests. Ordinary entry signatures,
production provisioning/open and acquisition-failure cleanup retain their existing behavior.
The default null branch directly delegates FileStream.Dispose. No path/descriptor/receipt
reconstructs ownership, and no mutable closer installation or public provider is introduced.

Lifetime release still attempts each original role exactly once, in reverse acquisition order:
authority log/metadata/owner, parent journal/metadata/owner. An injected closer is given the
actual FileStream, with its original SafeFileHandle captured before delegation. An exception
before or after real close is unconfirmed. Returning without closing that original managed
handle also produces an IOException rather than successful release. Native kernel-close
failure or general physical release certification is not established by this managed seam.

Close instrumentation runs during final actual drain, outside journal serialization. Existing
per-owner lifetime monitors still protect release state. The seam must not reenter lifetimes,
source validation, serializers or callbacks; it is not an extension point. No journal/data write,
rename, truncate, history cleanup or new namespace publication is added.

## Error Propagation and Retention

Source retention drains before authority/parent operations, as before. Authority role release
failure faults its WhenReleased task and keeps the actual parent application registration.
Its physical authority roles may be partly or wholly closed; that does not authorize clearing
the retained parent registration. Parent release then does not start and its owner stays held.

If authority roles close successfully but parent release fails, authority WhenReleased can be
successful while parent WhenReleased is faulted. Parent operation count reaches zero; its
release remains logically unconfirmed. Neither task result proves global reader absence or
permits a retry, route, writer resume or reclamation. Repeated Dispose never repeats an already
attempted release, including no-op or after-close errors.

RetainedEnrollmentResources checks both tasks after actual operation disposal. Required
cleanup failure therefore makes AppendFirstEnrollment Uncertain with ReleaseUnknown=true,
no receipt and no ConfirmedEnrollment. PossibleOutput remains a separate fact: closing before
arm can yield uncertain release without entering any output-capable call; closing after arm
can leave a fully verified one-frame log while acknowledgment is suppressed. Bytes are retained.
Source stop-latch and thread/object/initializer binding rules remain unchanged.

## Acknowledgment and Later Disposal

A qualified append may legitimately return AcknowledgedStopped while its live owners retain
their handles. A later independent owner Dispose can fail; its release task reports that error
without rewriting the already qualified publication receipt. This is not an inferred release
acknowledgment. Application admission remains stopped, the session is terminal and the plan
cannot run again. Pending-plan disposal instead propagates a required cleanup error directly
without starting append or writing authority content.

Tests may close fresh fixture handles manually to permit workspace cleanup. Such teardown
neither retries the production adapter nor changes any faulted/pending logical release task.
It is not a live-store recovery path. All store history and CanReclaim=false remain intact.

## Next Gate

ER-004 needs a stopped restart/enrollment reconciliation and owner-handoff contract before
post-enrollment authority operations. This release qualification adds no public API, wire
format, general append, actual routing/work admission, persistent fence, source replacement,
archived release evidence or retirement capability.

ER-004 design follow-up (2026-10-30): [stopped restart/handoff contract](M2_STOPPED_ENROLLMENT_RESTART_CONTRACT.md)
separates pure stopped assessment from actual retained evidence and future owner transfer.
Next SR1 pure classifier. No additional writer, resumed source or new capability is implemented.
