# MG4 Conversion Fault and Interruption Qualification

Date: 2026-10-27. Internal migration qualification under
[ADR-018](../ADR-018-full-history-legacy-migration-and-cutover.md).
The [MG3 runtime contract](M2_EPOCH_MIGRATION_CONVERSION.md) and all production algorithms,
wire formats, fixtures, licensing and public APIs remain unchanged by this step.

## 1. Observed persistence-call matrix

EpochMigrationFaultTests records a successful H=1 legacy conversion trace, then injects
an IOException before and after every observed ITransactionStorage/ITransactionFile call.
Each WriteFile/before position additionally writes a real first half and throws through
the existing fault adapter. Creation, writes, flushes, closes, moves, deletion and barriers
cover MG2 source complete/redo clones, transformation, destination complete/redo clones,
fresh runtime, BXEM, publication and cleanup. The injected exception uses a disk-full
HRESULT; this is not physical capacity exhaustion or a fault inside every native syscall.

Modes are recorded separately: 0=ProcessCrash, 1=modeled FileAndDirectoryFlush ordering with
ProcessCrash delegation, 2=actual native Linux FileAndDirectoryFlush. Assert EffectiveDurability
in every adapter. Three mode-2 cases return on Windows without native execution evidence.

Each worker owns a same-depth attempt directory and fresh operation workspaces. Up to four
workers run concurrently against only shared read-only input; the old source snapshot stays
on the test caller thread and is read after workers finish. This parallelism does not
parallelize a coordinator or share writable clone paths. Reference and attempts use the
same policy/trace cardinality, and each injected operation/moment is checked against the
reference. Every recorded position must fire and fail before being counted as verified.

Every attempt checks original source/artifact bytes and directory/file inventory. The
original pre-commit lazy snapshot must retain its value after source-owner disposal and
all conversion attempts. Failures before publication leave destination absent. If present,
require exactly migration.bin plus store/, MG1 provenance/header bindings, exact initial H,
fresh identities, repeated head/base snapshot reads and both complete/redo destination
oracles on an audit copy excluding runtime locks. Published paths reject retry unchanged.
Exclusive file opens expose leaked handles in the worker's own directory before contained
test-owned teardown. Production cleanup does not scan or delete abandoned paths/history.

This is exhaustive over the observed H=1 traces, not all history lengths or hostile external
mutation. MG3 retains H0/H1/H3 parity/rejection evidence. Per-case durations and all measured
positions are recorded in [machine evidence](m2-epoch-migration-fault-results.json).

## 2. Repeated process and actual native interruption

EpochLegacyMigrationProcessTests now runs 12 boundaries under default ProcessCrash and
actual native Linux directory flushing, repeating each three times against the same input.
The 12 native-policy theory branches return on Windows; they do not run with a fallback.

| Boundary | Interruption or completion |
|----------|-----------------------------|
| normal | Complete conversion and return published path |
| LegacyCompleteCopy | Kill after a real private complete-clone write, before flush |
| LegacyRedoWrite | Kill after a real legacy redo staging write, before flush |
| SourceVerified | Kill after both legacy oracles |
| Rebound | Kill after identity/authority transformation |
| EpochRedoWrite | Kill after a real epoch redo staging write, before flush |
| DestinationVerified | Kill after both destination oracles |
| RuntimeReady | Kill after fresh runtime validation |
| OriginFlushed | Kill after BXEM is flushed |
| BundleVerified | Kill after final input/bundle checks, before rename |
| Published | Kill after bundle rename and policy barriers |
| ACK | Kill after method return, before response delivery |

The process-only MigrationInterruptionStorage forwards every real local storage operation
and advertises its actual delegate policy. It interrupts targeted copy/redo writes without
adding production hooks or substituting modeled behavior for native operations. Writes
may still be buffered at those kill boundaries; no physical partial-flush claim is made.

Private kills leave no final path and can retry the same absent destination successfully
with the same selected policy, leaving older private debris untouched. Published/lost-ACK
outputs reopen repeatedly, accept an independent next commit without changing provenance,
and reject overwrite. Every repetition checks source/artifact bytes. Native reopens, retry
and branch writes use the native policy too. No source lease transfer, routing or deletion.

## 3. Regression accounting and limits

The new matrix adds nine Storage cases. Existing six process cases expand to 24 (18 extra),
so the catalog is 816 cases. Fresh filtered runs cover 798 per platform: 624 Storage,
27 Xdm and 147 Integration. The unchanged expensive 18-case EpochBackupFaultTests matrix
retains its previous [ET9-D evidence](m2-epoch-backup-fault-results.json); do not call this
an unfiltered new 816-case run. In addition to prior host-only branches, MG4 introduces
three native matrix and 12 native process branches not executed on Windows.

All 798 fresh cases pass on each platform, with zero failures/skips. The measured totals are:

| Platform | MG4 fault positions | Actual native fault positions | Process executions | Native process executions |
|----------|---------------------|-------------------------------|--------------------|---------------------------|
| Windows / NTFS | 2,900 | 0 | 36 | 0 |
| Linux / overlayfs | 4,424 | 1,588 | 72 | 36 |

The full filtered Windows Storage batch took 12m33s and Linux Storage 19m33s; per-matrix
case durations are retained in the machine report. The Linux integration batch took 12m20s
and Windows integration 5m29s. These are measured local run times, not performance promises.
SDK10.0.301; Windows runtime10.0.11, Linux runtime10.0.9.

Record measured Windows/NTFS and Linux/overlayfs results separately. Linux runs in the
pinned SDK image with source/cache read-only and network disabled. Validate frozen fixture
hashes, formatting and strict documentation. Injected faults and container process/native
fsync execution are not actual ENOSPC, controller/filesystem certification or physical
power-loss proof. No public API or release qualification is inferred from these local runs.

Next MG5: implement the bounded cutover acceptance harness for writer freeze, exact source/
candidate freshness, explicit application routing failure/uncertainty and divergent rollback
refusal. Preserve original paths/history; no automated routing service or retirement.
