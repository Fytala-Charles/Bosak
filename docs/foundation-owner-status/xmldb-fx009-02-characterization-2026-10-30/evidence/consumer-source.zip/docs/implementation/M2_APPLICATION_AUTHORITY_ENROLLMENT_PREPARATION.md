# Application-Authority First-Enrollment Preparation

Date: 2026-10-29. Internal legacy-only read-only boundary under
[ADR-032](../ADR-032-owner-bound-first-enrollment-preparation.md).

## 1. Prerequisites and Scope

Provision the separate authority with its original owner still live. Existing-root reopen,
including a valid empty log, never obtains initialization privilege. Independently open the
legacy store, acquire MigrationSourceFreeze under operator stop/drain attestation, and create
its one registered sealed capture using existing MG5 APIs. Those setup actions can write;
they precede and are outside the read-only preparation claim. Supply source/capture protected
root mappings when provisioning the authority. Do not fabricate legacy epoch identities.

The source freeze only blocks cooperating store mutations. It is not application ingress,
prior-task accounting, remote fencing or old-binary exclusion. Actual host controls remain
an EP7-D gap. Operational evidence must explicitly assert fresh closed ingress, excluded prior
executors/publishers, reconciled prior work and an empty queue, with exact host context,
authority ID, reconciliation ID and a canonical lower-hex SHA-256 reconciliation commitment.
Copying those fields does not independently establish their truth or freshness.

## 2. Preparation

PrepareFirstEnrollment consumes the original initializer reservation before any source I/O.
Require the exact capture registered in the supplied live caller-thread freeze. Verify sealed
closure and every retained legacy transition, then compare actual live document ID/H/head,
full retained file hashes/closure and canonical optional H0 CURRENT against that capture.
Reuse strict MG5 source validation; additionally reject nonempty staging and temporary files.
No recovery, runtime initialization, clone, import, source repair or cleanup is performed.

Read native source directory identity and compare the real retained coordinator writer handle
with its path, requiring a regular/single-link zero-byte admission file. Recheck those identities
after inspection. H0 and positive-H data stores are supported; metadata-only codec vectors are
not accepted as stores. Snapshot-owned readers and all histories remain untouched.

Construct a fresh library-generated baseline GUID, actual parent session/generation one,
source selection/revision one and a Legacy PilotRootBinding. Its InitialHistoryDigest is the
SHA-256 of the exact registered inventory bytes, not merely a head hash or current H. Its
admission key names the configured identity; actual native identity is also bound privately.
Validate the proposed entry by a bounded in-memory frame/whole-history round trip against the
existing v1 metadata. No authority.log bytes are written and no acknowledgment is returned.

The private evidence digest uses the BXEP-BASELINE-1 domain and BinaryWriter's length-prefixed
UTF-8 strings/numeric values to bind baseline GUID, canonical authority path, authority/admin
keys/IDs, parent session/deployment/resource, reconciliation ID/digest, capture key, source root
digest/inventory digest, admin position, and native authority/source/admission role identities.
This is an internal diagnostic correlation hash, not a new published format, portable recovery
record, signature, durable receipt or archived release proof. Existing v1 bytes are unchanged.

## 3. Consumption and Lifetime

ApplicationEnrollmentPreparation is caller-thread confined and holds an actual authority/admin
inspection operation. Its registered object identity is required by CheckFirstEnrollment;
a copied description or internally constructed lookalike cannot pass. The read-only check is
single-use and consumes before source I/O. Require fresh supplied evidence equal to prepared
scope/reconciliation intent; repeat exact source/capture/native identity and unchanged empty
authority checks. Owner/freeze loss, changed data or conflicting evidence faults the session.
Wrong-owner/thread/forged/disposed/consumed objects reject before consumption of a valid plan.

Dispose releases the retained operation once. Disposing authority/admin owners stops new work
while real preparations still hold their handles. Source owner/freeze remain caller-owned;
preparation does not extend their lifetime after disposal. Loss invalidates subsequent checks.
The source gate protects each actual source inspection; no source/artifact callback runs under
application-authority lifetime locks or its journal serializer.

Describe returns immutable point-in-time diagnostics and always WritersMustRemainStopped=true.
It may describe an earlier observation; it grants no freshness, enrollment, append, database
invocation or routing authority. No process restart can reconstruct the registered object.
No implicit retry, rearm, history reset, profile relaxation or public mutable API is enabled.

## 4. Next Gate

Design the conditional first-enrollment append/uncertain-save boundary using actual owner-bound
preparation, continuing source freeze and fresh explicit operational evidence. The current
CheckFirstEnrollment is read-only consumption, not an append capability. A future writer cannot
execute an old description or reuse consumed preparation. Keep actual host control, public API,
archive compatibility, source replacement and all retirement/reclamation gates explicit.

Before implementing that writer, specify how actual source exclusion survives the entire
read-to-append gap and racing caller disposal. The current preparation borrows source
scopes and returns diagnostic observations; it is not an atomic validation/write boundary.
Holding an authority operation alone does not keep a caller-disposed source freeze active.
Do not hold source gates across authority I/O or add an automatic check-then-write shortcut.
Use explicit retained source/owner operation lifetime, fixed lock order, exact conditional
head/identity checks and fail-closed treatment of any publication uncertainty. No future
writer may infer continuing exclusion from a previously successful description/check.

Design follow-up (2026-10-29): [ADR-033](../ADR-033-retained-source-exclusion-and-first-enrollment.md)
and [contract](M2_APPLICATION_AUTHORITY_ENROLLMENT_APPEND_DESIGN.md) specify a separate
retained preparation and conditional writer. They do not change this borrowed read-only
API or grant an upgrade from its descriptions/checks. EF1 source retention is next.
