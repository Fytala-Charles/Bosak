# Application-Authority Enrollment Preparation Validation

Date: 2026-10-29. Parent checkpoint 3f722da is committed/pushed. This continuation is local.
See [ADR-032](../ADR-032-owner-bound-first-enrollment-preparation.md) and
[contract](M2_APPLICATION_AUTHORITY_ENROLLMENT_PREPARATION.md).

## Implemented Boundary

A successful live initializer can prepare one read-only enrollment intent from a real frozen
legacy store and its registered sealed capture. Complete retained history, live head/closure,
actual native directory/writer identity and exact scope/reconciliation assertions are bound.
The data proof is verified; operational assertions remain supplied assumptions. All writers
stay stopped. No enrollment append, recovery, runtime creation or cleanup occurs.

## New Focused Cases

35 Windows Storage cases pass. Happy paths use real imported XML stores at H0/H1/H3 with
actual scalar histories and sealed captures. Setup/capture writes occur before snapshots;
preparation/check leave data and authority bytes unchanged. Proposed entries validate with
the existing whole-history v1 codec and retain actual source sequence/inventory commitment,
source profile, owner session, fresh library baseline ID and initial selection/revision.

Negative cases independently remove each supplied operational assertion or replace scope,
authority, reconciliation ID/digest and root keys. Others corrupt live WAL/capture bytes,
introduce unknown staging/temporary files before or after preparation, lose source freeze/
source owner/parent/authority, change reconciliation, forge capture/preparation objects,
reopen an empty root, consume/dispose twice, use a wrong caller thread or present a nonempty
actual writer role. Failures retain invalid bytes without repair and fault real sessions.
Wrong-thread/forged references do not consume the actual valid plan. A retained preparation
keeps authority/admin handles after both owners dispose until the actual operation drains.

## Regression Status

Isolated Linux focus passes 542: 496 Storage (including all 35 new enrollment cases and
32 existing MigrationCutover cases) + 46 Integration. Xdm has no matching cases. All new
case bodies execute, with x64 overlayfs native identity checks. The runner keeps source/
cache mounts read-only, network disabled and outputs isolated; its Git-free source copy
produces seven expected MINVER1001 warnings. Docker remains running. This is not a full
Linux run, ARM64 qualification or physical durability/ENOSPC proof.

Final Windows project results pass all 2,331 cases: 1,678 Storage, 626 Integration and 27
Xdm. Storage takes 46 minutes 42 seconds; the clean complete Integration confirmation takes
7 minutes 45 seconds. The original full-solution command exits nonzero because of its one
retained Integration failure; no single green full-solution command is claimed. The final
626-case Integration catalog replaces its failed 626-case attempt rather than adding to it.
All 1,643 prior Storage test names remain, with exactly 35 new names. Final selected project
results have no failures or skips. Formatting/analyzers, strict documentation, portability and frozen
fixture checks pass. Prior 2,296-case Windows and 475-case Linux provisioning evidence
does not count as execution of this change. Windows catalog totals include existing
host-only early returns; they do not prove execution of native Linux policy branches.

## Observed Windows Process Failure

The current full Windows attempt reported a failure in the existing
MigrationCutoverProcessTests.Freeze_HolderExitOrKill_ReleasesOwnershipWithoutRouting
kill case: legacy writer.lock was still unavailable immediately after awaited process kill.
The unchanged focused recheck passes both graceful and kill cases. This is similar to, but
not the same test as, the retained host-role failure in the previous provisioning step.
No cause is established, no assertion is relaxed and no polling/retry behavior is added.
The clean complete Integration confirmation passes all 626 cases. No source or test
assertion changes were made between the failed attempt and successful rechecks.

Review checked the existing awaited process exit and temporary native identity-handle
cleanup. Microsoft documents asynchronous external termination and process waiting in
[TerminateProcess](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-terminateprocess)
and [process termination](https://learn.microsoft.com/en-us/windows/win32/procthread/terminating-a-process).
Those descriptions do not establish the cause of this observed sharing violation. Retain
the failure separately from successful reruns and do not call it a diagnosed Windows defect.

## Limits and Next Step

This is legacy-only real data binding with supplied operational assumptions, not verified
application ingress/prior-work control. Borrowed source scopes must remain live and on their
caller thread. Native checks inherit existing local filesystem/platform limits; no hostile
namespace, coherent rollback, pre-lease reader-absence or archived release proof follows.
The read-only check consumes preparation; it grants no durable acknowledgment or write resume.

Next design conditional first-enrollment append and sticky uncertainty under retained actual
owners/source freeze with freshly scoped evidence. No general append, application work, real
routing, public mutable API, source replacement, cleanup or history reclamation is enabled.
All histories remain and CanReclaim=false.

## Machine Evidence and Delivery

[Machine evidence](m2-application-authority-enrollment-results.json) pins source hashes,
TRX paths/hashes, original failed/clean project counters and catalog replacement. Raw source
hashes describe this validation checkout, not archived-release provenance. Earlier focused
rechecks are not added to final totals. All five C# inputs remain unchanged since the full
build; no failure suppression, assertion relaxation or product retry behavior was introduced.

Provisioning checkpoint 3f722da is committed and pushed to origin/main. The subsequent
baseline-preparation code/docs remain local and uncommitted. Docker remains running.
Existing APIs, formats, frozen fixtures and every store/journal history are preserved.
Next: design retained source exclusion and conditional first-enrollment append/uncertainty;
a read-only diagnostic check cannot authorize a later write across an unprotected gap.
