# Application-Authority Journal Format and Commit Contract Version 1

Date: 2026-10-29. EP7-B specification under [ADR-029](../ADR-029-separate-application-authority-journal-v1.md).
This is a new host-only format. Pure codec/full-history validation is now implemented; see
[codec evidence](M2_APPLICATION_AUTHORITY_CODEC_VALIDATION.md). Root provisioner, journal writer,
admission adapter and application executor remain pending. Metadata examples are not authority.

## 1. Scope, Root Roles and Ownership

The [internal pilot contract](M2_EMBEDDED_PILOT_AUTHORITY_CONTRACT.md) remains controlling:
one cooperative process, complete controlled writer/publisher/ingress scope, stopped reopen,
ProcessCrash only, no external queues and no automatic dispatch/retry/write resume.

The dedicated authority root has exactly three regular files, each with one link and no
symlink/reparse-point role: authority.lock (zero
bytes, stable ownership inode), authority.meta (112 bytes), authority.log (bounded full history).
Reject extra/missing roles, links, unsupported aliases, overlapping/nested protected roots or
unbounded inventory. Administrative host root keeps its existing owner.lock/host.meta/journal.bin.
No application role is inserted into it or a store/artifact/candidate/workspace root.

Trusted deployment configuration supplies canonical deployment/resource keys, administrative
root key, authority root key, expected administrative journal ID and, on existing opens, expected
authority ID. Do not discover a replacement root/ID from arbitrary files or choose a new empty
root to reset work. Root keys are configured logical identity bindings, not a claim that string
equality detects filesystem aliases. EP7-C must qualify physical placement and stable identity.

Acquire administrative ownership first, then its new opaque application child mode, then the
stable authority owner. Bind the child/session to this exact pair; admit no work on partial
acquisition. Hold metadata/log identity handles and both owners until all real children finish;
release in reverse. Never unlink/replace an active lock. The new child mode must exclude admin
publication dispatch, EP6 stopped registration and incompatible application/selection operations;
it is not an EP6 registration or a Boolean substitute. Runtime lock ordering and drain must be
qualified before implementing admission. No filesystem ownership is established by a codec.

## 2. Canonical Primitives and Bounds

Integers are unsigned little-endian. GUIDs are exactly 16 RFC 4122/network-order bytes, not
Guid.ToByteArray default mixed-endian bytes. SHA-256 values are 32 raw bytes. Every GUID field
is nonempty. There is no implicit padding, serializer envelope or unchecked length arithmetic.

A TLV is UInt16 tag, UInt32 byte length, then exact value bytes. Tags must strictly increase.
Unknown, duplicate, missing, out-of-order, zero-length or wrong-size fields fail closed; optional
absence means omission. Nested records are exact bounded canonical TLVs with no trailing bytes.
Every schema below lists the only permitted fields. Lengths/remaining bytes are checked before
allocation/slicing; stream decoding must handle short reads and never read an oversized payload.

Strings are strict valid UTF-8 without BOM, NUL or unpaired surrogates, nonempty and not whitespace
only, at most 4,096 encoded bytes. Do not normalize Unicode, case or paths during decoding.
Configured keys compare exact canonical bytes. Reject source/candidate root or admission key
collisions using .NET 10 OrdinalIgnoreCase as an additional conservative shape check; this is
not an alias proof. A later physical verifier must reject unsupported aliases independently.

| Limit | Version 1 bound |
|-------|-----------------|
| Metadata | Exactly 112 bytes |
| Frame payload | 65,536 bytes maximum, positive |
| Complete log | 67,108,864 bytes maximum, including envelopes |
| Frames | 65,536 maximum |
| Accepted work IDs | 1,024 maximum across both branches, never reusable |
| Enrollment / candidate | Exactly one first enrollment; at most one candidate |
| Initial source/candidate H | 0 through 10,000, equal across registered roots |
| Strings | 4,096 UTF-8 bytes each |

These persistent bounds are explicitly chosen here; EP7-A's input limit did not establish a wire
format. Cumulative limits apply before buffering/enumeration/allocation. Reaching a bound refuses
further append without deleting history. Checked sequence/revision/generation arithmetic rejects
overflow. There is no reset, rotation, compaction, new-baseline event or prefix adoption.

## 3. Metadata: BXAM0001

| Offset | Field | Bytes |
|--------|-------|-------|
| 0 | ASCII BXAM0001 | 8 |
| 8 | Authority GUID | 16 |
| 24 | Administrative journal GUID | 16 |
| 40 | Configured scope digest | 32 |
| 72 | Durability wire value, exactly 1 (ProcessCrash) | 2 |
| 74 | Flags, exactly zero | 2 |
| 76 | Reserved, exactly zero | 4 |
| 80 | SHA-256 of bytes 0 through 79 | 32 |

Scope digest is SHA-256 of the concatenated canonical TLVs: tag 1 deployment, tag 2 resource
scope, tag 3 administrative root key, tag 4 application-authority root key. No terminator or
outer length is added. Trusted configured IDs/scope/policy must match exactly; checksum-valid
foreign metadata rejects. There is no implicit authority discovery or policy fallback. This
metadata neither enrolls a source nor asserts zero accepted work or a fresh deployment.

## 4. Frame Envelope: BXAJ0001

| Offset | Field | Bytes |
|--------|-------|-------|
| 0 | ASCII BXAJ0001 | 8 |
| 8 | Version, exactly 1 | 2 |
| 10 | Flags, exactly zero | 2 |
| 12 | Payload length N | 4 |
| 16 | Global sequence, first 1, exact increment | 8 |
| 24 | Authority GUID matching metadata | 16 |
| 40 | Previous frame digest; zero only for first frame | 32 |
| 72 | Metadata digest: metadata bytes 80 through 111 | 32 |
| 104 | Canonical payload | N |
| 104 + N | SHA-256 of bytes 0 through 103 + N | 32 |
| 136 + N | ASCII AJEND001 | 8 |

Total length is 144 + N. Previous digest means the preceding frame's stored/computed SHA-256,
not SHA-256 of the entire sealed frame. Both exact predecessor and metadata digest are mandatory.
No searching ahead, partial-prefix success, trailing bytes or implicit minor version is allowed.
A complete empty log is structurally representable but contains no enrollment or executable state.
Metadata/chain hashes detect damage; they provide no authentication, newest-head or flush proof.

## 5. Common Payload and Root/Publication Records

All eight common tags are required on every frame:

| Tag | Meaning | Encoding |
|-----|---------|----------|
| 1 | Event kind | 1 byte, explicit mapping below |
| 2 | Current owner session | GUID |
| 3 | Current owner generation | UInt64, positive |
| 4 | Immutable baseline ID | GUID |
| 5 | Resulting selection revision | UInt64, positive |
| 6 | Resulting selected branch | 1 byte: source 1, candidate 2 |
| 7 | Evidence commitment | SHA-256, 32 bytes |
| 8 | Event-specific data | Nested TLV |

Evidence commitment binds externally retained, scoped operational proof selected by the host.
It is not a Boolean permission, signature or independently validated fact. The codec cannot
verify such proof, determine an OS owner, acknowledge a historical save or enable admission.
Its exact evidence dossier/retention verification belongs to the consuming host in EP7-D.

Root binding fields: 1 kind (1 legacy format-1, 2 format-2 ScalarWal), 2 canonical root key
(string), 3 admission identity key (string), 4 document ID (UInt64, positive), 5 initial H
(UInt64), 6 initial complete-history commitment (32 bytes), 7 epoch identity (optional nested
record: tag 1 StoreId GUID, tag 2 EpochId GUID). Tags 1 through 6 are required. Legacy omits
7; ScalarWal requires it. Do not fabricate legacy epoch IDs. History commitments exclude runtime
lease/lock files and use the established verified data-history definition; no new store bytes.

Candidate must be ScalarWal, preserve source document/H and have different root/admission keys.
If source is ScalarWal, both destination StoreId and EpochId differ from source. Bind the actual
source and candidate initial histories separately; digest equality is not required. Root binding
digest means SHA-256 of this exact canonical root TLV sequence, with no outer field header.

Publication pin fields (all required): 1 kind (1 LegacyMigration, 2 IndependentEpochRestore),
2 operation/attempt GUID, 3 sealed artifact inventory SHA-256, 4 administrative frame sequence
(UInt64, positive), 5 administrative head digest (32 bytes), 6 canonical artifact root key
(string), 7 canonical published bundle root key (string), 8 artifact BackupId GUID. Kind 1
requires legacy source; kind 2 requires actual ScalarWal source identity. These bytes bind
an observed exact operation, not an actual acknowledged receipt or routing authority. Physical
artifact/bundle/root correlation and both verification oracles remain external requirements.

## 6. Events and Complete-History Validation

Wire mappings are independent of EP7-A/C# enum ordinals: 1 Enroll, 2 RegisterCandidate,
3 Select, 4 AcceptWork, 5 WorkOutcome, 6 ObserveReconciliation, 7 TransferOwner. Every other
value, including zero, rejects. Replay the complete bounded history with one baseline/source,
optional candidate, owner tuple, selection tuple and retained map of every work ID.

| Event | Event-data schema | Required transition |
|-------|-------------------|---------------------|
| Enroll (1) | tag 1 source root binding | First/only enrollment; sequence 1, generation 1, selection revision 1 and source selected; establish immutable baseline/source |
| RegisterCandidate (2) | tag 1 candidate root binding; tag 2 publication pin | Only once, before any acceptance; preserve owner, baseline and selection; validate root/pin shape and preserved document/H |
| Select (3) | tag 1 previous selection revision UInt64; tag 2 previous branch byte | Candidate registered; match previous selection exactly; change to the other registered branch and increment selection revision exactly once; zero work accepted anywhere since enrollment |
| AcceptWork (4) | tag 1 fresh work GUID; tag 2 intent SHA-256; tag 3 selected root-binding digest | Candidate registered, unique work ID, exact unchanged current selection and matching root digest; no unresolved prior acceptance; retain a new pending obligation |
| WorkOutcome (5) | tag 1 work GUID; tag 2 intent SHA-256; tag 3 acceptance frame sequence UInt64; tag 4 outcome byte | Exact pending acceptance from current owner, no earlier WorkOutcome; unchanged selection; retain outcome without removing acceptance |
| ObserveReconciliation (6) | Schema below | Explicit scoped observation; no historical acknowledgment or executable authority |
| TransferOwner (7) | tag 1 previous owner session GUID; tag 2 previous generation UInt64 | Match prior tuple; distinct new session and exact generation +1; preserve baseline, selection, candidate and every obligation/outcome |

Each data field listed in a row is required; all others reject except the explicitly optional
observation fields below. All events other than TransferOwner retain the current owner tuple.
All except Select retain selection revision/branch. Every event retains baseline ID. A second
Enroll, second candidate, changed root/pin, reused work ID or owner transfer over empty history
rejects the whole log. No event erases earlier terminal evidence or changes a work's intent,
target, acceptance sequence, selection revision or original accepting owner.

AcceptWork derives its target and selection revision from the current registered selection;
store that immutable association in replay state. Counts derive from every retained acceptance,
never from mutable summary fields. Completed and no-effect work remain counted forever. For
this conservative pilot any accepted work forbids later Select, even if all work is finished.
Future rebaselining requires a separate design; it cannot be encoded as a new enrollment here.

WorkOutcome wire values: 1 Committed, 2 NoEffect, 3 Unknown. Unknown preserves unresolved state;
Committed/NoEffect are terminal. No WorkOutcome can follow a previous WorkOutcome, including
Unknown. After process/owner change or an Unknown marker, resolve only via explicit observation
with fresh independent evidence. A missing outcome is unresolved too. AcceptWork requires all
prior obligations terminal; it never retries/replays a pending request. Distinct work IDs do not
provide business idempotency. Live mutation still requires a qualified acknowledged acceptance.

ObserveReconciliation data fields: 1 kind (1 SelectionObserved, 2 WorkCommitted, 3 WorkNoEffect,
4 WorkStillUnknown), 5 current selection revision UInt64, 6 current branch byte. Tags 1/5/6
are always required and must match current selection. Tags 2 work GUID, 3 acceptance sequence
UInt64 and 4 intent digest are required exactly for kinds 2/3/4 and forbidden for kind 1.
Work observations match an existing exact acceptance. Kinds 2/3 may terminally resolve a pending
or Unknown obligation, retaining all old records; they cannot contradict or replace an existing
terminal result. Kind 4 leaves an unresolved obligation unresolved and cannot downgrade terminal
work. Repeating an agreeing terminal observation is allowed; conflicting terminal facts reject.
SelectionObserved never increments selection revision or selects another target.

Observation evidence digests are references, not independent proof of database effects. H advance,
equal payload, provenance match or process exit alone cannot identify the specific accepted work.
A valid frame does not imply its append returned successfully. In particular, replay must not
populate EP7-A's SelectionAcknowledgmentKnown merely because Select/SelectionObserved is present.
An explicit fresh acknowledged reconciliation decision and continuing operational facts are
separate consuming-host prerequisites; no old acknowledgment is fabricated.

## 7. Explicit Provisioning and Conditional Commit

No writer/provisioner is implemented by this specification. EP7-C must implement and qualify:

1. Establish trusted scope, prior-work/executor exclusion and closed ingress under real retained
   administrative ownership/new child mode. Require configured absent authority root and distinct
   protected paths. Never treat an existing incomplete directory as freshly owned workspace.
2. Use no-overwrite creation. Directory creation alone is not exclusive; CreateNew authority.lock
   plus continuous exclusive owner handle must establish cooperative ownership before metadata/log
   writes. Retain failed partial state. A loser cannot delete/recreate roles or complete a winner's
   root. No backup-restore cleanup capability applies to authority history.
3. Create exact metadata and an empty log without overwriting any inode. Flush created files and
   validate exact contents/identities before acknowledging provisioning. ProcessCrash namespace
   survival across real process termination must be qualified; no native directory-fsync, power-loss
   or network filesystem claim follows. Unsupported stronger policies reject without fallback.
4. Only the same successful live initializer, with original handles still held, may attempt first
   enrollment after proving the real operational baseline. Reopened empty/partial roots stay stopped
   and have no first-write permission; this version defines no automatic repair or re-enrollment.

For append, compare expected authority ID, metadata digest, global sequence/digest, owner tuple,
baseline and selection with the exact current confirmed position under one serializer. Revalidate
stable file identities, complete history and EOF. Construct/validate a whole bounded next frame
in memory before attempting output. Refuse stale state without content writes. Write exactly at
EOF, perform FileStream.Flush(flushToDisk: true), then exact frame readback plus identity/length
validation. Only then publish the new live confirmed position and return acknowledgment.

A qualified accepted return is required before database invocation or telling the caller work
was accepted. No database I/O, artifact inspection, user callback or executor runs under journal/
lifetime locks. The actual owner-bound operation registration survives those unlocked gaps and
caller timeout/cancellation. Select additionally requires closed ingress/admissions, actual drain,
no active publisher, continuing writer exclusion and fresh exact root/publication readiness.

Any exception after output begins, including write/flush/readback/acknowledgment uncertainty,
faults the authority session and closes paired application/administrative admissions. Prevent
new dispatch, selection and work. Existing actual executors remain registered through completion;
do not dispose ownership or label them canceled merely because the append caller failed.
Do not rearm, replay, overwrite, truncate, scan past damage or continue from a plausible prefix.
A future operation after reconciliation needs new explicit authority; bytes are retained.

## 8. Restart, Damage, Rollback and Retention

Acquire owners in order with admissions closed. Validate metadata against trusted configured
IDs/scope, strict roles and the entire bounded log. Incomplete final frames, corrupt checksums,
illegal transitions, wrong identities, unknown fields and extra bytes fail closed with no repair,
cleanup or returned adopted prefix. A valid empty or complete prefix is structural evidence only.

Discard old live plans, registration tokens, selection/work execution handles and readiness.
Replayed accepted work is an obligation, never a task to execute. Reconcile publication, actual
roots, retained work and selection under independently fresh exclusion before considering a new
workflow. Unknown/missing/contradictory facts keep both branches stopped. No automatic route change,
writer resume, receipt synthesis, source path replacement or rollback is permitted.

A hash chain and lease do not detect coherent offline rollback of all files or prove complete
pre-enrollment work accounting. Trusted deployment control excludes unattended authority/admin/data
replacement or restore. Uncertain freshness requires independent reconciliation, not a flag inferred
from clean bytes, zero work records, matching H or an unlocked owner file. These limits remain even
when codecs and process tests pass. Retain both journals and all source/candidate/WAL histories;
CanReclaim=false. No deletion, pruning, abandoned-root cleanup or lease-based reader-absence inference.

## 9. Independent Examples and Implementation Sequence

Two new 112-byte metadata-only vectors and their pinned manifest/reference script live under
tests/TestData with the pilot-authority prefix. They use Python struct/uuid/hashlib only and
never call a production encoder. One scope is ASCII and one includes non-ASCII UTF-8. These
are not enrolled journals, full authority roots, store artifacts or evidence of live permissions.
No complete-frame/history golden vector is claimed in this specification step.

The next implementation is the pure application-authority codec and complete-history validator,
with independent full-frame/history vectors and malformed/overflow/short-read tests. It must not
open files, create roots, validate real host facts or expose execution authority. Qualify canonical
GUID/TLV/hash bytes and every transition above before EP7-C owned persistence/provisioning.
EP7-D actual consuming host, public/release, archived readers and physical durability remain open.

[Specification validation](M2_APPLICATION_AUTHORITY_FORMAT_VALIDATION.md) records exact checks,
metadata hashes and the unchanged 2,013-case Windows source baseline; no new runtime test claim.

Codec follow-up (2026-10-29): [validation](M2_APPLICATION_AUTHORITY_CODEC_VALIDATION.md) adds
four independent frame/history vectors and strict full-history decoding. The preceding original
specification-step evidence retains its scope. Unknown-work observations, like Unknown outcomes,
require explicit reconciliation before any direct terminal outcome; no old acknowledgment is
recreated. No wire layout/mapping changes. Next EP7-C lifetime/ownership before persistence.

EP7-C existing-root follow-up (2026-10-29): [ADR-030](../ADR-030-paired-read-only-application-authority-ownership.md)
and [validation](M2_APPLICATION_AUTHORITY_LIFETIME_VALIDATION.md) implement actual paired
read-only ownership/inspection with native identity and actual drain. Explicit provisioning,
initializer-only first enrollment and append remain pending; empty reopen stays stopped.

EP7-C provisioning follow-up (2026-10-29): [ADR-031](../ADR-031-application-authority-provisioning-and-initializer.md)
and [validation](M2_APPLICATION_AUTHORITY_PROVISIONING_VALIDATION.md) add separate absent-root
creation and a live-only read-only initializer reservation. Actual provisioning process
interruption, acknowledgment-loss and independent-creator qualification now pass on Windows
and isolated Linux. Real baseline binding and first-enrollment persistence remain pending.
No format changes.

First-enrollment preparation follow-up (2026-10-29): [ADR-032](../ADR-032-owner-bound-first-enrollment-preparation.md)
and [contract](M2_APPLICATION_AUTHORITY_ENROLLMENT_PREPARATION.md) bind a proposed Enroll entry
to real frozen legacy data and supplied operational assertions. The entry is validated only
in memory; no new bytes, append or acknowledgment are published. Existing v1 layouts remain.

Retained-source/first-append design follow-up (2026-10-29):
[ADR-033](../ADR-033-retained-source-exclusion-and-first-enrollment.md) specifies a
separate guarded initializer and one existing-v1 Enroll frame, with no wire or role changes.
EF1-EF4 are unimplemented; current preparation remains read-only and all writers stay stopped.
