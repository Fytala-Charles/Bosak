# HA1 Conditional Transition Harness Validation

Date: 2026-10-28. Internal protocol evidence under
[ADR-021](../ADR-021-host-attempt-ledger-and-publisher-exclusion.md) and the
[host ledger contract](M2_HOST_ATTEMPT_LEDGER_CONTRACT.md).

## 1. Implemented Protocol Model

HostAttemptLedgerHarness stores one request/attempt entirely in memory. It accepts an initial
revision-one record only from valid supplied evidence, keeps immutable snapshots and retains
every committed revision. One lock models atomic conditional updates; each operation requires
the exact current snapshot, including request, descriptor, revision and owner. A successful
transition increments the revision. Conflicts and rejected transitions leave history unchanged.
History returns a copied array of immutable records. There is no global request/path registry.

Supported transitions record intent, authorize dispatch once, mark uncertainty, retain a
separately supplied actual receipt, save a known-operation observation, reconcile absence and
model ownership transfer. DispatchAuthorized cannot reauthorize the same attempt. ObservedKnown
has no acknowledged receipt unless a separately supplied matching receipt is later recorded.
Known publication/acknowledgment survives takeover and cannot be changed into absence. Absence
reconciliation never rearms a plan; a fresh library-generated attempt must be separately prepared.

Takeover requires supplied fresh authoritative transfer, exclusion of every prior publisher,
drained queues, stopped database writers, a new owner session and increasing generation.
Changing a token/lease alone does not satisfy these facts. Revisions reject stale owner updates;
they cannot prevent an old executor publishing through the existing filesystem pipeline.

BeforeCommit throws before state/history changes. AfterCommit changes both then throws to model
acknowledgment loss. An explicit read distinguishes these test cases. Repeating the original
conditional update after an applied commit conflicts; a fresh snapshot still cannot authorize
the same attempt twice. No exception is converted into automatic retry, acknowledgment or a
negative publication result. No callbacks or executor actions run under the model lock.

The shared classifier exposes internal context/receipt shape checks; its original decision
semantics are unchanged and all 180 model tests plus 80 HC1 tests are rerun. All new types
remain internal. Every harness outcome keeps writers stopped; no return value is an execution
permit. Supplied facts/receipts are trusted test inputs, not authenticated host evidence.

## 2. Executed Qualification

83 new cases cover all seven modeled commits at no fault/before/after boundaries (21),
concurrent intent/authorization/receipt-versus-observation races (three), unsafe transfers
(11), stale owners and retained publication after transfer (three), terminal-state preservation
(three), invalid authorization evidence (12), wrong receipts (seven), immutable snapshots and
empty restart (one), unsafe absence (nine), invalid observations (six), invalid initial records
(six) and concurrent transfers (one). Synchronized eight-worker races produce exactly one
conditional winner. Faults are deterministic exceptions, not process/power failures.

Focused Windows Debug and isolated Linux Release validation passes 414 cases/platform:
343 Storage (83 harness + 180 model + 80 HC1) and 71 Integration (28 RC1 + 31 RC2 + 12 RC3).
The integration suite exercises real planned publication/process behavior, but is not yet wired
to this in-memory harness. This is not a full-suite run; previous full/fault evidence keeps its
original scope. Native RC2 cases run on Linux and assert unsupported policy on Windows;
the 12 RC3 cases use ProcessCrash on both hosts. SDK remains 10.0.301.

Formatting and strict documentation/hidden-link portability checks pass on Windows and Linux.
Public Storage metadata remains 95 signatures with no additions/removals against the frozen
local baseline. Existing frozen fixtures and provenance remain unchanged. No new persistent
record layout, database dependency, public API, release or package is introduced.

## 3. Limits and Next Work

This harness has no persistence, codec, durable-commit semantics, filesystem/network I/O,
executor dispatch, owning Open, routing or effective fence. A new instance is empty; snapshots
cannot reconstruct executable plans or prove restarted authoritative state. Fault injection
models atomic in-memory transitions only, not torn writes, power loss or rollback protection.
It does not serialize resource aliases or coordinate multiple harness instances/processes.
Actual host/backend selection and HA2 integration remain open. CanReclaim=false.

Next bounded work: integration tests that bind modeled ledger transitions to actual owner-bound
planned execution, including lost authorization/receipt-save acknowledgments and explicit read
reconciliation. Keep these test-only and distinguish modeled commits from durable host storage.
No production orchestration, descriptor replay or automatic retry is authorized by this evidence.
Changes remain local and uncommitted.

[Machine evidence](m2-host-ledger-transition-results.json).
