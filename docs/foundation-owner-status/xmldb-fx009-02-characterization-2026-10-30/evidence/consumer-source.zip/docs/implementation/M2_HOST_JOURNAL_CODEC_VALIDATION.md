# EP2 Internal Host Journal Codec Validation

Date: 2026-10-28. Pure internal codec under [ADR-023](../ADR-023-bounded-embedded-host-journal-contract.md)
and the [journal contract](M2_EMBEDDED_HOST_JOURNAL_CONTRACT.md). No journal writer or host
ownership/persistence implementation is introduced.

## 1. Implemented Boundary

HostJournalCodec and its two partial source files encode/decode exact 88-byte scope-bound
metadata, 72-byte frame headers, 112+N total frames and canonical nested TLV snapshots.
Explicit wire mappings avoid runtime enum ordinals; GUIDs use network-order bytes and all
integers are unsigned little-endian. SHA-256 binds metadata and each frame's header/payload,
with exact sequence, journal ID and previous-digest checks across the complete journal.

Strict decoding validates lengths before slicing/allocating and checks payload, journal,
frame/attempt and UTF-8 byte bounds. Duplicate, unknown, missing, reordered, empty or malformed
fields fail closed. Invalid UTF-8, BOM/NUL, whitespace-only strings and unpaired surrogate
encoder inputs reject. Source identities, H, profile/policy and actual receipt/observation
bindings are checked separately from the declared event/stage. Stronger durability is rejected.

History replay preserves immutable attempt descriptors, per-attempt revision/owner rules and
receipt/observation history. Illegal stage edges, duplicate IDs, stale owners, contradictory
publication, wrong request/scope and loss of retained evidence reject the whole input. Version 1
conservatively permits same-request retries only after the prior attempt reached ReconciledAbsent
with identical input and destination (apart from fresh attempt ID). Independent-destination
reasoning is absent from this schema; it cannot be invented by replay.

Caller-owned streams may be non-seekable and arbitrarily short-reading. The codec never opens
files, seeks, closes the caller's stream, writes, repairs, truncates, dispatches or creates a
plan. Incomplete/corrupt tails throw without returning an adopted prefix. Structurally valid
whole prefixes and empty journals remain possible; every read result keeps writers stopped.
Hash chains supply no authentication, anti-rollback anchor, flush/acknowledgment proof or fencing.
Root placement/provisioning, exclusive ownership and durable append remain EP3/EP4 requirements.

## 2. Independent Vectors and Tests

Four new host-only vectors were authored with a separate Python struct/uuid/hashlib reference,
without invoking the production encoder: metadata (88 bytes), legacy intent (386), restore
intent (450), and a four-event chain (1,544). Their pinned byte lengths/SHA-256 and input scope
are in tests/TestData/host-journal-fixtures-v1.json. Tests decode exact expected identities and
compare encoder bytes to those independent vectors. These are new host fixtures, separate from
the 15 existing frozen metadata fixtures and four reader DLLs; none of those were changed.

117 new cases cover independent bytes (four), every truncated frame/tail position (one looping
case), non-seekable short reads (five), malformed envelopes (13), well-sealed malformed TLVs
(24), valid role/event history paths (16), invalid complete histories (23), cumulative/attempt
bounds (one), strict UTF-8 boundaries (six), metadata corruption/trusted scope (eight), and
well-sealed receipt/observation binding mismatches (16). Limit tests accept exactly 1,024
attempts then reject 1,025, reject oversized declarations before reading payload, and reject
oversized byte-array journals. No process kill, actual durable append or controller loss test
is claimed for the codec.

Final focused Windows Debug and isolated Linux Release runs pass 697 cases/platform:
592 Storage (117 codec + 343 ledger/restart + 132 existing backup/migration codecs), and
105 Integration (34 ledger/planned execution + 71 RC1/RC2/RC3). SDK is 10.0.301. The integration
suite exercises existing process/native branches at its original scope; all newly added codec
cases execute on both hosts. This is not an unfiltered full-suite run. Earlier broad/fault
reports retain their dated scope.

All 168 prior non-build runtime/test/fixture files are SHA-256 unchanged. Only three new internal
codec files, one test file and the five new vector/manifest files were added. Public Storage
metadata remains 95 signatures with no additions/removals against the frozen local baseline.
Formatting, strict docs and actual hidden/link portability checks pass on Windows and Linux.
Proprietary licensing, dependency pins, frozen store layouts and disabled packaging are unchanged.

## 3. Remaining Work

EP2's pure codec is implemented internally. Next EP3 implements a stable existing-host-root
lifetime lease with explicit provisioning boundaries and actual cooperative process contention,
crash-release and admission-drain tests. Do not silently initialize/repair unknown roots or
conflate a free lock with global exclusion. EP4 must separately qualify actual journal writes,
flush errors, partial tails and stopped reopen; EP5 binds the real owned host to execution.
HA2 application route/work, archived compatibility, public/release, physical durability and
retirement gates remain open. CanReclaim=false. This step and the EP2 design remain local
and uncommitted; the pushed baseline is 2141eac.

[Machine evidence](m2-host-journal-codec-results.json).
