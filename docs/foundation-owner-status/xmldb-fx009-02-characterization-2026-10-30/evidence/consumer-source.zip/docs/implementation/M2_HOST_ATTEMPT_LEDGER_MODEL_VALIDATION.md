# HA1 Host Ledger Decision Model Validation

Date: 2026-10-28. Internal supplied-evidence model under
[ADR-021](../ADR-021-host-attempt-ledger-and-publisher-exclusion.md) and the
[host ledger contract](M2_HOST_ATTEMPT_LEDGER_CONTRACT.md).

## 1. Implemented Boundary

HostAttemptLedgerClassifier is a pure internal classifier. Immutable records bind request ID,
deployment/resource scope, full attempt descriptor, ledger revision and owner session/generation.
Ledger, ownership, publication and workflow evidence must independently match that context.
Revision/owner changes and stale facts require fresh observations. Missing, malformed or
contradictory facts never produce dispatch or retry eligibility.

Confirmed durable intent, a live original executor/plan and an unstarted invocation can be
eligible for first authorization. DispatchAuthorized never authorizes replay. A timeout, lease
generation change or absent candidate while a publisher/queue remains reachable cannot qualify
retry. Fresh absence under supplied exclusion can qualify a new attempt only after the original
executor and executable plan are gone. Recorded first authorization remains distinct from retry.
Prior publication knowledge is never erased by absent or unknown later observations.

A declared known match must bind actual publication role, attempt/backup/source/destination
identity, H and store path. Independent restore requires distinct source/destination store and
epoch IDs. A persisted acknowledged receipt is checked separately against the descriptor and
observed destination; a match never creates a receipt. Route acknowledgment loss and unknown
work accounting remain separate stopped outcomes.

Every output has WritersMustRemainStopped=true. No result contains a plan, callback or executable
permit. Supplied durable/authoritative/exclusion/freshness facts are assumptions, not verified
host facts. Resource keys are opaque host-defined canonical names; only lexical store-path
comparison is performed. No path resolution, filesystem/network I/O, serialization, persistence,
dispatch, owning Open, route change, recovery, automatic retry or history deletion occurs.
The classifier does not implement revision CAS or establish a global fence.

## 2. Executed Tests

The 180 new Storage cases cover all 24 contract scenarios, 68 independent evidence-component
binding mismatches, 18 malformed contexts, 29 missing/stale/untrusted fact cases, 14 mismatched
receipt/observation bindings, three acknowledged-state observations, two conflicting prior
publication cases, four surviving executor/plan combinations, nine restore identity cases,
eight original-owner/plan/unstarted combinations and one explicit first-authorization/absence case.
These are model tests; the contract scenarios' real persistence/fencing fault tests remain open.

Focused validation passes 331 cases per platform: 260 Storage (180 model plus 80 HC1) and
71 Integration (28 RC1, 31 RC2, 12 RC3). Windows uses Debug; isolated network-disabled Linux
uses Release with SDK 10.0.301. RC3 executes ProcessCrash on both hosts; RC2 stronger-policy
rows execute natively on Linux and assert unsupported policy on Windows. These counts are
not a new unfiltered full-suite run. Earlier full/fault reports retain their original scope.

Public Storage metadata remains 95 signatures with no additions/removals against the frozen
local baseline. All 163 prior non-build runtime/test/fixture files are SHA-256 unchanged;
only the classifier and its tests were added. Frozen local binaries remain local evidence,
not archived-release qualification. Formatting, strict documentation and actual hidden/link
portability checks pass on Windows and Linux. No packaging or release gate is closed.

## 3. Remaining Work

Actual consuming host, durable backend/commit semantics, executor and queue inventory, effective
publisher fence, route revision and accepted-work authorities remain unselected/unqualified.
HA1's supplied-evidence model is implemented; HA1 actual-host selection and HA2 integration
remain open. A lease change still cannot fence the current publication path.

Next bounded repository work: a conditional-transition harness for revision-checked intent and
dispatch decisions, including lost-acknowledgment and concurrent-owner tests. Keep it internal
and in memory; distinguish its protocol evidence from real durable persistence/fencing.
RC2/RC3, the HA1 contract and this model remain local and uncommitted.

[Machine evidence](m2-host-attempt-ledger-model-results.json).
