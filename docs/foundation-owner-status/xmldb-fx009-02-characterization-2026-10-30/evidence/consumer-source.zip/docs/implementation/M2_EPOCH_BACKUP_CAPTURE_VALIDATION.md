# M2 ET9-B Epoch Backup Capture Validation

Date: 2026-10-27. Implements internal capture in
[ADR-017](../ADR-017-epoch-full-history-backup-and-independent-restore.md); see
[runtime contract](M2_EPOCH_BACKUP_CAPTURE.md). Metadata1.0/store formats, frozen fixtures,
public APIs, proprietary license and package pins remain unchanged. No restore is added.

## New capture evidence

Forty Storage and five Integration cases cover:

- H=0/1/3 capture with exact complete closure and source/data byte equality; all seven
  capture stages; source advance after capture leaves the artifact fixed at H.
- Old uncached snapshots, owner-disposal lifetime, operation admission before gate, safe
  disposal-race cleanup, and a contending commit advancing only after capture publication.
- Recognized private source debris retained/excluded; unknown root/.epoch/generation or
  empty-directory dependencies, missing/stale CURRENT, missing generation, incomplete WAL
  and fragment corruption refuse without source repair and fault the owner.
- Root/child/parent/existing destination refusal without owner fault/overwrite; Linux
  source/output link rejection. The link branches return explicitly on Windows.
- All seven selected capture checkpoint exceptions, preserving source/old-reader data.
  A failure after publication retains a valid artifact; earlier failures leave no final path.
- Read-only sealed artifact rejection for missing WAL/generation/CURRENT, extra files,
  empty directories, case substitutions, corrupt completion/payload and a validly resealed
  incomplete inventory. Missing data is never excused by redo or runtime file creation.
- A fully resealed changed operation with consistent hashes passes closure/header reading
  but fails complete-history validation. A hash-consistent payload with unused extra bytes
  preserves logical values and passes the complete oracle, then fails exact deterministic
  redo. These separate regressions prove both private oracles are necessary.
- Fresh-process normal capture and kills after copy, completion, publication and returned
  acknowledgment. Only a published complete artifact is at the final path; source bytes
  and its H=3 header/line updates survive repeated open.
- Native Linux stronger-policy capture with old reader handles alive and both oracles.
  This branch does not execute on Windows and does not claim hardware durability.

Exact source/backup bytes are compared; no source or sealed artifact is opened for repair.
The two private clone roots own newly created admission/runtime identities. Unpublished
failure workspaces are retained, not guessed to be routable stores. Capture remains internal.

## Full regression results

| Platform | Storage | Xdm | Integration | Total | Failed / skipped |
|----------|---------|-----|-------------|-------|------------------|
| Windows | 470 | 27 | 117 | 614 | 0 / 0 |
| Ubuntu24.04.4 / overlayfs | 470 | 27 | 117 | 614 | 0 / 0 |

Final TRX: .tools/et9b-windows-results and .tools/et9b-linux-results.
[Structured evidence](m2-epoch-backup-capture-results.json) records case counts and scope.
Existing 2,162 Windows /2,579 Linux fault positions (481 native ET8 Linux positions) remain
regression evidence. They are not new exhaustive capture/restore fault sweeps. Three new
ET9-B Linux-only branches return on Windows: two link cases and native strong capture.

SDK10.0.301; Windows dotnet runtime10.0.11; Linux runtime10.0.9 in the pinned isolated image,
source/cache read-only and network disabled. Formatting and strict documentation checks pass.
Known MINVER1001 warnings may occur in unversioned/isolated builds. No commits/publication,
source-root replacement, migration, reduced-history backup or reclamation is performed.

## Reproduce and limits

```powershell
dotnet test Bosak.XmlDb.slnx -c Release --no-restore --logger 'trx;LogFilePrefix=windows' --results-directory .tools/et9b-windows-results
$env:DOTNET_ROLL_FORWARD = 'Major'
& ./.tools/pwsh.exe -NoProfile -File tools/test-linux.ps1 -ResultsDirectory .tools/et9b-linux-results
dotnet format Bosak.XmlDb.slnx --no-restore --verify-no-changes
& ./.tools/pwsh.exe -NoProfile -File tools/check-docs.ps1 -ProjectPath . -Strict
```

ET9-B does not complete ET9. Next ET9-C implements fresh-identity rebinding and separate-root
restore bundles, preserving all H/transaction/document/node identity and data invariants.
ET9-D must exhaustively inject capture/restore storage calls, partial writes, repeated kills/
lost acknowledgment and native-platform failures. Public epoch APIs, full-history migration/
cutover, full archived-reader C1-C3 and retirement remain pending. Local process/native
filesystem evidence does not certify physical power loss, real ENOSPC, other controllers/
filesystems, malicious concurrent mutation or remote CI. Hashes do not establish authenticity.
