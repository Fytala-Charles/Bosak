# M2 Internal ET5 Scalar Epoch Commit

Date: 2026-10-27. Decision: [ADR-015](../ADR-015-internal-scalar-epoch-commit.md).
This records the ET5 boundary; [ET6 recovery](M2_EPOCH_RECOVERY.md) now extends reopen.
This internal implementation uses the existing [authority bytes](M2_EPOCH_AUTHORITY_FORMAT_V1.md)
and [mutable semantic contract](M2_MUTABLE_EPOCH_CONTRACT.md). Public mutation is pending.

## Ownership and staging

EpochScalarCoordinator acquires explicit ScalarWal admission before authority validation,
writer ownership and selection. It verifies the complete base and every retained committed
materialization. ET4 EpochEmptyCoordinator keeps its zero-only behavior. Default/public
legacy and immutable epoch entry points remain strict.

BeginRead forks shared admission before the coordinator gate and acquires a canonical
sequence-bound BXER handle. Both handles transfer to ImmutableXmlSnapshot. Owner disposal
closes only the owner's handles. Private generation loaders require exact root/profile
admission and matching FORMAT; they do not introduce nested M1 FORMAT roots.

A transaction captures owner, epoch, ID, selected sequence and selected manifest digest.
ReplaceNodeValue stages one text or ordinary attribute value in memory. Empty attributes
are allowed; empty text, structural, namespace and multiple-target changes are refused.
Reads use the selected snapshot until commit. Rollback/disposal releases that snapshot.
Commit without an operation is refused. Disposed/completed contexts cannot commit.

## Publication order

1. Under the owner gate, compare owner/epoch/sequence/selected manifest with the live head.
2. Build a GUID-named private staging generation; validate all hashes and exact metadata/value transition.
3. Flush a canonical epoch/base-bound WAL record with unique transaction ID and prior WAL/manifest digests.
4. Publish the generation containing the bound GENERATION witness.
5. Publish/reuse the stable sequence reader identity; never replace or unlink it.
6. Flush and atomically replace CURRENT, update the owned head, then return the new sequence.

All writes and namespace barriers use the storage seam. Persistence/validation failures
fault the owner, which must close and reopen. Conflicts reject without creating staging
or WAL. Existing source roots, base, old generations and lease identities remain retained.

## Reopen boundary

Validate consecutive canonical WAL names, complete envelopes, epoch/role/base bindings,
unique transaction IDs, hash links, matching GENERATION witnesses, exact scalar transitions,
all required payloads and stable reader identities. Present CURRENT must match a verified
prefix. Select the latest complete WAL/materialization even if CURRENT lags or is absent;
opening does not repair that pointer. Ignore retained private staging/current/reader
publication temporaries only under their recognized naming rules; never promote or delete them.

A missing generation is unsupported until redo exists. Partial/corrupt WAL, missing
records, orphan published generations, corrupt CURRENT or mismatched witnesses fail
closed. No fallback to base, tail deletion, redo, checkpoint acceleration, epoch backup,
history migration or reclamation is provided. A thrown commit may nevertheless have
published the new complete head, including after acknowledgment loss.

Validation is bounded by 10,000 records and existing file/string limits; full-history I/O
has no performance claim. ProcessCrash remains default. Native Linux FileAndDirectoryFlush
execution is experimental filesystem evidence, not physical power-loss certification.

## Next gate

ET6: exhaustive write/flush/close/rename/barrier faults, partial WAL publication and redo,
including repeated interruption and lost acknowledgment. ET7/ET8 broader recovery/platform
proof, ET9 epoch backup/migration, C1-C3 and retirement remain pending.
