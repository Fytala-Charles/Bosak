# M2 Reader Compatibility, Backup and Retirement Protocol

## 1. Status and Scope

Design baseline per [ADR-008](../ADR-008-reader-compatibility-backup-and-retirement.md).
The format-1 backup/restore slice is implemented in [ADR-009](../ADR-009-verified-full-history-backup-and-restore.md);
see [format](M2_BACKUP_FORMAT_V1.md) and [validation](M2_BACKUP_VALIDATION.md).
[ADR-010](../ADR-010-mandatory-epoch-format-and-admission-primitives.md) implements internal
metadata-only mandatory-format and admission primitives. [ADR-011](../ADR-011-admission-owned-read-only-epoch-snapshots.md) now integrates actual
read-only XML snapshots. Epoch transactions/coordinator/backup, history migration and
retirement remain unimplemented.
Current format 1, Open overloads, full-prefix recovery and CanReclaim=false remain
unchanged. Existing evidence is in [M2 status](../../M2_STATUS.md); passing current
tests does not establish any of the new gates below.

The first implementation is verified full-history backup/restore for format 1,
with no live-store deletion. Migration and reclamation follow separately.
Names used below describe proposed records and operations, not literal file encodings
or callable methods. Freeze codecs, limits and independent byte fixtures before use.

## 2. Invariants and Trust Boundary

- Never infer old-reader absence from writer ownership, lease files or a retention report.
- The source base, committed WAL and stable lease identities stay intact throughout
  format-1 operations. Do not unlink a lock file or substitute another inode.
- Capture a fixed source sequence H and manifest hash. Successful validation must
  reproduce H and its hash, document identity, topology/order and values.
- A valid optional checkpoint cannot excuse required history corruption. FullJournal
  is the format-1 verification oracle, including when PreferCheckpoint also succeeds.
- Reopen after persistence errors; do not acknowledge unverified partial work.
- Resolve destinations independently, reject symlinks/reparse points, traversal,
  duplicate/case-colliding paths, source/destination overlap and existing destination
  contents. Do not overwrite or merge a store. Detect ancestor links as well as leaves.
- The supported environment has cooperative application processes and excludes external
  mutation during capture/restore. File hashes provide integrity checks, not authenticity
  against an administrator who can rewrite data and manifests. OS locks are not a
  security boundary. A report is stale as soon as its observation changes.

## 3. Compatibility Transition

An optional file in format 1 cannot fence older readers. Use a new root and mandatory
FORMAT major 2 for a future epoch-capable data implementation. ADR-010 now freezes the
internal metadata-only descriptor in [M2_EPOCH_FORMAT_V2.md](M2_EPOCH_FORMAT_V2.md);
ADR-011 now adds the explicit sequence-zero read-only layout/reader. Mutable epoch
recovery and history migration remain pending. All supported public open paths,
including raw ImmutableXmlSnapshot entry points, must reject unsupported major/features
before writing CONTROL, locks, reader identities or other transaction artifacts.
Verify this using archived pre-lease and current binaries, not only the new decoder.
If an old binary does not reject the candidate encoding, the transition gate fails.
Private nested paths are unsupported; new internal materialization formats must not
provide an accidental supported legacy entry point.

| State | Required operation | Interruption/retry behavior |
|-------|--------------------|-----------------------------|
| LegacyRetained | Existing format-1 store; no reclamation | All old behavior remains supported |
| Exporting | Exclusive source coordinator and commit exclusion; fixed H; new destination | Source stays authoritative; incomplete destination cannot activate |
| CandidateVerified | Independently open destination at H; compare IDs/order/values and digests | Retry verification; never fall back to partially migrated content |
| EpochReady | New-format root has published complete identity and admission protocol | Explicit application configuration switch; no automatic path replacement |
| LegacyArchived | Operator has stopped routing new work to the source | Keep source indefinitely in this scope; old snapshots can still depend on it |

Source coordinator ownership prevents cooperative writers, but does not wait for
snapshots whose coordinator was disposed. They may continue reading immutable source
files. Never rename, replace or delete their root. A configuration switch may leave
old application work alive; writes must be stopped/drained by the operator before
switching to avoid divergent histories. No automatic merge, dual writer or rollback
from a divergent new store is supported. Returning to the source after new commits
requires an explicit data reconciliation/export decision.

Internal epoch metadata now binds a random StoreId, EpochId, document identity, required
reader/writer feature contracts and reserved recovery format. Future data-path integration
must make all snapshots/transactions/backups own admission. Lease keys include StoreId/EpochId
and sequence, preventing confusion between copied/restored histories. Every snapshot,
transaction and backup holds shared epoch admission until completion, independently
of coordinator lifetime. Selection and per-generation lease acquisition occur under
admission and coordinator serialization. Epoch maintenance takes exclusive admission,
then the coordinator gate, then generation leases in ascending order; ordinary readers
must acquire admission before the gate. No code may wait for admission while holding
the gate. Process exit releases handles. Stable admission identities are never replaced.
A restore creates fresh admission/lease namespaces; no live handle transfers.

## 4. First Backup Contract: Full History at H

This is a proposed application-coordinated backup, with writes blocked for the whole
capture. It is not a recursive copy of a live mutable directory and not an online
snapshot API. The source writer lease is held throughout; the owning coordinator gate
excludes commits, checkpoints and descriptor publication. Cooperative existing readers
may continue; they cannot mutate authoritative files. Stop uncooperative/older writers
before capture. The backup operation must not dispose snapshots it does not own.

1. Recover the source through FullJournal before choosing H. Fail on required history
   corruption. Record H, document/base/current manifest hashes and supported formats.
   For a freshly imported store H=0 is valid and needs no checkpoint.
2. Construct an explicit immutable file set: original FORMAT and all base manifest,
   directory and referenced fragments; CONTROL; canonical committed WAL 1..H; complete
   validated generation materializations 1..H; a CURRENT encoding bound to H. Optional
   checkpoints/descriptors are either verified with complete dependency closure or
   omitted together. Never copy an unverified selector alone.
3. Exclude writer.lock, all readers/lease files, staging, temporary files and future
   admission/retirement OS identities. Record exclusions. Reject unknown authoritative
   formats/features; do not silently ignore an extension whose dependencies are unknown.
   Runtime locks/reader identities are recreated at restore, not restored as ownership.
4. Copy exact bytes into an exclusively created staging destination on the destination
   filesystem. The proposed sealed inventory binds BackupId, format/version, document
   identity, H, base/head hashes, sorted canonical relative paths, exact byte lengths and
   SHA-256 per file, plus an inventory digest. Bound counts/lengths before allocating.
   The inventory cannot contain machine absolute paths or a destination supplied by data.
5. Validate every copied file and dependency, then run full recovery on a disposable
   verification clone of that staged copy. Require sequence H and expected head hash;
   recovery must neither repair missing required files nor accept a lower sequence.
   Compare all persistent node IDs/topology/order and values against the captured source.
   A clone keeps verifier-created locks/rewrites out of the exact sealed file set.
6. Flush data, publish the sealed inventory and a completion record binding its digest,
   then publish the destination directory by rename within its filesystem and synchronize
   affected directories according to the selected durability policy. Acknowledgment
   follows validation and publication barriers. Never remove the source on success.

Incomplete staging is recognizable but not a backup. A completed artifact is accepted
only after inventory and content verification; a filename alone proves nothing. Disk
full, partial writes and failures after publication may leave an unacknowledged complete
artifact. A retry validates and reports its exact BackupId/H, or uses a fresh destination;
it never merges, overwrites or acknowledges a different history. Cleanup may remove
only operation-owned unpublished staging after path checks, never committed source data.

Durability is explicit per operation. ProcessCrash is the current default; stronger
native directory barriers remain Linux-only. Destination cross-volume copies stage
on the destination volume and do not rely on atomic cross-volume rename. This contract
does not claim physical power-loss certification, remote/object storage atomicity,
encryption, authenticity, incremental backup or reduced-history backup portability.

## 5. Restore and Rollback

Verify completion/inventory binding, canonical paths, sizes, checksums and absence of
unexpected data before opening any restored store. Require the exact base, complete
WAL 1..H and all declared dependencies. Reject unsupported format/features, gaps,
truncation, substituted document identity, missing fragments and a mismatched head.
Never synthesize missing authoritative bytes from CURRENT or a newer source store.

Restore into a fresh unpublished directory, create fresh OS lock/lease identities,
perform the full verification from section 4, and publish only after verification and
policy barriers. The source backup stays immutable. Existing destinations and source
roots are never replaced. Restore failure leaves no routable store and can be retried
into another new root. Applications explicitly select the restored path after success.

A format-1 restore preserves persistent IDs and commit H but is an independent mutable
branch. Simultaneous writes to source and restore are not replication. New epoch formats
must additionally assign a fresh runtime epoch while preserving recorded provenance;
backup bytes do not grant the restored process ownership of the source epoch.

## 6. Future Retirement: Generation Materializations First

No implementation is authorized to delete history based on this document alone. First
ship and prove non-deleting epoch admission and migration. Then define a separate
versioned, checksummed retirement journal with independent fixtures. Initial candidates
are redundant generation materializations in the new epoch only. Preserve the original
base, every WAL record, stable leases and independently usable recovery anchors.
WAL truncation and base retirement need a later ADR and new recovery authority.

Acquire exclusive epoch admission, coordinator gate and candidate generation leases in
the order above. Recompute the dependency closure from actual validated state, not a
saved PlanRetention result. Protect live roots, all selected/fallback checkpoint copies,
replay sources, backup capture dependencies and active snapshots/transactions. A candidate
with unknown dependencies or a failed exclusive lease stays protected.

The proposed retirement intent binds OperationId, StoreId/EpochId, expected committed
head H/hash, protected recovery anchors, canonical candidate identities and file digests.
Persist and synchronize intent before namespace removal. A prepared intent is not proof
that deletion happened. On recovery, validate identity, authority and survivors before
resuming; disagreement fails closed. Recompute protection and reacquire admission/leases
after every process restart. Never inherit a previous process's exclusivity.

| Retirement state | Required durable evidence | Recovery obligation |
|------------------|---------------------------|---------------------|
| Prepared | Valid bounded intent and independently validated survivor closure | Revalidate protection; missing candidates need matching intent, not guessing |
| Removing | Same intent; candidate removal may be partial | Repeat allowed removals only after locks and survivor validation |
| Completed | All allowed namespace changes synchronized; completion binds intent digest | Verify survivors; retain audit identity; never reinterpret new files as old candidates |

Deleted redundant generations can be rebuilt from the retained base/WAL; missing
required survivors remain corruption. Never reuse a retired generation identity/path
for different bytes. Do not unlink lease identities, even when no holder is observed.
Release maintenance admission only after the durable state is recognizable. Errors
fault the owner; reopening must yield a verified current state or fail closed, never
silently acknowledge an older head. External simultaneous loss of all recovery evidence
is outside the guarantee; redundancy is not proof against arbitrary media destruction.

## 7. Acceptance Gates Before Shipping Each Phase

| ID | Scenario | Required evidence / outcome |
|----|----------|-----------------------------|
| B1 | Capture H=0 and H>0, multiple commits and optional checkpoints | Full recovery and all node/value identities match H; source authoritative byte set unchanged |
| B2 | Capture races with commit/checkpoint and live uncached old readers | Writes serialize; backup is wholly one H; old readers keep original values |
| B3 | Every copy/write/flush/rename/barrier fails before/after, including partial writes | No false completion; source remains usable; retry and repeated restore are deterministic |
| B4 | Kill capture/restore before and after acknowledgment; interrupt verification | Only complete verified artifacts accepted; acknowledged H restored exactly |
| B5 | Corrupt inventory/completion, missing/gapped WAL, wrong head/doc/format, extra files | Reject before publishing a restored root; no silent repair or stale acceptance |
| B6 | Linked ancestors/leaves, traversal, path aliases, overlaps and existing destination | Refuse without writing outside owned staging or changing source/destination data |
| C1 | Archived old binaries against proposed mandatory format and nested public paths | Unsupported roots fail before any persistent mutation |
| C2 | New root publication killed at every boundary; application cutover fails | Original retained; incomplete candidate never routed; no automatic overwrite rollback |
| C3 | Epoch admission across processes, disposed owners and terminated holders | Shared snapshots/transactions block maintenance; holder exit releases ownership |
| R1 | Active readers/transactions/backups and stale saved retention report | Recompute closure; nothing protected removed; no admission/generation-lock deadlocks |
| R2 | Every retirement intent/deletion/completion write, flush and namespace boundary | Repeated recovery retains verified H or fails closed; missing survivors never excused |
| R3 | Corrupt anchor/intent, changed head, wrong epoch, partial removals and rebuilt candidates | Reject mismatched authority; exact identities prevent deleting different content |
| D1 | Windows ProcessCrash and native Linux stronger policy; explicit unsupported platforms | No silent fallback; state actual policy, filesystem and limitations in results |

Run unit, fault-injection and process-kill suites; retain machine-readable results,
independent byte fixtures and a cross-platform validation report. Actual bounded-volume
ENOSPC, production filesystem/controller tests and physical power-loss certification
remain separate from injected exceptions and container process kills.

## 8. Implemented Slice and Next Work

B1-B6/D1 now have experimental format-1 backup/restore implementation and evidence in
[M2_BACKUP_VALIDATION.md](M2_BACKUP_VALIDATION.md); see ADR-009 and the frozen backup
format/fixtures. Source history is retained and CanReclaim=false. No in-place marker,
source-root replacement or deletion API was added.

Internal mandatory-format/admission fixtures and partial C1-C3 evidence are implemented
in ADR-010/M2_EPOCH_VALIDATION.md. Admission-owned read-only XML snapshots are now implemented in ADR-011. ADR-012/M2_MUTABLE_EPOCH_CONTRACT.md now specifies epoch-aware authority/features
(design only). ADR-013 now implements ET1-ET3 pure codecs and frozen immutable-reader proof. ADR-014 now implements internal ET4 empty-chain coordinator/snapshot/transaction-context
ownership. Next ET5 adds scalar staging and first commit/reopen, followed by fault/replay
and history migration gates. Complete C1-C3 remain pending;
pre-lease archived binaries are unavailable. Retirement (R1-R3) remains pending. Do not
remove base/WAL prefix as part of initial generation retirement. Physical durability
and actual bounded-volume ENOSPC remain separate unproven gates.

*Last updated: 2026-10-27*

Mutable transaction design update: [ADR-012](../ADR-012-mutable-epoch-feature-and-recovery-contract.md)
defines a separate proposed profile, epoch-bound authority and admission ordering, with
[ET1-ET9](M2_MUTABLE_EPOCH_CONTRACT.md) implementation gates. No runtime behavior or
mutable/migration/retirement gate is enabled by the design.

Codec update: [ADR-013](../ADR-013-epoch-profile-and-authority-codecs.md) now implements
ET1-ET3. Parsing the 2.1 profile does not enable any mutable open/writer or pass full
C1-C3/R1-R3. The [authority format](M2_EPOCH_AUTHORITY_FORMAT_V1.md) fixes exact bytes;
ET4-ET9 runtime ownership/commit/recovery/migration remain pending.

Ownership update: [ADR-014](../ADR-014-admitted-empty-chain-epoch-coordinator.md) implements
internal ET4 empty-chain admission/writer/base-reader ownership. Nonempty histories are
still unsupported, not downgraded to base. No public mutable API, scalar commit/recovery,
complete compatibility, migration or retirement gate is enabled by this slice.

## ET9 Design Update

[ADR-017](../ADR-017-epoch-full-history-backup-and-independent-restore.md) now specifies
mutable-epoch full-history backup and independent restore, building on implemented ET1-ET8.
The [semantic design](M2_EPOCH_BACKUP_DESIGN.md) and
[candidate byte contract](M2_EPOCH_BACKUP_FORMAT_DESIGN.md) are design only. Fresh StoreId/EpochId
rebinding preserves H, transaction IDs and all XML data. A separate origin sidecar and store/
are atomically published in one restore bundle. Existing profile/backup formats are unchanged.
Next ET9-A covers codecs/fixtures; capture, restore, faults and migration remain later gates.
This update does not enable any C1-C3/R1-R3 retirement or public mutable API.

ET9-A implementation update: [metadata1.0 codecs](M2_EPOCH_BACKUP_FORMAT_V1.md) and
[independent fixture proof](M2_EPOCH_BACKUP_CODEC_VALIDATION.md) are now implemented.
The candidate layout above is historical. Header consistency is not actual artifact/data/
history verification. Next ET9-B adds internal fixed-H capture and both private verification
oracles; runtime restore, full-history migration and all retirement gates remain pending.

ET9-B implementation update: [internal capture](M2_EPOCH_BACKUP_CAPTURE.md) now seals exact
H under admitted writer/gate ownership and verifies complete data plus exact full-WAL redo.
[Validation](M2_EPOCH_BACKUP_CAPTURE_VALIDATION.md) includes old readers, source preservation
and selected failure/process cases. Read-only seal/closure checks are not full history proof.
Next ET9-C implements independent restore; ET9-D exhaustive faults and all retirement remain pending.

ET9-C implementation update: [independent restore](M2_EPOCH_BACKUP_RESTORE.md) now rebinds
complete history into fresh identities and atomically publishes store/ plus external origin.
[Validation](M2_EPOCH_BACKUP_RESTORE_VALIDATION.md) proves parity/provenance/branching and
selected failures/process windows. ET9-D exhaustive fault/native proof remains pending;
public APIs, migration/cutover and retirement are still separate gates.


Migration design update (2026-10-27): [ADR-018](../ADR-018-full-history-legacy-migration-and-cutover.md) and
[MG1-MG5 acceptance criteria](M2_EPOCH_MIGRATION_DESIGN.md) now specify sealed
legacy-backup conversion, four verification oracles, fresh epoch authority and separate
migration provenance. Cutover requires an operator-held write freeze, exact source and
candidate freshness checks and explicit routing; original roots/history stay intact.
ET9-D backup/restore qualification is complete for its recorded scope. No migration codec,
runtime converter, route switch or retirement is implemented. Next: MG1 codecs/fixtures.
