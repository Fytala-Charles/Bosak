# M2 Compatibility and Release-Readiness Audit

Date: 2026-10-28. Scope: repository-local evidence review after MG1-MG5 internal prototype
completion. This audit changes documentation only. M2 shipping, complete C1-C3 and retirement
are not approved. The proprietary license, disabled packaging and public API remain fixed.

## 1. Reader Inventory and Provenance

[Machine-readable inventory](m2-release-readiness-audit.json) records exact sizes and SHA-256
for all four frozen DLL files in the two repository reader families. Every hash was checked
against its unchanged manifest. The shared Core DLL is identical across families.

| Family | Captured baseline | Provenance limit |
|--------|-------------------|------------------|
| legacy-format1-reader | Post-backup format-1, before epoch primitives, 2026-10-27, SDK 10.0.301 | Local capture; gitCommit=null; no release/tag provenance |
| legacy-readonly-epoch-reader | Post-ADR-011 immutable epoch reader, before mutable-profile codecs, same date/SDK | Local capture; gitCommit=null; no release/tag provenance |

These are useful immutable regression baselines, not actual archived pre-lease releases.
The search covers repository tests/TestData, manifests, probe implementation and evidence
reports; external archives were not searched. Absence here does not establish that no
historical binary exists elsewhere. Never rebuild current source as purported old evidence.
An archived contribution needs original bytes, product/version/commit or release identity,
origin and capture provenance, hash and licensing before a dedicated isolated probe is added.

## 2. Compatibility Coverage

Original criteria are in [the compatibility contract](M2_COMPATIBILITY_BACKUP_RETIREMENT.md).

| Gate | Available evidence | Remaining gap |
|------|--------------------|---------------|
| C1 | Frozen format-1 raw/coordinator/durability/recovery and frozen immutable Open; current corresponding paths and default admission reject mutable root and nested generation fixtures | Dedicated MutableProfileRejectionTests uses synthetic profile fixtures, not actual MG3 bundles. Actual archived release evidence is missing |
| C2 | MG3 verified bundle publication, MG4 observed faults/process interruption, MG5 freshness and modeled uncertain/failed route and no-work return | No actual application routing callback/configuration, external writer fencing or restart reconciliation integration |
| C3 | Cross-process admission, owner disposal, child snapshot/transaction ownership, killed holders, old lazy readers and MG5 freeze scope | No proof of pre-lease reader absence or uncooperative writer exclusion; end-to-end application lifecycle remains open |

MutableProfileRejectionTests has ten frozen-reader rows: five operations at root and nested
generation. Its two current-reader rows invoke six public/default entry points per location.
Current immutable raw root refusal can be the transaction-state guard; it is not uniformly
proof of a specific profile error. The occupied admission test distinguishes current
read-only profile refusal from admission acquisition. The frozen raw probe accepts the
known transaction guard or InvalidDataException as rejection. Assertions compare all file
names/bytes and writer-lock absence; they do not compare the entire directory inventory.
These details limit the claim to the actual tested contract.

Conversion tests additionally reject current public opens of produced stores, but do not
supply the full frozen/current per-entry-point matrix over each real published generation.
Neither header codecs nor unchanged sequence H alone establish safe acceptance.

## 3. Evidence and Release Boundaries

Retain [MG5 runtime results](m2-migration-cutover-acceptance-results.json): 823 selected
cases per platform, with 27 unchanged expensive matrix cases supported by prior reports.
This audit does not rerun or claim a new complete regression run. A focused rerun of the
existing 12-case mutable-profile rejection matrix is recorded separately in the audit JSON.
All 12 focused cases passed on both Windows and isolated Linux. All four frozen binary
hashes match manifests. No new cases or persistence behavior are introduced.

Local ProcessCrash and actual Linux directory-flush execution remain distinct from modeled
strong ordering on Windows. WSL2/overlayfs and injected partial writes are not production
filesystem/controller power-loss or real bounded-volume ENOSPC qualification. Broader
public API/versioning, supported platforms and operational routing ownership still need
explicit product contracts. Packaging remains disabled. All source paths, stable identities
and committed histories remain retained; CanReclaim=false and R1-R3 remain separate.

## 4. Next Bounded Work: CA1

Extend compatibility tests to real MG3 published H=0 and multi-commit candidates. Exercise
the bundle wrapper, returned store path and every published nested generation through all
applicable frozen/current public Open entry points. Assert rejection and exact file bytes,
file/directory inventory and stable runtime identities before/after. Keep probes isolated,
hash-verify existing binaries and preserve the successful explicitly internal open path.
Do not change formats or public admission to make a test pass.

CA1 can proceed with available local baselines; it strengthens local C1 without closing
archived C1. Importing actual archived release evidence is a separate externally dependent
step. Real application routing needs a defined host/route contract before implementation;
MG5 attestations and enums must not be presented as such a service.


2026-10-28 follow-up: CA1 now implements the local real-bundle matrix in
[compatibility validation](M2_MIGRATED_BUNDLE_COMPATIBILITY_VALIDATION.md). The synthetic-only
coverage gap above describes the audited baseline; archived provenance and release gaps
remain open. Next is CA2 migrated-candidate ownership/lifetime race qualification.
