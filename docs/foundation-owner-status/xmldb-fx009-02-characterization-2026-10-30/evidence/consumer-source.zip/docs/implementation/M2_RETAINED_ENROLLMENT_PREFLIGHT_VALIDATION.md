# ER-002 Retained Preflight Validation

Date: 2026-10-30. Parent checkpoint 4283316 is committed/pushed. This fix is subsequent local work.
See [implemented contract](M2_RETAINED_ENROLLMENT_PREFLIGHT.md) and
[readiness review](M2_ENROLLMENT_READINESS_REVIEW.md).

## Focused Qualification

All 81 focused Windows cases pass: 19 new preflight cases, 27 existing retained enrollment
cases and 35 existing borrowed preparation cases. The new cases execute actual H=1 sources,
registered sealed captures and live source/authority/parent owners.

Two complete flows (no-output inspection and first append) observe 24 protected-path walks
and eight unlocked authority-read boundaries each. In these fixtures the three protected
paths are source, capture and parent; real parent history can add other protected paths.
The probe checks all five library monitors are unheld and all three actual owner roles remain
excluded, including before the first protected inspection. Output instrumentation separately
requires authority serialization, no lifecycle/source monitor and no new protected-path work.
Exact authority checking also has an in-code serializer guard exercised by these successful flows.

Ten cases mutate valid-head/torn-head/metadata/namespace/owner-length state immediately before
the serialized check following the last unlocked placement pass, both before and after arm.
Every case refuses before output, retains invalid bytes/file-directory inventory and keeps
immutable acquisition History unchanged. Pre-arm cases remain unlatched; armed cases stay
latched stopped. No uncertain cleanup or receipt is synthesized.

Four worker-thread closing cases cover source, authority, parent and all owners during a
protected-path walk. The worker completes while the actual original handles remain excluded;
preparation then refuses and actual operations drain without output. An explicit caller-thread
freeze-disposal case keeps exclusion until unarmed child drain, then honors the requested
freeze release. A direct closed-source-before-registration case starts no protected inspection
and fills the earlier DR01 direct-acquire coverage gap. Capture mutation during placement is
preserved and rejected without repair or recapture. These schedules do not exhaust all interleavings.

An early development run passed 80/81: the resume-after-unarmed-drain fixture created a new
final-generation reader lease during its measured BeginWrite. Final setup initializes that
lease before measurement; the strict byte/inventory assertions are retained. The final 81-case
run passes. Earlier artifacts remain separate from final-source evidence.

## Full Regression and Integrity

Broad isolated Linux passes 698 cases (622 Storage + 76 Integration), including all 19 new
bodies. Xdm has no matching cases. Pinned SDK 10.0.301 runs on x64 overlayfs with read-only
source/cache, no network and isolated outputs; seven expected MINVER1001 warnings are from
Git-free copied sources.

All 2,487 Windows cases pass across complete project runs: 1,804 Storage and 27 Xdm from the
initial full command, plus a fresh complete 656-case Integration rerun. The initial unfiltered
command has two epoch-restore process timeouts (Published and normal); those exact failed
artifacts remain recorded. All six restore process cases pass a focused recheck with unchanged
50-second limits, and the entire Integration rerun passes. No cause is established by the
reruns; do not describe the initial command as green. All 2,468 prior test IDs remain, plus
exactly 19 new Storage IDs. Final counters, source
hashes and raw TRX hashes are recorded in
[machine evidence](m2-retained-enrollment-preflight-results.json). Existing EF4 all-prefix,
process/ACK-loss, native identity and I/O closing tests run against this changed runtime;
the older EF4 results are not execution evidence for these changed inputs.

No public metadata change or frozen vector is intended. Fresh Windows reflection confirms unchanged 95-entry signatures. Read-only manifest/hash
verification checks six frozen hex vectors and four binary records. A combined command with
fixture-capable scripts was rejected by automatic approval review; no such scripts ran.
The safe alternative reads data only, with no remaining blocked action. Actual hidden/link
portability checks pass; strict documentation is checked before handover. No full Linux, ARM64, other-filesystem, power-loss or
real ENOSPC qualification is claimed. Existing Windows host guards must remain distinct from
native Linux execution. This fix does not enable stronger first-writer durability.

## Remaining Gates

ER-002 is implemented for the retained protocol. Direct authority/parent close-fault injection
(ER-003), stopped restart/owner handoff (ER-004), actual host/public/archive release and all
retirement remain open. No generic reader semantics, existing bytes/fixtures or retained
history is changed; no new authority transition or application work admission is enabled.

ER-003 implementation follow-up (2026-10-30): [direct role-release qualification](M2_ENROLLMENT_ROLE_RELEASE.md)
and [validation](M2_ENROLLMENT_ROLE_RELEASE_VALIDATION.md) cover authority/parent before/after/
no-op closes and required-cleanup versus later-disposal outcomes. Dated evidence above retains
its original scope. Next ER-004 stopped restart/owner-handoff contract; no new writer is enabled.
