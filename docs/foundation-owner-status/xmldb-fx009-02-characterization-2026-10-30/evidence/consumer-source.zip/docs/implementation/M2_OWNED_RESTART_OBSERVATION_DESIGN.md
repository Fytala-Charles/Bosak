# SR2 Owned Stopped Restart Observation Design

Date: 2026-10-30. Design only under [ADR-035](../ADR-035-owned-stopped-restart-observation.md).
Follows [SR1](M2_ENROLLMENT_RESTART_CLASSIFIER_VALIDATION.md) and refines the
[ER-004 contract](M2_STOPPED_ENROLLMENT_RESTART_CONTRACT.md). SR2 runtime is not implemented.
No source/authority ownership, observation capability or write permission is created by this file.

## 1. Concrete Integration Findings

| Existing mechanism | Why it is insufficient for restart | Required boundary |
|---|---|---|
| MigrationSourceFreeze.Require/ClaimRetention | Requires exact live freeze and its one registered capture reference | Never deserialize or register an old artifact as that original capture |
| RetainedEnrollmentSource.Acquire | Rejects stopped owners; tied to first-enrollment arm/initializer semantics | Add a separate restart-only child; do not weaken enrollment checks |
| MigrationSourceFreeze alone | Blocks data mutation but deliberately permits CreateBackup; disposal can release the token | Retain original writer ownership and exclude every cooperating mutation/publisher through real drain |
| Generic authority Inspect | Owns its actual read only during that call and performs generic placement under its read serializer | Add an opt-in observation mode spanning unlocked source/capture work; preserve generic behavior |
| EmbeddedXmlDatabase.OpenCore | Legacy recovery may republish CURRENT even for complete valid history | Never hide a live-source open/recovery inside read-only SR2 verification |
| Enrollment source binding | InitialHistoryDigest is SHA-256 of exact inventory.bin bytes, not the manifest/head hash | Verify the same committed inventory and complete live source bytes before deriving SR1 baseline facts |

These are integration constraints, not newly demonstrated runtime failures. Existing EF1-ER-003
behavior remains qualified for its original scope. Reusing its classes by fabricating capture
association or clearing the stop latch would violate that scope.

## 2. New Restart-Only Source Child

The proposed internal RetainedRestartSource is acquired from an actual already-open legacy
EmbeddedXmlDatabase under explicit controlled/stopped-host attestation. It takes no
FrozenMigrationCapture, initializer, receipt or descriptor. Its constructor is private to the
owner factory. Its opaque registration binds this exact owner, caller thread and original
usable writer FileStream; a separately pinned handle to a disposed stream is insufficient.

Under the source lifetime gate, reject disposed/faulted owners, existing freeze, enrollment or
restart children and incompatible state. Register exactly one child and permanently latch that
owner stopped at the same successful admission point. Keep the existing armed-owner prohibition:
this path does not reopen or rearm the original enrollment-stopped object. Restart uses a fresh
explicit owner, whose lifetime then has its own permanent stopped state. The factory must not
accept a caller-controlled close/handle or invoke I/O/callbacks during this atomic decision.

The stopped condition excludes BeginWrite, preexisting transaction Commit, checkpoint creation,
recovery-descriptor publication and CreateBackup, including publishers entered after caller
wrapper disposal. Every other cooperating mutation/publisher entry must be inventoried before
implementation. Existing source operations serialize on the source gate: either an earlier
operation completes before acquisition or the new stopped state rejects it. Optimistic write
objects are not treated as canceled or absent; their later Commit must refuse. External/old
binaries and untracked executors remain a host-control gap.

Caller Dispose closes new admission immediately but retains the original usable writer until
the actual restart child drains. Dispose of the child never clears the stop latch, resumes
publishers or closes an unrelated owner. Once-only source close must distinguish before-close,
after-close and no-op failure without retry, using existing managed close confirmation rules.
Unknown release keeps admission stopped and is surfaced separately from physical availability.
Ordinary no-retainer behavior and enrollment/freeze behavior remain unchanged.

Source inspection copies only memory state under a brief gate. Native identity, path, namespace,
file/history and capture inspection runs outside all source/lifetime/journal gates while the
child retains the actual stream. Recheck exact root identity and writer.lock path/handle identity
before and after verification. If caller closing races after admission, actual reads may drain
safely, but the closing scope cannot publish a usable owner-bound observation. Do not turn an
already admitted read into a new data executor or append operation.

## 3. Actual Paired-Owner Observation Scope

The proposed StoppedRestartObservationScope is a new opt-in internal mode on an existing-root
ApplicationAuthorityLifetime, separate from the first-enrollment initializer. Acquire the actual
parent child/authority read registration before source retention and before any source/capture
inspection. Require stopped admissions and exclusive drained protocol state. Reject initializer,
retained enrollment and other incompatible modes; no two observation scopes share a child.

Keep authority -> parent -> source as the brief compatible admission order; use nonblocking
source admission when required by existing lock-order rules. No waiting for a source gate,
filesystem access or callback under the combined lifetime gates. If source acquisition loses,
release only the operation actually acquired; never release caller owners or another scope.
A successful source admission may already have latched its owner stopped even if later pairing
or verification fails. That conservative stop is permanent, not rolled back as cleanup.

The scope is caller-thread/object/session confined and owns all actual resources until Dispose.
It may perform one Observe attempt. A failed/consumed scope cannot retry; a new attempt needs
new explicit stopped ownership, not a copy of a dossier. Closing/fault marks the scope unusable
for a later workflow. No initializer reservation, append session or handoff plan is introduced.
The returned dossier/assessment is an immutable point-in-time description and owns no resources.
Holding or deserializing it cannot prolong the actual scope or reconstruct a capability.

## 4. Verification Phases and Exact Commitments

1. Capture expected administrative and authority acquisition positions from the actual owned
   sessions, including exact lengths/digests/identities. Bind configured IDs, metadata and scope.
   These pins detect change during this observation, not coherent offline rollback or global
   newest-head truth. Independently fresh host control remains mandatory.
2. With all real children retained, perform protected placement/native ancestor checks outside
   serializers. Validate the actual administrative history under its own serializer, then the
   authority-only roles/metadata/full bounded history under the authority serializer. Never hold
   both serializers across a source/capture read or nest a source gate under them.
3. For exactly one Enroll, resolve its legacy root/admission keys through trusted protected
   mappings. Resolve the sealed capture from an explicit configured capture key/path supplied for
   reconciliation; Enroll does not persist that path/key or a BackupId. Do not discover a matching
   artifact or fabricate its original registration. Verify strict artifact closure/seal/bytes and
   every legacy transition with ReadArtifact and ValidateHistory, without opening it live.
4. Compute SHA-256 of the exact sealed inventory.bin bytes and compare with Enroll source
   InitialHistoryDigest. Prove the live source's complete retained files/history against that
   verified inventory using ValidateSource, plus explicit empty staging/no temporary publication
   checks. Match document/H/manifest and native root/admission identities before and after. The
   source has no epoch IDs. Runtime reader files are not data-history commitments or proof of
   reader absence. Verify artifact bytes/identity remain exact after source validation.
5. Build SR1 EnrolledBaseline and ActualBaseline only from these checks. For the current legacy
   enrollment both HistoryDigest and CaptureDigest use the verified inventory digest; the live
   manifest hash is a separate comparison, never substituted for the inventory commitment.
6. Repeat unlocked protected-placement checks, then revalidate actual parent and authority-only
   positions/identities after the last unlocked phase. Reject a changed head without adoption.
   Check all actual registrations/source stop state are still usable at final publication under
   brief lifetime gates. Caller closing wins against publishing a live observation; retained
   operations still drain normally. A closing race after a valid returned description makes the
   scope unusable for any later consumption; the description is not a release acknowledgment.

The adapter must not call live Open/OpenCore, publish CURRENT, create a new capture, run recovery,
repair/truncate histories or invoke private complete/redo clone publishers as a hidden part of
this read-only path. Existing byte/transition validators establish this bounded proof; they do
not become a new two-oracle migration certification. Files/directories remain unchanged from
actual child admission through drain, excluding unrelated explicitly permitted reader activity.
Test preservation with fixed reader setup, so reader creation is not hidden in a byte comparison.
Caller preparation/open before admission is a separate explicit boundary and may have performed
legacy recovery; never claim this observer made that earlier open read-only.

## 5. Deriving Facts Without Upgrading Host Assertions

Derive Namespace, Identities, AdministrativeHistory, AuthorityHistory and HeadUnchanged from
actual checks. Derive OwnersReacquired and SourceExcluded from real retained registrations and
fresh identity checks; caller booleans cannot set these to Confirmed. Bind supplied FreshScope,
PriorWorkReconciled, ExecutorsDrained, PublishersDrained and ReleaseReconciled to this exact
scope/observation attempt. They remain supplied operational assertions, not proof from hashes
or lock probes. Unknown stays Unknown. A known prior same-process release error cannot be
cleared by setting a Boolean or successfully opening a physically available role. Reconciliation
must explicitly account for that error; an observation cannot resolve it automatically.

Valid empty history returns stopped reconciliation without source/capture association and
without a new initializer. Valid later history is explicitly unsupported by this first adapter;
it may be inspected structurally but never becomes exact-Enroll evidence. Structural corruption
rejects without prefix output. A mismatching complete source/capture requires reconciliation;
known corruption or changed identities/heads refuse. Exceptions must preserve the distinction
between failed verification, missing facts and unconfirmed resource release.

## 6. Cleanup and Later Consumption

Dispose releases source child before authority/parent operation registrations. Preserve original
errors together with cleanup errors; no receipt or live-success evidence after required cleanup
failure. Authority role-release failure retains its parent registration as ER-003 specifies;
parent-only failure remains separately visible. Actual drain, not waiting-caller cancellation,
owns the handles. No automatic close retry, source latch clear or fixture-style raw handle
cleanup is a runtime recovery policy. Retain bytes and every committed history.

SR2 returns no write authority. SR3 must separately define atomic single-use consumption of the
actual still-live scope with complete freshness verification again; a dossier, old assessment
or completed Observe call is insufficient. Do not preapprove future SR3/SR4 from an SR2 read.

## 7. Bounded Implementation Sequence and Acceptance

| Slice | Required work and evidence |
|---|---|
| SR2-A next | Restart-only actual source child, permanent stopped admission, original-handle deferred close; no capture/authority adapter yet |
| SR2-B | Actual paired-owner observation scope and strict read-only source/capture proof; derive SR1 facts, preserve generic inspection |
| SR2-C | Ordered/repeated disposal/head/identity races, actual process-held ownership and Windows/Linux fault qualification |

SR2-A needs happy registration/drain and failure cases for closed/faulted/wrong-thread/foreign/
existing freeze/enrollment/stopped owner, each cooperating mutation/publisher and preexisting
transaction commit. Test caller source Dispose before/after registration, simultaneous closing
endpoints, before/after/no-op close errors and repeated Dispose without retry; existing snapshots
must remain usable. The child must retain the actual original stream, not just report a count.

SR2-B/C need real Enroll and reopened owned roots, unchanged source/capture/admin/authority
bytes plus full directory inventory; H0/positive-H; changed capture/source/head; corrupt/torn/
empty/later histories; exact placement/serializer phase probes; hostile role substitution with
native/guarded accounting; closing at every unlocked boundary; faulted release propagation;
wrong object/thread, old descriptions and repeat Observe refusal. Preserve old generic API and
all frozen fixtures. Run the required full regression and actual focused Linux bodies for each
runtime slice. SR2-A alone must not be reported as completed SR2 observation.

No public API, wire/role change, persistent fence, source replacement, work acceptance/routing,
TransferOwner append, power-loss/real ENOSPC proof or reclamation is enabled. CanReclaim=false.

SR2-A follow-up (2026-10-30): [source-only retention](M2_RESTART_SOURCE_RETENTION_VALIDATION.md)
adds actual source lifetime retention and permanent stopped admission. Original design evidence
remains historical. Full paired SR2 observation is not implemented; next SR2-B.

SR2-B follow-up (2026-10-30): [actual paired stopped observation](M2_OWNED_RESTART_OBSERVATION_VALIDATION.md)
binds complete read-only legacy/capture proof to real retained owners, with no acknowledgment
or handoff authority. Earlier evidence retains its dated scope; next SR2-C qualification.

SR2-C follow-up (2026-10-30): [native/process/disposal qualification](M2_OWNED_RESTART_QUALIFICATION_VALIDATION.md)
adds bounded local identity, actual holder/interruption and closing evidence without product
source changes. Original evidence retains its dated inputs; next SR1/SR2 readiness consolidation.
