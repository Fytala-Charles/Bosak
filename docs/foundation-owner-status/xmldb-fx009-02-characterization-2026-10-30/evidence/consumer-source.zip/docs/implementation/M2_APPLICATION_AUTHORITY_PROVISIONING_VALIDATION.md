# Application-Authority Provisioning Validation

Date: 2026-10-29. Scope: internal EP7-C provisioning slice under
[ADR-031](../ADR-031-application-authority-provisioning-and-initializer.md).

## Implemented Boundary

ApplicationAuthorityLifetime.Provision is separate from OpenExisting. It requires exact
parent/configuration/root mappings and supplied fresh controlled-provisioner/no-prior-authority
evidence, captures the real exclusive parent mode, rejects existing targets and validates
planned physical ancestry before creation. CreateNew authority.lock is transferred without
close/reopen. The exact metadata and empty log use no-overwrite transaction storage calls.
All three retained path/handle identities and contents are validated before return.

ReserveInitializer is a single-use read-only reservation on that successful live instance.
It retains a real operation lease; disposing both owners does not release either until the
reservation drains. It does not establish the real source baseline or write enrollment.
Reopened empty roots reject it. Failed initialization cannot be resumed by a descriptor,
clean bytes, absent work records or a saved flag. Every result keeps writers stopped.

## Focused Qualification

29 new Storage cases pass on Windows. Fault tests first record the successful 24-call
storage trace, then inject at each observed before/after position. A separate real partial
metadata write leaves 56 of 112 bytes. Every interrupted existing root is retained and a
second provision attempt rejects it without completing any role. Ten explicit checkpoint
interruptions additionally cover direct exclusive-owner creation/flush and final handoff.
These are exception injection tests, not process termination or physical power-loss tests.

Other cases cover zero-byte log/expected metadata, continuous cooperative owner exclusion,
actual paired drain, empty reopen rejection, concurrent single-reservation winner, parent
mode contention, existing file/empty/partial roots, missing evidence, parent disposal,
occupied namespace after directory creation, planned protected overlap, disposed owners
and explicit stronger-policy rejection. Fixtures are metadata-only private roots, not
application databases or accepted-work accounting proof. Existing native alias/role/FIFO
and process ownership tests remain regression evidence, not fresh provisioning process tests.

## Actual Process Qualification

17 new Integration cases pass on Windows and isolated Linux. Fourteen interruption
boundaries run twice each in independent processes: the ten provisioning checkpoints,
actual half-metadata output, post-return acknowledgment loss, live reservation and disposal
with the actual reservation retained. Three independent-creator races use different retained
administrative owners against one authority destination. Each final focused run starts 34
processes for these new cases. This is separate from the 24 seam exception positions above.

At every death boundary source/admin bytes remain unchanged, retained role inventory matches
the reached publication position, ownership excludes contenders until actual process exit,
and existing partial roots cannot be resumed. Complete empty roots inspect read-only but
cannot reserve initialization, including after successful return. The actual partial-write
process leaves exactly 56 metadata bytes. The creator race publishes exactly one expected
parent-bound metadata configuration; the loser cannot complete, overwrite or delete roles.

## Regression Status

The fresh original unfiltered Windows run passes 2,279 cases: Storage 1,643, Integration
609 and Xdm 27. After adding the test-only process harness/cases, the final clean full
Integration confirmation passes 626. The final 2,296-case aggregate is 1,643 Storage +
626 Integration + 27 Xdm; it replaces the earlier 609 Integration rows rather than adding
them. All 609 old Integration test names remain, with exactly 17 new names. Production/
Storage/Xdm sources are unchanged after the original full build. The Storage run takes
41 minutes 17 seconds; final Integration takes 4 minutes 42 seconds. No failures or skips
remain in the selected final project results.

The first final Integration attempt reported one failure in the existing
EmbeddedHostProcessTests.Ownership_ProcessExitOrDrain_ReleasesOnlyAfterCompletion
kill-drain case: owner.lock remained unavailable immediately after awaited process kill.
The original full run had passed it. An immediate focused recheck passes all four modes;
the clean full Integration confirmation passes all 626. No source change was made to
that test or its old probe action, and no cause is established. Retain this observation;
the passing rerun does not prove the absence of intermittent Windows release failures.

Final isolated Linux focus passes 475 (429 Storage + 46 Integration), with all 46 new case
bodies executed. Xdm has no matching cases. The runner uses read-only source/cache mounts,
no container network and isolated outputs, SDK image 10.0.301 on x64/overlayfs. Seven expected
MINVER1001 warnings reflect the copied Git-free source. Docker remains running.

Full Windows totals include existing host-only early returns; they do not claim execution
of native Linux durability branches. This is no full Linux run, ARM64 qualification,
physical power-loss, real ENOSPC, archived release proof or global writer fencing evidence.
Formatting/analyzers, strict documentation/portability and frozen fixture checks pass.

## Remaining Gates

Next bind a real operational baseline to live owner-bound first-enrollment preparation,
then implement conditional append with sticky uncertainty. Provision return/reservation do
not prove baseline truth or authorize application work. This slice adds no enrollment/work
append, database invocation, consuming host, routing, public mutable API, source replacement
or retirement. All histories remain and CanReclaim stays false.

## Process Qualification Acceptance Matrix

The cases above execute this matrix on Windows and isolated Linux.

| Termination/contender boundary | Required observation after process exit |
|---|---|
| Before target creation | No target introduced; a new explicit absent-root attempt needs fresh evidence |
| After directory/owner creation | Retain incomplete inventory; no completing or resuming that root |
| During metadata/log creation | Retain exact surviving bytes; partial roles never become initializer authority |
| Before return with three valid roles | Existing-root inspection may succeed read-only; first-write reservation remains unavailable |
| After return/reservation, before caller observes success | No acknowledgment or initializer state reconstructed on reopen |
| Owner process exits, or lifetimes dispose with a live reservation | Independent contender stays excluded until actual process/handle release; source/admin histories remain unchanged |
| Independent parent owners race one authority destination | At most one no-overwrite creator; losers cannot clean up, complete or alter winner roles |

All workspaces are fresh metadata-only roots. Counts describe actual process boundaries
separately from modeled seam exceptions and earlier read-only ownership evidence. These
checks do not prove application baseline truth, old-binary exclusion, power-loss survival
or permission to append enrollment.

## Machine Evidence and Delivery

[Machine evidence](m2-application-authority-provisioning-results.json) records final
source hashes, TRX paths/hashes, selected project totals, exact Integration catalog
replacement, the failed attempt and passing rechecks. Source hashes describe raw validation
checkout bytes, not archived-release provenance. Retained earlier Linux/Windows focused
attempts are not added to final counts. No production code changed during process-test
extension or rechecks.

Checkpoint 21a33af is committed and pushed. This subsequent provisioning step is local
and uncommitted. Existing public APIs, wire formats, frozen vectors/binaries and every
store/journal history are preserved. Next: owner-bound first-enrollment preparation with
independently fresh real baseline evidence, before conditional append/uncertain-save work.
