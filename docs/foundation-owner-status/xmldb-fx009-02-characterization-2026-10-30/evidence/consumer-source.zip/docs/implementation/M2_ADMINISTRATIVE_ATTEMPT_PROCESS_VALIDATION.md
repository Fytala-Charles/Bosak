# RC3 Administrative Attempt Process and Contention Validation

Date: 2026-10-28. Internal qualification of ADR-020, following RC2.

The probe prepares an owner-bound plan and flushes its library-generated attempt ID and
inventory commitment before accepting a dispatch command. The parent retains those primitive
values. Process termination at ProofVerified, ReadyToPublish, Published and ACK is tested
for both legacy migration and independent epoch restore. The parent awaits process exit
before inspecting with a newly created administration service; it never recreates the plan.
Before publication, absence plus this test's exclusive dispatch ownership and confirmed exit
allows an explicit fresh plan with a different ID. Published/ACK cases match the retained ID
without fabricating an acknowledged receipt. Inspection preserves every observed file byte.

Two independent plans rendezvous after full proof at ReadyToPublish and race the actual
namespace publication: one succeeds, one fails with IOException. Only the winner's ID matches;
the loser's request requires reconciliation. Four concurrent dispatchers of one plan permit
one execution and reject three duplicates. All plans remain consumed and sealed input bytes
are retained. Each test owns its GUID temporary tree and closes child processes before cleanup.

The final focused run includes 71 cases/platform: 12 new RC3 cases, 28 RC1 and 31 RC2.
Windows Debug and isolated Linux Release pass with zero failures/skips. Windows RC2 native
rows assert unsupported policy; RC3's 12 new cases all execute ProcessCrash on both hosts.
These process-kill tests do not establish physical power-loss, controller, real ENOSPC,
archived-release compatibility, a durable host ledger or distributed fencing. The earlier
full regression evidence keeps its original scope; this is not a new full-suite run.

No production runtime change, public API, wire-format change, automatic retry, source
replacement or history deletion is introduced. RC2/RC3 remain local and uncommitted.
Next: HA1 host-side attempt-ledger and fencing contract, before any host routing integration.

[Machine evidence](m2-administrative-attempt-process-results.json).
