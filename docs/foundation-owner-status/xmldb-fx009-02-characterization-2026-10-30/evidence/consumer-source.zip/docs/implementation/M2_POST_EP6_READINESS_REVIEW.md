# Post-EP6-D Readiness and Consuming-Host Authority Audit

Date: 2026-10-29. Reviewed baseline: `4598346` (clean working tree at entry).
This review supersedes historical next-action wording, not historical test evidence.

## 1. Current Position

RC1-RC3 operation correlation progressed through HA1 models and the selected embedded
pilot to EP2-EP6-D. The latest checkpoint is not RC3. EP6-D records 1,055 focused cases
per Windows/Linux platform, including 72 new process cases; it explicitly is not a fresh
unfiltered regression. See [process qualification](M2_EMBEDDED_HOST_RESTART_PROCESS_VALIDATION.md).
The earlier [consolidated review](M2_CONSOLIDATED_API_READINESS_REVIEW.md) remains dated
evidence; its RC1-RC3 next-action statements are historical rather than current blockers.

## 2. Consuming-Host Authority Findings

| Boundary | Repository evidence | Remaining requirement |
|----------|---------------------|-----------------------|
| Administrative ownership | EmbeddedHostLifetime owns the controlled host root, drains registered operations and retains stopped reopen | Actual application must enumerate every writer, ingress and publisher in scope |
| Selected-root authority | No application selection/revision implementation; EmbeddedQuickstart opens a command-line path | Exact resource/root/store/epoch binding, authoritative revision and conditional selection update |
| Accepted application work | ActiveOperations counts registered administrative lifetimes | Define acceptance before side effects, both-branch durable accounting and treatment of pending/unknown work |
| Host history | HostJournalEvent records attempt intent, authorization, uncertainty, receipts, observations, absence and owner transfer | These events do not record application route revisions or application work acceptance |
| Restart | EP6 reconciles publications while admissions stay closed; fresh retry requires a new real plan/ID | Independently observe selection and accepted work before any application admission decision |
| Consumer | Only EmbeddedQuickstart exists in samples; no production consuming application was supplied | Select the actual application or explicitly scope a new internal pilot |

Source inspection: `src/Bosak.XmlDb.Storage/EmbeddedHostLifetime.cs`,
`src/Bosak.XmlDb.Storage/HostJournalCodec.cs` and `samples/EmbeddedQuickstart/Program.cs`.
Administrative admission evidence is supplied controlled-scope evidence; it is not an
independent discovery of external writer exclusion. Administrative drain cannot be used to
infer that application work is zero. No runtime defect or new permission is inferred here.

## 3. Next Bounded Gate

Prepare a consuming-host selected-root/work-authority contract against the chosen application
before implementing routing. Existing [ADR-019 boundaries](M2_PUBLIC_API_AND_HOST_CUTOVER_CONTRACT.md)
and the [embedded profile](M2_EMBEDDED_HOST_PROFILE.md) remain controlling requirements.
The contract must identify the actual authority owner/backend and specify:

- Exact selection identity/revision, conditional change and authoritative read after lost acknowledgment.
- Acceptance boundary and persistent accounting for ingress, pending operations, both branches and restart.
- One lifetime/admission protocol covering publishers and application writers, including shutdown drain.
- Stopped restart observations, unknown/contradictory evidence and explicit reconciliation.
- Tests for selection/work races, stale revisions, acceptance before crash, lost acknowledgment,
  pending-operation shutdown and restart with unknown work; both writers remain stopped on uncertainty.

Do not add speculative route/work records to the frozen host codec. A new authority format or
cross-cutting runtime decision needs a separately reviewed ADR. No automatic resume, public
API promotion, source replacement or history deletion follows from this audit. Archived release,
external consumer, physical durability and retirement gates remain open; CanReclaim=false.

## 4. Required Host Acceptance Scenarios

These are proposed acceptance criteria, not newly executed tests or an approved runtime design.

| Scenario | Required behavior |
|----------|-------------------|
| Selection changes between readiness and update | Reject the stale revision; preserve both roots and stay stopped |
| Selection update applies but acknowledgment is lost | Read the authority; unresolved target/revision requires reconciliation |
| Work is accepted before a process dies | Retain an authoritative accounting obligation; restart cannot assume zero |
| Accounting is absent, stale or contradictory on either branch | Require reconciliation; no automatic return or writer admission |
| Caller times out while an operation still runs | Keep the operation registered; do not release ownership on caller timeout |
| Shutdown races ingress or pending work | Close ingress first and establish actual drain before releasing ownership |
| Previously valid host history is restored from an older prefix | Require independent freshness/rollback handling; checksum validity is insufficient |
| Candidate publication is known but selection is unchanged or unknown | Retain candidate; no implicit routing, acknowledgment synthesis or cleanup |

## 5. Verification of This Review

Fresh unfiltered Windows Debug full-solution regression passes: 1,894 tests, zero failures
and skips (1,274 Storage, 593 Integration, 27 Xdm). Storage duration was 43 m 31 s.
The command was dotnet test Bosak.XmlDb.slnx with TRX output; its build/restore also passed.
Formatting/analyzer verification, strict documentation and actual hidden/link portability
regressions pass on Windows. [Machine evidence](m2-post-ep6-readiness-results.json) records
this review separately from the original EP6-D focused evidence.
Fresh Linux full-solution execution was attempted with tools/test-linux.ps1 but could not
start because the Docker Desktop Linux engine named pipe is unavailable. No image was pulled,
engine started or existing historical Linux evidence relabeled as a fresh run.
Hosted CI billing blockage is retained from the checkpoint; no fresh hosted run was requested.
Runtime source, frozen fixtures, package pins, public surface and wire formats are unchanged.


Target decision (2026-10-29): user chose the internal embedded pilot.
[ADR-028](../ADR-028-embedded-pilot-selection-and-work-authority.md) and the
[pilot authority contract](M2_EMBEDDED_PILOT_AUTHORITY_CONTRACT.md) now supply the next-gate
design. Next EP7-A implements pure stopped classification; this follow-up adds no runtime
or format and does not change the regression evidence above.
