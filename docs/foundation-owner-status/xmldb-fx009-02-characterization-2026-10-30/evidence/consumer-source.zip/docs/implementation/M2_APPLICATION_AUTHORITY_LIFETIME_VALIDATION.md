# EP7-C Paired Authority Lifetime and Existing-Root Inspection Validation

Date: 2026-10-29. Internal existing-root slice of [ADR-030](../ADR-030-paired-read-only-application-authority-ownership.md),
following [ADR-029](../ADR-029-separate-application-authority-journal-v1.md) and the
[authority format](M2_APPLICATION_AUTHORITY_FORMAT_V1.md). Provisioning, append and execution remain pending.

## 1. Actual Parent Exclusion and Child Lifetime

EmbeddedHostLifetime now reserves an opaque ApplicationInspectionRegistration only at an exact
acknowledged administrative head, with admissions closed, no active operations/executor/stopped
session and fresh context-bound controlled-scope facts. It validates complete current admin history
before returning. Facts remain supplied assumptions, not independent exclusion of old/foreign writers.
The registration is recognized by live object identity; forged, foreign, closed or faulted use fails.

While the mode exists, ordinary operations, reconciliation reads/tokens, append enablement/append,
executors, admission reopening, stopped sessions and another application acquisition are excluded.
The original behavior outside this mode is preserved. Empty admin history can be inspected but does
not acquire initializer/append authority. No journal bytes or existing wire mappings change.

ApplicationAuthorityLifetime acquires this real parent mode before authority ownership. Parent
shutdown blocks new reads but holds its role handles while the child remains live. Child shutdown
blocks new inspection, waits for actual registered reads, closes authority log/meta/owner handles,
then releases its parent registration. Duplicate/concurrent disposal completes each token once.
The shared 1,024-operation bound includes the base mode, leaving up to 1,023 actual child reads.
Caller cancellation/timeouts are not completion. WhenReleased confirms handle release, not valid data.

Callbacks/test checkpoints run outside parent lifetime/journal locks and the authority read serializer.
File reads serialize separately; accepted pending reads retain their actual handles through shutdown.
A failed release does not report successful release or silently clear parent ownership. Acquisition
cleanup preserves the primary failure alongside cleanup errors. No automatic dispatch/work is added.

## 2. Existing Root and Configured Resource Map

OpenExisting requires exactly authority.lock, authority.meta and authority.log, existing regular
single-link files in a separate disjoint directory. It uses FileMode.Open only, checks owner length
zero, metadata length 112 and log size bounds, and retains all three handles. Read/write opens avoid
blocking FIFO reads; no Write, SetLength, Flush, creation, replacement, deletion or repair is issued.
This prototype therefore requires read/write file permissions even though content is inspected only.

Trusted configuration binds actual parent journal ID, deployment/resource scope and expected authority
ID. A captured immutable logical-key/path map binds the admin/authority keys to their actual canonical
paths, includes every retained authority source/candidate/artifact/bundle key, and supplies the complete
configured protected inventory. Map size is 3 through 64; inherited admin artifact/bundle roots are
also checked (4,096 unique protected paths maximum). Ancestor walks are bounded at 128 directories.
Missing future data roots use existing ancestors without mistaking a missing path for a reparse role.

Reject lexical/physical ancestry overlap with the parent, configured data and retained administrative
roots. Native directory identities support physical ancestry comparisons; roots/ancestors reject
symlinks/junctions, unsupported filesystems and non-directory placements. Role enumeration stops at
four entries. Unknown/missing/directory/link roles reject. Logical keys and directory queries do not
verify XML/store identities, artifact closure or real publication correlation; these remain later gates.

Windows uses fixed local NTFS, native FileIdInfo volume/128-bit IDs and StandardInfo link counts.
Linux x64/arm64 code uses statx device/inode/type/link masks and statfs/fstatfs filesystem checks,
allowing ext-family/overlayfs/tmpfs only. Missing native support and unsupported hosts/filesystems
reject without weaker fallback. Primary ABI references are recorded in ADR-030. Fresh Linux x64/overlayfs execution is now qualified by the focused run below, not inferred
from Windows or older container evidence. ARM64 and other allowed filesystems were not executed.

## 3. Stable Read-Only Observations

Acquisition and repeat inspection validate exact metadata, full bounded history, handle/path/root
identities, required key mappings and physical disjointness. Read each bounded log into one private
byte snapshot, so the decoded history and retained raw SHA-256 describe the same bytes. Repeat reads
must match the original length/hash; a valid new head is never silently adopted. Recheck namespace
before/after content inspection and after acquisition checkpoints. No data root/coordinator is opened.

Invalid/changed owned observations fault this child permanently, even if a test later restores the
namespace. All initial/decoded outputs remain stopped. Empty reopened history gets no initializer
eligibility. History owner IDs, observed outcomes or zero counts never produce a receipt, freshness
proof, accepted-work authority or permission to resume writes. Stable namespace/external control are
still assumptions: this is not hostile rename protection, global fencing or anti-rollback evidence.

## 4. Executed Qualification

Final focused Windows runs pass 429 catalog cases: 400 Storage and 29 Integration. They include
71 new cases (55 Storage, 16 Integration) plus existing parent-mode/codec/classifier/process regression.

New Storage coverage: valid/enrolled and empty observations with stable bytes/role identities; nine
competing modes; 18 invalid parent/configuration cases; 14 malformed/unsupported root/inventory cases;
paused actual-read drain; parent disposal and concurrent duplicate child disposal; sticky failures;
four acquisition/shutdown checkpoints; forged/foreign/disposed registration rejection; reverse
stopped/executor exclusion; exact registration capacity; eight repeated simultaneous read/dispose
schedules. Ordered tests prove endpoints; repetitions do not claim every possible interleaving.

New Integration coverage: four process modes (exit, kill, actual-read drain, kill during drain), each
repeated three times with awaited exit; three actual hard-linked role rejections; four actual junction/
link placements; two protected-namespace-change cases; three Linux FIFO rows. On Windows, the three
new FIFO rows return as explicit guards: 68 new-case bodies execute and three are guard rows. The
focused Integration set also includes three older Windows FIFO guards; none is Linux FIFO evidence.

Test fixtures create only fresh private host/authority metadata trees and plain data directories;
they are not XML stores or a production provisioner. CrashProbe adds only the ep7c-hold test command.
Integration copies the existing pinned enrollment vector through one explicit project content item.
No frozen vectors/reader binaries are regenerated or replaced, and no public signature/pin changes.

Fresh unfiltered Windows Debug full-solution execution passes all 2,250 cases, zero failures/
skips: 1,614 Storage, 609 Integration and 27 Xdm. The 71 new cases are included, not added again.
The solution command exits 0 without a project rerun. Storage reported 1 h 12 m. Restore/build,
formatting/analyzers, strict documentation, actual hidden/link portability and fixture checks pass.
All nine full-run input fingerprints matched after execution.

After that run, exactly five XML returns comments were inserted into each new async test file;
mechanical removal reproduces the original source text. No executable body/runtime code changed.
The rebuilt final-source focused Windows run passes the same 400 + 29 test IDs. Both original
compile inputs and final file hashes are retained separately in machine evidence.
The initial Linux attempt was blocked by a stopped Docker engine. The installed backend was then
started detached; the already cached SDK 10.0.301 image was used without pulling or changing Docker
settings. Fresh isolated Linux Release execution passes all 429 focused cases (400 Storage, 29
Integration), zero failures/skips. All 71 new case bodies execute, including the three new FIFOs;
the three older focused FIFO bodies execute too. Xdm has no matching cases in this filter.

The runner keeps source/cache mounts read-only and container network none, with host build outputs
preserved. Actual environment is x64 overlayfs on WSL2 kernel 6.6.114.1. Seven expected MINVER1001
warnings reflect the intentionally Git-free copied source; no release version or full Linux suite
is claimed. Docker remains running. This is native ownership/identity/process evidence, not
FileAndDirectoryFlush, physical power-loss, real ENOSPC or global fencing qualification.
Final source hashes, TRX references and static checks are in
[machine evidence](m2-application-authority-lifetime-results.json).

## 5. Delivery and Next Work

Runtime changes are three new files plus narrow guards/change-history rows in two existing host files.
Two new test files, the existing test-only CrashProbe command/header and one fixture-copy project item
qualify them. The earlier audit/design/classifier/codec work remains local too; HEAD is 4598346.
No commit or push is performed. Existing store/host/authority bytes and all histories stay intact.

Next specify and qualify explicit no-overwrite authority provisioning with continuous ownership,
retained interrupted state and initializer-only first enrollment before conditional append. Existing
OpenExisting must remain non-creating/non-repairing; empty reopen must never become first-write
permission. Persistence/save uncertainty and EP7-D actual work remain later gates. Public/release,
archived-reader provenance, hostile/global fencing, physical power-loss/real ENOSPC and all retirement
requirements remain open. Keep CanReclaim=false and every source/candidate/WAL/authority history.
