# ER-003 Role-Close Fault Validation

Date: 2026-10-30. Parent checkpoint 1fc13c4 is committed/pushed. ER-003 is subsequent local work.
See [implemented contract](M2_ENROLLMENT_ROLE_RELEASE.md) and
[readiness review](M2_ENROLLMENT_READINESS_REVIEW.md).

## Focused Windows Qualification

All 42 new Storage cases pass. A 36-row matrix covers each authority role (authority.log,
authority.meta, authority.lock) and parent role (journal.bin, host.meta, owner.lock), each with
failure before actual close, failure after actual close and no delegated close, both before
arm and after arm. These are actual acquired FileStreams on real H=1 stores and sealed captures.
The no-op adapter is detected as unconfirmed through its original managed handle.

Every matrix outcome is Uncertain with ReleaseUnknown=true and no receipt/ConfirmedEnrollment.
PossibleOutput is false before arm and true after arm. Source close succeeds first; authority
release failure keeps the actual parent registration and prevents every parent close call.
Parent-only failure follows successful authority release and faults the parent task. Tests
check exact role order, each role attempted once, immutable acquisition History, surviving log
and all other bytes/full file-directory inventory, old source snapshot reads and repeated
Dispose/re-dispatch rejection. The fixture separately probes its known physical effect;
product uncertainty is not relabeled as definitely held or released when an after-close fault
left a role available. No close attempt is automatically retried.

Six additional cases cover two successful-close controls, two live-owner later-disposal errors,
configured authority/parent faults where parent release must not start, and pending-plan cleanup
with no append. Previously qualified source-close faults remain separate baseline evidence.
Late independent disposal failure preserves an already qualified publication receipt while
faulting the appropriate release task; it does not grant work admission or release authority.

The broader focused Windows run passes 139 cases: the 42 new cases plus existing retained
preflight, first-enrollment append and host-lifetime cases. An initial compile check caught an
xUnit collection assertion-style error; it was corrected before executable qualification.
No test timeout or product assertion was weakened. New cases have no platform early-return guards.

## Full Regression and Integrity

Broad isolated Linux passes 740 cases (664 Storage + 76 Integration), including all 42 new
bodies. Xdm has no matching cases. Pinned SDK 10.0.301 runs on x64 overlayfs with read-only
source/cache mounts, no network and isolated outputs; seven expected MINVER1001 warnings
reflect the Git-free copied sources.

All 2,529 Windows cases qualify across complete project runs: 1,846 Storage and 27 Xdm from
the initial command, plus a fresh complete 656-case Integration rerun. The initial full command
has existing Published/normal epoch-restore process timeouts; preserve its failed artifacts.
All six restore process cases pass a focused recheck with unchanged 50-second limits, then
the entire Integration rerun passes. No cause is inferred; do not call the initial command green.
All 2,487 previous test IDs remain, plus exactly 42 new Storage IDs. Five final C# hashes
remain unchanged from qualified inputs. Exact counters, source
fingerprints, per-role markers and raw TRX hashes are recorded in
[machine evidence](m2-enrollment-role-release-results.json). Linux runs before the full Windows
suite to avoid overlapping heavy regressions after prior-step restore timeout observations.
This sequencing does not establish the cause of those historical timeouts.

Fresh public metadata remains 95/95 with no additions/removals. Read-only manifest hashes
verify six frozen vectors and four binary file records. Actual hidden/link portability passes;
strict documentation passes before handover. No fixture generation script
is needed or executed. Governed kit files, fixture provenance, public layouts and all committed
history remain unchanged. Native Linux execution and existing Windows guarded rows must remain
separate; no power-loss, real ENOSPC or native kernel-close error certification is claimed.

## Remaining Gates

ER-003 implements the direct authority/parent managed close-fault qualification. ER-004 stopped
restart/owner handoff, actual host/public/archive release and all retirement remain open.
No data write, extra authority transition, descriptor replay or automatic close/recovery retry
is enabled. Preserve the original source owner stop latch and CanReclaim=false.
