# MG5 Cutover Acceptance Validation

Date: 2026-10-27. [Contract](M2_MIGRATION_CUTOVER_ACCEPTANCE.md) and
[machine results](m2-migration-cutover-acceptance-results.json) scope this internal harness.

32 new Storage cases verify:

- H0/H1/H3 explicit modeled switch/observed success/verified no-work return with source,
  artifact/candidate bytes and directory inventory unchanged, plus old lazy readers.
- Source new/pending writes and checkpoint/descriptor publication, candidate new/pending
  transactions/callback-bearing backups, pre-write rejection, clean release and later independent commits.
- Required operator/prototype attestations, one registered capture, duplicate owner freezes,
  foreign receipts, stale/consumed/cross-session evidence and session restart.
- Known failed switch/return, explicit uncertainty resolution, unknown/other routes and
  refusal when work is accepted or not drained even at the same commit sequence.
- Ten same-cached-H commitment changes: coherent source WAL TxId, fragment/current/extra WAL,
  artifact inventory, coherent candidate WAL TxId, current/reader/EPOCH and resealed origin.
  Revalidation rejects without repairing inputs or touching configuration.
- Source advancement/new capture versus old candidate, candidate advancement, wrong result,
  disposed owners, Prepare-time corruption, valid optional live H0 CURRENT, independent
  admission across candidate disposal and bounded concurrent/thread-confinement checks.

Two Integration cases hold the freeze in another process, then release or kill it. Both
OS writer leases exclude competing owners while held, old uncached legacy reads survive,
exit releases handles, and new owners can begin transactions. No persistent freeze,
readiness or routing decision is inherited. Real application routing is never changed.

Fresh filtered runs cover 823 cases per platform (647 Storage, 27 Xdm, 149 Integration).
The catalog contains 850 cases. The unchanged 18-case EpochBackupFaultTests and nine-case
EpochMigrationFaultTests matrices retain their prior ET9-D/MG4 qualification; they are not
rerun or counted as fresh here. Normal unfrozen paths gain only a no-op freeze guard, while
the new active-freeze behavior is covered directly. Existing process/native regressions
remain in the fresh batch. A final focused MG5 batch includes the late backup-callback
guard assertion and replaces its earlier rows in aggregate counts. No case is counted
twice, and no unfiltered new 850-case run is claimed.

Formatting, strict documentation and frozen fixture hashes are checked. Existing binary
encodings/public signatures, proprietary license, pins and disabled packaging remain fixed.
The live validator uses shared bounded read-only primitives; it invokes no recovery/write
barriers and no routing callback. No new native persistence algorithm is introduced.

MG1-MG5 are now internal prototype gates only. Actual archived-reader C1, broader C2/C3,
public API/release qualification and physical/controller durability remain distinct gaps.
Next: compatibility/release-readiness evidence audit, keeping missing historical binaries
explicit rather than rebuilding current code as purported archived evidence. CanReclaim=false;
source paths, stable identities and all histories remain retained.
