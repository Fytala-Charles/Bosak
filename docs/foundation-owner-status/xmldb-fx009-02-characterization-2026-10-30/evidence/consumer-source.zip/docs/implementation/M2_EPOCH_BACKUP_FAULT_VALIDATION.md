# ET9-D Epoch Backup and Restore Fault Qualification

Date: 2026-10-27. Internal APIs only; proprietary license retained.

The sweep records a successful capture or restore at H=1, then independently injects an
IOException before and after every observed storage call. Every WriteFile/before position
also gets a real first-half write followed by the injected exception. File creation,
write, flush, close, directory creation, move, deletion and sync calls use the real local
storage adapter. This is exhaustive over the observed fixture traces, not every possible
history size or concurrent external mutation.

Windows runs ProcessCrash and modeled FileAndDirectoryFlush ordering. Linux additionally
runs actual native FileAndDirectoryFlush delegation, with EffectiveDurability asserted.
Six native-only theory branches return on Windows and are not native execution evidence.
Machine labels use mode 0 for ProcessCrash, 1 for modeled strong ordering, and 2 for actual
native Linux durability. The matrix is deliberately expensive: each fault replays the
operation through its preceding calls and then checks preservation and published results;
per-case durations are retained in the machine evidence.

Each attempt checks unchanged source and sealed-backup file inventories and bytes. Capture
errors fault the owner while its independently held snapshot remains readable. Unpublished
outputs stay absent. Published-but-unacknowledged captures pass both complete-history and
full-WAL-redo oracles; restored bundles validate origin against the original inventory and
reopen twice with exact H, fresh identity, current value and historical base value. Exclusive
file opens detect leaked handles on Windows; test-owned orphan workspaces are removed only
after operations end. Production cleanup never scans or deletes abandoned workspaces.

Process probes use the default ProcessCrash policy. Native directory-flush evidence comes
from the separate Linux storage-fault matrix, not from a native-policy process-kill run.

Capture and restore process tests each repeat every selected boundary three times against
the same input, retaining earlier private workspaces. Capture covers Copied, Completed,
Published and ACK; restore covers Rebound, OriginFlushed, BundleVerified, Published and ACK.
Normal completion is repeated too. Unpublished paths can be retried successfully without
adopting abandoned workspaces. Retrying a published destination rejects without changing
its bytes. Each published restore supports an independent next
commit without changing origin, backup or source.

All 669 cases pass on each platform: 519 Storage, 27 Xdm and 123 Integration; zero final
failures/skips. Windows' six native-only branches return without native execution.

| Platform | New ET9-D positions | New actual native positions | Retained positions | All positions |
|----------|---------------------|-----------------------------|--------------------|---------------|
| Windows / NTFS | 4,770 | 0 | 2,162 | 6,932 |
| Linux / overlayfs | 7,242 | 2,568 | 2,579 | 9,821 |

Retained Linux positions include 481 actual native ET8 positions. Counts are measured from
each platform's own successful traces; path/operation differences are not normalized away.
The focused Windows matrix took 40m52s; the complete Linux Storage suite took 48m18s.
SDK 10.0.301, Windows runtime10.0.11 and Linux runtime10.0.9 in the pinned isolated image.

Machine-readable counts and platform evidence are in
[m2-epoch-backup-fault-results.json](m2-epoch-backup-fault-results.json).
Windows coverage combines the focused matrix, isolated Storage/Xdm regressions and the
canonical-layout Integration run. An exploratory isolated Integration run exposed the
existing sample-path assumption in ReopenTests; canonical-layout rerun passes. Linux runs
the complete suite in its standard layout, plus the final Integration batch that adds
same-path retry assertions. The later Integration results replace the earlier batch in
the aggregate case count; cases are not counted twice.

Existing metadata and frozen reader fixtures remain unchanged. There are no production
wire-format changes or new public APIs. These runs do not certify physical power-loss
behavior or actual capacity exhaustion; injected exceptions use the disk-full HRESULT.

Next: specify full-history migration/cutover and compatibility acceptance under ADR-008.
Keep original roots and all committed history; no retirement or reclamation is authorized.
