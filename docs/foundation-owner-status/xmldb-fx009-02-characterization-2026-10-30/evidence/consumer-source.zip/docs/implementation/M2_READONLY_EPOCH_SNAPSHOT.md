# M2 Read-Only Epoch Snapshot Contract

Implemented per [ADR-011](../ADR-011-admission-owned-read-only-epoch-snapshots.md).
Mandatory FORMAT/EPOCH/admission bytes from ADR-010 remain unchanged. This slice adds
immutable XML data and a separately versioned descriptor; it does not add mutable epoch
recovery or a public creation/migration path.

## Root Layout

FORMAT (BXDB 2.0), EPOCH (BXEP 1.0), .epoch/admission.lease (BXEA 1.0) and SNAPSHOT (BXES
1.0) are at the root. Data is documents/<document>/manifest.bin and directory.bin, plus
manifest-referenced fragments/<id>.bin. The M1 manifest/directory/fragment bytes remain
unchanged. There is exactly one FORMAT at the root, no nested M1 FORMAT, no transaction
tree and no generation/WAL selection. Unknown required major-2 fields/bits fail closed.

## SNAPSHOT: BXES 1.0

Use the existing bounded envelope: four-byte ASCII magic BXES, u16 major 1/minor 0,
i32 body length 112 (little endian), 112-byte body, 32-byte SHA-256 over header/body.
Complete size is 156 bytes. Reject invalid framing/version/checksum, truncation and
trailing bytes. All identities/digests must bind the admitted root.

| Absolute offset | Field | Encoding |
|-----------------|-------|----------|
| 12 | StoreId | 16 bytes, .NET Guid.ToByteArray order |
| 28 | EpochId | 16 bytes, same order |
| 44 | DocumentId | u64 little endian |
| 52 | Commit sequence | u64 little endian; must be zero |
| 60 | Mandatory FORMAT digest | SHA-256 of complete 99-byte FORMAT |
| 92 | Manifest digest | SHA-256 of complete document manifest |
| 124 | Descriptor integrity digest | SHA-256 over bytes 0..123 |

FORMAT/EPOCH/admission validation requires nonzero IDs and exact supported contracts.
SNAPSHOT must agree with that identity. A .transactions file or directory is unsupported
and causes rejection on Open/BeginRead. Neither a descriptor nor directory names can
select an unimplemented transaction head. A golden independent Python fixture is
tests/TestData/epoch-snapshot-v1.hex, including every truncation and a rechecksummed
nonzero-sequence rejection test.

## Public Read Path and Ownership

ReadOnlyEpochDatabase.Open reads identity, acquires existing shared admission, validates
SNAPSHOT and verifies manifest/directory metadata. A failed open releases every acquired
handle. No payload is read at this stage. The returned session exposes StoreId, EpochId,
DocumentId and BeginRead(cacheBytes), returning ImmutableXmlSnapshot at sequence zero.

BeginRead rechecks the descriptor against the session's immutable manifest identity,
forks a nonblocking shared child while the parent remains admitted and transfers it to
the snapshot. Its internal metadata loader checks a live shared token, exact root/identity
and expected manifest digest; legacy public loaders keep their original major-1 check.
Failures close the child, not another snapshot's handle. Negative cache arguments do
not acquire a child. Dispose closes only that session/snapshot's own handle; snapshots
outlive sessions. Existing thread confinement and BindResult rules still apply.

Fragment payloads are lazy and hash-checked on access, with existing metrics/cache
semantics. PersistentXdmNode accepts the returned snapshot directly. Header XPath and
line count queries do not read line payloads. A corrupt payload can therefore be detected
after Open succeeds; this is not an eager full-integrity audit or backup verifier.
Exclusive epoch maintenance conflicts with all active sessions and snapshots. Closing
or killing a process releases its handles without replacing the stable identity inode.

## Internal Fixture Production

Only tests/probes can prepare an epoch root: accept an immutable unadopted M1 source,
validate its manifest/fragments, create fresh StoreId/EpochId in sibling staging, copy
canonical documents/fragments without legacy FORMAT and write SNAPSHOT. Open and read
the staged root to verify all fragment digests/values before closing verification leases.
Then publish the whole directory with requested file/directory barriers. Source bytes
are retained. Staging is never routed as a final root. Publication errors/kill can leave
private .xmldb-epoch-* staging or an already-complete unacknowledged final root.

No existing root is overwritten. Transactional sources are refused rather than guessed
into a base export. All writes/namespace changes/barriers use ITransactionStorage; normal
read APIs never publish/repair/adopt anything. Migration, mutable epoch head/WAL recovery,
epoch backup and any committed-history deletion require later contracts and tests.

*Last updated: 2026-10-27*
