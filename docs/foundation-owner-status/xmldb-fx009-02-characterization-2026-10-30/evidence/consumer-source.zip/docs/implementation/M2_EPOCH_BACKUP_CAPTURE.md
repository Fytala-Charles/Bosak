# M2 ET9-B Internal Epoch Backup Capture

Date: 2026-10-27. Implements the capture gate of
[ADR-017](../ADR-017-epoch-full-history-backup-and-independent-restore.md) using unchanged
[frozen metadata1.0 bytes](M2_EPOCH_BACKUP_FORMAT_V1.md).
Restore, public APIs, full-history migration and ET9-D exhaustive fault qualification remain pending.

## Capture ownership and exact head

Internal EpochScalarCoordinator.CreateBackup validates the destination before mutating
owner state, then forks independent shared ScalarWal admission before the coordinator gate.
Under that gate it checks availability, root authority, complete retained history and the
cached owned head. CURRENT must be the exact canonical encoding for H, including H=0.
Missing materializations, incomplete WAL, corrupt dependencies or a lagging pointer fail;
capture does not repair the source or choose an older H. Persistence/verification failure
faults the owner; pure argument/path rejection does not.

The writer, gate and operation admission remain held through verification and publication.
Other commits wait; a disposal race after admission releases only the operation child.
Existing snapshots retain their own admission/generation handles and uncached values,
including after owner disposal. No source data, stable identity or original root is renamed,
replaced or deleted. Returned internal EpochBackupResult binds BackupId/source identity/H.

## Source closure and exclusions

EpochBackupStorage derives the exact base and all sequence1..H materializations from
bounded manifests, plus root FORMAT/EPOCH/BASE, CONTROL, canonical CURRENT and full WAL.
Generation FORMAT/witnesses are required. It bounds file count at100,000 and scans source
files/directories with ordinal path checks, depth64 and a400,000-entry traversal cap.

Only recognized runtime admission, writer, stable reader/reader temporary identities,
GUID-named private staging and canonical current temporaries are excluded. Unknown root,
.epoch, transaction or generation dependencies and unrelated empty directories fail.
Every encountered ancestor/entry is checked for links/reparse points. The source's private
failure debris remains untouched and is never promoted as authority.

Destination path guards reject existing roots, overlaps, aliases/devices and linked ancestors.
The parent must already exist. A new sibling .xmldb-epoch-backup-<guid> workspace is created
on the destination filesystem; bounded file copies create fresh files through the storage
seam. No cross-volume rename is assumed.

## Read-only artifact checks versus history verification

ReadArtifact checks BXEI/BXEZ binding, exact file/directory closure, lengths/hashes, canonical
source profile/FORMAT/EPOCH/BASE/CONTROL/CURRENT and generation FORMAT equality. Extra files,
case substitutions, unrelated empty directories and missing declared files fail before
any clone/ownership output. It never repairs or opens the sealed data as a live store.

ReadArtifact alone is not a full logical-history proof. A deliberately resealed wrong
logical operation can pass seal/closure/header checks while failing the complete-history
oracle. Call VerifyCopies for full proof; raw metadata DTOs are not verified-store tokens.

Capture runs both private verification oracles before sealing:

1. Complete clone: copy all declared bytes, create fresh local admission/runtime namespace,
   validate full history before Open, and require exact H/head with no redo, tail removal
   or CURRENT repair. Force all values at every sequence and compare all declared bytes.
2. Redo clone: copy only base/authority/WAL/CURRENT, create fresh local runtime namespace,
   replay exactly H generations and compare every regenerated file to the captured bytes.
   Force all values at every sequence and reject a different head or byte representation.

All expected files must be present before either oracle. Omitting generations in the redo
clone never excuses missing sealed generations. Clone identity bytes intentionally describe
the captured source epoch, but admission files/inodes and OS handles are freshly created
at private paths; source ownership is not copied. Neither sealed data nor user roots are
adopted or mutated. Close all clone handles before deleting only the exact owned clone path.

A nonreproducible but logically equivalent materialization can pass the complete oracle and
fail deterministic redo; both are required. This is a stricter backup guarantee than merely
reading the last visible snapshot. The second oracle is not redundant with file hashes.

## Seal and publication

After both oracles pass, write/flush inventory, then COMPLETE; recheck the exact sealed
artifact. Rename artifact/ to the absent destination and synchronize both parents. Cleanup
accepts only recognized, contained operation-owned clone names and an empty workspace.
Acknowledgment follows publication/barriers and cleanup. No runtime admission/readers are
copied into data/, so it is not an admitted mutable root and existing public readers still
reject it.

All writes/flushes/closes/directory creation, publication, owned cleanup and barriers use
ITransactionStorage. ProcessCrash is default; native Linux FileAndDirectoryFlush remains
explicit without fallback. A failure after publication can leave a complete unacknowledged
artifact. Retry into a fresh path; never merge/overwrite or discover/route private workspaces.
Failed private workspaces may remain. No source history reclamation is performed.

## Scope and next gate

[Validation](M2_EPOCH_BACKUP_CAPTURE_VALIDATION.md) covers fixed heads, exact bytes, both
oracles, old readers, ownership races, commit exclusion, representative rejection/failure
states, selected process kills and native Linux capture. It is not ET9-D exhaustive backup
storage-call fault coverage or physical power-loss/real ENOSPC certification.

Next ET9-C must rebind identities/WAL hashes and publish an independent store/origin bundle
from the immutable artifact. ET9-D full fault/native/process proof, full-history migration/
cutover, archived-reader C1-C3, public mutable APIs and retirement remain separate gates.
