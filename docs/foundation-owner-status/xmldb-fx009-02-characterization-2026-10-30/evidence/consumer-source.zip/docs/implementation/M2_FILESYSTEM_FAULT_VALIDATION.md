# M2 Filesystem Barrier and Fault Validation

## 1. Initial Gate Result and Scope

This report preserves the earlier Windows barrier gate. The subsequent [checkpoint validation](M2_CHECKPOINT_VALIDATION.md) supersedes current totals and records native Linux overlayfs execution, 144 tests per platform and the expanded checkpoint/reader fault matrix.


2026-10-26, Windows 10.0.26300 x64, .NET SDK 10.0.301/runtime 10.0.11, Release.
The complete suite passed **110 tests**: 62 Storage, 27 Xdm, 21 Integration, zero
failures/skips. Fifteen storage sweeps exercised **333 individual injected failure
positions** in addition to the previous real process-kill tests.
[Machine-readable summary](m2-storage-fault-results.json) was extracted from local
TRX output. It records the platform and what was not physically exercised.

This proves behavior under the tested injected errors and process crashes. It does
not certify Linux, physical ENOSPC, a filesystem/controller, or power-loss durability.
No disk was filled or system power interrupted. History reclamation is still disabled.

## 2. Storage Seam and Injected Errors

All transaction data creates, writes, flushes, closes, directory creates/barriers,
generation/root moves and incomplete-tail deletion use an internal storage adapter.
The production coordinator still acquires the actual OS-backed exclusive writer lease.
Read/decode paths and M1 import behavior remain unchanged.

A recording adapter calls the real temporary-store file operations, then injects a
disk-full-style IOException before/after an operation. Partial-write cases write a
real prefix of the requested bytes and then throw. File disposal always releases its
handle, including a simulated close error. Each sweep obtains a successful reference
trace and injects exactly once at every eligible observed boundary.

| Scenario | Before | After | Partial writes | Total |
|----------|--------|-------|----------------|-------|
| Initial sidecar/control adoption | 16 | 16 | 1 | 33 |
| Scalar commit | 49 | 49 | 8 | 106 |
| Redo without a published generation | 44 | 44 | 6 | 94 |
| Incomplete-tail cleanup/publication | 10 | 10 | 1 | 21 |
| Stronger-barrier adoption of existing history | 39 | 39 | 1 | 79 |
| Total | 158 | 158 | 17 | 333 |

Each position requires: an IOException and confirmed injection; no mixed XML state;
a released coordinator lease; two consistent recoveries; intact unrelated line data;
and a later successful commit. A live coordinator that suffered a commit persistence
error must reject new reads/writes until reopened. A complete WAL may make an
unacknowledged edit recover as committed; a partial final append recovers the old state.

## 3. Explicit Barrier Modes

The original Open(root, documentId) API remains available and selects ProcessCrash.
The overload Open(root, durability, documentId) exposes the requested per-owner mode.

| Mode | Behavior | Local validation |
|------|----------|------------------|
| ProcessCrash | File Flush(true), explicit ordering, no directory-persistence promise | Native Windows and injected faults/process kills passed |
| FileAndDirectoryFlush | File barriers plus Linux directory fsync; synchronizes pre-existing history before use | Windows rejects before adoption; ordering/failures modeled on Windows; native Linux branch not executed here |

There is no silent fallback when a requested platform/filesystem barrier fails.
The mode applies to that coordinator session, not a persisted store SLA. It does not
turn previous process-mode acknowledgments into a physical power-loss guarantee.

The stronger mode preflights the root, acquires ownership, synchronizes existing
files/directories bottom-up and root ancestors, then recovers. Directory creation and
new file entry creation have parent barriers. WAL file close plus WAL directory sync
precede generation publication. Generation rename syncs both parents. CURRENT's parent
sync completes before acknowledgment. An ordering test verifies these dependencies;
it also checks existing base synchronization precedes control adoption.

The Linux adapter uses open/fsync/close for directories and rejects syscall failures.
Windows has no implemented equivalent adapter here. See [ADR-005](../ADR-005-filesystem-barriers-and-checkpoint-gates.md)
for the source references and exact policy.

## 4. Reproduction

```sh
dotnet restore Bosak.XmlDb.slnx --locked-mode
dotnet build Bosak.XmlDb.slnx -c Release --no-restore
dotnet test Bosak.XmlDb.slnx -c Release --no-build --logger "trx;LogFilePrefix=m2-storage-faults" --results-directory .tools/m2-storage-fault-results
dotnet format Bosak.XmlDb.slnx --verify-no-changes --no-restore
pwsh tools/check-docs.ps1 -ProjectPath . -Strict
```

The Windows native suite deliberately checks rejection of directory mode without
creating .transactions. The same test includes an actual fsync commit/reopen branch
when run on Linux; configuring Linux CI is not a claim it has run.

## 5. Remaining Durability and Checkpoint Gates

Validate native directory behavior on intended Linux filesystems and storage; define
what Windows can support without overstating guarantees. Exercise actual bounded-volume
ENOSPC and controlled power/fault environments separately. Deterministic errors do
not model arbitrary device reordering or a device falsely reporting a completed flush.

The [checkpoint design](M2_CHECKPOINT_DESIGN.md) proposes non-deleting anchors first,
then reader leases across processes/coordinator lifetimes, then separately verified
reclamation. Neither checkpoints nor reader leases nor committed-history deletion
have been added by this step. Existing M1 and WAL bytes/golden fixtures are unchanged.

*Last updated: 2026-10-26*
