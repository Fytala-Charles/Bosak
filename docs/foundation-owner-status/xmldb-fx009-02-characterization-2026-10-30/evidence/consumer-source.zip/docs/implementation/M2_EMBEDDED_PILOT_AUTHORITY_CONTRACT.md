# Internal Embedded Pilot Selection and Work Authority Contract

Date: 2026-10-29. Authority backend design under [ADR-028](../ADR-028-embedded-pilot-selection-and-work-authority.md).
The user selected an internal embedded pilot. No external production application, new host,
writer-admission API, route callback, byte format or application execution is implemented here.

## 1. Consumer, Scope and Authority Owner

The proposed consumer is an internal test host composing existing administrative plans,
stopped reconciliation and explicit scalar operations. EmbeddedQuickstart remains unchanged.
One controlled process owns a configured deployment/resource scope, all ingress, application
writers and publishers. There is no external queue, remote worker, server or automatic retry.
An unenumerated writer, background task or old binary invalidates this controlled scope.

Use a separate local application-authority root disjoint from the administrative host root,
source, artifacts, candidates and workspaces. The existing administrative root still has exactly
its current three roles. The new root's names, bounds, path identity checks and provisioning
bytes belong to EP7-B/C; this document does not authorize creating it. No nested store root.

The future authority session must hold a real opaque child registration under the retained
administrative owner plus exclusive stable ownership of the authority root. Bind authority ID,
administrative journal ID, deployment/resource scope and current owner session. Acquire admin
ownership before authority ownership; release in reverse only after all actual child work ends.
If either acquisition/validation fails, admit no work. Foreign/disposed/faulted registrations
reject. This needs a new reviewed lifetime mode: it cannot reuse the EP6 stopped registration,
which excludes admissions, or disguise application work as today's administrative count.

Database writers and new publication dispatch are mutually excluded for the initial pilot.
Selection change requires both quiescent. Do not hold lifetime/journal locks during database
I/O, artifact inspection or callbacks; use retained exclusive mode/registrations across those
gaps. Keep MG5 scopes on their caller thread; no await/serialization of freeze capabilities.

## 2. Enrollment and Retained Baseline

Explicit enrollment starts stopped under operator-controlled scope and proven prior executor
exclusion. Inventory all ingress and outstanding work; cancel or drain it to actual completion.
Unknown pre-enrollment work cannot become zero because a new file was created. Record a fresh
baseline ID binding the controlled source identity, verified head/history commitment and the
scope of reconciled prior work. Claims are supplied operational facts until EP7-D proves the
pilot actually controls them; a classifier cannot manufacture this evidence.

Register a candidate only after separate publication verification and exact artifact/attempt
correlation, fresh identity/history checks and continuing exclusion. Candidate registration is
not selection, acknowledgment of an unknown pipeline return or permission to write. Bind the
candidate's initial verified head and the same baseline. Missing or contradictory registration
keeps both roots stopped. All work since the baseline on either branch stays in the authority
history; no resets, compaction, branch removal or history deletion are defined.

The legacy source has no epoch IDs. Its binding is the controlled canonical root/admission
identity, document ID, format/profile and verified baseline history commitment, with explicit
limitations of its identity evidence. Never fabricate StoreId/EpochId or assume a path/document
ID alone uniquely identifies a legacy root. Epoch targets require actual StoreId/EpochId,
document ID, profile and controlled canonical root identity. Runtime lock files are not data
history pins; reuse established history/inventory definitions without changing frozen formats.
Aliases, replacement, duplicate/ambiguous identities or changed baseline commitments reject.

## 3. Logical Authority and Conditional Selection

A single bounded append-only application journal orders enrollment, candidate registration,
selection and work obligations. Its logical head is authority ID plus global sequence and digest;
selection also has a checked monotonically increasing revision. These are separate from store
H, admin attempt revision and owner generation. Validate the full retained chain and exact
expected head before every append. No numeric revision alone permits an ABA target change.

| Logical record | Required binding |
|----------------|------------------|
| Enrollment | Authority/admin IDs, configured scope, baseline, initial source target and prior-work reconciliation |
| Candidate registration | Baseline, exact target identity/initial history and publication attempt/artifact commitment |
| Selection change | Exact expected global head, previous selection/revision, new registered target, continuing exclusion and zero-work assessment |
| Work accepted | Fresh work ID, baseline, selected target/revision, immutable request commitment and owner |
| Work outcome | Exact accepted work ID/intent/target, independently observed actual outcome or unresolved status; no removal of acceptance |
| Reconciliation observation | Explicit scoped fresh findings and retained evidence references; no dispatch or inferred acknowledgment |

These names are logical concepts, not assigned wire events or permission to extend BXHJ v1.
EP7-B must specify canonical bytes, transition validation, cumulative bounds, overflow rejection,
no-overwrite provisioning and independent fixtures before implementing persistence.

Selection change requires closed ingress/admissions, no running application/publisher work,
exact fresh source/candidate readiness and complete accounting of both branches since baseline.
For this conservative pilot, any accepted work since baseline disqualifies initial cutover or
no-work return even if completed/aborted. A new controlled migration/baseline workflow would
need its own reconciliation design; it cannot erase old obligations or reset counters here.

Conditional update compares the exact head and previous target/revision under continuous
ownership. Append and qualify the new selection before returning acknowledgment. A stale
head/target rejects without writes. A failure after write begins faults the session and closes
admissions. A fresh stopped read may find the previous selection, a complete new selection or
corruption; none retroactively acknowledges the call. Retain all bytes and reconcile against
actual root/work facts. Unknown selection permits no use of either branch for application writes.
A selection observation never grants admission by itself.

## 4. Application Work Acceptance

Acceptance means the host has assumed responsibility for a specific request, before database
mutation and before telling the caller it was accepted. It is not network arrival, queue polling,
transaction commit, callback return or client receipt of acknowledgment. The live host must:

1. Acquire the actual application operation registration while admissions are explicitly open.
2. Under the authority serializer, capture the exact selected target/revision/head, allocate a
   fresh host work ID and bind immutable intent bytes/digest. Reject duplicate IDs, stale selection,
   unknown prior outcome or capacity exhaustion before writes. A fresh ID is not idempotency.
3. Append WorkAccepted and complete the qualified file flush/readback boundary before mutation
   or accepted acknowledgment. Keep the same selected-root registration throughout execution.
4. Execute at most once through the live operation, outside journal/lifetime locks. Bind the
   actual transaction to the recorded target; caller cancellation/timeout cannot untrack it.
5. Record a verified actual outcome separately. A returned commit can be recorded as such;
   an exception after possible commit remains unresolved until independently reconciled.
   Do not infer the specific operation from H advancement or payload equality.
6. Release registration only after actual executor completion. Completion never subtracts the
   historical accepted count. Even confirmed no-effect acceptance bars the pilot's no-work return.

A pre-write rejection with proven unchanged head may leave the session usable. Any uncertain
acceptance append stops it and invokes no database operation through that call. On restart,
a structurally valid observed acceptance is conservatively an obligation even if flush/client
acknowledgment is unknown. Complete valid records are retained; partial/corrupt tails stop all
admission without truncation or scanning ahead. Pending work is never replayed from saved intent.
Lost database acknowledgment, completion-save failure or caller death leaves possible effects;
record/inspect the uncertainty, retain both histories and require reconciliation.

The first persistence target is ProcessCrash on qualified local filesystems, using explicit
file flush and readback with ownership/namespace rules defined in EP7-B/C. A buffered append
is insufficient. Other policies reject until designed/qualified; no silent durability fallback.

## 5. Cutover, Shutdown and Restart

Publication, admin acknowledgment, application selection, work acceptance and database commit
are distinct boundaries. No atomic cross-journal commit is assumed. Candidate publication can
exist while source remains selected; retain it. A matching provenance file never selects it.
Recheck exact admin attempt evidence under continued exclusion before a selection proposal;
admin journal and application authority references must agree without fabricating receipts.

Close application ingress before closing admissions; account for requests already accepted,
then drain all actual operations/publishers before any selection mutation or ownership release.
A timeout is not drain. If the host cannot establish completion, remain stopped and retain
ownership until controlled termination; final process exit only covers the proved in-process
scope. Reader/snapshot handles still obey storage ownership; their existence/absence is not
inferred from these counts and cannot authorize deletion.

Every reopen starts stopped with no reconstructed executable work, plan, ticket or readiness.
Acquire ownership in order; validate complete bounded histories; independently establish
operational freshness/exclusion; inspect exact registered roots and pending obligations.

| Restart observation | Required disposition |
|---------------------|----------------------|
| Selection and both-branch zero-work evidence agree under fresh exclusion | Eligible only for a separate explicit readiness workflow; still stopped |
| Accepted work exists, even completed | Keep historical obligation; no automatic return/cutover; reconcile the branch |
| Accepted work lacks a proven outcome | Preserve possible effects; no replay, retry or zero-work assertion |
| Published candidate but no agreed selection | Retain candidate; no implicit selection or receipt synthesis |
| Missing/unavailable authority, corrupt tail, unknown ownership or changed roots | Reconciliation; preserve bytes and both branches |
| Valid-looking old prefix or uncertain offline restore | Independent freshness/reconciliation required; no inferred newest head |
| Admin publication and application selection/work references disagree | Stop; neither journal can overwrite the other's evidence |

A local journal/owner lock cannot independently detect an offline coherent rollback of all
host files. The controlled scope excludes unattended host-state replacement/restore. After
restart, explicit deployment freshness facts and reconciled root/work observations are required;
missing facts stay unknown. No hash chain, unlocked lease, clean H or empty journal proves
freshness, zero work, old-reader absence or permission to resume writers.

## 6. Qualification Gates and Immediate Next Work

| Gate | Deliverable and required evidence | Status |
|------|----------------------------------|--------|
| EP7-A | Pure internal authority classifier with exact scope/target/revision/baseline and freshness/work uncertainty cases; no I/O/callback, every result stopped | Implemented internally; see classification validation |
| EP7-B | Separate bounded application-journal format/transition specification, provisioning/commit rules and independent metadata vectors; no changes to BXHM/BXHJ | Pure codec/full-history validator implemented; persistence pending |
| EP7-C | Actual owner-bound lifetime, persistent conditional append, uncertainty, alias/namespace/rollback limitations and process/partial-write tests | Pending |
| EP7-D | Internal consuming host with actual ingress/registration, selected target binding, acceptance-before-mutation and process-kill/restart evidence | Pending |

EP7-A tests must cover a valid stopped zero-work assessment and malformed, foreign, stale,
missing, contradictory, overflow and duplicate-work cases. Unknown is never encoded as zero.
Model supplied facts explicitly; classification cannot create write authority or validate files.

Later runtime qualification must kill before/after selection write/flush/readback/acknowledgment,
acceptance write/flush/acknowledgment, database invocation/return and outcome save. Race work
acceptance against selection/shutdown; test stale head, simultaneous callers, lost acknowledgments,
actual pending executor drain, old-prefix restoration, foreign owner/registration and changed
root identities. Assert no mutation before qualified acceptance, no wrong-root execution,
no replay on reopen, all-history retention and preservation of existing frozen hashes/formats.

This design adds no public API, actual route change or writer enablement. HA2 external consumer,
archived releases, physical power-loss/real ENOSPC and release qualification remain open.
Keep proprietary licensing, Bosak 1.26.2, disabled packaging and CanReclaim=false.

## 7. Evidence and Delivery

This is documentation-only continuation of the post-EP6-D review on baseline `4598346`.
The preceding full Windows run passed 1,894 tests; no runtime/test/fixture changes follow it.
It qualifies existing code, not this proposed authority backend. Fresh Linux execution remains
blocked by the unavailable Docker engine. New format/runtime tests are not claimed here.
See [readiness evidence](m2-post-ep6-readiness-results.json) for the completed regression scope.

EP7-A implementation follow-up (2026-10-29): [validation](M2_EMBEDDED_PILOT_AUTHORITY_CLASSIFICATION_VALIDATION.md)
qualifies pure stopped classification, not verification of host facts or executable authority.
Its 1,024-work-record input bound does not freeze an on-disk limit. Next EP7-B specifies the
separate application-authority format, transitions and commit/provisioning contract.

EP7-B follow-up (2026-10-29): [v1 format](M2_APPLICATION_AUTHORITY_FORMAT_V1.md) and
[specification validation](M2_APPLICATION_AUTHORITY_FORMAT_VALIDATION.md) define the bytes,
transitions and two metadata-only vectors. Next implement the pure codec/full-history validator
before EP7-C persistence. Existing host/store formats, admissions and all histories are unchanged.

Pure codec follow-up: [validation](M2_APPLICATION_AUTHORITY_CODEC_VALIDATION.md) qualifies
strict complete histories and stopped decoded results. Next EP7-C owner-bound application
child lifetime/existing-root inspection before provisioning/persistence; EP7-D execution pending.

EP7-C existing-root follow-up (2026-10-29): [ADR-030](../ADR-030-paired-read-only-application-authority-ownership.md)
and [validation](M2_APPLICATION_AUTHORITY_LIFETIME_VALIDATION.md) implement actual paired
read-only ownership/inspection with native identity and actual drain. Explicit provisioning,
initializer-only first enrollment and append remain pending; empty reopen stays stopped.
