# M2 ET9-C Independent Epoch Restore Validation

Date: 2026-10-27. Implements the bounded restore gate of
[ADR-017](../ADR-017-epoch-full-history-backup-and-independent-restore.md); see
[runtime contract](M2_EPOCH_BACKUP_RESTORE.md). Existing formats, public APIs, frozen metadata
fixtures, proprietary licensing and package pins remain unchanged. ET9-D remains pending.

## New proof

Thirty-one Storage and six Integration cases cover:

- H=0/1/3 restore with fresh store/epoch identity and exact origin binding. Compare every
  WAL record/transaction/sequence and every node's topology/order/namespaces/URI/value at
  each retained sequence. Include text and empty ordinary attribute changes. Destination
  manifests/directories/fragments remain byte-identical; WAL bindings/digests change.
- Old source identity cannot admit the restored root. Format-1/immutable public readers
  reject it; the restore bundle itself cannot be opened as a store. Returned StorePath
  opens after publication and snapshots remain valid after their new owner closes.
- Repeated restores have distinct fresh identities/RestoreIds. Writes to source and one
  restored branch do not change the second branch or backup. Origin bytes retain the
  initial restored prefix after later branch commits.
- Missing/corrupt metadata/WAL/generations, extra directories and wrong-role metadata fail
  read-only before workspace creation. Existing/overlapping source/backup/parent/destination
  roots are never replaced. Linux link-boundary checks are conditional on Linux.
- A fully resealed wrong source operation passes seal/header reading but fails the full
  source oracle before rebinding. Changed source-copy/rebound data, resealed origin
  inventory/source/destination identity substitution and missing initial readers fail before
  publication. No source repair or copied ownership is accepted.
- Seven selected checkpoint exceptions preserve original source and sealed backup. Only
  the post-publication case leaves a final complete bundle. A native Linux strong-policy
  restore runs with a live source snapshot and reopens the fresh root.
- Fresh-process normal restore and kills after rebinding, origin flush, complete-bundle
  verification, publication and returned acknowledgment. Only a complete published bundle
  is at the final path; repeated fresh opens reproduce H=3/header/line state and an
  independent H=4 write leaves source, backup and initial origin unchanged.

## Full regression results

| Platform | Storage | Xdm | Integration | Total | Failed / skipped |
|----------|---------|-----|-------------|-------|------------------|
| Windows | 501 | 27 | 123 | 651 | 0 / 0 |
| Ubuntu24.04.4 / overlayfs | 501 | 27 | 123 | 651 | 0 / 0 |

Final TRX: .tools/et9c-windows-results and .tools/et9c-linux-results.
[Structured evidence](m2-epoch-backup-restore-results.json) records cases and limits.
Existing 2,162 Windows /2,579 Linux fault positions (481 native ET8 Linux) remain regression
coverage, not new exhaustive restore/capture fault sweeps. Three new ET9-C Linux-only
branches return explicitly on Windows: two link cases and native stronger restore.

SDK10.0.301; Windows dotnet10.0.11; Linux10.0.9 in the pinned network-disabled container,
source/cache read-only and test temp overlayfs. Formatting and strict docs pass. Known
MINVER1001 warnings may occur in isolated/unversioned builds; no commit/release was made.
The frozen BXEI/BXEZ/BXEO metadata bytes and both historical reader families are unchanged.

## Reproduce and remaining gates

```powershell
dotnet test Bosak.XmlDb.slnx -c Release --no-restore --logger 'trx;LogFilePrefix=windows' --results-directory .tools/et9c-windows-results
$env:DOTNET_ROLL_FORWARD = 'Major'
& ./.tools/pwsh.exe -NoProfile -File tools/test-linux.ps1 -ResultsDirectory .tools/et9c-linux-results
dotnet format Bosak.XmlDb.slnx --no-restore --verify-no-changes
& ./.tools/pwsh.exe -NoProfile -File tools/check-docs.ps1 -ProjectPath . -Strict
```

ET9-C is internal restore, not ET9 completion. Next ET9-D must cover every observed
capture/restore write/flush/close/rename/barrier failure before/after, partial writes,
repeated verification/process interruption, acknowledgment loss and native Linux failure
paths. Public epoch APIs, full-history migration/cutover, full archived-reader C1-C3 and
retirement remain pending. No history reduction, source replacement, cleanup scans or
physical power-loss/real ENOSPC/production-controller/remote-CI certification is implied.
