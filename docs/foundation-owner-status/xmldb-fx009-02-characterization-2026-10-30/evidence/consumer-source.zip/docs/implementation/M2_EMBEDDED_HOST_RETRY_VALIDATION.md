# Explicit Fresh-Plan Retry Validation

Date: 2026-10-29. EP6-C implements the explicit retry boundary in
[ADR-027](../ADR-027-stopped-embedded-restart-reconciliation.md).

## 1. Implemented Behavior

PrepareRetry requires the exact latest ReconciledAbsent request snapshot owned by the current
host session, with no receipt/observation, and fresh bound controlled-writer/publisher exclusion,
drained queue, stable namespace and no-retained-publication assertions. These facts are trusted
host input and must remain valid throughout the workflow; they do not fence hostile publishers.
Administrative admissions and journal append must already have been explicitly enabled by a
separate readiness decision. A reconciler result alone never opens admissions or starts retry.

The orchestrator rereads complete history, selects the latest RecordIntent for the business
request, checks its exact terminal snapshot and invokes the real pinned publication inspector.
Only NotObserved is eligible. It prepares a new real library plan with a different attempt ID;
the entire descriptor except that ID must equal the prior descriptor. Request ID, artifact pin,
role, backup identity, destination and durability stay fixed. It rechecks evidence/history/absence
after preparing; old plans and tickets are never reset or reconstructed.

The new private owner-bound ticket retains its retry evidence. Record rechecks it and reinspects
before saving. The save uses the exact journal position captured for that check; another front's
intervening write becomes a conflict rather than adopting a new head. Competing retry records
cannot both become current. Ordinary Record rejects any existing request ID, so callers cannot
bypass the retry evidence checks by using normal Prepare/Record. A claimed record failure stops the front and closes admissions;
an uncertain write faults the lifetime. A failed ticket cannot dispatch even if its new intent
frame is complete on disk. Existing EP5 single-use execution handles a successfully recorded
retry without a replay path, preserving original absent history and every candidate.

## 2. Qualification

22 new Integration cases cover both roles at H=0/H=3, nine invalid binding/exclusion facts,
changed artifact/destination before prepare and record, competing prepared tickets across fronts,
actual concurrent record attempts, closed admissions and lost retry-intent acknowledgment.
The initial 17-case Windows run passed; five additional boundary cases are included in the
final focused Windows/Linux runs. All 983 focused cases pass per platform (732 Storage and
251 Integration), with zero failures/skips. Formatting and Windows/Linux strict documentation/
portability checks pass. Public Storage metadata remains at 95 signatures; all 56 tracked
TestData files are unchanged under Git attributes. Counts and TRX references are in the
[machine evidence](m2-embedded-host-retry-results.json). This is not an unfiltered full-suite
run, process-kill qualification or physical durability proof. Public API and wire formats remain
unchanged; no routing, writer resumption, reclamation or automatic retry is enabled.

## 3. Delivery and Next Work

EP6-A/B is committed/pushed as `8d38762`; EP6-C remains local/uncommitted. Next qualify the
full transfer/outcome/fresh-intent workflow with process termination around each persistence
and acknowledgment boundary, including reopen remaining stopped and retaining candidates.
Do not infer process-kill coverage from injected exceptions. Application routing/work authority,
public release/archived-reader proof, global fencing and physical durability gates remain open.
