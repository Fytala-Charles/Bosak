# M2 Mandatory Epoch Format and Admission Primitive Validation

Date: 2026-10-27. Scope: [ADR-010](../ADR-010-mandatory-epoch-format-and-admission-primitives.md).
**218 tests pass on Windows and 218 on Linux**, zero failures/skips in either full run:
136 Storage, 27 Xdm, 55 Integration. Release builds use SDK 10.0.301; Windows runtime
10.0.11 and Ubuntu 24.04 runtime 10.0.9 / Docker overlayfs. Seven existing MINVER1001
warnings per build remain; no warning was suppressed or release tag created.

Thirty-three fault sweep cases validate **1,100 Windows / 1,068 Linux positions**,
including **61 / 53 epoch-bootstrap positions**. Counts differ with path ancestry.
[Structured evidence](m2-epoch-results.json) includes per-scenario counts and frozen
reader provenance. TRX is in .tools/epoch-windows-results and .tools/epoch-linux-results.
Formatting verification and strict FYTALA documentation checks pass.

## Evidence and Remaining Gates

| Area | Implemented checks | Remaining limit |
|------|--------------------|-----------------|
| C1 boundary | Current public Open overloads and hash-verified frozen format-1 Storage/Core binaries reject major 2 without adoption writes | No archived pre-lease/released binary is available; complete C1 remains open |
| Required contracts | Independent byte fixtures, truncation, rechecksummed unknown major/minor/flags/reader/writer/recovery/features | No new-format XML data decoder or writer is shipped |
| C2 bootstrap | All before/after persistence calls and partial writes; kills at metadata flush/publish/ack boundaries | Metadata-only fixture publication, not data migration or application cutover |
| C3 ownership | Child OS handles survive parent disposal; shared/exclusive conflicts across processes; close/kill releases; bytes unchanged | Actual epoch snapshots/transactions/backups/coordinator integration still pending |
| Identity/corruption | Wrong store/epoch/document, corrupt/missing descriptors or admission file refused without recreation | Cooperative filesystem and fixed root paths required |
| Native barriers | Linux FileAndDirectoryFlush bootstrap with real fsync; Windows modeled policy and ProcessCrash | No physical power loss/real ENOSPC certification |

Nineteen new Storage cases and thirteen Integration cases exercise the primitives.
The latter include four frozen-reader overloads, five bootstrap kill/ack cases and
four cross-process shared/exclusive close/kill cases. Existing format-1 behavior and
backup/restore tests remain part of the full regression suite.

## Frozen Reader Provenance

Captured from the built post-backup format-1 implementation before epoch source existed:

- Bosak.XmlDb.Storage.dll: 88c16e73bccf0641b8bcc1392c4ab9d038cd9bbd025100eb5cc6404a5ba0d67c
- Bosak.XmlDb.Core.dll: 60a9af0eed267cb20d55ffb507ed3ae2c5102a5c18c0151d45e99b701e590804

Both are proprietary Fytala managed binaries, about 100 KiB total, with a capture manifest
and fixture README. No third-party runtime binary is added. The subprocess verifies
hashes, loads Core then Storage in a separate collectible AssemblyLoadContext and calls
raw/default/durability/recovery Open. Accepted opens or mutation are test failures.
There is no Git commit/release provenance because this checkout has no initial commit;
these are exact local baseline evidence, not a claim about every historical build.

## Reproduction

```powershell
dotnet build Bosak.XmlDb.slnx -c Release --no-restore
dotnet test Bosak.XmlDb.slnx -c Release --no-build --logger 'trx;LogFilePrefix=epoch' --results-directory .tools/epoch-windows-results
pwsh tools/test-linux.ps1 -ResultsDirectory .tools/epoch-linux-results
```

The Linux helper uses pinned SDK 10.0.301, read-only source/cache, isolated /work and no
network. Full results and actual fault counts are recorded above. No user
store migration, new public data API, committed-history deletion, remote publication,
production filesystem/controller or physical durability certification is performed.

*Last updated: 2026-10-27*
