# RC2 Explicit Planned Administrative Execution

Date: 2026-10-28. Internal execution under
[ADR-020](../ADR-020-planned-administrative-attempt-correlation.md). No public API, new
provenance layout, descriptor replay, automatic retry, routing or reclamation is enabled.

## 1. Claim and Bound Pipeline Entry

ScalarEpochAdministration.ExecuteAttempt accepts only an opaque plan created by that
administration. Before filesystem work, it consumes the same owner/policy-bound atomic
claim used by RC1. A pure ClaimAttempt followed by ExecuteAttempt therefore rejects as
already dispatched. Null/foreign plans reject without consuming another owner's plan.

A private-constructor EpochAttemptExecution can be created only by successful plan claim.
It carries immutable intent and allows one pipeline entry. Role, original absolute roots,
policy and ScalarWal target must match; repurposing/reusing even a rejected entry fails
before filesystem I/O. A descriptive record cannot recreate this execution context.
Plan state remains Dispatched after success or failure: consumed local state, not an
acknowledgment. A normal returned receipt versus an exception describes the call outcome.

## 2. Input Pinning and Existing Provenance Fields

The legacy/epoch pipelines accept an optional internal claimed context. Planned paths
require exact pinned inventory SHA and source BackupId/document/H/optional epoch before
verification output. Legacy verification receives the expected hash and rejects mismatch
before private copies/barriers. The source inventory is checked again after source-proof
callbacks. Existing copy/data mapping, full complete/redo oracles, runtime validation,
provenance byte checks and final sealed-input checks remain required before publication.

The preknown attempt ID fills the existing MigrationId or RestoreId field. Fresh destination
StoreId/EpochId, every retained sequence and source transaction/document/node identities
remain unchanged in meaning. BXEM/BXEO layouts, role rules and frozen vectors are unchanged.
With no claimed context, old entry points retain their internal fresh-ID selection and
existing I/O path; default optional checks do not add storage calls. Prior unplanned
fault matrices remain prior evidence, not a new planned exhaustive sweep.

Binding checks are point-in-time checks under the existing sealed-input/owned-namespace
assumptions. They are not a global filesystem snapshot, external writer fence or signature.
Changed sealed bytes with a valid replacement seal still reject a plan pinned to the original
inventory. Same H or BackupId alone cannot repurpose its intent.

## 3. Uncertain Outcomes and Retry

Failures leave the plan consumed. No catch converts I/O into NotPublished, synthesizes an
acknowledged receipt from PA3 or retries a pipeline. The test seams cover errors after actual
bundle rename, before the Published callback, and after workspace cleanup. A valid candidate
can remain in each case with no acknowledged receipt. Descriptor-based PA3 inspection then
matches the preknown attempt ID while still returning only observation and keeping writers
stopped. An existing destination is never overwritten or silently adopted.

An explicit new attempt uses a new administration/plan/ID only after the old synchronous
executor has returned and the test observes no target. This is local controlled evidence,
not a general absence-based retry permit. Process death, simultaneous publishers and
restart/retry ownership require RC3 and actual host protocols. Descriptors cannot execute.

## 4. Qualification

31 new friend-consumer cases cover both roles at H0/H3 and every historical value; exact
preknown IDs and source metadata; null/foreign/preclaimed attempts; resealed changed input,
existing target and missing source rejected before mutation/barrier calls; ten selected
publication/proof/rename/cleanup failures; post-proof inventory replacement; pipeline role/
path/policy repurposing and replay refusal; the verifier's pre-output inventory guard; and
actual native planned execution on Linux. Windows asserts unsupported native policy and
does not execute the native branch.

Input and published byte/file/directory inventories are preserved across failures and
refused retries. Zero-call tracking storage makes early rejection fail if a write/barrier
is attempted. Unplanned migration/restore/capture/verifier suites run alongside RC1/PA/HC/
compatibility/scalar regressions. [Results](m2-administrative-attempt-execution-results.json)
record the focused cross-platform batch and four frozen DLL/15 metadata fixture hashes.
The catalog grows from 1,079 to 1,110; this is not a fresh unfiltered full run. Retain the
consolidated baseline and previous exhaustive traces at their original scope. Formatting,
strict documentation, portable hygiene and unchanged public metadata are checked.

## 5. Repository State and Next Work

The owner requested commit/push before this step. Commit a3b578c includes validated work
through RC1 and is pushed to main. RC2 is subsequent local work. Hosted CI for a3b578c is
separate from current RC2 validation; no current-source hosted success is inferred.

Next RC3: process boundaries for preannounced descriptors and lost acknowledgments, killed
publishers and read-only restart inspection, competing same/different plans, and explicit
new-ID retry qualification under proven executor exit. Keep actual host ledger/exclusion/
accepted-work/routing and archived/public/physical/release gates open. CanReclaim=false;
retain all original paths, stable identities and every committed history.
