# PA2 Internal Administrative Facade Validation

Date: 2026-10-28. Internal prototype under
[ADR-019](../ADR-019-explicit-mutable-api-and-host-cutover-boundary.md). No public surface,
new binary format, durable receipt, application routing or reclamation is introduced.

## 1. Administrative Surface

ScalarEpochAdministration is a separate internal object with explicit durability options.
It does not own/open a live source coordinator and has no configuration or route callbacks.
CreateCore and administrative checkpoint callbacks are test-only seams. Requested policy
must match injected storage; native policy has no fallback. Operations preserve underlying
exceptions and never silently retry, overwrite destinations or adopt old workspaces.

| Operation | Behavior / acknowledged result |
|-----------|--------------------------------|
| VerifyLegacyBackup | Existing strict sealed preflight plus private complete/full-redo proof; profile/BackupId/document/H/inventory SHA receipt, no source epoch fabricated |
| VerifyEpochBackup | Exact seal/closure/headers, private complete/full-redo copies, then final artifact/inventory recheck; source epoch and inventory SHA receipt |
| ConvertLegacyBackup | Existing MG3 fresh-epoch verified bundle publication; migration ID, source backup ID, destination epoch/H and actual returned store path |
| RestoreEpochBackup | Existing ET9 independent fresh-epoch restore; restore ID, source backup/epoch, destination epoch/H and store path |

Verification requires an explicit nonexisting disjoint placement hint under an existing
parent. The hint itself is not published; a fresh nonce workspace is placed beside it.
Successful cleanup removes only the operation's named verification clones and empty workspace.
Failures may retain owned workspaces; later calls never scan, delete or adopt them.
Existing unidentified workspace sentinels remain untouched.

Bounds are inherited from the frozen codecs and bounded tree traversal: sequence/count/path/
per-file limits and exact supported closure. This is not a configurable aggregate disk quota,
free-space reservation or real ENOSPC guarantee. Verification can write substantial private
copies even though source/backup bytes are read-only. No coordinator opens sealed input.

Standalone epoch verification pins original inventory bytes before proof, checks canonical
inventory/header closure, invokes both existing independent oracles, then rechecks artifact
closure/content and exact inventory bytes before returning. Legacy verification delegates
to MG2 and additionally binds its receipt to the original inventory bytes. Neither receipt
is a reusable freshness capability, source authenticity proof or routing/recovery authority.
A concurrently changed artifact must be verified again, not trusted from an old receipt.

## 2. Publication and Uncertain Outcomes

EpochPublishedReceipt is returned only after the existing pipeline returns normally,
including publication and normal workspace cleanup. It contains the actual store/ path,
not the bundle wrapper path. Its metadata binds the initial operation, not later branch
commits. It is an in-memory record with no codec or restart/idempotency authority.

Injected failures after source proof or final bundle proof can leave no published destination;
a failure immediately after namespace publication can leave a fully valid candidate despite
returning no receipt. Cleanup errors after publication can also be uncertain. The facade
preserves the exception and does not label it NotPublished, delete candidates, route traffic
or retry automatically. Caller observation in tests establishes which outcome occurred; the
exception itself does not. Retrying against an existing destination is rejected without
changing that destination. Explicit fresh verification/reconciliation is required.

## 3. Validation

29 new friend-consumer Integration cases cover H0/H3 verification and publication for both
profiles; bound receipt metadata and every historical value; old uncached readers; six
before/after-publication failures with retry behavior; wrong artifact roles; post-proof
input mutation; corrupt seals; resealed logical WAL corruption; placement rejection; invalid
options; and native proof. Input snapshots compare all original source/backup/initial-bundle
file bytes and directory inventories. Intentional mutation cases are labeled separately.

The resealed logical corruption fixture passes seal/hash/header preflight and then fails
complete-history verification; ProofVerified is never reported. The final-input mutation
cases change inventory bytes after both oracles and must fail before receipt return.
Existing private-oracle tests retain independent redo-specific adversarial coverage.

[Results](m2-scalar-epoch-administration-results.json) record new cases plus the relevant
PA1/verifier/capture/migration/restore regressions. The previous 978-case catalog grows to
1,007; no new unfiltered full run or rerun of expensive fault matrices is claimed. Frozen
DLL hashes, public signatures, formats, proprietary license and disabled packaging remain
unchanged. Linux executes actual native private proof; Windows rejects native policy and
is not native directory-flush evidence. Formatting and strict documentation are checked.

## 4. Remaining Gates and Next Work

PA2 is an internal administrative prototype, not complete public administration/release
qualification. Public API/diagnostic review, actual host/external writer exclusion/routing/
restart proof, archived reader provenance and physical/controller durability remain open.
Keep all histories and CanReclaim=false. No result authorizes retirement.

Next PA3: read-only publication inspection for unacknowledged administrative outcomes.
Bind observations to the requested artifact and destination, validate published provenance/
history without adopting/recovering the candidate, and return uncertainty/reconciliation
rather than inferred routing authority. A matching artifact alone must not be described as
proof that a particular lost request published it when its operation ID is unknown.
