# HC1 Pure Restart and Reconciliation Classification

Date: 2026-10-28. Implements only HC1 under
[ADR-019](../ADR-019-explicit-mutable-api-and-host-cutover-boundary.md). No adapter, owning
Open, recovery, route callback, receipt replay or persistent host record is added.

## 1. Inputs and Trust Boundary

MigrationRestartClassifier consumes immutable in-memory observation records. Every record
binds the same operation context: operation/Migration/Backup IDs, destination store/epoch/
document, original sequence, opaque canonical source/candidate root keys and source/candidate
full-history commitment strings. There is no invented source epoch identity. Root keys are
compared as supplied, not resolved; case-insensitive equal source/candidate keys are refused
conservatively. Digests must be canonical 64-character lowercase hex and H is bounded at
10,000, matching the internal migration limit.

Ownership, history, accepted-work accounting and routing are separate required observations.
All must be fresh and context-equal. Ownership asserts external exclusion, no possible writer
overlap and reacquired owners. Histories must both exactly match the initial commitments;
work must be drained with zero accepted work. Routing must be authoritative, select the exact
legacy root with no epoch or exact candidate root/epoch, and have a nonempty revision equal
to the separately supplied confirmed revision. Revisions are opaque and have no inferred
ordering. Different-context same-H commitments are rejected.

These are caller assertions, not capabilities or verified host facts. The classifier does
not inspect storage, authenticate digests, prove canonical paths, establish exclusion or
confirm revisions itself. A future host must obtain independently authoritative observations.
Copying the same string into both revision fields is not a real host confirmation protocol.
Records have no codec, durable schema or deserialization contract.

## 2. Decision Rules

All results have WritersMustRemainStopped=true, including eligibility outcomes. They cannot
resume work, route requests or restore an old MG5 receipt. Null/missing, malformed, stale,
foreign-context, changed/unknown history, accepted/unknown work, possible overlap, lost
ownership or unknown/foreign route observations require ReconciliationRequired.

| Supplied routing facts after all prerequisite checks | Classification |
|-----------------------------------------------------|----------------|
| Candidate request not issued, exact route remains legacy | CandidateRetained; no automatic switch/deletion |
| Candidate request known not applied, route legacy | NewSourceReadinessEligible |
| Candidate request known applied, route candidate | NewCandidateReadinessEligible |
| Legacy return known not applied, route candidate | NewCandidateReadinessEligible |
| Legacy return known applied, route legacy | NewSourceReadinessEligible |
| Acknowledgment lost, fresh bound/confirmed authoritative route known | Eligibility for a new workflow for that observed route only |
| Known applied/not-applied contradicts exact route; invalid action/outcome | ReconciliationRequired |
| Legacy-return outcome with no request issued | ReconciliationRequired; no invented outstanding intent |

The confirmed observation can resolve a lost acknowledgment only inside this supplied-fact
model. It does not discharge HA1/HA2. An eligible result starts a new ownership/freshness
workflow and does not authorize serving requests. No record grants retirement.

## 3. Validation

MigrationRestartClassifierTests includes 32 explicit intent/outcome/route combinations,
46 missing/stale/contradictory/binding fault cases and one null/concurrency case (1,000
parallel classifications of immutable input). Every matrix/fault result is checked to keep
writers stopped. The classifier is stateless; it only examines values and returns a record.
There are no I/O seams, callbacks, coordinator calls, timers or cached readiness references.

[Results](m2-restart-classification-results.json) record the 79 new Storage cases and the
focused MG5/CA1/CA2 regressions. This step does not claim a new full regression run. Catalog
957 comprises the previous 878 plus HC1's 79. The original MG5 823-case broad run and 27
previously qualified expensive matrix cases retain their original scope. Four frozen DLL
hashes remain unchanged; formatting and strict documentation are checked before handover.

## 4. Remaining Gates and Next Work

HC1 is implemented as an internal supplied-observation classifier only. PA1 explicit facade,
HA1 actual host mechanisms, HA2 conditional-update/restart qualification and REL archived
compatibility/platform/release approval remain open. No public API, actual route service,
write enablement, format change or reclamation is introduced. Packaging stays disabled.

Next PA1: prototype an explicitly named mutable facade internally, fixing consumer-facing
ownership/profile/diagnostic semantics with tests before any public exposure. Do not widen
existing Open methods or promote HC1 records into durable authority. Actual host/external
writer exclusion and archived release provenance still need concrete external inputs.


Review hardening (2026-10-28): the [consolidated review](M2_CONSOLIDATED_API_READINESS_REVIEW.md)
adds a null candidate-identity guard and one regression case. Its final 80-case batch is
separate from this original 79-case qualification; no old run count is silently rewritten.
