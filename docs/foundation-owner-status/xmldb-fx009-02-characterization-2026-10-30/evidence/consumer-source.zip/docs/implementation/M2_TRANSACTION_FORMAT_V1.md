# M2 Transaction Sidecar Format 1.0

## 1. Scope and Relationship to M1

This additive format implements one text/ordinary-attribute replacement per document
transaction. It does not change the M1 FORMAT, directory, manifest or fragment encoding.
The base store is immutable sequence zero. New immutable generations retain the same
DocumentId/NodeIds and topology; scalar payloads and pointers may change. See
[ADR-004](../ADR-004-embedded-scalar-transactions.md).

```text
<root>/FORMAT, documents/, fragments/    # Original M1 base, never rewritten
<root>/.transactions/
  CONTROL                              # Immutable base identity
  writer.lock                          # OS-backed exclusive coordinator lease
  CURRENT                              # Published root pointer/checkpoint hint
  wal/00000000000000000001.wal          # One bounded record per sequence
  generations/00000000000000000001/    # Complete M1-format materialization
  staging/<random-id>/                 # Unpublished work; retained after failure
  root-<random-id>.tmp                  # Root publication temporary file
```

Every transaction file uses the M1 common envelope: four-byte magic, little-endian
u16 major=1, u16 minor=0, i32 body length, body, then SHA-256 over header/body.
Unsupported versions, oversized files, trailing bytes and complete hash mismatches
are rejected. Golden transaction fixtures are in tests/TestData/*-v1.hex.

## 2. Body Fields

| File | Magic | Body in order |
|------|-------|---------------|
| CONTROL | BXTC | u64 DocumentId; u64 sequence=0; 32-byte SHA-256 of complete base manifest |
| CURRENT | BXHD | u64 DocumentId; u64 sequence; 32-byte SHA-256 of complete selected manifest |
| WAL | BXWL | u64 DocumentId; u64 sequence; 16-byte transaction GUID; u64 NodeId; UTF-8 replacement string; 32-byte predecessor manifest hash; 32-byte new manifest hash |

Strings use the M1 strict UTF-8/i32 byte-length encoding, maximum 1 MiB. GUID bytes
use Guid.ToByteArray()/new Guid(byte[]), not a textual GUID representation. Sequence
numbers start at 1 and file names use exactly twenty invariant decimal digits. The
experimental retained journal is limited to 10,000 commits; no truncation API exists.
Each record means predecessor sequence N-1 to generation N. Transaction IDs must be
nonempty and unique within the chain. No caller idempotency-key API exists yet.

## 3. Commit and Publication

1. Under the coordinator's exclusive writer lease, reject a transaction whose base
   sequence is stale. Validate XML characters, kind and value limits.
2. Build a unique staging generation: repack scalar values in the touched fragment,
   update offsets/lengths, and copy unchanged fragments. Preserve all identities,
   structural lists and immutable order. Flush format, fragments, directory and manifest.
3. Validate the staged generation. Encode the logical replacement and old/new manifest
   hashes into one WAL record. Write with CreateNew, then Flush(true).
4. Rename the staging directory to its final generation path on the same volume.
5. Write/flush a temporary CURRENT, atomically replace the published pointer using
   same-volume File.Move(overwrite:true), then return the sequence to the caller.

The replayable WAL is authoritative; CURRENT records publication, not the commit
source. Once a complete record exists, a failed response can have an uncertain
outcome. A persistence exception faults the coordinator; dispose/reopen to recover
before deciding whether another operation is needed. Never continue on a faulted owner.

## 4. Recovery and Failure Classification

Acquire FileShare.None ownership before recovery or writes. Verify base identity and
metadata, then require contiguous canonical WAL files. Validate complete record
checksums, document/transaction identity, predecessor hashes and scalar operation
semantics. Reconstruct missing generation directories from redo and require the exact
recorded manifest hash. Validate existing generations and ensure the materialized
scalar equals the WAL value. Publish the final recovered root only after chain validation.

A physically incomplete final append may be discarded only if no later record exists
and CURRENT does not reference it. Complete checksum failures, non-final partial
records, missing committed history and invalid published roots fail closed. An intact
WAL with a missing generation can replay; a present but corrupt generation is rejected
rather than rewriting bytes that another snapshot might still reference.

A kill before the WAL exists recovers the old state. A kill during an unflushed
append can recover old or new. A kill after WAL Flush(true) recovers the new state
in the tested process-crash model. Recovery can itself be interrupted and rerun.

## 5. Ownership, Retention and Durability Limits

One coordinator owns the store; its methods serialize begin/commit operations.
Snapshots and individual transactions remain confined to one caller thread. A
transaction exposes staging, not a read-your-writes query API. Multiple pending
transactions may share a base, but after one commit the others are stale even when
they target different nodes. Disposing an uncommitted transaction rolls it back.

After adoption, direct ImmutableXmlSnapshot.Open(root) rejects the transactional
root. Use EmbeddedXmlDatabase.Open/BeginRead to select a recovered generation.
Older M1 binaries do not recognize the transaction sidecar and must not be used on adopted stores: their old readers can return the original base. This experimental upgrade requires the current reader/coordinator; it is not backward read compatibility.

Already-open base snapshots and all pinned generations remain readable after later
commits or coordinator disposal. No generation, WAL, temporary or orphan-stage
reclamation is implemented; do not manually remove files from an active store.

Tests cover OS process termination and injected storage failures on local Windows.
Startup verifies retained generations and can read every payload; query counters
exclude that work. The default process mode flushes files. An explicit experimental
Linux directory-fsync adapter now exists; see [ADR-005](../ADR-005-filesystem-barriers-and-checkpoint-gates.md).
Native Linux overlayfs execution now passes; controller guarantees, sudden power loss, physical disk-full
behavior, network filesystems and backup consistency have not been established here.
This is not a production durability contract. Define those guarantees before a
supported mutable format is published or any committed history is reclaimed.
Empty ordinary-attribute values are supported. Empty text replacement is rejected
because it requires structural removal rather than a scalar-only change.

## 6. Barrier Policy Without Encoding Changes

The filesystem contract is explicit per coordinator; no journal body or version
field changed. ProcessCrash remains the default. FileAndDirectoryFlush requests Linux
file/directory barriers and synchronizes existing history plus root ancestors before
recovery. Unsupported platforms fail before adoption and filesystem barrier errors
propagate. The old two-argument Open overload remains available.

Ordered directory barriers cover new directories, new file entries, WAL before
publication, both generation-rename parents, CURRENT replacement and incomplete-tail
deletion. The [fault report](M2_FILESYSTEM_FAULT_VALIDATION.md) distinguishes tested
injected errors from untested native/power-loss conditions. A later session choosing
a weaker policy does not inherit a stronger implicit SLA.

The [checkpoint format](M2_CHECKPOINT_FORMAT_V1.md) adds immutable anchors, a selector and shared reader identities. Optional recovery skips prior materializations while validating the full retained WAL. Reclamation remains unimplemented; all committed history is retained.
*Last updated: 2026-10-26*
