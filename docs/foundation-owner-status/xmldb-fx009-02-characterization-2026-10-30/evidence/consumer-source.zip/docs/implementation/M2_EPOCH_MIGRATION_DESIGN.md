# M2 Full-History Legacy Migration and Cutover Design

Date: 2026-10-27. [ADR-018](../ADR-018-full-history-legacy-migration-and-cutover.md)
accepts this design. MG1-MG5 internal codecs, verification, conversion, fault and bounded cutover acceptance are implemented.
No public migration entry point or routing switch exists.
The [work plan](m2-epoch-migration-design.json) separates design decisions from unpassed gates.

## 1. Scope and prerequisites

The first internal converter accepts only an already sealed format-1 full-history
BXBI inventory/BXBC completion artifact produced under the existing backup contract.
The source is one supported document, with CONTROL, complete base data and every canonical
WAL and generation 1..H. H>0 requires canonical CURRENT at H. H=0 is valid and the sealed
format-1 closure omits CURRENT entirely; do not invent one or change the backup format. Reject raw live roots,
immutable 2.0, ScalarWal 2.1/BXEI backups, mixed/unknown profiles, unsupported operations,
gaps, corrupt present materializations and history beyond the current 10,000-commit bound.
Optional checkpoints/descriptors are absent together, as in the existing sealed file set.
An incomplete final WAL in an artifact is corruption, not a tail to truncate.

The converter never calls Open on the original root or sealed data. Legacy source recovery
and capture are explicit preceding operations using the existing coordinator. If they
need repair/adoption, the operator completes that before choosing the sealed capture H;
those mutations are not part of conversion's read-only input guarantee. A plain M1 import
is not accepted through a fallback path; explicitly adopt/capture it first for H=0.

Preserve the proprietary license, Bosak 1.26.2 pins, disabled packaging and all existing wire
formats and frozen fixtures. The converter remains internal. No public mutable open or
migration API, automatic source replacement, source deletion, checkpoint optimization,
WAL truncation, replication or retirement is enabled by this design.

## 2. Identity and byte transformation

| Role | Required transformation |
|------|-------------------------|
| DocumentId; NodeId; FragmentId | Preserve exactly at every sequence |
| Sequence; TransactionId; target NodeId; replacement value | Preserve 1..H exactly, including transaction-ID uniqueness |
| XML structure/order, names/prefixes/namespaces, URI/base URI and values | Compare every node at every sequence; preserve |
| Base and generation manifest/directory/fragment bytes | Copy exact bytes and require deterministic replay to reproduce them |
| FORMAT at root and each generation | Write exact ScalarWal 2.1 profile; no nested legacy FORMAT entry point |
| EPOCH, BASE, CONTROL | Create fresh admitted identity and epoch-bound authority using the preserved base hash |
| WAL N | Encode BXEW with fresh common binding, original logical fields/manifest links and SHA-256 of destination WAL N-1 |
| GENERATION N | Create epoch witness bound to the destination identity, sequence, manifest links and new WAL digest |
| CURRENT | Encode exact H, preserved head manifest hash and new head-WAL hash; H=0 uses the zero-WAL sentinel |
| Runtime admission/writer/readers | Fresh inodes/namespace; readers0..H bind the corresponding manifest; no copied locks |
| Source legacy authority/WAL bytes | Retain in the sealed artifact; never modify or publish inside the epoch store |

Legacy BXWL has no predecessor-WAL digest. Compute the destination chain from actual
newly encoded BXEW bytes, starting with 32 zero bytes. Do not hash a re-encoding of the
legacy record in place of the original sealed bytes when checking source provenance.
Manifest hashes must remain equal across profiles because the document materialization
encoding is shared. If either redo oracle cannot reproduce exact bytes, reject the
candidate; do not recalculate recorded manifests to accommodate a new serializer.

Generate nonzero fresh destination StoreId/EpochId and MigrationId. Format 1 has no source
store/epoch IDs: do not invent them, use all-zero epoch bindings, or call an ordinary
format-1 restore an admitted epoch source. Repeated conversions create distinct destination
identities and independent branches. DocumentId is preserved but is not a global store ID.

## 3. Provenance and publication roles

```text
<legacy-backup>/inventory.bin          # Existing BXBI 1.0, unchanged
<legacy-backup>/COMPLETE               # Existing BXBC 1.0, unchanged
<legacy-backup>/data/...               # Exact legacy source files, never opened live

<migration-destination>/migration.bin  # BXEM 1.0 migration-origin role; metadata codec only
<migration-destination>/store/...      # Actual admitted ScalarWal 2.1 root
```

Publish the two-role bundle together; return the published store path explicitly.
Do not put migration metadata in the store's mandatory recovery layout or reuse origin.bin
from epoch restore. The proposed migration-origin semantic fields are:

- Record version/role and nonzero MigrationId and source BackupId.
- SHA-256 of the exact original BXBI inventory and exact source FORMAT bytes.
- Source DocumentId, H, base/head manifest hashes and original head BXWL-file digest.
- Fresh destination StoreId/EpochId with the same DocumentId, destination FORMAT digest
  and destination head-WAL digest; base/head manifest commitments are shared and preserved.

At H=0, head=base and both head-WAL digests are zero; at positive H both digests are nonzero.
The inventory digest binds the entire source file set, including every original WAL.
The record contains no absolute filesystem paths, routing decision or copied OS ownership.
MG1 now freezes a 350-byte BXEM 1.0 envelope/body with independent fixtures in
[the migration byte contract](M2_EPOCH_MIGRATION_FORMAT_V1.md). Do not alter BXBI/BXBC/BXEI/BXEZ/BXEO or their fixture bytes.

This record is audit provenance for the initial migrated prefix. It is not a current-head
selector, epoch admission token, authentication proof or routing/fencing capability. Later
commits do not rewrite it. Source-to-candidate validation requires the original sealed
artifact; the candidate alone cannot prove source authenticity or source freshness.
A subsequent epoch backup uses the existing exact store closure and does not include the
external migration sidecar; it does not promise recursive migration provenance.

## 4. Conversion and verification protocol

1. Select the requested policy before I/O; reject unsupported FileAndDirectoryFlush on
   Windows without fallback. Validate an absent portable destination with an existing
   unlinked parent, disjoint from input and any supplied legacy source location. No path
   comes from provenance. Reject linked ancestors/leaves, aliases, case collisions,
   traversal, unknown files/directories, overlap and existing destinations before output.
2. Read the legacy seal, exact inventory bytes, closure, bounded lengths and checksums.
   Require full supported format/CONTROL/CURRENT/WAL bindings and H before transformation.
   Preserve the sealed artifact's bytes and directory/file inventory throughout. For H=0,
   header checks accept absent legacy CURRENT and head=base; the destination still requires
   its own canonical epoch CURRENT at zero.
3. Create an exclusively owned nonce workspace on the destination filesystem. All creates,
   writes, flushes, moves, removals and barriers use ITransactionStorage. Never scan for,
   adopt or delete abandoned workspaces. Cleanup only contained owned verification clones
   and an empty workspace; errors may leave private debris for explicit later handling.
4. Preflight complete legacy history with strict read-only validation before opening a
   private complete clone under FullJournal. Require zero generation redo, no tail discard,
   missing-file repair, stale-head promotion or checkpoint substitution. Legacy Open always
   republishes CURRENT at positive H: permit only that byte-identical canonical rewrite
   and fresh runtime housekeeping in this private clone, never in sealed data. At H=0, no
   CURRENT is needed. Independently validate every logical scalar transition
   and all nodes/values at 0..H; opening only the head is insufficient. Existing source
   generations must match the committed result and unchanged-node projection.
5. Build a second private legacy clone with the base and all WAL but no positive generation
   directories; initialize only fresh runtime identities. FullJournal must replay exactly H
   records, not accept a lower head. Compare every regenerated manifest/directory/fragment
   and expected FORMAT against every declared source generation byte. At H=0 require zero
   replay. Do not treat the existing one-oracle BackupStorage.Verify as proof of this step.
6. Copy only verified document data into private bundle/store. Create fresh epoch authority
   and transform every WAL/generation as in section 2. Compare each decoded destination WAL
   with the original logical record plus expected binding/hash transformation. Construct a
   bounded ephemeral expected destination inventory; do not relabel the source BXBI as BXEI.
7. Run both destination oracles: complete history must require no recovery content writes;
   a private base/full-WAL clone must redo exactly H missing generations and reproduce the
   expected bytes at every sequence. Require exact initial H and head hashes in both clones.
   EpochBackupStorage.VerifyCopies may be reused only with a properly constructed destination
   inventory, never by relaxing its epoch/closure checks to accept legacy source data.
8. Initialize fresh admission and stable readers0..H. Open the staged store under exact
   ScalarWal admission; require no repair and correct initial runtime closure. Close every
   private coordinator/snapshot/transaction/admission handle before publishing its directory.
9. Write/flush migration.bin, validate its binding against original inventory and actual
   candidate headers, and validate the exact two-role bundle. Re-read the original artifact
   seal/inventory and copy digests; reject observed mutation. No repaired or guessed source
   bytes may replace the originally captured commitment.
10. Flush all required content, rename the bundle into the final absent destination, sync
    both rename parents and acknowledge only after policy barriers. Return candidate StorePath,
    MigrationId, BackupId, destination identity, H and commitments; never return staging paths.

The supported environment is cooperative local application processes without malicious
concurrent mutation. Hashes give integrity, not authenticity. Input changes observed during
verification reject; this is not a defense against an administrator racing verified handles.
Bounds remain 100,000 inventory entries, 512 ASCII path characters, 64 MiB per file, 1 MiB
scalar UTF-8 and 10,000 commits; validate transformed closure/counts too. Added epoch roles
can make an otherwise valid source exceed the destination count limit: fail rather than
omit dependencies. No source locks/reader files or optional anchors are migrated.

## 5. Outcomes, interruptions and retry

| Observation | Required outcome |
|-------------|------------------|
| Bad input/profile/path or unknown closure | Reject; source/artifact and existing destination unchanged |
| Copy, codec, verification or flush failure before rename | Final destination absent; private workspace may remain; no routable result |
| Failure after rename, during parent barrier/cleanup or before response | Uncertain acknowledgment; final path, if present, must be a complete verified bundle |
| Retry at an absent destination | Start a fresh nonce/identity; ignore prior abandoned private work |
| Retry at an existing destination | Refuse without merge/overwrite; use a separate read-only bundle audit to identify any previous success |
| Candidate H or provenance does not match requested source artifact | Reject; never infer success from a directory or filename |
| Candidate later receives commits | It remains an independent branch; migration provenance describes only the initial prefix |

A future bundle-audit helper must verify provenance, exact supported closure and the complete
initial prefix, not just decode migration.bin. It must distinguish the original H from a
later branch head. No helper is implemented or granted routing authority here. Retain all
source base/WAL/generations, runtime identities and sealed artifact files on every outcome.
Native Linux and modeled ordering evidence must remain separate; application-boundary
exceptions/process kills are not real ENOSPC or physical power-loss certification.

## 6. Explicit cutover and rollback

Conversion does not acquire a lease on the live legacy source. For actual cutover, the
operator must stop all legacy writers, drain pending transactions/checkpoint/publication
work, and keep them stopped from capture through the final routing decision. Hold the
current cooperating source writer/coordinator gate during capture and final freshness
checks. Do not try to hold an owner across process death as a persistent fence. A legacy
marker or lease probe cannot account for old or uncooperative processes.

Before routing, a future coordinated verifier must compare the frozen source against the
captured document/H, FORMAT/base/head and every canonical WAL digest, not H alone. Compare
its authoritative data closure using the original format-1 capture exclusions (including
H=0 CURRENT omission and optional checkpoints/runtime files). Any live CURRENT must still
be valid at the captured H; excluded files remain protected. Require a clean canonical
recovered head. Recovery, if
needed, is a separate explicit source operation, followed by a new capture/comparison.
Also revalidate the candidate's full initial prefix, origin binding and exact unchanged
initial head; a destination that already advanced is not eligible for initial cutover.

| State | Routing / required action |
|-------|---------------------------|
| LegacyActive | Existing routing; conversion may produce an archival candidate, not a live cutover |
| WritesFrozenAndCaptured | Cooperative writers excluded; operator keeps the freeze across conversion/restarts |
| CandidateVerified | Both legacy/destination oracles passed; source and destination remain unrouted/unmodified by cutover |
| ReadyForExplicitRoute | Source still exactly matches capture; candidate still at initial H; compatibility and ownership gates accepted |
| EpochRouted | Application explicitly selects returned store/; no source rename, replacement, symlink redirect or automatic configuration rewrite |
| Diverged | Either branch advanced since comparison; stop automatic rollback and require a reconciliation/export decision |

The library does not atomically coordinate every application's configuration. Routing
failures must leave the original available. Inspect actual routing/acknowledgments before
retry; do not guess which writer served work. Before any post-switch work is accepted,
returning routing to the still-frozen unchanged source requires operator verification that
neither branch advanced and all candidate work drained. If that cannot be established,
treat the outcome as divergent/uncertain. After destination commits, rollback is not a
path swap: preserve both histories and decide reconciliation explicitly. No dual writing,
automatic failback, source-to-destination merge or durable source fence is implemented.

Old immutable snapshots can survive coordinator disposal and routing changes. Keep the
original root and stable file identities indefinitely in this scope. Lazy source reads
must still return their old values after publication, source-owner disposal and routing.
Candidate admission must protect its own children across disposal/process exit; migration
does not prove old-reader absence. CanReclaim=false; no C1-C3 result grants retirement.

## 7. Acceptance matrix and implementation gates

| Gate | Required scenarios and observable acceptance |
|------|---------------------------------------------|
| MG1 | Pure migration-origin codec; exact independently authored golden bytes; all truncations; resealed role/version/identity/digest/H0/positive-H/bound rejection; source/destination header-context checks; no I/O or capability grant |
| MG2 | Legacy verifier at H0/1/multiple (absent H0 CURRENT and clone-only byte-identical positive-H CURRENT republication), mixed text/empty-attribute edits and namespaces/URI; complete and redo oracles, exact every-sequence bytes/logical state; resealed wrong transition and noncanonical regenerated bytes rejected before conversion |
| MG3 | Internal new-root conversion; fresh repeat identities, exact transformation of every authority/WAL link; destination complete/redo oracles, old lazy readers, published-path independent snapshots and post-migration branch commits with unchanged provenance |
| MG4 | Every observed create/write/flush/close/move/delete/barrier before/after plus real partial writes; interrupted legacy/destination redo; repeated kills before/after publication and ACK; no leaked handles, false completion, input mutation or overwrite on retry |
| MG5 / C2 | Explicit cutover acceptance harness; source same-H different bytes, source advanced, candidate advanced and stale evidence rejected; routing failure/uncertain acknowledgment, no-write verified return and divergent rollback refusal; no automatic source path replacement |
| C1 | Both current and frozen local legacy/immutable readers reject candidate root and every supported nested materialization entry before persistent mutation; actual archived pre-lease binaries/provenance required before broader compatibility claim |
| C3 | Cross-process admission, disposed owners, old uncached snapshots, concurrent child creation/Dispose and killed holders; no gate/admission deadlock or stable identity replacement; no inference about pre-lease readers |
| Platform | Windows ProcessCrash and actual native Linux FileAndDirectoryFlush, explicit unsupported-policy refusal; distinguish modeled/native positions, host-only branches and process-probe policy |

Each runtime gate needs happy, failure and adversarial evidence plus machine-readable
counts and a report. Include corruption, duplicate transaction IDs, gaps, wrong document,
unknown profiles, source mutation, path collisions/links, closure limits, insufficient
space injections and repeated verification/retry. Test no persistent writes on reader
rejection using byte and directory/file inventories. H0/1/multiple success is not exhaustive
fault proof for every history length. Retain immutable frozen fixtures; do not rebuild old
binaries as a substitute for missing archived releases. Local C1 evidence may be recorded,
but complete archived C1/C3 and product shipping remain explicitly open when evidence is
unavailable. MG5 defines/testing application behavior does not ship a routing service.

R1-R3, source retirement, redundant-generation deletion and WAL/base retirement remain
separate future decisions. Migration never changes retention eligibility.

## 8. Current evidence and next work

MG1-MG4 internal conversion and observed-fault proof remain recorded. MG5 now implements
[bounded prototype cutover acceptance](M2_MIGRATION_CUTOVER_ACCEPTANCE.md), with
[validation](M2_MIGRATION_CUTOVER_ACCEPTANCE_VALIDATION.md) and
[machine evidence](m2-migration-cutover-acceptance-results.json). Operator stop/drain and
prototype compatibility attestations are required. Capture is registered in a cooperating
source freeze, candidate writes are frozen independently, and exact commitments are
rechecked before every consumed single-use observation. No recovery or persistent writes
occur during validation/evaluation; no actual routing/configuration operation exists.

All five MG gates are now implemented only for the internal prototype. Unknown routes,
accepted work or divergent/changed bytes never trigger automatic rollback. Freeze/evidence
are process-local; owner disposal/process exit invalidates readiness, not reader lifetimes.
No marker fences old binaries or proves pre-lease reader absence. Complete archived C1-C3,
product API exposure, actual application cutover/release certification, physical/controller
durability and all retirement/reclamation remain unpassed separate gates.

Next audit evidence against original M2/C1-C3 release criteria, inventory the exact missing
archived pre-lease binaries/provenance and distinguish local frozen baseline proof from
actual historical compatibility. Do not fabricate old releases, expose public mutable APIs,
replace source paths or delete any history as part of that audit.
