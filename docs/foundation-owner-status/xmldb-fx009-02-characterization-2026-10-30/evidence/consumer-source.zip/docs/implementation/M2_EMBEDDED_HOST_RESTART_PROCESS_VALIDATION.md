# Restart and Retry Process Interruption Validation

Date: 2026-10-29. EP6-D qualifies the internal workflow in
[ADR-027](../ADR-027-stopped-embedded-restart-reconciliation.md).

## 1. Matrix and Scope

72 new process cases execute on each platform, using both LegacyMigration and
IndependentEpochRestore artifacts at H=1. Earlier EP6-B/C in-process functional tests retain
H=0/H=3 coverage; this process matrix does not claim those heads or physical power-loss proof.
Every child reacquires an existing controlled host root, waits for a parent dispatch handshake,
and terminates itself at a named boundary using the established CrashProbe kill mechanism.
The parent waits for actual process exit and never treats a timeout as publisher completion.

| Prior workflow | Per-role boundaries | Cases across roles |
|----------------|---------------------|--------------------|
| Absent prior attempt | TransferOwner and ReconcileAbsent: Validated, BeforeWrite, Written, Flushed, BeforeAcknowledge, ACK | 24 |
| Known published prior attempt with no saved receipt | TransferOwner and ObserveKnown: same six boundaries | 24 |
| Explicit fresh retry intent | Same six save boundaries | 12 |
| Retry execution | AuthorizationAcknowledged, BeforeInvoke, PipelineReturned, BeforeReceiptSave, BeforeReturn, ACK | 12 |

Transfer ACK is exercised at the following outcome's Validated checkpoint, after the transfer
save has actually returned and before outcome bytes are written. Outcome ACK is after Reconcile
returns. Retry-intent ACK is after Record returns. Execution ACK is after Execute returns with
Succeeded. Written/Flushed/BeforeAcknowledge are distinct complete-frame gaps; file flush does
not certify physical durability. No new partial-frame kill is claimed here: EP4's separate
partial-write process case remains regression evidence and corrupt tails still fail closed.

## 2. Assertions

Every case verifies the exact expected retained frame count and original attempt snapshot.
Retry descriptors are announced to the parent before Record, with a fresh ID and identical pin;
retained retry frames preserve request and descriptor fields except ID. Exact operation-aware
inspection distinguishes absence from a complete publication. ObserveKnown retains an observation
without synthesizing a receipt; actual receipt saves appear only at their execution boundaries.

The first fresh owner starts with closed admissions and disabled append and cannot create an
orchestrator. Opening/inspection leaves the complete file inventory and bytes unchanged. A second,
separately authorized stopped reconciliation correlates retained known/absent outcomes without
dispatch or opening admissions. Artifact, source and any published candidate bytes are unchanged,
and no unrequested destination appears. This is controlled single-machine cooperating-process
qualification, not hostile namespace/global fencing or production application routing authority.

CrashProbe adds only the internal ep6-restart test command. Production source, public APIs,
wire mappings, frozen fixtures, dependency pins, proprietary license and disabled packaging are
unchanged. All 1,055 focused cases pass per platform (732 Storage and 323 Integration),
with zero failures/skips. Formatting and Windows/Linux strict documentation/portability checks
pass; all 118 tracked src/TestData files match the pushed baseline under Git attributes, and
public Storage metadata remains at 95 signatures. Final platform counts and TRX references are in the
[machine evidence](m2-embedded-host-restart-process-results.json). The suite is focused, not a
fresh unfiltered full-suite run. Three existing Windows FIFO guard rows remain separate from
Linux's actual FIFO bodies.

## 3. Delivery and Next Work

EP6-C is committed/pushed as `5977451`; EP6-D tests/evidence are included in the 2026-10-29 host restart checkpoint commit.
Next audit the combined embedded pilot against the application integration gate, specifying
actual selected-root authority and accepted-work accounting before adding a consuming host.
Do not interpret these process tests as permission to resume writers, expose mutable public
APIs, discard candidates/history or ship a globally fenced service. Archived-reader/release,
physical durability and production application authority gates remain open.
