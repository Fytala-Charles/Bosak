# EP4 Owned Conditional Journal Append Validation

Date: 2026-10-28. Internal append under [ADR-025](../ADR-025-owned-conditional-host-journal-append.md)
and the [journal contract](M2_EMBEDDED_HOST_JOURNAL_CONTRACT.md).

## 1. Ownership, Enablement and Expected State

EmbeddedHostLifetime now owns a serialized append session on its already-open journal stream.
The acquisition history/stream length initialize a descriptive known position: journal GUID,
global sequence, last frame digest and byte length. Acquired positions are observations, not
acknowledged earlier calls. JournalStatus is advisory point-in-time state, never a permit.

Administrative admissions alone do not enable output. EnableJournalAppend requires separately
supplied fresh controlled/excluded/reconciled facts bound to the current session/journal/scope,
plus the exact expected position. Reopened empty roots reject first-write enablement, even
when structurally valid; only successful live provisioning supplies that initial origin.
Nonempty reopened history can be explicitly enabled after caller-owned reconciliation, but no
saved authorization or plan is automatically executed. New frames must use the current live
owner session; changing a historic owner requires an explicit codec-valid transfer event.

Append compares every expected-position component. Stale callers receive Conflict with no
frame, no output and no implied publication outcome. Valid proposals bind deployment/scope,
canonical disjoint/unlinked artifact/bundle paths and the unchanged codec/transition rules.
The codec shares bounded semantic-extension validation without changing wire bytes. Metadata,
complete journal history and exact EOF are checked under the append gate before write entry,
including a second check after the validation test seam.

## 2. Acknowledgment and Faulted Sessions

A registered operation token retains ownership through writes, actual Flush(true), exact frame
length/readback, complete post-flush history verification and acknowledgment. No executor or
host route callback runs as part of append. The host append result is distinct from an actual
library publication receipt stored in its payload. Snapshot claims are trusted caller data;
the backend validates binding/structure rather than authenticating a pipeline return.

Validation/schema/transition rejections before write leave a valid session usable. Once the
write-entry boundary is crossed, exceptions irreversibly fault the append session and close
administrative admissions, including errors before any observable bytes or after actual flush.
Unexpected owned namespace/history errors also fault before output. Neither enabling again nor
reopening admissions can reset the same lifetime's fault. Already admitted writers check fault
under the shared gate before output. Recursive append/enable/read-cursor access is rejected.

ReadJournalForReconciliation admits a counted read-only operation even while admissions are
closed, preserving ownership until completion. It returns strict stopped history or throws on
corruption; it cannot clear a fault or update the known position into an acknowledgment. After
failure, known position may precede actual complete or damaged bytes. Dispose closes admissions
and waits through registered work via WhenReleased; caller timeout never completes the work.

Only the existing journal is mutated. No file creation, metadata rewrite, tail truncation,
repair, prefix adoption, store replacement or history deletion is added. Complete valid-prefix
rollback remains undetectable without an independent anchor. Current validation is O(history)
per append and repeats full reads; this bounded prototype makes no throughput or heap-size SLO.
ProcessCrash file-flush qualification is not controller/power-loss durability or a global fence.

## 3. Executed Evidence

47 new cases comprise 34 Storage and 13 Integration. Storage covers normal conditional append/
owner transfer, empty-reopen refusal, four stale position components, ten invalid proposals,
12 write/flush/readback/callback failures, validation-only rejection, concurrent expected-head
writers, shutdown while actual append is paused, reentrancy, explicit enablement and unexpected
namespace mutation. Errors include actual prefix writes followed by failure, silent short or
corrupt writes, extra trailing bytes, old-prefix corruption and before/after actual flush.
Retained complete/partial/corrupt histories are never repaired or silently acknowledged.

Seven Integration rows kill actual processes at validation, write entry, after write/flush,
before acknowledgment, after return and in an actual partial-frame write. Complete frames
reopen stopped without append/dispatch enablement; partial frames block reopen. Six additional
rows combine real migration/restore plans with actual journal writes: normal acknowledgment,
lost authorization flush result (test dispatch does not run), and lost receipt-save flush result
(actual pipeline is not replayed). Candidate bytes remain unchanged by host receipt persistence.
These branches are test-controlled composition, not a shipped orchestrator enforcing all callers.

Final focused Windows Debug and isolated Linux Release runs pass 854 cases/platform:
707 Storage (34 new + 673 prior) and 147 Integration (13 new + 134 prior). SDK stays 10.0.301.
All 47 new bodies execute on both hosts. Prior three FIFO rows execute on Linux and return on
Windows; other native-policy/process branches retain their previous scope. This is not a new
unfiltered full-suite, real ENOSPC, physical-loss, hostile-namespace or archived-reader run.

Public Storage metadata remains 95 signatures with no additions/removals. Store/journal wire
formats, independent vectors and frozen reader binaries are unchanged. Shared lifetime code
adds acquisition-length tracking, counted reconciliation reads and an irreversible fault gate;
codec history code adds semantic extension checks; CrashProbe gains a test command/header.
Formatting, strict docs and actual hidden/link portability checks pass on Windows and Linux.

## 4. Delivery and Remaining Work

EP2/EP3 was committed/pushed as 4642b09 before this continuation; EP4 changes are local/uncommitted.
Proprietary licensing, dependency pins and disabled packaging remain unchanged. CanReclaim=false.

Next EP5 prototypes the internal owned orchestration boundary: bind a live prepared plan and
its exact persisted descriptor, require acknowledged intent/authorization before one dispatch,
register the actual executor through shutdown, keep pipeline and host-write acknowledgments
separate, and reconcile uncertainty without replay. No direct-caller enforcement/global exactly-once
claim follows from test branches or this journal backend. HA2 application routing/work authority,
public/archived-reader/release, physical durability and retirement gates remain open.

[Machine evidence](m2-embedded-host-append-results.json).

Hosted CI observation: [run 40771851255](https://github.com/Fytala-Charles/Bosak.XmlDb/actions/runs/40771851255)
for pushed 4642b09 failed before either runner executed a step. GitHub check-run annotations
state recent account payments failed or the spending limit must be increased. There are no
hosted build/test results for that run. Account billing/settings require account-owner action;
no billing change or repeated rerun is attempted. Local evidence above remains separate.
