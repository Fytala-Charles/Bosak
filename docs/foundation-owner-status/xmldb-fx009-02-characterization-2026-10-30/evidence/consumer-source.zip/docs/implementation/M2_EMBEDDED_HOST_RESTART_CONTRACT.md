# Embedded Host Restart Reconciliation Contract

Date: 2026-10-29. EP6 design under [ADR-027](../ADR-027-stopped-embedded-restart-reconciliation.md).
EP6-A/B/C stopped registration, inspection and explicit retry are pushed as `5977451`, with
983 focused cases per platform. EP6-D adds H=1 combined process qualification; see its linked
validation report for exact scope and platform evidence. This contract introduces no wire change.

## 1. Restricted Lifetime Mode

Acquire only under retained ownership, closed admissions, no executor and fresh bound
inspection/exclusion facts. Serialize reconciliation with all ordinary journal mutations and
admission changes using an opaque lifetime registration. Recheck closing/fault state when
registering and at each save. Do not hold lifetime/journal locks across artifact inspection.
Retain the registration until actual work ends; cancellation is not completion.

The stopped append path accepts only TransferOwner, ObserveKnown and ReconcileAbsent,
bound to an exact captured snapshot/position and the session registration. It cannot RecordIntent,
AuthorizeDispatch, MarkUncertain or Acknowledge. Ordinary AppendJournal retains its admission
requirements. Conflict writes no bytes; post-entry uncertainty faults the entire lifetime.
A complete frame after a lost acknowledgment is reconciled on a new lifetime, never silently
reported as a previous successful call.

## 2. Outcome Rules

| Latest stage | Fresh outcome | Permitted stopped action |
|--------------|---------------|--------------------------|
| Recorded / DispatchAuthorized, previous owner | Any | TransferOwner to Uncertain, then inspect |
| Uncertain, previous owner | Any | TransferOwner preserving stage, then inspect |
| Uncertain, current owner | Exact known operation | ObserveKnown with actual inspection observation; no receipt |
| Recorded / DispatchAuthorized / Uncertain | NotObserved plus qualified exclusion and no contradictory evidence | ReconcileAbsent after required owner binding |
| Acknowledged / ObservedKnown | Exact agreeing known operation | Preserve terminal evidence; report fresh correlation separately |
| ReconciledAbsent | Fresh qualified absence | Preserve terminal evidence; explicit fresh-plan retry may be considered |
| Any | Unknown / inaccessible / foreign / malformed / contradictory | Retain all bytes and candidates; stay stopped |

Never turn ArtifactMatched into KnownOperationMatched. Never overwrite a prior receipt with an
observation. Owner transfer increments revision and generation without overflow and preserves
all immutable request/descriptor fields. Inspection cannot authorize reclamation.

## 3. Explicit Retry Boundary

Retry is a separate operation after acknowledged absence. Prepare a new library plan and
require a distinct attempt ID, same business request and exact descriptor equality except
attempt ID. Recheck input commitment and the latest absent snapshot before recording it.
Changed artifacts or destinations require a separately designed request/workflow; v1 does
not serialize an independent-destination justification. No automatic restart dispatch or
reopening of an old process-local ticket is permitted.

## 4. Required Qualification Before Completion

- Both publication roles at H=0 and H=3: transfer, exact known observation and explicit absent retry.
- Every stage above, including terminal agreement/disagreement, overflow, invalid evidence,
  foreign session/registration, changed revision/position/pin and reopened empty root rejection.
- Duplicate/concurrent reconciliation, ordinary append/admission/execute contention, shutdown
  during inspection/save, actual drain before owner release and cross-process exclusion.
- Before-write, partial-write, flush, readback and acknowledgment-loss boundaries for transfer
  and outcome saves. No same-session rearm, prefix adoption or replay after uncertainty.
- Process kill after each transfer/outcome frame and before/after caller acknowledgment;
  reopen stays stopped, retains bytes/candidates and never recreates an executable ticket.
- Frozen reader/vector hashes, 95 public Storage signatures and wire mappings remain unchanged;
  run relevant Windows/Linux suites, formatting and strict documentation/portability checks.

## 5. Delivery

Next implement the restricted stopped lifetime registration and conditional append path first,
with focused failure/concurrency tests, then compose the inspector and explicit retry workflow.
Application routing/work authority, public mutable APIs, global fencing, physical durability,
archived-reader release proof and reclamation remain outside this contract.

Hosted push run [40793748444](https://github.com/Fytala-Charles/Bosak.XmlDb/actions/runs/40793748444)
was blocked before runner steps by account payment/spending limits; this is not runtime evidence.

[Machine contract](m2-embedded-host-restart-contract.json).

[EP6-A boundary validation](M2_EMBEDDED_HOST_STOPPED_APPEND_VALIDATION.md).

[EP6-B actual inspection validation](M2_EMBEDDED_HOST_RESTART_INSPECTION_VALIDATION.md).

[EP6-C explicit retry validation](M2_EMBEDDED_HOST_RETRY_VALIDATION.md).

[EP6-D process qualification](M2_EMBEDDED_HOST_RESTART_PROCESS_VALIDATION.md).
