# ADR-035: Owned Stopped Restart Observation

**Status:** Accepted; SR2-A/B and bounded SR2-C local qualification implemented internally; host/release/handoff gates open
**Date:** 2026-10-30
**Deciders:** Authorized continuation of the internal embedded pilot

## Context

[REQ-007](FEATURE_REQUESTS.md#req-007-mutable-epoch-authority-and-recovery),
[ADR-034](ADR-034-stopped-enrollment-restart-and-owner-handoff.md) and the SR1 pure classifier
require fresh actual ownership before descriptive facts can support a future workflow.
The enrollment retainer requires the original freeze/capture association; a restart cannot
recreate it from sealed bytes. A standalone migration freeze permits backup publication and
does not provide the required original-stream retention. Generic inspection also ends its
operation before a later source/capture check, and legacy OpenCore can publish CURRENT.

## Decision

Adopt the [SR2 observation design](implementation/M2_OWNED_RESTART_OBSERVATION_DESIGN.md).
Introduce a separate opt-in restart-only source child before the paired observation adapter.
Acquire it from a fresh actual source owner, retain its original usable writer stream, latch
that owner stopped permanently and exclude cooperating mutations/publishers through actual
drain. Preserve old freeze/enrollment gates and the original armed-owner stop latch.

A future paired scope retains real parent/authority/source registrations through unlocked
verification and exact head rechecks. Derive storage/ownership facts from actual evidence;
keep external host facts as scoped assertions. Reverify the existing sealed artifact without
reconstructing FrozenMigrationCapture or implicitly opening/recovering a live root. Preserve
the inventory digest definition used by Enroll. No new journal record or public API is added.

## Consequences

### Positive

- Restart does not weaken original enrollment object/capture binding or revive an initializer.
- Real writer/publisher exclusion spans the entire observation rather than a caller Boolean.
- Source/capture verification stays outside serializers and cannot hide recovery writes.

### Negative / Accepted Costs

- A new source lifetime primitive and mutation/publisher audit require separate qualification.
- A successfully admitted restart owner stays stopped even after observation failure or disposal.
- Actual observation needs fresh verification beyond SR1, and future handoff still needs SR3/SR4.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Register an old artifact in a new MigrationSourceFreeze | Fabricates the original capture association |
| Use a migration freeze alone | Permits backup publication and loses exclusion/usable ownership on disposal |
| Borrow only a SafeFileHandle | Does not retain the original usable owner stream and lifecycle |
| Call live OpenCore during verification | Can republish CURRENT or perform recovery behind a read-only claim |
| Return a descriptive dossier as a handoff capability | Cannot retain or establish fresh actual ownership |
| Clear the original armed latch for inspection | Violates terminal stopped enrollment semantics |

## References

- [ER-004 contract](implementation/M2_STOPPED_ENROLLMENT_RESTART_CONTRACT.md)
- [Source retention](implementation/M2_ENROLLMENT_SOURCE_RETENTION.md)
- [Release qualification](implementation/M2_ENROLLMENT_ROLE_RELEASE.md)
- [SR2 design review](implementation/M2_OWNED_RESTART_OBSERVATION_REVIEW.md)

SR2-A follow-up (2026-10-30): [source-only retention](implementation/M2_RESTART_SOURCE_RETENTION_VALIDATION.md)
adds actual source lifetime retention and permanent stopped admission. Original design evidence
remains historical. Full paired SR2 observation is not implemented; next SR2-B.

SR2-B follow-up (2026-10-30): [actual paired stopped observation](implementation/M2_OWNED_RESTART_OBSERVATION_VALIDATION.md)
binds complete read-only legacy/capture proof to real retained owners, with no acknowledgment
or handoff authority. Earlier evidence retains its dated scope; next SR2-C qualification.

SR2-C follow-up (2026-10-30): [native/process/disposal qualification](implementation/M2_OWNED_RESTART_QUALIFICATION_VALIDATION.md)
adds bounded local identity, actual holder/interruption and closing evidence without product
source changes. Original evidence retains its dated inputs; next SR1/SR2 readiness consolidation.

Readiness follow-up (2026-10-30): [consolidated SR1/SR2 review](implementation/M2_STOPPED_RESTART_READINESS_REVIEW.md)
verifies retained input/catalog evidence and separates current observation from future success-only
proof consumption and plan-child retention. Next SR3-A contract; no new writer is enabled.


SR3-A design follow-up (2026-10-30): [preparation/lifetime contract](implementation/M2_STOPPED_HANDOFF_PREPARATION_CONTRACT.md)
resolves RR-002/003/004 at the design level only. Private proof, actual child drain and
paired-parent successor binding are specified, not implemented. Next SR3-B1 adds proof/lifetime
primitives; preparation/claim and SR4 output remain later gates. Original execution evidence
and all host/public/archive/fencing/retirement limitations remain unchanged.
