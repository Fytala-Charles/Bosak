# ADR-005: Filesystem Barriers and Checkpoint Safety Gates

- Date: 2026-10-26
- Status: barrier contract implemented; non-deleting checkpoint/lease gate now implemented in ADR-006; reclamation deferred
- Request: REQ-004

## Context

The first M2 slice proves process-crash recovery, not a power-loss contract. File data
and namespace persistence are separate dependencies. Linux documents that a file
fsync alone does not make the containing directory entry persistent; an explicit
directory fsync is needed. See [Linux fsync(2)](https://man7.org/linux/man-pages/man2/fsync.2.html).
Microsoft separately documents explicit flushing of buffered file writes in
[Windows buffered I/O](https://learn.microsoft.com/en-us/windows/win32/fileio/flushing-system-buffered-i-o-data-to-disk).
These contracts do not certify our filesystem/controller or prove power-loss safety.

Removing history before validating publication and protecting lazy readers risks data
loss. This step therefore establishes barriers and fault testing before reclamation.

## Decision: Explicit Per-Coordinator Barriers

Keep the existing Open(root, documentId) overload and default ProcessCrash mode.
Add Open(root, durability, documentId) and a Durability property. ProcessCrash flushes
file content but does not promise namespace persistence after power loss.
FileAndDirectoryFlush is an experimental Linux-only adapter that requests directory
fsync as well. Unsupported platforms fail before adoption with no silent downgrade;
filesystem errors also propagate. Windows currently supports ProcessCrash only.
The policy is per coordinator; it is not a persisted per-store SLA or implicit promise
for future sessions that choose another mode.

Preflight the requested root-directory barrier before creating .transactions. After
exclusive writer ownership, stronger-mode adoption flushes existing files and directories
bottom-up, excluding the live writer lease, then synchronizes root ancestors. This
covers an imported M1 base and history from earlier process-mode sessions. Do not
assume those earlier names/data were already durable.

For new work, flush each file and then its parent directory. Flush a new directory's
parent after creation. WAL file content/close and WAL-directory barriers precede
publication. Moving a generation requires barriers on both old and new parents.
After replacing CURRENT, complete its parent barrier before acknowledgment. Flush
incomplete-tail deletion before reusing the sequence. A persistence error prevents
acknowledgment, faults a live writer or aborts Open, and requires recovery.

No binary fields or format versions change; M1 and journal golden fixtures are retained.
The new storage abstraction is internal. It supports file create/write/flush/close,
directory create/sync, moves and the existing incomplete-tail deletion. Production
ownership still uses an actual OS-backed lease, not a mock.

## Validation and Accepted Costs

A recording adapter injects before/after disk-full-style IOException failures around
real temporary-store operations, including actual partial writes followed by an error.
Sweeps cover initialization, commit, redo, tail cleanup and stronger-policy adoption.
Every case checks a complete old/new state, ownership release, repeatable recovery
and a later successful commit. Ordering tests verify the dependency chain separately.
Directory operations in the Windows test adapter model stronger-mode ordering; they
are not native Linux fsync evidence. Native Linux execution is conditional on running
the suite there. No actual disk was filled and no physical power interruption occurred.

Native Linux overlayfs tests now pass in the [checkpoint validation](implementation/M2_CHECKPOINT_VALIDATION.md). The adapter and all stronger-mode sessions still require production filesystem/controller
validation before a production power-loss promise. Startup can be expensive because
it synchronizes/verifies retained history. Existing process-crash behavior and all
previous tests must remain passing.

## Checkpoint and Reclamation Gate

The [checkpoint design](implementation/M2_CHECKPOINT_DESIGN.md) now has an implemented non-deleting checkpoint/reader-lease gate; see [ADR-006](ADR-006-nondeleting-checkpoints-and-reader-leases.md). Reclamation and redundant-anchor publication remain proposals. Required gates include durable independently verifiable
anchors, protected reader leases across coordinator disposal/processes, and fault
injection at every publication/deletion step. Keep all committed history until those
gates pass. This step does not authorize unsafe deletion or reinterpret existing M1
node order as a mutable insertion scheme.

## Alternatives Considered

- Claim file flushing alone proves power-loss safety: rejected; namespace dependencies remain.
- Silently use process mode when directory fsync is unavailable: rejected.
- Exhaust the user's actual disk to test ENOSPC: use deterministic injected failures instead.
- Reclaim first and add reader protection later: rejected because snapshots fetch lazily.

*Last updated: 2026-10-26*
