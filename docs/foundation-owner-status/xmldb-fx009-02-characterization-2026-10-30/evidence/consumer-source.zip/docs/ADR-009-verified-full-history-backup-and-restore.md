# ADR-009: Verified Full-History Backup and Restore

**Status:** Implemented experimental format-1 slice  
**Date:** 2026-10-27  
**Deciders:** Bosak.XmlDb implementation within authorized M2 work

## Context

[REQ-006](FEATURE_REQUESTS.md) and [ADR-008](ADR-008-reader-compatibility-backup-and-retirement.md)
require a fixed-sequence full-history backup before migration or retirement. A copy of
CURRENT and a checkpoint is insufficient for the existing full-prefix recovery contract.

## Decision

`EmbeddedXmlDatabase.CreateBackup(destination)` owns the coordinator gate throughout
capture, excluding commits/checkpoints. It copies the original base, CONTROL, committed
WAL 1..H, every complete generation 1..H and CURRENT for H>0. Optional checkpoint and
recovery-descriptor trees, reader identities, OS locks, staging and temporary files are
excluded by schema. Unknown source dependencies fail closed. Missing generations must
be rebuilt by an independent FullJournal reopen before capture; capture does not repair
the source or silently reduce the captured sequence.

A backup directory contains data/, inventory.bin (BXBI) and COMPLETE (BXBC). The bounded
inventory binds a random BackupId, document, H, base/head manifest hashes and a sorted
canonical exact file set with sizes and SHA-256. Completion binds the inventory digest.
Existing source formats and previous fixture bytes do not change. The backup encoding
is separately versioned; format 1 remains non-deleting.

Verify using full recovery on an operation-owned clone with zero generation replay,
exact H/head and all values read. Matching manifest/directory/fragment digests binds
persistent IDs, topology, order and values to the copied source. A verification clone
keeps recovery-created locks, reader files and rewritten CURRENT out of sealed bytes.
Only the operation's own clone/workspace is cleaned up; no source data is removed.

`RestoreBackup(backupRoot, destination, durability)` verifies completion, canonical
closure, exact file set, all hashes and full recovery before publishing a fresh store.
It copies declared immutable data and recreates runtime locks on future Open. Source
and backup remain unchanged. A restore is an independently writable branch, not replica
coordination. Both operations stage on the destination filesystem and use file/directory
barriers through the transaction storage seam; there is no cross-volume rename.

Existing or overlapping destinations and linked ancestors are refused. The parent must
already exist. Pure destination validation does not fault a coordinator; capture I/O or
verification errors do, including preflight barriers. Reopen before retrying. Failures
can leave unpublished .xmldb-backup-* workspaces, or a complete published destination
when acknowledgment was lost. Retry into a fresh destination; never merge or overwrite.
There is no automatic discovery or cleanup of abandoned workspaces.

## Consequences

### Positive

- Restore has an exact sequence/head oracle and complete independent history.
- Current old snapshots and source files remain available during capture.
- Independent codec fixtures, persistence fault sweeps and real process kills cover
  capture and restore publication; native Linux barriers have a dedicated test.

### Negative / Accepted Costs

- Writes block for capture; full history plus verification clone consumes additional disk.
- Inventory is limited to 100,000 files, each within existing 64 MiB format limits.
- Cooperative processes and no external mutation are required. Hashes are integrity
  checks, not authenticity, encryption or protection against an administrator.
- No online/incremental backup, epoch migration, retirement, WAL truncation or physical
  power-loss/real capacity-exhaustion certification is added.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| Copy arbitrary live files recursively | Can mix commit boundaries and unknown dependencies |
| Reuse source process locks in restore | File bytes do not transfer OS ownership |
| Verify by reopening the sealed data directly | Recovery can rewrite selectors and create runtime files |
| Accept a repaired or older recovered head | Would conceal missing history or an incomplete backup |
| Delete the original after successful restore | Existing readers and compatibility still require retention |

## References

- [Backup format](implementation/M2_BACKUP_FORMAT_V1.md)
- [Compatibility/backup/retirement protocol](implementation/M2_COMPATIBILITY_BACKUP_RETIREMENT.md)
- [Validation](implementation/M2_BACKUP_VALIDATION.md)

*Last updated: 2026-10-27*
