# ADR-022: Single-Process Embedded Pilot Host

**Status:** Accepted pilot target and exclusion constraints; durable backend and host implementation pending
**Date:** 2026-10-28
**Deciders:** User selected single-process embedded application first; local profile specified within authorized continuation

## Context

[REQ-006 and REQ-007](FEATURE_REQUESTS.md) have internal planned publication and test-only
ledger integration. [ADR-021](ADR-021-host-attempt-ledger-and-publisher-exclusion.md) requires
an actual host/exclusion/persistence boundary before production orchestration. The user selected
single-process embedded integration first. The ASP.NET Core server remains an M4 milestone;
no existing business application or external route/work authority was supplied.

## Decision

Target a controlled embedded pilot on one machine with one application process owning every
administrative publisher and database writer in its configured scope. Use a dedicated host-state
root outside source, sealed artifacts, candidate bundles and library workspaces. Require a
process-lifetime exclusive ownership handle before reading authoritative host state or opening
owned stores. This excludes cooperating pilot instances only; no old binary, manual writer,
remote worker or external application may remain in the supported deployment scope.

Do not use expiring leases, automatic generation takeover, child publisher processes, external
queues, remote execution or distributed failover. Stop admissions before shutdown and await every
owned operation/child reader before releasing ownership. Unknown worker reachability prevents
release/takeover eligibility. On restart, acquire ownership and begin stopped reconciliation;
a free lock alone does not prove absence of old/foreign writers or authorize dispatch.

Keep initial pilot administration internal. Existing EmbeddedQuickstart/public entry points
remain unchanged and do not gain mutable ScalarWal access. Routing and business accepted-work
integration are deferred until a real consuming application supplies authoritative mechanisms.
No candidate is automatically selected or enabled for writes after publication/restart.

Prefer a bounded local file-backed append-only host ledger for the next design, avoiding a
server dependency for an embedded application. This is a backend proposal, not an implemented
or qualified durable store: record framing, integrity, conditional revision, flush/commit
semantics and restart/fault proof must be designed before implementation. Initial qualification
targets ProcessCrash on validated local filesystems. Physical power-loss and distributed fencing
remain separate gates; do not downgrade a requested stronger policy silently.

The [pilot profile](implementation/M2_EMBEDDED_HOST_PROFILE.md) specifies resource/lifetime,
persistence and restart requirements and sequenced acceptance gates.

## Consequences

### Positive

- The next host work has a concrete deployment scope without advancing the M4 server.
- Process ownership and application-controlled admissions can bound the initial worker inventory.
- Backend/codec qualification can proceed without new public APIs or infrastructure dependencies.

### Negative / Accepted Costs

- Exclusivity requires controlled deployment and cannot exclude arbitrary non-cooperating writers.
- Restart remains stopped until fresh reconciliation; no transparent failover is promised.
- Business routing/work accounting and a production consuming application remain open inputs.
- A file ledger requires its own versioned integrity, crash, corruption and durability proof.

## Alternatives Considered

| Option | Why Rejected or Deferred |
|--------|--------------------------|
| Start the ASP.NET Core server now | User selected embedded first; server remains M4 |
| Lease/generation-based automatic takeover | Current publication path does not consume host fencing tokens |
| Select a remote durable database/queue now | Adds infrastructure without a selected consuming application requirement |
| Reuse store provenance as the host ledger | Provenance is not dispatch/routing authority and sealed formats must stay unchanged |
| Treat an unlocked host file as permission to resume | Does not prove worker inventory, fresh histories or complete work accounting |

## References

- [Host ledger contract](implementation/M2_HOST_ATTEMPT_LEDGER_CONTRACT.md)
- [Actual publication/ledger test integration](implementation/M2_HOST_LEDGER_PLANNED_EXECUTION_VALIDATION.md)
- [Pilot profile](implementation/M2_EMBEDDED_HOST_PROFILE.md)
- [Roadmap](../ROADMAP.md)


EP2 follow-up: [ADR-023](ADR-023-bounded-embedded-host-journal-contract.md) defines the local
journal contract. Codec, ownership/persistence implementation and qualification remain open.


EP3 follow-up: [existing-root lifetime validation](implementation/M2_EMBEDDED_HOST_OWNERSHIP_VALIDATION.md)
adds cooperative process ownership and drain without provisioning, append or global fencing.
Explicit provisioning and EP4/EP5 implementation remain open; all writers stay stopped.
