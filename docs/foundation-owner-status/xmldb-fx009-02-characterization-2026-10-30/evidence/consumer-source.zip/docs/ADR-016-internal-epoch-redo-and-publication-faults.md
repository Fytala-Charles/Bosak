# ADR-016: Internal Epoch Redo and Publication-Fault Recovery

- Status: Accepted for internal ET6; public mutation and broad ET7/ET8 qualification remain pending
- Date: 2026-10-27
- Related: [REQ-007](FEATURE_REQUESTS.md#req-007-mutable-epoch-authority-and-recovery), [ADR-012](ADR-012-mutable-epoch-feature-and-recovery-contract.md), [ADR-015](ADR-015-internal-scalar-epoch-commit.md)

## Context

ET5 can reopen complete materializations but refuses a complete WAL without its generation.
ET6 must recover publication interruptions, including real partial writes and interrupted
recovery, while retaining every committed record and every stable reader identity.

## Decision

Open performs recovery under explicit ScalarWal admission and exclusive writer ownership.
Preflight all canonical WAL, unique transaction IDs, sequence/hash links, scalar semantics,
published generation witnesses/data, CURRENT and stable reader identities before recovery
writes. Existing generations are checked against the logical projection of the base and
preceding scalar operations, even when an earlier generation is absent. Corrupt published
data is never overwritten. BeginRead keeps its read-only full-history validation path.

For an absent generation, synchronize its intact WAL, rebuild in fresh private staging from
the verified predecessor, and require the exact recorded manifest digest and scalar
metadata/value transition. Publish a matching GENERATION witness and stable reader identity.
After full verification, publish CURRENT from the verified head if absent or lagging.
Repeated interrupted recovery starts fresh staging and validates/reuses completed publications.
Neither private stages nor selector/reader temporaries are promoted as authority.

A final physically incomplete WAL may be removed only after canonical path/framing checks
and all publication witnesses exclude that sequence. Supported framing requires every
available magic/version prefix byte to agree and any complete length field to be bounded.
Every available binding/role/sequence byte must also match the expected epoch/position.
A complete checksum failure, malformed/unsupported header, later record, CURRENT, published
generation or stable reader witness prevents removal. Delete only that uncommitted tail
through the storage seam and synchronize its directory. This is not committed-history
reclamation. Unknown published state and missing witnessed WAL fail closed.

Persistence errors fault a live committing owner; failed opens expose no owner and release
their handles. Returned old snapshots continue to own independent admission/generation
handles. Commit exceptions remain uncertain outcomes, including after acknowledgment loss.
All wire formats, public profile gates, proprietary licensing and frozen fixtures stay fixed.

## Consequences

Full-history preflight and verification remain deliberately expensive. Fresh private stages
can accumulate after failures; no automatic workspace cleanup or history retirement is added.
ProcessCrash is default; native Linux stronger-policy execution does not establish hardware
power-loss behavior. Injected disk-full errors are not real ENOSPC evidence. Complete ET7
classification and ET8 platform qualification, ET9 backup/migration, C1-C3 and retirement
remain separate gates. Simultaneous loss of all journal/publication witnesses cannot be
inferred from the remaining base alone.

## Validation

[ET6 validation](implementation/M2_EPOCH_RECOVERY_VALIDATION.md) covers every observed
before/after persistence call for zero/positive-head commits, redo and tail removal; partial
file writes; all supported WAL truncations; required corruption/witness refusal; process
kills and repeated redo; and the complete existing suite on Windows and native Linux.
See [runtime contract](implementation/M2_EPOCH_RECOVERY.md).
