# ADR-008: Reader Compatibility, Backup and Retirement Boundary

**Status:** Accepted design direction; format-1/epoch backup and internal scalar recovery implemented; migration acceptance per ADR-018 designed, runtime migration/retirement pending  
**Date:** 2026-10-26  
**Deciders:** Bosak.XmlDb implementation within the authorized M2 design scope

## Context

[REQ-005](FEATURE_REQUESTS.md) protects all committed history. Leases introduced in
ADR-006 cannot account for older binaries or pre-adoption snapshots. ADR-007 inventories
files but cannot authorize deletion. Current recovery requires the original base and
every retained WAL record. A safe transition must reject incompatible opens, preserve
reader lifetimes and provide an independently verified restore route.

## Decision

Keep version 1 non-deleting. Do not add an in-place compatibility marker that old code
ignores. Design an explicit offline migration into a separate, exclusively created
root with a new mandatory FORMAT major and store/epoch identity. Old supported entry
points must reject that major before creating transaction state. Preserve the original
root and prohibit automatic replacement, rename or cleanup of it. A migration is a
copy/export and verification operation, not proof that old readers have disappeared.

Specify full-history, fixed-sequence backup/restore first, using the current format.
Hold coordinator ownership and exclude commits for the entire capture. Produce a sealed
inventory with exact bytes, lengths and hashes, validate the destination through full
recovery, and restore only into a new root. Snapshot-only XML export is a distinct
operation: it does not preserve transaction history or persistent identity.

Future reclamation requires an epoch-wide admission lease held by every snapshot and
transaction, a mandatory compatible format, and a separately implemented retirement
journal. Initial reclamation scope is redundant generation materializations only;
base and WAL-prefix removal remain excluded until a new recovery authority and byte
contract exist. Retention reports remain advisory and CanReclaim remains false.

The [protocol](implementation/M2_COMPATIBILITY_BACKUP_RETIREMENT.md) defines states,
publication order, restore checks, failure behavior and acceptance gates. Its record
fields are semantic requirements, not frozen wire encodings or shipped APIs.

## Consequences

### Positive

- Old binaries cannot silently enter a new-format root through supported entry points.
- The original root and existing lazy readers remain independent of migration success.
- Backup correctness has a fixed commit boundary and a testable full-recovery oracle.
- Generation retirement can be proved before changing authoritative WAL retention.

### Negative / Accepted Costs

- Migration and full-history backup require temporary additional disk and blocked writes.
- An operator must exclude uncooperative writers; OS leases do not fence administrators.
- A format-major implementation, byte fixtures, migration and retirement tests remain open.
- No physical power-loss, real ENOSPC, online backup or reclamation support is added here.

## Alternatives Considered

| Option | Why Rejected |
|--------|--------------|
| New optional marker in the existing root | Old binaries can ignore it |
| Absence of exclusive lease conflict proves quiescence | Old readers may have no lease and future readers can race |
| Rename the old root over a new one | Lazy readers can resolve paths again; Windows handles and rollback become unsafe |
| Copy CURRENT and the latest checkpoint alone | Current recovery still requires original base and complete WAL |
| Reuse process lock files in a restored store | Locks belong to OS handles; copying identity bytes does not transfer ownership |
| Truncate WAL as the first retirement step | It changes recovery authority and removes the independent full-history oracle |

## References

- [ADR-006](ADR-006-nondeleting-checkpoints-and-reader-leases.md)
- [ADR-007](ADR-007-recovery-descriptors-and-retention-inventory.md)
- [Protocol and acceptance matrix](implementation/M2_COMPATIBILITY_BACKUP_RETIREMENT.md)
- [Current format](implementation/M2_TRANSACTION_FORMAT_V1.md)

*Last updated: 2026-10-27*

Implementation update (2026-10-27): [ADR-009](ADR-009-verified-full-history-backup-and-restore.md)
implements the format-1 backup/restore slice and fixes its separate byte contract.
Epoch admission, migration and retirement portions of this ADR remain design-only.

Implementation update (2026-10-27): [ADR-010](ADR-010-mandatory-epoch-format-and-admission-primitives.md)
adds internal mandatory-major-2 metadata and OS admission primitives, not real epoch
XML stores. Complete C1-C3, broader archived-reader proof and retirement remain open.


Migration design update (2026-10-27): [ADR-018](ADR-018-full-history-legacy-migration-and-cutover.md) and
[MG1-MG5 acceptance criteria](implementation/M2_EPOCH_MIGRATION_DESIGN.md) now specify sealed
legacy-backup conversion, four verification oracles, fresh epoch authority and separate
migration provenance. Cutover requires an operator-held write freeze, exact source and
candidate freshness checks and explicit routing; original roots/history stay intact.
ET9-D backup/restore qualification is complete for its recorded scope. No migration codec,
runtime converter, route switch or retirement is implemented. Next: MG1 codecs/fixtures.
