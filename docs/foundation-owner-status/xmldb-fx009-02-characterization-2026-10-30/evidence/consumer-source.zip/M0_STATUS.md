# Bosak.XmlDb M0 Status

- Date: 2026-10-26.
- Path: D:/Development/Bosal.XmlDb; canonical product name Bosak.XmlDb.
- SDK/OS: verified .NET SDK 10.0.301; Windows 10.0.26300, x64.
- Scope: M0 project setup only. Three empty runtime projects and two test projects.
- Bosak baseline: design cites archive commit 927d7a458dd90a8b506840c045808f4f27e3c8d1;
  not independently verified or referenced. No upstream source changed.
- Dependency pins: MinVer 6.0.0, Microsoft.NET.Test.Sdk 17.14.1,
  xunit 2.9.3, xunit.runner.visualstudio 3.1.4.
- Hygiene: Templates 1.0.0 / FYTALA kit 1.2.0, with original generation provenance.
- Git: initialized main locally, no commits/tags/remotes; no remote CI run claimed.

## Commands and Evidence

- `dotnet --info`: SDK 10.0.301 verified.
- `dotnet restore Bosak.XmlDb.slnx`: passed for five projects.
- `dotnet build Bosak.XmlDb.slnx -c Release --no-restore`: passed, zero errors;
  five MinVer MINVER1001 warnings in the initial uncommitted checkout. The validation
  account differs from the Git directory owner. No released version is claimed.
- `dotnet test Bosak.XmlDb.slnx -c Release --no-build`: passed 4, failed 0, skipped 0.
  These guard project references and the absence of embedded runtime packages;
  they do not test an XML engine.
- `dotnet format Bosak.XmlDb.slnx --verify-no-changes --no-restore`: passed.
- `pwsh tools/check-docs.ps1 -ProjectPath . -Strict`: passed all checks, including kit hashes, branding, renderer settings, provenance and local links.

## Limitations and Next Actions

The owner selected the proprietary Fytala license on 2026-10-26, using wording
from D:/Development/Bosak.Braid/LICENSE.md. IsPackable=false remains in effect.
Select and verify
exact Bosak package versions or an immutable source baseline before M1 integration.
The default Windows pwsh alias was unavailable; a local ignored PowerShell 7.5.4
tool was installed for verification and run with DOTNET_ROLL_FORWARD=Major against
installed .NET 10. CI uses hosted PowerShell 7. No global tool/settings changed.

No lazy fragment I/O, persistent format, API, benchmark or remote CI result exists.
Linux CI is configured but has not executed here. Renderer fixture needs visual
review in supported renderers; mechanical hygiene cannot claim visual acceptance.
See docs/implementation/FIXTURE_PLAN.md and the supplied M1 plan for next work.

*Last updated: 2026-10-26*

