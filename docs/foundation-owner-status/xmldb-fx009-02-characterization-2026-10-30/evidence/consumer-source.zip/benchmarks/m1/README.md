# M1 Query Measurements

## Environment and Method

2026-10-26, Windows 10.0.26300 x64, .NET runtime 10.0.11, SDK 10.0.301, Release.
Bosak 1.26.2; 500 generated SalesOrder lines, 16 lines per group, 100 measurements
per query/mode. [Raw JSON lines](windows-net10-500-lines.jsonl) contain percentiles,
per-query allocated bytes, fragment reads/bytes and cache hits.

Run with a new store path:

```sh
dotnet run --project samples/EmbeddedQuickstart -c Release -- benchmark new-benchmark-store 500
```

Compilation and XML import are excluded from timing. In-memory uses a resident tree;
warm mode retains a snapshot/fragment cache; fresh mode opens a new snapshot for each
query and times only evaluation, excluding metadata open. OS disk cache is not
flushed: fresh-fragment-cache is not an OS-cold disk claim. Warm counters include
the initial warm-up query plus 100 measurements. Fresh counters sum 100 snapshots.
Allocation measurements include small harness overhead. Timing noise, JIT/tiering,
process scheduling and GC can affect this single local run; it is an initial baseline.

## Recorded Latencies

All values are microseconds.

| Query | Mode | p50 | p95 | p99 |
|-------|------|-----|-----|-----|
| Header ID | In-memory | 308.2 | 496.1 | 587.6 |
| Header ID | Warm fragments | 235.1 | 340.3 | 579.5 |
| Header ID | Fresh fragments | 343.2 | 461.3 | 602.3 |
| Line count | In-memory | 344.3 | 389.0 | 557.5 |
| Line count | Warm fragments | 232.7 | 303.3 | 462.7 |
| Line count | Fresh fragments | 448.6 | 586.6 | 703.4 |
| Tenth ItemID | In-memory | 88.1 | 100.4 | 164.0 |
| Tenth ItemID | Warm fragments | 85.1 | 95.1 | 180.6 |
| Tenth ItemID | Fresh fragments | 187.0 | 326.0 | 592.5 |

## I/O and Metadata Evidence

- Fresh header queries: 100 header file reads, 17,700 bytes, zero line payload reads.
- Line counts: zero payload reads in both persistent modes.
- Fresh tenth-line queries: 100 line-group reads, 183,900 bytes, zero header reads.
- Warm header/tenth-line runs: one initial physical read, then 100 cache hits each.
- Directory: 4,008 node records, 296,137 encoded bytes. Snapshot open allocated
  2,308,080 bytes; estimated retained snapshot memory was 820,640 bytes. The GC-based
  retained estimate is not an exact object-size audit and excludes unrelated provider state.

The suite also validates I/O isolation across 0, 1, 10, 500 and 10,000 lines and varied
group sizes. These measurements support lazy payload access; they do not establish
an overall speed advantage. Full OS-cold storage tests, extended repetitions,
concurrency and cross-platform comparisons remain follow-up performance work.

*Last updated: 2026-10-26*
