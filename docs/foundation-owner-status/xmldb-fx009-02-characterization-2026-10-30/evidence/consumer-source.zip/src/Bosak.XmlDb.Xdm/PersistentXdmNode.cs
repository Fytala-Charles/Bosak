// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Adapts immutable persisted nodes to the Bosak XDM contract.
// SPECIAL NOTES        : Immutable M1 format; no transaction or crash recovery guarantee.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Text;
using System.Xml;
using Bosak.XmlDb.Core;
using Bosak.XmlDb.Storage;
using Bosak.XPath.Core.Xdm;

namespace Bosak.XmlDb.Xdm;

/// <summary>Adapts immutable persisted nodes to the Bosak XDM contract.</summary>
public sealed class PersistentXdmNode : IXdmNode
{
    private readonly ImmutableXmlSnapshot _snapshot;
    private readonly ulong _id;
    private StorageNode Metadata => _snapshot.GetNode(_id);

    /// <summary>Opens a wrapper; the caller retains snapshot ownership.</summary>
    /// <param name="snapshot">Live immutable snapshot.</param>
    /// <param name="nodeId">Node identity; defaults to the document.</param>
    public PersistentXdmNode(ImmutableXmlSnapshot snapshot, ulong nodeId = 1)
    {
        ArgumentNullException.ThrowIfNull(snapshot);
        _ = snapshot.GetNode(nodeId);
        _snapshot = snapshot;
        _id = nodeId;
    }

    /// <inheritdoc />
    public XdmNodeKind NodeKind => (XdmNodeKind)Metadata.Kind;
    /// <inheritdoc />
    public string LocalName => Metadata.LocalName;
    /// <inheritdoc />
    public string NamespaceUri => Metadata.NamespaceUri;
    /// <inheritdoc />
    public string Prefix => Metadata.Prefix;
    /// <inheritdoc />
    public long DocumentOrder => checked((long)Metadata.Id);
    /// <inheritdoc />
    public string BaseUri => Metadata.BaseUri;
    /// <inheritdoc />
    public string DocumentUri { get { _snapshot.ThrowIfDisposed(); return _snapshot.DocumentUri; } }
    /// <inheritdoc />
    public IXdmNode? Parent => Metadata.ParentId == 0 ? null : Open(Metadata.ParentId);
    /// <inheritdoc />
    public IXdmNode Document { get { _snapshot.ThrowIfDisposed(); return Open(1); } }
    /// <inheritdoc />
    public XdmValue TypedValue => XdmValue.FromString(StringValue);
    /// <inheritdoc />
    public bool IsId => NodeKind == XdmNodeKind.Attribute && LocalName == "id" && NamespaceUri == "http://www.w3.org/XML/1998/namespace";

    /// <inheritdoc />
    public string StringValue
    {
        get
        {
            if (NodeKind is not (XdmNodeKind.Element or XdmNodeKind.Document)) return _snapshot.ReadValue(_id);
            var builder = new StringBuilder();
            foreach (var id in Descendants(_id))
                if (_snapshot.GetNode(id).Kind == StorageNodeKind.Text) builder.Append(_snapshot.ReadValue(id));
            return builder.ToString();
        }
    }

    /// <inheritdoc />
    public bool IsSameNode(IXdmNode other)
    {
        _snapshot.ThrowIfDisposed();
        if (other is not PersistentXdmNode node) return false;
        node._snapshot.ThrowIfDisposed();
        // Cross-snapshot wrappers are intentionally distinct until MVCC identity is specified.
        return ReferenceEquals(_snapshot, node._snapshot) && _id == node._id;
    }

    /// <inheritdoc />
    public XdmSequence Children(XdmNodeKind kind = XdmNodeKind.All) => Sequence(() =>
        Metadata.Children.Where(id => ((XdmNodeKind)_snapshot.GetNode(id).Kind & kind) != 0));

    /// <inheritdoc />
    public XdmSequence Attributes(string? localName = null, string? namespaceUri = null) => Sequence(() =>
        Metadata.Attributes.Where(id => (localName is null || _snapshot.GetNode(id).LocalName == localName) &&
                                      (namespaceUri is null || _snapshot.GetNode(id).NamespaceUri == namespaceUri)));

    /// <inheritdoc />
    public XdmSequence Axis(XdmAxis axis) => Sequence(() => AxisIds(axis));

    /// <summary>Resolves this snapshot's exact stored URI for an evaluation document loader.</summary>
    /// <param name="uri">Absolute URI supplied by the Bosak evaluation context.</param>
    /// <returns>The document node from this same snapshot.</returns>
    /// <exception cref="FileNotFoundException">The URI is not this snapshot's document.</exception>
    public IXdmNode ResolveDocument(string uri)
    {
        _snapshot.ThrowIfDisposed();
        if (_snapshot.DocumentUri.Length == 0 || !string.Equals(uri, _snapshot.DocumentUri, StringComparison.Ordinal))
            throw new FileNotFoundException("URI is not registered in this snapshot.", uri);
        return Open(1);
    }

    /// <summary>Binds an evaluator-produced lazy result to this snapshot's lifetime.</summary>
    /// <param name="result">Result returned by the Bosak evaluator.</param>
    /// <returns>A sequence that validates lifetime at enumeration and every fetch.</returns>
    /// <remarks>Use this at the evaluation boundary because the VM may materialize its own result sequence.</remarks>
    public XdmSequence BindResult(XdmSequence result)
    {
        _snapshot.ThrowIfDisposed();
        return XdmSequence.FromSource(new NodeSequence(_snapshot, Enumerate));
        IEnumerable<XdmValue> Enumerate()
        {
            foreach (var item in result) yield return item;
        }
    }
    /// <inheritdoc />
    public string ToXmlString()
    {
        _snapshot.ThrowIfDisposed();
        if (NodeKind == XdmNodeKind.Namespace) return string.Empty;
        if (NodeKind == XdmNodeKind.Attribute) return StringValue;
        var builder = new StringBuilder();
        using (var writer = XmlWriter.Create(builder, new XmlWriterSettings
        {
            OmitXmlDeclaration = true,
            ConformanceLevel = ConformanceLevel.Fragment,
            Indent = false,
        })) WriteXml(writer, _id);
        return builder.ToString();
    }

    /// <inheritdoc />
    public override bool Equals(object? obj) => obj is PersistentXdmNode node &&
        ReferenceEquals(_snapshot, node._snapshot) && _id == node._id;

    /// <inheritdoc />
    public override int GetHashCode() => HashCode.Combine(_snapshot, _id);
    private PersistentXdmNode Open(ulong id) => new(_snapshot, id);

    private IEnumerable<ulong> Descendants(ulong id)
    {
        foreach (var child in _snapshot.GetNode(id).Children)
        {
            yield return child;
            foreach (var nested in Descendants(child)) yield return nested;
        }
    }

    private IEnumerable<ulong> Ancestors(ulong id)
    {
        var parent = _snapshot.GetNode(id).ParentId;
        while (parent != 0)
        {
            yield return parent;
            parent = _snapshot.GetNode(parent).ParentId;
        }
    }

    private IEnumerable<ulong> AxisIds(XdmAxis axis)
    {
        var metadata = Metadata;
        return axis switch
        {
            XdmAxis.Self => [_id],
            XdmAxis.Child => metadata.Children,
            XdmAxis.Attribute => metadata.Attributes,
            XdmAxis.Namespace => metadata.Namespaces,
            XdmAxis.Parent => metadata.ParentId == 0 ? [] : [metadata.ParentId],
            XdmAxis.Descendant => Descendants(_id),
            XdmAxis.DescendantOrSelf => new[] { _id }.Concat(Descendants(_id)),
            XdmAxis.Ancestor => Ancestors(_id),
            XdmAxis.AncestorOrSelf => new[] { _id }.Concat(Ancestors(_id)),
            XdmAxis.FollowingSibling => Siblings().Where(id => id > _id),
            XdmAxis.PrecedingSibling => Siblings().Where(id => id < _id).Reverse(),
            XdmAxis.Following => Descendants(1).Where(id => id > _id && !Ancestors(id).Contains(_id)),
            XdmAxis.Preceding => Descendants(1).Where(id => id < _id && !Ancestors(_id).Contains(id)).Reverse(),
            _ => throw new ArgumentOutOfRangeException(nameof(axis)),
        };
    }

    private IEnumerable<ulong> Siblings() => Metadata.ParentId == 0 ||
        NodeKind is XdmNodeKind.Attribute or XdmNodeKind.Namespace
        ? [] : _snapshot.GetNode(Metadata.ParentId).Children;

    private XdmSequence Sequence(Func<IEnumerable<ulong>> ids)
    {
        _snapshot.ThrowIfDisposed();
        return XdmSequence.FromSource(new NodeSequence(_snapshot, () => Values(ids())));
    }

    private IEnumerable<XdmValue> Values(IEnumerable<ulong> ids)
    {
        _snapshot.ThrowIfDisposed();
        foreach (var id in ids)
        {
            _snapshot.ThrowIfDisposed();
            yield return XdmValue.FromNode(Open(id));
        }
        _snapshot.ThrowIfDisposed();
    }

    private void WriteXml(XmlWriter writer, ulong id)
    {
        var node = _snapshot.GetNode(id);
        switch (node.Kind)
        {
            case StorageNodeKind.Document:
                foreach (var child in node.Children) WriteXml(writer, child);
                break;
            case StorageNodeKind.Element:
                writer.WriteStartElement(node.Prefix, node.LocalName, node.NamespaceUri);
                foreach (var nsId in node.Namespaces)
                {
                    var ns = _snapshot.GetNode(nsId);
                    if (ns.LocalName == "xml") continue;
                    if (ns.LocalName.Length == 0) writer.WriteAttributeString("xmlns", _snapshot.ReadValue(nsId));
                    else writer.WriteAttributeString("xmlns", ns.LocalName, null, _snapshot.ReadValue(nsId));
                }
                foreach (var attribute in node.Attributes)
                {
                    var attr = _snapshot.GetNode(attribute);
                    writer.WriteAttributeString(attr.Prefix, attr.LocalName, attr.NamespaceUri, _snapshot.ReadValue(attribute));
                }
                foreach (var child in node.Children) WriteXml(writer, child);
                writer.WriteEndElement();
                break;
            case StorageNodeKind.Text: writer.WriteString(_snapshot.ReadValue(id)); break;
            case StorageNodeKind.Comment: writer.WriteComment(_snapshot.ReadValue(id)); break;
            case StorageNodeKind.ProcessingInstruction: writer.WriteProcessingInstruction(node.LocalName, _snapshot.ReadValue(id)); break;
            default: throw new InvalidOperationException("Cannot serialize this node as content.");
        }
    }

    private sealed class NodeSequence(ImmutableXmlSnapshot snapshot, Func<IEnumerable<XdmValue>> values) : IXdmSequence
    {
        public bool TryGetLength(out int length) { snapshot.ThrowIfDisposed(); length = 0; return false; }
        public IXdmSequenceEnumerator GetEnumerator()
        {
            snapshot.ThrowIfDisposed();
            return new NodeEnumerator(snapshot, values().GetEnumerator());
        }
    }

    private sealed class NodeEnumerator(ImmutableXmlSnapshot snapshot, IEnumerator<XdmValue> inner) : IXdmSequenceEnumerator
    {
        public XdmValue Current { get { snapshot.ThrowIfDisposed(); return inner.Current; } }
        public bool MoveNext()
        {
            snapshot.ThrowIfDisposed();
            var moved = inner.MoveNext();
            if (!moved) inner.Dispose();
            return moved;
        }
    }
}



