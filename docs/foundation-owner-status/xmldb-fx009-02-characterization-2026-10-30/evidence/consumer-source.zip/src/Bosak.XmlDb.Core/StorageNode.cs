// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Describes immutable XML node metadata independently of Bosak.
// SPECIAL NOTES        : Immutable M1 format; no transaction or crash recovery guarantee.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Core;

/// <summary>Identifies XML node kinds in persisted format version 1.</summary>
public enum StorageNodeKind : byte
{
    /// <summary>A document.</summary>
    Document = 1,
    /// <summary>An element.</summary>
    Element = 2,
    /// <summary>An attribute.</summary>
    Attribute = 4,
    /// <summary>Text, including CDATA content.</summary>
    Text = 8,
    /// <summary>A comment.</summary>
    Comment = 16,
    /// <summary>A processing instruction.</summary>
    ProcessingInstruction = 32,
    /// <summary>An in-scope namespace owned by an element.</summary>
    Namespace = 64,
}

/// <summary>Describes immutable XML node metadata independently of Bosak.</summary>
/// <param name="Id">Stable node identity within a document.</param>
/// <param name="ParentId">Parent ID, or zero for the document.</param>
/// <param name="Kind">XML node kind.</param>
/// <param name="LocalName">Local name or namespace prefix.</param>
/// <param name="NamespaceUri">Expanded name namespace URI.</param>
/// <param name="Prefix">Lexical name prefix.</param>
/// <param name="BaseUri">Effective base URI.</param>
/// <param name="FragmentId">Value fragment, or zero for structural nodes.</param>
/// <param name="ValueOffset">UTF-8 value offset in the fragment payload.</param>
/// <param name="ValueLength">UTF-8 value byte length.</param>
/// <param name="Children">Ordered child identities.</param>
/// <param name="Attributes">Ordered attribute identities.</param>
/// <param name="Namespaces">Ordered in-scope namespace identities.</param>
public sealed record StorageNode(
    ulong Id, ulong ParentId, StorageNodeKind Kind, string LocalName,
    string NamespaceUri, string Prefix, string BaseUri,
    ulong FragmentId, int ValueOffset, int ValueLength,
    IReadOnlyList<ulong> Children, IReadOnlyList<ulong> Attributes,
    IReadOnlyList<ulong> Namespaces);

/// <summary>Reports physical fragment I/O and cache activity for one snapshot.</summary>
/// <param name="PhysicalFragmentReads">Number of payload file reads.</param>
/// <param name="BytesRead">Total payload file bytes read, including framing.</param>
/// <param name="CacheHits">Number of decoded cache hits.</param>
/// <param name="HeaderFragmentReads">Reads of header fragment 1.</param>
/// <param name="LineFragmentReads">Reads of repeating line fragments.</param>
public readonly record struct FragmentReadMetrics(
    long PhysicalFragmentReads, long BytesRead, long CacheHits,
    long HeaderFragmentReads, long LineFragmentReads);
