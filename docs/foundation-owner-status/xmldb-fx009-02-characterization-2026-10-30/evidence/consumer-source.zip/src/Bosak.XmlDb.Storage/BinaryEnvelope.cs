// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Encodes bounded versioned files with SHA-256 integrity.
// SPECIAL NOTES        : Immutable M1 format; no transaction or crash recovery guarantee.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Text;

namespace Bosak.XmlDb.Storage;

internal static class BinaryEnvelope
{
    internal const int MaximumFileBytes = 64 * 1024 * 1024;
    internal const int MaximumStringBytes = 1024 * 1024;
    internal const int MaximumNodes = 1_000_000;
    internal static readonly UTF8Encoding Utf8 = new(false, true);

    internal static byte[] Encode(string magic, Action<BinaryWriter> write)
    {
        using var body = new BoundedBodyStream();
        using (var writer = new BinaryWriter(body, Utf8, true))
        {
            write(writer);
        }
        if (body.Length > MaximumFileBytes - 44)
            throw new InvalidDataException("File exceeds the M1 size limit.");
        var result = new byte[checked((int)body.Length + 44)];
        Encoding.ASCII.GetBytes(magic).CopyTo(result, 0);
        BinaryPrimitives.WriteUInt16LittleEndian(result.AsSpan(4), 1);
        BinaryPrimitives.WriteUInt16LittleEndian(result.AsSpan(6), 0);
        BinaryPrimitives.WriteInt32LittleEndian(result.AsSpan(8), (int)body.Length);
        body.GetBuffer().AsSpan(0, (int)body.Length).CopyTo(result.AsSpan(12));
        SHA256.HashData(result.AsSpan(0, result.Length - 32), result.AsSpan(result.Length - 32));
        return result;
    }

    internal static T Decode<T>(byte[] bytes, string magic, Func<BinaryReader, T> read)
    {
        if (bytes.Length < 44 || bytes.Length > MaximumFileBytes ||
            !bytes.AsSpan(0, 4).SequenceEqual(Encoding.ASCII.GetBytes(magic)) ||
            BinaryPrimitives.ReadUInt16LittleEndian(bytes.AsSpan(4)) != 1 ||
            BinaryPrimitives.ReadUInt16LittleEndian(bytes.AsSpan(6)) != 0 ||
            BinaryPrimitives.ReadInt32LittleEndian(bytes.AsSpan(8)) != bytes.Length - 44 ||
            !CryptographicOperations.FixedTimeEquals(SHA256.HashData(bytes.AsSpan(0, bytes.Length - 32)), bytes.AsSpan(bytes.Length - 32)))
            throw new InvalidDataException("Invalid file framing, version, length or checksum.");
        try
        {
            using var stream = new MemoryStream(bytes, 12, bytes.Length - 44, false);
            using var reader = new BinaryReader(stream, Utf8);
            var value = read(reader);
            if (stream.Position != stream.Length)
                throw new InvalidDataException("Unexpected trailing data.");
            return value;
        }
        catch (Exception exception) when (exception is EndOfStreamException or DecoderFallbackException or ArgumentException or OverflowException)
        {
            throw new InvalidDataException("Invalid bounded binary payload.", exception);
        }
    }

    internal static byte[] ReadFile(string path)
    {
        RejectLinks(path);
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        if (stream.Length < 44 || stream.Length > MaximumFileBytes)
            throw new InvalidDataException("Invalid file size.");
        var bytes = new byte[(int)stream.Length];
        stream.ReadExactly(bytes);
        if (stream.ReadByte() != -1)
            throw new InvalidDataException("File changed while reading.");
        return bytes;
    }

    internal static void RejectLinks(string path)
    {
        for (var current = new FileInfo(Path.GetFullPath(path)) as FileSystemInfo; current is not null;
             current = current is DirectoryInfo directory ? directory.Parent : ((FileInfo)current).Directory)
        {
            if ((current.Attributes & FileAttributes.ReparsePoint) != 0)
                throw new InvalidDataException("Store paths must not traverse symbolic links or junctions.");
        }
    }

    internal static void WriteString(BinaryWriter writer, string value)
    {
        var bytes = Utf8.GetBytes(value);
        if (bytes.Length > MaximumStringBytes)
            throw new InvalidDataException("String exceeds the format limit.");
        writer.Write(bytes.Length);
        writer.Write(bytes);
    }

    internal static string ReadString(BinaryReader reader)
    {
        var length = ReadCount(reader, MaximumStringBytes);
        var bytes = reader.ReadBytes(length);
        if (bytes.Length != length)
            throw new InvalidDataException("Truncated string.");
        return Utf8.GetString(bytes);
    }

    private sealed class BoundedBodyStream : MemoryStream
    {
        private void Check(int count)
        {
            if (count < 0 || Position + count > MaximumFileBytes - 44)
                throw new InvalidDataException("File body exceeds the format size limit.");
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            Check(count);
            base.Write(buffer, offset, count);
        }

        public override void Write(ReadOnlySpan<byte> buffer)
        {
            Check(buffer.Length);
            base.Write(buffer);
        }

        public override void WriteByte(byte value)
        {
            Check(1);
            base.WriteByte(value);
        }
    }
    internal static int ReadCount(BinaryReader reader, int maximum)
    {
        var count = reader.ReadInt32();
        if (count < 0 || count > maximum || count > reader.BaseStream.Length - reader.BaseStream.Position)
            throw new InvalidDataException("Invalid bounded count.");
        return count;
    }
}

