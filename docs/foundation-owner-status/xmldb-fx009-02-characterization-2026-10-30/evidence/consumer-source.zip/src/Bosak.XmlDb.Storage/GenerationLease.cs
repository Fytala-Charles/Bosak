// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Pins snapshot generations with stable cross-process reader leases.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Globalization;

namespace Bosak.XmlDb.Storage;

internal static class GenerationLease
{
    internal static string PathFor(string transactions, ulong sequence) =>
        Path.Combine(transactions, "readers", sequence.ToString("D20", CultureInfo.InvariantCulture) + ".lease");

    internal static byte[] Encode(ulong documentId, ulong sequence) => BinaryEnvelope.Encode("BXRL", writer =>
    {
        writer.Write(documentId);
        writer.Write(sequence);
    });

    internal static FileStream Acquire(string transactions, ulong documentId, ulong sequence, ITransactionStorage storage)
    {
        var path = PathFor(transactions, sequence);
        TransactionCodec.EnsureDirectory(Path.GetDirectoryName(path)!, storage);
        if (!File.Exists(path))
        {
            // Publish a complete immutable lease identity; partial temporary files never become the stable lock inode.
            var temporary = path + ".tmp-" + Guid.NewGuid().ToString("N");
            TransactionCodec.WriteFlushed(temporary, Encode(documentId, sequence), storage);
            TransactionCodec.PublishFile(temporary, path, false, storage);
        }
        Validate(path, documentId, sequence);
        return new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
    }

    internal static FileStream OpenExclusive(string transactions, ulong documentId, ulong sequence)
    {
        var path = PathFor(transactions, sequence);
        Validate(path, documentId, sequence);
        return new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None);
    }

    private static void Validate(string path, ulong documentId, ulong sequence) =>
        BinaryEnvelope.Decode(BinaryEnvelope.ReadFile(path), "BXRL", reader =>
        {
            if (reader.ReadUInt64() != documentId || reader.ReadUInt64() != sequence)
                throw new InvalidDataException("Generation lease identity mismatch.");
            return true;
        });

    internal static bool IsStableLease(string root, string path)
    {
        var parent = Path.Combine(root, ".transactions", "readers");
        var comparison = OperatingSystem.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;
        if (!string.Equals(Path.GetDirectoryName(path), parent, comparison)) return false;
        var name = Path.GetFileName(path);
        return name.Length == 26 && name.EndsWith(".lease", StringComparison.Ordinal) &&
            ulong.TryParse(name.AsSpan(0, 20), NumberStyles.None, CultureInfo.InvariantCulture, out var sequence) &&
            name == sequence.ToString("D20", CultureInfo.InvariantCulture) + ".lease";
    }
}
