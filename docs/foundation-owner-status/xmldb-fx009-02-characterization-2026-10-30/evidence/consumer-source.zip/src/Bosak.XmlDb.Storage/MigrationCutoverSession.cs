// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Models session-bound cutover freshness and routing decisions without external state changes.
// SPECIAL NOTES        : Internal prototype acceptance only; no persistent fence, routing service or retirement.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      | Charles Korthout | 0.2   | 29-10-2026     | Bind enrollment inspection to the live frozen source owner
//                      | Charles Korthout | 0.3   | 29-10-2026     | Add exact single-use retained enrollment child binding
//                      | Charles Korthout | 0.4   | 29-10-2026     | Detect invalid caller-held source gates before combined admission
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal enum CutoverRoute { Legacy, Candidate, Unknown, Other }
internal enum CutoverAction { ProposeCandidate, ObserveCandidateOutcome, ProposeLegacyReturn, ObserveLegacyOutcome }
internal enum CutoverDecision { LegacyObserved, CandidateProposed, CandidateObserved, LegacyReturnProposed, RoutingUncertain, ReconciliationRequired }
internal sealed record CutoverWork(bool Drained, bool NoWorkAccepted);

internal sealed class FrozenMigrationCapture
{
    private readonly byte[] _bytes;
    internal string Artifact { get; }
    internal byte[] InventoryBytes => (byte[])_bytes.Clone();
    internal BackupInventory Inventory => EpochMigrationCodec.ReadSourceInventory(_bytes);
    internal FrozenMigrationCapture(string artifact, byte[] bytes) { Artifact = artifact; _bytes = (byte[])bytes.Clone(); }
}

internal sealed class MigrationSourceFreeze : IDisposable
{
    private readonly EmbeddedXmlDatabase _owner;
    private readonly Guid _token;
    private readonly int _thread = Environment.CurrentManagedThreadId;
    private bool _disposed;
    private FrozenMigrationCapture? _capture;
    private bool _retentionClaimed;
    private MigrationSourceFreeze(EmbeddedXmlDatabase owner) { _owner = owner; _token = owner.EnterCutoverFreeze(); }
    internal static MigrationSourceFreeze Acquire(EmbeddedXmlDatabase owner, bool operatorWritersStoppedAndDrained)
    {
        if (!operatorWritersStoppedAndDrained) throw new InvalidOperationException("Operator writer-stop/drain attestation is required; this is not an external writer fence.");
        return new(owner);
    }
    internal FrozenMigrationCapture Capture(string destination)
    {
        Check();
        if (_capture is not null) throw new InvalidOperationException("A freeze has exactly one registered capture.");
        return Inspect(state =>
        {
            _owner.CreateBackup(destination);
            var root = Path.GetFullPath(destination); var bytes = BinaryEnvelope.ReadFile(Path.Combine(root, "inventory.bin"));
            var inventory = LegacyMigrationVerifier.ReadArtifact(root);
            LegacyMigrationVerifier.ValidateHistory(Path.Combine(root, "data"), inventory);
            _capture = new(root, bytes); return _capture;
        });
    }
    internal void Require(FrozenMigrationCapture capture)
    {
        Check(); if (!ReferenceEquals(_capture, capture)) throw new InvalidOperationException("Capture was not registered in this active freeze.");
    }
    internal EmbeddedXmlDatabase.RetainedEnrollmentSource RetainForEnrollment(FrozenMigrationCapture capture) =>
        RetainForEnrollmentCore(capture, new LocalEnrollmentSourceLeaseClose());
    internal EmbeddedXmlDatabase.RetainedEnrollmentSource RetainForEnrollmentCore(FrozenMigrationCapture capture, IEnrollmentSourceLeaseClose close) =>
        EmbeddedXmlDatabase.RetainedEnrollmentSource.Acquire(_owner, this, _token, capture, close);
    internal void RequireRetentionBinding(EmbeddedXmlDatabase owner, Guid token, FrozenMigrationCapture capture, bool allowDisposed)
    {
        if (_thread != Environment.CurrentManagedThreadId) throw new InvalidOperationException("Source retention is caller-thread confined.");
        if (capture is null || _capture is null || !ReferenceEquals(owner, _owner) || token != _token || !ReferenceEquals(capture, _capture)) throw new InvalidOperationException("Retention requires the actual source/freeze/capture association.");
        ObjectDisposedException.ThrowIf(_disposed && !allowDisposed, this);
    }
    internal void ClaimRetention(EmbeddedXmlDatabase owner, Guid token, FrozenMigrationCapture capture)
    {
        RequireRetentionBinding(owner, token, capture, false);
        if (_retentionClaimed) throw new InvalidOperationException("A freeze can register exactly one enrollment retainer.");
        _retentionClaimed = true;
    }
    internal void MarkDisposed(EmbeddedXmlDatabase owner)
    { Check(); if (!ReferenceEquals(owner, _owner)) throw new InvalidOperationException("Foreign source owner."); _disposed = true; }
    internal bool IsDisposed => _disposed;
    internal bool IsSourceGateEntered => EmbeddedXmlDatabase.RetainedEnrollmentSource.IsOwnerGateEntered(_owner);
    internal ApplicationFileIdentity InspectAdmission() { Check(); return _owner.InspectCutoverAdmission(_token); }
    internal T Inspect<T>(Func<LegacyCutoverState, T> inspect) { Check(); return _owner.InspectCutover(_token, inspect); }
    private void Check()
    {
        if (_disposed) throw new ObjectDisposedException(nameof(MigrationSourceFreeze));
        if (_thread != Environment.CurrentManagedThreadId) throw new InvalidOperationException("Cutover freeze is caller-thread confined.");
    }
    public void Dispose() { if (_disposed) return; Check(); _owner.ExitCutoverFreeze(_token, this); }
}

internal sealed class CutoverEvidence
{
    internal MigrationCutoverSession Session { get; }
    internal CutoverEvidence(MigrationCutoverSession session) { Session = session; }
}

internal sealed class MigrationCutoverSession : IDisposable
{
    private readonly MigrationSourceFreeze _source;
    private readonly FrozenMigrationCapture _capture;
    private readonly EpochScalarCoordinator _candidate;
    private readonly EpochMigrationResult _result;
    private readonly Guid _token;
    private readonly EpochAdmissionLease _admission;
    private readonly int _thread = Environment.CurrentManagedThreadId;
    private bool _disposed;
    private CutoverEvidence? _latest;
    private CutoverAction? _intent;
    internal CutoverDecision Decision { get; private set; } = CutoverDecision.LegacyObserved;

    private MigrationCutoverSession(MigrationSourceFreeze source, FrozenMigrationCapture capture, EpochScalarCoordinator candidate, EpochMigrationResult result,
        (Guid Token, EpochAdmissionLease Admission) lease)
    { _source = source; _capture = capture; _candidate = candidate; _result = result; _token = lease.Token; _admission = lease.Admission; }
    internal static MigrationCutoverSession Attach(MigrationSourceFreeze source, FrozenMigrationCapture capture, EpochScalarCoordinator candidate,
        EpochMigrationResult result, bool prototypeCompatibilityReviewed)
    {
        if (!prototypeCompatibilityReviewed) throw new InvalidOperationException("Explicit prototype compatibility review is required; archived compatibility remains a separate gap.");
        source.Require(capture); source.Inspect(state => true);
        var lease = candidate.EnterCutoverFreeze(); // Candidate admission is acquired before source/candidate inspection gates.
        var session = new MigrationCutoverSession(source, capture, candidate, result, lease);
        try { session.Validate(); return session; } catch { session.Dispose(); throw; }
    }
    internal CutoverEvidence Prepare()
    {
        Check();
        if (Decision == CutoverDecision.ReconciliationRequired) throw new InvalidOperationException("Reconciliation is terminal for this session.");
        _latest = null;
        try { Validate(); return _latest = new(this); }
        catch { Decision = CutoverDecision.ReconciliationRequired; throw; }
    }
    internal CutoverDecision Evaluate(CutoverEvidence evidence, CutoverAction action, CutoverRoute observed, CutoverWork work)
    {
        Check();
        if (!ReferenceEquals(evidence.Session, this) || !ReferenceEquals(_latest, evidence)) throw new InvalidOperationException("Evidence is stale, consumed or belongs to another session.");
        _latest = null;
        if (!Enum.IsDefined(action) || !Enum.IsDefined(observed)) throw new ArgumentOutOfRangeException(nameof(action));
        if (Decision == CutoverDecision.ReconciliationRequired) throw new InvalidOperationException("Reconciliation is terminal for this session.");
        try { Validate(); }
        catch (Exception exception) when (exception is IOException or InvalidDataException or InvalidOperationException or ObjectDisposedException or NotSupportedException)
        { return Decision = CutoverDecision.ReconciliationRequired; }
        if (!work.Drained || !work.NoWorkAccepted) return Decision = CutoverDecision.ReconciliationRequired;
        switch (action)
        {
            case CutoverAction.ProposeCandidate:
                if (Decision != CutoverDecision.LegacyObserved || observed != CutoverRoute.Legacy) return Decision = CutoverDecision.RoutingUncertain;
                _intent = action; return Decision = CutoverDecision.CandidateProposed;
            case CutoverAction.ObserveCandidateOutcome:
                if (_intent != CutoverAction.ProposeCandidate || Decision is not (CutoverDecision.CandidateProposed or CutoverDecision.RoutingUncertain))
                    throw new InvalidOperationException("No unresolved candidate routing proposal.");
                break;
            case CutoverAction.ProposeLegacyReturn:
                if (Decision != CutoverDecision.CandidateObserved || observed != CutoverRoute.Candidate) return Decision = CutoverDecision.RoutingUncertain;
                _intent = action; return Decision = CutoverDecision.LegacyReturnProposed;
            case CutoverAction.ObserveLegacyOutcome:
                if (_intent != CutoverAction.ProposeLegacyReturn || Decision is not (CutoverDecision.LegacyReturnProposed or CutoverDecision.RoutingUncertain))
                    throw new InvalidOperationException("No unresolved legacy return proposal.");
                break;
        }
        if (observed is CutoverRoute.Unknown or CutoverRoute.Other) return Decision = CutoverDecision.RoutingUncertain;
        _intent = null; return Decision = observed == CutoverRoute.Legacy ? CutoverDecision.LegacyObserved : CutoverDecision.CandidateObserved;
    }
    private void Validate()
    {
        _source.Require(_capture);
        _source.Inspect(source => _candidate.InspectCutover(_token, _admission, candidate =>
        { MigrationCutoverValidation.Validate(source, candidate, _capture, _result); return true; }));
    }
    private void Check()
    {
        if (_disposed) throw new ObjectDisposedException(nameof(MigrationCutoverSession));
        if (_thread != Environment.CurrentManagedThreadId) throw new InvalidOperationException("Cutover session is caller-thread confined.");
    }
    public void Dispose()
    {
        if (_disposed) return; Check(); _disposed = true; _latest = null;
        try { _candidate.ExitCutoverFreeze(_token); } finally { _admission.Dispose(); }
    }
}
