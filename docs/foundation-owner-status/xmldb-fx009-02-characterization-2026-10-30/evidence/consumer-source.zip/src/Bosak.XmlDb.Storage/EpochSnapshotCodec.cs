// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Binds immutable epoch snapshot content to mandatory format and admission identities.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

internal static class EpochSnapshotCodec
{
    internal static byte[] Encode(EpochIdentity identity, byte[] format, byte[] manifestHash) => BinaryEnvelope.Encode("BXES", writer =>
    {
        writer.Write(identity.StoreId.ToByteArray()); writer.Write(identity.EpochId.ToByteArray()); writer.Write(identity.DocumentId);
        writer.Write(0UL); // This slice accepts only immutable sequence zero, not migrated transactional histories.
        writer.Write(SHA256.HashData(format)); writer.Write(manifestHash);
    });

    internal static byte[] Read(string root, EpochIdentity identity) => BinaryEnvelope.Decode(
        BinaryEnvelope.ReadFile(Path.Combine(root, "SNAPSHOT")), "BXES", reader =>
        {
            if (Directory.Exists(Path.Combine(root, ".transactions")) || File.Exists(Path.Combine(root, ".transactions")))
                throw new InvalidDataException("Read-only epoch roots cannot contain transaction state.");
            var store = new Guid(reader.ReadBytes(16)); var epoch = new Guid(reader.ReadBytes(16)); var document = reader.ReadUInt64();
            if (store != identity.StoreId || epoch != identity.EpochId || document != identity.DocumentId || reader.ReadUInt64() != 0 ||
                !reader.ReadBytes(32).AsSpan().SequenceEqual(SHA256.HashData(BinaryEnvelope.ReadFile(Path.Combine(root, "FORMAT")))))
                throw new InvalidDataException("Epoch snapshot identity, sequence or mandatory-format binding mismatch.");
            var hash = reader.ReadBytes(32);
            if (hash.Length != 32) throw new InvalidDataException("Truncated epoch snapshot manifest identity.");
            return hash;
        });
}

internal static class EpochReadOnlyRoot
{
    // Fixture producer only: immutable unadopted M1 input, no transaction/migration authority or public export API.
    internal static EpochIdentity CreateFixture(string source, string destination, ulong documentId, ITransactionStorage storage, Action<EpochStage>? checkpoint = null)
    {
        destination = BackupStorage.Destination(source, destination);
        using var original = ImmutableXmlSnapshot.Open(source, documentId, cacheBytes: 0);
        var hash = TransactionCodec.ManifestHash(source, documentId);
        ScalarGeneration.Validate(source, documentId, hash);
        return EpochAdmission.CreateFixtureRoot(destination, documentId, storage, checkpoint, (staging, identity, format) =>
        {
            var doc = "documents/" + documentId.ToString(System.Globalization.CultureInfo.InvariantCulture) + "/";
            var manifest = StoreCodec.ReadManifest(TransactionCodec.ReadManifestBytes(source, documentId));
            var names = new[] { doc + "manifest.bin", doc + "directory.bin" }.Concat(manifest.Fragments.Select(fragment =>
                "fragments/" + fragment.Id.ToString(System.Globalization.CultureInfo.InvariantCulture) + ".bin"));
            BackupStorage.Copy(source, staging, names, storage); // Never copy a nested legacy FORMAT.
            checkpoint?.Invoke(EpochStage.DataCopied);
            TransactionCodec.WriteFlushed(Path.Combine(staging, "SNAPSHOT"), EpochSnapshotCodec.Encode(identity, format, hash), storage);
            checkpoint?.Invoke(EpochStage.SnapshotFlushed);
            using (var store = ReadOnlyEpochDatabase.Open(staging))
            using (var snapshot = store.BeginRead(cacheBytes: 0))
            {
                foreach (var fragment in manifest.Fragments)
                {
                    var bytes = BinaryEnvelope.ReadFile(Path.Combine(staging, "fragments", fragment.Id.ToString(System.Globalization.CultureInfo.InvariantCulture) + ".bin"));
                    if (!SHA256.HashData(bytes).AsSpan().SequenceEqual(fragment.Hash)) throw new InvalidDataException("Copied epoch fragment differs from manifest.");
                }
                if (snapshot.NodeCount != original.NodeCount) throw new InvalidDataException("Epoch metadata differs from source.");
                for (ulong id = 1; id <= (ulong)snapshot.NodeCount; id++)
                    if (snapshot.ReadValue(id) != original.ReadValue(id)) throw new InvalidDataException("Epoch scalar differs from source.");
            }
            checkpoint?.Invoke(EpochStage.SnapshotVerified);
        });
    }
}
