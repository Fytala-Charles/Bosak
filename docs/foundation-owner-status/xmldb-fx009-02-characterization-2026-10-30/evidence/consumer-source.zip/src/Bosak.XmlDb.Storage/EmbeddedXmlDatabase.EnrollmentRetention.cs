// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Retains original legacy source ownership and freeze exclusion for enrollment children.
// SPECIAL NOTES        : Opt-in source lifetime only; no authority output, persistent fence or write admission.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.3   | 30-10-2026     | Share original writer drain with restart-only source retention                            |
//                      | Charles Korthout | 0.2   | 29-10-2026     | Add nonblocking source arm for combined lifetime admission                                 |
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal enum EnrollmentSourceReleaseState { Owned, RetainedClosing, Released, Unknown }
internal enum EnrollmentSourceRetentionState { Pending, Armed, Faulted, Released, ReleaseUnknown }
internal sealed record EnrollmentSourceOwnerStatus(bool Closing, bool StopLatched, bool HasRetainer, EnrollmentSourceReleaseState ReleaseState);
internal sealed record RetainedEnrollmentSourceState(LegacyCutoverState Source, ApplicationFileIdentity RootIdentity, ApplicationFileIdentity AdmissionIdentity);
internal interface IEnrollmentSourceLeaseClose { void Close(FileStream stream); }
internal sealed class LocalEnrollmentSourceLeaseClose : IEnrollmentSourceLeaseClose
{
    /// <inheritdoc/>
    public void Close(FileStream stream) => stream.Dispose();
}

/// <summary>Retains original legacy source ownership and freeze exclusion for enrollment children.</summary>
public sealed partial class EmbeddedXmlDatabase
{
    private RetainedEnrollmentSource? _enrollmentSource;
    private bool _enrollmentStopLatched;
    private bool _enrollmentCloseAttempted;
    private bool _enrollmentLeaseReleased;
    private Exception? _enrollmentReleaseError;
    private TaskCompletionSource? _enrollmentOwnerReleased;
    private IEnrollmentSourceLeaseClose? _enrollmentClose;

    internal EnrollmentSourceOwnerStatus EnrollmentOwnershipStatus
    {
        get
        {
            lock (_gate) return new(_disposed, _enrollmentStopLatched, _enrollmentSource is not null || _restartSource is not null,
                _enrollmentReleaseError is not null ? EnrollmentSourceReleaseState.Unknown : _enrollmentLeaseReleased ? EnrollmentSourceReleaseState.Released :
                _disposed ? EnrollmentSourceReleaseState.RetainedClosing : EnrollmentSourceReleaseState.Owned);
        }
    }
    internal Task WhenEnrollmentOwnershipReleased
    {
        get
        {
            lock (_gate)
            {
                if (_enrollmentReleaseError is not null) return Task.FromException(_enrollmentReleaseError);
                if (_enrollmentLeaseReleased) return Task.CompletedTask;
                return (_enrollmentOwnerReleased ??= new(TaskCreationOptions.RunContinuationsAsynchronously)).Task;
            }
        }
    }
    private void RejectEnrollmentPublisher()
    {
        if (_enrollmentSource is not null || _enrollmentStopLatched) throw new InvalidOperationException("Retained enrollment or its stop latch excludes new source publishers.");
    }
    private void CloseEnrollmentOwnerIfReady()
    {
        if (_enrollmentSource is not null || _restartSource is not null) return;
        CloseEnrollmentLease();
    }
    private void CloseEnrollmentLease()
    {
        if (_enrollmentCloseAttempted) return;
        _enrollmentCloseAttempted = true;
        try
        {
            if (_enrollmentClose is null) _lease.Dispose();
            else
            {
                var original = _lease.SafeFileHandle;
                _enrollmentClose.Close(_lease);
                if (!original.IsClosed) throw new IOException("Original source writer close was not confirmed.");
            }
            _enrollmentLeaseReleased = true; _enrollmentOwnerReleased?.TrySetResult();
        }
        catch (Exception error)
        {
            _enrollmentReleaseError = error; _enrollmentStopLatched = true;
            _enrollmentOwnerReleased?.TrySetException(error); throw;
        }
    }

    internal sealed class RetainedEnrollmentSource : IDisposable
    {
        private readonly EmbeddedXmlDatabase _owner;
        private readonly MigrationSourceFreeze _freeze;
        private readonly Guid _token;
        private readonly FrozenMigrationCapture _capture;
        private readonly int _thread = Environment.CurrentManagedThreadId;
        private bool _armed;
        private bool _nativeValidated;
        private bool _inspectionFaulted;
        private bool _disposeAttempted;
        private bool _released;
        private bool _releaseUnknown;
        private RetainedEnrollmentSource(EmbeddedXmlDatabase owner, MigrationSourceFreeze freeze, Guid token, FrozenMigrationCapture capture)
        { _owner = owner; _freeze = freeze; _token = token; _capture = capture; }

        internal static RetainedEnrollmentSource Acquire(EmbeddedXmlDatabase owner, MigrationSourceFreeze freeze, Guid token,
            FrozenMigrationCapture capture, IEnrollmentSourceLeaseClose close)
        {
            ArgumentNullException.ThrowIfNull(owner); ArgumentNullException.ThrowIfNull(freeze);
            ArgumentNullException.ThrowIfNull(capture); ArgumentNullException.ThrowIfNull(close); ApplicationAuthorityFileIdentity.RequirePlatform();
            lock (owner._gate)
            {
                owner.ThrowIfUnavailable();
                if (owner._enrollmentSource is not null || owner._enrollmentStopLatched || owner._cutoverFreeze != token || token == Guid.Empty)
                    throw new InvalidOperationException("Source cannot register this retained child.");
                freeze.ClaimRetention(owner, token, capture);
                var child = new RetainedEnrollmentSource(owner, freeze, token, capture);
                owner._enrollmentClose = close; owner._enrollmentSource = child; return child;
            }
        }
        internal EnrollmentSourceRetentionState State
        {
            get
            {
                lock (_owner._gate) return _releaseUnknown ? EnrollmentSourceRetentionState.ReleaseUnknown : _released ? EnrollmentSourceRetentionState.Released :
                _inspectionFaulted ? EnrollmentSourceRetentionState.Faulted : _armed ? EnrollmentSourceRetentionState.Armed : EnrollmentSourceRetentionState.Pending;
            }
        }
        internal void Arm()
        {
            CheckThread();
            lock (_owner._gate) ArmCore();
        }
        internal bool IsSourceGateEntered => Monitor.IsEntered(_owner._gate);
        internal static bool IsOwnerGateEntered(EmbeddedXmlDatabase owner) => Monitor.IsEntered(owner._gate);
        internal bool TryArm()
        {
            CheckThread();
            if (!Monitor.TryEnter(_owner._gate)) return false;
            try { ArmCore(); return true; } finally { Monitor.Exit(_owner._gate); }
        }
        private void ArmCore()
        {
            RequireRegistered(); _owner.ThrowIfUnavailable();
            _freeze.RequireRetentionBinding(_owner, _token, _capture, false);
            if (_armed || !_nativeValidated) throw new InvalidOperationException("Arming requires a once-checked native source identity and can occur only once.");
            _armed = true; _owner._enrollmentStopLatched = true;
        }
        internal RetainedEnrollmentSourceState InspectState()
        {
            CheckThread();
            lock (_owner._gate)
            {
                RequireRegistered();
                if (!_armed) _owner.ThrowIfUnavailable();
                _freeze.RequireRetentionBinding(_owner, _token, _capture, _armed);
                if (_owner._faulted || _armed && !_owner._enrollmentStopLatched) throw new InvalidOperationException("Retained source is unavailable or no longer stopped.");
                try
                {
                    var root = ApplicationAuthorityFileIdentity.PathIdentity(_owner._root, true);
                    var admission = ApplicationAuthorityFileIdentity.HandleIdentity(_owner._lease);
                    if (_owner._lease.Length != 0 || ApplicationAuthorityFileIdentity.PathIdentity(Path.Combine(_owner._transactions, "writer.lock"), false) != admission)
                        throw new InvalidDataException("Source path no longer names the original empty writer handle.");
                    _nativeValidated = true;
                    return new(new(_owner._root, _owner._documentId, _owner._sequence, (byte[])_owner._manifestHash.Clone()), root, admission);
                }
                catch { _inspectionFaulted = true; _owner._enrollmentStopLatched = true; throw; }
            }
        }
        private void CheckThread()
        { if (_thread != Environment.CurrentManagedThreadId) throw new InvalidOperationException("Source enrollment retention is caller-thread confined."); }
        private void RequireRegistered()
        {
            if (_disposeAttempted || _inspectionFaulted || !ReferenceEquals(_owner._enrollmentSource, this) || _owner._cutoverFreeze != _token)
                throw new InvalidOperationException("Retained child is released, faulted or foreign.");
        }
        /// <summary>Releases the actual source child once; closing owners release their original stream only after this drain.</summary>
        public void Dispose()
        {
            CheckThread();
            lock (_owner._gate)
            {
                if (_disposeAttempted) return;
                RequireRegisteredForRelease(); _disposeAttempted = true;
                try
                {
                    if (_owner._disposed) _owner.CloseEnrollmentLease();
                    if (_freeze.IsDisposed && _owner._cutoverFreeze == _token) _owner._cutoverFreeze = Guid.Empty;
                    _owner._enrollmentSource = null; _released = true;
                }
                catch { _releaseUnknown = true; throw; }
            }
        }
        private void RequireRegisteredForRelease()
        {
            if (!ReferenceEquals(_owner._enrollmentSource, this)) throw new InvalidOperationException("Foreign retained child cannot release source ownership.");
        }
    }
}
