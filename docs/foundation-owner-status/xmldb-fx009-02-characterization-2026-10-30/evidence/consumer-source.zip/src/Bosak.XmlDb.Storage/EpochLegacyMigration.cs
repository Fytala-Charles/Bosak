// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Converts verified legacy history into a fresh epoch and atomically publishes provenance.
// SPECIAL NOTES        : Internal conversion only; no live source recovery, public migration API, routing or retirement.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 28-10-2026     | Accept a claimed pinned attempt without changing unplanned identity allocation
// ===========================================================================================================================================================

using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

internal enum EpochMigrationStage { SourceVerified, Rebound, DestinationVerified, RuntimeReady, OriginFlushed, BundleVerified, Published }
internal sealed record EpochMigrationResult(Guid MigrationId, Guid BackupId, EpochIdentity Destination, ulong CommitSequence, string StorePath);

internal static class EpochLegacyMigration
{
    internal static EpochMigrationResult Convert(string backup, string destination, ITransactionStorage? storage = null,
        Action<EpochMigrationStage>? checkpoint = null, EpochAttemptExecution? execution = null)
    {
        storage ??= new LocalTransactionStorage();
        execution?.Enter(EpochPublicationKind.LegacyMigration, backup, destination, storage.Durability);
        destination = BackupStorage.Destination(backup, destination); backup = Path.GetFullPath(backup);
        var inventoryBytes = BinaryEnvelope.ReadFile(Path.Combine(backup, "inventory.bin"));
        execution?.ValidateInput(inventoryBytes);
        var source = LegacyMigrationVerifier.Verify(backup, destination, storage, expectedInventorySha256: execution?.Intent.InventorySha256);
        if (!BackupCodec.Encode(source).AsSpan().SequenceEqual(inventoryBytes)) throw new InvalidDataException("Legacy inventory changed during conversion verification.");
        checkpoint?.Invoke(EpochMigrationStage.SourceVerified);
        if (execution is not null) execution.ValidateInput(BinaryEnvelope.ReadFile(Path.Combine(backup, "inventory.bin")));
        var identity = new EpochIdentity(Fresh(), Fresh(), source.Identity.DocumentId); var migrationId = execution?.Intent.AttemptId ?? Fresh();
        var workspace = EpochBackupStorage.Workspace(destination, storage); var bundle = Path.Combine(workspace, "bundle"); var root = Path.Combine(bundle, "store");
        var data = Path.Combine(backup, "data"); var files = source.Files.ToDictionary(file => file.Path, StringComparer.Ordinal);
        var expected = Transform(data, root, source, identity, storage);
        checkpoint?.Invoke(EpochMigrationStage.Rebound);
        EpochBackupStorage.VerifyCopies(root, workspace, expected, storage);
        checkpoint?.Invoke(EpochMigrationStage.DestinationVerified);
        EpochBackupRestore.InitializeRuntime(root, expected, storage); EpochBackupRestore.ValidateRuntime(root, expected, storage);
        checkpoint?.Invoke(EpochMigrationStage.RuntimeReady);
        var sourceFormat = EpochBackupRestore.ReadBound(data, files["FORMAT"]);
        var sourceWal = source.Identity.CommitSequence == 0 ? new byte[32] : files[".transactions/wal/" + EpochAuthorityCodec.WalFileName(source.Identity.CommitSequence)].Hash;
        var origin = new EpochMigrationOrigin(migrationId, source.Identity.BackupId, SHA256.HashData(inventoryBytes), SHA256.HashData(sourceFormat), identity,
            source.Identity.CommitSequence, expected.Source.FormatHash, source.BaseHash, source.HeadHash, sourceWal, expected.HeadWalHash);
        TransactionCodec.WriteFlushed(Path.Combine(bundle, "migration.bin"), EpochMigrationCodec.Encode(origin), storage);
        checkpoint?.Invoke(EpochMigrationStage.OriginFlushed);
        ValidateBundle(bundle, backup, inventoryBytes, source, expected, origin, storage);
        LegacyMigrationVerifier.ReadArtifact(backup);
        if (!BinaryEnvelope.ReadFile(Path.Combine(backup, "inventory.bin")).AsSpan().SequenceEqual(inventoryBytes))
            throw new InvalidDataException("Legacy artifact changed before publication.");
        checkpoint?.Invoke(EpochMigrationStage.BundleVerified);
        // All private writer/admission/snapshot handles are closed before the directory moves.
        TransactionCodec.PublishGeneration(bundle, destination, storage);
        checkpoint?.Invoke(EpochMigrationStage.Published);
        EpochBackupStorage.RemoveWorkspace(workspace, storage);
        return new(migrationId, source.Identity.BackupId, identity, source.Identity.CommitSequence, Path.Combine(destination, "store"));
    }

    private static EpochBackupInventory Transform(string data, string root, BackupInventory source, EpochIdentity identity, ITransactionStorage storage)
    {
        var files = source.Files.ToDictionary(file => file.Path, StringComparer.Ordinal);
        var copied = BackupStorage.Copy(data, root, source.Files.Where(file => EpochBackupRestore.IsDocumentData(file.Path)).Select(file => file.Path), storage);
        foreach (var file in copied)
            if (file.Length != files[file.Path].Length || !Same(file.Hash, files[file.Path].Hash)) throw new InvalidDataException("Legacy document data changed during conversion.");
        var format = EpochCodec.EncodeProfile(identity, EpochProfile.ScalarWal); var binding = EpochAuthorityBinding.Create(format, source.BaseHash);
        Write("FORMAT", format); Write("EPOCH", EpochCodec.EncodeBinding("BXEP", identity, format));
        Write("BASE", EpochAuthorityCodec.EncodeBase(new(binding))); Write(".transactions/CONTROL", EpochAuthorityCodec.EncodeControl(EpochAuthorityCodec.CreateControl(binding)));
        var prior = new byte[32];
        for (ulong sequence = 1; sequence <= source.Identity.CommitSequence; sequence++)
        {
            var name = ".transactions/wal/" + EpochAuthorityCodec.WalFileName(sequence); var original = ReadWal(data, files[name]);
            var bytes = EpochAuthorityCodec.EncodeWal(Map(original, binding, prior)); Write(name, bytes); prior = SHA256.HashData(bytes);
            var prefix = ".transactions/generations/" + EpochAuthorityCodec.GenerationName(sequence) + "/";
            Write(prefix + "FORMAT", format);
            Write(prefix + "GENERATION", EpochAuthorityCodec.EncodeGeneration(new(binding, sequence, original.PreviousManifestHash, original.ManifestHash, prior)));
        }
        Write(".transactions/CURRENT", EpochAuthorityCodec.EncodeCurrent(new(binding, source.Identity.CommitSequence, source.HeadHash, prior)));
        var names = EpochBackupStorage.FileSet(root, identity.DocumentId, source.Identity.CommitSequence);
        var entries = names.Select(name => { var bytes = BinaryEnvelope.ReadFile(Path.Combine(root, name)); return new BackupEntry(name, bytes.Length, SHA256.HashData(bytes)); }).ToArray();
        var expected = new EpochBackupInventory(source.Identity.BackupId, binding, source.Identity.CommitSequence, source.HeadHash, prior, entries);
        EpochBackupStorage.ValidateData(root, expected);
        // Re-read both sides and enforce exact source-to-destination transformation, not just internal consistency.
        prior = new byte[32];
        for (ulong sequence = 1; sequence <= source.Identity.CommitSequence; sequence++)
        {
            var name = ".transactions/wal/" + EpochAuthorityCodec.WalFileName(sequence); var original = ReadWal(data, files[name]);
            var bytes = BinaryEnvelope.ReadFile(Path.Combine(root, name));
            if (!bytes.AsSpan().SequenceEqual(EpochAuthorityCodec.EncodeWal(Map(original, binding, prior)))) throw new InvalidDataException("Converted WAL differs from its legacy logical operation.");
            prior = SHA256.HashData(bytes);
        }
        var byPath = entries.ToDictionary(file => file.Path, StringComparer.Ordinal);
        foreach (var file in source.Files.Where(file => EpochBackupRestore.IsDocumentData(file.Path)))
            if (!byPath.TryGetValue(file.Path, out var actual) || actual.Length != file.Length || !Same(actual.Hash, file.Hash))
                throw new InvalidDataException("Converted document bytes differ from legacy history.");
        return expected;
        void Write(string name, byte[] bytes)
        {
            var path = Path.Combine(root, name); TransactionCodec.EnsureDirectory(Path.GetDirectoryName(path)!, storage);
            TransactionCodec.WriteFlushed(path, bytes, storage);
        }
    }

    private static WalRecord ReadWal(string data, BackupEntry file)
    {
        var bytes = EpochBackupRestore.ReadBound(data, file);
        var record = TransactionCodec.ReadWal(Path.Combine(data, file.Path)) ?? throw new InvalidDataException("Partial legacy WAL during conversion.");
        if (!bytes.AsSpan().SequenceEqual(TransactionCodec.EncodeWal(record))) throw new InvalidDataException("Legacy WAL changed or is noncanonical.");
        return record;
    }
    private static EpochWalRecord Map(WalRecord source, EpochAuthorityBinding destination, byte[] prior) =>
        new(destination, source.Sequence, source.TransactionId, source.NodeId, source.Value, source.PreviousManifestHash, source.ManifestHash, prior);

    private static void ValidateBundle(string bundle, string backup, byte[] inventoryBytes, BackupInventory source,
        EpochBackupInventory expected, EpochMigrationOrigin origin, ITransactionStorage storage)
    {
        var entries = Directory.GetFileSystemEntries(bundle); foreach (var entry in entries) BinaryEnvelope.RejectLinks(entry);
        if (entries.Length != 2 || !entries.Select(Path.GetFileName).Order(StringComparer.Ordinal).SequenceEqual(new[] { "migration.bin", "store" }) ||
            !File.Exists(Path.Combine(bundle, "migration.bin")) || !Directory.Exists(Path.Combine(bundle, "store"))) throw new InvalidDataException("Invalid migration bundle shape.");
        var bytes = BinaryEnvelope.ReadFile(Path.Combine(bundle, "migration.bin"));
        if (!bytes.AsSpan().SequenceEqual(EpochMigrationCodec.Encode(origin))) throw new InvalidDataException("Migration provenance differs from this operation.");
        var root = Path.Combine(bundle, "store"); var data = Path.Combine(backup, "data"); var files = source.Files.ToDictionary(file => file.Path, StringComparer.Ordinal);
        EpochMigrationCodec.ValidateHeaders(bytes, inventoryBytes, BinaryEnvelope.ReadFile(Path.Combine(backup, "COMPLETE")),
            EpochBackupRestore.ReadBound(data, files["FORMAT"]), EpochBackupRestore.ReadBound(data, files[".transactions/CONTROL"]),
            source.Identity.CommitSequence == 0 ? null : EpochBackupRestore.ReadBound(data, files[".transactions/CURRENT"]),
            BinaryEnvelope.ReadFile(Path.Combine(root, "FORMAT")), BinaryEnvelope.ReadFile(Path.Combine(root, ".transactions", "CURRENT")));
        EpochBackupRestore.ValidateRuntime(root, expected, storage);
    }
    private static bool Same(byte[] a, byte[] b) => a.AsSpan().SequenceEqual(b);
    private static Guid Fresh() { Guid value; do { value = Guid.NewGuid(); } while (value == Guid.Empty); return value; }
}
