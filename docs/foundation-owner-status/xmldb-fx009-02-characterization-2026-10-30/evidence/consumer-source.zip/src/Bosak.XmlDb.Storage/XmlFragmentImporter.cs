// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Imports XML into an immutable fragment store.
// SPECIAL NOTES        : Immutable M1 format; no transaction or crash recovery guarantee.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Security.Cryptography;
using System.Xml;
using System.Xml.Linq;
using Bosak.XmlDb.Core;

namespace Bosak.XmlDb.Storage;

/// <summary>Imports XML into an immutable fragment store.</summary>
public static class XmlFragmentImporter
{
    /// <summary>Parses XML once and publishes a new immutable store directory.</summary>
    /// <param name="xml">XML input; the caller retains ownership.</param>
    /// <param name="databaseRoot">New store path; an existing path is never overwritten.</param>
    /// <param name="documentId">Nonzero logical document identity.</param>
    /// <param name="linesPerFragment">Number of direct SalesOrderLine children per group.</param>
    /// <param name="documentUri">Absolute document URI, or empty.</param>
    /// <exception cref="InvalidDataException">The input exceeds format limits.</exception>
    /// <exception cref="IOException">The destination already exists.</exception>
    public static void Import(Stream xml, string databaseRoot, ulong documentId = 1,
        int linesPerFragment = 16, string documentUri = "")
    {
        ArgumentNullException.ThrowIfNull(xml);
        ArgumentException.ThrowIfNullOrWhiteSpace(databaseRoot);
        ArgumentOutOfRangeException.ThrowIfZero(documentId);
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(linesPerFragment);
        if (documentUri.Length != 0 && !Uri.TryCreate(documentUri, UriKind.Absolute, out _))
            throw new ArgumentException("Document URI must be absolute.", nameof(documentUri));
        var root = Path.GetFullPath(databaseRoot);
        if (Directory.Exists(root) || File.Exists(root))
            throw new IOException("Immutable store destination already exists.");
        var parent = Path.GetDirectoryName(root) ?? throw new ArgumentException("Invalid store root.", nameof(databaseRoot));
        Directory.CreateDirectory(parent);
        BinaryEnvelope.RejectLinks(parent);
        using var reader = XmlReader.Create(xml, new XmlReaderSettings
        {
            DtdProcessing = DtdProcessing.Prohibit,
            XmlResolver = null,
            MaxCharactersInDocument = 16 * 1024 * 1024,
            CloseInput = false,
        }, documentUri);
        var document = XDocument.Load(reader, LoadOptions.PreserveWhitespace);
        foreach (var whitespace in document.Nodes().OfType<XText>().ToArray()) whitespace.Remove();
        var builder = new Builder(linesPerFragment);
        builder.Visit(document, 0, 1, 0, documentUri);
        var staging = Path.Combine(parent, "." + Path.GetFileName(root) + ".staging-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(staging);
        try
        {
            var documents = Path.Combine(staging, "documents", documentId.ToString(System.Globalization.CultureInfo.InvariantCulture));
            var fragments = Path.Combine(staging, "fragments");
            Directory.CreateDirectory(documents);
            Directory.CreateDirectory(fragments);
            File.WriteAllBytes(Path.Combine(staging, "FORMAT"), BinaryEnvelope.Encode("BXDB", writer => writer.Write((byte)0)));
            var directory = StoreCodec.WriteDirectory(builder.Nodes);
            File.WriteAllBytes(Path.Combine(documents, "directory.bin"), directory);
            var entries = builder.Payloads.Select((payload, index) =>
            {
                var id = (ulong)index + 1;
                var bytes = BinaryEnvelope.Encode("BXFG", writer =>
                {
                    writer.Write(id);
                    writer.Write(documentId);
                    writer.Write((byte)0);
                    writer.Write(checked((int)payload.Length));
                    writer.Write(payload.ToArray());
                });
                File.WriteAllBytes(Path.Combine(fragments, id.ToString(System.Globalization.CultureInfo.InvariantCulture) + ".bin"), bytes);
                return new FragmentEntry(id, (int)payload.Length, SHA256.HashData(bytes));
            }).ToArray();
            File.WriteAllBytes(Path.Combine(documents, "manifest.bin"),
                StoreCodec.WriteManifest(new(documentId, documentUri, SHA256.HashData(directory), entries)));
            Directory.Move(staging, root);
        }
        finally
        {
            foreach (var payload in builder.Payloads) payload.Dispose();
            // Only the unique staging directory created above is cleaned up.
            if (Directory.Exists(staging)) Directory.Delete(staging, true);
        }
    }

    private sealed class Builder(int groupSize)
    {
        internal List<StorageNode> Nodes { get; } = [];
        internal List<MemoryStream> Payloads { get; } = [new()];
        private int _lineCount;

        internal ulong Visit(XObject source, ulong parent, ulong fragment, int depth, string baseUri)
        {
            if (depth > 256 || Nodes.Count >= BinaryEnvelope.MaximumNodes)
                throw new InvalidDataException("XML depth or node limit exceeded.");
            var id = (ulong)Nodes.Count + 1;
            var kind = source switch
            {
                XDocument => StorageNodeKind.Document,
                XElement => StorageNodeKind.Element,
                XAttribute => StorageNodeKind.Attribute,
                XText => StorageNodeKind.Text,
                XComment => StorageNodeKind.Comment,
                XProcessingInstruction => StorageNodeKind.ProcessingInstruction,
                _ => throw new InvalidDataException("Unsupported XML node kind."),
            };
            var element = source as XElement;
            var attribute = source as XAttribute;
            var name = element?.Name ?? attribute?.Name;
            var local = name?.LocalName ?? (source as XProcessingInstruction)?.Target ?? "";
            var ns = name?.NamespaceName ?? "";
            var owner = element ?? attribute?.Parent;
            var prefix = ns.Length == 0 ? "" : owner?.GetPrefixOfNamespace(ns) ?? "";
            if (element?.Attribute(XNamespace.Xml + "base") is { } xmlBase)
            {
                if (Uri.TryCreate(xmlBase.Value, UriKind.Absolute, out var absolute)) baseUri = absolute.AbsoluteUri;
                else if (Uri.TryCreate(baseUri, UriKind.Absolute, out var inherited)) baseUri = new Uri(inherited, xmlBase.Value).AbsoluteUri;
                else baseUri = xmlBase.Value;
            }
            var value = source switch
            {
                XAttribute a => a.Value,
                XText text => text.Value,
                XComment comment => comment.Value,
                XProcessingInstruction pi => pi.Data,
                _ => null,
            };
            var location = Value(fragment, value);
            var children = new List<ulong>();
            var attributes = new List<ulong>();
            var namespaces = new List<ulong>();
            Nodes.Add(new(id, parent, kind, local, ns, prefix, baseUri,
                location.Fragment, location.Offset, location.Length,
                children.AsReadOnly(), attributes.AsReadOnly(), namespaces.AsReadOnly()));
            if (element is not null)
            {
                var bindings = new Dictionary<string, string> { ["xml"] = XNamespace.Xml.NamespaceName };
                foreach (var ancestor in element.AncestorsAndSelf().Reverse())
                    foreach (var declaration in ancestor.Attributes().Where(a => a.IsNamespaceDeclaration))
                        bindings[declaration.Name.LocalName == "xmlns" ? "" : declaration.Name.LocalName] = declaration.Value;
                foreach (var binding in bindings.Where(pair => pair.Value.Length != 0))
                {
                    if (Nodes.Count >= BinaryEnvelope.MaximumNodes) throw new InvalidDataException("Node limit exceeded.");
                    var nsId = (ulong)Nodes.Count + 1;
                    var pointer = Value(fragment, binding.Value);
                    namespaces.Add(nsId);
                    Nodes.Add(new(nsId, id, StorageNodeKind.Namespace, binding.Key, "", "", baseUri,
                        pointer.Fragment, pointer.Offset, pointer.Length, Array.Empty<ulong>(), Array.Empty<ulong>(), Array.Empty<ulong>()));
                }
                foreach (var attr in element.Attributes().Where(a => !a.IsNamespaceDeclaration))
                    attributes.Add(Visit(attr, id, fragment, depth + 1, baseUri));
            }
            if (source is XContainer container)
            {
                foreach (var child in container.Nodes())
                {
                    var childFragment = fragment;
                    if (source is XElement salesOrder && salesOrder.Document?.Root == salesOrder &&
                        child is XElement lineElement && lineElement.Name.LocalName == "SalesOrderLine")
                    {
                        if (_lineCount % groupSize == 0) Payloads.Add(new());
                        childFragment = (ulong)Payloads.Count;
                        _lineCount++;
                    }
                    children.Add(Visit(child, id, childFragment, depth + 1, baseUri));
                }
            }
            return id;
        }

        private (ulong Fragment, int Offset, int Length) Value(ulong fragment, string? value)
        {
            if (value is null) return (0, 0, 0);
            var bytes = BinaryEnvelope.Utf8.GetBytes(value);
            if (bytes.Length > BinaryEnvelope.MaximumStringBytes)
                throw new InvalidDataException("Node value exceeds limit.");
            var payload = Payloads[checked((int)fragment - 1)];
            if (payload.Length + bytes.Length > BinaryEnvelope.MaximumFileBytes - 65)
                throw new InvalidDataException("Fragment exceeds size limit.");
            var offset = (int)payload.Length;
            payload.Write(bytes);
            return (fragment, offset, bytes.Length);
        }
    }
}


