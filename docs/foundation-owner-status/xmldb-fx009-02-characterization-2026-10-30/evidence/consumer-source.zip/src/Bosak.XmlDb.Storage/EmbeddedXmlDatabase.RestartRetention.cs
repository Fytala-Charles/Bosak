// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 30 October 2026
// PURPOSE              : Retains actual stopped legacy ownership for restart-only source inspection.
// SPECIAL NOTES        : Internal source child only; no capture association, paired observation or write authority.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 30-10-2026     | Add nonblocking current-owner check for paired final validation                           |
//                      | Charles Korthout | 0.1   | 30-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal enum RestartSourceState { Retained, Faulted, Released, ReleaseUnknown }
internal sealed record RestartSourceInspection(LegacyCutoverState Source, ApplicationFileIdentity RootIdentity,
    ApplicationFileIdentity AdmissionIdentity, bool OwnerClosing);

/// <summary>Retains actual stopped legacy ownership for restart-only source inspection.</summary>
public sealed partial class EmbeddedXmlDatabase
{
    private RetainedRestartSource? _restartSource;

    internal sealed class RetainedRestartSource : IDisposable
    {
        private readonly EmbeddedXmlDatabase _owner;
        private readonly int _thread = Environment.CurrentManagedThreadId;
        private bool _faulted;
        private bool _disposeAttempted;
        private bool _released;
        private bool _releaseUnknown;
        private RetainedRestartSource(EmbeddedXmlDatabase owner) => _owner = owner;

        internal static RetainedRestartSource Acquire(EmbeddedXmlDatabase owner, bool controlledStoppedScope) =>
            AcquireCore(owner, controlledStoppedScope, null);

        // Qualification-only closer is bound once to the actual owner's original stream.
        internal static RetainedRestartSource AcquireCore(EmbeddedXmlDatabase owner, bool controlledStoppedScope, IEnrollmentSourceLeaseClose? close)
        {
            ArgumentNullException.ThrowIfNull(owner);
            if (!controlledStoppedScope) throw new InvalidOperationException("Fresh controlled stopped-scope attestation is required.");
            if (Monitor.IsEntered(owner._gate)) throw new InvalidOperationException("Restart admission cannot run under a caller-held source gate.");
            ApplicationAuthorityFileIdentity.RequirePlatform();
            lock (owner._gate)
            {
                owner.ThrowIfUnavailable();
                if (owner._enrollmentStopLatched || owner._enrollmentSource is not null || owner._restartSource is not null || owner._cutoverFreeze != Guid.Empty)
                    throw new InvalidOperationException("Restart retention requires a fresh unclaimed source owner.");
                var child = new RetainedRestartSource(owner);
                owner._enrollmentClose = close;
                owner._restartSource = child;
                owner._enrollmentStopLatched = true;
                return child;
            }
        }

        internal RestartSourceState State
        {
            get { lock (_owner._gate) return _releaseUnknown ? RestartSourceState.ReleaseUnknown : _released ? RestartSourceState.Released : _faulted ? RestartSourceState.Faulted : RestartSourceState.Retained; }
        }
        internal bool IsSourceGateEntered => Monitor.IsEntered(_owner._gate);
        internal bool BelongsTo(EmbeddedXmlDatabase owner) => ReferenceEquals(_owner, owner);

        internal void RequireCurrent(EmbeddedXmlDatabase expected)
        {
            CheckThread();
            lock (_owner._gate)
            {
                RequireRegistered();
                if (!ReferenceEquals(expected, _owner)) throw new InvalidOperationException("Restart source owner is foreign.");
                ObjectDisposedException.ThrowIf(_owner._disposed, _owner);
            }
        }

        internal bool TryRequireCurrent(EmbeddedXmlDatabase expected)
        {
            CheckThread();
            if (!Monitor.TryEnter(_owner._gate)) return false;
            try { RequireCurrent(expected); return true; }
            finally { Monitor.Exit(_owner._gate); }
        }

        internal RestartSourceInspection InspectState() => InspectStateCore(null);
        internal RestartSourceInspection InspectStateCore(Action? beforeNativeCheck)
        {
            CheckThread();
            if (Monitor.IsEntered(_owner._gate)) throw new InvalidOperationException("Native restart inspection must run outside source gates.");
            LegacyCutoverState state;
            lock (_owner._gate)
            {
                RequireRegistered();
                state = new(_owner._root, _owner._documentId, _owner._sequence, (byte[])_owner._manifestHash.Clone());
            }
            try
            {
                beforeNativeCheck?.Invoke(); // Test-only observation outside the lifetime gate.
                if (Monitor.IsEntered(_owner._gate)) throw new InvalidOperationException("Inspection probe entered the source gate.");
                var root = ApplicationAuthorityFileIdentity.PathIdentity(state.Root, true);
                var admission = ApplicationAuthorityFileIdentity.HandleIdentity(_owner._lease);
                if (_owner._lease.Length != 0 || ApplicationAuthorityFileIdentity.PathIdentity(Path.Combine(_owner._transactions, "writer.lock"), false) != admission)
                    throw new InvalidDataException("Restart source path no longer names its original empty writer handle.");
                lock (_owner._gate)
                {
                    RequireRegistered();
                    if (_owner._sequence != state.Sequence || _owner._documentId != state.DocumentId || !_owner._manifestHash.AsSpan().SequenceEqual(state.ManifestHash))
                        throw new InvalidDataException("Stopped source state changed during inspection.");
                    return new(state, root, admission, _owner._disposed);
                }
            }
            catch { lock (_owner._gate) _faulted = true; throw; }
        }

        private void CheckThread()
        { if (_thread != Environment.CurrentManagedThreadId) throw new InvalidOperationException("Restart source retention is caller-thread confined."); }
        private void RequireRegistered()
        {
            if (_disposeAttempted || _faulted || _owner._faulted || !_owner._enrollmentStopLatched || !ReferenceEquals(_owner._restartSource, this))
                throw new InvalidOperationException("Restart child is released, faulted or foreign.");
        }
        /// <summary>Drains the actual child once without clearing the original owner's permanent stop.</summary>
        public void Dispose()
        {
            CheckThread();
            lock (_owner._gate)
            {
                if (_disposeAttempted) return;
                if (!ReferenceEquals(_owner._restartSource, this)) throw new InvalidOperationException("Foreign restart child cannot release source ownership.");
                _disposeAttempted = true;
                try
                {
                    if (_owner._disposed) _owner.CloseEnrollmentLease();
                    _owner._restartSource = null; _released = true;
                }
                catch { _releaseUnknown = true; throw; }
            }
        }
    }
}
