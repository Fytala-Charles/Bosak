// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Encodes bounded application-authority metadata and frame envelopes.
// SPECIAL NOTES        : Pure internal codec; checksums and decoded state grant no ownership, freshness or write authority.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Buffers.Binary;
using System.Collections.Immutable;
using System.Diagnostics.CodeAnalysis;
using System.Security.Cryptography;
using System.Text;

namespace Bosak.XmlDb.Storage;

internal sealed record ApplicationAuthorityConfiguration(Guid AuthorityId, Guid AdministrativeJournalId, string Deployment,
    string ResourceScope, string AdministrativeRootKey, string AuthorityRootKey, DurabilityMode Durability = DurabilityMode.ProcessCrash);
internal sealed record ApplicationAuthorityMetadata(ApplicationAuthorityConfiguration Configuration, string ScopeDigest, string Digest)
{ internal bool WritersMustRemainStopped => true; }
internal sealed record ApplicationAuthorityPublication(EpochPublicationKind Kind, Guid AttemptId, string ArtifactDigest,
    ulong AdministrativeSequence, string AdministrativeHeadDigest, string ArtifactRootKey, string BundleRootKey, Guid BackupId);
internal abstract record ApplicationAuthorityData;
internal sealed record ApplicationEnroll(PilotRootBinding Source) : ApplicationAuthorityData;
internal sealed record ApplicationRegister(PilotRootBinding Candidate, ApplicationAuthorityPublication Publication) : ApplicationAuthorityData;
internal sealed record ApplicationSelect(ulong PreviousRevision, PilotBranch PreviousBranch) : ApplicationAuthorityData;
internal sealed record ApplicationAccept(Guid WorkId, string IntentDigest, string RootDigest) : ApplicationAuthorityData;
internal sealed record ApplicationWorkReference(Guid WorkId, string IntentDigest, ulong AcceptanceSequence);
internal sealed record ApplicationOutcome(ApplicationWorkReference Work, PilotWorkOutcome Outcome) : ApplicationAuthorityData;
internal enum ApplicationObservationKind { Selection, WorkCommitted, WorkNoEffect, WorkUnknown }
internal sealed record ApplicationObserve(ApplicationObservationKind Kind, ApplicationWorkReference? Work,
    ulong ObservedRevision, PilotBranch ObservedBranch) : ApplicationAuthorityData;
internal sealed record ApplicationTransfer(Guid PreviousOwner, ulong PreviousGeneration) : ApplicationAuthorityData;
internal sealed record ApplicationAuthorityEntry(Guid OwnerSession, ulong OwnerGeneration, Guid BaselineId,
    ulong SelectionRevision, PilotBranch Selected, string EvidenceDigest, ApplicationAuthorityData Data);
internal sealed record ApplicationAuthorityFrame(Guid AuthorityId, ulong Sequence, string PreviousDigest, string MetadataDigest,
    ApplicationAuthorityEntry Entry, string Digest)
{ internal bool WritersMustRemainStopped => true; }
internal sealed record ApplicationAuthorityWork(ApplicationWorkReference Reference, PilotBranch Branch, PilotRootBinding Target,
    ulong SelectionRevision, Guid AcceptingOwner, ulong AcceptingGeneration, PilotWorkOutcome Outcome, bool OutcomeRecorded, bool RequiresObservation);
internal sealed record ApplicationAuthorityHistory(ImmutableArray<ApplicationAuthorityFrame> Frames, PilotRootBinding? Source,
    PilotRootBinding? Candidate, ApplicationAuthorityPublication? Publication, ImmutableArray<ApplicationAuthorityWork> Work)
{
    internal bool WritersMustRemainStopped => true;
    internal ulong SourceAccepted => (ulong)Work.Count(w => w.Branch == PilotBranch.Source);
    internal ulong CandidateAccepted => (ulong)Work.Count(w => w.Branch == PilotBranch.Candidate);
}

/// <summary>Encodes bounded application-authority metadata and frame envelopes.</summary>
internal static partial class ApplicationAuthorityCodec
{
    internal const int MaximumPayloadBytes = 65_536;
    internal const int MaximumJournalBytes = 67_108_864;
    internal const int MaximumFrames = 65_536;
    internal const int MaximumWork = 1_024;
    internal const int MaximumStringBytes = 4_096;
    private static readonly UTF8Encoding Utf8 = new(false, true);
    private static readonly string ZeroHash = new('0', 64);

    internal static byte[] EncodeMetadata(ApplicationAuthorityConfiguration configuration)
    {
        Require(configuration is not null && configuration.Durability == DurabilityMode.ProcessCrash);
        var scope = Tlv((1, Text(configuration.Deployment)), (2, Text(configuration.ResourceScope)),
            (3, Text(configuration.AdministrativeRootKey)), (4, Text(configuration.AuthorityRootKey)));
        var bytes = new byte[112]; "BXAM0001"u8.CopyTo(bytes);
        GuidBytes(configuration.AuthorityId).CopyTo(bytes, 8); GuidBytes(configuration.AdministrativeJournalId).CopyTo(bytes, 24);
        SHA256.HashData(scope, bytes.AsSpan(40, 32)); BinaryPrimitives.WriteUInt16LittleEndian(bytes.AsSpan(72), 1);
        SHA256.HashData(bytes.AsSpan(0, 80), bytes.AsSpan(80)); return bytes;
    }

    internal static ApplicationAuthorityMetadata DecodeMetadata(ReadOnlySpan<byte> bytes, ApplicationAuthorityConfiguration expected)
    {
        Require(bytes.Length == 112 && bytes.SequenceEqual(EncodeMetadata(expected)));
        return new(expected, Hex(bytes.Slice(40, 32)), Hex(bytes[80..]));
    }

    private static void ValidateMetadata(ApplicationAuthorityMetadata metadata)
    {
        Require(metadata is not null);
        var bytes = EncodeMetadata(metadata.Configuration);
        Require(metadata.ScopeDigest == Hex(bytes.AsSpan(40, 32)) && metadata.Digest == Hex(bytes.AsSpan(80)));
    }

    internal static byte[] EncodeFrame(ApplicationAuthorityMetadata metadata, ulong sequence, string previousDigest, ApplicationAuthorityEntry entry)
    {
        ValidateMetadata(metadata); Require(sequence is > 0 and <= MaximumFrames);
        var previous = Hash(previousDigest); Require(sequence == 1 ? previousDigest == ZeroHash : previousDigest != ZeroHash);
        var payload = EncodePayload(entry); _ = DecodePayload(payload);
        var bytes = new byte[144 + payload.Length]; "BXAJ0001"u8.CopyTo(bytes);
        BinaryPrimitives.WriteUInt16LittleEndian(bytes.AsSpan(8), 1);
        BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(12), (uint)payload.Length);
        BinaryPrimitives.WriteUInt64LittleEndian(bytes.AsSpan(16), sequence);
        GuidBytes(metadata.Configuration.AuthorityId).CopyTo(bytes, 24); previous.CopyTo(bytes, 40); Hash(metadata.Digest).CopyTo(bytes, 72);
        payload.CopyTo(bytes, 104); SHA256.HashData(bytes.AsSpan(0, 104 + payload.Length), bytes.AsSpan(104 + payload.Length, 32));
        "AJEND001"u8.CopyTo(bytes.AsSpan(136 + payload.Length)); return bytes;
    }

    internal static ApplicationAuthorityFrame DecodeFrame(ReadOnlySpan<byte> bytes, ApplicationAuthorityMetadata metadata)
    {
        ValidateMetadata(metadata); Require(bytes.Length >= 144 && bytes.Length <= MaximumPayloadBytes + 144);
        ValidateHeader(bytes[..104], metadata);
        var n = BinaryPrimitives.ReadUInt32LittleEndian(bytes[12..]); Require(n is > 0 and <= MaximumPayloadBytes && bytes.Length == 144L + n);
        var length = (int)n;
        Require(bytes[(136 + length)..].SequenceEqual("AJEND001"u8) &&
            CryptographicOperations.FixedTimeEquals(SHA256.HashData(bytes[..(104 + length)]), bytes.Slice(104 + length, 32)));
        return new(ReadGuid(bytes.Slice(24, 16)), BinaryPrimitives.ReadUInt64LittleEndian(bytes[16..]), Hex(bytes.Slice(40, 32)),
            Hex(bytes.Slice(72, 32)), DecodePayload(bytes.Slice(104, length)), Hex(bytes.Slice(104 + length, 32)));
    }

    private static void ValidateHeader(ReadOnlySpan<byte> header, ApplicationAuthorityMetadata metadata)
    {
        Require(header.Length == 104 && header[..8].SequenceEqual("BXAJ0001"u8) &&
            BinaryPrimitives.ReadUInt16LittleEndian(header[8..]) == 1 && BinaryPrimitives.ReadUInt16LittleEndian(header[10..]) == 0 &&
            ReadGuid(header.Slice(24, 16)) == metadata.Configuration.AuthorityId && Hex(header.Slice(72, 32)) == metadata.Digest);
        var sequence = BinaryPrimitives.ReadUInt64LittleEndian(header[16..]);
        Require(sequence is > 0 and <= MaximumFrames && (sequence == 1 ? Hex(header.Slice(40, 32)) == ZeroHash : Hex(header.Slice(40, 32)) != ZeroHash));
    }
    private static byte[] Tlv(params (ushort Tag, byte[]? Value)[] fields)
    {
        var size = 0; ushort prior = 0;
        foreach (var (tag, value) in fields)
        {
            Require(tag > prior); prior = tag; if (value is null) continue;
            Require(value.Length > 0 && value.Length <= MaximumPayloadBytes - 6 && size <= MaximumPayloadBytes - value.Length - 6); size += 6 + value.Length;
        }
        var bytes = new byte[size]; var cursor = 0;
        foreach (var (tag, value) in fields)
        {
            if (value is null) continue;
            BinaryPrimitives.WriteUInt16LittleEndian(bytes.AsSpan(cursor), tag); BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(cursor + 2), (uint)value.Length);
            value.CopyTo(bytes, cursor + 6); cursor += value.Length + 6;
        }
        return bytes;
    }
    private ref struct Fields(ReadOnlySpan<byte> bytes)
    {
        private ReadOnlySpan<byte> _remaining = bytes;
        internal ReadOnlySpan<byte> Take(ushort tag, bool optional = false)
        {
            if (_remaining.IsEmpty && optional) return [];
            Require(_remaining.Length >= 6); var actual = BinaryPrimitives.ReadUInt16LittleEndian(_remaining);
            if (optional && actual > tag) return [];
            Require(actual == tag); var length = BinaryPrimitives.ReadUInt32LittleEndian(_remaining[2..]);
            Require(length > 0 && length <= _remaining.Length - 6); var value = _remaining.Slice(6, (int)length); _remaining = _remaining[(6 + (int)length)..]; return value;
        }
        internal void End() => Require(_remaining.IsEmpty);
    }
    private static byte[] Text(string value)
    {
        Require(!string.IsNullOrWhiteSpace(value) && value.Length <= MaximumStringBytes && !value.Contains('\0') && !value.StartsWith('\uFEFF'));
        try { Require(Utf8.GetByteCount(value) <= MaximumStringBytes); return Utf8.GetBytes(value); }
        catch (EncoderFallbackException error) { throw new InvalidDataException("Invalid application authority UTF-8 input.", error); }
    }
    private static string ReadText(ReadOnlySpan<byte> bytes)
    {
        Require(bytes.Length is > 0 and <= MaximumStringBytes);
        try { var text = Utf8.GetString(bytes); _ = Text(text); return text; }
        catch (DecoderFallbackException error) { throw new InvalidDataException("Invalid application authority UTF-8 bytes.", error); }
    }
    private static byte[] U64(ulong value) { var bytes = new byte[8]; BinaryPrimitives.WriteUInt64LittleEndian(bytes, value); return bytes; }
    private static ulong ReadU64(ReadOnlySpan<byte> bytes) { Require(bytes.Length == 8); return BinaryPrimitives.ReadUInt64LittleEndian(bytes); }
    private static byte[] GuidBytes(Guid value) { Require(value != Guid.Empty); var bytes = new byte[16]; value.TryWriteBytes(bytes, bigEndian: true, out _); return bytes; }
    private static Guid ReadGuid(ReadOnlySpan<byte> bytes) { Require(bytes.Length == 16); var value = new Guid(bytes, bigEndian: true); Require(value != Guid.Empty); return value; }
    private static byte[] Hash(string value) { Require(value is { Length: 64 } && value.All(c => c is >= '0' and <= '9' or >= 'a' and <= 'f')); return Convert.FromHexString(value); }
    private static string Hex(ReadOnlySpan<byte> bytes) => Convert.ToHexString(bytes).ToLowerInvariant();
    private static byte ReadByte(ReadOnlySpan<byte> bytes) { Require(bytes.Length == 1); return bytes[0]; }
    private static byte[] One(byte value) => [value];
    private static void Require([DoesNotReturnIf(false)] bool valid) { if (!valid) throw new InvalidDataException("Invalid bounded application authority bytes or state."); }
}
