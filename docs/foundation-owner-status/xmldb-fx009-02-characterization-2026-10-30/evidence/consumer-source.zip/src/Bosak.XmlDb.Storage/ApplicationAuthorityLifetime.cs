// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Owns an existing application-authority root under a drained parent inspection lifetime.
// SPECIAL NOTES        : Existing inspection/provisioning plus terminal first enrollment; no application writer admission.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.7   | 30-10-2026     | Exclude generic reads after paired restart observation reservation                         |
//                      | Charles Korthout | 0.6   | 30-10-2026     | Bind role-release fault seam to actual owner lifetime                                    |
//                      | Charles Korthout | 0.5   | 30-10-2026     | Observe retained protected-path inspection without changing generic readers               |
//                      | Charles Korthout | 0.4   | 30-10-2026     | Document bounded terminal first-enrollment writer                                       |
//                      | Charles Korthout | 0.3   | 29-10-2026     | Exclude generic reads during retained enrollment mode                                    |
//                      | Charles Korthout | 0.2   | 29-10-2026     | Add separate provisioning and live initializer reservation                               |
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Collections.Immutable;
using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

internal enum ApplicationInspectionStage { Registered, OwnerOpened, MetadataOpened, HistoryRead }

/// <summary>Owns an existing application-authority root under a drained parent inspection lifetime.</summary>
internal sealed partial class ApplicationAuthorityLifetime : IDisposable
{
    private readonly object _gate = new();
    private readonly object _readGate = new();
    private readonly EmbeddedHostLifetime _parent;
    private readonly EmbeddedHostLifetime.ApplicationInspectionRegistration _registration;
    private readonly FileStream[] _roles;
    private readonly IRetainedRoleLeaseClose? _roleClose;
    private readonly ApplicationFileIdentity[] _identities;
    private readonly ApplicationFileIdentity _rootIdentity;
    private readonly ApplicationAuthorityConfiguration _configuration;
    private readonly ImmutableDictionary<string, string> _roots;
    private readonly TaskCompletionSource _released = new(TaskCreationOptions.RunContinuationsAsynchronously);
    private readonly bool _provisioned;
    private bool _initializerClaimed;
    private bool _closing;
    private bool _faulted;
    private bool _releaseAttempted;
    private bool _isReleased;
    private int _reads;
    private readonly long _length;
    private readonly string _digest;
    private static readonly string[] RoleNames = ["authority.lock", "authority.meta", "authority.log"];

    private ApplicationAuthorityLifetime(EmbeddedHostLifetime parent, EmbeddedHostLifetime.ApplicationInspectionRegistration registration,
        string root, ApplicationAuthorityConfiguration configuration, ImmutableDictionary<string, string> roots, FileStream[] roles,
        ApplicationFileIdentity[] identities, ApplicationFileIdentity rootIdentity, ApplicationAuthorityHistory history, long length, string digest, bool provisioned = false, IRetainedRoleLeaseClose? roleClose = null)
    {
        _parent = parent; _registration = registration; Root = root; _configuration = configuration; _roots = roots; _roles = roles;
        _identities = identities; _rootIdentity = rootIdentity; History = history; _length = length; _digest = digest; _provisioned = provisioned; _roleClose = roleClose;
    }
    internal string Root { get; }
    internal ApplicationAuthorityHistory History { get; }
    internal bool WritersMustRemainStopped => true;
    internal Task WhenReleased => _released.Task;
    internal bool IsReleased { get { lock (_gate) return _isReleased; } }
    internal bool IsFaulted { get { lock (_gate) return _faulted; } }
    internal int ActiveInspections { get { lock (_gate) return _reads; } }

    internal static ApplicationAuthorityLifetime OpenExisting(EmbeddedHostLifetime parent, HostJournalPosition expected,
        EmbeddedHostInspectionEvidence evidence, string root, ApplicationAuthorityConfiguration configuration,
        IReadOnlyDictionary<string, string> roots) => OpenExistingCore(parent, expected, evidence, root, configuration, roots, null);

    internal static ApplicationAuthorityLifetime OpenExistingCore(EmbeddedHostLifetime parent, HostJournalPosition expected,
        EmbeddedHostInspectionEvidence evidence, string root, ApplicationAuthorityConfiguration configuration,
        IReadOnlyDictionary<string, string> roots, Action<ApplicationInspectionStage>? checkpoint, IRetainedRoleLeaseClose? roleClose = null)
    {
        ArgumentNullException.ThrowIfNull(parent); ApplicationAuthorityFileIdentity.RequirePlatform();
        _ = ApplicationAuthorityCodec.EncodeMetadata(configuration); root = Canonical(root);
        if (configuration.AdministrativeJournalId != parent.Context.JournalId || configuration.Deployment != parent.Context.Deployment || configuration.ResourceScope != parent.Context.ResourceScope)
            throw new InvalidDataException("Authority configuration must bind the actual administrative host.");
        var inventory = FreezeRoots(roots);
        if (!inventory.TryGetValue(configuration.AdministrativeRootKey, out var administrativeRoot) || administrativeRoot != parent.Root ||
            !inventory.TryGetValue(configuration.AuthorityRootKey, out var authorityRoot) || authorityRoot != root)
            throw new InvalidDataException("Trusted root-key mapping does not bind the actual parent/authority roots.");
        var registration = parent.BeginApplicationInspection(expected, evidence);
        var handles = new List<FileStream>();
        try
        {
            checkpoint?.Invoke(ApplicationInspectionStage.Registered);
            CheckPlacement(parent.Root, root, configuration, inventory, registration.History);
            var rootIdentity = CheckNamespace(root);
            handles.Add(new(Path.Combine(root, RoleNames[0]), FileMode.Open, FileAccess.ReadWrite, FileShare.None, 1));
            if (!handles[0].CanSeek || handles[0].Length != 0) throw new InvalidDataException("Authority owner file must be empty and seekable.");
            _ = ApplicationAuthorityFileIdentity.HandleIdentity(handles[0]);
            checkpoint?.Invoke(ApplicationInspectionStage.OwnerOpened);
            handles.Add(new(Path.Combine(root, RoleNames[1]), FileMode.Open, FileAccess.ReadWrite, FileShare.Read, 1));
            if (!handles[1].CanSeek || handles[1].Length != 112) throw new InvalidDataException("Authority metadata size mismatch.");
            _ = ApplicationAuthorityFileIdentity.HandleIdentity(handles[1]);
            checkpoint?.Invoke(ApplicationInspectionStage.MetadataOpened);
            handles.Add(new(Path.Combine(root, RoleNames[2]), FileMode.Open, FileAccess.ReadWrite, FileShare.Read, 1));
            if (!handles[2].CanSeek || handles[2].Length > ApplicationAuthorityCodec.MaximumJournalBytes) throw new InvalidDataException("Authority log exceeds its size bound.");
            var roles = handles.ToArray(); var identities = roles.Select(r => ApplicationAuthorityFileIdentity.HandleIdentity(r)).ToArray();
            var read = ReadOwned(root, rootIdentity, roles, identities, configuration, inventory, parent.Root, registration.History);
            checkpoint?.Invoke(ApplicationInspectionStage.HistoryRead);
            registration.RequireCurrent(parent);
            // Recheck after the acquisition test seam and before the lifetime is returned.
            var final = ReadOwned(root, rootIdentity, roles, identities, configuration, inventory, parent.Root, registration.History);
            if (final.Length != read.Length || final.Digest != read.Digest) throw new InvalidDataException("Authority bytes changed during acquisition.");
            registration.RequireCurrent(parent);
            return new(parent, registration, root, configuration, inventory, roles, identities, rootIdentity, final.History, final.Length, final.Digest, roleClose: roleClose);
        }
        catch (Exception primary)
        {
            var errors = CloseRoles(handles);
            if (errors.Count == 0) registration.Dispose();
            // An unconfirmed role release deliberately keeps the parent registration held.
            if (errors.Count != 0) throw new AggregateException("Authority acquisition cleanup could not confirm release; parent remains held.", new[] { primary }.Concat(errors));
            throw;
        }
    }

    internal ApplicationAuthorityHistory Inspect() => InspectCore(null);
    internal ApplicationAuthorityHistory InspectCore(Action? beforeRead)
    {
        using var operation = BeginRead();
        try
        {
            beforeRead?.Invoke();
            lock (_readGate)
            {
                var read = ReadOwned(Root, _rootIdentity, _roles, _identities, _configuration, _roots, _parent.Root, _registration.History);
                if (read.Length != _length || read.Digest != _digest) throw new InvalidDataException("Owned authority history changed; no new head is adopted.");
                return read.History;
            }
        }
        catch { lock (_gate) _faulted = true; throw; }
    }
    private IDisposable BeginRead()
    {
        lock (_gate)
        {
            ObjectDisposedException.ThrowIf(_closing, this);
            if (_faulted) throw new InvalidOperationException("Faulted authority inspection cannot be rearmed.");
            if (_retainedEnrollmentMode || _restartObservationMode) throw new InvalidOperationException("Retained protocol mode excludes generic inspection.");
            var parentRead = _registration.BeginRead(_parent); _reads++; return new Inspection(this, parentRead);
        }
    }
    private void CompleteRead(IDisposable parentRead)
    {
        try { lock (_gate) { _reads--; if (_closing && _reads == 0) ReleaseHandles(); } }
        finally { parentRead.Dispose(); }
    }
    /// <summary>Stops new inspection and retains both owners until all actual inspections have finished.</summary>
    public void Dispose() { lock (_gate) { _closing = true; if (_reads == 0) ReleaseHandles(); } }
    private void ReleaseHandles()
    {
        if (_releaseAttempted) return; _releaseAttempted = true;
        var errors = CloseRoles(_roles, _roleClose);
        if (errors.Count == 0)
        {
            try { _registration.Dispose(); _isReleased = true; _released.TrySetResult(); }
            catch (Exception error) { _released.TrySetException(error); }
        }
        else _released.TrySetException(new AggregateException("Authority release is unconfirmed; parent registration remains held.", errors));
    }
    private static List<Exception> CloseRoles(IEnumerable<FileStream> roles, IRetainedRoleLeaseClose? close = null)
    {
        var errors = new List<Exception>();
        foreach (var role in roles.Reverse()) { try { RetainedRoleRelease.Close(role, close); } catch (Exception error) { errors.Add(error); } }
        return errors;
    }
    private sealed class Inspection(ApplicationAuthorityLifetime owner, IDisposable parentRead) : IDisposable
    {
        private ApplicationAuthorityLifetime? _owner = owner;
        /// <inheritdoc/>
        public void Dispose() => Interlocked.Exchange(ref _owner, null)?.CompleteRead(parentRead);
    }

    private static (ApplicationAuthorityHistory History, long Length, string Digest) ReadOwned(string root, ApplicationFileIdentity rootIdentity,
        FileStream[] roles, ApplicationFileIdentity[] identities, ApplicationAuthorityConfiguration configuration, ImmutableDictionary<string, string> roots, string parent, HostJournalReadResult administrativeHistory)
    {
        CheckPlacement(parent, root, configuration, roots, administrativeHistory);
        VerifyRoles(root, rootIdentity, roles, identities);
        if (roles[0].Length != 0 || roles[1].Length != 112 || roles[2].Length > ApplicationAuthorityCodec.MaximumJournalBytes)
            throw new InvalidDataException("Owned authority role lengths changed.");
        var meta = new byte[112]; roles[1].Position = 0; roles[1].ReadExactly(meta);
        var metadata = ApplicationAuthorityCodec.DecodeMetadata(meta, configuration);
        var length = roles[2].Length; var bytes = new byte[(int)length]; roles[2].Position = 0; roles[2].ReadExactly(bytes);
        if (roles[2].ReadByte() != -1 || roles[2].Length != length) throw new InvalidDataException("Authority log changed while reading.");
        var history = ApplicationAuthorityCodec.DecodeJournal(bytes, metadata);
        foreach (var key in RequiredDataKeys(history))
        {
            if (string.Equals(key, configuration.AuthorityRootKey, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(key, configuration.AdministrativeRootKey, StringComparison.OrdinalIgnoreCase) || !roots.ContainsKey(key))
                throw new InvalidDataException("Retained authority data keys require explicit separate protected-path mappings.");
        }
        VerifyRoles(root, rootIdentity, roles, identities);
        CheckPlacement(parent, root, configuration, roots, administrativeHistory);
        return (history, length, Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant());
    }
    private static IEnumerable<string> RequiredDataKeys(ApplicationAuthorityHistory history)
    {
        if (history.Source is not null) yield return history.Source.RootKey;
        if (history.Candidate is not null) yield return history.Candidate.RootKey;
        if (history.Publication is not null) { yield return history.Publication.ArtifactRootKey; yield return history.Publication.BundleRootKey; }
    }
    private static void VerifyRoles(string root, ApplicationFileIdentity rootIdentity, FileStream[] roles, ApplicationFileIdentity[] identities)
    {
        if (CheckNamespace(root) != rootIdentity) throw new InvalidDataException("Authority root directory identity changed.");
        for (var index = 0; index < roles.Length; index++)
            if (ApplicationAuthorityFileIdentity.HandleIdentity(roles[index]) != identities[index] ||
                ApplicationAuthorityFileIdentity.PathIdentity(Path.Combine(root, RoleNames[index]), false) != identities[index])
                throw new InvalidDataException("Authority role path/handle identity changed.");
    }
    private static ApplicationFileIdentity CheckNamespace(string root)
    {
        var identity = ApplicationAuthorityFileIdentity.PathIdentity(root, true);
        var names = Directory.EnumerateFileSystemEntries(root).Take(4).Select(Path.GetFileName).Order(StringComparer.Ordinal).ToArray();
        if (!names.SequenceEqual(RoleNames.Order(StringComparer.Ordinal))) throw new InvalidDataException("Authority root requires exactly three existing file roles.");
        foreach (var name in RoleNames) _ = ApplicationAuthorityFileIdentity.PathIdentity(Path.Combine(root, name), false);
        return identity;
    }
    private static ImmutableDictionary<string, string> FreezeRoots(IReadOnlyDictionary<string, string> roots)
    {
        ArgumentNullException.ThrowIfNull(roots);
        if (roots.Count is < 3 or > 64) throw new ArgumentException("Supply a bounded complete root-key/path inventory.", nameof(roots));
        var snapshot = roots.Take(65).ToArray();
        if (snapshot.Length != roots.Count) throw new InvalidDataException("Root inventory changed during capture.");
        var builder = ImmutableDictionary.CreateBuilder<string, string>(StringComparer.Ordinal);
        foreach (var pair in snapshot)
        {
            if (string.IsNullOrWhiteSpace(pair.Key) || pair.Key.Length > 4096 || pair.Key.Contains('\0')) throw new InvalidDataException("Invalid root inventory key.");
            builder.Add(pair.Key, Canonical(pair.Value));
        }
        return builder.ToImmutable();
    }
    private static string Canonical(string path)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(path);
        if (path.Length > 4096 || !Path.IsPathFullyQualified(path)) throw new ArgumentException("Root paths must be bounded and fully qualified.", nameof(path));
        return Path.TrimEndingDirectorySeparator(Path.GetFullPath(path));
    }
    private static void CheckPlacement(string parent, string root, ApplicationAuthorityConfiguration configuration,
        ImmutableDictionary<string, string> roots, HostJournalReadResult history, Action<string>? beforeProtectedPathRead = null)
    {
        var cache = new Dictionary<string, ApplicationFileIdentity>(OperatingSystem.IsWindows() ? StringComparer.OrdinalIgnoreCase : StringComparer.Ordinal);
        var authorityAncestors = Ancestors(root, cache); var authorityId = ApplicationAuthorityFileIdentity.PathIdentity(root, true);
        var paths = new HashSet<string>(StringComparer.Ordinal) { parent };
        foreach (var pair in roots) if (pair.Key != configuration.AuthorityRootKey) paths.Add(pair.Value);
        foreach (var frame in history.Frames)
        {
            paths.Add(Canonical(frame.Snapshot.Context.Intent.ArtifactRoot)); paths.Add(Canonical(frame.Snapshot.Context.Intent.BundleRoot));
            if (paths.Count > 4096) throw new InvalidDataException("Retained protected root inventory exceeds the inspection bound.");
        }
        foreach (var path in paths)
        {
            if (Contains(root, path) || Contains(path, root)) throw new InvalidDataException("Authority and protected/admin roots must be disjoint.");
            beforeProtectedPathRead?.Invoke(path);
            var ancestors = Ancestors(path, cache);
            if (ancestors.Contains(authorityId) || Directory.Exists(path) && authorityAncestors.Contains(ApplicationAuthorityFileIdentity.PathIdentity(path, true)))
                throw new InvalidDataException("Physical authority/protected ancestry overlaps.");
        }
    }
    private static HashSet<ApplicationFileIdentity> Ancestors(string path, Dictionary<string, ApplicationFileIdentity> cache)
    {
        var result = new HashSet<ApplicationFileIdentity>(); var depth = 0;
        for (var current = path; current is not null; current = Path.GetDirectoryName(current))
        {
            if (++depth > 128) throw new InvalidDataException("Path ancestry exceeds the inspection bound.");
            if (!Directory.Exists(current))
            {
                try
                {
                    _ = File.GetAttributes(current); BinaryEnvelope.RejectLinks(current);
                    throw new InvalidDataException("Protected roots and ancestors must be directories.");
                }
                catch (Exception error) when (error is FileNotFoundException or DirectoryNotFoundException) { continue; }
            }
            if (!cache.TryGetValue(current, out var identity)) { identity = ApplicationAuthorityFileIdentity.PathIdentity(current, true); cache.Add(current, identity); }
            result.Add(identity);
        }
        return result;
    }
    private static bool Contains(string parent, string child) => string.Equals(parent, child, StringComparison.OrdinalIgnoreCase) ||
        child.StartsWith(Path.EndsInDirectorySeparator(parent) ? parent : parent + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase);
}
