// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Prepares isolated complete empty-chain epoch fixtures without migrating user stores.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal static class EpochEmptyRoot
{
    internal static EpochIdentity CreateFixture(string source, string destination, ulong documentId, ITransactionStorage storage)
    {
        destination = BackupStorage.Destination(source, destination);
        using var original = ImmutableXmlSnapshot.Open(source, documentId, 0);
        var hash = TransactionCodec.ManifestHash(source, documentId);
        ScalarGeneration.Validate(source, documentId, hash);
        return EpochAdmission.CreateFixtureRoot(destination, documentId, storage, prepare: (staging, identity, format) =>
        {
            var binding = EpochAuthorityBinding.Create(format, hash);
            var document = "documents/" + documentId.ToString(System.Globalization.CultureInfo.InvariantCulture) + "/";
            var manifest = StoreCodec.ReadManifest(TransactionCodec.ReadManifestBytes(source, documentId));
            var names = new[] { document + "manifest.bin", document + "directory.bin" }.Concat(manifest.Fragments.Select(fragment =>
                "fragments/" + fragment.Id.ToString(System.Globalization.CultureInfo.InvariantCulture) + ".bin"));
            BackupStorage.Copy(source, staging, names, storage);
            TransactionCodec.WriteFlushed(Path.Combine(staging, "BASE"), EpochAuthorityCodec.EncodeBase(new(binding)), storage);
            var transactions = Path.Combine(staging, ".transactions"); TransactionCodec.EnsureDirectory(transactions, storage);
            foreach (var directory in new[] { "wal", "generations", "readers", "staging" }) TransactionCodec.EnsureDirectory(Path.Combine(transactions, directory), storage);
            TransactionCodec.WriteFlushed(Path.Combine(transactions, "CONTROL"), EpochAuthorityCodec.EncodeControl(EpochAuthorityCodec.CreateControl(binding)), storage);
            EpochEmptyCoordinator.ReadAuthority(staging, identity);
            using var admission = EpochAdmission.Acquire(staging, identity, profile: EpochProfile.ScalarWal);
            EpochEmptyCoordinator.VerifyBase(staging, admission, hash);
        }, profile: EpochProfile.ScalarWal);
    }
}
