// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Owns an existing embedded host root through administrative admission and drain.
// SPECIAL NOTES        : Controlled cooperative namespace; existing opens never provision or repair.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 28-10-2026     | Share placement validation and continuous ownership with explicit provisioning
//                      | Charles Korthout | 0.3   | 28-10-2026     | Retain acquisition length and fault-gate journal operation registration
//                      | Charles Korthout | 0.4   | 28-10-2026     | Share bound reconciliation checks and fault-safe executor admission
//                      | Charles Korthout | 0.5   | 29-10-2026     | Exclude admissions during stopped reconciliation
//                      | Charles Korthout | 0.6   | 29-10-2026     | Exclude administrative paths during paired application inspection
//                      | Charles Korthout | 0.7   | 30-10-2026     | Bind optional actual-owner role close faults and confirm injected release
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal sealed record EmbeddedHostContext(Guid SessionId, Guid JournalId, string Deployment, string ResourceScope);
internal sealed record EmbeddedHostAdmissionEvidence(EmbeddedHostContext Context, bool Fresh, bool AllWritersControlled,
    bool AllPublishersControlled, bool PriorExecutorsExcluded, bool Reconciled, bool QueueFree);

internal sealed partial class EmbeddedHostLifetime : IDisposable
{
    private readonly object _gate = new();
    private readonly FileStream _owner;
    private readonly FileStream _metadata;
    private readonly FileStream _journal;
    private readonly IRetainedRoleLeaseClose? _roleClose;
    private readonly TaskCompletionSource _drained = new(TaskCreationOptions.RunContinuationsAsynchronously);
    private bool _admissions;
    private bool _closing;
    private bool _releaseAttempted;
    private bool _released;
    private int _operations;
    private ExecutorRegistration? _executorRegistration;
    private StoppedRegistration? _stoppedRegistration;
    internal const int MaximumOperations = 1024;

    private EmbeddedHostLifetime(string root, FileStream owner, FileStream metadata, FileStream journal, EmbeddedHostContext context, HostJournalReadResult history, bool provisioned = false, IRetainedRoleLeaseClose? roleClose = null)
    { Root = root; _owner = owner; _metadata = metadata; _journal = journal; Context = context; History = history; WasProvisionedHere = provisioned; _acquiredJournalLength = journal.Position; _roleClose = roleClose; }
    internal string Root { get; }
    internal EmbeddedHostContext Context { get; }
    internal HostJournalReadResult History { get; }
    internal bool WasProvisionedHere { get; }
    internal bool WritersMustRemainStopped => true;
    internal Task WhenReleased => _drained.Task;
    internal int ActiveOperations { get { lock (_gate) return _operations; } }
    internal bool AdmissionsOpen { get { lock (_gate) return _admissions; } }
    internal bool IsReleased { get { lock (_gate) return _released; } }

    internal static EmbeddedHostLifetime OpenExisting(string root, string deployment, string scope, IReadOnlyList<string> protectedRoots,
        DurabilityMode durability = DurabilityMode.ProcessCrash) => OpenExistingCore(root, deployment, scope, protectedRoots, durability, null);

    internal static EmbeddedHostLifetime OpenExistingCore(string root, string deployment, string scope, IReadOnlyList<string> protectedRoots,
        DurabilityMode durability, IRetainedRoleLeaseClose? roleClose)
    {
        root = ValidatePlacement(root, deployment, scope, protectedRoots, durability);
        CheckNamespace(root);
        FileStream? owner = null; FileStream? metadata = null; FileStream? journal = null;
        try
        {
            // Open only: never create/recreate a lock or read authoritative state before exclusion.
            owner = new(Path.Combine(root, "owner.lock"), FileMode.Open, FileAccess.ReadWrite, FileShare.None, bufferSize: 1);
            if (!owner.CanSeek || owner.Length != 0) throw new InvalidDataException("Host ownership file must be empty and stable.");
            CheckNamespace(root);
            // Read/write open avoids a blocking read-only FIFO open on Linux; no Write/SetLength
            // calls occur. Non-seekable roles are rejected before reading authoritative bytes.
            metadata = new(Path.Combine(root, "host.meta"), FileMode.Open, FileAccess.ReadWrite, FileShare.Read, bufferSize: 1);
            if (!metadata.CanSeek || metadata.Length != 88) throw new InvalidDataException("Host metadata size mismatch.");
            var bytes = new byte[88]; metadata.ReadExactly(bytes); var identity = HostJournalCodec.DecodeMetadata(bytes, deployment, scope);
            journal = new(Path.Combine(root, "journal.bin"), FileMode.Open, FileAccess.ReadWrite, FileShare.Read, bufferSize: 1);
            if (!journal.CanSeek || journal.Length > HostJournalCodec.MaximumJournalBytes) throw new InvalidDataException("Host journal exceeds size bound.");
            var history = HostJournalCodec.ReadJournal(journal, identity, deployment, scope);
            var checkedRoots = new HashSet<string>(StringComparer.Ordinal);
            foreach (var frame in history.Frames)
            {
                foreach (var path in new[] { frame.Snapshot.Context.Intent.ArtifactRoot, frame.Snapshot.Context.Intent.BundleRoot })
                    if (checkedRoots.Add(path)) CheckProtected(root, path);
            }
            CheckNamespace(root);
            return new(root, owner, metadata, journal, new(Guid.NewGuid(), identity.JournalId, deployment, scope), history, roleClose: roleClose);
        }
        catch
        {
            try { journal?.Dispose(); }
            finally { try { metadata?.Dispose(); } finally { owner?.Dispose(); } }
            throw;
        }
    }

    internal void OpenAdministrativeAdmissions(EmbeddedHostAdmissionEvidence evidence)
    {
        ArgumentNullException.ThrowIfNull(evidence);
        lock (_gate)
        {
            ObjectDisposedException.ThrowIf(_closing, this);
            if (Volatile.Read(ref _journalFaulted)) throw new InvalidOperationException("Faulted journal sessions cannot reopen admissions.");
            RequireAdmissionEvidence(evidence);
            if (_stoppedRegistration is not null || _applicationRegistration is not null) throw new InvalidOperationException("Stopped inspection excludes administrative admission.");
            _admissions = true;
        }
    }
    internal void CloseAdmissions() { lock (_gate) _admissions = false; }
    internal IDisposable BeginOperation() => RegisterOperation(requireAdmission: true);
    private void RequireAdmissionEvidence(EmbeddedHostAdmissionEvidence evidence)
    {
        ArgumentNullException.ThrowIfNull(evidence);
        if (evidence.Context != Context || !evidence.Fresh || !evidence.AllWritersControlled || !evidence.AllPublishersControlled ||
            !evidence.PriorExecutorsExcluded || !evidence.Reconciled || !evidence.QueueFree)
            throw new InvalidOperationException("Administrative admission requires fresh bound controlled-scope reconciliation evidence.");
    }
    internal IDisposable BeginReconciliationOperation() => RegisterOperation(requireAdmission: false);
    internal IDisposable BeginExclusiveExecutor(Guid attemptId)
    {
        if (attemptId == Guid.Empty) throw new ArgumentException("Executor attempt ID must be nonempty.", nameof(attemptId));
        lock (_gate)
        {
            ObjectDisposedException.ThrowIf(_closing, this);
            if (!_admissions || _stoppedRegistration is not null || _applicationRegistration is not null || Volatile.Read(ref _journalFaulted) || _executorRegistration is not null || _operations == MaximumOperations)
                throw new InvalidOperationException("Host executor admission is closed, faulted or already reserved.");
            var registration = new ExecutorRegistration(this, attemptId); _executorRegistration = registration; _operations++; return registration;
        }
    }
    private void CompleteExecutor(ExecutorRegistration registration)
    {
        lock (_gate) { if (!ReferenceEquals(_executorRegistration, registration)) throw new InvalidOperationException("Executor registration mismatch."); _executorRegistration = null; _operations--; if (_closing && _operations == 0) ReleaseHandles(); }
    }
    private sealed class ExecutorRegistration(EmbeddedHostLifetime owner, Guid attemptId) : IDisposable
    {
        private EmbeddedHostLifetime? _owner = owner;
        internal Guid AttemptId { get; } = attemptId;
        /// <inheritdoc/>
        public void Dispose() => Interlocked.Exchange(ref _owner, null)?.CompleteExecutor(this);
    }
    private void RequireExecutorAppend(Guid attemptId, IDisposable? registration)
    {
        lock (_gate)
        {
            if (_executorRegistration is { } active && active.AttemptId == attemptId)
            {
                if (!ReferenceEquals(active, registration)) throw new InvalidOperationException("Active attempt writes require the reserved executor registration.");
            }
            else if (registration is not null) throw new InvalidOperationException("Executor registration does not own this attempt.");
        }
    }
    private IDisposable RegisterOperation(bool requireAdmission)
    {
        lock (_gate)
        {
            ObjectDisposedException.ThrowIf(_closing, this);
            if (_applicationRegistration is not null) throw new InvalidOperationException("Application inspection excludes ordinary host operations.");
            if (requireAdmission && (!_admissions || _stoppedRegistration is not null || Volatile.Read(ref _journalFaulted)) || _operations == MaximumOperations) throw new InvalidOperationException("Administrative admission is closed or full.");
            var operation = new Operation(this); _operations++; return operation;
        }
    }
    /// <summary>Closes admissions and requests shutdown; ownership remains held until all registered work drains.</summary>
    /// <remarks>Await WhenReleased to establish successful handle release. Caller timeout/cancellation does not finish an operation.</remarks>
    public void Dispose()
    {
        lock (_gate) { _closing = true; _admissions = false; if (_operations == 0) ReleaseHandles(); }
    }
    private void CompleteOperation()
    {
        lock (_gate) { _operations--; if (_closing && _operations == 0) ReleaseHandles(); }
    }
    private void ReleaseHandles()
    {
        if (_releaseAttempted) return; _releaseAttempted = true; var errors = new List<Exception>();
        foreach (var handle in new[] { _journal, _metadata, _owner })
        { try { RetainedRoleRelease.Close(handle, _roleClose); } catch (Exception error) { errors.Add(error); } }
        if (errors.Count == 0) { _released = true; _drained.TrySetResult(); }
        else _drained.TrySetException(new AggregateException("Host handle release could not be confirmed.", errors));
    }
    private sealed class Operation(EmbeddedHostLifetime owner) : IDisposable
    {
        private EmbeddedHostLifetime? _owner = owner;
        /// <inheritdoc/>
        public void Dispose() => Interlocked.Exchange(ref _owner, null)?.CompleteOperation();
    }
    private static string ValidatePlacement(string root, string deployment, string scope, IReadOnlyList<string> protectedRoots, DurabilityMode durability)
    {
        if (durability != DurabilityMode.ProcessCrash) throw new NotSupportedException("Host lifetime pilot supports ProcessCrash only.");
        _ = HostJournalCodec.ScopeDigest(deployment, scope); root = Canonical(root);
        ArgumentNullException.ThrowIfNull(protectedRoots);
        if (protectedRoots.Count is < 1 or > 64) throw new ArgumentException("Supply a bounded complete inventory of protected data roots.", nameof(protectedRoots));
        for (var index = 0; index < protectedRoots.Count; index++) CheckProtected(root, protectedRoots[index]);
        return root;
    }
    private static string Canonical(string path)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(path);
        if (path.Length > HostJournalCodec.MaximumStringBytes) throw new ArgumentException("Host/data root exceeds the pilot path bound.", nameof(path));
        if (!Path.IsPathFullyQualified(path)) throw new ArgumentException("Host and data roots must be fully qualified.", nameof(path));
        return Path.TrimEndingDirectorySeparator(Path.GetFullPath(path));
    }
    private static void CheckProtected(string host, string path)
    {
        path = Canonical(path);
        if (Contains(host, path) || Contains(path, host)) throw new InvalidDataException("Host and protected data roots must be disjoint.");
        var existing = path;
        while (true)
        {
            try
            {
                _ = File.GetAttributes(existing); BinaryEnvelope.RejectLinks(existing);
                if (!Directory.Exists(existing)) throw new InvalidDataException("Protected roots/ancestors must be directories.");
                return;
            }
            catch (Exception error) when (error is FileNotFoundException or DirectoryNotFoundException)
            { existing = Path.GetDirectoryName(existing) ?? throw new InvalidDataException("Protected root has no existing ancestor."); }
        }
    }
    private static bool Contains(string parent, string child) => string.Equals(parent, child, StringComparison.OrdinalIgnoreCase) ||
        child.StartsWith(Path.EndsInDirectorySeparator(parent) ? parent : parent + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase);
    private static void CheckNamespace(string root)
    {
        BinaryEnvelope.RejectLinks(root);
        if (!Directory.Exists(root)) throw new DirectoryNotFoundException("Existing host root required.");
        var roles = Directory.EnumerateFileSystemEntries(root).Take(4).ToArray();
        if (!roles.Select(Path.GetFileName).Order(StringComparer.Ordinal).SequenceEqual(new[] { "host.meta", "journal.bin", "owner.lock" }))
            throw new InvalidDataException("Existing host root requires exactly its three stable file roles.");
        foreach (var role in roles)
        {
            BinaryEnvelope.RejectLinks(role);
            if ((File.GetAttributes(role) & (FileAttributes.Directory | FileAttributes.Device)) != 0) throw new InvalidDataException("Host roles must be regular files.");
        }
    }
}
