// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Owns a read-only immutable epoch root with independently admitted snapshots.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

/// <summary>Owns a read-only immutable epoch root with independently admitted snapshots.</summary>
/// <remarks>Experimental sequence-zero roots only. Transactions, migration, epoch backup and reclamation are unsupported.</remarks>
public sealed class ReadOnlyEpochDatabase : IDisposable
{
    private readonly object _gate = new();
    private readonly string _root;
    private readonly EpochAdmissionLease _admission;
    private readonly byte[] _manifestHash;
    private bool _disposed;

    private ReadOnlyEpochDatabase(string root, EpochAdmissionLease admission, byte[] manifestHash)
    { _root = root; _admission = admission; _manifestHash = manifestHash; }

    /// <summary>Gets the immutable store identity.</summary>
    public Guid StoreId => _admission.Identity.StoreId;
    /// <summary>Gets the immutable epoch identity.</summary>
    public Guid EpochId => _admission.Identity.EpochId;
    /// <summary>Gets the persistent document identity.</summary>
    public ulong DocumentId => _admission.Identity.DocumentId;

    /// <summary>Opens a complete read-only epoch root and holds shared admission until disposal.</summary>
    /// <param name="databaseRoot">Published mandatory-major-2 root with a sequence-zero SNAPSHOT descriptor.</param>
    /// <returns>An owned read-only store session.</returns>
    /// <exception cref="InvalidDataException">Identity, descriptor or structural metadata is invalid.</exception>
    /// <exception cref="IOException">Maintenance owns exclusive admission or storage reading fails.</exception>
    public static ReadOnlyEpochDatabase Open(string databaseRoot)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(databaseRoot);
        var root = Path.GetFullPath(databaseRoot);
        var admission = EpochAdmission.Acquire(root, EpochAdmission.ReadIdentity(root));
        try
        {
            var hash = EpochSnapshotCodec.Read(root, admission.Identity);
            using (ImmutableXmlSnapshot.OpenEpoch(root, admission.ForkShared(), hash, cacheBytes: 0)) { }
            return new(root, admission, hash);
        }
        catch { admission.Dispose(); throw; }
    }

    /// <summary>Opens an independently admitted immutable snapshot that can outlive this session.</summary>
    /// <param name="cacheBytes">Maximum retained decoded fragment bytes; zero forces uncached lazy reads.</param>
    /// <returns>A snapshot owning its own shared epoch handle.</returns>
    public ImmutableXmlSnapshot BeginRead(int cacheBytes = 8 * 1024 * 1024)
    {
        ArgumentOutOfRangeException.ThrowIfNegative(cacheBytes);
        lock (_gate)
        {
            ObjectDisposedException.ThrowIf(_disposed, this);
            if (!EpochSnapshotCodec.Read(_root, _admission.Identity).AsSpan().SequenceEqual(_manifestHash))
                throw new InvalidDataException("Immutable epoch snapshot descriptor changed.");
            // Parent admission is already held; a nonblocking child fork cannot wait for maintenance under this gate.
            return ImmutableXmlSnapshot.OpenEpoch(_root, _admission.ForkShared(), _manifestHash, cacheBytes);
        }
    }

    /// <inheritdoc />
    public void Dispose()
    {
        lock (_gate)
        {
            if (_disposed) return;
            _admission.Dispose(); _disposed = true;
        }
    }
}
