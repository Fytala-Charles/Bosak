// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 30 October 2026
// PURPOSE              : Conditionally publishes the first authority enrollment under retained ownership.
// SPECIAL NOTES        : Internal terminal ProcessCrash writer; no work admission, retry, repair or history deletion.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 30-10-2026     | Enforce authority serialization for exact empty-head checks                               |
//                      | Charles Korthout | 0.1   | 30-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

internal enum ApplicationEnrollmentAppendDisposition { RefusedBeforeWrite, AcknowledgedStopped, Uncertain }
internal enum ApplicationEnrollmentAppendStage { Armed, Validated, BeforeWrite, Written, Flushed, BeforeAcknowledge, BeforeRelease, BeforeArm }
internal sealed record ApplicationEnrollmentReceipt(Guid AuthorityId, HostJournalPosition AdministrativePosition,
    ApplicationAuthorityFrame Frame, long Length, string JournalDigest)
{ internal bool WritersMustRemainStopped => true; }
internal sealed record ApplicationEnrollmentAppendResult(ApplicationEnrollmentAppendDisposition Disposition,
    ApplicationEnrollmentReceipt? Receipt, bool PossibleOutput, bool ReleaseUnknown, Exception? Error)
{ internal bool WritersMustRemainStopped => true; }
internal interface IApplicationAuthorityAppendIo
{
    void Write(FileStream stream, ReadOnlySpan<byte> bytes);
    void Flush(FileStream stream);
    void ReadBack(FileStream stream, Span<byte> bytes);
}

internal sealed partial class ApplicationAuthorityLifetime
{
    private bool _firstEnrollmentAppendStarted;
    private ApplicationEnrollmentReceipt? _confirmedEnrollment;
    internal ApplicationEnrollmentReceipt? ConfirmedEnrollment { get { lock (_gate) return _confirmedEnrollment; } }

    internal ApplicationEnrollmentAppendResult AppendFirstEnrollment(RetainedEnrollmentPreparation plan, ApplicationEnrollmentEvidence freshEvidence) =>
        AppendFirstEnrollmentCore(plan, freshEvidence, new LocalEnrollmentAppendIo());

    // Instrumentation is private test infrastructure, never a consumer callback/provider.
    internal ApplicationEnrollmentAppendResult AppendFirstEnrollmentCore(RetainedEnrollmentPreparation plan,
        ApplicationEnrollmentEvidence freshEvidence, IApplicationAuthorityAppendIo io,
        Action<ApplicationEnrollmentAppendStage>? checkpoint = null, DurabilityMode durability = DurabilityMode.ProcessCrash)
    {
        ArgumentNullException.ThrowIfNull(plan); ArgumentNullException.ThrowIfNull(io); plan.CheckThread();
        RequireRetainedEntryWithoutCallerLocks(plan.IsSourceGateEntered);
        if (durability != DurabilityMode.ProcessCrash) throw new NotSupportedException("First enrollment supports only ProcessCrash without fallback.");
        lock (_gate)
        {
            if (_firstEnrollmentAppendStarted || !ReferenceEquals(_retainedPreparation, plan) || !ReferenceEquals(plan.Owner, this) || plan.Disposed || plan.Consumed)
                throw new InvalidOperationException("Only the actual unconsumed retained preparation can start first enrollment once.");
            _firstEnrollmentAppendStarted = true;
        }
        RetainedEnrollmentExecution? execution = null; ApplicationEnrollmentReceipt? receipt = null;
        Exception? failure = null; var possibleOutput = false; var releaseUnknown = false;
        try
        {
            execution = TryArmRetainedFirstEnrollmentCore(plan, freshEvidence, () => checkpoint?.Invoke(ApplicationEnrollmentAppendStage.BeforeArm));
            if (execution is null) throw new InvalidOperationException("Combined enrollment admission was busy; the plan is consumed.");
            checkpoint?.Invoke(ApplicationEnrollmentAppendStage.Armed);
            var description = execution.Inspect(); // All source/capture/admin I/O precedes the authority serializer.
            var metadata = ApplicationAuthorityCodec.DecodeMetadata(ApplicationAuthorityCodec.EncodeMetadata(_configuration), _configuration);
            var bytes = ApplicationAuthorityCodec.EncodeFrame(metadata, 1, new string('0', 64), description.Entry);
            var expectedHistory = ApplicationAuthorityCodec.DecodeJournal(bytes, metadata);
            var frame = expectedHistory.Frames.Single();
            lock (_readGate)
            {
                RequireEmptyAppendHead();
                checkpoint?.Invoke(ApplicationEnrollmentAppendStage.Validated);
                RequireEmptyAppendHead(); // Native roles, metadata and exact EOF after instrumentation.
                _roles[2].Position = 0;
                possibleOutput = true; // Before any output-capable hook/delegation, even if it throws before writing.
                checkpoint?.Invoke(ApplicationEnrollmentAppendStage.BeforeWrite);
                io.Write(_roles[2], bytes); checkpoint?.Invoke(ApplicationEnrollmentAppendStage.Written);
                io.Flush(_roles[2]); checkpoint?.Invoke(ApplicationEnrollmentAppendStage.Flushed);
                if (_roles[2].Length != bytes.Length) throw new InvalidDataException("Enrollment did not write exactly one frame.");
                var actual = new byte[bytes.Length]; _roles[2].Position = 0; io.ReadBack(_roles[2], actual);
                if (!actual.AsSpan().SequenceEqual(bytes) || _roles[2].ReadByte() != -1)
                    throw new InvalidDataException("Enrollment frame readback differs from the exact request.");
                checkpoint?.Invoke(ApplicationEnrollmentAppendStage.BeforeAcknowledge);
                var confirmed = ReadAppendAuthority();
                if (confirmed.Length != bytes.Length || !confirmed.Bytes.AsSpan().SequenceEqual(bytes) ||
                    confirmed.History.Frames.Length != 1 || confirmed.History.Frames[0] != frame)
                    throw new InvalidDataException("Complete enrollment history changed before acknowledgment.");
                receipt = new(_configuration.AuthorityId, description.AdministrativePosition, frame, bytes.Length,
                    Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant());
            }
            checkpoint?.Invoke(ApplicationEnrollmentAppendStage.BeforeRelease);
        }
        catch (Exception error) { failure = error; }
        // No source/lifetime gate is entered while holding the authority serializer.
        if (execution is not null)
        {
            try { execution.Dispose(); }
            catch (Exception error) { releaseUnknown = true; failure = failure is null ? error : new AggregateException(failure, error); }
        }
        else releaseUnknown = _unreleasedRetainedResources is not null;
        lock (_gate)
        {
            if (failure is not null) _faulted = true;
            else _confirmedEnrollment = receipt;
        }
        if (failure is null) return new(ApplicationEnrollmentAppendDisposition.AcknowledgedStopped, receipt, possibleOutput, false, null);
        return new(possibleOutput || releaseUnknown ? ApplicationEnrollmentAppendDisposition.Uncertain : ApplicationEnrollmentAppendDisposition.RefusedBeforeWrite,
            null, possibleOutput, releaseUnknown, failure);
    }
    private void RequireEmptyAppendHead()
    {
        if (!Monitor.IsEntered(_readGate)) throw new InvalidOperationException("Exact authority checks require the authority serializer.");
        var read = ReadAppendAuthority();
        if (_length != 0 || History.Frames.Length != 0 || read.Length != 0 || read.History.Frames.Length != 0 ||
            Convert.ToHexString(SHA256.HashData(read.Bytes)).ToLowerInvariant() != _digest)
            throw new InvalidDataException("First enrollment requires the exact acquired empty authority; no head is adopted.");
    }
    // Authority roles only. ReadOwned additionally visits protected roots, so cannot be used in journal I/O.
    private (ApplicationAuthorityHistory History, long Length, byte[] Bytes) ReadAppendAuthority()
    {
        VerifyRoles(Root, _rootIdentity, _roles, _identities);
        if (_roles[0].Length != 0 || _roles[1].Length != 112 || _roles[2].Length > ApplicationAuthorityCodec.MaximumJournalBytes)
            throw new InvalidDataException("Enrollment authority role lengths changed.");
        var meta = new byte[112]; _roles[1].Position = 0; _roles[1].ReadExactly(meta);
        var metadata = ApplicationAuthorityCodec.DecodeMetadata(meta, _configuration);
        var length = _roles[2].Length; var bytes = new byte[(int)length]; _roles[2].Position = 0; _roles[2].ReadExactly(bytes);
        if (_roles[2].ReadByte() != -1 || _roles[2].Length != length) throw new InvalidDataException("Authority EOF changed.");
        var history = ApplicationAuthorityCodec.DecodeJournal(bytes, metadata);
        VerifyRoles(Root, _rootIdentity, _roles, _identities);
        return (history, length, bytes);
    }
    private sealed class LocalEnrollmentAppendIo : IApplicationAuthorityAppendIo
    {
        /// <inheritdoc/>
        public void Write(FileStream stream, ReadOnlySpan<byte> bytes) => stream.Write(bytes);
        /// <inheritdoc/>
        public void Flush(FileStream stream) => stream.Flush(flushToDisk: true);
        /// <inheritdoc/>
        public void ReadBack(FileStream stream, Span<byte> bytes) => stream.ReadExactly(bytes);
    }
}
