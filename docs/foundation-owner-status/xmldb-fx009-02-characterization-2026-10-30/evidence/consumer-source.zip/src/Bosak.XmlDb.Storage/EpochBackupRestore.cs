// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Restores verified epoch history into an independent atomically published provenance bundle.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 27-10-2026     | Share destination verification primitives with internal legacy conversion
//                      | Charles Korthout | 0.3   | 28-10-2026     | Use a claimed preknown restore identity after exact prepared-input validation
// ===========================================================================================================================================================

using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

internal enum EpochRestoreStage { SourceVerified, Rebound, DestinationVerified, RuntimeReady, OriginFlushed, BundleVerified, Published }
internal sealed record EpochRestoreResult(Guid RestoreId, Guid BackupId, EpochIdentity Source, EpochIdentity Destination,
    ulong CommitSequence, string StorePath);

internal static class EpochBackupRestore
{
    internal static EpochRestoreResult Restore(string backup, string destination, ITransactionStorage? storage = null,
        Action<EpochRestoreStage>? checkpoint = null, EpochAttemptExecution? execution = null)
    {
        storage ??= new LocalTransactionStorage();
        execution?.Enter(EpochPublicationKind.IndependentEpochRestore, backup, destination, storage.Durability);
        destination = BackupStorage.Destination(backup, destination); backup = Path.GetFullPath(backup);
        var source = EpochBackupStorage.ReadArtifact(backup); // No output before seal/closure/header rejection.
        var inventoryBytes = BinaryEnvelope.ReadFile(Path.Combine(backup, "inventory.bin"));
        execution?.ValidateInput(inventoryBytes);
        if (!inventoryBytes.AsSpan().SequenceEqual(EpochBackupCodec.EncodeInventory(source))) throw new InvalidDataException("Source inventory changed during restore.");
        BackupStorage.Preflight(destination, storage);
        var workspace = EpochBackupStorage.Workspace(destination, storage); var data = Path.Combine(backup, "data");
        EpochBackupStorage.VerifyCopies(data, workspace, source, storage);
        checkpoint?.Invoke(EpochRestoreStage.SourceVerified);
        var identity = new EpochIdentity(Fresh(source.Source.Identity.StoreId), Fresh(source.Source.Identity.EpochId), source.Source.Identity.DocumentId);
        if (execution is not null) execution.ValidateInput(BinaryEnvelope.ReadFile(Path.Combine(backup, "inventory.bin")));
        var restoreId = execution?.Intent.AttemptId ?? Fresh(Guid.Empty); var bundle = Path.Combine(workspace, "bundle"); var root = Path.Combine(bundle, "store");
        var expected = Rebind(data, root, source, identity, storage);
        checkpoint?.Invoke(EpochRestoreStage.Rebound);
        EpochBackupStorage.VerifyCopies(root, workspace, expected, storage);
        checkpoint?.Invoke(EpochRestoreStage.DestinationVerified);
        InitializeRuntime(root, expected, storage);
        ValidateRuntime(root, expected, storage);
        checkpoint?.Invoke(EpochRestoreStage.RuntimeReady);
        var origin = new EpochRestoreOrigin(restoreId, source.BackupId, SHA256.HashData(inventoryBytes), source.Source,
            identity, source.CommitSequence, expected.Source.FormatHash, source.HeadManifestHash, source.HeadWalHash, expected.HeadWalHash);
        TransactionCodec.WriteFlushed(Path.Combine(bundle, "origin.bin"), EpochBackupCodec.EncodeOrigin(origin), storage);
        checkpoint?.Invoke(EpochRestoreStage.OriginFlushed);
        ValidateBundle(bundle, inventoryBytes, expected, storage);
        // Recheck the original seal/data as well; no source or backup file is ever written here.
        var unchanged = EpochBackupStorage.ReadArtifact(backup);
        if (!EpochBackupCodec.EncodeInventory(unchanged).AsSpan().SequenceEqual(inventoryBytes)) throw new InvalidDataException("Source artifact changed during restore.");
        checkpoint?.Invoke(EpochRestoreStage.BundleVerified);
        // Every staging-path admission/writer/snapshot handle has closed before this rename.
        TransactionCodec.PublishGeneration(bundle, destination, storage);
        checkpoint?.Invoke(EpochRestoreStage.Published);
        EpochBackupStorage.RemoveWorkspace(workspace, storage);
        return new(restoreId, source.BackupId, source.Source.Identity, identity, source.CommitSequence, Path.Combine(destination, "store"));
    }

    private static EpochBackupInventory Rebind(string data, string root, EpochBackupInventory source, EpochIdentity destination, ITransactionStorage storage)
    {
        var files = source.Files.ToDictionary(file => file.Path, StringComparer.Ordinal);
        var copied = BackupStorage.Copy(data, root, source.Files.Where(file => IsDocumentData(file.Path)).Select(file => file.Path), storage);
        foreach (var file in copied)
            if (file.Length != files[file.Path].Length || !file.Hash.AsSpan().SequenceEqual(files[file.Path].Hash)) throw new InvalidDataException("Copied source data changed during restore.");
        var format = EpochCodec.EncodeProfile(destination, EpochProfile.ScalarWal);
        var binding = EpochAuthorityBinding.Create(format, source.Source.BaseHash);
        Write("FORMAT", format); Write("EPOCH", EpochCodec.EncodeBinding("BXEP", destination, format));
        Write("BASE", EpochAuthorityCodec.EncodeBase(new(binding)));
        Write(".transactions/CONTROL", EpochAuthorityCodec.EncodeControl(EpochAuthorityCodec.CreateControl(binding)));
        var previousWal = new byte[32];
        for (ulong sequence = 1; sequence <= source.CommitSequence; sequence++)
        {
            var name = ".transactions/wal/" + EpochAuthorityCodec.WalFileName(sequence);
            var originalBytes = ReadBound(data, files[name]); var original = EpochAuthorityCodec.DecodeWal(originalBytes, source.Source);
            var rebound = EpochAuthorityCodec.EncodeWal(original with { Binding = binding, PreviousWalHash = previousWal });
            Write(name, rebound); previousWal = SHA256.HashData(rebound);
            var prefix = ".transactions/generations/" + EpochAuthorityCodec.GenerationName(sequence) + "/";
            Write(prefix + "FORMAT", format);
            Write(prefix + "GENERATION", EpochAuthorityCodec.EncodeGeneration(new(binding, sequence, original.PreviousManifestHash, original.ManifestHash, previousWal)));
        }
        Write(".transactions/CURRENT", EpochAuthorityCodec.EncodeCurrent(new(binding, source.CommitSequence, source.HeadManifestHash, previousWal)));
        var entries = source.Files.Select(file =>
        {
            var bytes = BinaryEnvelope.ReadFile(Path.Combine(root, file.Path)); return new BackupEntry(file.Path, bytes.Length, SHA256.HashData(bytes));
        }).ToArray();
        var expected = new EpochBackupInventory(source.BackupId, binding, source.CommitSequence, source.HeadManifestHash, previousWal, entries);
        EpochBackupStorage.ValidateData(root, expected);
        // Assert exact transformation, not merely a new internally consistent chain.
        var prior = new byte[32];
        for (ulong sequence = 1; sequence <= source.CommitSequence; sequence++)
        {
            var name = ".transactions/wal/" + EpochAuthorityCodec.WalFileName(sequence);
            var original = EpochAuthorityCodec.DecodeWal(ReadBound(data, files[name]), source.Source);
            var actual = BinaryEnvelope.ReadFile(Path.Combine(root, name));
            if (!actual.AsSpan().SequenceEqual(EpochAuthorityCodec.EncodeWal(original with { Binding = binding, PreviousWalHash = prior })))
                throw new InvalidDataException("Rebound logical operation differs from its source.");
            prior = SHA256.HashData(actual);
        }
        var byPath = entries.ToDictionary(entry => entry.Path, StringComparer.Ordinal);
        foreach (var file in source.Files.Where(file => IsDocumentData(file.Path)))
        {
            var actual = byPath[file.Path];
            if (actual.Length != file.Length || !actual.Hash.AsSpan().SequenceEqual(file.Hash)) throw new InvalidDataException("Restore changed persistent XML data.");
        }
        return expected;
        void Write(string name, byte[] bytes)
        {
            var path = Path.Combine(root, name); TransactionCodec.EnsureDirectory(Path.GetDirectoryName(path)!, storage);
            TransactionCodec.WriteFlushed(path, bytes, storage);
        }
    }

    internal static void InitializeRuntime(string root, EpochBackupInventory expected, ITransactionStorage storage)
    {
        foreach (var relative in new[] { ".epoch", ".transactions/wal", ".transactions/generations", ".transactions/readers", ".transactions/staging" })
            TransactionCodec.EnsureDirectory(Path.Combine(root, relative), storage);
        var format = BinaryEnvelope.ReadFile(Path.Combine(root, "FORMAT"));
        TransactionCodec.WriteFlushed(Path.Combine(root, ".epoch", "admission.lease"), EpochCodec.EncodeBinding("BXEA", expected.Source.Identity, format), storage);
        for (ulong sequence = 0; sequence <= expected.CommitSequence; sequence++)
        {
            var hash = sequence == 0 ? expected.Source.BaseHash : EpochAuthorityCodec.DecodeWal(BinaryEnvelope.ReadFile(
                Path.Combine(root, ".transactions", "wal", EpochAuthorityCodec.WalFileName(sequence))), expected.Source).ManifestHash;
            EpochGenerationReader.Ensure(root, expected.Source, sequence, hash, storage);
        }
    }

    internal static void ValidateRuntime(string root, EpochBackupInventory expected, ITransactionStorage storage)
    {
        EpochBackupStorage.ValidateSourceLayout(root, expected.Files.Select(file => file.Path).ToArray());
        if (Directory.EnumerateFileSystemEntries(Path.Combine(root, ".transactions", "staging")).Any() ||
            Directory.EnumerateFileSystemEntries(Path.Combine(root, ".transactions")).Any(path => EpochScalarHistory.IsCurrentTemporary(Path.GetFileName(path))))
            throw new InvalidDataException("Initial restore contains private publication debris.");
        var readers = Directory.GetFileSystemEntries(Path.Combine(root, ".transactions", "readers")).Select(Path.GetFileName).Order(StringComparer.Ordinal);
        var wanted = Enumerable.Range(0, checked((int)expected.CommitSequence + 1)).Select(value => EpochAuthorityCodec.ReaderFileName((ulong)value));
        if (!readers.SequenceEqual(wanted)) throw new InvalidDataException("Initial restore does not contain exactly the fresh reader identities.");
        using (var owner = EpochScalarCoordinator.Open(root, storage, stage =>
        {
            if (stage is EpochScalarStage.TailDiscarded or EpochScalarStage.RecoveryStageWritten or EpochScalarStage.RecoveryGenerationPublished or EpochScalarStage.RecoveryCurrentPublished)
                throw new InvalidDataException("Initial restore required unexpected recovery repair.");
        }))
        {
            using var snapshot = owner.BeginRead(0);
            if (snapshot.CommitSequence != expected.CommitSequence || !snapshot.ManifestIdentity.AsSpan().SequenceEqual(expected.HeadManifestHash))
                throw new InvalidDataException("Initial restore selected a different head.");
            for (ulong id = 1; id <= (ulong)snapshot.NodeCount; id++) _ = snapshot.ReadValue(id);
        }
        foreach (var entry in expected.Files) _ = ReadBound(root, entry);
    }

    private static void ValidateBundle(string bundle, byte[] sourceInventory, EpochBackupInventory destination, ITransactionStorage storage)
    {
        var entries = Directory.GetFileSystemEntries(bundle);
        foreach (var path in entries) BinaryEnvelope.RejectLinks(path);
        if (entries.Length != 2 || !entries.Select(Path.GetFileName).Order(StringComparer.Ordinal).SequenceEqual(new[] { "origin.bin", "store" }) ||
            !Directory.Exists(Path.Combine(bundle, "store")) || !File.Exists(Path.Combine(bundle, "origin.bin"))) throw new InvalidDataException("Invalid initial restore bundle shape.");
        var root = Path.Combine(bundle, "store");
        EpochBackupCodec.ValidateOriginHeaders(BinaryEnvelope.ReadFile(Path.Combine(bundle, "origin.bin")), sourceInventory,
            BinaryEnvelope.ReadFile(Path.Combine(root, "FORMAT")), BinaryEnvelope.ReadFile(Path.Combine(root, ".transactions", "CURRENT")));
        ValidateRuntime(root, destination, storage);
    }
    internal static byte[] ReadBound(string root, BackupEntry entry)
    {
        var bytes = BinaryEnvelope.ReadFile(Path.Combine(root, entry.Path));
        if (bytes.Length != entry.Length || !SHA256.HashData(bytes).AsSpan().SequenceEqual(entry.Hash)) throw new InvalidDataException("Restore bytes differ from their expected inventory.");
        return bytes;
    }
    internal static bool IsDocumentData(string name) => name.StartsWith("documents/", StringComparison.Ordinal) || name.StartsWith("fragments/", StringComparison.Ordinal) ||
        name.StartsWith(".transactions/generations/", StringComparison.Ordinal) && !name.EndsWith("/FORMAT", StringComparison.Ordinal) && !name.EndsWith("/GENERATION", StringComparison.Ordinal);
    private static Guid Fresh(Guid previous) { Guid value; do { value = Guid.NewGuid(); } while (value == Guid.Empty || value == previous); return value; }
}
