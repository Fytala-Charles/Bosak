// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Encodes bounded epoch backup metadata without enabling capture or restore.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

internal sealed record EpochBackupInventory(Guid BackupId, EpochAuthorityBinding Source, ulong CommitSequence,
    byte[] HeadManifestHash, byte[] HeadWalHash, BackupEntry[] Files);
internal sealed record EpochBackupCompletion(Guid BackupId, byte[] InventoryHash);
internal sealed record EpochRestoreOrigin(Guid RestoreId, Guid BackupId, byte[] InventoryHash, EpochAuthorityBinding Source,
    EpochIdentity Destination, ulong CommitSequence, byte[] DestinationFormatHash, byte[] HeadManifestHash,
    byte[] SourceHeadWalHash, byte[] DestinationHeadWalHash);

internal static class EpochBackupCodec
{
    internal const int MaximumEntries = 100_000;
    internal const int MaximumPathBytes = 512;
    internal const ulong MaximumSequence = 10_000;

    internal static byte[] EncodeInventory(EpochBackupInventory value)
    {
        ValidateInventory(value);
        return BinaryEnvelope.Encode("BXEI", writer =>
        {
            writer.Write((ushort)1); writer.Write(value.BackupId.ToByteArray());
            WriteIdentity(writer, value.Source.Identity); writer.Write(value.Source.FormatHash); writer.Write(value.Source.BaseHash);
            writer.Write(value.CommitSequence); writer.Write(value.HeadManifestHash); writer.Write(value.HeadWalHash);
            writer.Write(value.Files.Length);
            foreach (var entry in value.Files)
            { BinaryEnvelope.WriteString(writer, entry.Path); writer.Write(entry.Length); writer.Write(entry.Hash); }
        });
    }

    internal static EpochBackupInventory DecodeInventory(byte[] bytes) => BinaryEnvelope.Decode(bytes, "BXEI", reader =>
    {
        if (reader.ReadUInt16() != 1) throw new InvalidDataException("Unsupported epoch backup closure contract.");
        var backup = ReadGuid(reader); var source = new EpochAuthorityBinding(ReadIdentity(reader), Hash(reader), Hash(reader));
        var sequence = reader.ReadUInt64(); var head = Hash(reader); var wal = Hash(reader);
        var count = reader.ReadInt32();
        // A nonempty path and its length/file-length/hash consume at least 41 bytes per entry.
        if (count is < 1 or > MaximumEntries || count > Remaining(reader) / 41)
            throw new InvalidDataException("Invalid bounded epoch backup entry count.");
        var entries = new BackupEntry[count];
        for (var index = 0; index < count; index++)
        {
            var length = reader.ReadInt32();
            if (length is < 1 or > MaximumPathBytes || length > Remaining(reader) - 36)
                throw new InvalidDataException("Invalid bounded epoch backup path length.");
            var path = BinaryEnvelope.Utf8.GetString(reader.ReadBytes(length));
            entries[index] = new(path, reader.ReadInt32(), Hash(reader));
        }
        var value = new EpochBackupInventory(backup, source, sequence, head, wal, entries); ValidateInventory(value); return value;
    });

    internal static byte[] EncodeCompletion(EpochBackupCompletion value)
    {
        ValidateCompletionRecord(value);
        return BinaryEnvelope.Encode("BXEZ", writer => { writer.Write(value.BackupId.ToByteArray()); writer.Write(value.InventoryHash); });
    }
    internal static EpochBackupCompletion DecodeCompletion(byte[] bytes) => BinaryEnvelope.Decode(bytes, "BXEZ", reader =>
    {
        var value = new EpochBackupCompletion(ReadGuid(reader), Hash(reader)); ValidateCompletionRecord(value); return value;
    });
    internal static byte[] Complete(byte[] inventory)
    {
        var value = DecodeInventory(inventory); return EncodeCompletion(new(value.BackupId, SHA256.HashData(inventory)));
    }
    internal static EpochBackupInventory ValidateCompletion(byte[] completion, byte[] inventory)
    {
        var value = DecodeInventory(inventory); var complete = DecodeCompletion(completion);
        if (complete.BackupId != value.BackupId || !Same(complete.InventoryHash, SHA256.HashData(inventory)))
            throw new InvalidDataException("Epoch backup completion does not bind its inventory.");
        return value;
    }

    internal static byte[] EncodeOrigin(EpochRestoreOrigin value)
    {
        ValidateOrigin(value);
        return BinaryEnvelope.Encode("BXEO", writer =>
        {
            writer.Write(value.RestoreId.ToByteArray()); writer.Write(value.BackupId.ToByteArray()); writer.Write(value.InventoryHash);
            writer.Write(value.Source.Identity.StoreId.ToByteArray()); writer.Write(value.Source.Identity.EpochId.ToByteArray());
            writer.Write(value.Destination.StoreId.ToByteArray()); writer.Write(value.Destination.EpochId.ToByteArray());
            writer.Write(value.Source.Identity.DocumentId); writer.Write(value.CommitSequence);
            writer.Write(value.Source.FormatHash); writer.Write(value.DestinationFormatHash); writer.Write(value.Source.BaseHash);
            writer.Write(value.HeadManifestHash); writer.Write(value.SourceHeadWalHash); writer.Write(value.DestinationHeadWalHash);
        });
    }
    internal static EpochRestoreOrigin DecodeOrigin(byte[] bytes) => BinaryEnvelope.Decode(bytes, "BXEO", reader =>
    {
        var restore = ReadGuid(reader); var backup = ReadGuid(reader); var inventory = Hash(reader);
        var sourceStore = ReadGuid(reader); var sourceEpoch = ReadGuid(reader); var destinationStore = ReadGuid(reader); var destinationEpoch = ReadGuid(reader);
        var document = reader.ReadUInt64(); var sequence = reader.ReadUInt64();
        var sourceFormat = Hash(reader); var destinationFormat = Hash(reader); var baseHash = Hash(reader); var head = Hash(reader);
        var sourceWal = Hash(reader); var destinationWal = Hash(reader);
        var value = new EpochRestoreOrigin(restore, backup, inventory, new(new(sourceStore, sourceEpoch, document), sourceFormat, baseHash),
            new(destinationStore, destinationEpoch, document), sequence, destinationFormat, head, sourceWal, destinationWal);
        ValidateOrigin(value); return value;
    });

    // Header consistency only: these pure checks do not verify a file closure or grant admission.
    internal static EpochBackupInventory ValidateSourceHeaders(byte[] inventory, byte[] sourceFormat, byte[] sourceCurrent)
    {
        var value = DecodeInventory(inventory);
        var profile = EpochCodec.RequireProfile(sourceFormat, EpochProfile.ScalarWal);
        if (profile.Identity != value.Source.Identity || !Same(SHA256.HashData(sourceFormat), value.Source.FormatHash))
            throw new InvalidDataException("Epoch backup source FORMAT does not match its inventory.");
        var current = EpochAuthorityCodec.DecodeCurrent(sourceCurrent, value.Source);
        if (current.Sequence != value.CommitSequence || !Same(current.ManifestHash, value.HeadManifestHash) || !Same(current.WalHash, value.HeadWalHash))
            throw new InvalidDataException("Epoch backup source CURRENT does not match its inventory.");
        return value;
    }
    internal static EpochRestoreOrigin ValidateOriginHeaders(byte[] origin, byte[] inventory, byte[] destinationFormat, byte[] destinationCurrent)
    {
        var value = DecodeOrigin(origin); var source = DecodeInventory(inventory);
        var profile = EpochCodec.RequireProfile(destinationFormat, EpochProfile.ScalarWal);
        if (value.BackupId != source.BackupId || !Same(value.InventoryHash, SHA256.HashData(inventory)) ||
            value.Source.Identity != source.Source.Identity || !Same(value.Source.FormatHash, source.Source.FormatHash) || !Same(value.Source.BaseHash, source.Source.BaseHash) ||
            value.CommitSequence != source.CommitSequence || !Same(value.HeadManifestHash, source.HeadManifestHash) || !Same(value.SourceHeadWalHash, source.HeadWalHash) ||
            profile.Identity != value.Destination || !Same(value.DestinationFormatHash, SHA256.HashData(destinationFormat)))
            throw new InvalidDataException("Epoch restore origin does not match its expected inventory/FORMAT context.");
        var binding = EpochAuthorityBinding.Create(destinationFormat, source.Source.BaseHash);
        var current = EpochAuthorityCodec.DecodeCurrent(destinationCurrent, binding);
        if (current.Sequence != value.CommitSequence || !Same(current.ManifestHash, value.HeadManifestHash) || !Same(current.WalHash, value.DestinationHeadWalHash))
            throw new InvalidDataException("Epoch restore origin does not match destination CURRENT.");
        return value;
    }

    private static void ValidateInventory(EpochBackupInventory value)
    {
        if (value is null || value.BackupId == Guid.Empty || value.Source is null) throw new InvalidDataException("Invalid epoch backup identity.");
        Binding(value.Source); Head(value.CommitSequence, value.Source.BaseHash, value.HeadManifestHash, value.HeadWalHash);
        if (value.Files is null || value.Files.Length is < 1 or > MaximumEntries) throw new InvalidDataException("Invalid epoch backup file count.");
        var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase); string? previous = null; long bytes = 242;
        foreach (var entry in value.Files)
        {
            if (entry is null) throw new InvalidDataException("Missing epoch backup file entry.");
            ValidatePath(entry.Path); Digest(entry.Hash);
            if (entry.Length < 44 || entry.Length > BinaryEnvelope.MaximumFileBytes || !names.Add(entry.Path) ||
                previous is not null && StringComparer.Ordinal.Compare(previous, entry.Path) >= 0)
                throw new InvalidDataException("Invalid length, duplicate or unordered epoch backup file.");
            bytes += 40 + entry.Path.Length;
            if (bytes > BinaryEnvelope.MaximumFileBytes) throw new InvalidDataException("Epoch backup inventory exceeds its byte limit.");
            previous = entry.Path;
        }
    }
    private static void ValidateCompletionRecord(EpochBackupCompletion value)
    {
        if (value is null || value.BackupId == Guid.Empty) throw new InvalidDataException("Invalid epoch backup completion identity.");
        Digest(value.InventoryHash);
    }
    private static void ValidateOrigin(EpochRestoreOrigin value)
    {
        if (value is null || value.RestoreId == Guid.Empty || value.BackupId == Guid.Empty || value.Source is null)
            throw new InvalidDataException("Invalid epoch restore origin identity.");
        Binding(value.Source); Identity(value.Destination); Digest(value.InventoryHash); Digest(value.DestinationFormatHash);
        if (value.Source.Identity.DocumentId != value.Destination.DocumentId || value.Source.Identity.StoreId == value.Destination.StoreId ||
            value.Source.Identity.EpochId == value.Destination.EpochId) throw new InvalidDataException("Restore requires independent identities and a preserved document.");
        Head(value.CommitSequence, value.Source.BaseHash, value.HeadManifestHash, value.SourceHeadWalHash);
        Head(value.CommitSequence, value.Source.BaseHash, value.HeadManifestHash, value.DestinationHeadWalHash);
    }
    private static void ValidatePath(string path)
    {
        if (path is null || path.Length is < 1 or > MaximumPathBytes || path.Any(c => !char.IsAsciiLetterOrDigit(c) && c is not '/' and not '.' and not '-'))
            throw new InvalidDataException("Invalid portable epoch backup path.");
        foreach (var part in path.Split('/'))
        {
            var stem = part.Split('.')[0].ToUpperInvariant();
            if (part is "" or "." or ".." || part.EndsWith('.') || stem is "CON" or "PRN" or "AUX" or "NUL" ||
                stem.Length == 4 && (stem.StartsWith("COM", StringComparison.Ordinal) || stem.StartsWith("LPT", StringComparison.Ordinal)) && stem[3] is >= '0' and <= '9')
                throw new InvalidDataException("Noncanonical or device-alias epoch backup path.");
        }
    }
    private static void Binding(EpochAuthorityBinding value) { Identity(value.Identity); Digest(value.FormatHash); Digest(value.BaseHash); }
    private static void Identity(EpochIdentity value)
    { if (value is null || value.StoreId == Guid.Empty || value.EpochId == Guid.Empty || value.DocumentId == 0) throw new InvalidDataException("Invalid epoch identity."); }
    private static void Head(ulong sequence, byte[] baseHash, byte[] headHash, byte[] walHash)
    {
        Digest(baseHash); Digest(headHash); Digest(walHash);
        if (sequence > MaximumSequence || (sequence == 0 ? !Same(baseHash, headHash) || !Zero(walHash) : Zero(walHash)))
            throw new InvalidDataException("Invalid epoch backup sequence/head relation.");
    }
    private static void Digest(byte[] value) { if (value is null || value.Length != 32) throw new InvalidDataException("Invalid digest size."); }
    private static bool Same(byte[] a, byte[] b) => a.AsSpan().SequenceEqual(b);
    private static bool Zero(byte[] value) => value.AsSpan().IndexOfAnyExcept((byte)0) < 0;
    private static Guid ReadGuid(BinaryReader reader) => new(reader.ReadBytes(16));
    private static byte[] Hash(BinaryReader reader) { var value = reader.ReadBytes(32); Digest(value); return value; }
    private static long Remaining(BinaryReader reader) => reader.BaseStream.Length - reader.BaseStream.Position;
    private static EpochIdentity ReadIdentity(BinaryReader reader) => new(ReadGuid(reader), ReadGuid(reader), reader.ReadUInt64());
    private static void WriteIdentity(BinaryWriter writer, EpochIdentity value)
    { writer.Write(value.StoreId.ToByteArray()); writer.Write(value.EpochId.ToByteArray()); writer.Write(value.DocumentId); }
}
