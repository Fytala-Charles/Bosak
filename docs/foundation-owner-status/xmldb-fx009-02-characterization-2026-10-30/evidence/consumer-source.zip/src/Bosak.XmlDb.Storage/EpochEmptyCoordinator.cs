// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Coordinates admitted empty mutable epochs and independently protected base snapshots.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 27-10-2026     | Support scalar epoch materializations and verified history selection
// ===========================================================================================================================================================

using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

internal enum EpochCoordinatorStage { AdmissionAcquired, AuthorityValidated, WriterAcquired, ReaderPublished, Opened }

internal sealed class EpochEmptyCoordinator : IDisposable
{
    private readonly object _gate = new();
    private readonly string _root;
    private readonly EpochAdmissionLease _admission;
    private readonly EpochAuthorityBinding _binding;
    private readonly FileStream _writer;
    private bool _disposed;
    private bool _faulted;

    private EpochEmptyCoordinator(string root, EpochAdmissionLease admission, EpochAuthorityBinding binding, FileStream writer)
    { _root = root; _admission = admission; _binding = binding; _writer = writer; }
    internal EpochAuthorityBinding Binding => _binding;

    internal static EpochEmptyCoordinator Open(string root, ITransactionStorage? storage = null, Action<EpochCoordinatorStage>? checkpoint = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(root);
        root = Path.GetFullPath(root); storage ??= new LocalTransactionStorage();
        var identity = EpochAdmission.ReadIdentity(root, EpochProfile.ScalarWal);
        var admission = EpochAdmission.Acquire(root, identity, profile: EpochProfile.ScalarWal);
        FileStream? writer = null;
        try
        {
            checkpoint?.Invoke(EpochCoordinatorStage.AdmissionAcquired);
            var binding = ReadAuthority(root, identity);
            VerifyBase(root, admission, binding.BaseHash);
            checkpoint?.Invoke(EpochCoordinatorStage.AuthorityValidated);
            var writerPath = Path.Combine(root, ".transactions", "writer.lock");
            if (File.Exists(writerPath)) BinaryEnvelope.RejectLinks(writerPath);
            writer = new FileStream(writerPath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
            checkpoint?.Invoke(EpochCoordinatorStage.WriterAcquired);
            // Recheck under writer ownership so prior changes cannot escape validation.
            var rechecked = ReadAuthority(root, identity);
            if (!rechecked.FormatHash.AsSpan().SequenceEqual(binding.FormatHash) || !rechecked.BaseHash.AsSpan().SequenceEqual(binding.BaseHash))
                throw new InvalidDataException("Epoch base/profile changed before writer ownership.");
            if (storage.Durability == DurabilityMode.FileAndDirectoryFlush)
                TransactionCodec.SyncExistingStore(root, writerPath, storage, Path.Combine(root, ".epoch", "admission.lease"));
            storage.SyncDirectory(Path.GetDirectoryName(writerPath)!);
            EpochBaseReader.Ensure(root, binding, storage);
            checkpoint?.Invoke(EpochCoordinatorStage.ReaderPublished);
            var owner = new EpochEmptyCoordinator(root, admission, binding, writer);
            checkpoint?.Invoke(EpochCoordinatorStage.Opened);
            return owner;
        }
        catch { writer?.Dispose(); admission.Dispose(); throw; }
    }

    internal ImmutableXmlSnapshot BeginRead(int cacheBytes = 8 * 1024 * 1024, Action? admitted = null)
    {
        ArgumentOutOfRangeException.ThrowIfNegative(cacheBytes);
        var admission = _admission.ForkShared(); // Must precede coordinator gate; fork preserves explicit profile.
        IDisposable? generation = null;
        try
        {
            admitted?.Invoke();
            lock (_gate)
            {
                ObjectDisposedException.ThrowIf(_disposed, this);
                if (_faulted) throw new InvalidOperationException("Epoch coordinator requires reopen after storage failure.");
                var current = ReadAuthority(_root, _binding.Identity);
                if (!current.BaseHash.AsSpan().SequenceEqual(_binding.BaseHash) || !current.FormatHash.AsSpan().SequenceEqual(_binding.FormatHash))
                    throw new InvalidDataException("Immutable epoch base/profile changed.");
                generation = EpochBaseReader.Acquire(_root, _binding);
                return ImmutableXmlSnapshot.OpenMutableEpochBase(_root, admission, _binding.BaseHash, cacheBytes, generation);
            }
        }
        catch (Exception exception)
        {
            generation?.Dispose(); admission.Dispose();
            if (exception is IOException or InvalidDataException or NotSupportedException) lock (_gate) { if (!_disposed) _faulted = true; }
            throw;
        }
    }

    internal EpochTransactionContext BeginTransaction() => new(this, _binding, BeginRead(0));

    public void Dispose()
    {
        lock (_gate)
        {
            if (_disposed) return;
            _writer.Dispose(); _admission.Dispose(); _disposed = true;
        }
    }

    internal static EpochAuthorityBinding ReadAuthority(string root, EpochIdentity identity, bool allowHistory = false)
    {
        if (EpochAdmission.ReadIdentity(root, EpochProfile.ScalarWal) != identity) throw new InvalidDataException("Epoch identity changed.");
        var format = BinaryEnvelope.ReadFile(Path.Combine(root, "FORMAT"));
        if (EpochCodec.RequireProfile(format, EpochProfile.ScalarWal).Identity != identity) throw new InvalidDataException("Epoch identity changed.");
        var binding = EpochAuthorityBinding.Create(format, TransactionCodec.ManifestHash(root, identity.DocumentId));
        EpochAuthorityCodec.DecodeBase(BinaryEnvelope.ReadFile(Path.Combine(root, "BASE")), binding);
        var transactions = Path.Combine(root, ".transactions"); RequiredDirectory(transactions);
        EpochAuthorityCodec.DecodeControl(BinaryEnvelope.ReadFile(Path.Combine(transactions, "CONTROL")), binding);
        foreach (var name in new[] { "wal", "generations", "readers", "staging" }) RequiredDirectory(Path.Combine(transactions, name));
        foreach (var path in Directory.EnumerateFileSystemEntries(transactions))
        {
            BinaryEnvelope.RejectLinks(path);
            var name = Path.GetFileName(path);
            if (allowHistory && !Directory.Exists(path) && EpochScalarHistory.IsCurrentTemporary(name)) continue;
            if (name is not ("CONTROL" or "CURRENT" or "writer.lock" or "wal" or "generations" or "readers" or "staging"))
                throw new NotSupportedException("ET4 encountered unknown transaction state.");
            if ((name is "CONTROL" or "CURRENT" or "writer.lock") && Directory.Exists(path))
                throw new InvalidDataException("A transaction file role is a directory.");
        }
        if (!allowHistory && (Directory.EnumerateFileSystemEntries(Path.Combine(transactions, "wal")).Any() ||
            Directory.EnumerateFileSystemEntries(Path.Combine(transactions, "generations")).Any()))
            throw new NotSupportedException("ET4 cannot open nonempty WAL or published generation histories.");
        var current = Path.Combine(transactions, "CURRENT");
        if (Directory.Exists(current)) throw new InvalidDataException("CURRENT is not a file.");
        if (File.Exists(current) && EpochAuthorityCodec.DecodeCurrent(BinaryEnvelope.ReadFile(current), binding).Sequence != 0 && !allowHistory)
            throw new NotSupportedException("ET4 cannot select a nonzero published head.");
        if (allowHistory) { EpochGenerationReader.ValidateDirectory(root, binding, null); return binding; }
        foreach (var path in Directory.EnumerateFileSystemEntries(Path.Combine(transactions, "readers")))
        {
            BinaryEnvelope.RejectLinks(path);
            var name = Path.GetFileName(path); var canonical = EpochAuthorityCodec.ReaderFileName(0);
            if (name == canonical) EpochBaseReader.Validate(root, binding);
            else if (Directory.Exists(path) || !name.StartsWith(canonical + ".tmp-", StringComparison.Ordinal) ||
                !Guid.TryParseExact(name[(canonical.Length + 5)..], "N", out _))
                throw new NotSupportedException("ET4 encountered an unsupported reader identity.");
        }
        return binding;
    }

    internal static void VerifyBase(string root, EpochAdmissionLease admission, byte[] hash)
    {
        using var snapshot = ImmutableXmlSnapshot.OpenMutableEpochBase(root, admission.ForkShared(), hash, 0);
        var manifest = StoreCodec.ReadManifest(TransactionCodec.ReadManifestBytes(root, admission.Identity.DocumentId));
        foreach (var entry in manifest.Fragments)
        {
            var path = Path.Combine(root, "fragments", entry.Id.ToString(System.Globalization.CultureInfo.InvariantCulture) + ".bin");
            if (!SHA256.HashData(BinaryEnvelope.ReadFile(path)).AsSpan().SequenceEqual(entry.Hash)) throw new InvalidDataException("Corrupt base fragment.");
        }
        for (ulong id = 1; id <= (ulong)snapshot.NodeCount; id++) _ = snapshot.ReadValue(id);
    }
    private static void RequiredDirectory(string path)
    { if (!Directory.Exists(path)) throw new InvalidDataException("Required epoch directory is missing."); BinaryEnvelope.RejectLinks(path); }
}

internal static class EpochBaseReader
{
    internal static string PathFor(string root) => Path.Combine(root, ".transactions", "readers", EpochAuthorityCodec.ReaderFileName(0));
    internal static void Ensure(string root, EpochAuthorityBinding binding, ITransactionStorage storage)
    {
        var path = PathFor(root);
        if (!File.Exists(path))
        {
            var temporary = path + ".tmp-" + Guid.NewGuid().ToString("N");
            TransactionCodec.WriteFlushed(temporary, EpochAuthorityCodec.EncodeReader(new(binding, 0, binding.BaseHash)), storage);
            TransactionCodec.PublishFile(temporary, path, false, storage);
        }
        Validate(root, binding);
    }
    internal static void Validate(string root, EpochAuthorityBinding binding)
    {
        var record = EpochAuthorityCodec.DecodeReader(BinaryEnvelope.ReadFile(PathFor(root)), binding);
        if (record.Sequence != 0) throw new InvalidDataException("Not an empty-chain reader identity.");
    }
    internal static FileStream Acquire(string root, EpochAuthorityBinding binding)
    {
        var path = PathFor(root); BinaryEnvelope.RejectLinks(path);
        var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        try
        {
            if (stream.Length != 189) throw new InvalidDataException("Invalid base reader identity size.");
            var bytes = new byte[189]; stream.ReadExactly(bytes);
            var record = EpochAuthorityCodec.DecodeReader(bytes, binding);
            if (record.Sequence != 0) throw new InvalidDataException("Not a base reader.");
            return stream;
        }
        catch { stream.Dispose(); throw; }
    }
}

// Ownership/base capture only: scalar staging and Commit are deliberately absent until ET5.
internal sealed class EpochTransactionContext(EpochEmptyCoordinator owner, EpochAuthorityBinding binding, ImmutableXmlSnapshot snapshot) : IDisposable
{
    private readonly byte[] _manifestHash = (byte[])binding.BaseHash.Clone();
    internal Guid TransactionId { get; } = Guid.NewGuid();
    internal EpochEmptyCoordinator Owner => owner;
    internal EpochIdentity Identity => binding.Identity;
    internal ReadOnlyMemory<byte> BaseManifestHash => _manifestHash;
    internal ulong BaseSequence => snapshot.CommitSequence;
    internal string ReadValue(ulong nodeId) => snapshot.ReadValue(nodeId);
    internal Bosak.XmlDb.Core.FragmentReadMetrics Metrics => snapshot.Metrics;
    internal void Rollback() => Dispose();
    public void Dispose() => snapshot.Dispose();
}
