// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Verifies sealed legacy history with strict preflight and independent private redo.
// SPECIAL NOTES        : Internal legacy verification only; no conversion, source recovery, routing or retirement.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 27-10-2026     | Expose strict read-only history inspection to cutover acceptance
//                      | Charles Korthout | 0.3   | 28-10-2026     | Check an optional pinned inventory commitment before private verification output
// ===========================================================================================================================================================

using System.Globalization;
using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

internal enum LegacyMigrationStage { PreflightVerified, CompleteCopied, CompleteVerified, RedoCopied, RedoVerified }

internal static class LegacyMigrationVerifier
{
    // The destination is only a workspace placement hint, never a published store or bundle.
    internal static BackupInventory Verify(string artifact, string destination, ITransactionStorage? storage = null, Action<LegacyMigrationStage>? checkpoint = null, string? expectedInventorySha256 = null)
    {
        storage ??= new LocalTransactionStorage();
        destination = BackupStorage.Destination(artifact, destination);
        var inventoryBytes = BinaryEnvelope.ReadFile(Path.Combine(artifact, "inventory.bin"));
        if (expectedInventorySha256 is not null && Convert.ToHexString(SHA256.HashData(inventoryBytes)).ToLowerInvariant() != expectedInventorySha256)
            throw new InvalidDataException("Legacy inventory differs from the prepared verification commitment.");
        var inventory = ReadArtifact(artifact);
        if (!inventoryBytes.AsSpan().SequenceEqual(BinaryEnvelope.ReadFile(Path.Combine(artifact, "inventory.bin"))))
            throw new InvalidDataException("Legacy inventory changed during verification.");
        var data = Path.Combine(artifact, "data"); ValidateHistory(data, inventory);
        checkpoint?.Invoke(LegacyMigrationStage.PreflightVerified);
        BackupStorage.Preflight(destination, storage);
        var workspace = EpochBackupStorage.Workspace(destination, storage);
        VerifyClone(false); checkpoint?.Invoke(LegacyMigrationStage.CompleteVerified);
        VerifyClone(true); checkpoint?.Invoke(LegacyMigrationStage.RedoVerified);
        ReadArtifact(artifact);
        if (!inventoryBytes.AsSpan().SequenceEqual(BinaryEnvelope.ReadFile(Path.Combine(artifact, "inventory.bin"))))
            throw new InvalidDataException("Legacy inventory changed after verification.");
        EpochBackupStorage.RemoveWorkspace(workspace, storage);
        return inventory;

        void VerifyClone(bool redo)
        {
            var clone = Path.Combine(workspace, redo ? "verify-redo" : "verify-complete");
            var names = inventory.Files.Where(file => !redo || !file.Path.StartsWith(".transactions/generations/", StringComparison.Ordinal)).Select(file => file.Path).ToArray();
            Compare(BackupStorage.Copy(data, clone, names, storage), inventory.Files.Where(file => !redo || !file.Path.StartsWith(".transactions/generations/", StringComparison.Ordinal)));
            checkpoint?.Invoke(redo ? LegacyMigrationStage.RedoCopied : LegacyMigrationStage.CompleteCopied);
            // The callback cannot smuggle a different copy into recovery. No source path is opened live.
            EpochBackupStorage.ExactTree(clone, names); CompareFiles(clone, inventory.Files.Where(file => !redo || !file.Path.StartsWith(".transactions/generations/", StringComparison.Ordinal)));
            if (!redo) ValidateHistory(clone, inventory);
            var published = 0;
            using (var owner = EmbeddedXmlDatabase.OpenCore(clone, inventory.Identity.DocumentId, stage =>
            {
                if (stage == CommitStage.GenerationPublished) published++;
                if (!redo && stage is not (CommitStage.RootTemporaryFlushed or CommitStage.RootPublished))
                    throw new InvalidDataException("Complete legacy verifier attempted materialization repair.");
            }, storage, RecoveryMode.FullJournal))
            {
                if (owner.CommitSequence != inventory.Identity.CommitSequence ||
                    owner.LastRecovery.GenerationsReplayed != (redo ? (int)inventory.Identity.CommitSequence : 0) ||
                    published != (redo ? (int)inventory.Identity.CommitSequence : 0))
                    throw new InvalidDataException("Legacy verifier selected or replayed a different history.");
                CompareFiles(clone, inventory.Files); ValidateHistory(clone, inventory);
                using var read = owner.BeginRead(0);
                if (read.CommitSequence != inventory.Identity.CommitSequence) throw new InvalidDataException("Legacy verifier selected a different head.");
            }
            EpochBackupStorage.RemoveClone(workspace, clone, storage);
        }
    }

    internal static BackupInventory ReadArtifact(string root)
    {
        try
        {
            BinaryEnvelope.RejectLinks(root);
            var bytes = BinaryEnvelope.ReadFile(Path.Combine(root, "inventory.bin"));
            var inventory = EpochMigrationCodec.ReadSourceInventory(bytes);
            BackupCodec.ValidateCompletion(BinaryEnvelope.ReadFile(Path.Combine(root, "COMPLETE")), bytes);
            var names = inventory.Files.Select(file => file.Path).ToArray();
            EpochBackupStorage.ExactTree(root, names.Select(name => "data/" + name).Append("inventory.bin").Append("COMPLETE"));
            var data = Path.Combine(root, "data"); CompareFiles(data, inventory.Files);
            if (!BackupStorage.FileSet(data, inventory.Identity.DocumentId, inventory.Identity.CommitSequence).SequenceEqual(names))
                throw new InvalidDataException("Legacy artifact does not declare exact full-history closure.");
            return inventory;
        }
        catch (Exception exception) when (exception is FileNotFoundException or DirectoryNotFoundException)
        { throw new InvalidDataException("Legacy artifact has missing required files.", exception); }
    }

    internal static void ValidateHistory(string data, BackupInventory inventory)
    {
        var identity = inventory.Identity; var format = BinaryEnvelope.ReadFile(Path.Combine(data, "FORMAT"));
        BinaryEnvelope.Decode(format, "BXDB", reader =>
        { if (reader.ReadByte() != 0) throw new InvalidDataException("Unsupported legacy format flags."); return true; });
        var control = TransactionCodec.ReadPointer(Path.Combine(data, ".transactions", "CONTROL"), "BXTC");
        if (control.DocumentId != identity.DocumentId || control.Sequence != 0 || !Same(control.ManifestHash, inventory.BaseHash))
            throw new InvalidDataException("Legacy control differs from captured base.");
        Materialization(data, identity.DocumentId, inventory.BaseHash, format);
        var previousHash = inventory.BaseHash; var previousRoot = data; var ids = new HashSet<Guid>();
        for (ulong sequence = 1; sequence <= identity.CommitSequence; sequence++)
        {
            var record = TransactionCodec.ReadWal(Path.Combine(data, ".transactions", "wal", Name(sequence) + ".wal"));
            if (record is null || record.DocumentId != identity.DocumentId || record.Sequence != sequence ||
                !ids.Add(record.TransactionId) || !Same(record.PreviousManifestHash, previousHash))
                throw new InvalidDataException("Legacy WAL is incomplete or has broken identity/sequence/transaction/hash links.");
            var currentRoot = Path.Combine(data, ".transactions", "generations", Name(sequence));
            Materialization(currentRoot, identity.DocumentId, record.ManifestHash, format);
            using var previous = ImmutableXmlSnapshot.OpenVersion(previousRoot, identity.DocumentId, sequence - 1);
            using var current = ImmutableXmlSnapshot.OpenVersion(currentRoot, identity.DocumentId, sequence);
            try { ScalarGeneration.ValidateReplacement(previous, record.NodeId, record.Value); }
            catch (Exception exception) when (exception is ArgumentException or NotSupportedException or System.Xml.XmlException)
            { throw new InvalidDataException("Legacy WAL has unsupported scalar semantics.", exception); }
            EpochScalarHistory.ValidateTransition(previous, current, record.NodeId, record.Value);
            previousHash = record.ManifestHash; previousRoot = currentRoot;
        }
        if (!Same(previousHash, inventory.HeadHash)) throw new InvalidDataException("Legacy history differs from captured head.");
        var currentPath = Path.Combine(data, ".transactions", "CURRENT");
        if (identity.CommitSequence == 0)
        {
            if (File.Exists(currentPath)) throw new InvalidDataException("Sealed legacy zero-head closure omits CURRENT.");
        }
        else if (!BinaryEnvelope.ReadFile(currentPath).AsSpan().SequenceEqual(TransactionCodec.EncodePointer(new(identity.DocumentId, identity.CommitSequence, inventory.HeadHash), "BXHD")))
            throw new InvalidDataException("Legacy CURRENT is not the exact captured head.");
    }

    private static void Materialization(string root, ulong documentId, byte[] hash, byte[] format)
    {
        if (!BinaryEnvelope.ReadFile(Path.Combine(root, "FORMAT")).AsSpan().SequenceEqual(format)) throw new InvalidDataException("Mixed legacy generation format.");
        ScalarGeneration.Validate(root, documentId, hash);
        using var read = ImmutableXmlSnapshot.OpenVersion(root, documentId, 0);
        for (ulong id = 1; id <= (ulong)read.NodeCount; id++) _ = read.ReadValue(id);
    }
    private static void CompareFiles(string root, IEnumerable<BackupEntry> files) => Compare(files.Select(file =>
    { var bytes = BinaryEnvelope.ReadFile(Path.Combine(root, file.Path)); return new BackupEntry(file.Path, bytes.Length, SHA256.HashData(bytes)); }), files);
    private static void Compare(IEnumerable<BackupEntry> actual, IEnumerable<BackupEntry> expected)
    {
        using var a = actual.GetEnumerator(); using var b = expected.GetEnumerator();
        while (b.MoveNext())
            if (!a.MoveNext() || a.Current.Path != b.Current.Path || a.Current.Length != b.Current.Length || !Same(a.Current.Hash, b.Current.Hash))
                throw new InvalidDataException("Legacy verification copy differs from committed bytes.");
        if (a.MoveNext()) throw new InvalidDataException("Unexpected legacy verification copy entry.");
    }
    private static bool Same(byte[] a, byte[] b) => a.AsSpan().SequenceEqual(b);
    private static string Name(ulong sequence) => sequence.ToString("D20", CultureInfo.InvariantCulture);
}
