// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Classifies supplied restart observations without granting routing or write authority.
// SPECIAL NOTES        : Pure internal HC1 model; caller observations are assumptions, not independently verified facts.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 28-10-2026     | Reconcile malformed null candidate identity instead of dereferencing it
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal enum RestartRoute { Unknown, Legacy, Candidate, Other }
internal enum RestartIntent { Candidate, LegacyReturn }
internal enum RestartOutcome { NotRequested, KnownNotApplied, KnownApplied, AcknowledgmentLost }
internal enum RestartWork { Unknown, ZeroAcceptedAndDrained, Accepted, Contradictory }
internal enum RestartHistory { Unknown, ExactInitial, Changed }
internal enum RestartDecision { ReconciliationRequired, CandidateRetained, NewSourceReadinessEligible, NewCandidateReadinessEligible }
internal enum RestartReason { ReadyForNewWorkflow, NoRouteRequest, MissingEvidence, InvalidContext, ContextMismatch, StaleObservation, WriterExclusionUnknown, HistoryChangedOrUnknown, WorkAcceptedOrUnknown, RouteUnknown, RevisionUnconfirmed, TargetMismatch, OutcomeContradiction }

// Opaque canonical root keys and digests are supplied by a future host; no path resolution,
// storage verification, authenticated provenance or durable record parsing occurs here.
internal sealed record RestartContext(Guid OperationId, Guid MigrationId, Guid BackupId, EpochIdentity CandidateIdentity,
    string SourceRoot, string CandidateRoot, ulong Sequence, string SourceCommitment, string CandidateCommitment);
internal sealed record RestartOwnership(RestartContext Context, bool Fresh, bool ExternalExclusionEstablished, bool NoPossibleWriterOverlap, bool OwnersReacquired);
internal sealed record RestartHistories(RestartContext Context, bool Fresh, RestartHistory Source, RestartHistory Candidate);
internal sealed record RestartWorkAccounting(RestartContext Context, bool Fresh, RestartWork State);
internal sealed record RestartRouting(RestartContext Context, bool Fresh, bool Authoritative, string Revision, string ConfirmedRevision,
    RestartRoute Target, string TargetRoot, EpochIdentity? TargetEpoch, RestartIntent Intent, RestartOutcome Outcome);
internal sealed record RestartObservations(RestartContext? Expected, RestartOwnership? Ownership, RestartHistories? Histories,
    RestartWorkAccounting? Work, RestartRouting? Routing);
internal sealed record RestartClassification(RestartDecision Decision, RestartReason Reason)
{
    internal bool WritersMustRemainStopped => true;
}

internal static class MigrationRestartClassifier
{
    internal static RestartClassification Classify(RestartObservations? observations)
    {
        if (observations is not { Expected: { } expected, Ownership: { } ownership, Histories: { } histories, Work: { } work, Routing: { } route })
            return Reject(RestartReason.MissingEvidence);
        if (!Valid(expected)) return Reject(RestartReason.InvalidContext);
        if (ownership.Context != expected || histories.Context != expected || work.Context != expected || route.Context != expected)
            return Reject(RestartReason.ContextMismatch);
        if (!ownership.Fresh || !histories.Fresh || !work.Fresh || !route.Fresh) return Reject(RestartReason.StaleObservation);
        if (!ownership.ExternalExclusionEstablished || !ownership.NoPossibleWriterOverlap || !ownership.OwnersReacquired)
            return Reject(RestartReason.WriterExclusionUnknown);
        if (histories.Source != RestartHistory.ExactInitial || histories.Candidate != RestartHistory.ExactInitial)
            return Reject(RestartReason.HistoryChangedOrUnknown);
        if (work.State != RestartWork.ZeroAcceptedAndDrained) return Reject(RestartReason.WorkAcceptedOrUnknown);
        if (!route.Authoritative || route.Target is not (RestartRoute.Legacy or RestartRoute.Candidate)) return Reject(RestartReason.RouteUnknown);
        if (string.IsNullOrWhiteSpace(route.Revision) || route.Revision != route.ConfirmedRevision) return Reject(RestartReason.RevisionUnconfirmed);
        if (route.Target == RestartRoute.Legacy ? route.TargetRoot != expected.SourceRoot || route.TargetEpoch is not null :
            route.TargetRoot != expected.CandidateRoot || route.TargetEpoch != expected.CandidateIdentity)
            return Reject(RestartReason.TargetMismatch);
        if (!Enum.IsDefined(route.Intent) || !Enum.IsDefined(route.Outcome)) return Reject(RestartReason.OutcomeContradiction);
        if (route.Outcome == RestartOutcome.NotRequested)
            return route.Intent == RestartIntent.Candidate && route.Target == RestartRoute.Legacy ?
                new(RestartDecision.CandidateRetained, RestartReason.NoRouteRequest) : Reject(RestartReason.OutcomeContradiction);
        var intended = route.Intent == RestartIntent.Candidate ? RestartRoute.Candidate : RestartRoute.Legacy;
        if (route.Outcome == RestartOutcome.KnownApplied && route.Target != intended ||
            route.Outcome == RestartOutcome.KnownNotApplied && route.Target == intended) return Reject(RestartReason.OutcomeContradiction);
        // Lost acknowledgment is resolved only by the supplied fresh authoritative, bound
        // revision/target observation. This result neither replays a receipt nor resumes work.
        return new(route.Target == RestartRoute.Legacy ? RestartDecision.NewSourceReadinessEligible : RestartDecision.NewCandidateReadinessEligible,
            RestartReason.ReadyForNewWorkflow);
    }
    private static RestartClassification Reject(RestartReason reason) => new(RestartDecision.ReconciliationRequired, reason);
    private static bool Valid(RestartContext context) => context.OperationId != Guid.Empty && context.MigrationId != Guid.Empty && context.BackupId != Guid.Empty &&
        context.CandidateIdentity is not null && context.CandidateIdentity.StoreId != Guid.Empty && context.CandidateIdentity.EpochId != Guid.Empty && context.CandidateIdentity.DocumentId != 0 &&
        context.Sequence <= 10_000 && !string.IsNullOrWhiteSpace(context.SourceRoot) && !string.IsNullOrWhiteSpace(context.CandidateRoot) &&
        !string.Equals(context.SourceRoot, context.CandidateRoot, StringComparison.OrdinalIgnoreCase) &&
        Digest(context.SourceCommitment) && Digest(context.CandidateCommitment);
    private static bool Digest(string? value) => value is { Length: 64 } && value.All(character => character is >= '0' and <= '9' or >= 'a' and <= 'f');
}
