// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Classifies supplied pilot authority evidence while keeping application writers stopped.
// SPECIAL NOTES        : Pure internal EP7-A model; supplied observations are assumptions, not verified host authority.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Collections.Immutable;

namespace Bosak.XmlDb.Storage;

internal enum PilotRootKind { Legacy, ScalarEpoch }
internal enum PilotBranch { Source, Candidate }
internal enum PilotWorkOutcome { Unknown, Committed, NoEffect }
internal enum PilotAuthorityDecision { ReconciliationRequired, NewSourceReadinessEligible, NewCandidateReadinessEligible }
internal enum PilotAuthorityReason
{
    MissingEvidence, InvalidContext, ContextMismatch, StaleEvidence, CapacityExhausted,
    OwnershipUnknown, AuthorityUnconfirmed, SelectionUnconfirmed, HistoriesUnconfirmed,
    PublicationUnconfirmed, AccountingUnknown, InvalidWorkEvidence, DuplicateWork,
    WorkOutcomeUnknown, WorkAccepted, ReadyForNewWorkflow
}

// Root/admission keys are opaque canonical identities supplied by the host. No paths are resolved.
internal sealed record PilotRootBinding(PilotRootKind Kind, string RootKey, string AdmissionKey,
    ulong DocumentId, EpochIdentity? Epoch, ulong InitialSequence, string InitialHistoryDigest);
internal sealed record PilotPublicationPin(Guid AttemptId, string ArtifactDigest, ulong AdministrativeSequence, string AdministrativeHeadDigest);
internal sealed record PilotAuthorityContext(Guid AuthorityId, Guid AdministrativeJournalId, string Deployment,
    string ResourceScope, Guid OwnerSession, Guid BaselineId, PilotRootBinding Source, PilotRootBinding Candidate,
    PilotPublicationPin Publication, ulong Sequence, string HeadDigest, ulong SelectionRevision, PilotBranch Selected);
internal sealed record PilotAuthorityOwnership(PilotAuthorityContext Context, bool Fresh, bool OwnersHeld,
    bool AllWritersAndPublishersExcluded, bool IngressClosed, bool ActualOperationsDrained);
internal sealed record PilotAuthorityObservation(PilotAuthorityContext Context, bool Fresh, bool CompleteHistoryValidated,
    bool IndependentFreshnessEstablished, bool EnrollmentBaselineReconciled, bool SelectionAcknowledgmentKnown);
internal sealed record PilotAuthorityHistories(PilotAuthorityContext Context, bool Fresh, bool IndependentlyVerified,
    PilotRootBinding Source, PilotRootBinding Candidate);
internal sealed record PilotAuthorityPublication(PilotAuthorityContext Context, bool Fresh, bool ExactAttemptMatched,
    bool AdministrativeHistoryAgrees);
internal sealed record PilotWorkAcceptance(Guid WorkId, Guid BaselineId, PilotBranch Branch, PilotRootBinding Target,
    ulong SelectionRevision, string IntentDigest, PilotWorkOutcome Outcome);
internal sealed record PilotAuthorityWork(PilotAuthorityContext Context, bool Fresh, bool Complete,
    bool PriorWorkReconciled, ulong? SourceAccepted, ulong? CandidateAccepted, ImmutableArray<PilotWorkAcceptance> Acceptances);
internal sealed record PilotAuthorityEvidence(PilotAuthorityContext? Expected, PilotAuthorityOwnership? Ownership,
    PilotAuthorityObservation? Authority, PilotAuthorityHistories? Histories,
    PilotAuthorityPublication? Publication, PilotAuthorityWork? Work);
internal sealed record PilotAuthorityClassification(PilotAuthorityDecision Decision, PilotAuthorityReason Reason)
{
    internal bool WritersMustRemainStopped => true;
}

/// <summary>Classifies supplied pilot authority evidence while keeping application writers stopped.</summary>
internal static class EmbeddedPilotAuthorityClassifier
{
    // A model input bound, not a persistent format limit or permission to truncate retained history.
    internal const int MaximumWorkRecords = 1024;

    internal static PilotAuthorityClassification Classify(PilotAuthorityEvidence? evidence)
    {
        if (evidence is not
            {
                Expected: { } expected, Ownership: { } owner, Authority: { } authority,
                Histories: { } histories, Publication: { } publication, Work: { } work
            }) return Reject(PilotAuthorityReason.MissingEvidence);
        if (!Valid(expected)) return Reject(PilotAuthorityReason.InvalidContext);
        if (owner.Context != expected || authority.Context != expected || histories.Context != expected ||
            publication.Context != expected || work.Context != expected) return Reject(PilotAuthorityReason.ContextMismatch);
        if (!owner.Fresh || !authority.Fresh || !histories.Fresh || !publication.Fresh || !work.Fresh)
            return Reject(PilotAuthorityReason.StaleEvidence);
        // Reject exhausted next-step positions without arithmetic that could wrap.
        if (expected.Sequence == ulong.MaxValue || expected.SelectionRevision == ulong.MaxValue ||
            expected.Publication.AdministrativeSequence == ulong.MaxValue)
            return Reject(PilotAuthorityReason.CapacityExhausted);
        if (!owner.OwnersHeld || !owner.AllWritersAndPublishersExcluded || !owner.IngressClosed || !owner.ActualOperationsDrained)
            return Reject(PilotAuthorityReason.OwnershipUnknown);
        if (!authority.CompleteHistoryValidated || !authority.IndependentFreshnessEstablished || !authority.EnrollmentBaselineReconciled)
            return Reject(PilotAuthorityReason.AuthorityUnconfirmed);
        if (!authority.SelectionAcknowledgmentKnown) return Reject(PilotAuthorityReason.SelectionUnconfirmed);
        if (!histories.IndependentlyVerified || histories.Source != expected.Source || histories.Candidate != expected.Candidate)
            return Reject(PilotAuthorityReason.HistoriesUnconfirmed);
        if (!publication.ExactAttemptMatched || !publication.AdministrativeHistoryAgrees)
            return Reject(PilotAuthorityReason.PublicationUnconfirmed);
        if (!work.Complete || !work.PriorWorkReconciled || work.SourceAccepted is null || work.CandidateAccepted is null || work.Acceptances.IsDefault)
            return Reject(PilotAuthorityReason.AccountingUnknown);
        if (work.Acceptances.Length > MaximumWorkRecords || work.SourceAccepted > MaximumWorkRecords || work.CandidateAccepted > MaximumWorkRecords)
            return Reject(PilotAuthorityReason.CapacityExhausted);

        var ids = new HashSet<Guid>();
        ulong sourceCount = 0, candidateCount = 0;
        var unresolved = false;
        foreach (var acceptance in work.Acceptances)
        {
            if (acceptance is null || acceptance.WorkId == Guid.Empty || acceptance.BaselineId != expected.BaselineId ||
                !Enum.IsDefined(acceptance.Branch) || !Enum.IsDefined(acceptance.Outcome) || !Hash(acceptance.IntentDigest) ||
                acceptance.SelectionRevision == 0 || acceptance.SelectionRevision > expected.SelectionRevision ||
                acceptance.SelectionRevision == expected.SelectionRevision && acceptance.Branch != expected.Selected ||
                acceptance.Target != (acceptance.Branch == PilotBranch.Source ? expected.Source : expected.Candidate))
                return Reject(PilotAuthorityReason.InvalidWorkEvidence);
            if (!ids.Add(acceptance.WorkId)) return Reject(PilotAuthorityReason.DuplicateWork);
            if (acceptance.Branch == PilotBranch.Source) sourceCount++; else candidateCount++;
            unresolved |= acceptance.Outcome == PilotWorkOutcome.Unknown;
        }
        if (sourceCount != work.SourceAccepted || candidateCount != work.CandidateAccepted)
            return Reject(PilotAuthorityReason.InvalidWorkEvidence);
        if (unresolved) return Reject(PilotAuthorityReason.WorkOutcomeUnknown);
        // Completed and no-effect work retain the acceptance obligation. Never subtract it.
        if (sourceCount != 0 || candidateCount != 0) return Reject(PilotAuthorityReason.WorkAccepted);
        return new(expected.Selected == PilotBranch.Source ? PilotAuthorityDecision.NewSourceReadinessEligible :
            PilotAuthorityDecision.NewCandidateReadinessEligible, PilotAuthorityReason.ReadyForNewWorkflow);
    }

    private static PilotAuthorityClassification Reject(PilotAuthorityReason reason) => new(PilotAuthorityDecision.ReconciliationRequired, reason);

    private static bool Valid(PilotAuthorityContext context) =>
        context.AuthorityId != Guid.Empty && context.AdministrativeJournalId != Guid.Empty && context.OwnerSession != Guid.Empty &&
        context.BaselineId != Guid.Empty && Text(context.Deployment) && Text(context.ResourceScope) && context.Sequence != 0 &&
        Hash(context.HeadDigest) && context.SelectionRevision != 0 && context.SelectionRevision <= context.Sequence && Enum.IsDefined(context.Selected) &&
        Root(context.Source) && Root(context.Candidate) && context.Candidate.Kind == PilotRootKind.ScalarEpoch &&
        context.Source.DocumentId == context.Candidate.DocumentId && context.Source.InitialSequence == context.Candidate.InitialSequence &&
        !string.Equals(context.Source.RootKey, context.Candidate.RootKey, StringComparison.OrdinalIgnoreCase) &&
        !string.Equals(context.Source.AdmissionKey, context.Candidate.AdmissionKey, StringComparison.OrdinalIgnoreCase) &&
        (context.Source.Epoch is null || context.Source.Epoch.StoreId != context.Candidate.Epoch!.StoreId &&
            context.Source.Epoch.EpochId != context.Candidate.Epoch.EpochId) &&
        context.Publication is { AttemptId: var attempt, AdministrativeSequence: > 0 } pin && attempt != Guid.Empty &&
        Hash(pin.ArtifactDigest) && Hash(pin.AdministrativeHeadDigest);

    private static bool Root(PilotRootBinding? root) => root is not null && Enum.IsDefined(root.Kind) && Text(root.RootKey) &&
        Text(root.AdmissionKey) && root.DocumentId != 0 && root.InitialSequence <= 10_000 && Hash(root.InitialHistoryDigest) &&
        (root.Kind == PilotRootKind.Legacy ? root.Epoch is null : root.Epoch is { StoreId: var store, EpochId: var epoch } identity &&
            store != Guid.Empty && epoch != Guid.Empty && identity.DocumentId == root.DocumentId);
    private static bool Text(string? value) => !string.IsNullOrWhiteSpace(value) && value.Length <= 4096 && !value.Contains('\0');
    private static bool Hash(string? value) => value is { Length: 64 } && value.All(c => c is >= '0' and <= '9' or >= 'a' and <= 'f');
}
