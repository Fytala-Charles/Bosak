// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Encodes the versioned transaction journal and publication pointer.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      | Charles Korthout | 0.2   | 26-10-2026     | Add injected file operations and explicit namespace barriers
//                      | Charles Korthout | 0.3   | 26-10-2026     | Add checkpoint stages; preserve live reader lease files
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.4   | 27-10-2026     | Add backup publication stages and owned-workspace cleanup seam
//                      | Charles Korthout | 0.5   | 27-10-2026     | Add explicit-profile empty-chain ownership and stable lease protection
// ===========================================================================================================================================================

using System.Buffers.Binary;
using System.Security.Cryptography;



namespace Bosak.XmlDb.Storage;

internal sealed record WalRecord(ulong DocumentId, ulong Sequence, Guid TransactionId,
    ulong NodeId, string Value, byte[] PreviousManifestHash, byte[] ManifestHash);
internal sealed record RootPointer(ulong DocumentId, ulong Sequence, byte[] ManifestHash);

internal enum CommitStage
{
    BackupVerificationOpened, RestoreVerificationOpened,
    BackupCopied, BackupVerified, BackupInventoryFlushed, BackupCompleted, BackupPublished,
    RestoreCopied, RestoreVerified, RestorePublished,
    StageCreated,
    FragmentsFlushed,
    DirectoryFlushed,
    ManifestFlushed,
    BeforeWal,
    WalPrefixWritten,
    WalWritten,
    WalFlushed,
    GenerationPublished,
    RootTemporaryFlushed,
    RootPublished,
    CheckpointStageCreated,
    CheckpointFilesFlushed,
    CheckpointAnchorFlushed,
    CheckpointDirectoryPublished,
    CheckpointSelectorTemporaryFlushed,
    CheckpointSelectorPublished,
}

internal static class TransactionCodec
{
    internal static byte[] EncodeWal(WalRecord record) => BinaryEnvelope.Encode("BXWL", writer =>
    {
        writer.Write(record.DocumentId);
        writer.Write(record.Sequence);
        writer.Write(record.TransactionId.ToByteArray());
        writer.Write(record.NodeId);
        BinaryEnvelope.WriteString(writer, record.Value);
        writer.Write(record.PreviousManifestHash);
        writer.Write(record.ManifestHash);
    });

    internal static WalRecord? ReadWal(string path)
    {
        BinaryEnvelope.RejectLinks(path);
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        if (stream.Length > BinaryEnvelope.MaximumFileBytes) throw new InvalidDataException("Oversized WAL record.");
        var bytes = new byte[(int)stream.Length];
        stream.ReadExactly(bytes);
        // Only a physically incomplete final append can be ignored by recovery.
        if (bytes.Length < 12) return null;
        var bodyLength = BinaryPrimitives.ReadInt32LittleEndian(bytes.AsSpan(8));
        if (!bytes.AsSpan(0, 4).SequenceEqual("BXWL"u8) ||
            BinaryPrimitives.ReadUInt16LittleEndian(bytes.AsSpan(4)) != 1 ||
            BinaryPrimitives.ReadUInt16LittleEndian(bytes.AsSpan(6)) != 0 ||
            bodyLength < 0 || bodyLength > BinaryEnvelope.MaximumFileBytes - 44)
            throw new InvalidDataException("Invalid WAL header.");
        if (bytes.Length < (long)bodyLength + 44) return null;
        return BinaryEnvelope.Decode(bytes, "BXWL", reader =>
        {
            var document = reader.ReadUInt64();
            var sequence = reader.ReadUInt64();
            var transaction = new Guid(reader.ReadBytes(16));
            var node = reader.ReadUInt64();
            var value = BinaryEnvelope.ReadString(reader);
            var previous = reader.ReadBytes(32);
            var next = reader.ReadBytes(32);
            if (document == 0 || sequence == 0 || transaction == Guid.Empty || node == 0 || previous.Length != 32 || next.Length != 32)
                throw new InvalidDataException("Invalid WAL record.");
            return new WalRecord(document, sequence, transaction, node, value, previous, next);
        });
    }

    internal static byte[] EncodePointer(RootPointer pointer, string magic) => BinaryEnvelope.Encode(magic, writer =>
    {
        writer.Write(pointer.DocumentId);
        writer.Write(pointer.Sequence);
        writer.Write(pointer.ManifestHash);
    });

    internal static RootPointer ReadPointer(string path, string magic) => BinaryEnvelope.Decode(BinaryEnvelope.ReadFile(path), magic, reader =>
    {
        var pointer = new RootPointer(reader.ReadUInt64(), reader.ReadUInt64(), reader.ReadBytes(32));
        if (pointer.DocumentId == 0 || pointer.ManifestHash.Length != 32)
            throw new InvalidDataException("Invalid transaction control pointer.");
        return pointer;
    });

    internal static void WriteFlushed(string path, byte[] bytes, ITransactionStorage storage)
    {
        using (var file = storage.CreateFile(path))
        {
            file.Write(bytes);
            file.FlushToDisk();
        }
        storage.SyncDirectory(Path.GetDirectoryName(path)!);
    }

    internal static void EnsureDirectory(string path, ITransactionStorage storage)
    {
        if (Directory.Exists(path)) { BinaryEnvelope.RejectLinks(path); return; }
        if (File.Exists(path)) throw new IOException("A file occupies a required transaction directory.");
        var parent = Path.GetDirectoryName(path) ?? throw new IOException("Invalid transaction directory.");
        EnsureDirectory(parent, storage);
        storage.CreateDirectory(path);
        BinaryEnvelope.RejectLinks(path);
        storage.SyncDirectory(parent);
    }

    internal static void PublishGeneration(string source, string destination, ITransactionStorage storage)
    {
        storage.MoveDirectory(source, destination);
        storage.SyncDirectory(Path.GetDirectoryName(source)!);
        storage.SyncDirectory(Path.GetDirectoryName(destination)!);
    }

    internal static void PublishFile(string source, string destination, bool overwrite, ITransactionStorage storage)
    {
        if (File.Exists(destination)) BinaryEnvelope.RejectLinks(destination);
        storage.MoveFile(source, destination, overwrite);
        storage.SyncDirectory(Path.GetDirectoryName(destination)!);
    }

    internal static void SyncExistingStore(string root, string leasePath, ITransactionStorage storage, string? admissionPath = null)
    {
        var visited = 0;
        var directories = new Stack<(string Path, bool ChildrenDone, int Depth)>();
        directories.Push((root, false, 0));
        while (directories.TryPop(out var entry))
        {
            if (entry.Depth > 512 || ++visited > 2_000_000)
                throw new InvalidDataException("Store exceeds the directory-barrier traversal limits.");
            BinaryEnvelope.RejectLinks(entry.Path);
            if (entry.ChildrenDone) { storage.SyncDirectory(entry.Path); continue; }
            directories.Push((entry.Path, true, entry.Depth));
            foreach (var file in Directory.EnumerateFiles(entry.Path).Order(StringComparer.Ordinal))
            {
                if (string.Equals(file, leasePath, OperatingSystem.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal)) continue;
                if (++visited > 2_000_000) throw new InvalidDataException("Store exceeds the directory-barrier file limit.");
                if (GenerationLease.IsStableLease(root, file) || admissionPath is not null && string.Equals(file, admissionPath, OperatingSystem.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal)) { BinaryEnvelope.RejectLinks(file); continue; }
                storage.SyncFile(file);
            }
            foreach (var directory in Directory.EnumerateDirectories(entry.Path).Order(StringComparer.Ordinal))
                directories.Push((directory, false, entry.Depth + 1));
        }
        // The imported root and its containing directory may themselves have been newly created by M1.
        for (var parent = Directory.GetParent(root); parent is not null; parent = parent.Parent)
            storage.SyncDirectory(parent.FullName);
    }
    internal static string DocumentPath(string root, ulong documentId) =>
        Path.Combine(root, "documents", documentId.ToString(System.Globalization.CultureInfo.InvariantCulture));

    internal static byte[] ReadManifestBytes(string root, ulong documentId) =>
        BinaryEnvelope.ReadFile(Path.Combine(DocumentPath(root, documentId), "manifest.bin"));

    internal static byte[] ManifestHash(string root, ulong documentId) => SHA256.HashData(ReadManifestBytes(root, documentId));
}






