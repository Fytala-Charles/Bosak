// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Explicitly provisions an absent controlled host root without overwriting or repair.
// SPECIAL NOTES        : Internal ProcessCrash pilot; retained partial roots are not resumable provisioning plans.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal enum HostProvisionStage
{
    PreflightValidated, RootCreated, OwnerCreated, OwnerFlushed, MetadataCreated, MetadataWritten,
    MetadataFlushed, JournalCreated, JournalFlushed, NamespaceVerified, BeforeReturn
}
internal sealed record EmbeddedHostProvisioningEvidence(string Root, string Deployment, string ResourceScope,
    bool Fresh, bool ControlledProvisionersOnly, bool NoPriorHost);

internal sealed partial class EmbeddedHostLifetime
{
    internal static EmbeddedHostLifetime Provision(string root, string deployment, string scope, IReadOnlyList<string> protectedRoots,
        EmbeddedHostProvisioningEvidence evidence, DurabilityMode durability = DurabilityMode.ProcessCrash, Action<HostProvisionStage>? checkpoint = null)
    {
        if (durability != DurabilityMode.ProcessCrash) throw new NotSupportedException("Provisioning pilot supports ProcessCrash only.");
        return ProvisionCore(root, deployment, scope, protectedRoots, evidence, new LocalTransactionStorage(durability), checkpoint);
    }
    internal static EmbeddedHostLifetime ProvisionCore(string root, string deployment, string scope, IReadOnlyList<string> protectedRoots,
        EmbeddedHostProvisioningEvidence evidence, ITransactionStorage storage, Action<HostProvisionStage>? checkpoint = null)
    {
        ArgumentNullException.ThrowIfNull(storage); ArgumentNullException.ThrowIfNull(evidence);
        root = ValidatePlacement(root, deployment, scope, protectedRoots, storage.Durability);
        if (evidence.Root != root || evidence.Deployment != deployment || evidence.ResourceScope != scope || !evidence.Fresh ||
            !evidence.ControlledProvisionersOnly || !evidence.NoPriorHost)
            throw new InvalidOperationException("Provisioning requires explicit fresh controlled-scope evidence of no prior host.");
        var parent = Path.GetDirectoryName(root) ?? throw new InvalidDataException("Host root requires an existing parent.");
        BinaryEnvelope.RejectLinks(parent);
        if (!Directory.Exists(parent)) throw new DirectoryNotFoundException("Host parent must already exist.");
        if (ProvisioningPathExists(root)) throw new IOException("Existing host paths are retained; provisioning never resumes, resets or repairs them.");
        var journalId = Guid.NewGuid(); var bytes = HostJournalCodec.EncodeMetadata(journalId, deployment, scope);
        checkpoint?.Invoke(HostProvisionStage.PreflightValidated);
        FileStream? owner = null; FileStream? metadata = null; FileStream? journal = null;
        try
        {
            // Directory creation alone is not an exclusive claim. Within the asserted stable
            // parent/scope only cooperating provisioners can race here; CreateNew decides ownership.
            storage.CreateDirectory(root); checkpoint?.Invoke(HostProvisionStage.RootCreated); BinaryEnvelope.RejectLinks(root);
            if (Directory.EnumerateFileSystemEntries(root).Take(1).Any()) throw new IOException("Provisioning encountered an occupied root; retain it.");
            owner = new(Path.Combine(root, "owner.lock"), FileMode.CreateNew, FileAccess.ReadWrite, FileShare.None, bufferSize: 1);
            checkpoint?.Invoke(HostProvisionStage.OwnerCreated); owner.Flush(true); storage.SyncDirectory(root); checkpoint?.Invoke(HostProvisionStage.OwnerFlushed);
            using (var output = storage.CreateFile(Path.Combine(root, "host.meta")))
            {
                checkpoint?.Invoke(HostProvisionStage.MetadataCreated); output.Write(bytes); checkpoint?.Invoke(HostProvisionStage.MetadataWritten);
                output.FlushToDisk(); checkpoint?.Invoke(HostProvisionStage.MetadataFlushed);
            }
            storage.SyncDirectory(root);
            using (var output = storage.CreateFile(Path.Combine(root, "journal.bin")))
            {
                checkpoint?.Invoke(HostProvisionStage.JournalCreated); output.FlushToDisk(); checkpoint?.Invoke(HostProvisionStage.JournalFlushed);
            }
            storage.SyncDirectory(root); storage.SyncDirectory(parent);
            CheckNamespace(root); checkpoint?.Invoke(HostProvisionStage.NamespaceVerified);
            metadata = new(Path.Combine(root, "host.meta"), FileMode.Open, FileAccess.ReadWrite, FileShare.Read, bufferSize: 1);
            journal = new(Path.Combine(root, "journal.bin"), FileMode.Open, FileAccess.ReadWrite, FileShare.Read, bufferSize: 1);
            checkpoint?.Invoke(HostProvisionStage.BeforeReturn);
            CheckNamespace(root);
            if (!owner.CanSeek || owner.Length != 0 || !metadata.CanSeek || metadata.Length != 88 || !journal.CanSeek || journal.Length != 0)
                throw new InvalidDataException("Provisioned host roles changed before handoff.");
            var read = new byte[88]; metadata.ReadExactly(read);
            var identity = HostJournalCodec.DecodeMetadata(read, deployment, scope);
            if (identity.JournalId != journalId || !read.AsSpan().SequenceEqual(bytes)) throw new InvalidDataException("Provisioned metadata changed.");
            var history = HostJournalCodec.ReadJournal(journal, identity, deployment, scope);
            // The CreateNew owner handle is transferred directly; no close/reopen exclusion gap.
            return new(root, owner, metadata, journal, new(Guid.NewGuid(), journalId, deployment, scope), history, provisioned: true);
        }
        catch
        {
            try { journal?.Dispose(); }
            finally { try { metadata?.Dispose(); } finally { owner?.Dispose(); } }
            // Do not delete, truncate or complete any role, even if this invocation created it.
            throw;
        }
    }
    private static bool ProvisioningPathExists(string path)
    {
        try { _ = File.GetAttributes(path); return true; }
        catch (Exception error) when (error is FileNotFoundException or DirectoryNotFoundException) { return false; }
    }

}
