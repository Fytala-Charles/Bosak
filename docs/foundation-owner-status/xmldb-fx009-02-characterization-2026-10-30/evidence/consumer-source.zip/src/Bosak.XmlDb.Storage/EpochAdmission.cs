// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Publishes isolated epoch metadata fixtures and owns stable OS admission leases.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.4   | 27-10-2026     | Integrate admission-owned read-only epoch snapshots
//                      | Charles Korthout | 0.5   | 27-10-2026     | Add explicit-profile empty-chain ownership and stable lease protection
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal enum EpochStage { FormatFlushed, IdentityFlushed, AdmissionFlushed, Published, DataCopied, SnapshotFlushed, SnapshotVerified }

internal static class EpochAdmission
{
    // Internal bootstrap only; optional preparation must finish and verify immutable data before publication.
    internal static EpochIdentity CreateFixtureRoot(string root, ulong documentId, ITransactionStorage storage, Action<EpochStage>? checkpoint = null,
        Action<string, EpochIdentity, byte[]>? prepare = null, EpochProfile profile = EpochProfile.ImmutableSnapshot)
    {
        ArgumentOutOfRangeException.ThrowIfZero(documentId);
        ArgumentException.ThrowIfNullOrWhiteSpace(root);
        root = Path.GetFullPath(root);
        var parent = Path.GetDirectoryName(root) ?? throw new ArgumentException("Epoch fixture requires an existing parent.", nameof(root));
        if (!Directory.Exists(parent)) throw new DirectoryNotFoundException(parent);
        BinaryEnvelope.RejectLinks(parent);
        if (Directory.Exists(root) || File.Exists(root) || new DirectoryInfo(root).LinkTarget is not null || new FileInfo(root).LinkTarget is not null)
            throw new IOException("Epoch bootstrap never changes or replaces an existing root.");
        BackupStorage.Preflight(root, storage);
        var identity = new EpochIdentity(Guid.NewGuid(), Guid.NewGuid(), documentId);
        var format = EpochCodec.EncodeProfile(identity, profile);
        var staging = Path.Combine(parent, ".xmldb-epoch-" + Guid.NewGuid().ToString("N"));
        TransactionCodec.EnsureDirectory(staging, storage);
        TransactionCodec.WriteFlushed(Path.Combine(staging, "FORMAT"), format, storage);
        checkpoint?.Invoke(EpochStage.FormatFlushed);
        TransactionCodec.WriteFlushed(Path.Combine(staging, "EPOCH"), EpochCodec.EncodeBinding("BXEP", identity, format), storage);
        checkpoint?.Invoke(EpochStage.IdentityFlushed);
        TransactionCodec.EnsureDirectory(Path.Combine(staging, ".epoch"), storage);
        TransactionCodec.WriteFlushed(LeasePath(staging), EpochCodec.EncodeBinding("BXEA", identity, format), storage);
        checkpoint?.Invoke(EpochStage.AdmissionFlushed);
        prepare?.Invoke(staging, identity, format);
        TransactionCodec.PublishGeneration(staging, root, storage);
        checkpoint?.Invoke(EpochStage.Published);
        return identity;
    }

    internal static EpochIdentity ReadIdentity(string root, EpochProfile profile = EpochProfile.ImmutableSnapshot)
    {
        root = Path.GetFullPath(root);
        var format = BinaryEnvelope.ReadFile(Path.Combine(root, "FORMAT"));
        var identity = EpochCodec.RequireProfile(format, profile).Identity;
        EpochCodec.ValidateBinding(BinaryEnvelope.ReadFile(Path.Combine(root, "EPOCH")), "BXEP", identity, format);
        return identity;
    }

    internal static EpochAdmissionLease Acquire(string root, EpochIdentity expected, bool exclusive = false, EpochProfile profile = EpochProfile.ImmutableSnapshot)
    {
        root = Path.GetFullPath(root);
        var format = BinaryEnvelope.ReadFile(Path.Combine(root, "FORMAT"));
        var identity = EpochCodec.RequireProfile(format, profile).Identity;
        if (identity != expected) throw new InvalidDataException("Admission requested for a different store, epoch or document.");
        EpochCodec.ValidateBinding(BinaryEnvelope.ReadFile(Path.Combine(root, "EPOCH")), "BXEP", identity, format);
        var path = LeasePath(root);
        BinaryEnvelope.RejectLinks(path);
        // Fail immediately rather than waiting while a caller could hold a coordinator gate.
        var stream = new FileStream(path, FileMode.Open, exclusive ? FileAccess.ReadWrite : FileAccess.Read,
            exclusive ? FileShare.None : FileShare.Read);
        try
        {
            if (stream.Length != 116) throw new InvalidDataException("Invalid admission identity size.");
            var bytes = new byte[116];
            stream.ReadExactly(bytes);
            EpochCodec.ValidateBinding(bytes, "BXEA", identity, format);
            return new(root, identity, stream, exclusive, profile);
        }
        catch { stream.Dispose(); throw; }
    }

    private static string LeasePath(string root) => Path.Combine(root, ".epoch", "admission.lease");
}

internal sealed class EpochAdmissionLease(string root, EpochIdentity identity, FileStream stream, bool exclusive, EpochProfile profile) : IDisposable
{
    private readonly object _gate = new();
    private bool _disposed;
    internal EpochIdentity Identity => identity;
    internal string Root => root;
    internal EpochProfile Profile => profile;
    internal void ThrowIfDisposed() { lock (_gate) { ObjectDisposedException.ThrowIf(_disposed, this); } }
    internal bool IsExclusive => exclusive;

    // Each child owns a separate OS handle, independent of this owner's eventual disposal.
    internal EpochAdmissionLease ForkShared()
    {
        lock (_gate)
        {
            ObjectDisposedException.ThrowIf(_disposed, this);
            if (exclusive) throw new InvalidOperationException("Maintenance admission cannot create ordinary shared readers.");
            return EpochAdmission.Acquire(root, identity, profile: profile);
        }
    }

    public void Dispose()
    {
        lock (_gate)
        {
            if (_disposed) return;
            stream.Dispose();
            _disposed = true;
        }
    }
}
