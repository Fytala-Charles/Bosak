// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Models conditional host ledger commits and uncertain acknowledgments in memory.
// SPECIAL NOTES        : Internal protocol harness only; no durable persistence, executable permits or effective fence.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal enum HostLedgerStage { Recorded, DispatchAuthorized, Uncertain, Acknowledged, ObservedKnown, ReconciledAbsent }
internal enum HostLedgerCommitFault { None, BeforeCommit, AfterCommit }
internal enum HostLedgerTransition { Applied, Conflict, Rejected }
internal sealed record HostLedgerSnapshot(HostLedgerContext Context, HostLedgerStage Stage,
    EpochPublishedReceipt? Receipt = null, EpochObservedPublication? Observed = null);
internal sealed record HostLedgerTakeoverEvidence(HostLedgerContext Context, bool Fresh, bool AuthoritativeTransfer,
    bool AllPriorPublishersExcluded, bool QueuesDrained, bool DatabaseWritersExcluded);

// This single-attempt in-memory object models conditional commit boundaries. It is not a
// backend, dispatch service, global scope registry or serialized/restartable execution plan.
internal sealed class HostAttemptLedgerHarness
{
    private readonly object _gate = new();
    private readonly List<HostLedgerSnapshot> _history = [];
    private HostLedgerSnapshot? _current;

    internal HostLedgerSnapshot? Read() { lock (_gate) return _current; }
    internal HostLedgerSnapshot[] History() { lock (_gate) return _history.ToArray(); }
    internal bool WritersMustRemainStopped => true;

    internal HostLedgerTransition Record(HostLedgerEvidence? evidence, HostLedgerCommitFault fault = HostLedgerCommitFault.None)
    {
        lock (_gate)
        {
            if (_current is not null) return HostLedgerTransition.Conflict;
            if (evidence?.Expected is not { Revision: 1 } context ||
                HostAttemptLedgerClassifier.Classify(evidence).Decision != HostLedgerDecision.EligibleToAuthorize) return HostLedgerTransition.Rejected;
            return Commit(new(context, HostLedgerStage.Recorded), fault);
        }
    }

    internal HostLedgerTransition Authorize(HostLedgerSnapshot? expected, HostLedgerEvidence? evidence, HostLedgerCommitFault fault = HostLedgerCommitFault.None)
    {
        lock (_gate)
        {
            if (!Current(expected)) return HostLedgerTransition.Conflict;
            if (_current!.Stage != HostLedgerStage.Recorded || !Bound(evidence) ||
                HostAttemptLedgerClassifier.Classify(evidence).Decision != HostLedgerDecision.EligibleToAuthorize) return HostLedgerTransition.Rejected;
            return Advance(_current with { Stage = HostLedgerStage.DispatchAuthorized }, fault);
        }
    }

    internal HostLedgerTransition MarkUncertain(HostLedgerSnapshot? expected, HostLedgerCommitFault fault = HostLedgerCommitFault.None)
    {
        lock (_gate)
        {
            if (!Current(expected)) return HostLedgerTransition.Conflict;
            if (_current!.Stage != HostLedgerStage.DispatchAuthorized) return HostLedgerTransition.Rejected;
            return Advance(_current with { Stage = HostLedgerStage.Uncertain }, fault);
        }
    }

    // Receipt is a separately supplied actual-return value, never synthesized from inspection.
    // This model checks shape/binding; it does not authenticate the caller or the receipt.
    internal HostLedgerTransition Acknowledge(HostLedgerSnapshot? expected, EpochPublishedReceipt? receipt, HostLedgerCommitFault fault = HostLedgerCommitFault.None)
    {
        lock (_gate)
        {
            if (!Current(expected)) return HostLedgerTransition.Conflict;
            if (_current!.Stage is not (HostLedgerStage.DispatchAuthorized or HostLedgerStage.Uncertain or HostLedgerStage.ObservedKnown) ||
                !HostAttemptLedgerClassifier.ReceiptMatches(_current.Context, receipt) ||
                _current.Observed is { } observed && receipt!.DestinationEpoch != observed.DestinationEpoch) return HostLedgerTransition.Rejected;
            return Advance(_current with { Stage = HostLedgerStage.Acknowledged, Receipt = receipt }, fault);
        }
    }

    internal HostLedgerTransition ObserveKnown(HostLedgerSnapshot? expected, HostLedgerEvidence? evidence, HostLedgerCommitFault fault = HostLedgerCommitFault.None)
    {
        lock (_gate)
        {
            if (!Current(expected)) return HostLedgerTransition.Conflict;
            if (_current!.Stage is not (HostLedgerStage.DispatchAuthorized or HostLedgerStage.Uncertain) || !Bound(evidence) ||
                HostAttemptLedgerClassifier.Classify(evidence).Decision != HostLedgerDecision.RecordObservedKnownOnly) return HostLedgerTransition.Rejected;
            return Advance(_current with { Stage = HostLedgerStage.ObservedKnown, Observed = evidence!.Publication!.Observed }, fault);
        }
    }

    internal HostLedgerTransition ReconcileAbsent(HostLedgerSnapshot? expected, HostLedgerEvidence? evidence, HostLedgerCommitFault fault = HostLedgerCommitFault.None)
    {
        lock (_gate)
        {
            if (!Current(expected)) return HostLedgerTransition.Conflict;
            if (_current!.Stage is not (HostLedgerStage.Recorded or HostLedgerStage.DispatchAuthorized or HostLedgerStage.Uncertain) ||
                _current.Receipt is not null || _current.Observed is not null || !Bound(evidence) ||
                HostAttemptLedgerClassifier.Classify(evidence).Decision != HostLedgerDecision.EligibleForFreshAttempt) return HostLedgerTransition.Rejected;
            return Advance(_current with { Stage = HostLedgerStage.ReconciledAbsent }, fault);
        }
    }

    internal HostLedgerTransition TakeOver(HostLedgerSnapshot? expected, HostLedgerTakeoverEvidence? evidence,
        Guid newOwnerSession, ulong newGeneration, HostLedgerCommitFault fault = HostLedgerCommitFault.None)
    {
        lock (_gate)
        {
            if (!Current(expected)) return HostLedgerTransition.Conflict;
            if (evidence is null || evidence.Context != _current!.Context || !evidence.Fresh || !evidence.AuthoritativeTransfer ||
                !evidence.AllPriorPublishersExcluded || !evidence.QueuesDrained || !evidence.DatabaseWritersExcluded ||
                newOwnerSession == Guid.Empty || newOwnerSession == _current.Context.OwnerSession || newGeneration <= _current.Context.OwnerGeneration)
                return HostLedgerTransition.Rejected;
            // A takeover invalidates original-executor assumptions, not known publication evidence.
            var stage = _current.Stage is HostLedgerStage.Recorded or HostLedgerStage.DispatchAuthorized ? HostLedgerStage.Uncertain : _current.Stage;
            return Advance(_current with { Stage = stage, Context = _current.Context with { OwnerSession = newOwnerSession, OwnerGeneration = newGeneration } }, fault);
        }
    }

    private bool Current(HostLedgerSnapshot? expected) => expected is not null && expected == _current;
    private bool Bound(HostLedgerEvidence? evidence) => evidence?.Expected == _current!.Context && evidence?.Record?.Phase == (_current.Stage switch
    {
        HostLedgerStage.Recorded => HostLedgerPhase.Recorded,
        HostLedgerStage.DispatchAuthorized => HostLedgerPhase.DispatchAuthorized,
        HostLedgerStage.Acknowledged => HostLedgerPhase.Acknowledged,
        _ => HostLedgerPhase.Uncertain
    });
    private HostLedgerTransition Advance(HostLedgerSnapshot next, HostLedgerCommitFault fault) => _current!.Context.Revision == ulong.MaxValue ?
        HostLedgerTransition.Rejected : Commit(next with { Context = next.Context with { Revision = _current.Context.Revision + 1 } }, fault);
    private HostLedgerTransition Commit(HostLedgerSnapshot next, HostLedgerCommitFault fault)
    {
        if (!Enum.IsDefined(fault)) return HostLedgerTransition.Rejected;
        if (fault == HostLedgerCommitFault.BeforeCommit) throw new InvalidOperationException("Simulated failure before in-memory commit.");
        _history.Add(next); _current = next;
        if (fault == HostLedgerCommitFault.AfterCommit) throw new InvalidOperationException("Simulated acknowledgment loss after in-memory commit.");
        return HostLedgerTransition.Applied;
    }
}
