// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Validates exact epoch backup closure and privately verifies complete and replayed history.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 27-10-2026     | Share bounded parsing or contained verification helpers with MG2
//                      | Charles Korthout | 0.3   | 27-10-2026     | Share bounded unlinked tree traversal with cutover inspection
// ===========================================================================================================================================================

using System.Globalization;
using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

internal static class EpochBackupStorage
{
    private const string WorkspacePrefix = ".xmldb-epoch-backup-";

    internal static string Workspace(string destination, ITransactionStorage storage)
    {
        var root = Path.Combine(Path.GetDirectoryName(destination)!, WorkspacePrefix + Guid.NewGuid().ToString("N"));
        if (Directory.Exists(root) || File.Exists(root) || new DirectoryInfo(root).LinkTarget is not null || new FileInfo(root).LinkTarget is not null)
            throw new IOException("Epoch backup workspace already exists.");
        TransactionCodec.EnsureDirectory(root, storage); return root;
    }

    internal static string[] FileSet(string data, ulong documentId, ulong sequence)
    {
        if (documentId == 0 || sequence > EpochBackupCodec.MaximumSequence) throw new InvalidDataException("Invalid epoch backup selection.");
        var names = new List<string>();
        AddMaterialization(data, ""); Add("EPOCH"); Add("BASE"); Add(".transactions/CONTROL"); Add(".transactions/CURRENT");
        for (ulong current = 1; current <= sequence; current++)
        {
            Add(".transactions/wal/" + EpochAuthorityCodec.WalFileName(current));
            var prefix = ".transactions/generations/" + EpochAuthorityCodec.GenerationName(current) + "/";
            AddMaterialization(EpochScalarHistory.Generation(data, current), prefix); Add(prefix + "GENERATION");
        }
        names.Sort(StringComparer.Ordinal); return names.ToArray();
        void Add(string name)
        { if (names.Count == EpochBackupCodec.MaximumEntries) throw new InvalidDataException("Epoch backup file count exceeds its limit."); names.Add(name); }
        void AddMaterialization(string root, string prefix)
        {
            var document = "documents/" + documentId.ToString(CultureInfo.InvariantCulture) + "/";
            Add(prefix + "FORMAT"); Add(prefix + document + "manifest.bin"); Add(prefix + document + "directory.bin");
            var manifest = StoreCodec.ReadManifest(TransactionCodec.ReadManifestBytes(root, documentId));
            if (manifest.DocumentId != documentId) throw new InvalidDataException("Epoch backup manifest document mismatch.");
            foreach (var fragment in manifest.Fragments) Add(prefix + "fragments/" + fragment.Id.ToString(CultureInfo.InvariantCulture) + ".bin");
        }
    }

    internal static void ValidateSourceLayout(string root, string[] names)
    {
        var files = names.ToHashSet(StringComparer.Ordinal); var directories = Parents(names);
        foreach (var directory in new[] { ".epoch", ".transactions/wal", ".transactions/generations", ".transactions/readers", ".transactions/staging" }) directories.Add(directory);
        foreach (var (name, directory) in Walk(root))
        {
            if (directory ? directories.Contains(name) : files.Contains(name)) continue;
            if (RuntimePath(name, directory)) continue;
            throw new InvalidDataException("Unknown epoch source dependency; capture cannot omit it.");
        }
    }

    // Read-only seal/closure/header validation. Full history proof additionally requires VerifyCopies.
    internal static EpochBackupInventory ReadArtifact(string root)
    {
        try
        {
            var bytes = BinaryEnvelope.ReadFile(Path.Combine(root, "inventory.bin"));
            var inventory = EpochBackupCodec.ValidateCompletion(BinaryEnvelope.ReadFile(Path.Combine(root, "COMPLETE")), bytes);
            var names = inventory.Files.Select(file => "data/" + file.Path).Append("inventory.bin").Append("COMPLETE").ToArray();
            ExactTree(root, names); ValidateData(Path.Combine(root, "data"), inventory); return inventory;
        }
        catch (Exception error) when (error is FileNotFoundException or DirectoryNotFoundException)
        { throw new InvalidDataException("Epoch backup is missing required metadata or data.", error); }
    }

    internal static void ValidateData(string data, EpochBackupInventory inventory)
    {
        // Canonicalize/validate DTO shape too; a DTO is never a trusted closure token.
        var bytes = EpochBackupCodec.EncodeInventory(inventory);
        var names = inventory.Files.Select(file => file.Path).ToArray(); ExactTree(data, names);
        CompareFiles(data, inventory.Files);
        if (!FileSet(data, inventory.Source.Identity.DocumentId, inventory.CommitSequence).SequenceEqual(names))
            throw new InvalidDataException("Epoch backup lacks its exact full-history closure.");
        EpochBackupCodec.ValidateSourceHeaders(bytes, BinaryEnvelope.ReadFile(Path.Combine(data, "FORMAT")), BinaryEnvelope.ReadFile(Path.Combine(data, ".transactions", "CURRENT")));
        EpochCodec.ValidateBinding(BinaryEnvelope.ReadFile(Path.Combine(data, "EPOCH")), "BXEP", inventory.Source.Identity, BinaryEnvelope.ReadFile(Path.Combine(data, "FORMAT")));
        EpochAuthorityCodec.DecodeBase(BinaryEnvelope.ReadFile(Path.Combine(data, "BASE")), inventory.Source);
        EpochAuthorityCodec.DecodeControl(BinaryEnvelope.ReadFile(Path.Combine(data, ".transactions", "CONTROL")), inventory.Source);
        if (!TransactionCodec.ManifestHash(data, inventory.Source.Identity.DocumentId).AsSpan().SequenceEqual(inventory.Source.BaseHash))
            throw new InvalidDataException("Epoch backup base does not bind the inventory.");
        var format = BinaryEnvelope.ReadFile(Path.Combine(data, "FORMAT"));
        for (ulong sequence = 1; sequence <= inventory.CommitSequence; sequence++)
            if (!BinaryEnvelope.ReadFile(Path.Combine(EpochScalarHistory.Generation(data, sequence), "FORMAT")).AsSpan().SequenceEqual(format))
                throw new InvalidDataException("Epoch backup generation FORMAT differs from its root.");
    }

    internal static void VerifyCopies(string data, string workspace, EpochBackupInventory inventory, ITransactionStorage storage, Action<EpochBackupStage>? checkpoint = null)
    {
        RequireWorkspace(workspace); ValidateData(data, inventory);
        Verify(false); checkpoint?.Invoke(EpochBackupStage.CompleteVerified);
        Verify(true); checkpoint?.Invoke(EpochBackupStage.RedoVerified);
        void Verify(bool redo)
        {
            var clone = Path.Combine(workspace, redo ? "verify-redo" : "verify-complete");
            if (Directory.Exists(clone) || File.Exists(clone)) throw new IOException("Epoch verifier clone already exists.");
            var names = inventory.Files.Select(file => file.Path).Where(name => !redo || !name.StartsWith(".transactions/generations/", StringComparison.Ordinal));
            BackupStorage.Copy(data, clone, names, storage); InitializeClone(clone, inventory, storage);
            if (!redo)
            {
                using var admission = EpochAdmission.Acquire(clone, inventory.Source.Identity, profile: EpochProfile.ScalarWal);
                RequireHead(EpochScalarHistory.Validate(clone, admission, inventory.Source), inventory);
            }
            var replayed = 0;
            using (var owner = EpochScalarCoordinator.Open(clone, storage, stage =>
            {
                if (stage == EpochScalarStage.RecoveryGenerationPublished) replayed++;
                if (stage is EpochScalarStage.TailDiscarded or EpochScalarStage.RecoveryCurrentPublished ||
                    !redo && stage is (EpochScalarStage.RecoveryStageWritten or EpochScalarStage.RecoveryGenerationPublished))
                    throw new InvalidDataException("Epoch verifier repaired an unexpected authority/materialization.");
            }))
            {
                if (owner.CommitSequence != inventory.CommitSequence || replayed != (redo ? (int)inventory.CommitSequence : 0))
                    throw new InvalidDataException("Epoch verifier did not reproduce its exact selected history.");
                using var admission = EpochAdmission.Acquire(clone, inventory.Source.Identity, profile: EpochProfile.ScalarWal);
                RequireHead(EpochScalarHistory.Validate(clone, admission, inventory.Source), inventory);
                for (ulong sequence = 0; sequence <= inventory.CommitSequence; sequence++)
                {
                    var hash = sequence == 0 ? inventory.Source.BaseHash : EpochAuthorityCodec.DecodeWal(BinaryEnvelope.ReadFile(
                        Path.Combine(clone, ".transactions", "wal", EpochAuthorityCodec.WalFileName(sequence))), inventory.Source).ManifestHash;
                    using var snapshot = EpochScalarHistory.Open(clone, sequence, admission, hash);
                    for (ulong id = 1; id <= (ulong)snapshot.NodeCount; id++) _ = snapshot.ReadValue(id);
                }
                CompareFiles(clone, inventory.Files); // Includes exact regenerated witnesses, manifests, topology and payloads.
            }
            RemoveClone(workspace, clone, storage);
        }
    }

    private static void InitializeClone(string root, EpochBackupInventory inventory, ITransactionStorage storage)
    {
        var format = BinaryEnvelope.ReadFile(Path.Combine(root, "FORMAT"));
        EpochCodec.RequireProfile(format, EpochProfile.ScalarWal);
        foreach (var relative in new[] { ".epoch", ".transactions/wal", ".transactions/generations", ".transactions/readers", ".transactions/staging" })
            TransactionCodec.EnsureDirectory(Path.Combine(root, relative), storage);
        // New inode/namespace at this private clone path: source ownership is not copied.
        TransactionCodec.WriteFlushed(Path.Combine(root, ".epoch", "admission.lease"), EpochCodec.EncodeBinding("BXEA", inventory.Source.Identity, format), storage);
    }

    private static void RequireHead(EpochVerifiedHead head, EpochBackupInventory expected)
    {
        if (head.Sequence != expected.CommitSequence || !head.ManifestHash.AsSpan().SequenceEqual(expected.HeadManifestHash) || !head.WalHash.AsSpan().SequenceEqual(expected.HeadWalHash))
            throw new InvalidDataException("Epoch backup verification selected a different history.");
    }
    private static void CompareFiles(string root, IEnumerable<BackupEntry> entries)
    {
        foreach (var entry in entries)
        {
            var bytes = BinaryEnvelope.ReadFile(Path.Combine(root, entry.Path));
            if (bytes.Length != entry.Length || !SHA256.HashData(bytes).AsSpan().SequenceEqual(entry.Hash))
                throw new InvalidDataException("Epoch backup bytes differ from the declared inventory.");
        }
    }
    internal static void ExactTree(string root, IEnumerable<string> names)
    {
        var files = names.ToHashSet(StringComparer.Ordinal); var directories = Parents(files); var seen = new HashSet<string>(StringComparer.Ordinal);
        foreach (var (name, directory) in Walk(root))
            if (directory ? !directories.Contains(name) : !files.Contains(name) || !seen.Add(name)) throw new InvalidDataException("Epoch backup has extra or case-substituted paths.");
        if (seen.Count != files.Count) throw new InvalidDataException("Epoch backup is missing declared files.");
    }
    private static HashSet<string> Parents(IEnumerable<string> names)
    {
        var result = new HashSet<string>(StringComparer.Ordinal);
        foreach (var name in names)
            for (var index = name.IndexOf('/'); index >= 0; index = name.IndexOf('/', index + 1)) result.Add(name[..index]);
        return result;
    }
    internal static IEnumerable<(string Name, bool Directory)> Walk(string root)
    {
        BinaryEnvelope.RejectLinks(root);
        if (!Directory.Exists(root)) throw new InvalidDataException("Epoch backup data root is not a directory.");
        var pending = new Stack<(string Path, int Depth)>(); pending.Push((root, 0)); var visited = 0;
        while (pending.TryPop(out var item))
            foreach (var path in Directory.EnumerateFileSystemEntries(item.Path))
            {
                if (++visited > EpochBackupCodec.MaximumEntries * 4 || item.Depth >= 64) throw new InvalidDataException("Epoch backup tree exceeds its traversal bound.");
                BinaryEnvelope.RejectLinks(path); var directory = Directory.Exists(path);
                yield return (Path.GetRelativePath(root, path).Replace('\\', '/'), directory);
                if (directory) pending.Push((path, item.Depth + 1));
            }
    }
    private static bool RuntimePath(string name, bool directory)
    {
        if (!directory && name is ".epoch/admission.lease" or ".transactions/writer.lock") return true;
        const string staging = ".transactions/staging/";
        if (name.StartsWith(staging, StringComparison.Ordinal))
        {
            var tail = name[staging.Length..]; var slash = tail.IndexOf('/');
            return Guid.TryParseExact(slash < 0 ? tail : tail[..slash], "N", out _) && (slash >= 0 || directory);
        }
        const string readers = ".transactions/readers/";
        if (!directory && name.StartsWith(readers, StringComparison.Ordinal))
        {
            var tail = name[readers.Length..];
            if (tail.Length == 63 && tail.AsSpan(26, 5).SequenceEqual(".tmp-") && Guid.TryParseExact(tail.AsSpan(31), "N", out _))
            { EpochAuthorityCodec.ParseReaderName(tail[..26]); return true; }
            EpochAuthorityCodec.ParseReaderName(tail); return true;
        }
        const string transactions = ".transactions/";
        return !directory && name.StartsWith(transactions, StringComparison.Ordinal) && EpochScalarHistory.IsCurrentTemporary(name[transactions.Length..]);
    }
    private static void RequireWorkspace(string workspace)
    {
        var name = Path.GetFileName(Path.GetFullPath(workspace));
        if (!name.StartsWith(WorkspacePrefix, StringComparison.Ordinal) || !Guid.TryParseExact(name.AsSpan(WorkspacePrefix.Length), "N", out _))
            throw new InvalidDataException("Not an owned epoch backup workspace.");
        BinaryEnvelope.RejectLinks(workspace);
    }
    internal static void RemoveClone(string workspace, string clone, ITransactionStorage storage)
    {
        RequireWorkspace(workspace);
        if (Path.GetDirectoryName(Path.GetFullPath(clone)) != Path.GetFullPath(workspace) || Path.GetFileName(clone) is not ("verify-complete" or "verify-redo"))
            throw new InvalidDataException("Clone cleanup escaped its owned workspace.");
        BinaryEnvelope.RejectLinks(clone); storage.DeleteDirectory(clone); storage.SyncDirectory(workspace);
    }
    internal static void RemoveWorkspace(string workspace, ITransactionStorage storage)
    {
        RequireWorkspace(workspace);
        if (Directory.EnumerateFileSystemEntries(workspace).Any()) throw new InvalidDataException("Epoch backup workspace is not empty after publication.");
        storage.DeleteDirectory(workspace); storage.SyncDirectory(Path.GetDirectoryName(workspace)!);
    }
}
