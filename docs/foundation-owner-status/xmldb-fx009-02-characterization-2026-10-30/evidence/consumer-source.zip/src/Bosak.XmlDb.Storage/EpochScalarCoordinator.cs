// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Stages and commits epoch scalar updates while retaining complete immutable history.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 27-10-2026     | Recover missing generations and narrowly classified incomplete WAL tails
//                      | Charles Korthout | 0.3   | 27-10-2026     | Add internal admitted fixed-head backup capture through a partial coordinator
//                      | Charles Korthout | 0.4   | 27-10-2026     | Guard pending and new transactions during internal cutover freeze
//                      | Charles Korthout | 0.5   | 28-10-2026     | Validate optional expected identity before admission or owner adoption
// ===========================================================================================================================================================

using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

internal enum EpochScalarStage { StageWritten, BeforeWal, WalFlushed, GenerationPublished, ReaderPublished, BeforeCurrent, CurrentPublished, Committed, TailDiscarded, RecoveryStageWritten, RecoveryGenerationPublished, RecoveryCurrentPublished }

internal sealed partial class EpochScalarCoordinator : IDisposable
{
    private readonly object _gate = new();
    private readonly string _root;
    private readonly EpochAdmissionLease _admission;
    private readonly EpochAuthorityBinding _binding;
    private readonly FileStream _writer;
    private readonly ITransactionStorage _storage;
    private readonly Action<EpochScalarStage>? _checkpoint;
    private EpochVerifiedHead _head;
    private bool _disposed;
    private bool _faulted;

    private EpochScalarCoordinator(string root, EpochAdmissionLease admission, EpochAuthorityBinding binding, FileStream writer,
        ITransactionStorage storage, EpochVerifiedHead head, Action<EpochScalarStage>? checkpoint)
    { _root = root; _admission = admission; _binding = binding; _writer = writer; _storage = storage; _head = head; _checkpoint = checkpoint; }
    internal ulong CommitSequence { get { lock (_gate) { Available(); return _head.Sequence; } } }
    internal EpochIdentity Identity => _binding.Identity;

    internal static EpochScalarCoordinator Open(string root, ITransactionStorage? storage = null, Action<EpochScalarStage>? checkpoint = null, EpochIdentity? expectedIdentity = null)
    {
        root = Path.GetFullPath(root); storage ??= new LocalTransactionStorage();
        var identity = EpochAdmission.ReadIdentity(root, EpochProfile.ScalarWal);
        if (expectedIdentity is not null && identity != expectedIdentity) throw new InvalidDataException("Mutable epoch identity differs from the explicitly expected store, epoch or document.");
        var admission = EpochAdmission.Acquire(root, identity, profile: EpochProfile.ScalarWal);
        FileStream? writer = null;
        try
        {
            var binding = EpochEmptyCoordinator.ReadAuthority(root, identity, allowHistory: true);
            EpochEmptyCoordinator.VerifyBase(root, admission, binding.BaseHash);
            var writerPath = Path.Combine(root, ".transactions", "writer.lock");
            if (File.Exists(writerPath)) BinaryEnvelope.RejectLinks(writerPath);
            writer = new FileStream(writerPath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
            var rechecked = EpochEmptyCoordinator.ReadAuthority(root, identity, allowHistory: true);
            if (!binding.FormatHash.AsSpan().SequenceEqual(rechecked.FormatHash) || !binding.BaseHash.AsSpan().SequenceEqual(rechecked.BaseHash))
                throw new InvalidDataException("Epoch authority changed.");
            if (storage.Durability == DurabilityMode.FileAndDirectoryFlush)
                TransactionCodec.SyncExistingStore(root, writerPath, storage, Path.Combine(root, ".epoch", "admission.lease"));
            storage.SyncDirectory(Path.GetDirectoryName(writerPath)!);
            var head = EpochScalarRecovery.Recover(root, admission, binding, storage, checkpoint);
            EpochGenerationReader.Ensure(root, binding, 0, binding.BaseHash, storage);
            EpochGenerationReader.Ensure(root, binding, head.Sequence, head.ManifestHash, storage);
            return new(root, admission, binding, writer, storage, head, checkpoint);
        }
        catch { writer?.Dispose(); admission.Dispose(); throw; }
    }

    internal ImmutableXmlSnapshot BeginRead(int cacheBytes = 8 * 1024 * 1024)
    {
        ArgumentOutOfRangeException.ThrowIfNegative(cacheBytes);
        var admission = _admission.ForkShared(); IDisposable? generation = null;
        try
        {
            lock (_gate)
            {
                Available();
                var verified = EpochScalarHistory.Validate(_root, admission, _binding);
                if (verified.Sequence != _head.Sequence || !verified.ManifestHash.AsSpan().SequenceEqual(_head.ManifestHash) || !verified.WalHash.AsSpan().SequenceEqual(_head.WalHash))
                    throw new InvalidDataException("Verified head differs from the owned selection.");
                generation = EpochGenerationReader.Acquire(_root, _binding, _head.Sequence, _head.ManifestHash);
                return ImmutableXmlSnapshot.OpenMutableEpochGeneration(_root, _head.Sequence, admission, _head.ManifestHash, cacheBytes, generation);
            }
        }
        catch (Exception exception)
        {
            generation?.Dispose(); admission.Dispose();
            if (exception is IOException or InvalidDataException or NotSupportedException) lock (_gate) { if (!_disposed) _faulted = true; }
            throw;
        }
    }
    internal EpochScalarTransaction BeginTransaction()
    {
        lock (_gate) { Available(); RejectCutoverMutation(); }
        return new(this, BeginRead());
    }

    internal ulong Commit(EpochScalarTransaction transaction, ImmutableXmlSnapshot snapshot, ulong nodeId, string value)
    {
        lock (_gate)
        {
            Available();
            RejectCutoverMutation();
            if (!ReferenceEquals(transaction.Owner, this) || transaction.Identity != _binding.Identity || transaction.BaseSequence != _head.Sequence ||
                !transaction.BaseManifestHash.Span.SequenceEqual(_head.ManifestHash)) throw new TransactionConflictException("Epoch head changed after transaction selection.");
            if (_head.Sequence == 10_000) throw new NotSupportedException("Epoch journal limit reached.");
            ScalarGeneration.ValidateReplacement(snapshot, nodeId, value);
            var next = _head.Sequence + 1;
            var staging = Path.Combine(_root, ".transactions", "staging", Guid.NewGuid().ToString("N"));
            try
            {
                var hash = ScalarGeneration.BuildEpochMaterialization(snapshot.MaterializationRoot, staging, snapshot, nodeId, value, null, _storage);
                var record = new EpochWalRecord(_binding, next, transaction.TransactionId, nodeId, value, _head.ManifestHash, hash, _head.WalHash);
                var bytes = EpochAuthorityCodec.EncodeWal(record); var digest = SHA256.HashData(bytes);
                TransactionCodec.WriteFlushed(Path.Combine(staging, "GENERATION"), EpochAuthorityCodec.EncodeGeneration(new(_binding, next, _head.ManifestHash, hash, digest)), _storage);
                EpochScalarHistory.ValidateFiles(staging, _binding.Identity.DocumentId, hash);
                using (var staged = ImmutableXmlSnapshot.OpenMutableEpochStaging(_root, staging, next, _admission.ForkShared(), hash))
                    EpochScalarHistory.ValidateTransition(snapshot, staged, nodeId, value);
                _checkpoint?.Invoke(EpochScalarStage.StageWritten);
                _checkpoint?.Invoke(EpochScalarStage.BeforeWal);
                TransactionCodec.WriteFlushed(Path.Combine(_root, ".transactions", "wal", EpochAuthorityCodec.WalFileName(next)), bytes, _storage);
                _checkpoint?.Invoke(EpochScalarStage.WalFlushed);
                TransactionCodec.PublishGeneration(staging, EpochScalarHistory.Generation(_root, next), _storage);
                _checkpoint?.Invoke(EpochScalarStage.GenerationPublished);
                EpochGenerationReader.Ensure(_root, _binding, next, hash, _storage);
                _checkpoint?.Invoke(EpochScalarStage.ReaderPublished);
                var temporary = Path.Combine(_root, ".transactions", "current-" + Guid.NewGuid().ToString("N") + ".tmp");
                TransactionCodec.WriteFlushed(temporary, EpochAuthorityCodec.EncodeCurrent(new(_binding, next, hash, digest)), _storage);
                _checkpoint?.Invoke(EpochScalarStage.BeforeCurrent);
                TransactionCodec.PublishFile(temporary, Path.Combine(_root, ".transactions", "CURRENT"), true, _storage);
                _checkpoint?.Invoke(EpochScalarStage.CurrentPublished);
                _head = new(next, hash, digest);
                _checkpoint?.Invoke(EpochScalarStage.Committed);
                return next;
            }
            catch { _faulted = true; throw; }
        }
    }
    private void Available()
    { ObjectDisposedException.ThrowIf(_disposed, this); if (_faulted) throw new InvalidOperationException("Epoch coordinator requires reopen after persistence/validation failure."); }
    /// <inheritdoc />
    public void Dispose() { lock (_gate) { if (_disposed) return; _writer.Dispose(); _admission.Dispose(); _disposed = true; } }
}

internal sealed class EpochScalarTransaction : IDisposable
{
    private readonly ImmutableXmlSnapshot _snapshot;
    private readonly byte[] _manifest;
    private bool _completed;
    private ulong _node;
    private string? _value;
    internal EpochScalarTransaction(EpochScalarCoordinator owner, ImmutableXmlSnapshot snapshot)
    { Owner = owner; _snapshot = snapshot; _manifest = snapshot.ManifestIdentity; BaseSequence = snapshot.CommitSequence; Identity = owner.Identity; }
    internal EpochScalarCoordinator Owner { get; }
    internal EpochIdentity Identity { get; }
    internal Guid TransactionId { get; } = Guid.NewGuid();
    internal ulong BaseSequence { get; }
    internal ReadOnlyMemory<byte> BaseManifestHash => _manifest;
    internal string ReadValue(ulong node) { Live(); return _snapshot.ReadValue(node); }
    internal void ReplaceNodeValue(ulong node, string value)
    {
        Live(); ScalarGeneration.ValidateReplacement(_snapshot, node, value);
        if (_node != 0 && _node != node) throw new NotSupportedException("One scalar per epoch transaction.");
        _node = node; _value = value;
    }
    internal ulong Commit()
    {
        Live(); if (_value is null) throw new InvalidOperationException("No scalar replacement staged.");
        _completed = true;
        try { return Owner.Commit(this, _snapshot, _node, _value); }
        finally { _snapshot.Dispose(); }
    }
    internal void Rollback() => Dispose();
    private void Live() => ObjectDisposedException.ThrowIf(_completed, this);
    /// <inheritdoc />
    public void Dispose() { if (_completed) return; _completed = true; _value = null; _snapshot.Dispose(); }
}
