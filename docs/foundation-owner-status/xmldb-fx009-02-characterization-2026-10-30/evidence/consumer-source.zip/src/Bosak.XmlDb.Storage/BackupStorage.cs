// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Copies and verifies fixed-sequence full-history backups without source mutation.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Globalization;
using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

internal static class BackupStorage
{
    internal static string Destination(string source, string destination)
    {
        ValidatePortableRoot(source);
        ValidatePortableRoot(destination); // Check raw spelling before Windows normalizes trailing dots.
        source = Path.TrimEndingDirectorySeparator(Path.GetFullPath(source));
        destination = Path.TrimEndingDirectorySeparator(Path.GetFullPath(destination));
        ValidatePortableRoot(source);
        ValidatePortableRoot(destination);
        BinaryEnvelope.RejectLinks(source);
        var parentPath = Path.GetDirectoryName(destination) ?? throw new ArgumentException("Destination has no parent.", nameof(destination));
        if (!Directory.Exists(parentPath)) throw new DirectoryNotFoundException("Destination parent must already exist.");
        BinaryEnvelope.RejectLinks(parentPath);
        if (new DirectoryInfo(destination).LinkTarget is not null || new FileInfo(destination).LinkTarget is not null)
            throw new InvalidDataException("Destination cannot be a link.");
        // Case-insensitive comparison also rejects portable path aliases on Linux.
        if (source.Equals(destination, StringComparison.OrdinalIgnoreCase) ||
            source.StartsWith(destination + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) ||
            destination.StartsWith(source + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("Source and destination must be separate nonoverlapping roots.", nameof(destination));
        if (File.Exists(destination) || Directory.Exists(destination)) throw new IOException("Destination already exists; backup/restore never overwrites it.");
        var parent = Path.GetDirectoryName(destination) ?? throw new ArgumentException("Destination has no parent.", nameof(destination));
        if (!Directory.Exists(parent)) throw new DirectoryNotFoundException("Destination parent must already exist.");
        return destination;
    }

    private static void ValidatePortableRoot(string path)
    {
        var relative = path[(Path.GetPathRoot(path)?.Length ?? 0)..];
        foreach (var component in relative.Split([Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar]))
        {
            if (component is "." or "..") continue;
            var stem = component.Split('.')[0].ToUpperInvariant();
            if (component.EndsWith(' ') || component.EndsWith('.') || component.Contains('~') || component.Contains(':') ||
                stem is "CON" or "PRN" or "AUX" or "NUL" ||
                stem.Length == 4 && (stem.StartsWith("COM", StringComparison.Ordinal) || stem.StartsWith("LPT", StringComparison.Ordinal)) && stem[3] is >= '0' and <= '9')
                throw new ArgumentException("Backup paths must not use device names, trailing-dot/space or short-name aliases.");
        }
    }

    internal static void Preflight(string destination, ITransactionStorage storage)
    {
        for (var ancestor = Directory.GetParent(destination); ancestor is not null; ancestor = ancestor.Parent)
            storage.SyncDirectory(ancestor.FullName);
    }

    internal static string Workspace(string destination, ITransactionStorage storage)
    {
        var path = Path.Combine(Path.GetDirectoryName(destination)!, ".xmldb-backup-" + Guid.NewGuid().ToString("N"));
        TransactionCodec.EnsureDirectory(path, storage);
        return path;
    }

    internal static string[] FileSet(string root, ulong documentId, ulong sequence)
    {
        var names = new List<string>();
        AddMaterialization(root, "");
        names.Add(".transactions/CONTROL");
        if (sequence > 0) names.Add(".transactions/CURRENT");
        for (ulong index = 1; index <= sequence; index++)
        {
            var name = index.ToString("D20", CultureInfo.InvariantCulture);
            names.Add(".transactions/wal/" + name + ".wal");
            AddMaterialization(Path.Combine(root, ".transactions", "generations", name), ".transactions/generations/" + name + "/");
        }
        if (names.Count > BackupCodec.MaximumEntries) throw new InvalidDataException("Backup file count exceeds its bounded inventory.");
        return names.Order(StringComparer.Ordinal).ToArray();

        void AddMaterialization(string materialization, string prefix)
        {
            var doc = "documents/" + documentId.ToString(CultureInfo.InvariantCulture) + "/";
            names.Add(prefix + "FORMAT");
            names.Add(prefix + doc + "manifest.bin");
            names.Add(prefix + doc + "directory.bin");
            var manifest = StoreCodec.ReadManifest(TransactionCodec.ReadManifestBytes(materialization, documentId));
            foreach (var fragment in manifest.Fragments)
            {
                names.Add(prefix + "fragments/" + fragment.Id.ToString(CultureInfo.InvariantCulture) + ".bin");
                if (names.Count > BackupCodec.MaximumEntries) throw new InvalidDataException("Backup contains too many files.");
            }
            if (names.Count > BackupCodec.MaximumEntries) throw new InvalidDataException("Backup contains too many files.");
        }
    }

    internal static void ValidateSourceLayout(string root, string[] files)
    {
        var expected = files.ToHashSet(StringComparer.Ordinal);
        foreach (var path in Enumerate(root))
        {
            if (expected.Contains(path) || path is ".transactions/writer.lock" or ".transactions/CHECKPOINT" ||
                path.StartsWith(".transactions/checkpoints/", StringComparison.Ordinal) ||
                path.StartsWith(".transactions/anchors/", StringComparison.Ordinal) ||
                path.StartsWith(".transactions/readers/", StringComparison.Ordinal) ||
                path.StartsWith(".transactions/staging/", StringComparison.Ordinal) ||
                path.StartsWith(".transactions/", StringComparison.Ordinal) && path.Count(c => c == '/') == 1 && path.EndsWith(".tmp", StringComparison.Ordinal))
                continue;
            throw new InvalidDataException("Unrecognized source file; backup cannot omit unknown dependencies.");
        }
    }

    internal static BackupEntry[] Copy(string source, string destination, IEnumerable<string> names, ITransactionStorage storage)
    {
        TransactionCodec.EnsureDirectory(destination, storage);
        var entries = new List<BackupEntry>();
        foreach (var name in names)
        {
            var bytes = BinaryEnvelope.ReadFile(Path.Combine(source, name));
            var target = Path.Combine(destination, name);
            TransactionCodec.EnsureDirectory(Path.GetDirectoryName(target)!, storage);
            TransactionCodec.WriteFlushed(target, bytes, storage);
            entries.Add(new(name, bytes.Length, SHA256.HashData(bytes)));
        }
        return entries.ToArray();
    }

    internal static BackupInventory ReadArtifact(string root)
    {
        BinaryEnvelope.RejectLinks(root);
        var bytes = BinaryEnvelope.ReadFile(Path.Combine(root, "inventory.bin"));
        BackupCodec.ValidateCompletion(BinaryEnvelope.ReadFile(Path.Combine(root, "COMPLETE")), bytes);
        var inventory = BackupCodec.Decode(bytes);
        var data = Path.Combine(root, "data");
        var expected = inventory.Files.Select(entry => entry.Path).ToArray();
        if (!FileSet(data, inventory.Identity.DocumentId, inventory.Identity.CommitSequence).SequenceEqual(expected))
            throw new InvalidDataException("Inventory does not contain the complete canonical full-history file set.");
        var actual = Enumerate(root).Order(StringComparer.Ordinal).ToArray();
        var directories = Directory.EnumerateDirectories(root, "*", SearchOption.AllDirectories);
        foreach (var directory in directories)
        {
            var relative = Path.GetRelativePath(root, directory).Replace('\\', '/') + "/";
            if (!expected.Any(name => ("data/" + name).StartsWith(relative, StringComparison.Ordinal)))
                throw new InvalidDataException("Backup contains an unexpected directory.");
        }
        var allowed = expected.Select(path => "data/" + path).Append("inventory.bin").Append("COMPLETE").Order(StringComparer.Ordinal);
        if (!actual.SequenceEqual(allowed)) throw new InvalidDataException("Backup contains missing or unexpected files.");
        foreach (var entry in inventory.Files)
        {
            var file = BinaryEnvelope.ReadFile(Path.Combine(data, entry.Path));
            if (file.Length != entry.Length || !SHA256.HashData(file).AsSpan().SequenceEqual(entry.Hash))
                throw new InvalidDataException("Backup content differs from sealed inventory.");
        }
        return inventory;
    }

    private static IEnumerable<string> Enumerate(string root)
    {
        var pending = new Stack<(string Path, int Depth)>();
        pending.Push((root, 0));
        var visited = 0;
        while (pending.TryPop(out var item))
        {
            if (item.Depth > 64) throw new InvalidDataException("Backup directory nesting exceeds limit.");
            foreach (var path in Directory.EnumerateFileSystemEntries(item.Path))
            {
                if (++visited > BackupCodec.MaximumEntries * 4) throw new InvalidDataException("Backup tree exceeds limit.");
                BinaryEnvelope.RejectLinks(path);
                if (Directory.Exists(path)) pending.Push((path, item.Depth + 1));
                else yield return Path.GetRelativePath(root, path).Replace('\\', '/');
            }
        }
    }

    internal static void Verify(string data, string clone, BackupInventory inventory, ITransactionStorage storage, Action? verificationOpened = null)
    {
        var identity = inventory.Identity;
        if (!TransactionCodec.ManifestHash(data, identity.DocumentId).AsSpan().SequenceEqual(inventory.BaseHash))
            throw new InvalidDataException("Backup base differs from captured identity.");
        ScalarGeneration.Validate(data, identity.DocumentId, inventory.BaseHash);
        Copy(data, clone, inventory.Files.Select(entry => entry.Path), storage);
        using (var database = EmbeddedXmlDatabase.OpenCore(clone, identity.DocumentId, null, storage))
        {
            verificationOpened?.Invoke();
            if (database.CommitSequence != identity.CommitSequence || database.LastRecovery.GenerationsReplayed != 0)
                throw new InvalidDataException("Backup verification repaired history or did not reproduce the exact sequence.");
            var visible = identity.CommitSequence == 0 ? clone : Path.Combine(clone, ".transactions", "generations", identity.CommitSequence.ToString("D20", CultureInfo.InvariantCulture));
            if (!TransactionCodec.ManifestHash(visible, identity.DocumentId).AsSpan().SequenceEqual(inventory.HeadHash))
                throw new InvalidDataException("Backup verification did not reproduce the exact head.");
            using var snapshot = database.BeginRead();
            for (ulong id = 1; id <= (ulong)snapshot.NodeCount; id++) _ = snapshot.ReadValue(id);
        }
        // Only this operation's freshly generated verification clone is removed.
        BinaryEnvelope.RejectLinks(clone);
        storage.DeleteDirectory(clone);
        storage.SyncDirectory(Path.GetDirectoryName(clone)!);
    }
}
