// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Captures and restores verified full-history backups at a fixed committed sequence.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      | Charles Korthout | 0.2   | 29-10-2026     | Exclude new backup publication in opt-in retained enrollment mode
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

public sealed partial class EmbeddedXmlDatabase
{
    /// <summary>Captures verified complete history while excluding commits and checkpoint publication.</summary>
    /// <param name="destination">New backup directory beneath an existing parent, outside the source root.</param>
    /// <returns>The sealed backup identity and exact sequence.</returns>
    /// <remarks>Optional checkpoints are omitted. Source history is retained. Errors fault this coordinator; reopen before retrying.</remarks>
    public BackupResult CreateBackup(string destination)
    {
        lock (_gate)
        {
            ThrowIfUnavailable();
            RejectEnrollmentPublisher();
            destination = BackupStorage.Destination(_root, destination);
            try
            {
                BackupStorage.Preflight(destination, _storage);
                var workspace = BackupStorage.Workspace(destination, _storage);
                var artifact = Path.Combine(workspace, "artifact");
                var data = Path.Combine(artifact, "data");
                var names = BackupStorage.FileSet(_root, _documentId, _sequence);
                BackupStorage.ValidateSourceLayout(_root, names);
                var entries = BackupStorage.Copy(_root, data, names, _storage);
                var identity = new BackupResult(Guid.NewGuid(), _documentId, _sequence);
                var inventory = new BackupInventory(identity, TransactionCodec.ManifestHash(_root, _documentId), _manifestHash, entries);
                _checkpoint?.Invoke(CommitStage.BackupCopied);
                BackupStorage.Verify(data, Path.Combine(workspace, "verify"), inventory, _storage,
                    () => _checkpoint?.Invoke(CommitStage.BackupVerificationOpened));
                // Check exact copied bytes against the pinned source materialization (all IDs/order/values included).
                var copiedVisible = _sequence == 0 ? data : Path.Combine(data, ".transactions", "generations", _sequence.ToString("D20", System.Globalization.CultureInfo.InvariantCulture));
                if (!TransactionCodec.ManifestHash(copiedVisible, _documentId).AsSpan().SequenceEqual(_manifestHash))
                    throw new InvalidDataException("Captured head changed during backup.");
                _checkpoint?.Invoke(CommitStage.BackupVerified);
                var bytes = BackupCodec.Encode(inventory);
                TransactionCodec.WriteFlushed(Path.Combine(artifact, "inventory.bin"), bytes, _storage);
                _checkpoint?.Invoke(CommitStage.BackupInventoryFlushed);
                TransactionCodec.WriteFlushed(Path.Combine(artifact, "COMPLETE"), BackupCodec.Complete(bytes), _storage);
                _ = BackupStorage.ReadArtifact(artifact);
                _checkpoint?.Invoke(CommitStage.BackupCompleted);
                TransactionCodec.PublishGeneration(artifact, destination, _storage);
                _checkpoint?.Invoke(CommitStage.BackupPublished);
                _storage.DeleteDirectory(workspace);
                _storage.SyncDirectory(Path.GetDirectoryName(workspace)!);
                return identity;
            }
            catch { _faulted = true; throw; }
        }
    }

    /// <summary>Restores a sealed full-history backup into a new independently writable store.</summary>
    /// <param name="backupRoot">Completed backup artifact directory.</param>
    /// <param name="destination">New store directory beneath an existing parent, outside the backup root.</param>
    /// <param name="durability">Requested restore barriers; unsupported policies fail without fallback.</param>
    /// <returns>The backup identity and exact restored sequence.</returns>
    public static BackupResult RestoreBackup(string backupRoot, string destination, DurabilityMode durability = DurabilityMode.ProcessCrash) =>
        RestoreBackupCore(backupRoot, destination, new LocalTransactionStorage(durability), null);

    internal static BackupResult RestoreBackupCore(string backupRoot, string destination, ITransactionStorage storage, Action<CommitStage>? checkpoint)
    {
        destination = BackupStorage.Destination(backupRoot, destination);
        backupRoot = Path.GetFullPath(backupRoot);
        BackupStorage.Preflight(destination, storage);
        var inventory = BackupStorage.ReadArtifact(backupRoot); // Validate before creating destination artifacts.
        var workspace = BackupStorage.Workspace(destination, storage);
        var data = Path.Combine(workspace, "data");
        var copied = BackupStorage.Copy(Path.Combine(backupRoot, "data"), data, inventory.Files.Select(entry => entry.Path), storage);
        if (copied.Where((entry, index) => entry.Length != inventory.Files[index].Length || !entry.Hash.AsSpan().SequenceEqual(inventory.Files[index].Hash)).Any())
            throw new InvalidDataException("Backup changed during restore.");
        checkpoint?.Invoke(CommitStage.RestoreCopied);
        BackupStorage.Verify(data, Path.Combine(workspace, "verify"), inventory, storage,
            () => checkpoint?.Invoke(CommitStage.RestoreVerificationOpened));
        checkpoint?.Invoke(CommitStage.RestoreVerified);
        TransactionCodec.PublishGeneration(data, destination, storage);
        checkpoint?.Invoke(CommitStage.RestorePublished);
        storage.DeleteDirectory(workspace);
        storage.SyncDirectory(Path.GetDirectoryName(workspace)!);
        return inventory.Identity;
    }
}
