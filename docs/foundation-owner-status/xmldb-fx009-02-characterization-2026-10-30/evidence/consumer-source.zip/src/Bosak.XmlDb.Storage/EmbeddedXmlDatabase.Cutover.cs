// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Provides cooperating coordinator freeze and read-only state inspection for cutover acceptance.
// SPECIAL NOTES        : Internal prototype acceptance only; no persistent fence, routing service or retirement.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      | Charles Korthout | 0.2   | 29-10-2026     | Inspect actual frozen source admission identity for enrollment
//                      | Charles Korthout | 0.3   | 29-10-2026     | Retain freeze exclusion through real enrollment child drain
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal sealed record LegacyCutoverState(string Root, ulong DocumentId, ulong Sequence, byte[] ManifestHash);

/// <summary>Coordinates the embedded scalar store and internal cooperating cutover freeze.</summary>
public sealed partial class EmbeddedXmlDatabase
{
    private Guid _cutoverFreeze;
    internal Guid EnterCutoverFreeze()
    {
        lock (_gate)
        {
            ThrowIfUnavailable();
            if (_enrollmentStopLatched || _enrollmentSource is not null) throw new InvalidOperationException("Enrollment retention or its stop latch prevents a new freeze.");
            if (_cutoverFreeze != Guid.Empty) throw new InvalidOperationException("Source is already frozen for cutover.");
            return _cutoverFreeze = Guid.NewGuid();
        }
    }
    internal void ExitCutoverFreeze(Guid token, MigrationSourceFreeze freeze)
    {
        lock (_gate)
        {
            freeze.MarkDisposed(this);
            if (_cutoverFreeze == token && _enrollmentSource is null) _cutoverFreeze = Guid.Empty;
        }
    }
    internal T InspectCutover<T>(Guid token, Func<LegacyCutoverState, T> inspect)
    {
        lock (_gate)
        {
            ThrowIfUnavailable();
            if (_cutoverFreeze != token || token == Guid.Empty) throw new InvalidOperationException("Source cutover freeze is not active.");
            return inspect(new(_root, _documentId, _sequence, (byte[])_manifestHash.Clone()));
        }
    }
    internal ApplicationFileIdentity InspectCutoverAdmission(Guid token)
    {
        lock (_gate)
        {
            ThrowIfUnavailable();
            if (_cutoverFreeze != token || token == Guid.Empty) throw new InvalidOperationException("Source freeze is no longer active.");
            var identity = ApplicationAuthorityFileIdentity.HandleIdentity(_lease);
            if (_lease.Length != 0 || ApplicationAuthorityFileIdentity.PathIdentity(Path.Combine(_transactions, "writer.lock"), false) != identity)
                throw new InvalidDataException("Source admission path no longer names the actual retained owner handle.");
            return identity;
        }
    }
    private void RejectCutoverMutation()
    { if (_cutoverFreeze != Guid.Empty || _enrollmentStopLatched) throw new InvalidOperationException("Source writes are frozen for internal cutover acceptance."); }
}
