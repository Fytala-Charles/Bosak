// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Encodes and strictly decodes bounded host-only journal complete bounded host journal histories.
// SPECIAL NOTES        : Internal pure codec; structural replay never proves durability, freshness or dispatch authority.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 28-10-2026     | Share bounded semantic extension validation with owned append
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal static partial class HostJournalCodec
{
    internal static HostJournalReadResult DecodeJournal(byte[] bytes, HostJournalMetadata metadata, string deployment, string scope)
    {
        Require(bytes is not null && bytes.Length <= MaximumJournalBytes);
        using var input = new MemoryStream(bytes, writable: false); return ReadJournal(input, metadata, deployment, scope);
    }

    // Reads only the caller-owned stream, without seeking, closing it or opening any file.
    // An incomplete tail throws; no usable prefix or append authority is returned.
    internal static HostJournalReadResult ReadJournal(Stream input, HostJournalMetadata metadata, string deployment, string scope)
    {
        Require(input is not null && input.CanRead && metadata is not null && metadata.JournalId != Guid.Empty && metadata.ScopeDigest == ScopeDigest(deployment, scope));
        var frames = new List<HostJournalFrame>(); var attempts = new Dictionary<Guid, HostLedgerSnapshot>(); var requests = new Dictionary<Guid, HostLedgerSnapshot>();
        long total = 0; var previous = ZeroHash; var header = new byte[72];
        try
        {
            while (true)
            {
                var first = input.Read(header, 0, 1); if (first == 0) break;
                Require(frames.Count < MaximumFrames && total <= MaximumJournalBytes - 72); input.ReadExactly(header.AsSpan(1));
                Require(header.AsSpan(0, 8).SequenceEqual("BXHJ0001"u8) &&
                    System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian(header.AsSpan(8)) == 1 &&
                    System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian(header.AsSpan(10)) == 0 &&
                    ReadGuid(header.AsSpan(24, 16)) == metadata.JournalId &&
                    System.Buffers.Binary.BinaryPrimitives.ReadUInt64LittleEndian(header.AsSpan(16)) == (ulong)frames.Count + 1 &&
                    Hex(header.AsSpan(40, 32)) == previous);
                var n = System.Buffers.Binary.BinaryPrimitives.ReadUInt32LittleEndian(header.AsSpan(12));
                Require(n is > 0 and <= MaximumPayloadBytes && total + 112L + n <= MaximumJournalBytes);
                var bytes = new byte[112 + (int)n]; header.CopyTo(bytes, 0); input.ReadExactly(bytes.AsSpan(72));
                var frame = DecodeFrame(bytes);
                Require(frame.JournalId == metadata.JournalId && frame.Sequence == (ulong)frames.Count + 1 && frame.PreviousDigest == previous &&
                    frame.Snapshot.Context.Deployment == deployment && frame.Snapshot.Context.ResourceScope == scope);
                Apply(frame.Event, frame.Snapshot, attempts, requests); frames.Add(frame); previous = frame.Digest; total += bytes.Length;
            }
        }
        catch (EndOfStreamException error) { throw new InvalidDataException("Incomplete host journal tail; retain all bytes and reconcile.", error); }
        return new(frames.AsReadOnly());
    }
    internal static void ValidateExtension(HostJournalReadResult history, HostJournalFrame next)
    {
        Require(history is not null && history.Frames is not null && history.Frames.Count < MaximumFrames && next is not null);
        var count = history.Frames.Count;
        Require(next.Sequence == (ulong)count + 1 && next.PreviousDigest == (count == 0 ? ZeroHash : history.Frames[count - 1].Digest));
        var attempts = new Dictionary<Guid, HostLedgerSnapshot>(); var requests = new Dictionary<Guid, HostLedgerSnapshot>();
        for (var index = 0; index < count; index++)
        {
            var frame = history.Frames[index]; Require(frame is not null && frame.JournalId == next.JournalId);
            Apply(frame.Event, frame.Snapshot, attempts, requests);
        }
        Apply(next.Event, next.Snapshot, attempts, requests);
    }
    private static void Apply(HostJournalEvent kind, HostLedgerSnapshot next, Dictionary<Guid, HostLedgerSnapshot> attempts, Dictionary<Guid, HostLedgerSnapshot> requests)
    {
        var c = next.Context; var id = c.Intent.AttemptId;
        if (kind == HostJournalEvent.RecordIntent)
        {
            Require(attempts.Count < MaximumAttempts && !attempts.ContainsKey(id));
            if (requests.TryGetValue(c.RequestId, out var prior))
            {
                // Version 1 cannot encode independent-destination reasoning. Same-request retries
                // are limited to the identical intent/destination after reconciled absence.
                Require(prior.Stage == HostLedgerStage.ReconciledAbsent && c.Intent with { AttemptId = prior.Context.Intent.AttemptId } == prior.Context.Intent);
            }
            attempts.Add(id, next); requests[c.RequestId] = next; return;
        }
        Require(attempts.TryGetValue(id, out var old)); var oldContext = old.Context;
        Require(oldContext.Revision < ulong.MaxValue && c.Revision == oldContext.Revision + 1);
        if (kind == HostJournalEvent.TransferOwner)
        {
            Require(c.OwnerSession != oldContext.OwnerSession && c.OwnerGeneration > oldContext.OwnerGeneration &&
                c with { Revision = oldContext.Revision, OwnerSession = oldContext.OwnerSession, OwnerGeneration = oldContext.OwnerGeneration } == oldContext);
        }
        else Require(c with { Revision = oldContext.Revision } == oldContext);
        Require(kind switch
        {
            HostJournalEvent.AuthorizeDispatch => old.Stage == HostLedgerStage.Recorded,
            HostJournalEvent.MarkUncertain => old.Stage == HostLedgerStage.DispatchAuthorized,
            HostJournalEvent.Acknowledge => old.Stage is HostLedgerStage.DispatchAuthorized or HostLedgerStage.Uncertain or HostLedgerStage.ObservedKnown,
            HostJournalEvent.ObserveKnown => old.Stage is HostLedgerStage.DispatchAuthorized or HostLedgerStage.Uncertain,
            HostJournalEvent.ReconcileAbsent => old.Stage is HostLedgerStage.Recorded or HostLedgerStage.DispatchAuthorized or HostLedgerStage.Uncertain && old.Receipt is null && old.Observed is null,
            HostJournalEvent.TransferOwner => next.Stage == (old.Stage is HostLedgerStage.Recorded or HostLedgerStage.DispatchAuthorized ? HostLedgerStage.Uncertain : old.Stage),
            _ => false
        });
        if (kind != HostJournalEvent.Acknowledge) Require(next.Receipt == old.Receipt);
        if (kind != HostJournalEvent.ObserveKnown) Require(next.Observed == old.Observed);
        attempts[id] = next;
        if (requests[c.RequestId].Context.Intent.AttemptId == id) requests[c.RequestId] = next;
    }
}
