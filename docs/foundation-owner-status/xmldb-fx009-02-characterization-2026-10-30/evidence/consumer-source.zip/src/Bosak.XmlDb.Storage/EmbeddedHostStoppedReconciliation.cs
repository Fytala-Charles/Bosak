// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Registers stopped reconciliation without opening administrative admissions.
// SPECIAL NOTES        : Internal ProcessCrash append only; uncertain sessions remain faulted and all writers stopped.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 29-10-2026     | Exclude paired application inspection from stopped sessions
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal sealed partial class EmbeddedHostLifetime
{
    internal IDisposable BeginStoppedReconciliation(HostJournalPosition expected, EmbeddedHostInspectionEvidence evidence)
    {
        ArgumentNullException.ThrowIfNull(expected); ArgumentNullException.ThrowIfNull(evidence);
        if (evidence.Context != Context || !evidence.Fresh || !evidence.AllWritersControlled || !evidence.AllPublishersControlled ||
            !evidence.PriorExecutorsExcluded || !evidence.QueueFree)
            throw new InvalidOperationException("Stopped reconciliation requires fresh bound controlled-scope exclusion.");
        lock (_appendGate)
        {
            lock (_gate)
            {
                ObjectDisposedException.ThrowIf(_closing, this);
                EnsureJournalSession();
                if (_admissions || _operations != 0 || _applicationRegistration is not null || _stoppedRegistration is not null || _executorRegistration is not null)
                    throw new InvalidOperationException("Reconciliation requires exclusive stopped lifetime state.");
                if (expected != KnownPosition()) throw new InvalidOperationException("Reconciliation position changed.");
                if (ReadAndVerifyKnown().Frames.Count == 0) throw new InvalidOperationException("Empty history has no stopped attempt to reconcile.");
                var registration = new StoppedRegistration(this); _stoppedRegistration = registration; _operations++;
                return registration;
            }
        }
    }
    internal HostJournalAppendResult AppendStopped(IDisposable registration, HostJournalPosition expected, HostJournalEvent kind,
        HostLedgerSnapshot snapshot, Action<HostAppendStage>? checkpoint = null) =>
        AppendJournalCore(expected, kind, snapshot, new LocalAppendIo(), checkpoint, stoppedRegistration: registration ?? throw new ArgumentNullException(nameof(registration)));

    private void RequireStoppedRegistration(IDisposable registration)
    {
        lock (_gate)
        {
            ObjectDisposedException.ThrowIf(_closing, this);
            if (_applicationRegistration is not null || _stoppedRegistration is null || !ReferenceEquals(registration, _stoppedRegistration) || _admissions || Volatile.Read(ref _journalFaulted))
                throw new InvalidOperationException("Stopped registration is foreign, completed or faulted.");
        }
    }
    private IDisposable RegisterStoppedAppend(IDisposable registration)
    {
        lock (_gate)
        {
            RequireStoppedRegistration(registration);
            if (_operations == MaximumOperations) throw new InvalidOperationException("Operation limit reached.");
            _operations++; return new Operation(this);
        }
    }
    private void CompleteStopped(StoppedRegistration registration)
    {
        lock (_appendGate)
        {
            lock (_gate)
            {
                if (!ReferenceEquals(_stoppedRegistration, registration)) throw new InvalidOperationException("Stopped registration mismatch.");
                if (_appendInProgress) throw new InvalidOperationException("Cannot dispose stopped registration from an append callback.");
                _stoppedRegistration = null; _operations--; if (_closing && _operations == 0) ReleaseHandles();
            }
        }
    }
    private sealed class StoppedRegistration(EmbeddedHostLifetime owner) : IDisposable
    {
        private bool _disposed;
        /// <inheritdoc/>
        public void Dispose()
        {
            lock (owner._appendGate) { if (_disposed) return; owner.CompleteStopped(this); _disposed = true; }
        }
    }
}
