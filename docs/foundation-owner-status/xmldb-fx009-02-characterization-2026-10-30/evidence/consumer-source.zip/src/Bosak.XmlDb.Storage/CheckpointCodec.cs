// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Encodes immutable checkpoint anchors and bound WAL prefix identities.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.4   | 26-10-2026     | Add recovery descriptors and conservative retention inventory
// ===========================================================================================================================================================

using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

/// <summary>Selects recovery from full history or a verified optional checkpoint.</summary>
public enum RecoveryMode
{
    /// <summary>Validates/materializes every committed generation from the imported base.</summary>
    FullJournal = 0,
    /// <summary>Validates retained WAL history and uses a verified checkpoint to skip earlier materializations.</summary>
    PreferCheckpoint = 1,
}

/// <summary>Reports the work performed during the coordinator's most recent open.</summary>
/// <param name="CheckpointSequence">Selected anchor sequence, or zero for full recovery.</param>
/// <param name="WalRecordsValidated">Complete WAL records validated, including retained prefix records.</param>
/// <param name="GenerationsValidated">Generation/checkpoint materializations checked.</param>
/// <param name="GenerationsReplayed">Missing generation directories reconstructed.</param>
/// <param name="CheckpointRejected">An optional selector/anchor could not be verified; an alternative descriptor or full recovery was used.</param>
public readonly record struct RecoveryStatistics(ulong CheckpointSequence, int WalRecordsValidated,
    int GenerationsValidated, int GenerationsReplayed, bool CheckpointRejected);

internal sealed record CheckpointAnchor(ulong DocumentId, ulong Sequence, byte[] ManifestHash,
    byte[] WalHash, byte[] PrefixHash);
internal sealed record CheckpointCandidate(string Root, CheckpointAnchor Anchor);

internal static class CheckpointCodec
{
    internal static byte[] Encode(CheckpointAnchor anchor) => BinaryEnvelope.Encode("BXCP", writer =>
    {
        writer.Write(anchor.DocumentId);
        writer.Write(anchor.Sequence);
        writer.Write(anchor.ManifestHash);
        writer.Write(anchor.WalHash);
        writer.Write(anchor.PrefixHash);
        writer.Write((ushort)1); // Referenced M1 materialization format.
        writer.Write((ushort)0);
    });

    internal static CheckpointAnchor Decode(byte[] bytes) => BinaryEnvelope.Decode(bytes, "BXCP", reader =>
    {
        var anchor = new CheckpointAnchor(reader.ReadUInt64(), reader.ReadUInt64(), reader.ReadBytes(32), reader.ReadBytes(32), reader.ReadBytes(32));
        if (anchor.DocumentId == 0 || anchor.Sequence is 0 or > 10_000 ||
            anchor.ManifestHash.Length != 32 || anchor.WalHash.Length != 32 || anchor.PrefixHash.Length != 32 ||
            reader.ReadUInt16() != 1 || reader.ReadUInt16() != 0)
            throw new InvalidDataException("Invalid checkpoint identity or referenced format.");
        return anchor;
    });

    internal static byte[] ExtendPrefix(byte[] prefix, byte[] walBytes)
    {
        Span<byte> combined = stackalloc byte[64];
        prefix.CopyTo(combined);
        SHA256.HashData(walBytes, combined[32..]);
        return SHA256.HashData(combined);
    }

    internal static string DirectoryPath(string transactions, ulong sequence) =>
        Path.Combine(transactions, "checkpoints", sequence.ToString("D20", System.Globalization.CultureInfo.InvariantCulture));

    internal static CheckpointCandidate? TryLoad(string transactions, ulong documentId, out bool rejected)
    {
        var candidate = TryLoadSelector(transactions, documentId, Path.Combine(transactions, "CHECKPOINT"), out rejected);
        if (candidate is not null) return candidate;
        var anchors = Path.Combine(transactions, "anchors");
        if (!Directory.Exists(anchors)) return null;
        foreach (var path in Directory.GetFiles(anchors).OrderDescending(StringComparer.Ordinal))
        {
            var name = Path.GetFileName(path);
            if (name.Length != 27 || !name.EndsWith(".anchor", StringComparison.Ordinal) ||
                !ulong.TryParse(name.AsSpan(0, 20), out var sequence) ||
                name != sequence.ToString("D20", System.Globalization.CultureInfo.InvariantCulture) + ".anchor")
            { rejected = true; continue; }
            candidate = TryLoadSelector(transactions, documentId, path, out var invalid);
            rejected |= invalid;
            if (candidate is not null && candidate.Anchor.Sequence == sequence) return candidate;
            rejected = true;
        }
        return null;
    }

    private static CheckpointCandidate? TryLoadSelector(string transactions, ulong documentId, string selector, out bool rejected)
    {
        rejected = false;
        if (!File.Exists(selector) && !Directory.Exists(selector)) return null;
        try
        {
            var pointer = TransactionCodec.ReadPointer(selector, "BXCS");
            if (pointer.DocumentId != documentId || pointer.Sequence is 0 or > 10_000)
                throw new InvalidDataException("Invalid checkpoint selector identity.");
            var root = DirectoryPath(transactions, pointer.Sequence);
            var bytes = BinaryEnvelope.ReadFile(Path.Combine(root, "anchor.bin"));
            if (!SHA256.HashData(bytes).AsSpan().SequenceEqual(pointer.ManifestHash))
                throw new InvalidDataException("Checkpoint selector does not match its anchor.");
            var anchor = Decode(bytes);
            if (anchor.DocumentId != documentId || anchor.Sequence != pointer.Sequence)
                throw new InvalidDataException("Checkpoint anchor does not match its selector.");
            ScalarGeneration.Validate(root, documentId, anchor.ManifestHash);
            return new(root, anchor);
        }
        catch (Exception exception) when (exception is IOException or InvalidDataException)
        {
            // Optional optimization only: retained full history must still independently validate.
            rejected = true;
            return null;
        }
    }

    internal static void CopyMaterialization(string source, string destination, ulong documentId,
        byte[] manifestHash, ITransactionStorage storage, Action<CommitStage>? checkpoint)
    {
        ScalarGeneration.Validate(source, documentId, manifestHash);
        TransactionCodec.EnsureDirectory(destination, storage);
        checkpoint?.Invoke(CommitStage.CheckpointStageCreated);
        var documentPath = TransactionCodec.DocumentPath(destination, documentId);
        TransactionCodec.EnsureDirectory(documentPath, storage);
        var fragments = Path.Combine(destination, "fragments");
        TransactionCodec.EnsureDirectory(fragments, storage);
        TransactionCodec.WriteFlushed(Path.Combine(destination, "FORMAT"), BinaryEnvelope.ReadFile(Path.Combine(source, "FORMAT")), storage);
        var manifestBytes = TransactionCodec.ReadManifestBytes(source, documentId);
        var manifest = StoreCodec.ReadManifest(manifestBytes);
        foreach (var entry in manifest.Fragments)
        {
            var name = entry.Id.ToString(System.Globalization.CultureInfo.InvariantCulture) + ".bin";
            TransactionCodec.WriteFlushed(Path.Combine(fragments, name), BinaryEnvelope.ReadFile(Path.Combine(source, "fragments", name)), storage);
        }
        TransactionCodec.WriteFlushed(Path.Combine(documentPath, "directory.bin"),
            BinaryEnvelope.ReadFile(Path.Combine(TransactionCodec.DocumentPath(source, documentId), "directory.bin")), storage);
        TransactionCodec.WriteFlushed(Path.Combine(documentPath, "manifest.bin"), manifestBytes, storage);
        ScalarGeneration.Validate(destination, documentId, manifestHash);
        checkpoint?.Invoke(CommitStage.CheckpointFilesFlushed);
    }
}

