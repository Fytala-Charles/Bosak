// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Checks native regular-file identity and single-link authority role ownership.
// SPECIAL NOTES        : Windows NTFS and Linux x64/arm64 local filesystems only; unsupported native queries fail closed.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.ComponentModel;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

namespace Bosak.XmlDb.Storage;

internal readonly record struct ApplicationFileIdentity(ulong Volume, ulong Low, ulong High);

/// <summary>Checks native regular-file identity and single-link authority role ownership.</summary>
internal static class ApplicationAuthorityFileIdentity
{
    internal static void RequirePlatform()
    {
        if (!(OperatingSystem.IsWindows() || OperatingSystem.IsLinux()) || RuntimeInformation.ProcessArchitecture is not (Architecture.X64 or Architecture.Arm64))
            throw new PlatformNotSupportedException("Authority ownership requires Windows/Linux x64 or arm64 native identity support.");
    }

    internal static ApplicationFileIdentity PathIdentity(string path, bool directory)
    {
        RequirePlatform(); BinaryEnvelope.RejectLinks(path);
        if (OperatingSystem.IsWindows())
        {
            var drive = new DriveInfo(Path.GetPathRoot(path)!);
            if (drive.DriveType != DriveType.Fixed || !string.Equals(drive.DriveFormat, "NTFS", StringComparison.OrdinalIgnoreCase))
                throw new NotSupportedException("Authority inspection supports local fixed NTFS only on Windows.");
            using var handle = CreateFile(path, 0, 7, IntPtr.Zero, 3, 0x02200000, IntPtr.Zero);
            if (handle.IsInvalid) throw Error("Cannot query authority path identity.");
            return WindowsIdentity(handle, directory);
        }
        RequireLinuxFileSystem(path);
        var stat = LinuxStat(-100, path, 0x100); return LinuxIdentity(stat, directory);
    }

    internal static ApplicationFileIdentity HandleIdentity(FileStream file, bool directory = false)
    {
        RequirePlatform();
        if (OperatingSystem.IsWindows()) return WindowsIdentity(file.SafeFileHandle, directory);
        var added = false;
        try
        {
            file.SafeFileHandle.DangerousAddRef(ref added); var descriptor = file.SafeFileHandle.DangerousGetHandle().ToInt32();
            if (Fstatfs(descriptor, out var fs) != 0) throw Error("Cannot query authority handle filesystem.");
            RequireLinuxType(fs.Type); return LinuxIdentity(LinuxStat(descriptor, "", 0x1000), directory);
        }
        finally { if (added) file.SafeFileHandle.DangerousRelease(); }
    }

    private static ApplicationFileIdentity WindowsIdentity(SafeFileHandle handle, bool directory)
    {
        if (GetFileType(handle) != 1 || !GetStandard(handle, 1, out var standard, 24) || !GetAttributes(handle, 9, out var attributes, 8) || !GetIdentity(handle, 18, out var identity, 24))
            throw Error("Cannot establish native disk file identity.");
        if (standard.DeletePending != 0 || (standard.Directory != 0) != directory || (attributes.Attributes & 0x400) != 0 || !directory && standard.Links != 1)
            throw new InvalidDataException("Authority roles require regular single-link files and stable directories.");
        return new(identity.Volume, identity.Low, identity.High);
    }
    private static Statx LinuxStat(int descriptor, string path, int flags)
    {
        try
        {
            if (Stat(descriptor, path, flags, 0x105, out var value) != 0) throw Error("Cannot establish Linux authority identity.");
            if ((value.Mask & 0x105) != 0x105) throw new NotSupportedException("Required Linux identity/link fields are unavailable.");
            return value;
        }
        catch (Exception error) when (error is EntryPointNotFoundException or DllNotFoundException)
        { throw new PlatformNotSupportedException("Linux statx identity support is required without fallback.", error); }
    }
    private static ApplicationFileIdentity LinuxIdentity(Statx value, bool directory)
    {
        if ((value.Mode & 0xF000) != (directory ? 0x4000 : 0x8000) || !directory && value.Links != 1)
            throw new InvalidDataException("Authority roles require regular single-link files and stable directories.");
        return new(((ulong)value.DeviceMajor << 32) | value.DeviceMinor, value.Inode, 0);
    }
    private static void RequireLinuxFileSystem(string path)
    {
        if (Statfs(path, out var value) != 0) throw Error("Cannot query authority filesystem.");
        RequireLinuxType(value.Type);
    }
    private static void RequireLinuxType(long type)
    {
        if (type is not (0xEF53 or 0x794c7630 or 0x01021994))
            throw new NotSupportedException("Authority inspection supports Linux ext-family, overlayfs and tmpfs only.");
    }
    private static IOException Error(string message) => new(message, new Win32Exception(Marshal.GetLastPInvokeError()));

    [StructLayout(LayoutKind.Explicit, Size = 24)]
    private struct StandardInfo
    {
        [FieldOffset(16)] internal uint Links;
        [FieldOffset(20)] internal byte DeletePending;
        [FieldOffset(21)] internal byte Directory;
    }
    [StructLayout(LayoutKind.Sequential)]
    private struct AttributeInfo { internal uint Attributes; internal uint ReparseTag; }
    [StructLayout(LayoutKind.Sequential)]
    private struct FileIdentity { internal ulong Volume; internal ulong Low; internal ulong High; }
    // Linux UAPI statx is exactly 256 bytes; only the requested fixed-offset fields are read.
    [StructLayout(LayoutKind.Explicit, Size = 256)]
    private struct Statx
    {
        [FieldOffset(0)] internal uint Mask;
        [FieldOffset(16)] internal uint Links;
        [FieldOffset(28)] internal ushort Mode;
        [FieldOffset(32)] internal ulong Inode;
        [FieldOffset(136)] internal uint DeviceMajor;
        [FieldOffset(140)] internal uint DeviceMinor;
    }
    // x64/arm64 libc statfs writes at most this buffer; only its first native long is consumed.
    [StructLayout(LayoutKind.Explicit, Size = 256)]
    private struct FileSystemInfo { [FieldOffset(0)] internal long Type; }

    [DllImport("kernel32.dll", EntryPoint = "CreateFileW", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern SafeFileHandle CreateFile(string path, uint access, uint share, IntPtr security, uint creation, uint flags, IntPtr template);
    [DllImport("kernel32.dll", EntryPoint = "GetFileType", SetLastError = true)]
    private static extern uint GetFileType(SafeFileHandle handle);
    [DllImport("kernel32.dll", EntryPoint = "GetFileInformationByHandleEx", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetStandard(SafeFileHandle handle, int kind, out StandardInfo value, uint size);
    [DllImport("kernel32.dll", EntryPoint = "GetFileInformationByHandleEx", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetAttributes(SafeFileHandle handle, int kind, out AttributeInfo value, uint size);
    [DllImport("kernel32.dll", EntryPoint = "GetFileInformationByHandleEx", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetIdentity(SafeFileHandle handle, int kind, out FileIdentity value, uint size);
    [DllImport("libc", EntryPoint = "statx", SetLastError = true)]
    private static extern int Stat(int descriptor, [MarshalAs(UnmanagedType.LPUTF8Str)] string path, int flags, uint mask, out Statx value);
    [DllImport("libc", EntryPoint = "statfs", SetLastError = true)]
    private static extern int Statfs([MarshalAs(UnmanagedType.LPUTF8Str)] string path, out FileSystemInfo value);
    [DllImport("libc", EntryPoint = "fstatfs", SetLastError = true)]
    private static extern int Fstatfs(int descriptor, out FileSystemInfo value);
}
