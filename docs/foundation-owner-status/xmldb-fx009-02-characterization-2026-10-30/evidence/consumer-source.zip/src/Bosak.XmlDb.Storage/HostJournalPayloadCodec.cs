// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Encodes and strictly decodes bounded host-only journal snapshot TLV payloads.
// SPECIAL NOTES        : Internal pure codec; structural replay never proves durability, freshness or dispatch authority.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal static partial class HostJournalCodec
{
    internal static byte[] EncodePayload(HostJournalEvent kind, HostLedgerSnapshot snapshot)
    {
        ValidateSnapshot(kind, snapshot); var c = snapshot.Context;
        return Tlv((1, One(EventWire(kind))), (2, GuidBytes(c.RequestId)), (3, Text(c.Deployment)), (4, Text(c.ResourceScope)),
            (5, Descriptor(c.Intent)), (6, U64(c.Revision)), (7, GuidBytes(c.OwnerSession)), (8, U64(c.OwnerGeneration)), (9, One(StageWire(snapshot.Stage))),
            (10, snapshot.Receipt is { } r ? Publication(r.Kind, r.OperationId, r.BackupId, r.SourceEpoch, r.DestinationEpoch, r.CommitSequence, r.StorePath) : null),
            (11, snapshot.Observed is { } o ? Publication(o.Kind, o.OperationId, o.BackupId, o.SourceEpoch, o.DestinationEpoch, o.CommitSequence, o.StorePath) : null));
    }
    internal static (HostJournalEvent Event, HostLedgerSnapshot Snapshot) DecodePayload(ReadOnlySpan<byte> bytes)
    {
        Require(bytes.Length is > 0 and <= MaximumPayloadBytes); var f = new Fields(bytes);
        var kind = ReadEvent(ReadByte(f.Take(1))); var request = ReadGuid(f.Take(2)); var deployment = ReadText(f.Take(3)); var scope = ReadText(f.Take(4));
        var descriptor = ReadDescriptor(f.Take(5)); var revision = ReadU64(f.Take(6)); var owner = ReadGuid(f.Take(7)); var generation = ReadU64(f.Take(8));
        var stage = ReadStage(ReadByte(f.Take(9))); var receiptBytes = f.Take(10, true); var observedBytes = f.Take(11, true); f.End();
        var receipt = receiptBytes.IsEmpty ? null : ReadPublication(receiptBytes);
        var observed = observedBytes.IsEmpty ? null : ReadPublication(observedBytes);
        var snapshot = new HostLedgerSnapshot(new(request, deployment, scope, descriptor, revision, owner, generation), stage,
            receipt is null ? null : new(receipt.Kind, receipt.OperationId, receipt.BackupId, receipt.SourceEpoch, receipt.DestinationEpoch, receipt.CommitSequence, receipt.StorePath), observed);
        ValidateSnapshot(kind, snapshot); return (kind, snapshot);
    }
    private static byte[] Descriptor(EpochAdministrativeAttemptDescriptor d) => Tlv((1, GuidBytes(d.AttemptId)), (2, One(KindWire(d.Kind))),
        (3, Text(d.ArtifactRoot)), (4, Text(d.BundleRoot)), (5, Hash(d.InventorySha256)), (6, GuidBytes(d.BackupId)), (7, U64(d.DocumentId)),
        (8, U64(d.CommitSequence)), (9, d.SourceEpoch is null ? null : Epoch(d.SourceEpoch)), (10, One(d.DestinationProfile == EpochProfile.ScalarWal ? (byte)1 : InvalidByte())),
        (11, One(d.Durability == DurabilityMode.ProcessCrash ? (byte)1 : InvalidByte())));
    private static EpochAdministrativeAttemptDescriptor ReadDescriptor(ReadOnlySpan<byte> bytes)
    {
        var f = new Fields(bytes); var attempt = ReadGuid(f.Take(1)); var kind = ReadKind(ReadByte(f.Take(2))); var artifact = ReadText(f.Take(3)); var bundle = ReadText(f.Take(4));
        var hash = f.Take(5); Require(hash.Length == 32); var digest = Hex(hash); var backup = ReadGuid(f.Take(6)); var document = ReadU64(f.Take(7)); var head = ReadU64(f.Take(8));
        var sourceBytes = f.Take(9, true); var source = sourceBytes.IsEmpty ? null : ReadEpoch(sourceBytes);
        Require(ReadByte(f.Take(10)) == 1 && ReadByte(f.Take(11)) == 1); f.End();
        return new(attempt, kind, artifact, bundle, digest, backup, document, head, source, EpochProfile.ScalarWal, DurabilityMode.ProcessCrash);
    }
    private static byte[] Epoch(EpochIdentity epoch) => Tlv((1, GuidBytes(epoch.StoreId)), (2, GuidBytes(epoch.EpochId)), (3, U64(epoch.DocumentId)));
    private static EpochIdentity ReadEpoch(ReadOnlySpan<byte> bytes)
    {
        var f = new Fields(bytes); var store = ReadGuid(f.Take(1)); var epoch = ReadGuid(f.Take(2)); var document = ReadU64(f.Take(3)); Require(document != 0); f.End(); return new(store, epoch, document);
    }
    private static byte[] Publication(EpochPublicationKind kind, Guid operation, Guid backup, EpochIdentity? source, EpochIdentity destination, ulong head, string path) =>
        Tlv((1, One(KindWire(kind))), (2, GuidBytes(operation)), (3, GuidBytes(backup)), (4, source is null ? null : Epoch(source)), (5, Epoch(destination)), (6, U64(head)), (7, Text(path)));
    private static EpochObservedPublication ReadPublication(ReadOnlySpan<byte> bytes)
    {
        var f = new Fields(bytes); var kind = ReadKind(ReadByte(f.Take(1))); var operation = ReadGuid(f.Take(2)); var backup = ReadGuid(f.Take(3));
        var sourceBytes = f.Take(4, true); var source = sourceBytes.IsEmpty ? null : ReadEpoch(sourceBytes); var destination = ReadEpoch(f.Take(5)); var head = ReadU64(f.Take(6)); var path = ReadText(f.Take(7)); f.End();
        return new(kind, operation, backup, source, destination, head, path);
    }
    private static void ValidateSnapshot(HostJournalEvent kind, HostLedgerSnapshot snapshot)
    {
        Require(snapshot is not null && HostAttemptLedgerClassifier.IsValidContext(snapshot.Context));
        var c = snapshot.Context; Require(c.Intent.Durability == DurabilityMode.ProcessCrash); _ = EventWire(kind); _ = StageWire(snapshot.Stage);
        Require(kind == HostJournalEvent.RecordIntent ? c.Revision == 1 : c.Revision > 1);
        Require(kind switch
        {
            HostJournalEvent.RecordIntent => snapshot.Stage == HostLedgerStage.Recorded,
            HostJournalEvent.AuthorizeDispatch => snapshot.Stage == HostLedgerStage.DispatchAuthorized,
            HostJournalEvent.MarkUncertain => snapshot.Stage == HostLedgerStage.Uncertain,
            HostJournalEvent.Acknowledge => snapshot.Stage == HostLedgerStage.Acknowledged,
            HostJournalEvent.ObserveKnown => snapshot.Stage == HostLedgerStage.ObservedKnown,
            HostJournalEvent.ReconcileAbsent => snapshot.Stage == HostLedgerStage.ReconciledAbsent,
            HostJournalEvent.TransferOwner => snapshot.Stage is not (HostLedgerStage.Recorded or HostLedgerStage.DispatchAuthorized),
            _ => false
        });
        Require(snapshot.Stage == HostLedgerStage.Acknowledged ? snapshot.Receipt is not null : snapshot.Receipt is null);
        Require(snapshot.Stage == HostLedgerStage.ObservedKnown ? snapshot.Observed is not null : snapshot.Stage == HostLedgerStage.Acknowledged || snapshot.Observed is null);
        if (snapshot.Receipt is { } r) Require(HostAttemptLedgerClassifier.ReceiptMatches(c, r));
        if (snapshot.Observed is { } o)
        {
            var d = c.Intent; Require(o.Kind == d.Kind && o.OperationId == d.AttemptId && o.BackupId == d.BackupId && o.SourceEpoch == d.SourceEpoch &&
                o.DestinationEpoch is { } e && e.StoreId != Guid.Empty && e.EpochId != Guid.Empty && e.DocumentId == d.DocumentId &&
                (d.SourceEpoch is null || e.StoreId != d.SourceEpoch.StoreId && e.EpochId != d.SourceEpoch.EpochId) &&
                o.CommitSequence == d.CommitSequence && o.StorePath == Path.Combine(d.BundleRoot, "store"));
        }
        Require(snapshot.Receipt is not { } receipt || snapshot.Observed is not { } observed || receipt.DestinationEpoch == observed.DestinationEpoch);
    }
    private static byte InvalidByte() => throw new InvalidDataException("Unsupported host journal wire value.");
    private static byte KindWire(EpochPublicationKind kind) => kind switch { EpochPublicationKind.LegacyMigration => 1, EpochPublicationKind.IndependentEpochRestore => 2, _ => InvalidByte() };
    private static EpochPublicationKind ReadKind(byte kind) => kind switch { 1 => EpochPublicationKind.LegacyMigration, 2 => EpochPublicationKind.IndependentEpochRestore, _ => throw new InvalidDataException("Unknown publication kind.") };
    private static byte EventWire(HostJournalEvent kind) => kind switch
    {
        HostJournalEvent.RecordIntent => 1,
        HostJournalEvent.AuthorizeDispatch => 2,
        HostJournalEvent.MarkUncertain => 3,
        HostJournalEvent.Acknowledge => 4,
        HostJournalEvent.ObserveKnown => 5,
        HostJournalEvent.ReconcileAbsent => 6,
        HostJournalEvent.TransferOwner => 7,
        _ => InvalidByte()
    };
    private static HostJournalEvent ReadEvent(byte kind) => kind switch
    {
        1 => HostJournalEvent.RecordIntent,
        2 => HostJournalEvent.AuthorizeDispatch,
        3 => HostJournalEvent.MarkUncertain,
        4 => HostJournalEvent.Acknowledge,
        5 => HostJournalEvent.ObserveKnown,
        6 => HostJournalEvent.ReconcileAbsent,
        7 => HostJournalEvent.TransferOwner,
        _ => throw new InvalidDataException("Unknown journal event.")
    };
    private static byte StageWire(HostLedgerStage stage) => stage switch
    {
        HostLedgerStage.Recorded => 1,
        HostLedgerStage.DispatchAuthorized => 2,
        HostLedgerStage.Uncertain => 3,
        HostLedgerStage.Acknowledged => 4,
        HostLedgerStage.ObservedKnown => 5,
        HostLedgerStage.ReconciledAbsent => 6,
        _ => InvalidByte()
    };
    private static HostLedgerStage ReadStage(byte stage) => stage switch
    {
        1 => HostLedgerStage.Recorded,
        2 => HostLedgerStage.DispatchAuthorized,
        3 => HostLedgerStage.Uncertain,
        4 => HostLedgerStage.Acknowledged,
        5 => HostLedgerStage.ObservedKnown,
        6 => HostLedgerStage.ReconciledAbsent,
        _ => throw new InvalidDataException("Unknown journal stage.")
    };
}
