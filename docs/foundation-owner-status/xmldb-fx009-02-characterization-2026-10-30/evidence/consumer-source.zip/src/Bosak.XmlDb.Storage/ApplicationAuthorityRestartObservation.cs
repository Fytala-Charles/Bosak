// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 30 October 2026
// PURPOSE              : Observes stopped restart facts under actual paired ownership and retained source exclusion.
// SPECIAL NOTES        : Internal read-only single-use scope; no recovery, acknowledgment or handoff authority.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 30-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

internal sealed record ApplicationRestartEvidence(EmbeddedHostContext Context, Guid AuthorityId, string? CaptureRootKey,
    EnrollmentRestartFact FreshScope, EnrollmentRestartFact PriorWorkReconciled, EnrollmentRestartFact ExecutorsDrained,
    EnrollmentRestartFact PublishersDrained, EnrollmentRestartFact ReleaseReconciled);
internal enum RestartObservationStage { Registered, SourceRetained, BeforeBaseline, BaselineVerified, BeforeFinalValidation }
internal interface IRestartObservationProbe
{
    void BeforeProtectedPathRead(string path);
    void AtStage(RestartObservationStage stage);
}
internal sealed record ApplicationRestartDescription(Guid ObservationId, bool AdministrativeReconciliationRequired, EnrollmentRestartObservations Observations,
    EnrollmentRestartAssessment Assessment)
{ internal bool WritersMustRemainStopped => true; }

/// <summary>Observes stopped restart facts under actual paired ownership and retained source exclusion.</summary>
internal sealed partial class ApplicationAuthorityLifetime
{
    private bool _restartObservationMode;
    private bool _restartObservationReady;
    private StoppedRestartObservation? _restartObservation;
    private StoppedRestartObservation? _unreleasedRestartObservation;

    internal StoppedRestartObservation BeginRestartObservation(EmbeddedXmlDatabase? source, ApplicationRestartEvidence evidence) =>
        BeginRestartObservationCore(source, evidence, null, null);

    internal StoppedRestartObservation BeginRestartObservationCore(EmbeddedXmlDatabase? source, ApplicationRestartEvidence evidence,
        IRestartObservationProbe? probe, IEnrollmentSourceLeaseClose? sourceClose)
    {
        ArgumentNullException.ThrowIfNull(evidence);
        RequireRetainedEntryWithoutCallerLocks(source is not null && EmbeddedXmlDatabase.RetainedEnrollmentSource.IsOwnerGateEntered(source));
        if (_configuration.Durability != DurabilityMode.ProcessCrash || source is not null && source.Durability != DurabilityMode.ProcessCrash)
            throw new NotSupportedException("Restart observation supports ProcessCrash only without fallback.");
        if (evidence.Context != _parent.Context || evidence.AuthorityId != _configuration.AuthorityId ||
            evidence.FreshScope != EnrollmentRestartFact.Confirmed || evidence.ExecutorsDrained != EnrollmentRestartFact.Confirmed ||
            evidence.PublishersDrained != EnrollmentRestartFact.Confirmed || !Enum.IsDefined(evidence.PriorWorkReconciled) || !Enum.IsDefined(evidence.ReleaseReconciled))
            throw new InvalidOperationException("Restart requires exact fresh controlled stopped-scope assertions.");
        if (evidence.CaptureRootKey is { } key && (!_roots.ContainsKey(key) ||
            string.Equals(key, _configuration.AdministrativeRootKey, StringComparison.OrdinalIgnoreCase) ||
            string.Equals(key, _configuration.AuthorityRootKey, StringComparison.OrdinalIgnoreCase) ||
            string.Equals(key, History.Source?.RootKey, StringComparison.OrdinalIgnoreCase)))
            throw new InvalidDataException("Capture needs an explicit separate protected root mapping.");
        StoppedRestartObservation scope;
        lock (_gate)
        {
            ObjectDisposedException.ThrowIf(_closing, this);
            if (_faulted || _provisioned || _initializerClaimed || _retainedEnrollmentMode || _restartObservationMode || _reads != 0)
                throw new InvalidOperationException("Restart observation requires an unused existing-root inspection session.");
            var read = _registration.BeginRead(_parent); _reads++; _restartObservationMode = true;
            scope = new(this, source, evidence, new Inspection(this, read), _parent.JournalStatus.KnownPosition, probe);
            _restartObservation = scope;
        }
        try
        {
            scope.Stage(RestartObservationStage.Registered);
            // Blocking source admission is outside every peer gate; real paired reads span this gap.
            if (source is not null && History.Frames.Length == 1 && History.Source?.Kind == PilotRootKind.Legacy)
                scope.InstallSource(EmbeddedXmlDatabase.RetainedRestartSource.AcquireCore(source, true, sourceClose));
            scope.Stage(RestartObservationStage.SourceRetained);
            scope.InitializeParentIdentity();
            _restartObservationReady = true;
            return scope;
        }
        catch (Exception primary)
        {
            lock (_gate) _faulted = true;
            try { scope.Dispose(); }
            catch (Exception cleanup) { throw new AggregateException(primary, cleanup); }
            throw;
        }
    }

    private ApplicationAuthorityHistory ReadRestartJournal(StoppedRestartObservation scope)
    {
        RequireRestartEntry(scope);
        if (_registration.InspectRestartParentIdentity(_parent) != scope.ParentIdentity) throw new InvalidDataException("Restart parent identity changed.");
        _registration.VerifyRetainedEnrollmentParent(_parent, scope.AdministrativePosition);
        if (_registration.InspectRestartParentIdentity(_parent) != scope.ParentIdentity) throw new InvalidDataException("Restart parent identity changed during read.");
        lock (_readGate)
        {
            var read = ReadAppendAuthority();
            if (read.Length != _length || HashRestart(read.Bytes) != _digest)
                throw new InvalidDataException("Restart authority differs from its exact acquisition history; no head adopted.");
            return read.History;
        }
    }
    private void RestartPlacement(StoppedRestartObservation scope)
    {
        RequireRestartEntry(scope);
        CheckPlacement(_parent.Root, Root, _configuration, _roots, _registration.History, path =>
        { scope.Probe?.BeforeProtectedPathRead(path); RequireRestartEntry(scope); });
    }
    private void RequireRestartEntry(StoppedRestartObservation scope)
    {
        RequireRetainedEntryWithoutCallerLocks(scope.Source?.IsSourceGateEntered == true);
        if (!ReferenceEquals(_restartObservation, scope) || scope.Disposed)
            throw new InvalidOperationException("Restart scope is foreign or disposed.");
    }
    private EnrollmentRestartPosition RestartPosition(ApplicationAuthorityHistory history, HostJournalPosition administrative)
    {
        var last = history.Frames.LastOrDefault(); var entry = last?.Entry;
        var metadata = ApplicationAuthorityCodec.DecodeMetadata(ApplicationAuthorityCodec.EncodeMetadata(_configuration), _configuration);
        return new(_configuration.Deployment, _configuration.ResourceScope, _configuration.AdministrativeRootKey, _configuration.AuthorityRootKey,
            _configuration.AdministrativeJournalId, _configuration.AuthorityId, metadata.Digest, administrative.Sequence, administrative.Digest,
            last?.Sequence ?? 0, last?.Digest ?? new string('0', 64), entry?.OwnerSession ?? Guid.Empty, entry?.OwnerGeneration ?? 0,
            entry?.BaselineId ?? Guid.Empty, entry?.SelectionRevision ?? 0, entry?.Selected ?? PilotBranch.Source);
    }
    private static string HashRestart(byte[] bytes) => Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();

    internal sealed class StoppedRestartObservation : IDisposable
    {
        private readonly ApplicationAuthorityLifetime _owner;
        private readonly EmbeddedXmlDatabase? _sourceOwner;
        private readonly ApplicationRestartEvidence _evidence;
        private readonly IDisposable _operation;
        private readonly int _thread = Environment.CurrentManagedThreadId;
        private readonly Guid _id = Guid.NewGuid();
        private bool _attempted;
        private bool _disposeAttempted;
        internal EmbeddedXmlDatabase.RetainedRestartSource? Source { get; private set; }
        internal bool Disposed => _disposeAttempted;
        internal bool ReleaseUnknown { get; private set; }
        internal void InstallSource(EmbeddedXmlDatabase.RetainedRestartSource source)
        {
            _owner.RequireRestartEntry(this);
            if (_sourceOwner is null || !source.BelongsTo(_sourceOwner) || Source is not null || _attempted || _owner.History.Frames.Length != 1 || _owner.History.Source?.Kind != PilotRootKind.Legacy)
                throw new InvalidOperationException("Restart source binding is not available.");
            Source = source; // Retain even if caller closing wins immediately after actual source admission.
        }
        internal RestartParentIdentity? ParentIdentity { get; private set; }
        internal void InitializeParentIdentity()
        {
            _owner.RequireRestartEntry(this);
            if (ParentIdentity is not null || _attempted || _owner._restartObservationReady) throw new InvalidOperationException("Restart parent pin is immutable.");
            ParentIdentity = _owner._registration.InspectRestartParentIdentity(_owner._parent);
        }
        internal HostJournalPosition AdministrativePosition { get; }
        internal IRestartObservationProbe? Probe { get; }
        internal StoppedRestartObservation(ApplicationAuthorityLifetime owner, EmbeddedXmlDatabase? sourceOwner,
            ApplicationRestartEvidence evidence, IDisposable operation, HostJournalPosition position, IRestartObservationProbe? probe)
        { _owner = owner; _sourceOwner = sourceOwner; _evidence = evidence; _operation = operation; AdministrativePosition = position; Probe = probe; }
        internal void Stage(RestartObservationStage stage)
        { _owner.RequireRestartEntry(this); Probe?.AtStage(stage); _owner.RequireRestartEntry(this); }
        private void CheckThread()
        { if (_thread != Environment.CurrentManagedThreadId) throw new InvalidOperationException("Restart observation is caller-thread confined."); }

        internal ApplicationRestartDescription Observe()
        {
            CheckThread(); _owner.RequireRestartEntry(this);
            if (!_owner._restartObservationReady || _attempted || _disposeAttempted) throw new InvalidOperationException("Restart observation is not ready, disposed or consumed.");
            _attempted = true;
            try
            {
                _owner.RestartPlacement(this); var history = _owner.ReadRestartJournal(this);
                var expected = _owner.RestartPosition(_owner.History, AdministrativePosition);
                var shape = history.Frames.Length switch { 0 => EnrollmentRestartShape.Empty, 1 => EnrollmentRestartShape.SingleEnroll, _ => EnrollmentRestartShape.LaterHistory };
                EnrollmentRestartBaseline? enrolled = history.Source is { Kind: PilotRootKind.Legacy } root ?
                    new(root.RootKey, root.AdmissionKey, root.DocumentId, root.InitialSequence, root.InitialHistoryDigest, root.InitialHistoryDigest) : null;
                Stage(RestartObservationStage.BeforeBaseline);
                var proof = VerifyBaseline(history);
                Stage(RestartObservationStage.BaselineVerified);
                Stage(RestartObservationStage.BeforeFinalValidation);
                _owner.RestartPlacement(this);
                var finalProof = VerifyBaseline(history);
                if (proof != finalProof) throw new InvalidDataException("Restart source/capture correlation changed during observation.");
                history = _owner.ReadRestartJournal(this);
                lock (_owner._gate)
                {
                    ObjectDisposedException.ThrowIf(_owner._closing, _owner);
                    if (_owner._faulted || _owner._reads != 1 || !_owner._registration.TryValidateRestartCurrent(_owner._parent, AdministrativePosition, Source, _sourceOwner))
                        throw new InvalidOperationException("Restart ownership is closing, busy or no longer current.");
                }
                var pendingAdministration = _owner._registration.History.Frames.GroupBy(f => f.Snapshot.Context.Intent.AttemptId)
                    .Any(g => g.Last().Snapshot.Stage is not (HostLedgerStage.Acknowledged or HostLedgerStage.ReconciledAbsent));
                var priorWork = pendingAdministration && _evidence.PriorWorkReconciled == EnrollmentRestartFact.Confirmed ?
                    EnrollmentRestartFact.Unknown : _evidence.PriorWorkReconciled;
                var host = new EnrollmentRestartHost(_evidence.FreshScope, EnrollmentRestartFact.Confirmed,
                    Source is not null && proof.RootIdentity is not null ? EnrollmentRestartFact.Confirmed : EnrollmentRestartFact.Unknown, priorWork,
                    _evidence.ExecutorsDrained, _evidence.PublishersDrained, _evidence.ReleaseReconciled);
                var facts = new EnrollmentRestartObservations(expected, _owner.RestartPosition(history, AdministrativePosition), shape,
                    new(EnrollmentRestartFact.Confirmed, EnrollmentRestartFact.Confirmed, EnrollmentRestartFact.Confirmed,
                        EnrollmentRestartFact.Confirmed, EnrollmentRestartFact.Confirmed), enrolled, proof.Baseline, host);
                var assessment = EnrollmentRestartClassifier.Classify(facts);
                if (proof.Mismatch && assessment.Decision != EnrollmentRestartDecision.Refused) assessment = new(EnrollmentRestartDecision.ReconciliationRequired, EnrollmentRestartReason.BaselineMismatch);
                if (shape == EnrollmentRestartShape.SingleEnroll && history.Source?.Kind != PilotRootKind.Legacy && assessment.Decision != EnrollmentRestartDecision.Refused)
                    assessment = new(EnrollmentRestartDecision.ReconciliationRequired, EnrollmentRestartReason.UnsupportedHistory);
                return new(_id, pendingAdministration, facts, assessment);
            }
            catch { lock (_owner._gate) _owner._faulted = true; throw; }
        }

        private sealed record BaselineProof(EnrollmentRestartBaseline? Baseline, bool Mismatch, ApplicationFileIdentity? RootIdentity,
            ApplicationFileIdentity? AdmissionIdentity, ApplicationFileIdentity? CaptureIdentity, string? InventoryDigest);
        private BaselineProof VerifyBaseline(ApplicationAuthorityHistory history)
        {
            _owner.RequireRestartEntry(this);
            if (history.Frames.Length != 1 || history.Source is not { Kind: PilotRootKind.Legacy } root || Source is null || _evidence.CaptureRootKey is null)
                return new(null, false, null, null, null, null);
            var before = Source.InspectState(); var state = before.Source;
            if (Canonical(state.Root) != _owner._roots[root.RootKey]) throw new InvalidDataException("Actual source differs from its trusted root mapping.");
            var capture = _owner._roots[_evidence.CaptureRootKey];
            if (!Directory.Exists(capture))
            {
                if (File.Exists(capture)) throw new InvalidDataException("Configured capture is not a sealed directory.");
                return new(null, false, before.RootIdentity, before.AdmissionIdentity, null, null);
            }
            var captureIdentity = ApplicationAuthorityFileIdentity.PathIdentity(capture, true);
            var bytes = BinaryEnvelope.ReadFile(Path.Combine(capture, "inventory.bin")); var digest = HashRestart(bytes);
            var inventory = LegacyMigrationVerifier.ReadArtifact(capture);
            LegacyMigrationVerifier.ValidateHistory(Path.Combine(capture, "data"), inventory);
            var mismatch = digest != root.InitialHistoryDigest || state.DocumentId != root.DocumentId || state.Sequence != root.InitialSequence ||
                state.DocumentId != inventory.Identity.DocumentId || state.Sequence != inventory.Identity.CommitSequence || !state.ManifestHash.AsSpan().SequenceEqual(inventory.HeadHash);
            if (!mismatch)
            {
                MigrationCutoverValidation.ValidateSource(state.Root, inventory);
                if (Directory.EnumerateFileSystemEntries(Path.Combine(state.Root, ".transactions", "staging")).Any() ||
                    Directory.EnumerateFileSystemEntries(Path.Combine(state.Root, ".transactions")).Any(p => Path.GetFileName(p).EndsWith(".tmp", StringComparison.Ordinal)))
                    throw new InvalidDataException("Restart source contains unpublished state; no cleanup allowed.");
            }
            var after = Source.InspectState();
            if (before.RootIdentity != after.RootIdentity || before.AdmissionIdentity != after.AdmissionIdentity || before.Source.Sequence != after.Source.Sequence ||
                !state.ManifestHash.AsSpan().SequenceEqual(after.Source.ManifestHash) ||
                ApplicationAuthorityFileIdentity.PathIdentity(capture, true) != captureIdentity ||
                !BinaryEnvelope.ReadFile(Path.Combine(capture, "inventory.bin")).AsSpan().SequenceEqual(bytes))
                throw new InvalidDataException("Restart source/capture identity or bytes changed during proof.");
            _ = LegacyMigrationVerifier.ReadArtifact(capture); // Recheck exact sealed file closure after unlocked source proof.
            return new(mismatch ? null : new(root.RootKey, root.AdmissionKey, state.DocumentId, state.Sequence, digest, digest), mismatch,
                before.RootIdentity, before.AdmissionIdentity, captureIdentity, digest);
        }

        /// <summary>Drains source before paired operations once; unknown source release retains the pair.</summary>
        public void Dispose()
        {
            CheckThread();
            if (!ReferenceEquals(_owner._restartObservation, this)) throw new InvalidOperationException("Foreign restart scope cannot drain actual operations.");
            if (_disposeAttempted) return; _disposeAttempted = true;
            try
            {
                Source?.Dispose(); _operation.Dispose();
                if (_owner.WhenReleased.IsFaulted) throw new IOException("Restart authority release is unconfirmed.", _owner.WhenReleased.Exception);
                if (_owner._parent.WhenReleased.IsFaulted) throw new IOException("Restart parent release is unconfirmed.", _owner._parent.WhenReleased.Exception);
            }
            catch { ReleaseUnknown = true; _owner._unreleasedRestartObservation = this; throw; }
        }
    }
}
