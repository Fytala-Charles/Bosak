// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Prepares owner-bound first enrollment against a live frozen legacy baseline.
// SPECIAL NOTES        : Read-only internal preparation; supplied operational assertions do not prove host control.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Security.Cryptography;
using System.Text;

namespace Bosak.XmlDb.Storage;

internal sealed record ApplicationEnrollmentEvidence(EmbeddedHostContext Context, Guid AuthorityId, string SourceRootKey,
    string SourceAdmissionKey, string CaptureRootKey, Guid ReconciliationId, string ReconciledWorkDigest,
    bool Fresh, bool IngressClosed, bool PriorExecutorsExcluded, bool PublishersExcluded, bool PriorWorkReconciled, bool QueueFree);
internal sealed record ApplicationEnrollmentDescription(Guid AuthorityId, HostJournalPosition AdministrativePosition, ApplicationAuthorityEntry Entry)
{ internal bool WritersMustRemainStopped => true; }

internal sealed partial class ApplicationAuthorityLifetime
{
    private ApplicationEnrollmentPreparation? _enrollmentPreparation;
    internal sealed record BaselinePin(PilotRootBinding Source, string CaptureDigest, ApplicationFileIdentity RootIdentity, ApplicationFileIdentity AdmissionIdentity);

    internal ApplicationEnrollmentPreparation PrepareFirstEnrollment(MigrationSourceFreeze source, FrozenMigrationCapture capture, ApplicationEnrollmentEvidence evidence)
    {
        var operation = ReserveInitializer();
        try
        {
            RequireEnrollmentEvidence(evidence);
            var pin = InspectEnrollmentBaseline(source, capture, evidence);
            var position = _parent.JournalStatus.KnownPosition;
            var baselineId = Guid.NewGuid();
            var entry = new ApplicationAuthorityEntry(_parent.Context.SessionId, 1, baselineId, 1, PilotBranch.Source,
                EnrollmentEvidenceDigest(evidence, pin, position, baselineId), new ApplicationEnroll(pin.Source));
            var metadataBytes = ApplicationAuthorityCodec.EncodeMetadata(_configuration);
            var metadata = ApplicationAuthorityCodec.DecodeMetadata(metadataBytes, _configuration);
            _ = ApplicationAuthorityCodec.DecodeJournal(ApplicationAuthorityCodec.EncodeFrame(metadata, 1, new string('0', 64), entry), metadata);
            ValidateEmptyEnrollmentAuthority(); RequireEnrollmentOwner();
            var plan = new ApplicationEnrollmentPreparation(this, source, capture, evidence, pin,
                new(_configuration.AuthorityId, position, entry), operation);
            lock (_gate)
            {
                ObjectDisposedException.ThrowIf(_closing, this);
                if (_faulted) throw new InvalidOperationException("Authority session is faulted.");
                _enrollmentPreparation = plan;
            }
            return plan;
        }
        catch { lock (_gate) _faulted = true; operation.Dispose(); throw; }
    }

    internal ApplicationEnrollmentDescription CheckFirstEnrollment(ApplicationEnrollmentPreparation preparation, ApplicationEnrollmentEvidence freshEvidence)
    {
        ArgumentNullException.ThrowIfNull(preparation);
        preparation.CheckThread();
        lock (_gate)
        {
            if (!ReferenceEquals(_enrollmentPreparation, preparation) || !ReferenceEquals(preparation.Owner, this) || preparation.Disposed || preparation.Consumed)
                throw new InvalidOperationException("Preparation is foreign, disposed or consumed; descriptions are not capabilities.");
            preparation.Claim();
        }
        try
        {
            RequireEnrollmentOwner(); RequireEnrollmentEvidence(freshEvidence);
            if (freshEvidence != preparation.Evidence) throw new InvalidOperationException("Fresh reconciliation must bind the exact prepared baseline intent.");
            var pin = InspectEnrollmentBaseline(preparation.Source, preparation.Capture, freshEvidence);
            if (pin != preparation.Pin || _parent.JournalStatus.KnownPosition != preparation.Description.AdministrativePosition)
                throw new InvalidDataException("Prepared baseline identity/history or administrative position changed.");
            ValidateEmptyEnrollmentAuthority();
            RequireEnrollmentOwner();
            return preparation.Description;
        }
        catch { lock (_gate) _faulted = true; throw; }
    }
    private void ValidateEmptyEnrollmentAuthority()
    {
        lock (_readGate)
        {
            var read = ReadOwned(Root, _rootIdentity, _roles, _identities, _configuration, _roots, _parent.Root, _registration.History);
            if (read.Length != 0 || read.Digest != _digest) throw new InvalidDataException("First enrollment requires unchanged empty authority.");
        }
    }
    private void RequireEnrollmentOwner()
    {
        lock (_gate)
        {
            ObjectDisposedException.ThrowIf(_closing, this);
            if (_faulted) throw new InvalidOperationException("Authority session is faulted.");
        }
        _registration.RequireCurrent(_parent);
    }
    private void RequireEnrollmentEvidence(ApplicationEnrollmentEvidence evidence)
    {
        ArgumentNullException.ThrowIfNull(evidence);
        if (evidence.Context != _parent.Context || evidence.AuthorityId != _configuration.AuthorityId || evidence.ReconciliationId == Guid.Empty ||
            !evidence.Fresh || !evidence.IngressClosed || !evidence.PriorExecutorsExcluded || !evidence.PublishersExcluded || !evidence.PriorWorkReconciled || !evidence.QueueFree ||
            evidence.ReconciledWorkDigest is not { Length: 64 } || evidence.ReconciledWorkDigest.Any(c => c is not (>= '0' and <= '9') and not (>= 'a' and <= 'f')))
            throw new InvalidOperationException("Fresh exact-scope prior-work/executor/ingress reconciliation assertions are required.");
        if (string.IsNullOrWhiteSpace(evidence.SourceAdmissionKey) || Encoding.UTF8.GetByteCount(evidence.SourceAdmissionKey) > 4096 || evidence.SourceAdmissionKey.Contains('\0'))
            throw new InvalidDataException("Invalid source admission key.");
        foreach (var key in new[] { evidence.SourceRootKey, evidence.CaptureRootKey })
            if (key == _configuration.AdministrativeRootKey || key == _configuration.AuthorityRootKey || key is null || !_roots.ContainsKey(key))
                throw new InvalidDataException("Source and registered capture require distinct protected mappings.");
        if (evidence.SourceRootKey == evidence.CaptureRootKey) throw new InvalidDataException("Source and capture must have distinct keys.");
    }
    private BaselinePin InspectEnrollmentBaseline(MigrationSourceFreeze source, FrozenMigrationCapture capture, ApplicationEnrollmentEvidence evidence)
    {
        ArgumentNullException.ThrowIfNull(source); ArgumentNullException.ThrowIfNull(capture);
        source.Require(capture);
        return source.Inspect<BaselinePin>(state =>
        {
            if (Canonical(state.Root) != _roots[evidence.SourceRootKey] || Canonical(capture.Artifact) != _roots[evidence.CaptureRootKey])
                throw new InvalidDataException("Actual source/capture do not match the configured protected roots.");
            var rootIdentity = ApplicationAuthorityFileIdentity.PathIdentity(state.Root, true);
            var admissionIdentity = source.InspectAdmission();
            var bytes = capture.InventoryBytes;
            if (!BinaryEnvelope.ReadFile(Path.Combine(capture.Artifact, "inventory.bin")).AsSpan().SequenceEqual(bytes))
                throw new InvalidDataException("Registered capture inventory changed.");
            var inventory = LegacyMigrationVerifier.ReadArtifact(capture.Artifact);
            LegacyMigrationVerifier.ValidateHistory(Path.Combine(capture.Artifact, "data"), inventory);
            if (state.DocumentId != inventory.Identity.DocumentId || state.Sequence != inventory.Identity.CommitSequence || !state.ManifestHash.AsSpan().SequenceEqual(inventory.HeadHash))
                throw new InvalidDataException("Frozen live source differs from the captured baseline.");
            MigrationCutoverValidation.ValidateSource(state.Root, inventory);
            if (Directory.EnumerateFileSystemEntries(Path.Combine(state.Root, ".transactions", "staging")).Any() ||
                Directory.EnumerateFileSystemEntries(Path.Combine(state.Root, ".transactions")).Any(path => Path.GetFileName(path).EndsWith(".tmp", StringComparison.Ordinal)))
                throw new InvalidDataException("Enrollment rejects unpublished source staging/temporary state without cleanup.");
            if (ApplicationAuthorityFileIdentity.PathIdentity(state.Root, true) != rootIdentity || source.InspectAdmission() != admissionIdentity)
                throw new InvalidDataException("Source directory/admission identity changed during baseline inspection.");
            var digest = Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
            return new(new(PilotRootKind.Legacy, evidence.SourceRootKey, evidence.SourceAdmissionKey, state.DocumentId, null, state.Sequence, digest), digest, rootIdentity, admissionIdentity);
        });
    }
    private string EnrollmentEvidenceDigest(ApplicationEnrollmentEvidence evidence, BaselinePin pin, HostJournalPosition position, Guid baselineId)
    {
        using var bytes = new MemoryStream();
        using (var writer = new BinaryWriter(bytes, Encoding.UTF8, leaveOpen: true))
        {
            writer.Write("BXEP-BASELINE-1"); writer.Write(baselineId.ToString("D")); writer.Write(Root);
            writer.Write(_configuration.AdministrativeRootKey); writer.Write(_configuration.AuthorityRootKey); writer.Write(_configuration.AuthorityId.ToString("D")); writer.Write(evidence.Context.JournalId.ToString("D"));
            writer.Write(evidence.Context.SessionId.ToString("D")); writer.Write(evidence.Context.Deployment); writer.Write(evidence.Context.ResourceScope);
            writer.Write(evidence.ReconciliationId.ToString("D")); writer.Write(evidence.ReconciledWorkDigest); writer.Write(evidence.CaptureRootKey);
            writer.Write(ApplicationAuthorityCodec.RootDigest(pin.Source)); writer.Write(pin.CaptureDigest); writer.Write(position.Sequence); writer.Write(position.Digest); writer.Write(position.Length);
            foreach (var id in new[] { _rootIdentity, pin.RootIdentity, pin.AdmissionIdentity }.Concat(_identities)) { writer.Write(id.Volume); writer.Write(id.Low); writer.Write(id.High); }
        }
        return Convert.ToHexString(SHA256.HashData(bytes.ToArray())).ToLowerInvariant();
    }
    internal sealed class ApplicationEnrollmentPreparation : IDisposable
    {
        internal ApplicationAuthorityLifetime Owner { get; }
        internal MigrationSourceFreeze Source { get; }
        internal FrozenMigrationCapture Capture { get; }
        internal ApplicationEnrollmentEvidence Evidence { get; }
        private readonly int _thread = Environment.CurrentManagedThreadId;
        private readonly IDisposable _operation;
        internal BaselinePin Pin { get; }
        internal ApplicationEnrollmentDescription Description { get; }
        private bool _consumed;
        internal bool Consumed => _consumed;
        internal void Claim() { if (_consumed || Disposed) throw new InvalidOperationException("Preparation cannot be claimed again."); _consumed = true; }
        internal bool Disposed { get; private set; }
        internal ApplicationEnrollmentPreparation(ApplicationAuthorityLifetime owner, MigrationSourceFreeze source, FrozenMigrationCapture capture,
            ApplicationEnrollmentEvidence evidence, BaselinePin pin, ApplicationEnrollmentDescription description, IDisposable operation)
        { Owner = owner; Source = source; Capture = capture; Evidence = evidence; Pin = pin; Description = description; _operation = operation; }
        internal ApplicationEnrollmentDescription Describe() { CheckThread(); ObjectDisposedException.ThrowIf(Disposed, this); return Description; }
        internal void CheckThread() { if (_thread != Environment.CurrentManagedThreadId) throw new InvalidOperationException("Enrollment preparation and freeze are caller-thread confined."); }
        /// <summary>Releases the actual retained authority operation; does not release caller-owned source scopes.</summary>
        public void Dispose() { CheckThread(); if (Disposed) return; Disposed = true; _operation.Dispose(); }
    }
}
