// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Persists actual publication observations under stopped host ownership.
// SPECIAL NOTES        : Internal ProcessCrash append only; uncertain sessions remain faulted and all writers stopped.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal enum EmbeddedHostReconciliationDisposition { KnownPublication, QualifiedAbsent, EvidenceRequired, Contradiction }
internal sealed record EmbeddedHostAbsenceEvidence(EmbeddedHostContext Context, HostLedgerSnapshot Expected,
    bool Fresh, bool StableDestinationNamespace, bool NoRetainedPublicationEvidence);
internal sealed record EmbeddedHostReconciliationResult(EmbeddedHostReconciliationDisposition Disposition, HostLedgerSnapshot Snapshot,
    EpochPublicationObservation Observation, HostJournalAppendResult? Transfer, HostJournalAppendResult? Outcome)
{
    internal bool WritersMustRemainStopped => true;
}

internal static class EmbeddedHostRestartReconciler
{
    internal static EmbeddedHostReconciliationResult Reconcile(EmbeddedHostLifetime host, HostJournalPosition expectedPosition,
        HostLedgerSnapshot expected, EmbeddedHostInspectionEvidence exclusion, EmbeddedHostAbsenceEvidence? absence = null,
        Action<HostAppendStage>? checkpoint = null)
    {
        ArgumentNullException.ThrowIfNull(host); ArgumentNullException.ThrowIfNull(expected);
        using var session = host.BeginStoppedReconciliation(expectedPosition, exclusion);
        var history = host.ReadJournalForReconciliation();
        var activeId = history.Frames.LastOrDefault(frame => frame.Event == HostJournalEvent.RecordIntent && frame.Snapshot.Context.RequestId == expected.Context.RequestId)?.Snapshot.Context.Intent.AttemptId;
        var latest = history.Frames.LastOrDefault(frame => frame.Snapshot.Context.Intent.AttemptId == activeId)?.Snapshot;
        if (latest != expected) throw new InvalidOperationException("Reconcile only the exact latest request attempt.");
        HostJournalAppendResult? transfer = null; HostJournalAppendResult? outcome = null; var current = expected;
        if (current.Context.OwnerSession != host.Context.SessionId)
        {
            current = current with
            {
                Context = current.Context with
                {
                    Revision = checked(current.Context.Revision + 1),
                    OwnerGeneration = checked(current.Context.OwnerGeneration + 1),
                    OwnerSession = host.Context.SessionId
                },
                Stage = current.Stage is HostLedgerStage.Recorded or HostLedgerStage.DispatchAuthorized ? HostLedgerStage.Uncertain : current.Stage
            };
            transfer = Save(HostJournalEvent.TransferOwner, current);
        }
        var observation = EpochPublicationInspector.Inspect(current.Context.Intent.ToInspectionRequest());
        if (observation.Status == EpochInspectionStatus.KnownOperationMatched && observation.Observed is { } observed)
        {
            if (current.Stage == HostLedgerStage.ReconciledAbsent) return Result(EmbeddedHostReconciliationDisposition.Contradiction);
            if (current.Receipt is { } receipt && new EpochObservedPublication(receipt.Kind, receipt.OperationId, receipt.BackupId, receipt.SourceEpoch,
                receipt.DestinationEpoch, receipt.CommitSequence, receipt.StorePath) != observed || current.Observed is { } saved && saved != observed)
                return Result(EmbeddedHostReconciliationDisposition.Contradiction);
            if (current.Stage is HostLedgerStage.Acknowledged or HostLedgerStage.ObservedKnown) return Result(EmbeddedHostReconciliationDisposition.KnownPublication);
            // A same-owner Recorded intent cannot lawfully gain a publication observation.
            if (current.Stage is not (HostLedgerStage.DispatchAuthorized or HostLedgerStage.Uncertain)) return Result(EmbeddedHostReconciliationDisposition.Contradiction);
            current = current with { Context = current.Context with { Revision = checked(current.Context.Revision + 1) }, Stage = HostLedgerStage.ObservedKnown, Observed = observed };
            outcome = Save(HostJournalEvent.ObserveKnown, current); return Result(EmbeddedHostReconciliationDisposition.KnownPublication);
        }
        if (observation.Status != EpochInspectionStatus.NotObserved) return Result(EmbeddedHostReconciliationDisposition.EvidenceRequired);
        if (current.Receipt is not null || current.Observed is not null) return Result(EmbeddedHostReconciliationDisposition.Contradiction);
        if (absence is null || absence.Context != host.Context || absence.Expected != expected || !absence.Fresh ||
            !absence.StableDestinationNamespace || !absence.NoRetainedPublicationEvidence) return Result(EmbeddedHostReconciliationDisposition.EvidenceRequired);
        // Trusted namespace/exclusion facts must remain true throughout this synchronous session.
        observation = EpochPublicationInspector.Inspect(current.Context.Intent.ToInspectionRequest());
        if (observation.Status != EpochInspectionStatus.NotObserved) return Result(EmbeddedHostReconciliationDisposition.EvidenceRequired);
        if (current.Stage == HostLedgerStage.ReconciledAbsent) return Result(EmbeddedHostReconciliationDisposition.QualifiedAbsent);
        current = current with { Context = current.Context with { Revision = checked(current.Context.Revision + 1) }, Stage = HostLedgerStage.ReconciledAbsent };
        outcome = Save(HostJournalEvent.ReconcileAbsent, current); return Result(EmbeddedHostReconciliationDisposition.QualifiedAbsent);

        HostJournalAppendResult Save(HostJournalEvent kind, HostLedgerSnapshot snapshot)
        {
            var result = host.AppendStopped(session, host.JournalStatus.KnownPosition, kind, snapshot, checkpoint);
            if (result.Disposition != HostJournalAppendDisposition.Acknowledged || result.Frame?.Snapshot != snapshot)
                throw new InvalidOperationException("Stopped reconciliation save was not acknowledged exactly.");
            return result;
        }
        EmbeddedHostReconciliationResult Result(EmbeddedHostReconciliationDisposition disposition) => new(disposition, current, observation, transfer, outcome);
    }
}
