// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Encodes sealed full-history backup inventories and completion identities.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

/// <summary>Identifies a verified fixed-sequence full-history backup or restore.</summary>
/// <param name="BackupId">Immutable backup identity.</param>
/// <param name="DocumentId">Persistent document identity.</param>
/// <param name="CommitSequence">Exact captured sequence.</param>
public readonly record struct BackupResult(Guid BackupId, ulong DocumentId, ulong CommitSequence);

internal sealed record BackupEntry(string Path, int Length, byte[] Hash);
internal sealed record BackupInventory(BackupResult Identity, byte[] BaseHash, byte[] HeadHash, BackupEntry[] Files);

internal static class BackupCodec
{
    internal const int MaximumEntries = 100_000;
    internal static byte[] Encode(BackupInventory value) => BinaryEnvelope.Encode("BXBI", writer =>
    {
        writer.Write(value.Identity.BackupId.ToByteArray());
        writer.Write(value.Identity.DocumentId);
        writer.Write(value.Identity.CommitSequence);
        writer.Write(value.BaseHash);
        writer.Write(value.HeadHash);
        writer.Write(value.Files.Length);
        foreach (var entry in value.Files)
        {
            BinaryEnvelope.WriteString(writer, entry.Path);
            writer.Write(entry.Length);
            writer.Write(entry.Hash);
        }
    });

    internal static BackupInventory Decode(byte[] bytes) => BinaryEnvelope.Decode(bytes, "BXBI", reader =>
    {
        var identity = new BackupResult(new Guid(reader.ReadBytes(16)), reader.ReadUInt64(), reader.ReadUInt64());
        if (identity.BackupId == Guid.Empty || identity.DocumentId == 0 || identity.CommitSequence > 10_000)
            throw new InvalidDataException("Invalid backup identity.");
        var baseHash = reader.ReadBytes(32);
        var headHash = reader.ReadBytes(32);
        var entries = new BackupEntry[BinaryEnvelope.ReadCount(reader, MaximumEntries)];
        if (entries.Length == 0) throw new InvalidDataException("Empty backup inventory.");
        var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        string? previous = null;
        for (var index = 0; index < entries.Length; index++)
        {
            var path = BinaryEnvelope.ReadString(reader);
            var length = reader.ReadInt32();
            var hash = reader.ReadBytes(32);
            ValidatePath(path);
            if (!names.Add(path) || previous is not null && StringComparer.Ordinal.Compare(previous, path) >= 0 ||
                length < 44 || length > BinaryEnvelope.MaximumFileBytes || hash.Length != 32)
                throw new InvalidDataException("Invalid or duplicate backup entry.");
            entries[index] = new(path, length, hash);
            previous = path;
        }
        return new BackupInventory(identity, baseHash, headHash, entries);
    });

    internal static byte[] Complete(byte[] inventory) => BinaryEnvelope.Encode("BXBC", writer => writer.Write(SHA256.HashData(inventory)));

    internal static void ValidateCompletion(byte[] complete, byte[] inventory) => BinaryEnvelope.Decode(complete, "BXBC", reader =>
    {
        if (!reader.ReadBytes(32).AsSpan().SequenceEqual(SHA256.HashData(inventory)))
            throw new InvalidDataException("Backup completion does not bind the inventory.");
        return true;
    });

    private static void ValidatePath(string path)
    {
        if (path.Length is 0 or > 512 || path.Split('/').Any(part => part is "" or "." or "..") ||
            path.Any(c => !char.IsAsciiLetterOrDigit(c) && c is not '/' and not '.' and not '-'))
            throw new InvalidDataException("Noncanonical backup path.");
    }
}
