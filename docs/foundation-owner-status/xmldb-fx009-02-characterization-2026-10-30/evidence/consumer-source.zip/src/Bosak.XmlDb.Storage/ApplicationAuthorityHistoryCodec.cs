// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Validates complete bounded application-authority histories without replaying work.
// SPECIAL NOTES        : Pure internal codec; checksums and decoded state grant no ownership, freshness or write authority.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Buffers.Binary;
using System.Collections.Immutable;

namespace Bosak.XmlDb.Storage;

/// <summary>Validates complete bounded application-authority histories without replaying work.</summary>
internal static partial class ApplicationAuthorityCodec
{
    internal static ApplicationAuthorityHistory DecodeJournal(byte[] bytes, ApplicationAuthorityMetadata metadata)
    {
        Require(bytes is not null && bytes.Length <= MaximumJournalBytes);
        using var input = new MemoryStream(bytes, writable: false); return ReadJournal(input, metadata);
    }

    // Only consumes the caller-owned stream; never seeks, closes, opens files or writes.
    // No prefix or state escapes when a later frame or tail is invalid.
    internal static ApplicationAuthorityHistory ReadJournal(Stream input, ApplicationAuthorityMetadata metadata)
    {
        Require(input is not null && input.CanRead); ValidateMetadata(metadata);
        var frames = ImmutableArray.CreateBuilder<ApplicationAuthorityFrame>(); var state = new ReplayState();
        var header = new byte[104]; long total = 0; var previous = ZeroHash;
        try
        {
            while (input.Read(header, 0, 1) != 0)
            {
                Require(frames.Count < MaximumFrames && total <= MaximumJournalBytes - 104);
                input.ReadExactly(header.AsSpan(1)); ValidateHeader(header, metadata);
                Require(BinaryPrimitives.ReadUInt64LittleEndian(header.AsSpan(16)) == (ulong)frames.Count + 1 && Hex(header.AsSpan(40, 32)) == previous);
                var n = BinaryPrimitives.ReadUInt32LittleEndian(header.AsSpan(12));
                Require(n is > 0 and <= MaximumPayloadBytes && total + 144L + n <= MaximumJournalBytes);
                var bytes = new byte[144 + (int)n]; header.CopyTo(bytes, 0); input.ReadExactly(bytes.AsSpan(104));
                var frame = DecodeFrame(bytes, metadata); state.Apply(frame); frames.Add(frame); previous = frame.Digest; total += bytes.Length;
            }
        }
        catch (EndOfStreamException error) { throw new InvalidDataException("Incomplete application authority history; retain every byte and reconcile.", error); }
        return new(frames.ToImmutable(), state.Source, state.Candidate, state.Publication,
            state.Work.Values.OrderBy(w => w.Reference.AcceptanceSequence).ToImmutableArray());
    }

    private sealed class ReplayState
    {
        internal PilotRootBinding? Source { get; private set; }
        internal PilotRootBinding? Candidate { get; private set; }
        internal ApplicationAuthorityPublication? Publication { get; private set; }
        internal Dictionary<Guid, ApplicationAuthorityWork> Work { get; } = [];
        private ApplicationAuthorityEntry? _last;

        internal void Apply(ApplicationAuthorityFrame frame)
        {
            var e = frame.Entry;
            if (_last is null)
            {
                Require(frame.Sequence == 1 && e.Data is ApplicationEnroll && e.OwnerGeneration == 1 && e.SelectionRevision == 1 && e.Selected == PilotBranch.Source);
                Source = ((ApplicationEnroll)e.Data).Source; _last = e; return;
            }
            var old = _last;
            Require(e.BaselineId == old.BaselineId);
            if (e.Data is ApplicationTransfer transfer)
            {
                Require(transfer.PreviousOwner == old.OwnerSession && transfer.PreviousGeneration == old.OwnerGeneration &&
                    e.OwnerSession != old.OwnerSession && old.OwnerGeneration < ulong.MaxValue && e.OwnerGeneration == old.OwnerGeneration + 1);
            }
            else Require(e.OwnerSession == old.OwnerSession && e.OwnerGeneration == old.OwnerGeneration);
            if (e.Data is not ApplicationSelect) Require(e.SelectionRevision == old.SelectionRevision && e.Selected == old.Selected);

            switch (e.Data)
            {
                case ApplicationEnroll: throw new InvalidDataException("Enrollment cannot replace retained history.");
                case ApplicationRegister register:
                    Require(Candidate is null && Work.Count == 0 && Source is not null);
                    var target = register.Candidate;
                    Require(target.Kind == PilotRootKind.ScalarEpoch && target.DocumentId == Source.DocumentId && target.InitialSequence == Source.InitialSequence &&
                        !string.Equals(target.RootKey, Source.RootKey, StringComparison.OrdinalIgnoreCase) &&
                        !string.Equals(target.AdmissionKey, Source.AdmissionKey, StringComparison.OrdinalIgnoreCase) &&
                        (Source.Epoch is null || Source.Epoch.StoreId != target.Epoch!.StoreId && Source.Epoch.EpochId != target.Epoch.EpochId));
                    Require(register.Publication.Kind == (Source.Kind == PilotRootKind.Legacy ? EpochPublicationKind.LegacyMigration : EpochPublicationKind.IndependentEpochRestore));
                    Candidate = target; Publication = register.Publication; break;
                case ApplicationSelect select:
                    Require(Candidate is not null && Work.Count == 0 && select.PreviousRevision == old.SelectionRevision && select.PreviousBranch == old.Selected &&
                        old.SelectionRevision < ulong.MaxValue && e.SelectionRevision == old.SelectionRevision + 1 && e.Selected != old.Selected); break;
                case ApplicationAccept accept:
                    Require(Candidate is not null && Source is not null && Work.Count < MaximumWork && !Work.ContainsKey(accept.WorkId) && Work.Values.All(w => w.Outcome != PilotWorkOutcome.Unknown));
                    var root = e.Selected == PilotBranch.Source ? Source : Candidate;
                    Require(accept.RootDigest == RootDigest(root));
                    var reference = new ApplicationWorkReference(accept.WorkId, accept.IntentDigest, frame.Sequence);
                    Work.Add(accept.WorkId, new(reference, e.Selected, root, e.SelectionRevision, e.OwnerSession, e.OwnerGeneration, PilotWorkOutcome.Unknown, false, false)); break;
                case ApplicationOutcome outcome:
                    var pending = Find(outcome.Work);
                    Require(pending.AcceptingOwner == e.OwnerSession && pending.AcceptingGeneration == e.OwnerGeneration && !pending.OutcomeRecorded &&
                        !pending.RequiresObservation && pending.Outcome == PilotWorkOutcome.Unknown);
                    Work[outcome.Work.WorkId] = pending with { Outcome = outcome.Outcome, OutcomeRecorded = true, RequiresObservation = outcome.Outcome == PilotWorkOutcome.Unknown }; break;
                case ApplicationObserve observation:
                    Require(observation.ObservedRevision == e.SelectionRevision && observation.ObservedBranch == e.Selected);
                    if (observation.Kind == ApplicationObservationKind.Selection) break;
                    Require(observation.Work is not null); var retained = Find(observation.Work);
                    var observed = observation.Kind switch
                    {
                        ApplicationObservationKind.WorkCommitted => PilotWorkOutcome.Committed,
                        ApplicationObservationKind.WorkNoEffect => PilotWorkOutcome.NoEffect,
                        _ => PilotWorkOutcome.Unknown
                    };
                    Require(retained.Outcome == PilotWorkOutcome.Unknown || observed == retained.Outcome);
                    Work[observation.Work.WorkId] = retained with { Outcome = observed, RequiresObservation = true }; break;
                case ApplicationTransfer: break;
                default: throw new InvalidDataException("Unknown application authority transition.");
            }
            _last = e;
        }

        private ApplicationAuthorityWork Find(ApplicationWorkReference reference)
        {
            Require(Work.TryGetValue(reference.WorkId, out var work) && work.Reference == reference); return work;
        }
    }
}
