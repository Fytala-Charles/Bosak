// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Conditionally appends bounded journal frames under retained host ownership.
// SPECIAL NOTES        : Internal ProcessCrash append only; uncertain sessions remain faulted and all writers stopped.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 28-10-2026     | Require opaque executor registration for active-attempt writes
//                      | Charles Korthout | 0.3   | 29-10-2026     | Share exact append checks with restricted stopped sessions
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal sealed record HostJournalPosition(Guid JournalId, ulong Sequence, string Digest, long Length);
internal sealed record HostJournalWriterStatus(HostJournalPosition KnownPosition, bool CanAttemptAppend, bool Faulted);
internal enum HostJournalAppendDisposition { Acknowledged, Conflict }
internal sealed record HostJournalAppendResult(HostJournalAppendDisposition Disposition, HostJournalPosition Position, HostJournalFrame? Frame)
{
    internal bool WritersMustRemainStopped => true;
}
internal enum HostAppendStage { Validated, BeforeWrite, Written, Flushed, BeforeAcknowledge }
internal interface IHostJournalAppendIo
{
    void Write(FileStream stream, ReadOnlySpan<byte> bytes);
    void Flush(FileStream stream);
}

internal sealed partial class EmbeddedHostLifetime
{
    private readonly object _appendGate = new();
    private readonly long _acquiredJournalLength;
    private HostJournalPosition? _journalPosition;
    private bool _journalAppendEnabled;
    private bool _journalFaulted;
    private bool _appendInProgress;

    internal HostJournalWriterStatus JournalStatus
    {
        get { lock (_appendGate) { lock (_gate) return new(KnownPosition(), _journalAppendEnabled && _admissions && !_closing && !_journalFaulted, _journalFaulted); } }
    }
    private HostJournalPosition KnownPosition() => _journalPosition ??= Position(History, _acquiredJournalLength);
    private HostJournalPosition Position(HostJournalReadResult history, long length) => new(Context.JournalId, (ulong)history.Frames.Count,
        history.Frames.Count == 0 ? new string('0', 64) : history.Frames[^1].Digest, length);

    // Explicit enablement uses trusted supplied host facts. Acquired bytes alone never enable writes.
    internal bool EnableJournalAppend(HostJournalPosition expected, EmbeddedHostAdmissionEvidence evidence)
    {
        ArgumentNullException.ThrowIfNull(expected); RequireAdmissionEvidence(evidence);
        using var operation = RegisterOperation(requireAdmission: true);
        lock (_appendGate)
        {
            EnsureJournalSession(); if (expected != KnownPosition()) return false;
            var history = ReadAndVerifyKnown();
            if (!WasProvisionedHere && history.Frames.Count == 0) throw new InvalidOperationException("Reopened empty roots have no initializer first-write authority.");
            _journalAppendEnabled = true; return true;
        }
    }

    internal HostJournalReadResult ReadJournalForReconciliation()
    {
        using var operation = RegisterOperation(requireAdmission: false);
        lock (_appendGate)
        {
            if (_appendInProgress) throw new InvalidOperationException("Reentrant journal observation is not supported.");
            try { return ReadOwnedJournal(); }
            catch { FaultJournalSession(); throw; }
        }
    }
    internal HostJournalAppendResult AppendJournal(HostJournalPosition expected, HostJournalEvent kind, HostLedgerSnapshot snapshot, Action<HostAppendStage>? checkpoint = null) =>
        AppendJournalCore(expected, kind, snapshot, new LocalAppendIo(), checkpoint);

    internal HostJournalAppendResult AppendForExecutor(IDisposable registration, HostJournalPosition expected, HostJournalEvent kind,
        HostLedgerSnapshot snapshot, Action<HostAppendStage>? checkpoint = null) => AppendJournalCore(expected, kind, snapshot, new LocalAppendIo(), checkpoint, registration);

    internal HostJournalAppendResult AppendJournalCore(HostJournalPosition expected, HostJournalEvent kind, HostLedgerSnapshot snapshot,
        IHostJournalAppendIo io, Action<HostAppendStage>? checkpoint = null, IDisposable? registration = null, IDisposable? stoppedRegistration = null)
    {
        ArgumentNullException.ThrowIfNull(expected); ArgumentNullException.ThrowIfNull(snapshot); ArgumentNullException.ThrowIfNull(io);
        using var operation = stoppedRegistration is null ? RegisterOperation(requireAdmission: true) : RegisterStoppedAppend(stoppedRegistration);
        lock (_appendGate)
        {
            EnsureJournalSession();
            if (stoppedRegistration is not null)
            {
                RequireStoppedRegistration(stoppedRegistration);
                if (kind is not (HostJournalEvent.TransferOwner or HostJournalEvent.ObserveKnown or HostJournalEvent.ReconcileAbsent))
                    throw new InvalidOperationException("Stopped session cannot authorize or execute attempts.");
            }
            if (stoppedRegistration is null && !_journalAppendEnabled) throw new InvalidOperationException("Journal append requires explicit reconciled session enablement.");
            var known = KnownPosition();
            if (expected != known) return new(HostJournalAppendDisposition.Conflict, known, null);
            _appendInProgress = true; var writeEntered = false;
            try
            {
                if (snapshot.Context is not { } c || c.OwnerSession != Context.SessionId || c.Deployment != Context.Deployment || c.ResourceScope != Context.ResourceScope)
                    throw new InvalidDataException("Append snapshot does not bind the current live owner.");
                var bytes = HostJournalCodec.EncodeFrame(Context.JournalId, known.Sequence + 1, known.Digest, kind, snapshot);
                RequireExecutorAppend(c.Intent.AttemptId, registration);
                CheckProtected(Root, c.Intent.ArtifactRoot); CheckProtected(Root, c.Intent.BundleRoot);
                if (known.Length > HostJournalCodec.MaximumJournalBytes - bytes.Length) throw new InvalidDataException("Journal byte limit reached.");
                var history = ReadAndVerifyKnown(); var frame = HostJournalCodec.DecodeFrame(bytes); HostJournalCodec.ValidateExtension(history, frame);
                checkpoint?.Invoke(HostAppendStage.Validated);
                _ = ReadAndVerifyKnown(); // Recheck ownership/EOF after the test seam before entering write uncertainty.
                _journal.Position = known.Length; writeEntered = true; checkpoint?.Invoke(HostAppendStage.BeforeWrite);
                io.Write(_journal, bytes); checkpoint?.Invoke(HostAppendStage.Written);
                io.Flush(_journal); checkpoint?.Invoke(HostAppendStage.Flushed);
                if (_journal.Length != known.Length + bytes.Length) throw new InvalidDataException("Append did not write exactly one frame.");
                var actual = new byte[bytes.Length]; _journal.Position = known.Length; _journal.ReadExactly(actual);
                if (!actual.AsSpan().SequenceEqual(bytes)) throw new InvalidDataException("Flushed frame readback mismatch.");
                checkpoint?.Invoke(HostAppendStage.BeforeAcknowledge);
                var next = new HostJournalPosition(Context.JournalId, frame.Sequence, frame.Digest, known.Length + bytes.Length);
                if (Position(ReadOwnedJournal(), _journal.Position) != next) throw new InvalidDataException("Post-flush complete history differs from the requested append.");
                _journalPosition = next; return new(HostJournalAppendDisposition.Acknowledged, next, frame);
            }
            catch { if (writeEntered) FaultJournalSession(); throw; }
            finally { _appendInProgress = false; }
        }
    }
    private void EnsureJournalSession()
    {
        if (_journalFaulted) throw new InvalidOperationException("Journal append session is faulted; it cannot be rearmed.");
        if (_appendInProgress) throw new InvalidOperationException("Reentrant journal append/enablement is not supported.");
    }
    private HostJournalReadResult ReadAndVerifyKnown()
    {
        try
        {
            var history = ReadOwnedJournal();
            if (Position(history, _journal.Position) != KnownPosition()) throw new InvalidDataException("Journal changed outside the acknowledged session history.");
            return history;
        }
        catch { FaultJournalSession(); throw; }
    }
    private HostJournalReadResult ReadOwnedJournal()
    {
        CheckNamespace(Root);
        if (_owner.Length != 0 || _metadata.Length != 88 || _journal.Length > HostJournalCodec.MaximumJournalBytes)
            throw new InvalidDataException("Owned host role size changed.");
        var metadata = new byte[88]; _metadata.Position = 0; _metadata.ReadExactly(metadata);
        var identity = HostJournalCodec.DecodeMetadata(metadata, Context.Deployment, Context.ResourceScope);
        if (identity.JournalId != Context.JournalId) throw new InvalidDataException("Owned host identity changed.");
        _journal.Position = 0;
        return HostJournalCodec.ReadJournal(_journal, identity, Context.Deployment, Context.ResourceScope);
    }
    private void FaultJournalSession()
    {
        Volatile.Write(ref _journalFaulted, true); _journalAppendEnabled = false; CloseAdmissions();
    }
    private sealed class LocalAppendIo : IHostJournalAppendIo
    {
        /// <inheritdoc/>
        public void Write(FileStream stream, ReadOnlySpan<byte> bytes) => stream.Write(bytes);
        /// <inheritdoc/>
        public void Flush(FileStream stream) => stream.Flush(flushToDisk: true);
    }
}
