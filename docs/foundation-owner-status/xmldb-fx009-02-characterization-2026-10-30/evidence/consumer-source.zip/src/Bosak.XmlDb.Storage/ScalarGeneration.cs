// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Builds a new immutable generation for one scalar replacement.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      | Charles Korthout | 0.2   | 26-10-2026     | Use injectable writes and directory entry barriers
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.3   | 27-10-2026     | Support scalar epoch materializations and verified history selection
// ===========================================================================================================================================================

using System.Security.Cryptography;
using System.Xml;
using Bosak.XmlDb.Core;

namespace Bosak.XmlDb.Storage;

internal static class ScalarGeneration
{
    internal static void ValidateReplacement(ImmutableXmlSnapshot snapshot, ulong nodeId, string value)
    {
        ArgumentNullException.ThrowIfNull(value);
        var node = snapshot.GetNode(nodeId);
        if (node.Kind is not (StorageNodeKind.Text or StorageNodeKind.Attribute) ||
            node.NamespaceUri == "http://www.w3.org/XML/1998/namespace")
            throw new NotSupportedException("Only text and ordinary attribute values can be replaced in this M2 slice.");
        if (node.Kind == StorageNodeKind.Text && value.Length == 0)
            throw new NotSupportedException("Empty text replacement requires structural node removal, which is not supported in this slice.");
        XmlConvert.VerifyXmlChars(value);
        if (BinaryEnvelope.Utf8.GetByteCount(value) > BinaryEnvelope.MaximumStringBytes)
            throw new InvalidDataException("Replacement value exceeds the format limit.");
    }

    internal static byte[] Build(string sourceRoot, string stagingRoot, ulong documentId,
        ulong nodeId, string value, Action<CommitStage>? checkpoint, ITransactionStorage storage)
    {
        using var snapshot = ImmutableXmlSnapshot.OpenVersion(sourceRoot, documentId, 0);
        var hash = BuildEpochMaterialization(sourceRoot, stagingRoot, snapshot, nodeId, value, checkpoint, storage);
        Validate(stagingRoot, documentId, hash);
        return hash;
    }

    // Materialization encoding is shared; admission/profile/role validation is the epoch caller's responsibility.
    internal static byte[] BuildEpochMaterialization(string sourceRoot, string stagingRoot, ImmutableXmlSnapshot snapshot,
        ulong nodeId, string value, Action<CommitStage>? checkpoint, ITransactionStorage storage)
    {
        var documentId = snapshot.DocumentId;
        ValidateReplacement(snapshot, nodeId, value);
        var originalManifest = StoreCodec.ReadManifest(TransactionCodec.ReadManifestBytes(sourceRoot, documentId));
        var nodes = Enumerable.Range(1, snapshot.NodeCount).Select(id => snapshot.GetNode((ulong)id)).ToArray();
        var fragmentId = snapshot.GetNode(nodeId).FragmentId;
        using var payload = new MemoryStream();
        foreach (var node in nodes.Where(node => node.FragmentId == fragmentId))
        {
            var bytes = BinaryEnvelope.Utf8.GetBytes(node.Id == nodeId ? value : snapshot.ReadValue(node.Id));
            if (payload.Length + bytes.Length > BinaryEnvelope.MaximumFileBytes - 65)
                throw new InvalidDataException("Updated fragment exceeds the format limit.");
            nodes[(int)node.Id - 1] = node with { ValueOffset = (int)payload.Length, ValueLength = bytes.Length };
            payload.Write(bytes);
        }
        var replacement = BinaryEnvelope.Encode("BXFG", writer =>
        {
            writer.Write(fragmentId);
            writer.Write(documentId);
            writer.Write((byte)0);
            writer.Write(checked((int)payload.Length));
            writer.Write(payload.GetBuffer(), 0, (int)payload.Length);
        });
        var directory = StoreCodec.WriteDirectory(nodes);
        var fragments = originalManifest.Fragments.Select(entry => entry.Id == fragmentId
            ? new FragmentEntry(entry.Id, (int)payload.Length, SHA256.HashData(replacement)) : entry).ToArray();
        var manifest = StoreCodec.WriteManifest(originalManifest with
        {
            DirectoryHash = SHA256.HashData(directory),
            Fragments = fragments,
        });

        if (Directory.Exists(stagingRoot) || File.Exists(stagingRoot)) throw new IOException("Generation destination already exists.");
        TransactionCodec.EnsureDirectory(stagingRoot, storage);
        BinaryEnvelope.RejectLinks(stagingRoot);
        checkpoint?.Invoke(CommitStage.StageCreated);
        var documentPath = TransactionCodec.DocumentPath(stagingRoot, documentId);
        TransactionCodec.EnsureDirectory(documentPath, storage);
        var fragmentPath = Path.Combine(stagingRoot, "fragments");
        TransactionCodec.EnsureDirectory(fragmentPath, storage);
        TransactionCodec.WriteFlushed(Path.Combine(stagingRoot, "FORMAT"), BinaryEnvelope.ReadFile(Path.Combine(sourceRoot, "FORMAT")), storage);
        foreach (var entry in originalManifest.Fragments)
        {
            var name = entry.Id.ToString(System.Globalization.CultureInfo.InvariantCulture) + ".bin";
            var bytes = entry.Id == fragmentId ? replacement : BinaryEnvelope.ReadFile(Path.Combine(sourceRoot, "fragments", name));
            if (entry.Id != fragmentId && !SHA256.HashData(bytes).AsSpan().SequenceEqual(entry.Hash))
                throw new InvalidDataException("Source fragment does not match its manifest.");
            TransactionCodec.WriteFlushed(Path.Combine(fragmentPath, name), bytes, storage);
        }
        checkpoint?.Invoke(CommitStage.FragmentsFlushed);
        TransactionCodec.WriteFlushed(Path.Combine(documentPath, "directory.bin"), directory, storage);
        checkpoint?.Invoke(CommitStage.DirectoryFlushed);
        TransactionCodec.WriteFlushed(Path.Combine(documentPath, "manifest.bin"), manifest, storage);
        checkpoint?.Invoke(CommitStage.ManifestFlushed);
        return SHA256.HashData(manifest);
    }

    internal static void Validate(string root, ulong documentId, byte[] expectedHash)
    {
        if (!TransactionCodec.ManifestHash(root, documentId).AsSpan().SequenceEqual(expectedHash))
            throw new InvalidDataException("Generation manifest identity mismatch.");
        using var snapshot = ImmutableXmlSnapshot.OpenVersion(root, documentId, 0);
        var manifest = StoreCodec.ReadManifest(TransactionCodec.ReadManifestBytes(root, documentId));
        foreach (var entry in manifest.Fragments)
        {
            var path = Path.Combine(root, "fragments", entry.Id.ToString(System.Globalization.CultureInfo.InvariantCulture) + ".bin");
            var bytes = BinaryEnvelope.ReadFile(path);
            if (!SHA256.HashData(bytes).AsSpan().SequenceEqual(entry.Hash))
                throw new InvalidDataException("Generation contains a corrupt fragment.");
        }
    }
}


