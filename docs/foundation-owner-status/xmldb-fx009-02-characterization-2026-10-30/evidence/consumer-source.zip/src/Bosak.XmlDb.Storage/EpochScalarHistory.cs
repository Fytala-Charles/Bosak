// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Validates complete epoch scalar histories without replaying or deleting incomplete state.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

internal sealed record EpochVerifiedHead(ulong Sequence, byte[] ManifestHash, byte[] WalHash);

internal static class EpochScalarHistory
{
    internal static bool IsCurrentTemporary(string name) => name.Length == 44 && name.StartsWith("current-", StringComparison.Ordinal) &&
        name.EndsWith(".tmp", StringComparison.Ordinal) && Guid.TryParseExact(name.AsSpan(8, 32), "N", out _);
    internal static string Generation(string root, ulong sequence) => sequence == 0 ? root :
        Path.Combine(root, ".transactions", "generations", EpochAuthorityCodec.GenerationName(sequence));

    internal static EpochVerifiedHead Validate(string root, EpochAdmissionLease admission, EpochAuthorityBinding binding)
    {
        var walPaths = Directory.GetFileSystemEntries(Path.Combine(root, ".transactions", "wal"));
        if (walPaths.Length > 10_000) throw new InvalidDataException("Epoch journal limit exceeded.");
        Array.Sort(walPaths, StringComparer.Ordinal);
        var hashes = new Dictionary<ulong, EpochVerifiedHead> { [0] = new(0, binding.BaseHash, new byte[32]) };
        var ids = new HashSet<Guid>();
        EpochVerifiedHead head = hashes[0];
        using var baseSnapshot = Open(root, 0, admission, binding.BaseHash);
        ValidateFiles(root, binding.Identity.DocumentId, binding.BaseHash);
        for (var index = 0; index < walPaths.Length; index++)
        {
            var sequence = (ulong)index + 1;
            var path = walPaths[index]; BinaryEnvelope.RejectLinks(path);
            if (Directory.Exists(path) || EpochAuthorityCodec.ParseWalName(Path.GetFileName(path)) != sequence)
                throw new InvalidDataException("Missing or noncanonical epoch WAL.");
            var bytes = BinaryEnvelope.ReadFile(path); // Strictly reject all partial/corrupt records; no tail cleanup in ET5.
            var record = EpochAuthorityCodec.DecodeWal(bytes, binding);
            if (record.Sequence != sequence || !ids.Add(record.TransactionId) || !record.PreviousManifestHash.AsSpan().SequenceEqual(head.ManifestHash) ||
                !record.PreviousWalHash.AsSpan().SequenceEqual(head.WalHash)) throw new InvalidDataException("Broken epoch WAL chain.");
            var data = Generation(root, sequence);
            if (!Directory.Exists(data)) throw new NotSupportedException("Epoch redo for missing generations is not implemented.");
            var digest = SHA256.HashData(bytes);
            var descriptor = EpochAuthorityCodec.DecodeGeneration(BinaryEnvelope.ReadFile(Path.Combine(data, "GENERATION")), binding);
            if (descriptor.Sequence != sequence || !descriptor.WalHash.AsSpan().SequenceEqual(digest) ||
                !descriptor.PreviousManifestHash.AsSpan().SequenceEqual(head.ManifestHash) || !descriptor.ManifestHash.AsSpan().SequenceEqual(record.ManifestHash))
                throw new InvalidDataException("Generation does not bind its WAL.");
            using var previous = Open(root, head.Sequence, admission, head.ManifestHash);
            using var current = Open(root, sequence, admission, record.ManifestHash);
            try { ScalarGeneration.ValidateReplacement(previous, record.NodeId, record.Value); }
            catch (Exception exception) when (exception is ArgumentException or NotSupportedException or System.Xml.XmlException)
            { throw new InvalidDataException("Invalid epoch scalar operation.", exception); }
            ValidateFiles(data, binding.Identity.DocumentId, record.ManifestHash);
            ValidateTransition(previous, current, record.NodeId, record.Value);
            head = new(sequence, record.ManifestHash, digest); hashes.Add(sequence, head);
        }
        foreach (var path in Directory.EnumerateFileSystemEntries(Path.Combine(root, ".transactions", "generations")))
        {
            BinaryEnvelope.RejectLinks(path);
            if (!Directory.Exists(path) || !hashes.ContainsKey(EpochAuthorityCodec.ParseGenerationName(Path.GetFileName(path))))
                throw new InvalidDataException("Published generation has no intact WAL witness.");
        }
        var currentPath = Path.Combine(root, ".transactions", "CURRENT");
        if (File.Exists(currentPath))
        {
            var current = EpochAuthorityCodec.DecodeCurrent(BinaryEnvelope.ReadFile(currentPath), binding);
            if (!hashes.TryGetValue(current.Sequence, out var selected) || !current.ManifestHash.AsSpan().SequenceEqual(selected.ManifestHash) ||
                !current.WalHash.AsSpan().SequenceEqual(selected.WalHash)) throw new InvalidDataException("CURRENT is not a verified WAL prefix.");
        }
        EpochGenerationReader.ValidateDirectory(root, binding, hashes.ToDictionary(pair => pair.Key, pair => pair.Value.ManifestHash));
        return head;
    }

    internal static ImmutableXmlSnapshot Open(string root, ulong sequence, EpochAdmissionLease admission, byte[] hash) =>
        ImmutableXmlSnapshot.OpenMutableEpochGeneration(root, sequence, admission.ForkShared(), hash, BinaryEnvelope.MaximumFileBytes, null);

    internal static void ValidateFiles(string data, ulong documentId, byte[] hash)
    {
        if (!TransactionCodec.ManifestHash(data, documentId).AsSpan().SequenceEqual(hash)) throw new InvalidDataException("Manifest identity mismatch.");
        var manifest = StoreCodec.ReadManifest(TransactionCodec.ReadManifestBytes(data, documentId));
        foreach (var fragment in manifest.Fragments)
            if (!SHA256.HashData(BinaryEnvelope.ReadFile(Path.Combine(data, "fragments", fragment.Id.ToString(System.Globalization.CultureInfo.InvariantCulture) + ".bin"))).AsSpan().SequenceEqual(fragment.Hash))
                throw new InvalidDataException("Corrupt epoch fragment.");
    }

    internal static void ValidateTransition(ImmutableXmlSnapshot previous, ImmutableXmlSnapshot current, ulong target, string value)
    {
        if (previous.NodeCount != current.NodeCount || previous.DocumentUri != current.DocumentUri) throw new InvalidDataException("Scalar update changed document structure.");
        for (ulong id = 1; id <= (ulong)current.NodeCount; id++)
        {
            var a = previous.GetNode(id); var b = current.GetNode(id);
            if (a with { ValueOffset = b.ValueOffset, ValueLength = b.ValueLength, Children = b.Children, Attributes = b.Attributes, Namespaces = b.Namespaces } != b ||
                !a.Children.SequenceEqual(b.Children) || !a.Attributes.SequenceEqual(b.Attributes) || !a.Namespaces.SequenceEqual(b.Namespaces) ||
                current.ReadValue(id) != (id == target ? value : previous.ReadValue(id))) throw new InvalidDataException("Scalar materialization differs from declared operation.");
        }
    }
}

internal static class EpochGenerationReader
{
    internal static string PathFor(string root, ulong sequence) => Path.Combine(root, ".transactions", "readers", EpochAuthorityCodec.ReaderFileName(sequence));
    internal static void Ensure(string root, EpochAuthorityBinding binding, ulong sequence, byte[] hash, ITransactionStorage storage)
    {
        var path = PathFor(root, sequence);
        if (!File.Exists(path))
        {
            var temporary = path + ".tmp-" + Guid.NewGuid().ToString("N");
            TransactionCodec.WriteFlushed(temporary, EpochAuthorityCodec.EncodeReader(new(binding, sequence, hash)), storage);
            TransactionCodec.PublishFile(temporary, path, false, storage);
        }
        Validate(BinaryEnvelope.ReadFile(path), binding, sequence, hash);
    }
    internal static FileStream Acquire(string root, EpochAuthorityBinding binding, ulong sequence, byte[] hash)
    {
        var path = PathFor(root, sequence); BinaryEnvelope.RejectLinks(path);
        var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        try
        {
            if (stream.Length != 189) throw new InvalidDataException("Invalid epoch reader size.");
            var bytes = new byte[189]; stream.ReadExactly(bytes); Validate(bytes, binding, sequence, hash); return stream;
        }
        catch { stream.Dispose(); throw; }
    }
    private static void Validate(byte[] bytes, EpochAuthorityBinding binding, ulong sequence, byte[] hash)
    {
        var record = EpochAuthorityCodec.DecodeReader(bytes, binding);
        if (record.Sequence != sequence || !record.ManifestHash.AsSpan().SequenceEqual(hash)) throw new InvalidDataException("Epoch reader selection mismatch.");
    }
    internal static void ValidateDirectory(string root, EpochAuthorityBinding binding, Dictionary<ulong, byte[]>? expected)
    {
        foreach (var path in Directory.EnumerateFileSystemEntries(Path.Combine(root, ".transactions", "readers")))
        {
            BinaryEnvelope.RejectLinks(path); var name = Path.GetFileName(path);
            if (Directory.Exists(path)) throw new InvalidDataException("Reader identity is a directory.");
            if (name.Length == 63 && name.AsSpan(26, 5).SequenceEqual(".tmp-") && Guid.TryParseExact(name.AsSpan(31), "N", out _))
            { EpochAuthorityCodec.ParseReaderName(name[..26]); continue; }
            var sequence = EpochAuthorityCodec.ParseReaderName(name);
            var record = EpochAuthorityCodec.DecodeReader(BinaryEnvelope.ReadFile(path), binding);
            if (record.Sequence != sequence || expected is not null && (!expected.TryGetValue(sequence, out var hash) || !record.ManifestHash.AsSpan().SequenceEqual(hash)))
                throw new InvalidDataException("Reader identity is not in verified history.");
        }
    }
}
