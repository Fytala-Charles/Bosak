// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Prototypes separate verification, restore and migration administration with explicit outcomes.
// SPECIAL NOTES        : PA2 internal prototype; returned receipts are not routing, recovery or retirement authority.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 28-10-2026     | Add read-only publication observation without invoking storage writes
//                      | Charles Korthout | 0.3   | 28-10-2026     | Add owner-bound read-only preparation and local dispatch claim through a partial facade
// ===========================================================================================================================================================

using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

internal enum EpochAdministrativeStage { PreflightVerified, ProofVerified, ReadyToPublish, Published }
internal enum EpochArtifactProfile { LegacyFullHistory, ScalarEpochFullHistory }
internal enum EpochPublicationKind { LegacyMigration, IndependentEpochRestore }
internal sealed record EpochAdministrativeOptions(DurabilityMode Durability);
internal sealed record EpochVerificationReceipt(EpochArtifactProfile Profile, Guid BackupId, EpochIdentity? SourceEpoch, ulong DocumentId,
    ulong CommitSequence, string InventorySha256);
internal sealed record EpochPublishedReceipt(EpochPublicationKind Kind, Guid OperationId, Guid BackupId, EpochIdentity? SourceEpoch,
    EpochIdentity DestinationEpoch, ulong CommitSequence, string StorePath);

internal sealed partial class ScalarEpochAdministration
{
    private readonly ITransactionStorage _storage;
    private readonly Action<EpochAdministrativeStage>? _checkpoint;
    private ScalarEpochAdministration(ITransactionStorage storage, Action<EpochAdministrativeStage>? checkpoint) { _storage = storage; _checkpoint = checkpoint; }
    internal static ScalarEpochAdministration Create(EpochAdministrativeOptions options)
    {
        Validate(options); return new(new LocalTransactionStorage(options.Durability), null);
    }
    // Test-only injection seam; no proposed public filesystem or routing extension point.
    internal static ScalarEpochAdministration CreateCore(EpochAdministrativeOptions options, ITransactionStorage storage, Action<EpochAdministrativeStage>? checkpoint = null)
    {
        Validate(options); ArgumentNullException.ThrowIfNull(storage);
        if (storage.Durability != options.Durability) throw new ArgumentException("Storage durability must match administrative options.", nameof(storage));
        return new(storage, checkpoint);
    }
    private static void Validate(EpochAdministrativeOptions options)
    {
        ArgumentNullException.ThrowIfNull(options);
        if (!Enum.IsDefined(options.Durability)) throw new ArgumentOutOfRangeException(nameof(options));
    }
    internal EpochVerificationReceipt VerifyLegacyBackup(string artifact, string workspacePlacementHint)
    {
        Arguments(artifact, workspacePlacementHint);
        var bytes = BinaryEnvelope.ReadFile(Path.Combine(artifact, "inventory.bin"));
        var inventory = LegacyMigrationVerifier.Verify(artifact, workspacePlacementHint, _storage, stage =>
        {
            if (stage == LegacyMigrationStage.PreflightVerified) _checkpoint?.Invoke(EpochAdministrativeStage.PreflightVerified);
            if (stage == LegacyMigrationStage.RedoVerified) _checkpoint?.Invoke(EpochAdministrativeStage.ProofVerified);
        });
        if (!bytes.AsSpan().SequenceEqual(BinaryEnvelope.ReadFile(Path.Combine(artifact, "inventory.bin"))))
            throw new InvalidDataException("Legacy artifact inventory changed during administration.");
        return new(EpochArtifactProfile.LegacyFullHistory, inventory.Identity.BackupId, null, inventory.Identity.DocumentId,
            inventory.Identity.CommitSequence, Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant());
    }
    internal EpochVerificationReceipt VerifyEpochBackup(string artifact, string workspacePlacementHint)
    {
        Arguments(artifact, workspacePlacementHint);
        var hint = BackupStorage.Destination(artifact, workspacePlacementHint);
        artifact = Path.GetFullPath(artifact);
        var bytes = BinaryEnvelope.ReadFile(Path.Combine(artifact, "inventory.bin"));
        var inventory = EpochBackupStorage.ReadArtifact(artifact);
        if (!bytes.AsSpan().SequenceEqual(EpochBackupCodec.EncodeInventory(inventory))) throw new InvalidDataException("Epoch artifact inventory changed before proof.");
        _checkpoint?.Invoke(EpochAdministrativeStage.PreflightVerified);
        BackupStorage.Preflight(hint, _storage);
        var workspace = EpochBackupStorage.Workspace(hint, _storage);
        EpochBackupStorage.VerifyCopies(Path.Combine(artifact, "data"), workspace, inventory, _storage);
        _checkpoint?.Invoke(EpochAdministrativeStage.ProofVerified);
        EpochBackupStorage.ReadArtifact(artifact);
        if (!bytes.AsSpan().SequenceEqual(BinaryEnvelope.ReadFile(Path.Combine(artifact, "inventory.bin"))))
            throw new InvalidDataException("Epoch artifact inventory changed after proof.");
        EpochBackupStorage.RemoveWorkspace(workspace, _storage);
        return new(EpochArtifactProfile.ScalarEpochFullHistory, inventory.BackupId, inventory.Source.Identity, inventory.Source.Identity.DocumentId,
            inventory.CommitSequence, Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant());
    }
    internal EpochPublishedReceipt ConvertLegacyBackup(string artifact, string destination)
    {
        Arguments(artifact, destination);
        var result = EpochLegacyMigration.Convert(artifact, destination, _storage, stage =>
        {
            if (stage == EpochMigrationStage.SourceVerified) _checkpoint?.Invoke(EpochAdministrativeStage.ProofVerified);
            if (stage == EpochMigrationStage.BundleVerified) _checkpoint?.Invoke(EpochAdministrativeStage.ReadyToPublish);
            if (stage == EpochMigrationStage.Published) _checkpoint?.Invoke(EpochAdministrativeStage.Published);
        });
        return new(EpochPublicationKind.LegacyMigration, result.MigrationId, result.BackupId, null, result.Destination, result.CommitSequence, result.StorePath);
    }
    internal EpochPublishedReceipt RestoreEpochBackup(string artifact, string destination)
    {
        Arguments(artifact, destination);
        var result = EpochBackupRestore.Restore(artifact, destination, _storage, stage =>
        {
            if (stage == EpochRestoreStage.SourceVerified) _checkpoint?.Invoke(EpochAdministrativeStage.ProofVerified);
            if (stage == EpochRestoreStage.BundleVerified) _checkpoint?.Invoke(EpochAdministrativeStage.ReadyToPublish);
            if (stage == EpochRestoreStage.Published) _checkpoint?.Invoke(EpochAdministrativeStage.Published);
        });
        return new(EpochPublicationKind.IndependentEpochRestore, result.RestoreId, result.BackupId, result.Source, result.Destination, result.CommitSequence, result.StorePath);
    }
    internal EpochPublicationObservation InspectPublication(EpochPublicationInspectionRequest request) => EpochPublicationInspector.Inspect(request);
    private static void Arguments(string artifact, string destination)
    { ArgumentException.ThrowIfNullOrWhiteSpace(artifact); ArgumentException.ThrowIfNullOrWhiteSpace(destination); }
}
