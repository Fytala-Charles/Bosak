// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Coordinates single-document scalar commits and WAL recovery.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      | Charles Korthout | 0.2   | 26-10-2026     | Add explicit durability policy and injected persistence operations
//                      | Charles Korthout | 0.3   | 26-10-2026     | Add non-deleting checkpoints, recovery statistics and reader leases
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.4   | 26-10-2026     | Add recovery descriptors and conservative retention inventory
//                      | Charles Korthout | 0.5   | 27-10-2026     | Add verified full-history backup and restore partial
//                      | Charles Korthout | 0.6   | 27-10-2026     | Guard cooperating mutations during internal cutover freeze
//                      | Charles Korthout | 0.7   | 29-10-2026     | Defer original writer close for opt-in enrollment children
// ===========================================================================================================================================================

using System.Globalization;
using System.Security.Cryptography;


namespace Bosak.XmlDb.Storage;

/// <summary>Coordinates single-document scalar commits and WAL recovery.</summary>
/// <remarks>
/// Experimental process-crash recovery. One exclusive coordinator owns the store;
/// generations and logs are retained. File flushing does not imply a tested power-loss guarantee.
/// </remarks>
public sealed partial class EmbeddedXmlDatabase : IDisposable
{
    private readonly object _gate = new();
    private readonly ITransactionStorage _storage;
    private readonly string _root;
    private readonly string _transactions;
    private readonly ulong _documentId;
    private readonly FileStream _lease;
    private readonly Action<CommitStage>? _checkpoint;
    private string _visibleRoot;
    private byte[] _manifestHash = [];
    private ulong _sequence;
    private bool _disposed;
    private bool _faulted;
    private readonly RecoveryMode _recoveryMode;
    private RecoveryStatistics _lastRecovery;
    private byte[] _prefixHash = new byte[32];

    private EmbeddedXmlDatabase(string root, ulong documentId, FileStream lease, Action<CommitStage>? checkpoint, ITransactionStorage storage, RecoveryMode recovery)
    {
        _root = root;
        _storage = storage;
        _recoveryMode = recovery;
        _transactions = Path.Combine(root, ".transactions");
        _documentId = documentId;
        _lease = lease;
        _checkpoint = checkpoint;
        _visibleRoot = root;
    }

    /// <summary>Gets the filesystem barrier policy requested for this coordinator.</summary>
    public DurabilityMode Durability => _storage.Durability;

    /// <summary>Gets work and checkpoint selection reported by the most recent open.</summary>
    public RecoveryStatistics LastRecovery { get { lock (_gate) { ThrowIfUnavailable(); return _lastRecovery; } } }

    /// <summary>Gets the latest recovered or acknowledged document commit sequence.</summary>
    public ulong CommitSequence { get { lock (_gate) { ThrowIfUnavailable(); return _sequence; } } }

    /// <summary>Acquires a process-crash-mode coordinator lease and recovers committed WAL records.</summary>
    /// <param name="databaseRoot">Existing M1 store root.</param>
    /// <param name="documentId">The store's document identity.</param>
    /// <returns>An owned embedded coordinator.</returns>
    /// <exception cref="IOException">Another coordinator owns the lease or storage I/O fails.</exception>
    /// <exception cref="InvalidDataException">Recovery detects corruption or a broken committed chain.</exception>
    public static EmbeddedXmlDatabase Open(string databaseRoot, ulong documentId = 1) =>
        Open(databaseRoot, DurabilityMode.ProcessCrash, documentId);

    /// <summary>Acquires a coordinator using explicit filesystem barriers without silently falling back.</summary>
    /// <param name="databaseRoot">Existing store root.</param>
    /// <param name="durability">Requested per-coordinator barrier policy.</param>
    /// <param name="documentId">The store's document identity.</param>
    /// <returns>An owned embedded coordinator.</returns>
    /// <exception cref="PlatformNotSupportedException">Directory barriers are requested on an unsupported platform.</exception>
    /// <exception cref="IOException">The filesystem rejects a barrier, ownership or storage operation.</exception>
    /// <exception cref="InvalidDataException">Recovery detects corrupt state.</exception>
    public static EmbeddedXmlDatabase Open(string databaseRoot, DurabilityMode durability, ulong documentId = 1) =>
        OpenCore(databaseRoot, documentId, null, new LocalTransactionStorage(durability));

    /// <summary>Opens with optional verified checkpoint recovery while retaining all history.</summary>
    /// <param name="databaseRoot">Existing store root.</param>
    /// <param name="recovery">Whether to prefer an optional checkpoint or replay the full journal.</param>
    /// <param name="durability">Per-coordinator filesystem barrier policy.</param>
    /// <param name="documentId">Logical document identity.</param>
    /// <returns>An owned coordinator; LastRecovery reports the selected path.</returns>
    public static EmbeddedXmlDatabase Open(string databaseRoot, RecoveryMode recovery,
        DurabilityMode durability = DurabilityMode.ProcessCrash, ulong documentId = 1) =>
        OpenCore(databaseRoot, documentId, null, new LocalTransactionStorage(durability), recovery);
    internal static EmbeddedXmlDatabase OpenCore(string databaseRoot, ulong documentId, Action<CommitStage>? checkpoint, ITransactionStorage? storage = null, RecoveryMode recovery = RecoveryMode.FullJournal)
    {
        ArgumentOutOfRangeException.ThrowIfZero(documentId);
        if (!Enum.IsDefined(recovery)) throw new ArgumentOutOfRangeException(nameof(recovery));
        var root = Path.GetFullPath(databaseRoot);
        storage ??= new LocalTransactionStorage();
        storage.SyncDirectory(root); // Preflight the requested barrier before adopting/mutating the store.
        // Validate the base before adopting it; bypass only the transactional-root public guard.
        using (ImmutableXmlSnapshot.OpenVersion(root, documentId, 0)) { }
        var transactions = Path.Combine(root, ".transactions");
        TransactionCodec.EnsureDirectory(transactions, storage);
        var leasePath = Path.Combine(transactions, "writer.lock");
        if (File.Exists(leasePath)) BinaryEnvelope.RejectLinks(leasePath);
        var lease = new FileStream(leasePath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
        try
        {
            var database = new EmbeddedXmlDatabase(root, documentId, lease, checkpoint, storage, recovery);
            if (storage.Durability == DurabilityMode.FileAndDirectoryFlush)
                TransactionCodec.SyncExistingStore(root, leasePath, storage);
            database.InitializeAndRecover();
            return database;
        }
        catch { lease.Dispose(); throw; }
    }

    /// <summary>Opens a snapshot pinned to the currently visible generation.</summary>
    /// <param name="cacheBytes">Maximum retained decoded payload bytes.</param>
    /// <returns>An independently owned snapshot that survives later commits and coordinator disposal.</returns>
    public ImmutableXmlSnapshot BeginRead(int cacheBytes = 8 * 1024 * 1024)
    {
        lock (_gate)
        {
            ThrowIfUnavailable();
            return OpenPinnedSnapshot(cacheBytes);
        }
    }

    /// <summary>Begins an optimistic transaction against the current document generation.</summary>
    /// <returns>A transaction; disposal without commit rolls back.</returns>
    public XmlWriteTransaction BeginWrite()
    {
        lock (_gate)
        {
            ThrowIfUnavailable();
            RejectCutoverMutation();
            return new(this, OpenPinnedSnapshot(8 * 1024 * 1024));
        }
    }

    internal ulong Commit(ulong baseSequence, ulong nodeId, string value)
    {
        lock (_gate)
        {
            ThrowIfUnavailable();
            RejectCutoverMutation();
            if (baseSequence != _sequence) throw new TransactionConflictException("The document changed after this transaction began.");
            var next = checked(_sequence + 1);
            if (next > 10_000) throw new NotSupportedException("The experimental retained journal is limited to 10,000 commits.");
            var staging = Path.Combine(_transactions, "staging", Guid.NewGuid().ToString("N"));
            try
            {
                var hash = ScalarGeneration.Build(_visibleRoot, staging, _documentId, nodeId, value, _checkpoint, _storage);
                var record = new WalRecord(_documentId, next, Guid.NewGuid(), nodeId, value, _manifestHash, hash);
                var bytes = TransactionCodec.EncodeWal(record);
                _checkpoint?.Invoke(CommitStage.BeforeWal);
                using (var stream = _storage.CreateFile(WalPath(next)))
                {
                    stream.Write(bytes.AsSpan(0, 16));
                    _checkpoint?.Invoke(CommitStage.WalPrefixWritten);
                    stream.Write(bytes.AsSpan(16));
                    _checkpoint?.Invoke(CommitStage.WalWritten);
                    stream.FlushToDisk();
                }
                _storage.SyncDirectory(Path.Combine(_transactions, "wal"));
                _checkpoint?.Invoke(CommitStage.WalFlushed);
                var generation = GenerationPath(next);
                TransactionCodec.PublishGeneration(staging, generation, _storage);
                _checkpoint?.Invoke(CommitStage.GenerationPublished);
                PublishRoot(new(_documentId, next, hash));
                _visibleRoot = generation;
                _manifestHash = hash;
                _sequence = next;
                _prefixHash = CheckpointCodec.ExtendPrefix(_prefixHash, bytes);
                return next;
            }
            catch
            {
                // Outcome may be committed once a complete WAL exists. Never continue on an uncertain coordinator.
                _faulted = true;
                throw;
            }
        }
    }

    /// <inheritdoc />
    public void Dispose()
    {
        lock (_gate)
        {
            if (_disposed) return;
            _disposed = true;
            CloseEnrollmentOwnerIfReady();
        }
    }

    /// <summary>Publishes a complete immutable checkpoint without deleting any generation or WAL record.</summary>
    /// <returns>The checkpoint's committed sequence.</returns>
    /// <exception cref="InvalidOperationException">No commit exists or the coordinator requires recovery.</exception>
    /// <exception cref="IOException">Checkpoint persistence fails; reopen the coordinator before continuing.</exception>
    public ulong CreateCheckpoint()
    {
        lock (_gate)
        {
            ThrowIfUnavailable();
            RejectCutoverMutation();
            if (_sequence == 0) throw new InvalidOperationException("Commit a scalar change before creating a checkpoint.");
            try
            {
                var prefix = new byte[32];
                var predecessor = TransactionCodec.ManifestHash(_root, _documentId);
                byte[] walHash = [];
                var ids = new HashSet<Guid>();
                for (ulong sequence = 1; sequence <= _sequence; sequence++)
                {
                    var path = WalPath(sequence);
                    var record = TransactionCodec.ReadWal(path) ?? throw new InvalidDataException("Checkpoint prefix contains an incomplete record.");
                    if (record.DocumentId != _documentId || record.Sequence != sequence || !ids.Add(record.TransactionId) ||
                        !predecessor.AsSpan().SequenceEqual(record.PreviousManifestHash))
                        throw new InvalidDataException("Checkpoint prefix is not a contiguous committed chain.");
                    var bytes = BinaryEnvelope.ReadFile(path);
                    prefix = CheckpointCodec.ExtendPrefix(prefix, bytes);
                    walHash = SHA256.HashData(bytes);
                    predecessor = record.ManifestHash;
                }
                if (!prefix.AsSpan().SequenceEqual(_prefixHash) || !predecessor.AsSpan().SequenceEqual(_manifestHash))
                    throw new InvalidDataException("Journal changed after the coordinator recovered it.");
                var anchor = new CheckpointAnchor(_documentId, _sequence, _manifestHash, walHash, prefix);
                var anchorBytes = CheckpointCodec.Encode(anchor);
                var destination = CheckpointCodec.DirectoryPath(_transactions, _sequence);
                TransactionCodec.EnsureDirectory(Path.GetDirectoryName(destination)!, _storage);
                if (!Directory.Exists(destination))
                {
                    var staging = Path.Combine(_transactions, "staging", "checkpoint-" + Guid.NewGuid().ToString("N"));
                    CheckpointCodec.CopyMaterialization(_visibleRoot, staging, _documentId, _manifestHash, _storage, _checkpoint);
                    TransactionCodec.WriteFlushed(Path.Combine(staging, "anchor.bin"), anchorBytes, _storage);
                    _checkpoint?.Invoke(CommitStage.CheckpointAnchorFlushed);
                    TransactionCodec.PublishGeneration(staging, destination, _storage);
                    _checkpoint?.Invoke(CommitStage.CheckpointDirectoryPublished);
                }
                else
                {
                    if (!BinaryEnvelope.ReadFile(Path.Combine(destination, "anchor.bin")).AsSpan().SequenceEqual(anchorBytes))
                        throw new InvalidDataException("Existing checkpoint identity differs; immutable checkpoints cannot be overwritten.");
                    ScalarGeneration.Validate(destination, _documentId, _manifestHash);
                }
                var temporary = Path.Combine(_transactions, "checkpoint-" + Guid.NewGuid().ToString("N") + ".tmp");
                TransactionCodec.WriteFlushed(temporary, TransactionCodec.EncodePointer(
                    new(_documentId, _sequence, SHA256.HashData(anchorBytes)), "BXCS"), _storage);
                _checkpoint?.Invoke(CommitStage.CheckpointSelectorTemporaryFlushed);
                TransactionCodec.PublishFile(temporary, Path.Combine(_transactions, "CHECKPOINT"), true, _storage);
                _checkpoint?.Invoke(CommitStage.CheckpointSelectorPublished);
                return _sequence;
            }
            catch { _faulted = true; throw; }
        }
    }

    /// <summary>Publishes an immutable recovery descriptor for a complete checkpoint; retains all history.</summary>
    /// <returns>The independently discoverable checkpoint sequence.</returns>
    /// <remarks>Older binaries ignore descriptors. All retained WAL is still required.</remarks>
    public ulong CreateRecoveryAnchor()
    {
        lock (_gate)
        {
            ThrowIfUnavailable();
            RejectCutoverMutation();
            CreateCheckpoint();
            try
            {
                var directory = Path.Combine(_transactions, "anchors");
                TransactionCodec.EnsureDirectory(directory, _storage);
                var path = Path.Combine(directory, _sequence.ToString("D20", System.Globalization.CultureInfo.InvariantCulture) + ".anchor");
                var bytes = BinaryEnvelope.ReadFile(Path.Combine(_transactions, "CHECKPOINT"));
                if (File.Exists(path))
                {
                    if (!BinaryEnvelope.ReadFile(path).AsSpan().SequenceEqual(bytes))
                        throw new InvalidDataException("Immutable recovery descriptor differs from the checkpoint.");
                }
                else
                {
                    var temporary = Path.Combine(directory, Guid.NewGuid().ToString("N") + ".tmp");
                    TransactionCodec.WriteFlushed(temporary, bytes, _storage);
                    TransactionCodec.PublishFile(temporary, path, false, _storage);
                }
                return _sequence;
            }
            catch { _faulted = true; throw; }
        }
    }

    /// <summary>Inventories retained files without changing files or granting deletion permission.</summary>
    /// <returns>A conservative point-in-time report; lease identities are not proof of active readers.</returns>
    public RetentionReport PlanRetention()
    {
        lock (_gate)
        {
            ThrowIfUnavailable();
            return RetentionPlanner.Inspect(_root, _visibleRoot, _sequence);
        }
    }

    private ImmutableXmlSnapshot OpenPinnedSnapshot(int cacheBytes)
    {
        ArgumentOutOfRangeException.ThrowIfNegative(cacheBytes);
        IDisposable? lease = null;
        try
        {
            lease = GenerationLease.Acquire(_transactions, _documentId, _sequence, _storage);
            var snapshot = ImmutableXmlSnapshot.OpenVersion(_visibleRoot, _documentId, _sequence, cacheBytes);
            snapshot.AttachReaderLease(lease);
            return snapshot;
        }
        catch
        {
            lease?.Dispose();
            _faulted = true;
            throw;
        }
    }
    private void InitializeAndRecover(bool forceFullJournal = false)
    {
        _visibleRoot = _root;
        _sequence = 0;
        _prefixHash = new byte[32];
        TransactionCodec.EnsureDirectory(Path.Combine(_transactions, "wal"), _storage);
        TransactionCodec.EnsureDirectory(Path.Combine(_transactions, "generations"), _storage);
        TransactionCodec.EnsureDirectory(Path.Combine(_transactions, "staging"), _storage);
        var controlPath = Path.Combine(_transactions, "CONTROL");
        var headPath = Path.Combine(_transactions, "CURRENT");
        var baseHash = TransactionCodec.ManifestHash(_root, _documentId);
        if (!File.Exists(controlPath))
        {
            if (File.Exists(headPath) || Directory.EnumerateFiles(Path.Combine(_transactions, "wal")).Any())
                throw new InvalidDataException("Transaction control identity is missing.");
            var temporary = Path.Combine(_transactions, "control-" + Guid.NewGuid().ToString("N") + ".tmp");
            TransactionCodec.WriteFlushed(temporary, TransactionCodec.EncodePointer(new(_documentId, 0, baseHash), "BXTC"), _storage);
            TransactionCodec.PublishFile(temporary, controlPath, false, _storage);
        }
        var control = TransactionCodec.ReadPointer(controlPath, "BXTC");
        if (control.DocumentId != _documentId || control.Sequence != 0 || !baseHash.AsSpan().SequenceEqual(control.ManifestHash))
            throw new InvalidDataException("Base store does not match transaction control identity.");
        var head = File.Exists(headPath) ? TransactionCodec.ReadPointer(headPath, "BXHD") : null;
        if (head is not null && head.DocumentId != _documentId) throw new InvalidDataException("Published document identity mismatch.");
        var rejected = forceFullJournal;
        var candidate = !forceFullJournal && _recoveryMode == RecoveryMode.PreferCheckpoint
            ? CheckpointCodec.TryLoad(_transactions, _documentId, out rejected) : null;
        _manifestHash = baseHash;
        var hashes = new Dictionary<ulong, byte[]> { [0] = baseHash };
        var transactions = new HashSet<Guid>();
        var paths = Directory.GetFiles(Path.Combine(_transactions, "wal"));
        if (paths.Length > 10_000) throw new InvalidDataException("Journal exceeds the experimental commit limit.");
        Array.Sort(paths, StringComparer.Ordinal);
        if (candidate is not null && candidate.Anchor.Sequence > (ulong)paths.Length) { candidate = null; rejected = true; }
        var validated = 0;
        var replayed = 0;
        ulong selectedSequence = 0;
        for (var index = 0; index < paths.Length; index++)
        {
            var expected = checked(_sequence + 1);
            if (!string.Equals(Path.GetFileName(paths[index]), WalName(expected), StringComparison.Ordinal))
                throw new InvalidDataException("Missing, unexpected or noncanonical WAL record.");
            var record = TransactionCodec.ReadWal(paths[index]);
            if (record is null)
            {
                if (candidate is not null && expected <= candidate.Anchor.Sequence)
                {
                    InitializeAndRecover(forceFullJournal: true);
                    return;
                }
                if (index != paths.Length - 1 || (head is not null && head.Sequence >= expected))
                    throw new InvalidDataException("Committed or non-final WAL record is incomplete.");
                _storage.DeleteFile(paths[index]);
                _storage.SyncDirectory(Path.GetDirectoryName(paths[index])!);
                break;
            }
            if (record.DocumentId != _documentId || record.Sequence != expected ||
                !transactions.Add(record.TransactionId) || !_manifestHash.AsSpan().SequenceEqual(record.PreviousManifestHash))
                throw new InvalidDataException("Broken WAL identity, sequence or predecessor chain.");
            var walBytes = BinaryEnvelope.ReadFile(paths[index]);
            _prefixHash = CheckpointCodec.ExtendPrefix(_prefixHash, walBytes);
            var skipMaterialization = candidate is not null && expected <= candidate.Anchor.Sequence;
            if (skipMaterialization && expected == candidate!.Anchor.Sequence)
            {
                var anchor = candidate.Anchor;
                if (!_prefixHash.AsSpan().SequenceEqual(anchor.PrefixHash) ||
                    !SHA256.HashData(walBytes).AsSpan().SequenceEqual(anchor.WalHash) ||
                    !record.ManifestHash.AsSpan().SequenceEqual(anchor.ManifestHash))
                {
                    InitializeAndRecover(forceFullJournal: true);
                    return;
                }
                _visibleRoot = candidate.Root;
                selectedSequence = anchor.Sequence;
                validated++;
            }
            if (!skipMaterialization)
            {
                using (var predecessor = ImmutableXmlSnapshot.OpenVersion(_visibleRoot, _documentId, _sequence))
                {
                    try { ScalarGeneration.ValidateReplacement(predecessor, record.NodeId, record.Value); }
                    catch (Exception exception) when (exception is ArgumentException or NotSupportedException or System.Xml.XmlException)
                    {
                        throw new InvalidDataException("WAL contains an invalid scalar replacement.", exception);
                    }
                }
                var generation = GenerationPath(expected);
                if (!Directory.Exists(generation))
                {
                    var staging = Path.Combine(_transactions, "staging", Guid.NewGuid().ToString("N"));
                    var hash = ScalarGeneration.Build(_visibleRoot, staging, _documentId, record.NodeId, record.Value, _checkpoint, _storage);
                    if (!hash.AsSpan().SequenceEqual(record.ManifestHash)) throw new InvalidDataException("Redo does not reproduce the committed manifest.");
                    TransactionCodec.PublishGeneration(staging, generation, _storage);
                    _checkpoint?.Invoke(CommitStage.GenerationPublished);
                    replayed++;
                }
                ScalarGeneration.Validate(generation, _documentId, record.ManifestHash);
                using (var materialized = ImmutableXmlSnapshot.OpenVersion(generation, _documentId, expected))
                {
                    if (materialized.ReadValue(record.NodeId) != record.Value)
                        throw new InvalidDataException("Materialized scalar does not match its WAL record.");
                }
                _visibleRoot = generation;
                validated++;
            }
            _manifestHash = record.ManifestHash;
            _sequence = expected;
            hashes.Add(expected, record.ManifestHash);
        }
        if (head is not null && (!hashes.TryGetValue(head.Sequence, out var hashAtHead) ||
                                  !hashAtHead.AsSpan().SequenceEqual(head.ManifestHash)))
            throw new InvalidDataException("Published root is not represented by the intact WAL chain.");
        if (_sequence > 0 || head is not null) PublishRoot(new(_documentId, _sequence, _manifestHash));
        _lastRecovery = new(selectedSequence, (int)_sequence, validated, replayed, rejected);
    }

    private void PublishRoot(RootPointer pointer)
    {
        var temporary = Path.Combine(_transactions, "root-" + Guid.NewGuid().ToString("N") + ".tmp");
        TransactionCodec.WriteFlushed(temporary, TransactionCodec.EncodePointer(pointer, "BXHD"), _storage);
        _checkpoint?.Invoke(CommitStage.RootTemporaryFlushed);
        var current = Path.Combine(_transactions, "CURRENT");
        if (File.Exists(current)) BinaryEnvelope.RejectLinks(current);
        TransactionCodec.PublishFile(temporary, current, true, _storage);
        _checkpoint?.Invoke(CommitStage.RootPublished);
    }

    private string WalPath(ulong sequence) => Path.Combine(_transactions, "wal", WalName(sequence));
    private static string WalName(ulong sequence) => sequence.ToString("D20", CultureInfo.InvariantCulture) + ".wal";
    private string GenerationPath(ulong sequence) => Path.Combine(_transactions, "generations", sequence.ToString("D20", CultureInfo.InvariantCulture));

    private void ThrowIfUnavailable()
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        if (_faulted) throw new InvalidOperationException("The coordinator has an uncertain persistence outcome; dispose and reopen for recovery.");
    }

}


