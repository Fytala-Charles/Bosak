// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Stages one scalar replacement against a document generation.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

/// <summary>Reports a stale optimistic document transaction.</summary>
public sealed class TransactionConflictException : InvalidOperationException
{
    /// <summary>Creates a conflict exception.</summary>
    /// <param name="message">Conflict explanation.</param>
    public TransactionConflictException(string message) : base(message) { }
}

/// <summary>Stages one scalar replacement against a document generation.</summary>
/// <remarks>Confined to one caller thread. Disposal rolls back an uncommitted replacement.</remarks>
public sealed class XmlWriteTransaction : IDisposable
{
    private readonly EmbeddedXmlDatabase _database;
    private readonly ImmutableXmlSnapshot _base;
    private ulong _nodeId;
    private string? _value;
    private bool _completed;

    internal XmlWriteTransaction(EmbeddedXmlDatabase database, ImmutableXmlSnapshot snapshot)
    {
        _database = database;
        _base = snapshot;
        BaseSequence = snapshot.CommitSequence;
    }

    /// <summary>Gets the document sequence against which conflict validation occurs.</summary>
    public ulong BaseSequence { get; }

    /// <summary>Stages a text or ordinary attribute value without changing node identity/order.</summary>
    /// <param name="nodeId">Stable scalar node ID within this document.</param>
    /// <param name="value">Replacement XML text value.</param>
    /// <exception cref="NotSupportedException">The node kind or requested mutation is outside this slice.</exception>
    /// <exception cref="InvalidDataException">The value exceeds format limits.</exception>
    public void ReplaceNodeValue(ulong nodeId, string value)
    {
        ThrowIfCompleted();
        ScalarGeneration.ValidateReplacement(_base, nodeId, value);
        if (_nodeId != 0 && _nodeId != nodeId)
            throw new NotSupportedException("This experimental transaction supports one scalar node only.");
        _nodeId = nodeId;
        _value = value;
    }

    /// <summary>Commits and returns the published sequence; failures after WAL writing may have an uncertain outcome.</summary>
    /// <returns>The committed document sequence.</returns>
    /// <exception cref="TransactionConflictException">Another transaction committed after this transaction began.</exception>
    /// <exception cref="InvalidOperationException">No replacement is staged or the coordinator requires recovery.</exception>
    public ulong Commit()
    {
        ThrowIfCompleted();
        if (_value is null) throw new InvalidOperationException("No scalar replacement is staged.");
        _completed = true;
        try { return _database.Commit(BaseSequence, _nodeId, _value); }
        finally { _base.Dispose(); }
    }

    /// <summary>Abandons the staged replacement; no WAL record is written.</summary>
    public void Rollback() => Dispose();

    /// <inheritdoc />
    public void Dispose()
    {
        if (_completed) return;
        _completed = true;
        _value = null;
        _base.Dispose();
    }

    private void ThrowIfCompleted() => ObjectDisposedException.ThrowIf(_completed, this);
}
