// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Encodes mandatory epoch identity and reader admission format contracts.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 27-10-2026     | Parse explicit profiles without widening immutable entry points
// ===========================================================================================================================================================

using System.Buffers.Binary;
using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

internal sealed record EpochIdentity(Guid StoreId, Guid EpochId, ulong DocumentId);

internal enum EpochProfile { ImmutableSnapshot, ScalarWal }
internal sealed record EpochFormatDescriptor(EpochIdentity Identity, EpochProfile Profile);

internal static class EpochCodec
{
    internal const int FormatLength = 99;

    internal static byte[] EncodeFormat(EpochIdentity identity) => EncodeProfile(identity, EpochProfile.ImmutableSnapshot);

    internal static byte[] EncodeProfile(EpochIdentity identity, EpochProfile profile)
    {
        ValidateIdentity(identity);
        var contracts = profile switch
        {
            EpochProfile.ImmutableSnapshot => (Minor: (ushort)0, Reader: (ushort)2, Writer: (ushort)2, Recovery: (ushort)1, Features: 1UL),
            EpochProfile.ScalarWal => (Minor: (ushort)1, Reader: (ushort)3, Writer: (ushort)3, Recovery: (ushort)2, Features: 3UL),
            _ => throw new ArgumentOutOfRangeException(nameof(profile)),
        };
        var bytes = BinaryEnvelope.Encode("BXDB", writer =>
        {
            writer.Write((byte)1); // Mandatory epoch admission; never interpreted as format-1 flags.
            WriteIdentity(writer, identity);
            writer.Write(contracts.Reader);
            writer.Write(contracts.Writer);
            writer.Write(contracts.Recovery);
            writer.Write(contracts.Features);
        });
        BinaryPrimitives.WriteUInt16LittleEndian(bytes.AsSpan(4), 2);
        BinaryPrimitives.WriteUInt16LittleEndian(bytes.AsSpan(6), contracts.Minor);
        SHA256.HashData(bytes.AsSpan(0, bytes.Length - 32), bytes.AsSpan(bytes.Length - 32));
        return bytes;
    }

    // Existing admission/data entry points retain the exact immutable allowlist.
    internal static EpochIdentity DecodeFormat(byte[] bytes) => RequireProfile(bytes, EpochProfile.ImmutableSnapshot).Identity;

    internal static EpochFormatDescriptor RequireProfile(byte[] bytes, EpochProfile required)
    {
        var descriptor = DecodeProfile(bytes);
        if (descriptor.Profile != required) throw new InvalidDataException("Entry point does not support this epoch feature profile.");
        return descriptor;
    }

    internal static EpochFormatDescriptor DecodeProfile(byte[] bytes)
    {
        if (bytes.Length != FormatLength || !bytes.AsSpan(0, 4).SequenceEqual("BXDB"u8) ||
            BinaryPrimitives.ReadUInt16LittleEndian(bytes.AsSpan(4)) != 2 ||
            BinaryPrimitives.ReadUInt16LittleEndian(bytes.AsSpan(6)) > 1 ||
            BinaryPrimitives.ReadInt32LittleEndian(bytes.AsSpan(8)) != FormatLength - 44 ||
            !CryptographicOperations.FixedTimeEquals(SHA256.HashData(bytes.AsSpan(0, bytes.Length - 32)), bytes.AsSpan(bytes.Length - 32)))
            throw new InvalidDataException("Invalid mandatory epoch format framing, version or checksum.");
        using var stream = new MemoryStream(bytes, 12, FormatLength - 44, false);
        using var reader = new BinaryReader(stream, BinaryEnvelope.Utf8);
        if (reader.ReadByte() != 1) throw new InvalidDataException("Unsupported epoch format flags.");
        var identity = ReadIdentity(reader);
        var tuple = (BinaryPrimitives.ReadUInt16LittleEndian(bytes.AsSpan(6)), reader.ReadUInt16(), reader.ReadUInt16(), reader.ReadUInt16(), reader.ReadUInt64());
        var profile = tuple switch
        {
            (0, 2, 2, 1, 1) => EpochProfile.ImmutableSnapshot,
            (1, 3, 3, 2, 3) => EpochProfile.ScalarWal,
            _ => throw new InvalidDataException("Unsupported or inconsistent epoch feature requirements."),
        };
        ValidateIdentity(identity);
        return new(identity, profile);
    }

    internal static byte[] EncodeBinding(string magic, EpochIdentity identity, byte[] format) => BinaryEnvelope.Encode(magic, writer =>
    {
        WriteIdentity(writer, identity);
        writer.Write(SHA256.HashData(format));
    });

    internal static void ValidateBinding(byte[] bytes, string magic, EpochIdentity identity, byte[] format) =>
        BinaryEnvelope.Decode(bytes, magic, reader =>
        {
            if (ReadIdentity(reader) != identity || !reader.ReadBytes(32).AsSpan().SequenceEqual(SHA256.HashData(format)))
                throw new InvalidDataException("Epoch identity or mandatory-format binding mismatch.");
            return true;
        });

    private static void WriteIdentity(BinaryWriter writer, EpochIdentity identity)
    {
        writer.Write(identity.StoreId.ToByteArray()); writer.Write(identity.EpochId.ToByteArray()); writer.Write(identity.DocumentId);
    }

    private static EpochIdentity ReadIdentity(BinaryReader reader) => new(new Guid(reader.ReadBytes(16)), new Guid(reader.ReadBytes(16)), reader.ReadUInt64());

    private static void ValidateIdentity(EpochIdentity identity)
    {
        if (identity.StoreId == Guid.Empty || identity.EpochId == Guid.Empty || identity.DocumentId == 0)
            throw new InvalidDataException("Epoch identities must be nonzero.");
    }
}
