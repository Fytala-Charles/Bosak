// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Executes a claimed administrative plan with pinned input and preknown provenance identity.
// SPECIAL NOTES        : RC2 internal execution only; no durable replay, target reservation, public API or routing.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

// Only a successful owner-bound plan claim can construct this one-entry pipeline context.
// Descriptive records cannot be converted into execution contexts.
internal sealed class EpochAttemptExecution
{
    private int _entered;
    private EpochAttemptExecution(EpochAdministrativeAttemptDescriptor intent) => Intent = intent;
    internal EpochAdministrativeAttemptDescriptor Intent { get; }
    internal static EpochAttemptExecution Claim(EpochAdministrativeAttemptPlan plan, object owner, DurabilityMode durability) => new(plan.Claim(owner, durability));
    internal void Enter(EpochPublicationKind kind, string artifact, string destination, DurabilityMode durability)
    {
        if (Interlocked.CompareExchange(ref _entered, 1, 0) != 0) throw new InvalidOperationException("A claimed attempt can enter its pipeline only once.");
        if (kind != Intent.Kind || durability != Intent.Durability || artifact != Intent.ArtifactRoot || destination != Intent.BundleRoot || Intent.DestinationProfile != EpochProfile.ScalarWal)
            throw new ArgumentException("Pipeline differs from its claimed attempt context.");
    }
    internal void ValidateInput(byte[] bytes)
    {
        if (Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant() != Intent.InventorySha256) throw new InvalidDataException("Input differs from the prepared inventory commitment.");
        if (Intent.Kind == EpochPublicationKind.LegacyMigration)
        {
            var value = EpochMigrationCodec.ReadSourceInventory(bytes);
            if (value.Identity.BackupId != Intent.BackupId || value.Identity.DocumentId != Intent.DocumentId || value.Identity.CommitSequence != Intent.CommitSequence || Intent.SourceEpoch is not null)
                throw new InvalidDataException("Legacy input differs from the prepared source selection.");
        }
        else
        {
            var value = EpochBackupCodec.DecodeInventory(bytes);
            if (value.BackupId != Intent.BackupId || value.Source.Identity != Intent.SourceEpoch || value.Source.Identity.DocumentId != Intent.DocumentId || value.CommitSequence != Intent.CommitSequence)
                throw new InvalidDataException("Epoch input differs from the prepared source selection.");
        }
    }
}

internal sealed partial class ScalarEpochAdministration
{
    internal EpochPublishedReceipt ExecuteAttempt(EpochAdministrativeAttemptPlan plan)
    {
        ArgumentNullException.ThrowIfNull(plan);
        var execution = EpochAttemptExecution.Claim(plan, _attemptOwner, _storage.Durability);
        var intent = execution.Intent;
        if (intent.Kind == EpochPublicationKind.LegacyMigration)
        {
            var result = EpochLegacyMigration.Convert(intent.ArtifactRoot, intent.BundleRoot, _storage, stage =>
            {
                if (stage == EpochMigrationStage.SourceVerified) _checkpoint?.Invoke(EpochAdministrativeStage.ProofVerified);
                if (stage == EpochMigrationStage.BundleVerified) _checkpoint?.Invoke(EpochAdministrativeStage.ReadyToPublish);
                if (stage == EpochMigrationStage.Published) _checkpoint?.Invoke(EpochAdministrativeStage.Published);
            }, execution);
            return new(EpochPublicationKind.LegacyMigration, result.MigrationId, result.BackupId, null, result.Destination, result.CommitSequence, result.StorePath);
        }
        var restored = EpochBackupRestore.Restore(intent.ArtifactRoot, intent.BundleRoot, _storage, stage =>
        {
            if (stage == EpochRestoreStage.SourceVerified) _checkpoint?.Invoke(EpochAdministrativeStage.ProofVerified);
            if (stage == EpochRestoreStage.BundleVerified) _checkpoint?.Invoke(EpochAdministrativeStage.ReadyToPublish);
            if (stage == EpochRestoreStage.Published) _checkpoint?.Invoke(EpochAdministrativeStage.Published);
        }, execution);
        return new(EpochPublicationKind.IndependentEpochRestore, restored.RestoreId, restored.BackupId, restored.Source, restored.Destination, restored.CommitSequence, restored.StorePath);
    }
}
