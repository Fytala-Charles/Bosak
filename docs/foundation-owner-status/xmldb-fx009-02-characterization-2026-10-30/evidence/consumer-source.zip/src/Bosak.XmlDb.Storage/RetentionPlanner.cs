// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Reports conservative retention dependencies without granting deletion permission.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

/// <summary>A retained file and the dependency preventing its removal.</summary>
/// <param name="RelativePath">Path relative to the database root.</param>
/// <param name="Reason">Conservative retention dependency.</param>
public sealed record RetainedFile(string RelativePath, string Reason);

/// <summary>A point-in-time inventory, never an authorization to reclaim files.</summary>
/// <param name="CommitSequence">Coordinator sequence at inspection.</param>
/// <param name="Files">Retained files and their dependencies.</param>
public sealed record RetentionReport(ulong CommitSequence, IReadOnlyList<RetainedFile> Files)
{
    /// <summary>Always false until a compatible retirement protocol exists.</summary>
    public bool CanReclaim => false;
}

internal static class RetentionPlanner
{
    internal static RetentionReport Inspect(string root, string visibleRoot, ulong sequence)
    {
        if ((File.GetAttributes(root) & FileAttributes.ReparsePoint) != 0)
            throw new InvalidDataException("Retention inventory refuses a linked database root.");
        var files = new List<RetainedFile>();
        Visit(root);
        return new(sequence, files.AsReadOnly());

        void Visit(string directory)
        {
            foreach (var path in Directory.EnumerateFileSystemEntries(directory).Order(StringComparer.Ordinal))
            {
                var relative = Path.GetRelativePath(root, path).Replace('\\', '/');
                var attributes = File.GetAttributes(path);
                if ((attributes & FileAttributes.ReparsePoint) != 0)
                    throw new InvalidDataException("Retention inventory refuses symbolic links or reparse points.");
                if ((attributes & FileAttributes.Directory) != 0) { Visit(path); continue; }
                var reason = relative switch
                {
                    var p when p.StartsWith(".transactions/wal/", StringComparison.Ordinal) => "Required full WAL prefix and replay history",
                    var p when p.StartsWith(".transactions/generations/", StringComparison.Ordinal) => "Committed generation; current roots, snapshots and unleased older readers may depend on it",
                    var p when p.StartsWith(".transactions/checkpoints/", StringComparison.Ordinal) => "Checkpoint materialization and anchor dependency",
                    var p when p.StartsWith(".transactions/anchors/", StringComparison.Ordinal) => "Independent recovery descriptor",
                    var p when p.StartsWith(".transactions/readers/", StringComparison.Ordinal) => "Stable lease identity; preserve inode regardless of current holders",
                    var p when p.StartsWith(".transactions/staging/", StringComparison.Ordinal) => "Unclassified staging artifact; retirement protocol absent",
                    var p when p.StartsWith(".transactions/", StringComparison.Ordinal) => "Coordinator identity, selector or unclassified transaction artifact",
                    _ => "Original base and older-reader compatibility dependency",
                };
                var comparison = OperatingSystem.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;
                if (path.StartsWith(visibleRoot + Path.DirectorySeparatorChar, comparison) &&
                    !relative.StartsWith(".transactions/", StringComparison.Ordinal) ||
                    visibleRoot != root && path.StartsWith(visibleRoot + Path.DirectorySeparatorChar, comparison))
                    reason += "; selected live root";
                files.Add(new(relative, reason));
            }
        }
    }
}
