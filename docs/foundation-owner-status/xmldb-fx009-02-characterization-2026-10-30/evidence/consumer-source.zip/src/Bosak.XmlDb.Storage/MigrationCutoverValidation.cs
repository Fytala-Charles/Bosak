// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Validates frozen source and initial candidate commitments without recovery or persistence.
// SPECIAL NOTES        : Internal prototype acceptance only; no persistent fence, routing service or retirement.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      | Charles Korthout | 0.2   | 29-10-2026     | Share strict read-only frozen source closure validation with enrollment
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

internal static class MigrationCutoverValidation
{
    internal static void Validate(LegacyCutoverState source, EpochCutoverState candidate, FrozenMigrationCapture capture, EpochMigrationResult result)
    {
        var inventoryBytes = capture.InventoryBytes;
        var inventory = LegacyMigrationVerifier.ReadArtifact(capture.Artifact);
        if (!BinaryEnvelope.ReadFile(Path.Combine(capture.Artifact, "inventory.bin")).AsSpan().SequenceEqual(inventoryBytes)) Fail("Captured artifact identity changed.");
        LegacyMigrationVerifier.ValidateHistory(Path.Combine(capture.Artifact, "data"), inventory);
        if (source.DocumentId != inventory.Identity.DocumentId || source.Sequence != inventory.Identity.CommitSequence || !Same(source.ManifestHash, inventory.HeadHash))
            Fail("Source owner no longer selects the captured prefix.");
        var root = Path.GetFullPath(result.StorePath); var bundle = Path.GetDirectoryName(root)!;
        if (!SamePath(candidate.Root, root) || Path.GetFileName(root) != "store" || result.Destination != candidate.Binding.Identity ||
            result.BackupId != inventory.Identity.BackupId || result.CommitSequence != inventory.Identity.CommitSequence ||
            candidate.Head.Sequence != inventory.Identity.CommitSequence) Fail("Candidate owner/result is not the initial migrated prefix.");
        Disjoint(source.Root, capture.Artifact); Disjoint(source.Root, bundle); Disjoint(capture.Artifact, bundle);
        ValidateSource(source.Root, inventory);
        var roles = Directory.GetFileSystemEntries(bundle); foreach (var role in roles) BinaryEnvelope.RejectLinks(role);
        if (roles.Length != 2 || !roles.Select(Path.GetFileName).Order(StringComparer.Ordinal).SequenceEqual(new[] { "migration.bin", "store" }) ||
            !File.Exists(Path.Combine(bundle, "migration.bin")) || !Directory.Exists(root)) Fail("Invalid candidate bundle roles.");
        var originBytes = BinaryEnvelope.ReadFile(Path.Combine(bundle, "migration.bin")); var data = Path.Combine(capture.Artifact, "data");
        var format = BinaryEnvelope.ReadFile(Path.Combine(root, "FORMAT"));
        var origin = EpochMigrationCodec.ValidateHeaders(originBytes, inventoryBytes, BinaryEnvelope.ReadFile(Path.Combine(capture.Artifact, "COMPLETE")),
            BinaryEnvelope.ReadFile(Path.Combine(data, "FORMAT")), BinaryEnvelope.ReadFile(Path.Combine(data, ".transactions", "CONTROL")),
            inventory.Identity.CommitSequence == 0 ? null : BinaryEnvelope.ReadFile(Path.Combine(data, ".transactions", "CURRENT")),
            format, BinaryEnvelope.ReadFile(Path.Combine(root, ".transactions", "CURRENT")));
        if (origin.MigrationId != result.MigrationId || origin.Destination != result.Destination) Fail("Candidate provenance differs from the selected operation.");
        var binding = EpochEmptyCoordinator.ReadAuthority(root, origin.Destination, true);
        if (!Same(binding.FormatHash, candidate.Binding.FormatHash) || !Same(binding.BaseHash, candidate.Binding.BaseHash)) Fail("Candidate authority changed under its owner.");
        EpochCodec.ValidateBinding(BinaryEnvelope.ReadFile(Path.Combine(root, ".epoch", "admission.lease")), "BXEA", origin.Destination, format);
        var names = EpochBackupStorage.FileSet(root, origin.Destination.DocumentId, origin.CommitSequence);
        EpochBackupStorage.ValidateSourceLayout(root, names);
        if (Directory.EnumerateFileSystemEntries(Path.Combine(root, ".transactions", "staging")).Any() ||
            Directory.EnumerateFileSystemEntries(Path.Combine(root, ".transactions")).Any(path => EpochScalarHistory.IsCurrentTemporary(Path.GetFileName(path))))
            Fail("Candidate contains unpublished work.");
        var readers = Directory.GetFileSystemEntries(Path.Combine(root, ".transactions", "readers")).Select(Path.GetFileName).Order(StringComparer.Ordinal);
        if (!readers.SequenceEqual(Enumerable.Range(0, checked((int)origin.CommitSequence + 1)).Select(n => EpochAuthorityCodec.ReaderFileName((ulong)n))))
            Fail("Candidate initial reader set changed.");
        foreach (var file in inventory.Files.Where(file => EpochBackupRestore.IsDocumentData(file.Path))) _ = EpochBackupRestore.ReadBound(root, file);
        var previous = new byte[32];
        for (ulong sequence = 1; sequence <= origin.CommitSequence; sequence++)
        {
            var name = ".transactions/wal/" + EpochAuthorityCodec.WalFileName(sequence);
            var old = TransactionCodec.ReadWal(Path.Combine(data, name)) ?? throw new InvalidDataException("Captured WAL became incomplete.");
            var expected = EpochAuthorityCodec.EncodeWal(new(binding, old.Sequence, old.TransactionId, old.NodeId, old.Value, old.PreviousManifestHash, old.ManifestHash, previous));
            var actual = BinaryEnvelope.ReadFile(Path.Combine(root, name));
            if (!actual.AsSpan().SequenceEqual(expected)) Fail("Candidate operation differs from captured source.");
            previous = SHA256.HashData(actual);
            var gen = Path.Combine(root, ".transactions", "generations", EpochAuthorityCodec.GenerationName(sequence));
            if (!BinaryEnvelope.ReadFile(Path.Combine(gen, "FORMAT")).AsSpan().SequenceEqual(format) ||
                !BinaryEnvelope.ReadFile(Path.Combine(gen, "GENERATION")).AsSpan().SequenceEqual(EpochAuthorityCodec.EncodeGeneration(new(binding, sequence, old.PreviousManifestHash, old.ManifestHash, previous))))
                Fail("Candidate generation differs from captured source transformation.");
        }
        var head = EpochScalarHistory.Validate(root, candidate.Admission, binding);
        if (head.Sequence != origin.CommitSequence || !Same(head.ManifestHash, inventory.HeadHash) || !Same(head.WalHash, previous) ||
            !Same(candidate.Head.ManifestHash, head.ManifestHash) || !Same(candidate.Head.WalHash, head.WalHash)) Fail("Candidate head changed.");
    }

    internal static void ValidateSource(string root, BackupInventory inventory)
    {
        var names = inventory.Files.Select(file => file.Path).ToArray();
        if (!BackupStorage.FileSet(root, inventory.Identity.DocumentId, inventory.Identity.CommitSequence).SequenceEqual(names)) Fail("Source data closure changed.");
        var files = names.ToHashSet(StringComparer.Ordinal); var directories = new HashSet<string>(StringComparer.Ordinal);
        foreach (var name in names)
            for (var slash = name.IndexOf('/'); slash >= 0; slash = name.IndexOf('/', slash + 1)) directories.Add(name[..slash]);
        foreach (var name in new[] { ".transactions/wal", ".transactions/generations", ".transactions/staging", ".transactions/readers", ".transactions/checkpoints", ".transactions/anchors" }) directories.Add(name);
        foreach (var (name, directory) in EpochBackupStorage.Walk(root))
        {
            if (directory ? directories.Contains(name) : files.Contains(name)) continue;
            if (name == ".transactions/CURRENT" && inventory.Identity.CommitSequence == 0 && !directory) continue;
            if (!directory && name is ".transactions/writer.lock" or ".transactions/CHECKPOINT") continue;
            if (new[] { ".transactions/staging/", ".transactions/readers/", ".transactions/checkpoints/", ".transactions/anchors/" }.Any(prefix => name.StartsWith(prefix, StringComparison.Ordinal))) continue;
            if (!directory && name.StartsWith(".transactions/", StringComparison.Ordinal) && name.Count(c => c == '/') == 1 && name.EndsWith(".tmp", StringComparison.Ordinal)) continue;
            Fail("Unknown source dependency or unrecorded committed file.");
        }
        foreach (var file in inventory.Files) _ = EpochBackupRestore.ReadBound(root, file);
        if (inventory.Identity.CommitSequence > 0) LegacyMigrationVerifier.ValidateHistory(root, inventory);
        else
        {
            var current = Path.Combine(root, ".transactions", "CURRENT");
            if (File.Exists(current) && !BinaryEnvelope.ReadFile(current).AsSpan().SequenceEqual(TransactionCodec.EncodePointer(new(inventory.Identity.DocumentId, 0, inventory.BaseHash), "BXHD")))
                Fail("Live zero-head CURRENT is invalid.");
        }
    }
    private static void Disjoint(string a, string b)
    {
        BinaryEnvelope.RejectLinks(a); BinaryEnvelope.RejectLinks(b);
        a = Path.TrimEndingDirectorySeparator(Path.GetFullPath(a)); b = Path.TrimEndingDirectorySeparator(Path.GetFullPath(b));
        if (a.Equals(b, StringComparison.OrdinalIgnoreCase) || a.StartsWith(b + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) || b.StartsWith(a + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            Fail("Source, artifact and candidate bundle must be separate roots.");
    }
    private static bool SamePath(string a, string b) => Path.GetFullPath(a).Equals(Path.GetFullPath(b), OperatingSystem.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal);
    private static bool Same(byte[] a, byte[] b) => a.AsSpan().SequenceEqual(b);
    private static void Fail(string message) => throw new InvalidDataException(message);
}
