// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Recovers admitted epoch scalar histories from validated WAL and publication witnesses.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Buffers.Binary;
using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

internal static class EpochScalarRecovery
{
    // Preflight all authority and existing materializations before performing recovery writes.
    internal static EpochVerifiedHead Recover(string root, EpochAdmissionLease admission, EpochAuthorityBinding binding,
        ITransactionStorage storage, Action<EpochScalarStage>? checkpoint)
    {
        var paths = Directory.GetFileSystemEntries(Path.Combine(root, ".transactions", "wal"));
        if (paths.Length > 10_000) throw new InvalidDataException("Epoch journal limit exceeded.");
        Array.Sort(paths, StringComparer.Ordinal);
        var records = new List<(EpochWalRecord Record, byte[] Digest)>();
        var heads = new Dictionary<ulong, EpochVerifiedHead> { [0] = new(0, binding.BaseHash, new byte[32]) };
        var ids = new HashSet<Guid>(); string? tail = null;
        var head = heads[0];
        using var original = EpochScalarHistory.Open(root, 0, admission, binding.BaseHash);
        var values = new Dictionary<ulong, string>();
        for (var index = 0; index < paths.Length; index++)
        {
            var path = paths[index]; BinaryEnvelope.RejectLinks(path);
            var sequence = (ulong)index + 1;
            if (Directory.Exists(path) || EpochAuthorityCodec.ParseWalName(Path.GetFileName(path)) != sequence)
                throw new InvalidDataException("Missing or noncanonical epoch WAL.");
            var bytes = ReadWal(path);
            if (bytes is null)
            {
                if (index != paths.Length - 1) throw new InvalidDataException("Incomplete WAL precedes later history.");
                RequireTailBinding(path, binding, sequence);
                tail = path; break;
            }
            var record = EpochAuthorityCodec.DecodeWal(bytes, binding);
            if (record.Sequence != sequence || !ids.Add(record.TransactionId) ||
                !record.PreviousManifestHash.AsSpan().SequenceEqual(head.ManifestHash) || !record.PreviousWalHash.AsSpan().SequenceEqual(head.WalHash))
                throw new InvalidDataException("Broken epoch WAL chain.");
            try { ScalarGeneration.ValidateReplacement(original, record.NodeId, record.Value); }
            catch (Exception exception) when (exception is ArgumentException or NotSupportedException or System.Xml.XmlException)
            { throw new InvalidDataException("Invalid epoch scalar operation.", exception); }
            var digest = SHA256.HashData(bytes); records.Add((record, digest));
            head = new(sequence, record.ManifestHash, digest); heads.Add(sequence, head);
            values[record.NodeId] = record.Value;
            var data = EpochScalarHistory.Generation(root, sequence);
            if (Directory.Exists(data))
            {
                BinaryEnvelope.RejectLinks(data);
                var witness = EpochAuthorityCodec.DecodeGeneration(BinaryEnvelope.ReadFile(Path.Combine(data, "GENERATION")), binding);
                if (witness.Sequence != sequence || !witness.WalHash.AsSpan().SequenceEqual(digest) ||
                    !witness.ManifestHash.AsSpan().SequenceEqual(record.ManifestHash) || !witness.PreviousManifestHash.AsSpan().SequenceEqual(record.PreviousManifestHash))
                    throw new InvalidDataException("Generation does not bind its WAL.");
                EpochScalarHistory.ValidateFiles(data, binding.Identity.DocumentId, record.ManifestHash);
                using var current = EpochScalarHistory.Open(root, sequence, admission, record.ManifestHash);
                ValidateProjection(original, current, values);
            }
        }
        foreach (var path in Directory.EnumerateFileSystemEntries(Path.Combine(root, ".transactions", "generations")))
        {
            BinaryEnvelope.RejectLinks(path);
            if (!Directory.Exists(path) || !heads.ContainsKey(EpochAuthorityCodec.ParseGenerationName(Path.GetFileName(path))))
                throw new InvalidDataException("Published generation has no intact WAL witness.");
        }
        var currentPath = Path.Combine(root, ".transactions", "CURRENT");
        EpochCurrentRecord? currentRecord = null;
        if (File.Exists(currentPath))
        {
            currentRecord = EpochAuthorityCodec.DecodeCurrent(BinaryEnvelope.ReadFile(currentPath), binding);
            if (!heads.TryGetValue(currentRecord.Sequence, out var selected) || !currentRecord.ManifestHash.AsSpan().SequenceEqual(selected.ManifestHash) ||
                !currentRecord.WalHash.AsSpan().SequenceEqual(selected.WalHash)) throw new InvalidDataException("CURRENT is not a verified WAL prefix.");
        }
        EpochGenerationReader.ValidateDirectory(root, binding, heads.ToDictionary(pair => pair.Key, pair => pair.Value.ManifestHash));
        // No CURRENT/generation/reader witness may refer to a physically incomplete final append.
        if (tail is not null)
        {
            storage.DeleteFile(tail); storage.SyncDirectory(Path.GetDirectoryName(tail)!);
            checkpoint?.Invoke(EpochScalarStage.TailDiscarded);
        }
        foreach (var (record, digest) in records)
        {
            var data = EpochScalarHistory.Generation(root, record.Sequence);
            if (Directory.Exists(data)) continue;
            var walPath = Path.Combine(root, ".transactions", "wal", EpochAuthorityCodec.WalFileName(record.Sequence));
            storage.SyncFile(walPath); storage.SyncDirectory(Path.GetDirectoryName(walPath)!);
            using var previous = EpochScalarHistory.Open(root, record.Sequence - 1, admission, record.PreviousManifestHash);
            var staging = Path.Combine(root, ".transactions", "staging", Guid.NewGuid().ToString("N"));
            var hash = ScalarGeneration.BuildEpochMaterialization(previous.MaterializationRoot, staging, previous, record.NodeId, record.Value, null, storage);
            if (!hash.AsSpan().SequenceEqual(record.ManifestHash)) throw new InvalidDataException("Redo does not reproduce recorded manifest identity.");
            TransactionCodec.WriteFlushed(Path.Combine(staging, "GENERATION"), EpochAuthorityCodec.EncodeGeneration(
                new(binding, record.Sequence, record.PreviousManifestHash, hash, digest)), storage);
            EpochScalarHistory.ValidateFiles(staging, binding.Identity.DocumentId, hash);
            using (var staged = ImmutableXmlSnapshot.OpenMutableEpochStaging(root, staging, record.Sequence, admission.ForkShared(), hash))
                EpochScalarHistory.ValidateTransition(previous, staged, record.NodeId, record.Value);
            checkpoint?.Invoke(EpochScalarStage.RecoveryStageWritten);
            TransactionCodec.PublishGeneration(staging, data, storage);
            checkpoint?.Invoke(EpochScalarStage.RecoveryGenerationPublished);
            EpochGenerationReader.Ensure(root, binding, record.Sequence, hash, storage);
        }
        var verified = EpochScalarHistory.Validate(root, admission, binding);
        if (currentRecord is null || currentRecord.Sequence != verified.Sequence)
        {
            var temporary = Path.Combine(root, ".transactions", "current-" + Guid.NewGuid().ToString("N") + ".tmp");
            TransactionCodec.WriteFlushed(temporary, EpochAuthorityCodec.EncodeCurrent(new(binding, verified.Sequence, verified.ManifestHash, verified.WalHash)), storage);
            TransactionCodec.PublishFile(temporary, currentPath, true, storage);
            checkpoint?.Invoke(EpochScalarStage.RecoveryCurrentPublished);
        }
        return verified;
    }

    // Null means physically incomplete supported framing, never a bad complete checksum/header.
    internal static byte[]? ReadWal(string path)
    {
        BinaryEnvelope.RejectLinks(path);
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        if (stream.Length > BinaryEnvelope.MaximumFileBytes) throw new InvalidDataException("Oversized epoch WAL.");
        var bytes = new byte[(int)stream.Length]; stream.ReadExactly(bytes);
        ReadOnlySpan<byte> prefix = [66, 88, 69, 87, 1, 0, 0, 0]; // BXEW, envelope 1.0
        if (!bytes.AsSpan(0, Math.Min(bytes.Length, 8)).SequenceEqual(prefix[..Math.Min(bytes.Length, 8)]))
            throw new InvalidDataException("Invalid epoch WAL framing.");
        if (bytes.Length < 12) return null;
        var length = BinaryPrimitives.ReadInt32LittleEndian(bytes.AsSpan(8));
        if (length < 237 || length > 237 + BinaryEnvelope.MaximumStringBytes) throw new InvalidDataException("Invalid epoch WAL body bound.");
        return bytes.Length < length + 44 ? null : bytes;
    }

    private static void RequireTailBinding(string path, EpochAuthorityBinding binding, ulong sequence)
    {
        // Validate every available binding/role/sequence byte, even when the envelope is torn.
        var expected = EpochAuthorityCodec.EncodeWal(new(binding, sequence, Guid.NewGuid(), 1, "x", binding.BaseHash, binding.BaseHash, new byte[32]));
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        var count = (int)Math.Min(113, Math.Max(0, stream.Length - 12));
        var actual = new byte[count]; stream.Position = 12; stream.ReadExactly(actual);
        if (!actual.AsSpan().SequenceEqual(expected.AsSpan(12, count))) throw new InvalidDataException("Incomplete WAL has a foreign binding, role or sequence.");
    }

    private static void ValidateProjection(ImmutableXmlSnapshot original, ImmutableXmlSnapshot current, Dictionary<ulong, string> values)
    {
        if (original.NodeCount != current.NodeCount || original.DocumentUri != current.DocumentUri) throw new InvalidDataException("Scalar history changed document structure.");
        for (ulong id = 1; id <= (ulong)current.NodeCount; id++)
        {
            var a = original.GetNode(id); var b = current.GetNode(id);
            if (a with { ValueOffset = b.ValueOffset, ValueLength = b.ValueLength, Children = b.Children, Attributes = b.Attributes, Namespaces = b.Namespaces } != b ||
                !a.Children.SequenceEqual(b.Children) || !a.Attributes.SequenceEqual(b.Attributes) || !a.Namespaces.SequenceEqual(b.Namespaces) ||
                current.ReadValue(id) != (values.TryGetValue(id, out var value) ? value : original.ReadValue(id)))
                throw new InvalidDataException("Published generation differs from logical WAL history.");
        }
    }
}
