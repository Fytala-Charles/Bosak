// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Provisions separate authority roles and retains a live initializer reservation.
// SPECIAL NOTES        : ProcessCrash only; no enrollment append or application writer admission.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 30-10-2026     | Transfer optional lifetime-only role closer with actual provisioned owner                |
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal enum ApplicationProvisionStage { PreflightValidated, RootCreated, OwnerCreated, OwnerFlushed, MetadataCreated, MetadataWritten, MetadataFlushed, JournalCreated, JournalFlushed, BeforeReturn }
internal sealed record ApplicationProvisionEvidence(string Root, bool Fresh, bool ControlledProvisionersOnly, bool NoPriorAuthority);

internal sealed partial class ApplicationAuthorityLifetime
{
    internal static ApplicationAuthorityLifetime Provision(EmbeddedHostLifetime parent, HostJournalPosition expected,
        EmbeddedHostInspectionEvidence inspection, string root, ApplicationAuthorityConfiguration configuration,
        IReadOnlyDictionary<string, string> roots, ApplicationProvisionEvidence evidence) =>
        ProvisionCore(parent, expected, inspection, root, configuration, roots, evidence, new LocalTransactionStorage(), null);

    internal static ApplicationAuthorityLifetime ProvisionCore(EmbeddedHostLifetime parent, HostJournalPosition expected,
        EmbeddedHostInspectionEvidence inspection, string root, ApplicationAuthorityConfiguration configuration,
        IReadOnlyDictionary<string, string> roots, ApplicationProvisionEvidence evidence, ITransactionStorage storage,
        Action<ApplicationProvisionStage>? checkpoint, IRetainedRoleLeaseClose? roleClose = null)
    {
        ArgumentNullException.ThrowIfNull(parent); ArgumentNullException.ThrowIfNull(evidence); ArgumentNullException.ThrowIfNull(storage);
        ApplicationAuthorityFileIdentity.RequirePlatform();
        var bytes = ApplicationAuthorityCodec.EncodeMetadata(configuration); root = Canonical(root);
        if (storage.Durability != DurabilityMode.ProcessCrash || configuration.Durability != DurabilityMode.ProcessCrash)
            throw new NotSupportedException("Authority provisioning supports ProcessCrash only.");
        if (configuration.AdministrativeJournalId != parent.Context.JournalId || configuration.Deployment != parent.Context.Deployment || configuration.ResourceScope != parent.Context.ResourceScope)
            throw new InvalidDataException("Authority configuration must bind the actual administrative host.");
        var inventory = FreezeRoots(roots);
        if (!inventory.TryGetValue(configuration.AdministrativeRootKey, out var administrative) || administrative != parent.Root ||
            !inventory.TryGetValue(configuration.AuthorityRootKey, out var authority) || authority != root)
            throw new InvalidDataException("Provisioning requires exact parent and authority mappings.");
        if (evidence.Root != root || !evidence.Fresh || !evidence.ControlledProvisionersOnly || !evidence.NoPriorAuthority)
            throw new InvalidOperationException("Explicit fresh controlled-scope evidence of no prior authority is required.");
        var registration = parent.BeginApplicationInspection(expected, inspection);
        var handles = new List<FileStream>();
        try
        {
            RequireAbsent(root);
            var directory = Path.GetDirectoryName(root) ?? throw new InvalidDataException("Authority requires an existing parent.");
            _ = ApplicationAuthorityFileIdentity.PathIdentity(directory, true);
            // Validate planned placement before creating anything. Shared physical ancestors carry
            // relative suffixes so aliases cannot hide overlap between two not-yet-existing paths.
            CheckPlannedPlacement(parent.Root, root, configuration, inventory, registration.History);
            checkpoint?.Invoke(ApplicationProvisionStage.PreflightValidated); registration.RequireCurrent(parent); RequireAbsent(root);
            storage.CreateDirectory(root); checkpoint?.Invoke(ApplicationProvisionStage.RootCreated);
            _ = ApplicationAuthorityFileIdentity.PathIdentity(root, true);
            if (Directory.EnumerateFileSystemEntries(root).Take(1).Any()) throw new IOException("Occupied authority root is retained.");
            CheckPlacement(parent.Root, root, configuration, inventory, registration.History);
            handles.Add(new(Path.Combine(root, RoleNames[0]), FileMode.CreateNew, FileAccess.ReadWrite, FileShare.None, 1));
            var rootIdentity = ApplicationAuthorityFileIdentity.PathIdentity(root, true);
            var ownerIdentity = ApplicationAuthorityFileIdentity.HandleIdentity(handles[0]);
            checkpoint?.Invoke(ApplicationProvisionStage.OwnerCreated);
            handles[0].Flush(true); storage.SyncDirectory(root); checkpoint?.Invoke(ApplicationProvisionStage.OwnerFlushed);
            using (var output = storage.CreateFile(Path.Combine(root, RoleNames[1])))
            {
                checkpoint?.Invoke(ApplicationProvisionStage.MetadataCreated); output.Write(bytes); checkpoint?.Invoke(ApplicationProvisionStage.MetadataWritten);
                output.FlushToDisk(); checkpoint?.Invoke(ApplicationProvisionStage.MetadataFlushed);
            }
            storage.SyncDirectory(root);
            using (var output = storage.CreateFile(Path.Combine(root, RoleNames[2])))
            {
                checkpoint?.Invoke(ApplicationProvisionStage.JournalCreated); output.FlushToDisk(); checkpoint?.Invoke(ApplicationProvisionStage.JournalFlushed);
            }
            storage.SyncDirectory(root); storage.SyncDirectory(directory);
            handles.Add(new(Path.Combine(root, RoleNames[1]), FileMode.Open, FileAccess.ReadWrite, FileShare.Read, 1));
            handles.Add(new(Path.Combine(root, RoleNames[2]), FileMode.Open, FileAccess.ReadWrite, FileShare.Read, 1));
            var roles = handles.ToArray(); var identities = roles.Select(role => ApplicationAuthorityFileIdentity.HandleIdentity(role)).ToArray();
            checkpoint?.Invoke(ApplicationProvisionStage.BeforeReturn);
            registration.RequireCurrent(parent);
            var read = ReadOwned(root, rootIdentity, roles, identities, configuration, inventory, parent.Root, registration.History);
            if (read.Length != 0 || identities[0] != ownerIdentity) throw new InvalidDataException("Provisioned authority changed before handoff.");
            registration.RequireCurrent(parent);
            return new(parent, registration, root, configuration, inventory, roles, identities, rootIdentity, read.History, read.Length, read.Digest, provisioned: true, roleClose: roleClose);
        }
        catch (Exception primary)
        {
            var errors = CloseRoles(handles);
            if (errors.Count == 0) registration.Dispose();
            if (errors.Count != 0) throw new AggregateException("Provisioning release is unconfirmed; parent remains held.", new[] { primary }.Concat(errors));
            // Retain all partial roles. Neither retry nor a clean empty reopen recreates initialization authority.
            throw;
        }
    }

    internal IDisposable ReserveInitializer()
    {
        IDisposable operation;
        lock (_gate)
        {
            if (!_provisioned || _initializerClaimed) throw new InvalidOperationException("Only the successful live initializer can reserve once.");
            operation = BeginRead(); _initializerClaimed = true;
        }
        try
        {
            lock (_readGate)
            {
                var read = ReadOwned(Root, _rootIdentity, _roles, _identities, _configuration, _roots, _parent.Root, _registration.History);
                if (read.Length != 0 || read.Digest != _digest) throw new InvalidDataException("Initializer requires unchanged empty authority.");
                _registration.RequireCurrent(_parent);
            }
            return operation;
        }
        catch { lock (_gate) _faulted = true; operation.Dispose(); throw; }
    }
    private static void RequireAbsent(string root)
    {
        try { _ = File.GetAttributes(root); }
        catch (Exception error) when (error is FileNotFoundException or DirectoryNotFoundException) { return; }
        throw new IOException("Existing authority paths cannot be provisioned, resumed or repaired.");
    }
    private static void CheckPlannedPlacement(string parent, string root, ApplicationAuthorityConfiguration configuration,
        System.Collections.Immutable.ImmutableDictionary<string, string> roots, HostJournalReadResult history)
    {
        var cache = new Dictionary<string, ApplicationFileIdentity>(StringComparer.Ordinal);
        var authorityAncestors = PlannedAncestors(root, cache);
        var paths = new HashSet<string>(StringComparer.Ordinal) { parent };
        foreach (var pair in roots) if (pair.Key != configuration.AuthorityRootKey) paths.Add(pair.Value);
        foreach (var frame in history.Frames)
        {
            paths.Add(Canonical(frame.Snapshot.Context.Intent.ArtifactRoot)); paths.Add(Canonical(frame.Snapshot.Context.Intent.BundleRoot));
            if (paths.Count > 4096) throw new InvalidDataException("Protected inventory exceeds bound.");
        }
        foreach (var path in paths)
        {
            if (Contains(root, path) || Contains(path, root)) throw new InvalidDataException("Authority and protected roots overlap.");
            foreach (var other in PlannedAncestors(path, cache))
                foreach (var own in authorityAncestors)
                    if (own.Identity == other.Identity && (own.Suffix.Length == 0 || other.Suffix.Length == 0 || Contains(own.Suffix, other.Suffix) || Contains(other.Suffix, own.Suffix)))
                        throw new InvalidDataException("Physical planned authority/protected roots overlap.");
        }
    }
    private static List<(ApplicationFileIdentity Identity, string Suffix)> PlannedAncestors(string path, Dictionary<string, ApplicationFileIdentity> cache)
    {
        _ = Ancestors(path, cache);
        var result = new List<(ApplicationFileIdentity Identity, string Suffix)>();
        for (var current = path; current is not null; current = Path.GetDirectoryName(current))
            if (cache.TryGetValue(current, out var identity))
            {
                var suffix = Path.GetRelativePath(current, path);
                result.Add((identity, suffix == "." ? "" : suffix));
            }
        return result;
    }
}
