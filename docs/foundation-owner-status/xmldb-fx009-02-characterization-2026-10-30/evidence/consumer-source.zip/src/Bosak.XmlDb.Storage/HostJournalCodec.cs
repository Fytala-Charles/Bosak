// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Encodes and strictly decodes bounded host-only journal metadata and frames.
// SPECIAL NOTES        : Internal pure codec; structural replay never proves durability, freshness or dispatch authority.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Buffers.Binary;
using System.Diagnostics.CodeAnalysis;
using System.Security.Cryptography;
using System.Text;

namespace Bosak.XmlDb.Storage;

internal enum HostJournalEvent { RecordIntent, AuthorizeDispatch, MarkUncertain, Acknowledge, ObserveKnown, ReconcileAbsent, TransferOwner }
internal sealed record HostJournalMetadata(Guid JournalId, string ScopeDigest);
internal sealed record HostJournalFrame(Guid JournalId, ulong Sequence, string PreviousDigest, HostJournalEvent Event, HostLedgerSnapshot Snapshot, string Digest);
internal sealed record HostJournalReadResult(IReadOnlyList<HostJournalFrame> Frames)
{
    internal bool WritersMustRemainStopped => true;
}

internal static partial class HostJournalCodec
{
    internal const int MaximumPayloadBytes = 1_048_576;
    internal const int MaximumJournalBytes = 67_108_864;
    internal const int MaximumFrames = 65_536;
    internal const int MaximumAttempts = 1_024;
    internal const int MaximumStringBytes = 4_096;
    private static readonly UTF8Encoding Utf8 = new(false, true);
    private static readonly string ZeroHash = new('0', 64);

    internal static byte[] EncodeMetadata(Guid journalId, string deployment, string scope)
    {
        Require(journalId != Guid.Empty);
        var bytes = new byte[88]; "BXHM0001"u8.CopyTo(bytes); GuidBytes(journalId).CopyTo(bytes, 8);
        Convert.FromHexString(ScopeDigest(deployment, scope)).CopyTo(bytes, 24);
        SHA256.HashData(bytes.AsSpan(0, 56), bytes.AsSpan(56)); return bytes;
    }
    internal static HostJournalMetadata DecodeMetadata(ReadOnlySpan<byte> bytes, string deployment, string scope)
    {
        Require(bytes.Length == 88 && bytes[..8].SequenceEqual("BXHM0001"u8));
        Require(CryptographicOperations.FixedTimeEquals(SHA256.HashData(bytes[..56]), bytes[56..]));
        var id = ReadGuid(bytes.Slice(8, 16)); var digest = Hex(bytes.Slice(24, 32));
        Require(digest == ScopeDigest(deployment, scope)); return new(id, digest);
    }
    internal static string ScopeDigest(string deployment, string scope) => Hex(SHA256.HashData(Tlv((1, Text(deployment)), (2, Text(scope)))));

    internal static byte[] EncodeFrame(Guid journalId, ulong sequence, string previousDigest, HostJournalEvent kind, HostLedgerSnapshot snapshot)
    {
        Require(journalId != Guid.Empty && sequence is > 0 and <= MaximumFrames);
        var previous = Hash(previousDigest); Require(sequence != 1 || previousDigest == ZeroHash);
        var payload = EncodePayload(kind, snapshot); Require(payload.Length is > 0 and <= MaximumPayloadBytes);
        var bytes = new byte[112 + payload.Length]; "BXHJ0001"u8.CopyTo(bytes);
        BinaryPrimitives.WriteUInt16LittleEndian(bytes.AsSpan(8), 1);
        BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(12), (uint)payload.Length);
        BinaryPrimitives.WriteUInt64LittleEndian(bytes.AsSpan(16), sequence); GuidBytes(journalId).CopyTo(bytes, 24); previous.CopyTo(bytes, 40);
        payload.CopyTo(bytes, 72); SHA256.HashData(bytes.AsSpan(0, 72 + payload.Length), bytes.AsSpan(72 + payload.Length, 32));
        "HJEND001"u8.CopyTo(bytes.AsSpan(104 + payload.Length)); return bytes;
    }
    internal static HostJournalFrame DecodeFrame(ReadOnlySpan<byte> bytes)
    {
        Require(bytes.Length >= 112 && bytes.Length <= MaximumPayloadBytes + 112);
        Require(bytes[..8].SequenceEqual("BXHJ0001"u8) && BinaryPrimitives.ReadUInt16LittleEndian(bytes[8..]) == 1 && BinaryPrimitives.ReadUInt16LittleEndian(bytes[10..]) == 0);
        var length = BinaryPrimitives.ReadUInt32LittleEndian(bytes[12..]);
        Require(length is > 0 and <= MaximumPayloadBytes && bytes.Length == 112L + length);
        var n = (int)length; Require(bytes[(104 + n)..].SequenceEqual("HJEND001"u8));
        Require(CryptographicOperations.FixedTimeEquals(SHA256.HashData(bytes[..(72 + n)]), bytes.Slice(72 + n, 32)));
        var sequence = BinaryPrimitives.ReadUInt64LittleEndian(bytes[16..]); Require(sequence is > 0 and <= MaximumFrames);
        var previous = Hex(bytes.Slice(40, 32)); Require(sequence != 1 || previous == ZeroHash);
        var (kind, snapshot) = DecodePayload(bytes.Slice(72, n));
        return new(ReadGuid(bytes.Slice(24, 16)), sequence, previous, kind, snapshot, Hex(bytes.Slice(72 + n, 32)));
    }

    private static byte[] Tlv(params (ushort Tag, byte[]? Value)[] fields)
    {
        var size = 0; ushort prior = 0;
        foreach (var (tag, value) in fields)
        {
            Require(tag > prior); prior = tag; if (value is null) continue;
            Require(value.Length > 0 && value.Length <= MaximumPayloadBytes - 6 && size <= MaximumPayloadBytes - value.Length - 6); size += 6 + value.Length;
        }
        var bytes = new byte[size]; var cursor = 0;
        foreach (var (tag, value) in fields)
        {
            if (value is null) continue;
            BinaryPrimitives.WriteUInt16LittleEndian(bytes.AsSpan(cursor), tag); BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(cursor + 2), (uint)value.Length);
            value.CopyTo(bytes, cursor + 6); cursor += value.Length + 6;
        }
        return bytes;
    }
    private ref struct Fields(ReadOnlySpan<byte> bytes)
    {
        private ReadOnlySpan<byte> _remaining = bytes;
        internal ReadOnlySpan<byte> Take(ushort tag, bool optional = false)
        {
            if (_remaining.IsEmpty && optional) return [];
            Require(_remaining.Length >= 6); var actual = BinaryPrimitives.ReadUInt16LittleEndian(_remaining);
            if (optional && actual > tag) return [];
            Require(actual == tag); var length = BinaryPrimitives.ReadUInt32LittleEndian(_remaining[2..]);
            Require(length > 0 && length <= _remaining.Length - 6); var value = _remaining.Slice(6, (int)length); _remaining = _remaining[(6 + (int)length)..]; return value;
        }
        internal void End() => Require(_remaining.IsEmpty);
    }
    private static byte[] Text(string value)
    {
        Require(!string.IsNullOrWhiteSpace(value) && value.Length <= MaximumStringBytes && !value.Contains('\0') && !value.Contains('\uFEFF'));
        try { Require(Utf8.GetByteCount(value) <= MaximumStringBytes); return Utf8.GetBytes(value); }
        catch (EncoderFallbackException error) { throw new InvalidDataException("Invalid host journal UTF-8 input.", error); }
    }
    private static string ReadText(ReadOnlySpan<byte> bytes)
    {
        Require(bytes.Length is > 0 and <= MaximumStringBytes);
        try { var text = Utf8.GetString(bytes); _ = Text(text); return text; }
        catch (DecoderFallbackException error) { throw new InvalidDataException("Invalid host journal UTF-8 bytes.", error); }
    }
    private static byte[] U64(ulong value) { var bytes = new byte[8]; BinaryPrimitives.WriteUInt64LittleEndian(bytes, value); return bytes; }
    private static ulong ReadU64(ReadOnlySpan<byte> bytes) { Require(bytes.Length == 8); return BinaryPrimitives.ReadUInt64LittleEndian(bytes); }
    private static byte[] GuidBytes(Guid value) { Require(value != Guid.Empty); var bytes = new byte[16]; value.TryWriteBytes(bytes, bigEndian: true, out _); return bytes; }
    private static Guid ReadGuid(ReadOnlySpan<byte> bytes) { Require(bytes.Length == 16); var value = new Guid(bytes, bigEndian: true); Require(value != Guid.Empty); return value; }
    private static byte[] Hash(string value) { Require(value is { Length: 64 } && value.All(c => c is >= '0' and <= '9' or >= 'a' and <= 'f')); return Convert.FromHexString(value); }
    private static string Hex(ReadOnlySpan<byte> bytes) => Convert.ToHexString(bytes).ToLowerInvariant();
    private static byte ReadByte(ReadOnlySpan<byte> bytes) { Require(bytes.Length == 1); return bytes[0]; }
    private static byte[] One(byte value) => [value];
    private static void Require([DoesNotReturnIf(false)] bool valid) { if (!valid) throw new InvalidDataException("Invalid bounded host journal bytes or state."); }
}
