// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Encodes canonical application-authority payloads with explicit wire mappings.
// SPECIAL NOTES        : Pure internal codec; checksums and decoded state grant no ownership, freshness or write authority.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

/// <summary>Encodes canonical application-authority payloads with explicit wire mappings.</summary>
internal static partial class ApplicationAuthorityCodec
{
    private static byte[] EncodePayload(ApplicationAuthorityEntry entry)
    {
        Require(entry is not null);
        return Tlv((1, One(EventByte(entry.Data))), (2, GuidBytes(entry.OwnerSession)), (3, U64(entry.OwnerGeneration)),
            (4, GuidBytes(entry.BaselineId)), (5, U64(entry.SelectionRevision)), (6, One(BranchByte(entry.Selected))),
            (7, Hash(entry.EvidenceDigest)), (8, EncodeData(entry.Data)));
    }

    private static ApplicationAuthorityEntry DecodePayload(ReadOnlySpan<byte> bytes)
    {
        var f = new Fields(bytes); var kind = ReadByte(f.Take(1)); var owner = ReadGuid(f.Take(2)); var generation = ReadU64(f.Take(3));
        var baseline = ReadGuid(f.Take(4)); var revision = ReadU64(f.Take(5)); var branch = ReadBranch(f.Take(6));
        var evidence = ReadHash(f.Take(7)); var data = ReadData(kind, f.Take(8)); f.End();
        Require(generation > 0 && revision > 0); return new(owner, generation, baseline, revision, branch, evidence, data);
    }

    private static byte EventByte(ApplicationAuthorityData data) => data switch
    {
        ApplicationEnroll => 1,
        ApplicationRegister => 2,
        ApplicationSelect => 3,
        ApplicationAccept => 4,
        ApplicationOutcome => 5,
        ApplicationObserve => 6,
        ApplicationTransfer => 7,
        _ => throw new InvalidDataException("Unknown application authority event.")
    };
    private static byte BranchByte(PilotBranch branch) => branch switch
    {
        PilotBranch.Source => 1,
        PilotBranch.Candidate => 2,
        _ => throw new InvalidDataException("Unknown application branch.")
    };
    private static PilotBranch ReadBranch(ReadOnlySpan<byte> bytes) => ReadByte(bytes) switch
    {
        1 => PilotBranch.Source,
        2 => PilotBranch.Candidate,
        _ => throw new InvalidDataException("Unknown application branch bytes.")
    };
    private static byte OutcomeByte(PilotWorkOutcome outcome) => outcome switch
    {
        PilotWorkOutcome.Committed => 1,
        PilotWorkOutcome.NoEffect => 2,
        PilotWorkOutcome.Unknown => 3,
        _ => throw new InvalidDataException("Unknown application work outcome.")
    };
    private static PilotWorkOutcome ReadOutcome(ReadOnlySpan<byte> bytes) => ReadByte(bytes) switch
    {
        1 => PilotWorkOutcome.Committed,
        2 => PilotWorkOutcome.NoEffect,
        3 => PilotWorkOutcome.Unknown,
        _ => throw new InvalidDataException("Unknown application work outcome bytes.")
    };
    private static byte ObservationByte(ApplicationObservationKind kind) => kind switch
    {
        ApplicationObservationKind.Selection => 1,
        ApplicationObservationKind.WorkCommitted => 2,
        ApplicationObservationKind.WorkNoEffect => 3,
        ApplicationObservationKind.WorkUnknown => 4,
        _ => throw new InvalidDataException("Unknown application observation.")
    };
    private static ApplicationObservationKind ReadObservation(ReadOnlySpan<byte> bytes) => ReadByte(bytes) switch
    {
        1 => ApplicationObservationKind.Selection,
        2 => ApplicationObservationKind.WorkCommitted,
        3 => ApplicationObservationKind.WorkNoEffect,
        4 => ApplicationObservationKind.WorkUnknown,
        _ => throw new InvalidDataException("Unknown application observation bytes.")
    };

    private static byte[] EncodeData(ApplicationAuthorityData data) => data switch
    {
        ApplicationEnroll e => Tlv((1, EncodeRoot(e.Source))),
        ApplicationRegister e => Tlv((1, EncodeRoot(e.Candidate)), (2, EncodePublication(e.Publication))),
        ApplicationSelect e => Tlv((1, U64(e.PreviousRevision)), (2, One(BranchByte(e.PreviousBranch)))),
        ApplicationAccept e => Tlv((1, GuidBytes(e.WorkId)), (2, Hash(e.IntentDigest)), (3, Hash(e.RootDigest))),
        ApplicationOutcome e when e.Work is not null => Tlv((1, GuidBytes(e.Work.WorkId)), (2, Hash(e.Work.IntentDigest)),
            (3, U64(e.Work.AcceptanceSequence)), (4, One(OutcomeByte(e.Outcome)))),
        ApplicationObserve e => Tlv((1, One(ObservationByte(e.Kind))), (2, e.Work is null ? null : GuidBytes(e.Work.WorkId)),
            (3, e.Work is null ? null : U64(e.Work.AcceptanceSequence)), (4, e.Work is null ? null : Hash(e.Work.IntentDigest)),
            (5, U64(e.ObservedRevision)), (6, One(BranchByte(e.ObservedBranch)))),
        ApplicationTransfer e => Tlv((1, GuidBytes(e.PreviousOwner)), (2, U64(e.PreviousGeneration))),
        _ => throw new InvalidDataException("Invalid application authority data.")
    };

    private static ApplicationAuthorityData ReadData(byte kind, ReadOnlySpan<byte> bytes)
    {
        var f = new Fields(bytes); ApplicationAuthorityData data;
        switch (kind)
        {
            case 1: data = new ApplicationEnroll(ReadRoot(f.Take(1))); break;
            case 2: data = new ApplicationRegister(ReadRoot(f.Take(1)), ReadPublication(f.Take(2))); break;
            case 3:
                var priorRevision = ReadU64(f.Take(1)); Require(priorRevision > 0);
                data = new ApplicationSelect(priorRevision, ReadBranch(f.Take(2))); break;
            case 4: data = new ApplicationAccept(ReadGuid(f.Take(1)), ReadHash(f.Take(2)), ReadHash(f.Take(3))); break;
            case 5:
                var id = ReadGuid(f.Take(1)); var intent = ReadHash(f.Take(2)); var sequence = ReadU64(f.Take(3)); Require(sequence > 0);
                data = new ApplicationOutcome(new(id, intent, sequence), ReadOutcome(f.Take(4))); break;
            case 6:
                var observation = ReadObservation(f.Take(1)); ApplicationWorkReference? work = null;
                if (observation != ApplicationObservationKind.Selection)
                {
                    var workId = ReadGuid(f.Take(2)); var acceptedSequence = ReadU64(f.Take(3)); Require(acceptedSequence > 0);
                    work = new(workId, ReadHash(f.Take(4)), acceptedSequence);
                }
                var observedRevision = ReadU64(f.Take(5)); Require(observedRevision > 0);
                data = new ApplicationObserve(observation, work, observedRevision, ReadBranch(f.Take(6))); break;
            case 7:
                var previousOwner = ReadGuid(f.Take(1)); var previousGeneration = ReadU64(f.Take(2)); Require(previousGeneration > 0);
                data = new ApplicationTransfer(previousOwner, previousGeneration); break;
            default: throw new InvalidDataException("Unknown application authority event bytes.");
        }
        f.End(); return data;
    }

    internal static string RootDigest(PilotRootBinding root) => Hex(System.Security.Cryptography.SHA256.HashData(EncodeRoot(root)));

    private static byte[] EncodeRoot(PilotRootBinding root)
    {
        Require(root is not null && (root.Epoch is null || root.Epoch.DocumentId == root.DocumentId));
        var kind = root.Kind switch { PilotRootKind.Legacy => (byte)1, PilotRootKind.ScalarEpoch => (byte)2, _ => throw new InvalidDataException("Unknown root kind.") };
        var bytes = Tlv((1, One(kind)), (2, Text(root.RootKey)), (3, Text(root.AdmissionKey)), (4, U64(root.DocumentId)),
            (5, U64(root.InitialSequence)), (6, Hash(root.InitialHistoryDigest)),
            (7, root.Epoch is null ? null : Tlv((1, GuidBytes(root.Epoch.StoreId)), (2, GuidBytes(root.Epoch.EpochId)))));
        _ = ReadRoot(bytes); return bytes;
    }

    private static PilotRootBinding ReadRoot(ReadOnlySpan<byte> bytes)
    {
        var f = new Fields(bytes);
        var kind = ReadByte(f.Take(1)) switch { 1 => PilotRootKind.Legacy, 2 => PilotRootKind.ScalarEpoch, _ => throw new InvalidDataException("Unknown root kind bytes.") };
        var key = ReadText(f.Take(2)); var admission = ReadText(f.Take(3)); var document = ReadU64(f.Take(4));
        var sequence = ReadU64(f.Take(5)); var digest = ReadHash(f.Take(6)); var identity = f.Take(7, optional: true); f.End();
        Require(document > 0 && sequence <= 10_000 && (kind == PilotRootKind.Legacy ? identity.IsEmpty : !identity.IsEmpty));
        EpochIdentity? epoch = null;
        if (!identity.IsEmpty) { var e = new Fields(identity); epoch = new(ReadGuid(e.Take(1)), ReadGuid(e.Take(2)), document); e.End(); }
        return new(kind, key, admission, document, epoch, sequence, digest);
    }

    private static byte[] EncodePublication(ApplicationAuthorityPublication pin)
    {
        Require(pin is not null);
        var kind = pin.Kind switch { EpochPublicationKind.LegacyMigration => (byte)1, EpochPublicationKind.IndependentEpochRestore => (byte)2, _ => throw new InvalidDataException("Unknown publication kind.") };
        return Tlv((1, One(kind)), (2, GuidBytes(pin.AttemptId)), (3, Hash(pin.ArtifactDigest)), (4, U64(pin.AdministrativeSequence)),
            (5, Hash(pin.AdministrativeHeadDigest)), (6, Text(pin.ArtifactRootKey)), (7, Text(pin.BundleRootKey)), (8, GuidBytes(pin.BackupId)));
    }

    private static ApplicationAuthorityPublication ReadPublication(ReadOnlySpan<byte> bytes)
    {
        var f = new Fields(bytes);
        var kind = ReadByte(f.Take(1)) switch { 1 => EpochPublicationKind.LegacyMigration, 2 => EpochPublicationKind.IndependentEpochRestore, _ => throw new InvalidDataException("Unknown publication kind bytes.") };
        var attempt = ReadGuid(f.Take(2)); var artifact = ReadHash(f.Take(3)); var sequence = ReadU64(f.Take(4)); Require(sequence > 0);
        var head = ReadHash(f.Take(5)); var root = ReadText(f.Take(6)); var bundle = ReadText(f.Take(7)); var backup = ReadGuid(f.Take(8)); f.End();
        return new(kind, attempt, artifact, sequence, head, root, bundle, backup);
    }

    private static string ReadHash(ReadOnlySpan<byte> bytes) { Require(bytes.Length == 32); return Hex(bytes); }
}
