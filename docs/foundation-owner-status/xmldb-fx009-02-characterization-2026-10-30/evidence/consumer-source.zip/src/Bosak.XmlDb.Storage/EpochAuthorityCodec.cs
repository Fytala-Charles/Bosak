// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Encodes bounded epoch-bound authority records without enabling mutable store access.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 27-10-2026     | Parse explicit profiles without widening immutable entry points
// ===========================================================================================================================================================

using System.Globalization;
using System.Security.Cryptography;
using System.Xml;

namespace Bosak.XmlDb.Storage;

internal sealed record EpochAuthorityBinding(EpochIdentity Identity, byte[] FormatHash, byte[] BaseHash)
{
    internal static EpochAuthorityBinding Create(byte[] format, byte[] baseHash)
    {
        var profile = EpochCodec.RequireProfile(format, EpochProfile.ScalarWal);
        if (baseHash.Length != 32) throw new InvalidDataException("Invalid base digest size.");
        return new(profile.Identity, SHA256.HashData(format), (byte[])baseHash.Clone());
    }
}
internal sealed record EpochBaseRecord(EpochAuthorityBinding Binding);
internal sealed record EpochControlRecord(EpochAuthorityBinding Binding, byte[] BaseRecordHash);
internal sealed record EpochCurrentRecord(EpochAuthorityBinding Binding, ulong Sequence, byte[] ManifestHash, byte[] WalHash);
internal sealed record EpochWalRecord(EpochAuthorityBinding Binding, ulong Sequence, Guid TransactionId, ulong NodeId,
    string Value, byte[] PreviousManifestHash, byte[] ManifestHash, byte[] PreviousWalHash);
internal sealed record EpochGenerationRecord(EpochAuthorityBinding Binding, ulong Sequence, byte[] PreviousManifestHash, byte[] ManifestHash, byte[] WalHash);
internal sealed record EpochReaderRecord(EpochAuthorityBinding Binding, ulong Sequence, byte[] ManifestHash);

internal static class EpochAuthorityCodec
{
    internal static byte[] EncodeBase(EpochBaseRecord record) => Encode("BXEB", 1, record.Binding, writer => writer.Write(0UL));
    internal static EpochBaseRecord DecodeBase(byte[] bytes, EpochAuthorityBinding expected) => Decode(bytes, "BXEB", 1, expected, (reader, binding) =>
    {
        if (reader.ReadUInt64() != 0) throw new InvalidDataException("BASE must select zero.");
        return new EpochBaseRecord(binding);
    });

    internal static EpochControlRecord CreateControl(EpochAuthorityBinding binding) => new(binding, SHA256.HashData(EncodeBase(new(binding))));
    internal static byte[] EncodeControl(EpochControlRecord record)
    {
        ValidateControl(record);
        return Encode("BXEC", 2, record.Binding, writer => { writer.Write(0UL); writer.Write(record.BaseRecordHash); writer.Write((ushort)1); writer.Write((ushort)2); });
    }
    internal static EpochControlRecord DecodeControl(byte[] bytes, EpochAuthorityBinding expected) => Decode(bytes, "BXEC", 2, expected, (reader, binding) =>
    {
        if (reader.ReadUInt64() != 0) throw new InvalidDataException("CONTROL must select zero.");
        var record = new EpochControlRecord(binding, Hash(reader));
        if (reader.ReadUInt16() != 1 || reader.ReadUInt16() != 2) throw new InvalidDataException("Unknown scalar/recovery contract.");
        ValidateControl(record); return record;
    });

    internal static byte[] EncodeCurrent(EpochCurrentRecord record)
    {
        ValidateCurrent(record);
        return Encode("BXEH", 3, record.Binding, writer => { writer.Write(record.Sequence); writer.Write(record.ManifestHash); writer.Write(record.WalHash); });
    }
    internal static EpochCurrentRecord DecodeCurrent(byte[] bytes, EpochAuthorityBinding expected) => Decode(bytes, "BXEH", 3, expected, (reader, binding) =>
    { var record = new EpochCurrentRecord(binding, reader.ReadUInt64(), Hash(reader), Hash(reader)); ValidateCurrent(record); return record; });

    internal static byte[] EncodeWal(EpochWalRecord record)
    {
        ValidateWal(record);
        return Encode("BXEW", 4, record.Binding, writer =>
        {
            writer.Write(record.Sequence); writer.Write(record.TransactionId.ToByteArray()); writer.Write(record.NodeId);
            BinaryEnvelope.WriteString(writer, record.Value); writer.Write(record.PreviousManifestHash); writer.Write(record.ManifestHash); writer.Write(record.PreviousWalHash);
        });
    }
    internal static EpochWalRecord DecodeWal(byte[] bytes, EpochAuthorityBinding expected) => Decode(bytes, "BXEW", 4, expected, (reader, binding) =>
    {
        var record = new EpochWalRecord(binding, reader.ReadUInt64(), new Guid(reader.ReadBytes(16)), reader.ReadUInt64(), BinaryEnvelope.ReadString(reader), Hash(reader), Hash(reader), Hash(reader));
        ValidateWal(record); return record;
    });

    internal static byte[] EncodeGeneration(EpochGenerationRecord record)
    {
        ValidateGeneration(record);
        return Encode("BXEG", 5, record.Binding, writer => { writer.Write(record.Sequence); writer.Write(record.PreviousManifestHash); writer.Write(record.ManifestHash); writer.Write(record.WalHash); });
    }
    internal static EpochGenerationRecord DecodeGeneration(byte[] bytes, EpochAuthorityBinding expected) => Decode(bytes, "BXEG", 5, expected, (reader, binding) =>
    { var record = new EpochGenerationRecord(binding, reader.ReadUInt64(), Hash(reader), Hash(reader), Hash(reader)); ValidateGeneration(record); return record; });

    internal static byte[] EncodeReader(EpochReaderRecord record)
    {
        ValidateReader(record);
        return Encode("BXER", 6, record.Binding, writer => { writer.Write(record.Sequence); writer.Write(record.ManifestHash); });
    }
    internal static EpochReaderRecord DecodeReader(byte[] bytes, EpochAuthorityBinding expected) => Decode(bytes, "BXER", 6, expected, (reader, binding) =>
    { var record = new EpochReaderRecord(binding, reader.ReadUInt64(), Hash(reader)); ValidateReader(record); return record; });

    internal static string WalFileName(ulong sequence) => Name(sequence, false) + ".wal";
    internal static string GenerationName(ulong sequence) => Name(sequence, false);
    internal static string ReaderFileName(ulong sequence) => Name(sequence, true) + ".lease";
    internal static ulong ParseWalName(string name) => ParseName(name, ".wal", false);
    internal static ulong ParseGenerationName(string name) => ParseName(name, "", false);
    internal static ulong ParseReaderName(string name) => ParseName(name, ".lease", true);

    private static string Name(ulong sequence, bool allowZero) { Sequence(sequence, allowZero); return sequence.ToString("D20", CultureInfo.InvariantCulture); }
    private static ulong ParseName(string name, string suffix, bool allowZero)
    {
        if (name.Length != 20 + suffix.Length || !name.EndsWith(suffix, StringComparison.Ordinal) ||
            !ulong.TryParse(name.AsSpan(0, 20), NumberStyles.None, CultureInfo.InvariantCulture, out var sequence) || name != Name(sequence, allowZero) + suffix)
            throw new InvalidDataException("Noncanonical authority file name.");
        return sequence;
    }

    private static byte[] Encode(string magic, byte role, EpochAuthorityBinding binding, Action<BinaryWriter> body)
    {
        ValidateBinding(binding);
        return BinaryEnvelope.Encode(magic, writer =>
        {
            writer.Write(binding.Identity.StoreId.ToByteArray()); writer.Write(binding.Identity.EpochId.ToByteArray()); writer.Write(binding.Identity.DocumentId);
            writer.Write(binding.FormatHash); writer.Write(binding.BaseHash); writer.Write(role); body(writer);
        });
    }
    private static T Decode<T>(byte[] bytes, string magic, byte role, EpochAuthorityBinding expected, Func<BinaryReader, EpochAuthorityBinding, T> body)
    {
        ValidateBinding(expected);
        return BinaryEnvelope.Decode(bytes, magic, reader =>
        {
            var binding = new EpochAuthorityBinding(new(new Guid(reader.ReadBytes(16)), new Guid(reader.ReadBytes(16)), reader.ReadUInt64()), Hash(reader), Hash(reader));
            if (binding.Identity != expected.Identity || !binding.FormatHash.AsSpan().SequenceEqual(expected.FormatHash) ||
                !binding.BaseHash.AsSpan().SequenceEqual(expected.BaseHash) || reader.ReadByte() != role)
                throw new InvalidDataException("Authority identity, profile, base or role mismatch.");
            return body(reader, binding);
        });
    }
    private static void ValidateBinding(EpochAuthorityBinding binding)
    {
        if (binding.Identity.StoreId == Guid.Empty || binding.Identity.EpochId == Guid.Empty || binding.Identity.DocumentId == 0)
            throw new InvalidDataException("Invalid authority identity.");
        Digest(binding.FormatHash); Digest(binding.BaseHash);
    }
    private static byte[] Hash(BinaryReader reader) { var bytes = reader.ReadBytes(32); Digest(bytes); return bytes; }
    private static void Digest(byte[] hash) { if (hash.Length != 32) throw new InvalidDataException("Invalid authority digest length."); }
    private static bool Zero(byte[] hash) => hash.All(value => value == 0);
    private static void Sequence(ulong sequence, bool allowZero)
    { if (sequence > 10_000 || !allowZero && sequence == 0) throw new InvalidDataException("Authority sequence out of bounds."); }
    private static void ValidateControl(EpochControlRecord record)
    {
        Digest(record.BaseRecordHash);
        if (!record.BaseRecordHash.AsSpan().SequenceEqual(SHA256.HashData(EncodeBase(new(record.Binding)))))
            throw new InvalidDataException("CONTROL does not bind the canonical BASE record.");
    }
    private static void ValidateCurrent(EpochCurrentRecord record)
    {
        Sequence(record.Sequence, true); Digest(record.ManifestHash); Digest(record.WalHash);
        if (record.Sequence == 0 ? !record.ManifestHash.AsSpan().SequenceEqual(record.Binding.BaseHash) || !Zero(record.WalHash) : Zero(record.WalHash))
            throw new InvalidDataException("CURRENT zero/head witness mismatch.");
    }
    private static void ValidateWal(EpochWalRecord record)
    {
        Sequence(record.Sequence, false); Digest(record.PreviousManifestHash); Digest(record.ManifestHash); Digest(record.PreviousWalHash);
        if (record.TransactionId == Guid.Empty || record.NodeId is 0 or > BinaryEnvelope.MaximumNodes ||
            record.Sequence == 1 && (!record.PreviousManifestHash.AsSpan().SequenceEqual(record.Binding.BaseHash) || !Zero(record.PreviousWalHash)))
            throw new InvalidDataException("Invalid WAL operation identity or first predecessor.");
        try
        {
            if (BinaryEnvelope.Utf8.GetByteCount(record.Value) > BinaryEnvelope.MaximumStringBytes) throw new InvalidDataException("Oversized WAL scalar.");
            XmlConvert.VerifyXmlChars(record.Value);
        }
        catch (Exception exception) when (exception is XmlException or System.Text.EncoderFallbackException)
        { throw new InvalidDataException("Invalid XML/UTF-8 scalar.", exception); }
    }
    private static void ValidateGeneration(EpochGenerationRecord record)
    {
        Sequence(record.Sequence, false); Digest(record.PreviousManifestHash); Digest(record.ManifestHash); Digest(record.WalHash);
        if (Zero(record.WalHash) || record.Sequence == 1 && !record.PreviousManifestHash.AsSpan().SequenceEqual(record.Binding.BaseHash))
            throw new InvalidDataException("Invalid generation WAL/base witness.");
    }
    private static void ValidateReader(EpochReaderRecord record)
    {
        Sequence(record.Sequence, true); Digest(record.ManifestHash);
        if (record.Sequence == 0 && !record.ManifestHash.AsSpan().SequenceEqual(record.Binding.BaseHash))
            throw new InvalidDataException("Base reader identity mismatch.");
    }
}
