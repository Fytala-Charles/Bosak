// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Prepares immutable administrative intent and guards one process-local dispatch claim.
// SPECIAL NOTES        : RC1 plan state shared by RC2 execution; no target reservation, durable replay or public API.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 28-10-2026     | Share immutable owner-bound intent with the explicit RC2 execution path
// ===========================================================================================================================================================

using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

internal enum EpochAttemptState { Prepared, Dispatched }
internal sealed record EpochAdministrativeAttemptDescriptor(Guid AttemptId, EpochPublicationKind Kind, string ArtifactRoot, string BundleRoot,
    string InventorySha256, Guid BackupId, ulong DocumentId, ulong CommitSequence, EpochIdentity? SourceEpoch,
    EpochProfile DestinationProfile, DurabilityMode Durability)
{
    internal EpochPublicationInspectionRequest ToInspectionRequest() => new(Kind, ArtifactRoot, BundleRoot, InventorySha256, AttemptId);
}

internal sealed class EpochAdministrativeAttemptPlan
{
    private readonly object _owner;
    private readonly EpochAdministrativeAttemptDescriptor _descriptor;
    private int _state;
    private EpochAdministrativeAttemptPlan(object owner, EpochAdministrativeAttemptDescriptor descriptor) { _owner = owner; _descriptor = descriptor; }
    internal EpochAttemptState State => (EpochAttemptState)Volatile.Read(ref _state);
    internal EpochAdministrativeAttemptDescriptor Describe() => _descriptor with { };

    internal static EpochAdministrativeAttemptPlan Prepare(object owner, EpochPublicationKind kind, string artifact, string destination, DurabilityMode durability)
    {
        ArgumentNullException.ThrowIfNull(owner);
        ArgumentException.ThrowIfNullOrWhiteSpace(artifact); ArgumentException.ThrowIfNullOrWhiteSpace(destination);
        if (!Enum.IsDefined(kind)) throw new ArgumentOutOfRangeException(nameof(kind));
        if (!Enum.IsDefined(durability)) throw new ArgumentOutOfRangeException(nameof(durability));
        destination = BackupStorage.Destination(artifact, destination);
        artifact = Path.TrimEndingDirectorySeparator(Path.GetFullPath(artifact));
        var bytes = BinaryEnvelope.ReadFile(Path.Combine(artifact, "inventory.bin"));
        Guid backup; ulong document, sequence; EpochIdentity? source;
        if (kind == EpochPublicationKind.LegacyMigration)
        {
            var inventory = LegacyMigrationVerifier.ReadArtifact(artifact);
            if (!bytes.AsSpan().SequenceEqual(BackupCodec.Encode(inventory))) throw new InvalidDataException("Legacy inventory changed during preparation.");
            backup = inventory.Identity.BackupId; document = inventory.Identity.DocumentId; sequence = inventory.Identity.CommitSequence; source = null;
        }
        else
        {
            var inventory = EpochBackupStorage.ReadArtifact(artifact);
            if (!bytes.AsSpan().SequenceEqual(EpochBackupCodec.EncodeInventory(inventory))) throw new InvalidDataException("Epoch inventory changed during preparation.");
            backup = inventory.BackupId; document = inventory.Source.Identity.DocumentId; sequence = inventory.CommitSequence; source = inventory.Source.Identity;
        }
        if (!bytes.AsSpan().SequenceEqual(BinaryEnvelope.ReadFile(Path.Combine(artifact, "inventory.bin")))) throw new InvalidDataException("Inventory changed after preparation preflight.");
        return new(owner, new(Guid.NewGuid(), kind, artifact, destination, Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant(),
            backup, document, sequence, source, EpochProfile.ScalarWal, durability));
    }

    // Pure local claim, not pipeline execution. RC2 revalidates every mutable input
    // after this point. Any later failure leaves Dispatched; there is no reset or replay.
    internal EpochAdministrativeAttemptDescriptor Claim(object owner, DurabilityMode durability)
    {
        if (!ReferenceEquals(owner, _owner)) throw new ArgumentException("Attempt plan belongs to another administration instance.", nameof(owner));
        if (durability != _descriptor.Durability) throw new ArgumentException("Attempt policy differs from its prepared policy.", nameof(durability));
        if (Interlocked.CompareExchange(ref _state, (int)EpochAttemptState.Dispatched, (int)EpochAttemptState.Prepared) != (int)EpochAttemptState.Prepared)
            throw new InvalidOperationException("Attempt plan has already been dispatched and cannot be replayed.");
        return Describe();
    }
}

internal sealed partial class ScalarEpochAdministration
{
    private readonly object _attemptOwner = new();
    internal EpochAdministrativeAttemptPlan PrepareAttempt(EpochPublicationKind kind, string artifact, string destination) =>
        EpochAdministrativeAttemptPlan.Prepare(_attemptOwner, kind, artifact, destination, _storage.Durability);
    // Internal pure state primitive; explicit execution claims independently through the same plan; does not publish.
    internal EpochAdministrativeAttemptDescriptor ClaimAttempt(EpochAdministrativeAttemptPlan plan)
    {
        ArgumentNullException.ThrowIfNull(plan);
        return plan.Claim(_attemptOwner, _storage.Durability);
    }
}
