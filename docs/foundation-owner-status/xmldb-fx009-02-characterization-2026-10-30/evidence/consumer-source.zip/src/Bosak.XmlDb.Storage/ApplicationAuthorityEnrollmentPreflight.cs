// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 30 October 2026
// PURPOSE              : Validates retained placement outside authority serialization and exact roles inside it.
// SPECIAL NOTES        : ER-002 retained preflight only; generic readers and frozen/public contracts are unchanged.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 30-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

/// <summary>Observes private retained preflight phases without supplying execution authority.</summary>
internal interface IRetainedEnrollmentPreflightProbe
{
    /// <summary>Observes a protected path immediately before native ancestor inspection.</summary>
    /// <param name="path">Protected path about to be inspected outside authority serialization.</param>
    void BeforeProtectedPathRead(string path);
    /// <summary>Observes the unlocked boundary immediately before serialized authority validation.</summary>
    void BeforeAuthorityRead();
}

/// <summary>Validates retained placement outside authority serialization and exact roles inside it.</summary>
internal sealed partial class ApplicationAuthorityLifetime
{
    private void ValidateRetainedEnrollmentAuthority(RetainedEnrollmentResources resources)
    {
        // The actual source child and authority/parent operation span both unlocked placement
        // checks. Generic ReadOwned is deliberately excluded from this retained protocol.
        if (resources.Source is null) throw new InvalidOperationException("Retained preflight requires the actual registered source child.");
        CheckRetainedPlacement(resources);
        CheckRetainedAuthority(resources);
        CheckRetainedPlacement(resources);
        // Recheck roles/metadata/empty head after the last unlocked placement pass. No head
        // or path observation is adopted, and no authority output occurs here.
        CheckRetainedAuthority(resources);
    }
    private void CheckRetainedPlacement(RetainedEnrollmentResources resources)
    {
        RequireRetainedEntryWithoutCallerLocks(resources.Source?.IsSourceGateEntered == true);
        CheckPlacement(_parent.Root, Root, _configuration, _roots, _registration.History,
            resources.PreflightProbe is { } probe ? probe.BeforeProtectedPathRead : null);
    }
    private void CheckRetainedAuthority(RetainedEnrollmentResources resources)
    {
        RequireRetainedEntryWithoutCallerLocks(resources.Source?.IsSourceGateEntered == true);
        resources.PreflightProbe?.BeforeAuthorityRead(); // Test observation only, outside all gates.
        RequireRetainedEntryWithoutCallerLocks(resources.Source?.IsSourceGateEntered == true);
        lock (_readGate) RequireEmptyAppendHead();
    }
}
