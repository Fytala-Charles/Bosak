// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Binds live plans to acknowledged host transitions and registered single dispatch.
// SPECIAL NOTES        : Internal synchronous pilot; no descriptor replay, automatic retry, routing or global fence.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 29-10-2026     | Prepare explicit fresh-plan retries from qualified latest absence
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal sealed record EmbeddedHostRetryEvidence(EmbeddedHostContext Context, HostLedgerSnapshot Absent, bool Fresh,
    bool AllWritersControlled, bool AllPublishersControlled, bool PriorExecutorsExcluded, bool QueueFree,
    bool StableDestinationNamespace, bool NoRetainedPublicationEvidence);

internal enum EmbeddedHostAttemptState { Prepared, Recording, Recorded, Dispatching, Completed, ReconciliationRequired }
internal enum EmbeddedHostExecutionDisposition { Succeeded, NotInvoked, PipelineFailed, ReconciliationRequired }
internal enum HostOrchestrationStage { IntentAcknowledged, AuthorizationAcknowledged, BeforeInvoke, PipelineReturned, BeforeReceiptSave, BeforeReturn }
internal sealed record EmbeddedHostInspectionEvidence(EmbeddedHostContext Context, bool Fresh, bool AllWritersControlled,
    bool AllPublishersControlled, bool PriorExecutorsExcluded, bool QueueFree);
internal sealed record EmbeddedHostExecutionResult(EmbeddedHostExecutionDisposition Disposition, EpochAdministrativeAttemptDescriptor Attempt,
    EpochPublishedReceipt? PipelineReceipt, HostJournalAppendResult? Authorization, HostJournalAppendResult? ReceiptSave, Exception? Error, Exception? LedgerError)
{
    internal bool WritersMustRemainStopped => true;
}

// A descriptor is descriptive only. This private-constructor ticket additionally holds a
// real process-local library plan and an unexposed orchestration-owner token.
internal sealed class EmbeddedHostAttempt
{
    private readonly object _owner;
    private readonly EpochAdministrativeAttemptPlan _plan;
    private HostLedgerSnapshot _snapshot;
    private int _state;
    private bool _authorized;
    private readonly EmbeddedHostRetryEvidence? _retry;
    internal EmbeddedHostRetryEvidence? Retry => _retry;
    private EmbeddedHostAttempt(object owner, EpochAdministrativeAttemptPlan plan, HostLedgerContext context, EmbeddedHostRetryEvidence? retry)
    { _owner = owner; _plan = plan; _snapshot = new(context, HostLedgerStage.Recorded); _retry = retry; }
    internal static EmbeddedHostAttempt Create(object owner, EpochAdministrativeAttemptPlan plan, HostLedgerContext context, EmbeddedHostRetryEvidence? retry = null) => new(owner, plan, context, retry);
    internal EpochAdministrativeAttemptDescriptor Describe() => _plan.Describe();
    internal EmbeddedHostAttemptState State => (EmbeddedHostAttemptState)Volatile.Read(ref _state);
    internal EpochAttemptState PlanState => _plan.State;
    internal HostLedgerSnapshot Snapshot => _snapshot;
    internal void CheckOwner(object owner) { if (!ReferenceEquals(owner, _owner)) throw new ArgumentException("Attempt belongs to another orchestrator."); }
    internal void Claim(object owner, EmbeddedHostAttemptState from, EmbeddedHostAttemptState to)
    {
        CheckOwner(owner);
        if (Interlocked.CompareExchange(ref _state, (int)to, (int)from) != (int)from) throw new InvalidOperationException("Attempt cannot repeat or replay this transition.");
    }
    internal void Recorded(object owner) { CheckOwner(owner); Volatile.Write(ref _state, (int)EmbeddedHostAttemptState.Recorded); }
    internal void Authorized(object owner, HostLedgerSnapshot snapshot) { CheckOwner(owner); _snapshot = snapshot; _authorized = true; }
    internal EpochPublishedReceipt Invoke(object owner, ScalarEpochAdministration administration)
    {
        CheckOwner(owner);
        if (State != EmbeddedHostAttemptState.Dispatching || !_authorized) throw new InvalidOperationException("No acknowledged live authorization.");
        return administration.ExecuteAttempt(_plan);
    }
    internal void Finish(object owner, bool success) { CheckOwner(owner); Volatile.Write(ref _state, (int)(success ? EmbeddedHostAttemptState.Completed : EmbeddedHostAttemptState.ReconciliationRequired)); }
}

internal sealed class EmbeddedHostOrchestrator
{
    private readonly object _ticketOwner = new();
    private readonly object _flowGate = new();
    private readonly EmbeddedHostLifetime _host;
    private readonly ScalarEpochAdministration _administration;
    private readonly Action<HostOrchestrationStage>? _checkpoint;
    private readonly Action<HostAppendStage>? _appendCheckpoint;
    private int _reconciliation;
    private EmbeddedHostOrchestrator(EmbeddedHostLifetime host, ScalarEpochAdministration administration,
        Action<HostOrchestrationStage>? checkpoint, Action<HostAppendStage>? appendCheckpoint)
    { _host = host; _administration = administration; _checkpoint = checkpoint; _appendCheckpoint = appendCheckpoint; }
    internal static EmbeddedHostOrchestrator Create(EmbeddedHostLifetime host) => CreateCore(host, ScalarEpochAdministration.Create(new(DurabilityMode.ProcessCrash)));
    internal static EmbeddedHostOrchestrator CreateCore(EmbeddedHostLifetime host, ScalarEpochAdministration administration,
        Action<HostOrchestrationStage>? checkpoint = null, Action<HostAppendStage>? appendCheckpoint = null)
    {
        ArgumentNullException.ThrowIfNull(host); ArgumentNullException.ThrowIfNull(administration);
        if (!host.JournalStatus.CanAttemptAppend) throw new InvalidOperationException("Orchestration requires explicitly enabled owned journal state.");
        return new(host, administration, checkpoint, appendCheckpoint);
    }
    internal bool ReconciliationRequired => Volatile.Read(ref _reconciliation) != 0;
    internal bool WritersMustRemainStopped => true;

    internal EmbeddedHostAttempt Prepare(Guid requestId, EpochPublicationKind kind, string artifact, string destination)
    {
        if (requestId == Guid.Empty) throw new ArgumentException("Host request ID must be nonempty.", nameof(requestId));
        EnsureRunning(); using var operation = _host.BeginOperation();
        var plan = _administration.PrepareAttempt(kind, artifact, destination); var h = _host.Context;
        return EmbeddedHostAttempt.Create(_ticketOwner, plan, new(requestId, h.Deployment, h.ResourceScope, plan.Describe(), 1, h.SessionId, 1));
    }
    internal EmbeddedHostAttempt PrepareRetry(EmbeddedHostRetryEvidence evidence)
    {
        ArgumentNullException.ThrowIfNull(evidence); EnsureRunning(); using var operation = _host.BeginOperation();
        lock (_flowGate)
        {
            RequireRetry(evidence); var old = evidence.Absent.Context; var descriptor = old.Intent;
            var plan = _administration.PrepareAttempt(descriptor.Kind, descriptor.ArtifactRoot, descriptor.BundleRoot);
            var next = plan.Describe();
            if (next.AttemptId == descriptor.AttemptId || next with { AttemptId = descriptor.AttemptId } != descriptor)
                throw new InvalidOperationException("Retry must use a fresh plan/ID and unchanged pinned input/destination.");
            RequireRetry(evidence);
            return EmbeddedHostAttempt.Create(_ticketOwner, plan, new(old.RequestId, old.Deployment, old.ResourceScope, next, 1, _host.Context.SessionId, 1), evidence);
        }
    }
    private HostJournalPosition RequireRetry(EmbeddedHostRetryEvidence evidence)
    {
        if (evidence.Context != _host.Context || evidence.Absent is not { Stage: HostLedgerStage.ReconciledAbsent, Receipt: null, Observed: null } absent ||
            absent.Context.OwnerSession != _host.Context.SessionId || !evidence.Fresh || !evidence.AllWritersControlled || !evidence.AllPublishersControlled ||
            !evidence.PriorExecutorsExcluded || !evidence.QueueFree || !evidence.StableDestinationNamespace || !evidence.NoRetainedPublicationEvidence)
            throw new InvalidOperationException("Explicit retry requires fresh bound qualified absence and controlled exclusion.");
        var position = _host.JournalStatus.KnownPosition; var history = _host.ReadJournalForReconciliation();
        var active = history.Frames.LastOrDefault(frame => frame.Event == HostJournalEvent.RecordIntent && frame.Snapshot.Context.RequestId == absent.Context.RequestId);
        var latest = history.Frames.LastOrDefault(frame => frame.Snapshot.Context.Intent.AttemptId == absent.Context.Intent.AttemptId);
        if (active?.Snapshot.Context.Intent.AttemptId != absent.Context.Intent.AttemptId || latest?.Snapshot != absent)
            throw new InvalidOperationException("Retry requires the exact latest reconciled request attempt.");
        if (_administration.InspectPublication(absent.Context.Intent.ToInspectionRequest()).Status != EpochInspectionStatus.NotObserved)
            throw new InvalidOperationException("Retry publication is no longer absent or pinned inputs are unavailable.");
        return position;
    }
    private HostJournalPosition RequireNewRequest(Guid requestId)
    {
        var position = _host.JournalStatus.KnownPosition;
        if (_host.ReadJournalForReconciliation().Frames.Any(frame => frame.Snapshot.Context.RequestId == requestId))
            throw new InvalidOperationException("An existing request requires the explicit fresh-plan retry path.");
        return position;
    }
    internal HostJournalAppendResult Record(EmbeddedHostAttempt ticket)
    {
        ArgumentNullException.ThrowIfNull(ticket); ticket.Claim(_ticketOwner, EmbeddedHostAttemptState.Prepared, EmbeddedHostAttemptState.Recording);
        try
        {
            using var operation = _host.BeginOperation();
            lock (_flowGate)
            {
                EnsureRunning(); var expectedPosition = ticket.Retry is { } retry ? RequireRetry(retry) : RequireNewRequest(ticket.Snapshot.Context.RequestId);
                var result = Save(HostJournalEvent.RecordIntent, ticket.Snapshot, expectedPosition: expectedPosition);
                ticket.Recorded(_ticketOwner); _checkpoint?.Invoke(HostOrchestrationStage.IntentAcknowledged); return result;
            }
        }
        catch { ticket.Finish(_ticketOwner, false); StopForReconciliation(); throw; }
    }
    internal EmbeddedHostExecutionResult Execute(EmbeddedHostAttempt ticket)
    {
        ArgumentNullException.ThrowIfNull(ticket); ticket.Claim(_ticketOwner, EmbeddedHostAttemptState.Recorded, EmbeddedHostAttemptState.Dispatching);
        IDisposable? workflow = null; EpochPublishedReceipt? receipt = null; HostJournalAppendResult? authorization = null; HostJournalAppendResult? receiptSave = null;
        var invoked = false;
        try
        {
            EnsureRunning(); workflow = _host.BeginExclusiveExecutor(ticket.Describe().AttemptId);
            lock (_flowGate)
            {
                RequireLatest(ticket.Snapshot);
                var next = ticket.Snapshot with { Context = ticket.Snapshot.Context with { Revision = 2 }, Stage = HostLedgerStage.DispatchAuthorized };
                authorization = Save(HostJournalEvent.AuthorizeDispatch, next, workflow); ticket.Authorized(_ticketOwner, next);
            }
            _checkpoint?.Invoke(HostOrchestrationStage.AuthorizationAcknowledged); _checkpoint?.Invoke(HostOrchestrationStage.BeforeInvoke);
            Exception? pipelineError = null;
            // Registration is the dispatch admission point. A concurrent fault/close before it
            // rejects invocation; after it, already admitted work retains ownership until completion.
            lock (_flowGate) RequireLatest(ticket.Snapshot);
            using (var executor = _host.BeginOperation())
            {
                invoked = true;
                try { receipt = ticket.Invoke(_ticketOwner, _administration); }
                catch (Exception error) { pipelineError = error; }
            }
            if (pipelineError is not null)
            {
                Exception? ledgerError = null;
                try
                {
                    lock (_flowGate)
                    {
                        RequireLatest(ticket.Snapshot);
                        Save(HostJournalEvent.MarkUncertain, ticket.Snapshot with { Context = ticket.Snapshot.Context with { Revision = 3 }, Stage = HostLedgerStage.Uncertain }, workflow);
                    }
                }
                catch (Exception error) { ledgerError = error; }
                ticket.Finish(_ticketOwner, false); StopForReconciliation();
                return new(EmbeddedHostExecutionDisposition.PipelineFailed, ticket.Describe(), null, authorization, null, pipelineError, ledgerError);
            }
            _checkpoint?.Invoke(HostOrchestrationStage.PipelineReturned); _checkpoint?.Invoke(HostOrchestrationStage.BeforeReceiptSave);
            lock (_flowGate)
            {
                RequireLatest(ticket.Snapshot);
                receiptSave = Save(HostJournalEvent.Acknowledge, ticket.Snapshot with { Context = ticket.Snapshot.Context with { Revision = 3 }, Stage = HostLedgerStage.Acknowledged, Receipt = receipt }, workflow);
            }
            _checkpoint?.Invoke(HostOrchestrationStage.BeforeReturn); ticket.Finish(_ticketOwner, true);
            return new(EmbeddedHostExecutionDisposition.Succeeded, ticket.Describe(), receipt, authorization, receiptSave, null, null);
        }
        catch (Exception error)
        {
            ticket.Finish(_ticketOwner, false); StopForReconciliation();
            return new(invoked ? EmbeddedHostExecutionDisposition.ReconciliationRequired : EmbeddedHostExecutionDisposition.NotInvoked,
                ticket.Describe(), receipt, authorization, receiptSave, error, null);
        }
        finally { workflow?.Dispose(); }
    }
    internal EpochPublicationObservation Inspect(EpochAdministrativeAttemptDescriptor descriptor, EmbeddedHostInspectionEvidence evidence)
    {
        ArgumentNullException.ThrowIfNull(descriptor); ArgumentNullException.ThrowIfNull(evidence);
        if (evidence.Context != _host.Context || !evidence.Fresh || !evidence.AllWritersControlled || !evidence.AllPublishersControlled || !evidence.PriorExecutorsExcluded || !evidence.QueueFree)
            throw new InvalidOperationException("Inspection requires fresh bound ownership and excluded publishers, not write-readiness authority.");
        using var observation = _host.BeginReconciliationOperation(); var history = _host.ReadJournalForReconciliation();
        var saved = history.Frames.LastOrDefault(frame => frame.Snapshot.Context.Intent.AttemptId == descriptor.AttemptId);
        if (saved?.Snapshot.Context.Intent != descriptor) throw new InvalidOperationException("No exact persisted attempt binding; external reconciliation is required.");
        return _administration.InspectPublication(descriptor.ToInspectionRequest());
    }
    private HostJournalAppendResult Save(HostJournalEvent kind, HostLedgerSnapshot snapshot, IDisposable? executor = null, HostJournalPosition? expectedPosition = null)
    {
        var result = executor is null ? _host.AppendJournal(expectedPosition ?? _host.JournalStatus.KnownPosition, kind, snapshot, _appendCheckpoint) :
            _host.AppendForExecutor(executor, _host.JournalStatus.KnownPosition, kind, snapshot, _appendCheckpoint);
        if (result.Disposition != HostJournalAppendDisposition.Acknowledged || result.Frame?.Snapshot != snapshot)
            throw new InvalidOperationException("Conditional journal save was not acknowledged exactly.");
        return result;
    }
    private void RequireLatest(HostLedgerSnapshot expected)
    {
        var saved = _host.ReadJournalForReconciliation().Frames.LastOrDefault(frame => frame.Snapshot.Context.Intent.AttemptId == expected.Context.Intent.AttemptId);
        if (saved?.Snapshot != expected) throw new InvalidOperationException("Persisted attempt changed or was not acknowledged by this ticket.");
    }
    private void EnsureRunning() { if (ReconciliationRequired) throw new InvalidOperationException("Orchestration is stopped for reconciliation; no retry/rearm is supported."); }
    private void StopForReconciliation() { Interlocked.Exchange(ref _reconciliation, 1); _host.CloseAdmissions(); }
}
