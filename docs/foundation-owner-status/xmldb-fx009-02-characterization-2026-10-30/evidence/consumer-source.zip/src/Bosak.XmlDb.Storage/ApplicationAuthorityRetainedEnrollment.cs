// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Prepares retained enrollment and admits actual no-output execution under three owners.
// SPECIAL NOTES        : EF2 memory-only admission and read-only validation; no authority output or writer resume.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 30-10-2026     | Separate retained placement preflight from authority-only serialization                   |
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

internal sealed partial class ApplicationAuthorityLifetime
{
    private bool _retainedEnrollmentMode;
    private RetainedEnrollmentPreparation? _retainedPreparation;
    private RetainedEnrollmentExecution? _retainedExecution;
    private RetainedEnrollmentResources? _unreleasedRetainedResources;

    internal RetainedEnrollmentPreparation PrepareRetainedFirstEnrollment(MigrationSourceFreeze source, FrozenMigrationCapture capture, ApplicationEnrollmentEvidence evidence) =>
        PrepareRetainedFirstEnrollmentCore(source, capture, evidence, new LocalEnrollmentSourceLeaseClose());
    internal RetainedEnrollmentPreparation PrepareRetainedFirstEnrollmentCore(MigrationSourceFreeze source, FrozenMigrationCapture capture,
        ApplicationEnrollmentEvidence evidence, IEnrollmentSourceLeaseClose close, IRetainedEnrollmentPreflightProbe? preflightProbe = null)
    {
        RequireRetainedEntryWithoutCallerLocks(source?.IsSourceGateEntered == true);
        IDisposable operation;
        lock (_gate)
        {
            ObjectDisposedException.ThrowIf(_closing, this);
            if (_faulted || !_provisioned || _initializerClaimed || _reads != 0 || _retainedEnrollmentMode)
                throw new InvalidOperationException("Retained preparation requires the original unused initializer and drained inspection mode.");
            var parentRead = _registration.BeginRead(_parent); _reads++; operation = new Inspection(this, parentRead);
            _initializerClaimed = true; _retainedEnrollmentMode = true;
        }
        var resources = new RetainedEnrollmentResources(this, operation, preflightProbe);
        try
        {
            RequireEnrollmentEvidence(evidence); ArgumentNullException.ThrowIfNull(source); ArgumentNullException.ThrowIfNull(capture);
            RequireEnrollmentOwner();
            resources.InstallSource(source.RetainForEnrollmentCore(capture, close));
            ValidateRetainedEnrollmentAuthority(resources);
            var pin = InspectRetainedBaseline(resources.Source!, capture, evidence);
            var position = _parent.JournalStatus.KnownPosition; var baseline = Guid.NewGuid();
            var entry = new ApplicationAuthorityEntry(_parent.Context.SessionId, 1, baseline, 1, PilotBranch.Source,
                EnrollmentEvidenceDigest(evidence, pin, position, baseline), new ApplicationEnroll(pin.Source));
            var metadata = ApplicationAuthorityCodec.DecodeMetadata(ApplicationAuthorityCodec.EncodeMetadata(_configuration), _configuration);
            _ = ApplicationAuthorityCodec.DecodeJournal(ApplicationAuthorityCodec.EncodeFrame(metadata, 1, new string('0', 64), entry), metadata);
            ValidateRetainedEnrollmentAuthority(resources); RequireEnrollmentOwner();
            var plan = new RetainedEnrollmentPreparation(this, capture, evidence, pin, new(_configuration.AuthorityId, position, entry), resources);
            lock (_gate)
            {
                ObjectDisposedException.ThrowIf(_closing, this);
                if (_faulted) throw new InvalidOperationException("Authority session is faulted.");
                _retainedPreparation = plan;
            }
            return plan;
        }
        catch (Exception primary)
        {
            lock (_gate) _faulted = true;
            try { resources.Dispose(); }
            catch (Exception cleanup) { _unreleasedRetainedResources = resources; throw new AggregateException(primary, cleanup); }
            throw;
        }
    }

    internal RetainedEnrollmentExecution? TryArmRetainedFirstEnrollment(RetainedEnrollmentPreparation plan, ApplicationEnrollmentEvidence freshEvidence) =>
        TryArmRetainedFirstEnrollmentCore(plan, freshEvidence, null);
    internal RetainedEnrollmentExecution? TryArmRetainedFirstEnrollmentCore(RetainedEnrollmentPreparation plan,
        ApplicationEnrollmentEvidence freshEvidence, Action? beforeAdmission, Action<bool>? afterAdmission = null)
    {
        ArgumentNullException.ThrowIfNull(plan); plan.CheckThread();
        RequireRetainedEntryWithoutCallerLocks(plan.IsSourceGateEntered);
        RetainedEnrollmentExecution execution;
        lock (_gate)
        {
            if (!ReferenceEquals(_retainedPreparation, plan) || !ReferenceEquals(plan.Owner, this) || plan.Disposed || plan.Consumed)
                throw new InvalidOperationException("Only the actual unconsumed retained preparation can dispatch.");
            execution = new(this, plan, plan.ClaimResources()); _retainedExecution = execution;
        }
        try
        {
            RequireEnrollmentOwner(); RequireEnrollmentEvidence(freshEvidence);
            if (freshEvidence != plan.Evidence) throw new InvalidOperationException("Fresh evidence must bind the exact prepared reconciliation intent.");
            var pin = InspectRetainedBaseline(execution.Resources.Source!, plan.Capture, freshEvidence);
            if (pin != plan.Pin) throw new InvalidDataException("Prepared retained baseline changed.");
            _registration.VerifyRetainedEnrollmentParent(_parent, plan.Description.AdministrativePosition);
            ValidateRetainedEnrollmentAuthority(execution.Resources); beforeAdmission?.Invoke();
            var armed = false;
            if (Monitor.TryEnter(_gate))
            {
                try
                {
                    ObjectDisposedException.ThrowIf(_closing, this);
                    if (_faulted || plan.Disposed || !ReferenceEquals(_retainedExecution, execution)) throw new InvalidOperationException("Retained dispatch is closed or faulted.");
                    armed = _registration.TryArmRetainedEnrollment(_parent, plan.Description.AdministrativePosition, execution.Resources.Source!);
                    if (armed) execution.MarkArmed();
                }
                finally { Monitor.Exit(_gate); }
            }
            afterAdmission?.Invoke(armed);
            if (armed) return execution;
            execution.Dispose(); return null;
        }
        catch (Exception primary)
        {
            lock (_gate) _faulted = true;
            try { execution.Dispose(); } catch (Exception cleanup) { throw new AggregateException(primary, cleanup); }
            throw;
        }
    }
    private ApplicationEnrollmentDescription InspectRetainedExecution(RetainedEnrollmentExecution execution)
    {
        execution.CheckThread(); RequireRetainedEntryWithoutCallerLocks(execution.Resources.Source?.IsSourceGateEntered == true);
        lock (_gate)
        {
            if (!ReferenceEquals(_retainedExecution, execution) || !execution.Armed || execution.Disposed || _faulted)
                throw new InvalidOperationException("Actual armed retained execution is not active.");
        }
        try
        {
            _registration.VerifyRetainedEnrollmentParent(_parent, execution.Plan.Description.AdministrativePosition);
            if (InspectRetainedBaseline(execution.Resources.Source!, execution.Plan.Capture, execution.Plan.Evidence) != execution.Plan.Pin)
                throw new InvalidDataException("Armed baseline changed.");
            ValidateRetainedEnrollmentAuthority(execution.Resources); return execution.Plan.Description;
        }
        catch { lock (_gate) _faulted = true; throw; }
    }
    private void RequireRetainedEntryWithoutCallerLocks(bool sourceGateEntered)
    {
        if (sourceGateEntered || Monitor.IsEntered(_gate) || Monitor.IsEntered(_readGate) || _registration.IsParentGateEntered)
            throw new InvalidOperationException("Retained protocol entry cannot run under caller-held source, authority or parent gates.");
    }
    private BaselinePin InspectRetainedBaseline(EmbeddedXmlDatabase.RetainedEnrollmentSource source, FrozenMigrationCapture capture, ApplicationEnrollmentEvidence evidence)
    {
        var before = source.InspectState(); var state = before.Source;
        if (Canonical(state.Root) != _roots[evidence.SourceRootKey] || Canonical(capture.Artifact) != _roots[evidence.CaptureRootKey])
            throw new InvalidDataException("Retained source/capture mapping changed.");
        var bytes = capture.InventoryBytes;
        if (!BinaryEnvelope.ReadFile(Path.Combine(capture.Artifact, "inventory.bin")).AsSpan().SequenceEqual(bytes)) throw new InvalidDataException("Registered capture changed.");
        var inventory = LegacyMigrationVerifier.ReadArtifact(capture.Artifact);
        LegacyMigrationVerifier.ValidateHistory(Path.Combine(capture.Artifact, "data"), inventory);
        if (state.DocumentId != inventory.Identity.DocumentId || state.Sequence != inventory.Identity.CommitSequence || !state.ManifestHash.AsSpan().SequenceEqual(inventory.HeadHash))
            throw new InvalidDataException("Retained source no longer selects the captured prefix.");
        MigrationCutoverValidation.ValidateSource(state.Root, inventory);
        if (Directory.EnumerateFileSystemEntries(Path.Combine(state.Root, ".transactions", "staging")).Any() ||
            Directory.EnumerateFileSystemEntries(Path.Combine(state.Root, ".transactions")).Any(path => Path.GetFileName(path).EndsWith(".tmp", StringComparison.Ordinal)))
            throw new InvalidDataException("Retained source has unpublished state.");
        var after = source.InspectState();
        if (after.RootIdentity != before.RootIdentity || after.AdmissionIdentity != before.AdmissionIdentity || after.Source.Sequence != state.Sequence ||
            after.Source.DocumentId != state.DocumentId || !after.Source.ManifestHash.AsSpan().SequenceEqual(state.ManifestHash) ||
            !BinaryEnvelope.ReadFile(Path.Combine(capture.Artifact, "inventory.bin")).AsSpan().SequenceEqual(bytes))
            throw new InvalidDataException("Retained source/capture changed during verification.");
        var digest = Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
        return new(new(PilotRootKind.Legacy, evidence.SourceRootKey, evidence.SourceAdmissionKey, state.DocumentId, null, state.Sequence, digest), digest, before.RootIdentity, before.AdmissionIdentity);
    }

    internal sealed class RetainedEnrollmentResources(ApplicationAuthorityLifetime owner, IDisposable operation, IRetainedEnrollmentPreflightProbe? preflightProbe = null) : IDisposable
    {
        internal IRetainedEnrollmentPreflightProbe? PreflightProbe { get; } = preflightProbe;
        internal EmbeddedXmlDatabase.RetainedEnrollmentSource? Source { get; private set; }
        internal void InstallSource(EmbeddedXmlDatabase.RetainedEnrollmentSource source)
        { if (Source is not null) throw new InvalidOperationException("Source retention is already bound."); Source = source; }
        private bool _attempted;
        /// <summary>Closes source retention before authority/parent operation; unconfirmed source release retains the latter.</summary>
        public void Dispose()
        {
            if (_attempted) return; _attempted = true;
            Source?.Dispose(); operation.Dispose();
            if (owner.WhenReleased.IsFaulted) throw new IOException("Authority release is unconfirmed.", owner.WhenReleased.Exception);
            if (owner._parent.WhenReleased.IsFaulted) throw new IOException("Parent release is unconfirmed.", owner._parent.WhenReleased.Exception);
        }
    }
    internal sealed class RetainedEnrollmentPreparation : IDisposable
    {
        internal ApplicationAuthorityLifetime Owner { get; }
        internal FrozenMigrationCapture Capture { get; }
        internal ApplicationEnrollmentEvidence Evidence { get; }
        internal BaselinePin Pin { get; }
        internal ApplicationEnrollmentDescription Description { get; }
        private readonly int _thread = Environment.CurrentManagedThreadId;
        private RetainedEnrollmentResources? _resources;
        private readonly EmbeddedXmlDatabase.RetainedEnrollmentSource? _boundSource;
        internal bool IsSourceGateEntered => _boundSource?.IsSourceGateEntered == true;
        internal bool Consumed { get; private set; }
        internal bool Disposed { get; private set; }
        internal RetainedEnrollmentPreparation(ApplicationAuthorityLifetime owner, FrozenMigrationCapture capture, ApplicationEnrollmentEvidence evidence,
            BaselinePin pin, ApplicationEnrollmentDescription description, RetainedEnrollmentResources resources)
        { Owner = owner; Capture = capture; Evidence = evidence; Pin = pin; Description = description; _resources = resources; _boundSource = resources.Source; }
        internal void CheckThread() { if (_thread != Environment.CurrentManagedThreadId) throw new InvalidOperationException("Retained enrollment is caller-thread confined."); }
        internal RetainedEnrollmentResources ClaimResources()
        { CheckThread(); if (Consumed || Disposed || _resources is null) throw new InvalidOperationException("Retained plan cannot dispatch again."); Consumed = true; var resources = _resources; _resources = null; return resources; }
        internal ApplicationEnrollmentDescription Describe() { CheckThread(); ObjectDisposedException.ThrowIf(Disposed, this); return Description; }
        /// <summary>Disposes pending resources only; an actual execution owns resources transferred at dispatch.</summary>
        public void Dispose()
        {
            CheckThread(); Owner.RequireRetainedEntryWithoutCallerLocks(IsSourceGateEntered); RetainedEnrollmentResources? resources;
            lock (Owner._gate) { if (Disposed) return; Disposed = true; resources = _resources; _resources = null; }
            try { resources?.Dispose(); }
            catch { lock (Owner._gate) { Owner._faulted = true; Owner._unreleasedRetainedResources = resources; } throw; }
        }
    }
    internal sealed class RetainedEnrollmentExecution : IDisposable
    {
        private readonly ApplicationAuthorityLifetime _owner;
        internal RetainedEnrollmentPreparation Plan { get; }
        internal RetainedEnrollmentResources Resources { get; }
        internal bool Armed { get; private set; }
        internal bool Disposed { get; private set; }
        internal RetainedEnrollmentExecution(ApplicationAuthorityLifetime owner, RetainedEnrollmentPreparation plan, RetainedEnrollmentResources resources)
        { _owner = owner; Plan = plan; Resources = resources; }
        internal void CheckThread() => Plan.CheckThread();
        internal void MarkArmed() => Armed = true;
        internal ApplicationEnrollmentDescription Inspect() => _owner.InspectRetainedExecution(this);
        /// <summary>Completes actual execution retention without changing authority bytes or reopening admissions.</summary>
        public void Dispose()
        {
            CheckThread(); _owner.RequireRetainedEntryWithoutCallerLocks(Resources.Source?.IsSourceGateEntered == true);
            lock (_owner._gate) { if (Disposed) return; Disposed = true; }
            try { Resources.Dispose(); }
            catch { lock (_owner._gate) { _owner._faulted = true; _owner._unreleasedRetainedResources = Resources; } throw; }
        }
    }
}
