// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Observes uncertain publication read-only without adoption, recovery or routing authority.
// SPECIAL NOTES        : PA3 point-in-time observation only; artifact match does not establish an unknown operation ID.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

internal enum EpochInspectionStatus { NotObserved, ArtifactMatched, KnownOperationMatched, ReconciliationRequired, Unavailable }
internal sealed record EpochPublicationInspectionRequest(EpochPublicationKind Kind, string Artifact, string Bundle,
    string ExpectedInventorySha256, Guid? ExpectedOperationId = null, EpochIdentity? ExpectedDestination = null);
internal sealed record EpochObservedPublication(EpochPublicationKind Kind, Guid OperationId, Guid BackupId, EpochIdentity? SourceEpoch, EpochIdentity DestinationEpoch, ulong CommitSequence, string StorePath);
internal sealed record EpochPublicationObservation(EpochInspectionStatus Status, string Reason, EpochObservedPublication? Observed)
{
    internal bool WritersMustRemainStopped => true;
}

internal static class EpochPublicationInspector
{
    internal static EpochPublicationObservation Inspect(EpochPublicationInspectionRequest request)
    {
        ArgumentNullException.ThrowIfNull(request);
        ArgumentException.ThrowIfNullOrWhiteSpace(request.Artifact); ArgumentException.ThrowIfNullOrWhiteSpace(request.Bundle);
        if (!Enum.IsDefined(request.Kind) || request.ExpectedOperationId == Guid.Empty ||
            request.ExpectedInventorySha256 is not { Length: 64 } || !request.ExpectedInventorySha256.All(c => c is >= '0' and <= '9' or >= 'a' and <= 'f'))
            throw new ArgumentException("Inspection requires a valid role, pinned inventory hash and optional nonempty operation ID.", nameof(request));
        var artifact = Path.TrimEndingDirectorySeparator(Path.GetFullPath(request.Artifact));
        var bundle = Path.TrimEndingDirectorySeparator(Path.GetFullPath(request.Bundle));
        if (artifact.Equals(bundle, StringComparison.OrdinalIgnoreCase) || artifact.StartsWith(bundle + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) ||
            bundle.StartsWith(artifact + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)) throw new ArgumentException("Inspection roots must be disjoint.", nameof(request));
        try
        {
            BinaryEnvelope.RejectLinks(artifact);
            var inventoryBytes = BinaryEnvelope.ReadFile(Path.Combine(artifact, "inventory.bin"));
            if (Convert.ToHexString(SHA256.HashData(inventoryBytes)).ToLowerInvariant() != request.ExpectedInventorySha256) Fail("Requested inventory commitment changed.");
            var legacy = request.Kind == EpochPublicationKind.LegacyMigration ? LegacyMigrationVerifier.ReadArtifact(artifact) : null;
            var epoch = legacy is null ? EpochBackupStorage.ReadArtifact(artifact) : null;
            if (legacy is not null) LegacyMigrationVerifier.ValidateHistory(Path.Combine(artifact, "data"), legacy);
            var parent = Path.GetDirectoryName(bundle) ?? throw new InvalidDataException("Bundle has no parent."); BinaryEnvelope.RejectLinks(parent);
            FileAttributes attributes;
            try { attributes = File.GetAttributes(bundle); }
            catch (Exception error) when (error is FileNotFoundException or DirectoryNotFoundException)
            { return new(EpochInspectionStatus.NotObserved, "No bundle observed at this instant; not proof that publication never occurred.", null); }
            if ((attributes & FileAttributes.Directory) == 0) Fail("Bundle path is not a directory.");
            BinaryEnvelope.RejectLinks(bundle);
            var sidecar = legacy is not null ? "migration.bin" : "origin.bin";
            var roles = Directory.EnumerateFileSystemEntries(bundle).Take(3).ToArray(); foreach (var role in roles) BinaryEnvelope.RejectLinks(role);
            if (!roles.Select(Path.GetFileName).Order(StringComparer.Ordinal).SequenceEqual(new[] { sidecar, "store" }) ||
                !File.Exists(Path.Combine(bundle, sidecar)) || !Directory.Exists(Path.Combine(bundle, "store"))) Fail("Unexpected publication roles.");
            var root = Path.Combine(bundle, "store"); var originBytes = BinaryEnvelope.ReadFile(Path.Combine(bundle, sidecar));
            var format = BinaryEnvelope.ReadFile(Path.Combine(root, "FORMAT")); var identity = EpochCodec.RequireProfile(format, EpochProfile.ScalarWal).Identity;
            using var admission = EpochAdmission.Acquire(root, identity, profile: EpochProfile.ScalarWal);
            var writerPath = Path.Combine(root, ".transactions", "writer.lock"); BinaryEnvelope.RejectLinks(writerPath);
            using var writerProbe = new FileStream(writerPath, FileMode.Open, FileAccess.Read, FileShare.Read);
            // Bound the entire namespace before authority helpers enumerate runtime entries.
            foreach (var _ in EpochBackupStorage.Walk(root)) { }
            var binding = EpochEmptyCoordinator.ReadAuthority(root, identity, true); var data = Path.Combine(artifact, "data");
            var current = BinaryEnvelope.ReadFile(Path.Combine(root, ".transactions", "CURRENT"));
            EpochObservedPublication observed; byte[] sourceHead, sourceWalHead, destinationWalHead; BackupEntry[] files;
            if (legacy is not null)
            {
                var origin = EpochMigrationCodec.ValidateHeaders(originBytes, inventoryBytes, BinaryEnvelope.ReadFile(Path.Combine(artifact, "COMPLETE")),
                    BinaryEnvelope.ReadFile(Path.Combine(data, "FORMAT")), BinaryEnvelope.ReadFile(Path.Combine(data, ".transactions", "CONTROL")),
                    legacy.Identity.CommitSequence == 0 ? null : BinaryEnvelope.ReadFile(Path.Combine(data, ".transactions", "CURRENT")), format, current);
                observed = new(request.Kind, origin.MigrationId, origin.BackupId, null, origin.Destination, origin.CommitSequence, root);
                sourceHead = legacy.HeadHash; sourceWalHead = origin.SourceHeadWalHash; destinationWalHead = origin.DestinationHeadWalHash; files = legacy.Files;
            }
            else
            {
                var origin = EpochBackupCodec.ValidateOriginHeaders(originBytes, inventoryBytes, format, current);
                observed = new(request.Kind, origin.RestoreId, origin.BackupId, origin.Source.Identity, origin.Destination, origin.CommitSequence, root);
                sourceHead = epoch!.HeadManifestHash; sourceWalHead = epoch.HeadWalHash; destinationWalHead = origin.DestinationHeadWalHash; files = epoch.Files;
            }
            if (request.ExpectedOperationId is { } operation && operation != observed.OperationId ||
                request.ExpectedDestination is { } destination && destination != observed.DestinationEpoch) Fail("Observed operation or destination differs from the request.");
            ValidateInitial(root, observed, binding);
            foreach (var file in files.Where(file => EpochBackupRestore.IsDocumentData(file.Path))) _ = EpochBackupRestore.ReadBound(root, file);
            var previousDestination = new byte[32]; var previousSource = new byte[32]; var previousManifest = binding.BaseHash;
            for (ulong sequence = 1; sequence <= observed.CommitSequence; sequence++)
            {
                var name = ".transactions/wal/" + EpochAuthorityCodec.WalFileName(sequence); var sourceBytes = BinaryEnvelope.ReadFile(Path.Combine(data, name));
                EpochWalRecord mapped;
                if (legacy is not null)
                {
                    var old = TransactionCodec.ReadWal(Path.Combine(data, name)) ?? throw new InvalidDataException("Source WAL is incomplete.");
                    mapped = new(binding, old.Sequence, old.TransactionId, old.NodeId, old.Value, old.PreviousManifestHash, old.ManifestHash, previousDestination);
                }
                else
                {
                    var old = EpochAuthorityCodec.DecodeWal(sourceBytes, epoch!.Source);
                    if (!Same(old.PreviousWalHash, previousSource) || !Same(old.PreviousManifestHash, previousManifest)) Fail("Source epoch chain changed.");
                    mapped = old with { Binding = binding, PreviousWalHash = previousDestination };
                    var sourceGeneration = EpochScalarHistory.Generation(data, sequence);
                    if (!Same(BinaryEnvelope.ReadFile(Path.Combine(sourceGeneration, "FORMAT")), BinaryEnvelope.ReadFile(Path.Combine(data, "FORMAT"))) ||
                        !Same(BinaryEnvelope.ReadFile(Path.Combine(sourceGeneration, "GENERATION")), EpochAuthorityCodec.EncodeGeneration(new(epoch.Source, sequence, old.PreviousManifestHash, old.ManifestHash, SHA256.HashData(sourceBytes)))))
                        Fail("Source generation changed.");
                }
                var actual = BinaryEnvelope.ReadFile(Path.Combine(root, name));
                if (!Same(actual, EpochAuthorityCodec.EncodeWal(mapped))) Fail("Published operation differs from the artifact.");
                previousSource = SHA256.HashData(sourceBytes); previousDestination = SHA256.HashData(actual); previousManifest = mapped.ManifestHash;
                var generation = EpochScalarHistory.Generation(root, sequence);
                if (!Same(BinaryEnvelope.ReadFile(Path.Combine(generation, "FORMAT")), format) ||
                    !Same(BinaryEnvelope.ReadFile(Path.Combine(generation, "GENERATION")), EpochAuthorityCodec.EncodeGeneration(new(binding, sequence, mapped.PreviousManifestHash, mapped.ManifestHash, previousDestination))))
                    Fail("Published generation differs from the mapped artifact.");
            }
            if (!Same(previousSource, sourceWalHead) || !Same(previousDestination, destinationWalHead)) Fail("Head WAL commitment differs.");
            var head = EpochScalarHistory.Validate(root, admission, binding);
            if (head.Sequence != observed.CommitSequence || !Same(head.ManifestHash, sourceHead) || !Same(head.WalHash, previousDestination)) Fail("Published history is not the initial artifact prefix.");
            if (legacy is not null) LegacyMigrationVerifier.ReadArtifact(artifact); else EpochBackupStorage.ReadArtifact(artifact);
            if (!Same(inventoryBytes, BinaryEnvelope.ReadFile(Path.Combine(artifact, "inventory.bin"))) || !Same(originBytes, BinaryEnvelope.ReadFile(Path.Combine(bundle, sidecar)))) Fail("Inspection commitments changed.");
            return new(request.ExpectedOperationId is null ? EpochInspectionStatus.ArtifactMatched : EpochInspectionStatus.KnownOperationMatched,
                "Point-in-time artifact/history correlation only; no routing, recovery or write-resume authority.", observed);
        }
        catch (Exception error) when (error is InvalidDataException or FileNotFoundException or DirectoryNotFoundException or NotSupportedException)
        { return new(EpochInspectionStatus.ReconciliationRequired, error.Message, null); }
        catch (Exception error) when (error is IOException or UnauthorizedAccessException)
        { return new(EpochInspectionStatus.Unavailable, "Input or candidate unavailable; cause is not classified as contention: " + error.Message, null); }
    }
    private static void ValidateInitial(string root, EpochObservedPublication observed, EpochAuthorityBinding binding)
    {
        EpochBackupStorage.ValidateSourceLayout(root, EpochBackupStorage.FileSet(root, observed.DestinationEpoch.DocumentId, observed.CommitSequence));
        if (Directory.EnumerateFileSystemEntries(Path.Combine(root, ".transactions", "staging")).Any() ||
            Directory.EnumerateFileSystemEntries(Path.Combine(root, ".transactions")).Any(path => EpochScalarHistory.IsCurrentTemporary(Path.GetFileName(path)))) Fail("Unpublished work is present.");
        var readers = Directory.GetFileSystemEntries(Path.Combine(root, ".transactions", "readers")).Select(Path.GetFileName).Order(StringComparer.Ordinal);
        if (!readers.SequenceEqual(Enumerable.Range(0, checked((int)observed.CommitSequence + 1)).Select(n => EpochAuthorityCodec.ReaderFileName((ulong)n)))) Fail("Initial stable reader set differs.");
        if (binding.Identity != observed.DestinationEpoch) Fail("Authority identity differs.");
    }
    private static bool Same(byte[] a, byte[] b) => a.AsSpan().SequenceEqual(b);
    private static void Fail(string message) => throw new InvalidDataException(message);
}
