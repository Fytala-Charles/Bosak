// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Serializes manifests and directories with explicit bounds.
// SPECIAL NOTES        : Immutable M1 format; no transaction or crash recovery guarantee.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using Bosak.XmlDb.Core;

namespace Bosak.XmlDb.Storage;

internal sealed record FragmentEntry(ulong Id, int Length, byte[] Hash);
internal sealed record Manifest(ulong DocumentId, string DocumentUri, byte[] DirectoryHash, FragmentEntry[] Fragments);

internal static class StoreCodec
{
    internal static byte[] WriteManifest(Manifest manifest) => BinaryEnvelope.Encode("BXMF", writer =>
    {
        writer.Write(manifest.DocumentId);
        writer.Write(1UL);
        BinaryEnvelope.WriteString(writer, manifest.DocumentUri);
        writer.Write(manifest.DirectoryHash);
        writer.Write(manifest.Fragments.Length);
        foreach (var entry in manifest.Fragments)
        {
            writer.Write(entry.Id);
            writer.Write(entry.Length);
            writer.Write(entry.Hash);
        }
    });

    internal static Manifest ReadManifest(byte[] bytes) => BinaryEnvelope.Decode(bytes, "BXMF", reader =>
    {
        var document = reader.ReadUInt64();
        if (document == 0 || reader.ReadUInt64() != 1)
            throw new InvalidDataException("Invalid document or root ID.");
        var uri = BinaryEnvelope.ReadString(reader);
        var hash = reader.ReadBytes(32);
        var entries = new FragmentEntry[BinaryEnvelope.ReadCount(reader, BinaryEnvelope.MaximumNodes)];
        for (var i = 0; i < entries.Length; i++)
        {
            var id = reader.ReadUInt64();
            var length = reader.ReadInt32();
            var digest = reader.ReadBytes(32);
            if (id != (ulong)i + 1 || length < 0 || length > BinaryEnvelope.MaximumFileBytes - 64 || digest.Length != 32)
                throw new InvalidDataException("Invalid fragment entry.");
            entries[i] = new(id, length, digest);
        }
        if (entries.Length == 0)
            throw new InvalidDataException("Missing header fragment.");
        return new Manifest(document, uri, hash, entries);
    });

    internal static byte[] WriteDirectory(IReadOnlyList<StorageNode> nodes) => BinaryEnvelope.Encode("BXND", writer =>
    {
        writer.Write(nodes.Count);
        foreach (var node in nodes)
        {
            writer.Write(node.Id);
            writer.Write(node.ParentId);
            writer.Write((byte)node.Kind);
            foreach (var value in new[] { node.LocalName, node.NamespaceUri, node.Prefix, node.BaseUri })
                BinaryEnvelope.WriteString(writer, value);
            writer.Write(node.FragmentId);
            writer.Write(node.ValueOffset);
            writer.Write(node.ValueLength);
            foreach (var ids in new[] { node.Children, node.Attributes, node.Namespaces })
            {
                writer.Write(ids.Count);
                foreach (var id in ids) writer.Write(id);
            }
        }
    });

    internal static StorageNode[] ReadDirectory(byte[] bytes) => BinaryEnvelope.Decode(bytes, "BXND", reader =>
    {
        var nodes = new StorageNode[BinaryEnvelope.ReadCount(reader, BinaryEnvelope.MaximumNodes)];
        for (var i = 0; i < nodes.Length; i++)
        {
            var id = reader.ReadUInt64();
            var parent = reader.ReadUInt64();
            var kind = (StorageNodeKind)reader.ReadByte();
            var name = BinaryEnvelope.ReadString(reader);
            var ns = BinaryEnvelope.ReadString(reader);
            var prefix = BinaryEnvelope.ReadString(reader);
            var baseUri = BinaryEnvelope.ReadString(reader);
            var fragment = reader.ReadUInt64();
            var offset = reader.ReadInt32();
            var length = reader.ReadInt32();
            var children = ReadIds(reader);
            var attributes = ReadIds(reader);
            var namespaces = ReadIds(reader);
            if (id != (ulong)i + 1 || !Enum.IsDefined(kind) || offset < 0 || length < 0)
                throw new InvalidDataException("Invalid node record.");
            nodes[i] = new(id, parent, kind, name, ns, prefix, baseUri, fragment, offset, length,
                Array.AsReadOnly(children), Array.AsReadOnly(attributes), Array.AsReadOnly(namespaces));
        }
        return nodes;
    });

    private static ulong[] ReadIds(BinaryReader reader)
    {
        var count = BinaryEnvelope.ReadCount(reader, BinaryEnvelope.MaximumNodes);
        if ((long)count * 8 > reader.BaseStream.Length - reader.BaseStream.Position)
            throw new InvalidDataException("Truncated ID list.");
        var ids = new ulong[count];
        for (var i = 0; i < count; i++) ids[i] = reader.ReadUInt64();
        return ids;
    }
}
