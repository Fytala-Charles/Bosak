// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 30 October 2026
// PURPOSE              : Classifies supplied enrollment restart facts without granting live authority.
// SPECIAL NOTES        : Pure internal SR1; supplied facts do not establish ownership, freshness or acknowledgment.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 30-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal enum EnrollmentRestartFact { Unknown, Confirmed, Contradictory }
internal enum EnrollmentRestartShape { Unknown, Empty, SingleEnroll, LaterHistory }
internal enum EnrollmentRestartDecision { Refused, ReconciliationRequired, ObservedEnrolledStopped }
internal enum EnrollmentRestartReason
{
    InvalidInput, ContradictoryObservation, InvalidStructure, ChangedPosition, MissingObservation,
    EmptyReopen, UnsupportedHistory, BaselineMismatch, HostReconciliationRequired,
    InvalidSuccessor, GenerationExhausted, ExactEnrollmentObserved
}

// All records are inert supplied descriptions. No live object, delegate or path access is accepted.
internal sealed record EnrollmentRestartPosition(string Deployment, string ResourceScope, string AdministrativeRootKey,
    string AuthorityRootKey, Guid AdministrativeId, Guid AuthorityId, string MetadataDigest,
    ulong AdministrativeSequence, string AdministrativeDigest, ulong Sequence, string Digest,
    Guid Owner, ulong OwnerGeneration, Guid Baseline, ulong SelectionRevision, PilotBranch Selected);
internal sealed record EnrollmentRestartBaseline(string RootKey, string AdmissionKey, ulong DocumentId,
    ulong Sequence, string HistoryDigest, string CaptureDigest);
internal sealed record EnrollmentRestartStructure(EnrollmentRestartFact Namespace, EnrollmentRestartFact Identities,
    EnrollmentRestartFact AdministrativeHistory, EnrollmentRestartFact AuthorityHistory, EnrollmentRestartFact HeadUnchanged);
internal sealed record EnrollmentRestartHost(EnrollmentRestartFact FreshScope, EnrollmentRestartFact OwnersReacquired,
    EnrollmentRestartFact SourceExcluded, EnrollmentRestartFact PriorWorkReconciled, EnrollmentRestartFact ExecutorsDrained,
    EnrollmentRestartFact PublishersDrained, EnrollmentRestartFact ReleaseReconciled);
internal sealed record EnrollmentRestartSuccessor(Guid Session);
internal sealed record EnrollmentRestartObservations(EnrollmentRestartPosition? Expected, EnrollmentRestartPosition? Observed,
    EnrollmentRestartShape Shape, EnrollmentRestartStructure? Structure, EnrollmentRestartBaseline? EnrolledBaseline,
    EnrollmentRestartBaseline? ActualBaseline, EnrollmentRestartHost? Host, EnrollmentRestartSuccessor? Successor = null);
internal sealed record EnrollmentRestartAssessment(EnrollmentRestartDecision Decision, EnrollmentRestartReason Reason)
{
    internal bool WritersMustRemainStopped => true;
}

/// <summary>Classifies supplied enrollment restart facts without granting live authority.</summary>
internal static class EnrollmentRestartClassifier
{
    internal static EnrollmentRestartAssessment Classify(EnrollmentRestartObservations? input)
    {
        if (input is null) return Reconcile(EnrollmentRestartReason.MissingObservation);
        if (!Enum.IsDefined(input.Shape) || input.Expected is { } expected && !Valid(expected) ||
            input.Observed is { } observed && !Valid(observed) ||
            input.EnrolledBaseline is { } enrolled && !Valid(enrolled) || input.ActualBaseline is { } actual && !Valid(actual))
            return Refuse(EnrollmentRestartReason.InvalidInput);
        var structure = input.Structure;
        var structuralFacts = structure is null ? [] : new[] { structure.Namespace, structure.Identities,
            structure.AdministrativeHistory, structure.AuthorityHistory, structure.HeadUnchanged };
        var host = input.Host;
        var hostFacts = host is null ? [] : new[] { host.FreshScope, host.OwnersReacquired, host.SourceExcluded,
            host.PriorWorkReconciled, host.ExecutorsDrained, host.PublishersDrained, host.ReleaseReconciled };
        if (structuralFacts.Concat(hostFacts).Any(f => !Enum.IsDefined(f))) return Refuse(EnrollmentRestartReason.InvalidInput);
        // Known damage wins over missing facts: absence cannot mask a supplied invalid history.
        if (structuralFacts.Take(4).Contains(EnrollmentRestartFact.Contradictory)) return Refuse(EnrollmentRestartReason.InvalidStructure);
        if (structure?.HeadUnchanged == EnrollmentRestartFact.Contradictory ||
            input.Expected is not null && input.Observed is not null && input.Expected != input.Observed)
            return Refuse(EnrollmentRestartReason.ChangedPosition);
        if (hostFacts.Contains(EnrollmentRestartFact.Contradictory)) return Refuse(EnrollmentRestartReason.ContradictoryObservation);
        if (input.Observed is { } position && !Consistent(input.Shape, position)) return Refuse(EnrollmentRestartReason.ContradictoryObservation);
        if (input.Successor is { } successor)
        {
            if (successor.Session == Guid.Empty || input.Observed is { } current &&
                (current.Owner == Guid.Empty || successor.Session == current.Owner)) return Refuse(EnrollmentRestartReason.InvalidSuccessor);
            if (input.Observed?.OwnerGeneration == ulong.MaxValue) return Refuse(EnrollmentRestartReason.GenerationExhausted);
        }
        if (input.Expected is null || input.Observed is null || structure is null ||
            structuralFacts.Contains(EnrollmentRestartFact.Unknown) || input.Shape == EnrollmentRestartShape.Unknown)
            return Reconcile(EnrollmentRestartReason.MissingObservation);
        if (input.Shape == EnrollmentRestartShape.Empty) return Reconcile(EnrollmentRestartReason.EmptyReopen);
        if (input.Shape == EnrollmentRestartShape.LaterHistory) return Reconcile(EnrollmentRestartReason.UnsupportedHistory);
        if (input.EnrolledBaseline is null || input.ActualBaseline is null) return Reconcile(EnrollmentRestartReason.MissingObservation);
        if (input.EnrolledBaseline != input.ActualBaseline) return Reconcile(EnrollmentRestartReason.BaselineMismatch);
        if (host is null || hostFacts.Contains(EnrollmentRestartFact.Unknown)) return Reconcile(EnrollmentRestartReason.HostReconciliationRequired);
        return new(EnrollmentRestartDecision.ObservedEnrolledStopped, EnrollmentRestartReason.ExactEnrollmentObserved);
    }

    private static bool Consistent(EnrollmentRestartShape shape, EnrollmentRestartPosition p) => shape switch
    {
        EnrollmentRestartShape.Empty => p.Sequence == 0,
        EnrollmentRestartShape.SingleEnroll => p.Sequence == 1 && p.OwnerGeneration == 1 && p.SelectionRevision == 1 && p.Selected == PilotBranch.Source,
        EnrollmentRestartShape.LaterHistory => p.Sequence >= 2,
        _ => true
    };
    private static bool Valid(EnrollmentRestartPosition p) => Key(p.Deployment) && Key(p.ResourceScope) && Key(p.AdministrativeRootKey) &&
        Key(p.AuthorityRootKey) && !string.Equals(p.AdministrativeRootKey, p.AuthorityRootKey, StringComparison.OrdinalIgnoreCase) &&
        p.AdministrativeId != Guid.Empty && p.AuthorityId != Guid.Empty && Hash(p.MetadataDigest) && Hash(p.AdministrativeDigest) &&
        Hash(p.Digest) && Enum.IsDefined(p.Selected) && p.Sequence <= ApplicationAuthorityCodec.MaximumFrames &&
        (p.Sequence == 0 ? p.Owner == Guid.Empty && p.OwnerGeneration == 0 && p.Baseline == Guid.Empty && p.SelectionRevision == 0 :
            p.Owner != Guid.Empty && p.OwnerGeneration > 0 && p.Baseline != Guid.Empty && p.SelectionRevision > 0);
    private static bool Valid(EnrollmentRestartBaseline b) => Key(b.RootKey) && Key(b.AdmissionKey) && b.DocumentId > 0 &&
        b.Sequence <= 10_000 && Hash(b.HistoryDigest) && Hash(b.CaptureDigest);
    private static bool Key(string? value)
    {
        if (string.IsNullOrWhiteSpace(value) || value.Length > 4096 || value.Contains('\0')) return false;
        try { return new System.Text.UTF8Encoding(false, true).GetByteCount(value) <= 4096; }
        catch (System.Text.EncoderFallbackException) { return false; }
    }
    private static bool Hash(string? value) => value is { Length: 64 } && value.All(c => c is >= '0' and <= '9' or >= 'a' and <= 'f');
    private static EnrollmentRestartAssessment Refuse(EnrollmentRestartReason reason) => new(EnrollmentRestartDecision.Refused, reason);
    private static EnrollmentRestartAssessment Reconcile(EnrollmentRestartReason reason) => new(EnrollmentRestartDecision.ReconciliationRequired, reason);
}
