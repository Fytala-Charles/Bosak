// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Prototypes explicit mutable epoch access and transaction ownership without public exposure.
// SPECIAL NOTES        : PA1 internal consumer prototype only; no host routing, new format or release approval.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal enum ScalarEpochRecovery { FullHistory }
internal sealed record ScalarEpochOpenOptions(DurabilityMode Durability, ScalarEpochRecovery Recovery, EpochIdentity? ExpectedIdentity = null);

// This facade deliberately preserves coordinator exceptions. In particular an I/O failure
// is not relabeled as contention or proof of no commit. No automatic retries are performed.
internal sealed class ScalarEpochDatabase : IDisposable
{
    private readonly EpochScalarCoordinator _owner;
    private ScalarEpochDatabase(EpochScalarCoordinator owner, DurabilityMode durability) { _owner = owner; Durability = durability; }
    internal EpochIdentity Identity => _owner.Identity;
    internal ulong CommitSequence => _owner.CommitSequence;
    internal DurabilityMode Durability { get; }

    internal static ScalarEpochDatabase Open(string root, ScalarEpochOpenOptions options)
    {
        Validate(root, options);
        return OpenCore(root, options, new LocalTransactionStorage(options.Durability));
    }
    // Explicit test seam; not a proposed consumer storage/callback extension point.
    internal static ScalarEpochDatabase OpenCore(string root, ScalarEpochOpenOptions options, ITransactionStorage storage, Action<EpochScalarStage>? checkpoint = null)
    {
        Validate(root, options); ArgumentNullException.ThrowIfNull(storage);
        if (storage.Durability != options.Durability) throw new ArgumentException("Storage durability must match the explicit options.", nameof(storage));
        return new(EpochScalarCoordinator.Open(root, storage, checkpoint, options.ExpectedIdentity), storage.Durability);
    }
    private static void Validate(string root, ScalarEpochOpenOptions options)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(root); ArgumentNullException.ThrowIfNull(options);
        if (!Enum.IsDefined(options.Durability)) throw new ArgumentOutOfRangeException(nameof(options));
        if (options.Recovery != ScalarEpochRecovery.FullHistory) throw new ArgumentOutOfRangeException(nameof(options));
    }
    internal ImmutableXmlSnapshot BeginRead(int cacheBytes = 8 * 1024 * 1024) => _owner.BeginRead(cacheBytes);
    internal ScalarEpochWriteTransaction BeginTransaction() => new(_owner.BeginTransaction());
    internal EpochBackupResult CreateBackup(string destination) => _owner.CreateBackup(destination);
    /// <summary>Releases this owner's handles; independent snapshots and transactions retain their own admission.</summary>
    public void Dispose() => _owner.Dispose();
}

internal sealed class ScalarEpochWriteTransaction : IDisposable
{
    private readonly EpochScalarTransaction _transaction;
    internal ScalarEpochWriteTransaction(EpochScalarTransaction transaction) => _transaction = transaction;
    internal Guid TransactionId => _transaction.TransactionId;
    internal EpochIdentity Identity => _transaction.Identity;
    internal ulong BaseSequence => _transaction.BaseSequence;
    internal string ReadValue(ulong nodeId) => _transaction.ReadValue(nodeId);
    internal void ReplaceNodeValue(ulong nodeId, string value) => _transaction.ReplaceNodeValue(nodeId, value);
    internal ulong Commit() => _transaction.Commit();
    internal void Rollback() => _transaction.Rollback();
    /// <summary>Rolls back pending in-memory work and releases this transaction's independent snapshot.</summary>
    public void Dispose() => _transaction.Dispose();
}
