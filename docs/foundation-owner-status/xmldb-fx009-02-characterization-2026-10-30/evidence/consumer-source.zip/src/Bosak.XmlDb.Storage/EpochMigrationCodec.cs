// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Encodes fixed migration provenance and checks header context without enabling conversion.
// SPECIAL NOTES        : Pure metadata only; no I/O, admission, full-history verification or cutover capability.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 27-10-2026     | Share bounded parsing or contained verification helpers with MG2
// ===========================================================================================================================================================

using System.Globalization;
using System.Security.Cryptography;

namespace Bosak.XmlDb.Storage;

internal sealed record EpochMigrationOrigin(Guid MigrationId, Guid BackupId, byte[] InventoryHash,
    byte[] SourceFormatHash, EpochIdentity Destination, ulong CommitSequence, byte[] DestinationFormatHash,
    byte[] BaseHash, byte[] HeadManifestHash, byte[] SourceHeadWalHash, byte[] DestinationHeadWalHash);

internal static class EpochMigrationCodec
{
    internal const int OriginLength = 350;

    internal static byte[] Encode(EpochMigrationOrigin value)
    {
        Validate(value);
        return BinaryEnvelope.Encode("BXEM", writer =>
        {
            writer.Write((ushort)1); writer.Write(value.MigrationId.ToByteArray()); writer.Write(value.BackupId.ToByteArray());
            writer.Write(value.InventoryHash); writer.Write(value.SourceFormatHash);
            writer.Write(value.Destination.StoreId.ToByteArray()); writer.Write(value.Destination.EpochId.ToByteArray());
            writer.Write(value.Destination.DocumentId); writer.Write(value.CommitSequence); writer.Write(value.DestinationFormatHash);
            writer.Write(value.BaseHash); writer.Write(value.HeadManifestHash); writer.Write(value.SourceHeadWalHash); writer.Write(value.DestinationHeadWalHash);
        });
    }

    internal static EpochMigrationOrigin Decode(byte[] bytes)
    {
        if (bytes is null || bytes.Length != OriginLength) throw new InvalidDataException("Invalid migration origin length.");
        return BinaryEnvelope.Decode(bytes, "BXEM", reader =>
        {
            if (reader.ReadUInt16() != 1) throw new InvalidDataException("Unsupported migration provenance contract.");
            var value = new EpochMigrationOrigin(GuidValue(reader), GuidValue(reader), Hash(reader), Hash(reader),
                new(GuidValue(reader), GuidValue(reader), reader.ReadUInt64()), reader.ReadUInt64(),
                Hash(reader), Hash(reader), Hash(reader), Hash(reader), Hash(reader));
            Validate(value); return value;
        });
    }

    // Pure header/seal consistency, not artifact closure, WAL semantics, admission or routing proof.
    internal static EpochMigrationOrigin ValidateHeaders(byte[] origin, byte[] inventory, byte[] completion,
        byte[] sourceFormat, byte[] sourceControl, byte[]? sourceCurrent, byte[] destinationFormat, byte[] destinationCurrent)
    {
        var value = Decode(origin); var source = ReadSourceInventory(inventory);
        BackupCodec.ValidateCompletion(completion, inventory);
        BinaryEnvelope.Decode(sourceFormat, "BXDB", reader =>
        { if (reader.ReadByte() != 0) throw new InvalidDataException("Unsupported legacy FORMAT flags."); return true; });
        var identity = source.Identity;
        if (value.BackupId != identity.BackupId || value.Destination.DocumentId != identity.DocumentId ||
            value.CommitSequence != identity.CommitSequence || !Same(value.InventoryHash, SHA256.HashData(inventory)) ||
            !Same(value.SourceFormatHash, SHA256.HashData(sourceFormat)) || !Same(value.BaseHash, source.BaseHash) ||
            !Same(value.HeadManifestHash, source.HeadHash)) throw new InvalidDataException("Migration origin differs from legacy source context.");
        Entry(source, "FORMAT", sourceFormat); Entry(source, ".transactions/CONTROL", sourceControl);
        var control = Pointer(sourceControl, "BXTC");
        if (control.DocumentId != identity.DocumentId || control.Sequence != 0 || !Same(control.ManifestHash, source.BaseHash))
            throw new InvalidDataException("Legacy CONTROL differs from captured base.");
        if (identity.CommitSequence == 0)
        {
            if (sourceCurrent is not null || source.Files.Any(entry => entry.Path == ".transactions/CURRENT"))
                throw new InvalidDataException("Sealed legacy zero-head closure omits CURRENT.");
        }
        else
        {
            if (sourceCurrent is null) throw new InvalidDataException("Legacy positive head requires CURRENT.");
            Entry(source, ".transactions/CURRENT", sourceCurrent); var current = Pointer(sourceCurrent, "BXHD");
            if (current.DocumentId != identity.DocumentId || current.Sequence != identity.CommitSequence || !Same(current.ManifestHash, source.HeadHash))
                throw new InvalidDataException("Legacy CURRENT differs from capture.");
            var wal = source.Files.SingleOrDefault(entry => entry.Path == ".transactions/wal/" + identity.CommitSequence.ToString("D20", CultureInfo.InvariantCulture) + ".wal");
            if (wal is null || !Same(wal.Hash, value.SourceHeadWalHash)) throw new InvalidDataException("Legacy head WAL commitment differs.");
        }
        var profile = EpochCodec.RequireProfile(destinationFormat, EpochProfile.ScalarWal);
        if (profile.Identity != value.Destination || !Same(SHA256.HashData(destinationFormat), value.DestinationFormatHash))
            throw new InvalidDataException("Migration destination FORMAT differs.");
        var binding = EpochAuthorityBinding.Create(destinationFormat, value.BaseHash);
        var destination = EpochAuthorityCodec.DecodeCurrent(destinationCurrent, binding);
        if (destination.Sequence != value.CommitSequence || !Same(destination.ManifestHash, value.HeadManifestHash) || !Same(destination.WalHash, value.DestinationHeadWalHash))
            throw new InvalidDataException("Migration destination CURRENT differs.");
        return value;
    }

    // Decode the existing BXBI encoding with remaining-byte checks before allocations.
    internal static BackupInventory ReadSourceInventory(byte[] bytes) => BinaryEnvelope.Decode(bytes, "BXBI", reader =>
    {
        var identity = new BackupResult(GuidValue(reader), reader.ReadUInt64(), reader.ReadUInt64());
        var baseHash = Hash(reader); var headHash = Hash(reader); var count = reader.ReadInt32();
        if (identity.BackupId == Guid.Empty || identity.DocumentId == 0 || identity.CommitSequence > 10_000 ||
            identity.CommitSequence == 0 && !Same(baseHash, headHash) || count is < 1 or > 100_000 || count > Remaining(reader) / 41)
            throw new InvalidDataException("Invalid bounded legacy inventory header.");
        var files = new BackupEntry[count]; var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase); string? previous = null;
        for (var index = 0; index < count; index++)
        {
            var size = reader.ReadInt32();
            if (size is < 1 or > 512 || size > Remaining(reader) - 36) throw new InvalidDataException("Invalid bounded legacy path length.");
            var path = BinaryEnvelope.Utf8.GetString(reader.ReadBytes(size)); var length = reader.ReadInt32(); var hash = Hash(reader);
            if (path.Any(c => !char.IsAsciiLetterOrDigit(c) && c is not '/' and not '.' and not '-') ||
                path.Split('/').Any(part => part is "" or "." or ".." || part.EndsWith('.') || Device(part)) ||
                !names.Add(path) || previous is not null && StringComparer.Ordinal.Compare(previous, path) >= 0 ||
                length < 44 || length > BinaryEnvelope.MaximumFileBytes) throw new InvalidDataException("Invalid canonical legacy inventory entry.");
            files[index] = new(path, length, hash); previous = path;
        }
        return new BackupInventory(identity, baseHash, headHash, files);
    });

    private static bool Device(string part)
    {
        var stem = part.Split('.')[0].ToUpperInvariant();
        return stem is "CON" or "PRN" or "AUX" or "NUL" ||
            stem.Length == 4 && (stem.StartsWith("COM", StringComparison.Ordinal) || stem.StartsWith("LPT", StringComparison.Ordinal)) && stem[3] is >= '0' and <= '9';
    }
    private static RootPointer Pointer(byte[] bytes, string magic) => BinaryEnvelope.Decode(bytes, magic,
        reader => new RootPointer(reader.ReadUInt64(), reader.ReadUInt64(), Hash(reader)));
    private static void Entry(BackupInventory source, string path, byte[] bytes)
    {
        var file = source.Files.SingleOrDefault(entry => entry.Path == path);
        if (file is null || file.Length != bytes.Length || !Same(file.Hash, SHA256.HashData(bytes)))
            throw new InvalidDataException("Legacy header differs from inventory commitment.");
    }
    private static void Validate(EpochMigrationOrigin value)
    {
        if (value is null || value.MigrationId == Guid.Empty || value.BackupId == Guid.Empty || value.Destination is null ||
            value.Destination.StoreId == Guid.Empty || value.Destination.EpochId == Guid.Empty || value.Destination.DocumentId == 0 || value.CommitSequence > 10_000)
            throw new InvalidDataException("Invalid migration identity/sequence.");
        foreach (var hash in new[] { value.InventoryHash, value.SourceFormatHash, value.DestinationFormatHash, value.BaseHash, value.HeadManifestHash, value.SourceHeadWalHash, value.DestinationHeadWalHash })
            if (hash is null || hash.Length != 32) throw new InvalidDataException("Invalid migration digest length.");
        if (value.CommitSequence == 0 ? !Same(value.BaseHash, value.HeadManifestHash) || !Zero(value.SourceHeadWalHash) || !Zero(value.DestinationHeadWalHash)
            : Zero(value.SourceHeadWalHash) || Zero(value.DestinationHeadWalHash)) throw new InvalidDataException("Invalid migration head relation.");
    }
    private static bool Same(byte[] a, byte[] b) => a.AsSpan().SequenceEqual(b);
    private static bool Zero(byte[] value) => value.AsSpan().IndexOfAnyExcept((byte)0) < 0;
    private static long Remaining(BinaryReader reader) => reader.BaseStream.Length - reader.BaseStream.Position;
    private static Guid GuidValue(BinaryReader reader) => new(reader.ReadBytes(16));
    private static byte[] Hash(BinaryReader reader)
    { var value = reader.ReadBytes(32); if (value.Length != 32) throw new InvalidDataException("Truncated digest."); return value; }
}
