// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 29 October 2026
// PURPOSE              : Reserves an exclusive stopped application inspection mode under the real host owner.
// SPECIAL NOTES        : Opaque process-local registration; actual child reads retain parent ownership through drain.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.3   | 30-10-2026     | Validate actual paired restart children without blocking under peer gates                  |
//                      | Charles Korthout | 0.2   | 29-10-2026     | Add typed no-callback combined admission and held-parent validation                       |
//                      | Charles Korthout | 0.1   | 29-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal sealed record RestartParentIdentity(ApplicationFileIdentity Root, ApplicationFileIdentity Owner,
    ApplicationFileIdentity Metadata, ApplicationFileIdentity Journal);

/// <summary>Reserves an exclusive stopped application inspection mode under the real host owner.</summary>
internal sealed partial class EmbeddedHostLifetime
{
    private ApplicationInspectionRegistration? _applicationRegistration;

    internal ApplicationInspectionRegistration BeginApplicationInspection(HostJournalPosition expected, EmbeddedHostInspectionEvidence evidence)
    {
        ArgumentNullException.ThrowIfNull(expected); ArgumentNullException.ThrowIfNull(evidence);
        if (evidence.Context != Context || !evidence.Fresh || !evidence.AllWritersControlled || !evidence.AllPublishersControlled ||
            !evidence.PriorExecutorsExcluded || !evidence.QueueFree)
            throw new InvalidOperationException("Application inspection requires fresh bound controlled-scope exclusion.");
        lock (_appendGate)
        {
            ApplicationInspectionRegistration registration;
            lock (_gate)
            {
                ObjectDisposedException.ThrowIf(_closing, this); EnsureJournalSession();
                if (_admissions || _operations != 0 || _executorRegistration is not null || _stoppedRegistration is not null || _applicationRegistration is not null)
                    throw new InvalidOperationException("Application inspection requires exclusive stopped lifetime state.");
                if (expected != KnownPosition()) throw new InvalidOperationException("Administrative position changed.");
                registration = new(this); _applicationRegistration = registration; _operations++;
            }
            try
            {
                // Reservation prevents concurrent modes; file reads do not hold the lifetime gate.
                registration.Initialize(ReadAndVerifyKnown()); registration.RequireCurrent(this); return registration;
            }
            catch { registration.Dispose(); throw; }
        }
    }

    internal sealed class ApplicationInspectionRegistration : IDisposable
    {
        private readonly EmbeddedHostLifetime _owner;
        private bool _closing;
        private int _reads;
        private HostJournalReadResult? _history;
        internal HostJournalReadResult History => _history ?? throw new InvalidOperationException("Registration is not initialized.");
        internal void Initialize(HostJournalReadResult history)
        { if (_history is not null) throw new InvalidOperationException("Registration history is immutable."); _history = history; }
        internal ApplicationInspectionRegistration(EmbeddedHostLifetime owner) => _owner = owner;

        internal void RequireCurrent(EmbeddedHostLifetime expected)
        {
            lock (_owner._gate)
            {
                ObjectDisposedException.ThrowIf(_owner._closing || _closing, this);
                if (!ReferenceEquals(expected, _owner) || !ReferenceEquals(_owner._applicationRegistration, this) || _owner._admissions || Volatile.Read(ref _owner._journalFaulted))
                    throw new InvalidOperationException("Application registration is foreign, faulted or inactive.");
            }
        }
        internal IDisposable BeginRead(EmbeddedHostLifetime expected)
        {
            lock (_owner._gate)
            {
                RequireCurrent(expected);
                if (_owner._operations == MaximumOperations) throw new InvalidOperationException("Operation limit reached.");
                _reads++; _owner._operations++; return new ReadRegistration(this);
            }
        }
        internal bool IsParentGateEntered => Monitor.IsEntered(_owner._gate) || Monitor.IsEntered(_owner._appendGate);
        internal bool TryArmRetainedEnrollment(EmbeddedHostLifetime expected, HostJournalPosition position, EmbeddedXmlDatabase.RetainedEnrollmentSource source)
        {
            if (!Monitor.TryEnter(_owner._gate)) return false;
            try
            {
                RequireCurrent(expected);
                if (_reads != 1 || _owner._operations != 2 || position != _owner.KnownPosition())
                    throw new InvalidOperationException("Retained enrollment requires its sole actual child and exact parent position.");
                return source.TryArm();
            }
            finally { Monitor.Exit(_owner._gate); }
        }
        internal void VerifyRetainedEnrollmentParent(EmbeddedHostLifetime expected, HostJournalPosition position)
        {
            lock (_owner._appendGate)
            {
                lock (_owner._gate)
                {
                    if (!ReferenceEquals(expected, _owner) || !ReferenceEquals(_owner._applicationRegistration, this) ||
                        _reads != 1 || _owner._operations != 2 || _owner._admissions || Volatile.Read(ref _owner._journalFaulted))
                        throw new InvalidOperationException("Actual retained parent operation is not held.");
                }
                _ = _owner.ReadAndVerifyKnown();
                if (position != _owner.KnownPosition()) throw new InvalidDataException("Retained parent position changed.");
            }
        }
        internal RestartParentIdentity InspectRestartParentIdentity(EmbeddedHostLifetime expected)
        {
            RequireCurrent(expected); // Brief memory validation; all native reads below are outside lifetime gates.
            var root = ApplicationAuthorityFileIdentity.PathIdentity(_owner.Root, true);
            var owner = ApplicationAuthorityFileIdentity.HandleIdentity(_owner._owner);
            var metadata = ApplicationAuthorityFileIdentity.HandleIdentity(_owner._metadata);
            var journal = ApplicationAuthorityFileIdentity.HandleIdentity(_owner._journal);
            if (_owner._owner.Length != 0 || ApplicationAuthorityFileIdentity.PathIdentity(Path.Combine(_owner.Root, "owner.lock"), false) != owner ||
                ApplicationAuthorityFileIdentity.PathIdentity(Path.Combine(_owner.Root, "host.meta"), false) != metadata ||
                ApplicationAuthorityFileIdentity.PathIdentity(Path.Combine(_owner.Root, "journal.bin"), false) != journal)
                throw new InvalidDataException("Restart parent paths do not name the actual retained role handles.");
            return new(root, owner, metadata, journal);
        }

        internal bool TryValidateRestartCurrent(EmbeddedHostLifetime expected, HostJournalPosition position,
            EmbeddedXmlDatabase.RetainedRestartSource? source, EmbeddedXmlDatabase? sourceOwner)
        {
            if (!Monitor.TryEnter(_owner._gate)) return false;
            try
            {
                RequireCurrent(expected);
                if (_reads != 1 || _owner._operations != 2 || position != _owner.KnownPosition())
                    throw new InvalidOperationException("Restart observation requires its sole actual child and unchanged parent position.");
                return source is null || sourceOwner is not null && source.TryRequireCurrent(sourceOwner);
            }
            finally { Monitor.Exit(_owner._gate); }
        }

        private void CompleteRead()
        {
            lock (_owner._gate) { _reads--; _owner._operations--; if (_closing && _reads == 0) Complete(); }
        }
        private void Complete()
        {
            if (!ReferenceEquals(_owner._applicationRegistration, this)) return;
            _owner._applicationRegistration = null; _owner._operations--;
            if (_owner._closing && _owner._operations == 0) _owner.ReleaseHandles();
        }
        /// <summary>Stops new child reads and releases the parent mode only after actual reads finish.</summary>
        public void Dispose()
        {
            lock (_owner._gate) { if (_closing) return; _closing = true; if (_reads == 0) Complete(); }
        }
        private sealed class ReadRegistration(ApplicationInspectionRegistration owner) : IDisposable
        {
            private ApplicationInspectionRegistration? _owner = owner;
            /// <inheritdoc/>
            public void Dispose() => Interlocked.Exchange(ref _owner, null)?.CompleteRead();
        }
    }
}
