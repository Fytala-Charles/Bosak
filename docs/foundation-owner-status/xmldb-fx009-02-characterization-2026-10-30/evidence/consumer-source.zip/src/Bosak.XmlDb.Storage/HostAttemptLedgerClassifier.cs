// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 28 October 2026
// PURPOSE              : Classifies supplied host ledger evidence without persistence or execution authority.
// SPECIAL NOTES        : Pure internal HA1 model; supplied host facts are not authenticated or independently verified.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 28-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 28-10-2026     | Share context and receipt shape checks with the transition harness
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal enum HostLedgerPhase { Recorded, DispatchAuthorized, Acknowledged, Uncertain }
internal enum HostLedgerSave { ConfirmedDurable, Rejected, Unknown }
internal enum HostPublicationState { Unknown, Absent, KnownAttempt, ArtifactOnly, Foreign, Advanced, Invalid }
internal enum HostLedgerDecision
{
    ReconciliationRequired, DoNotDispatch, ReconcileLedger, EligibleToAuthorize,
    ReconcileExecutorAndPublication, DoNotReplay, NoTakeoverOrRetry, ReconcileRetainedCandidate,
    ReconcileLedgerAndPublication, RecordObservedKnownOnly, NoRetry, EligibleForFreshAttempt,
    ReobserveUnderCurrentOwnership, ObserveAuthoritativeRoute, KeepWritersStopped,
    NoReconstructionReconcileFirst, RetainAcknowledged
}
internal enum HostLedgerReason
{
    MissingEvidence, InvalidContext, InvalidEvidence, ContextMismatch, StaleRevisionOrOwner,
    StaleEvidence, LedgerNotAuthoritative, SaveRejected, SaveUnresolved, Redelivery,
    OwnershipLost, WriterExclusionUnknown, PriorExecutorReachable, ConflictingPublication,
    PublicationMismatch, ReceiptMismatch, ReceiptSaveUnresolved, KnownObservation,
    RouteUnresolved, WorkUnknown, FreshAbsence, PlanLost, PriorDispatchPossible,
    OriginalOwnerMayAuthorize, AcknowledgedReceipt
}

// Resource keys are opaque host-supplied canonical names. This model neither resolves
// paths nor authenticates backend revisions, durable commits, executor death or fencing.
internal sealed record HostLedgerContext(Guid RequestId, string Deployment, string ResourceScope,
    EpochAdministrativeAttemptDescriptor Intent, ulong Revision, Guid OwnerSession, ulong OwnerGeneration);
internal sealed record HostLedgerRecord(HostLedgerContext Context, bool Fresh, bool Authoritative,
    bool IntegrityAndRollbackChecked, HostLedgerPhase Phase, HostLedgerSave Save,
    bool OriginalPlanAvailable, bool OriginalExecutor, bool InvocationNotStarted,
    bool ReceiptPersistenceUnknown, EpochPublishedReceipt? Receipt);
internal sealed record HostPublisherEvidence(HostLedgerContext Context, bool Fresh, bool CurrentOwner,
    bool DatabaseWritersExcluded, bool AllPriorPublishersExcluded, bool QueuesDrained);
internal sealed record HostPublicationEvidence(HostLedgerContext Context, bool Fresh, HostPublicationState State,
    EpochObservedPublication? Observed);
internal sealed record HostLedgerFlow(HostLedgerContext Context, bool Fresh, bool Redelivery,
    bool RouteAcknowledgmentLost, bool WorkAccountingComplete, bool InputStillPinned, bool PriorPublicationKnown);
internal sealed record HostLedgerEvidence(HostLedgerContext? Expected, HostLedgerRecord? Record,
    HostPublisherEvidence? Ownership, HostPublicationEvidence? Publication, HostLedgerFlow? Flow);
internal sealed record HostLedgerClassification(HostLedgerDecision Decision, HostLedgerReason Reason)
{
    internal bool WritersMustRemainStopped => true;
}

internal static class HostAttemptLedgerClassifier
{
    internal static HostLedgerClassification Classify(HostLedgerEvidence? evidence)
    {
        if (evidence is not
            {
                Expected: { } expected, Record: { } record, Ownership: { } owner,
                Publication: { } publication, Flow: { } flow
            }) return Reject(HostLedgerReason.MissingEvidence);
        if (!Valid(expected)) return Reject(HostLedgerReason.InvalidContext);
        var contexts = new[] { record.Context, owner.Context, publication.Context, flow.Context };
        if (contexts.Any(context => context is null || context with { Revision = expected.Revision, OwnerSession = expected.OwnerSession, OwnerGeneration = expected.OwnerGeneration } != expected))
            return Reject(HostLedgerReason.ContextMismatch);
        if (contexts.Any(context => context != expected)) return Result(HostLedgerDecision.ReobserveUnderCurrentOwnership, HostLedgerReason.StaleRevisionOrOwner);
        if (!record.Fresh || !owner.Fresh || !publication.Fresh || !flow.Fresh)
            return Result(HostLedgerDecision.ReobserveUnderCurrentOwnership, HostLedgerReason.StaleEvidence);
        if (!Enum.IsDefined(record.Phase) || !Enum.IsDefined(record.Save) || !Enum.IsDefined(publication.State)) return Reject(HostLedgerReason.InvalidEvidence);
        if (!record.IntegrityAndRollbackChecked) return Reject(HostLedgerReason.LedgerNotAuthoritative);
        if (record.Save == HostLedgerSave.Rejected) return Result(HostLedgerDecision.DoNotDispatch, HostLedgerReason.SaveRejected);
        if (!record.Authoritative || record.Save == HostLedgerSave.Unknown) return Result(HostLedgerDecision.ReconcileLedger, HostLedgerReason.SaveUnresolved);
        if (record.Phase == HostLedgerPhase.Acknowledged ? record.Receipt is null || record.ReceiptPersistenceUnknown : record.Receipt is not null)
            return Reject(HostLedgerReason.ReceiptMismatch);
        if (record.Receipt is { } receipt && !Matches(expected.Intent, receipt.Kind, receipt.OperationId, receipt.BackupId,
            receipt.SourceEpoch, receipt.DestinationEpoch, receipt.CommitSequence, receipt.StorePath)) return Reject(HostLedgerReason.ReceiptMismatch);
        if (publication.State == HostPublicationState.KnownAttempt ? publication.Observed is null : publication.Observed is not null)
            return Reject(HostLedgerReason.PublicationMismatch);
        if (publication.Observed is { } observed && !Matches(expected.Intent, observed.Kind, observed.OperationId, observed.BackupId,
            observed.SourceEpoch, observed.DestinationEpoch, observed.CommitSequence, observed.StorePath)) return Reject(HostLedgerReason.PublicationMismatch);
        if (record.Receipt is { } acknowledged && publication.Observed is { } matched && acknowledged.DestinationEpoch != matched.DestinationEpoch)
            return Reject(HostLedgerReason.ReceiptMismatch);
        if (flow.Redelivery) return Result(HostLedgerDecision.DoNotReplay, HostLedgerReason.Redelivery);
        if (!owner.CurrentOwner) return Result(publication.State == HostPublicationState.KnownAttempt ?
            HostLedgerDecision.ReconcileRetainedCandidate : HostLedgerDecision.NoTakeoverOrRetry, HostLedgerReason.OwnershipLost);
        if (!owner.DatabaseWritersExcluded) return Reject(HostLedgerReason.WriterExclusionUnknown);
        if (publication.State is HostPublicationState.ArtifactOnly or HostPublicationState.Foreign or HostPublicationState.Advanced or HostPublicationState.Invalid)
            return Reject(HostLedgerReason.PublicationMismatch);
        if ((flow.PriorPublicationKnown && publication.State != HostPublicationState.KnownAttempt) ||
            publication.State == HostPublicationState.Absent && record.Receipt is not null)
            return Reject(HostLedgerReason.ConflictingPublication);
        if (record.ReceiptPersistenceUnknown) return Result(HostLedgerDecision.ReconcileLedgerAndPublication, HostLedgerReason.ReceiptSaveUnresolved);
        if (!owner.AllPriorPublishersExcluded || !owner.QueuesDrained)
            return Result(publication.State == HostPublicationState.KnownAttempt ? HostLedgerDecision.ReconcileRetainedCandidate :
                publication.State == HostPublicationState.Absent ? HostLedgerDecision.NoRetry : HostLedgerDecision.NoTakeoverOrRetry, HostLedgerReason.PriorExecutorReachable);
        if (flow.RouteAcknowledgmentLost) return Result(HostLedgerDecision.ObserveAuthoritativeRoute, HostLedgerReason.RouteUnresolved);
        if (!flow.WorkAccountingComplete) return Result(HostLedgerDecision.KeepWritersStopped, HostLedgerReason.WorkUnknown);
        if (!flow.InputStillPinned) return Reject(HostLedgerReason.InvalidEvidence);
        if (publication.State == HostPublicationState.KnownAttempt)
        {
            if (record.Phase == HostLedgerPhase.Recorded) return Reject(HostLedgerReason.ConflictingPublication);
            return record.Phase == HostLedgerPhase.Acknowledged ? Result(HostLedgerDecision.RetainAcknowledged, HostLedgerReason.AcknowledgedReceipt) :
                Result(HostLedgerDecision.RecordObservedKnownOnly, HostLedgerReason.KnownObservation);
        }
        // A durable receipt and a fresh unknown observation cannot establish fresh readiness.
        if (record.Phase == HostLedgerPhase.Acknowledged) return Reject(HostLedgerReason.PublicationMismatch);
        if (record.Phase == HostLedgerPhase.Recorded && record.OriginalPlanAvailable && record.OriginalExecutor && record.InvocationNotStarted)
            return Result(HostLedgerDecision.EligibleToAuthorize, HostLedgerReason.OriginalOwnerMayAuthorize);
        if (publication.State == HostPublicationState.Absent)
        {
            // Fresh retry eligibility is descriptive, never a permit, and never rearms this attempt.
            if (record.OriginalExecutor || record.OriginalPlanAvailable) return Result(HostLedgerDecision.NoRetry, HostLedgerReason.PriorDispatchPossible);
            return Result(HostLedgerDecision.EligibleForFreshAttempt, HostLedgerReason.FreshAbsence);
        }
        if (record.Phase == HostLedgerPhase.Recorded)
            return Result(HostLedgerDecision.NoReconstructionReconcileFirst, HostLedgerReason.PlanLost);
        return Result(HostLedgerDecision.ReconcileExecutorAndPublication, HostLedgerReason.PriorDispatchPossible);
    }

    internal static bool IsValidContext(HostLedgerContext? context) => context is not null && Valid(context);
    internal static bool ReceiptMatches(HostLedgerContext context, EpochPublishedReceipt? receipt) => IsValidContext(context) && receipt is not null &&
        Matches(context.Intent, receipt.Kind, receipt.OperationId, receipt.BackupId, receipt.SourceEpoch, receipt.DestinationEpoch, receipt.CommitSequence, receipt.StorePath);

    private static HostLedgerClassification Reject(HostLedgerReason reason) => Result(HostLedgerDecision.ReconciliationRequired, reason);
    private static HostLedgerClassification Result(HostLedgerDecision decision, HostLedgerReason reason) => new(decision, reason);
    private static bool Valid(HostLedgerContext context)
    {
        var intent = context.Intent;
        return context.RequestId != Guid.Empty && Text(context.Deployment) && Text(context.ResourceScope) && context.Revision != 0 &&
            context.OwnerSession != Guid.Empty && context.OwnerGeneration != 0 && intent is not null && intent.AttemptId != Guid.Empty && intent.BackupId != Guid.Empty &&
            intent.DocumentId != 0 && intent.CommitSequence <= 10_000 && Enum.IsDefined(intent.Kind) && Enum.IsDefined(intent.Durability) && intent.DestinationProfile == EpochProfile.ScalarWal &&
            Text(intent.ArtifactRoot) && Text(intent.BundleRoot) && !string.Equals(intent.ArtifactRoot, intent.BundleRoot, StringComparison.OrdinalIgnoreCase) &&
            intent.InventorySha256 is { Length: 64 } && intent.InventorySha256.All(c => c is >= '0' and <= '9' or >= 'a' and <= 'f') &&
            (intent.Kind == EpochPublicationKind.LegacyMigration ? intent.SourceEpoch is null : Identity(intent.SourceEpoch, intent.DocumentId));
    }
    private static bool Text(string? value) => !string.IsNullOrWhiteSpace(value) && value.Length <= 4096;
    private static bool Identity(EpochIdentity? identity, ulong document) => identity is not null && identity.StoreId != Guid.Empty && identity.EpochId != Guid.Empty && identity.DocumentId == document;
    private static bool Matches(EpochAdministrativeAttemptDescriptor intent, EpochPublicationKind kind, Guid operation, Guid backup,
        EpochIdentity? source, EpochIdentity? destination, ulong sequence, string storePath) =>
        kind == intent.Kind && operation == intent.AttemptId && backup == intent.BackupId && source == intent.SourceEpoch &&
        Identity(destination, intent.DocumentId) && (source is null || destination!.StoreId != source.StoreId && destination.EpochId != source.EpochId) &&
        sequence == intent.CommitSequence && storePath == Path.Combine(intent.BundleRoot, "store");
}
