// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Provides cooperating coordinator freeze and read-only state inspection for cutover acceptance.
// SPECIAL NOTES        : Internal prototype acceptance only; no persistent fence, routing service or retirement.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal sealed record EpochCutoverState(string Root, EpochAuthorityBinding Binding, EpochVerifiedHead Head, EpochAdmissionLease Admission);

internal sealed partial class EpochScalarCoordinator
{
    private Guid _cutoverFreeze;
    internal (Guid Token, EpochAdmissionLease Admission) EnterCutoverFreeze()
    {
        var admission = _admission.ForkShared(); // Before any coordinator gate; survives racing owner disposal.
        try
        {
            lock (_gate)
            {
                Available();
                if (_cutoverFreeze != Guid.Empty) throw new InvalidOperationException("Candidate is already frozen for cutover.");
                _cutoverFreeze = Guid.NewGuid(); return (_cutoverFreeze, admission);
            }
        }
        catch { admission.Dispose(); throw; }
    }
    internal void ExitCutoverFreeze(Guid token)
    { lock (_gate) { if (_cutoverFreeze == token) _cutoverFreeze = Guid.Empty; } }
    internal T InspectCutover<T>(Guid token, EpochAdmissionLease admission, Func<EpochCutoverState, T> inspect)
    {
        lock (_gate)
        {
            Available();
            if (_cutoverFreeze != token || token == Guid.Empty) throw new InvalidOperationException("Candidate cutover freeze is not active.");
            var binding = new EpochAuthorityBinding(_binding.Identity, (byte[])_binding.FormatHash.Clone(), (byte[])_binding.BaseHash.Clone());
            return inspect(new(_root, binding, new(_head.Sequence, (byte[])_head.ManifestHash.Clone(), (byte[])_head.WalHash.Clone()), admission));
        }
    }
    private void RejectCutoverMutation()
    { if (_cutoverFreeze != Guid.Empty) throw new InvalidOperationException("Candidate writes are frozen for internal cutover acceptance."); }
}
