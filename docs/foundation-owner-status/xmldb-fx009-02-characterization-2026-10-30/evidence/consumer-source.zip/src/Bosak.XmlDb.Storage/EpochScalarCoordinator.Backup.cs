// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 27 October 2026
// PURPOSE              : Captures admitted epoch history at a fixed head without enabling restore or public APIs.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 27-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2   | 27-10-2026     | Exclude callback-bearing backup during candidate cutover freeze
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

internal enum EpochBackupStage { Captured, Copied, CompleteVerified, RedoVerified, InventoryFlushed, Completed, Published }
internal sealed record EpochBackupResult(Guid BackupId, EpochIdentity Source, ulong CommitSequence);

internal sealed partial class EpochScalarCoordinator
{
    internal EpochBackupResult CreateBackup(string destination, Action<EpochBackupStage>? checkpoint = null, Action? admitted = null)
    {
        destination = BackupStorage.Destination(_root, destination);
        using var operation = _admission.ForkShared(); // Acquire outside the gate; survives racing owner disposal.
        admitted?.Invoke();
        lock (_gate)
        {
            Available();
            RejectCutoverMutation(); // No callback-bearing backup operation while cutover inspection orders owner gates.
            try
            {
                var currentBinding = EpochEmptyCoordinator.ReadAuthority(_root, _binding.Identity, true);
                if (!currentBinding.FormatHash.AsSpan().SequenceEqual(_binding.FormatHash) || !currentBinding.BaseHash.AsSpan().SequenceEqual(_binding.BaseHash))
                    throw new InvalidDataException("Epoch backup authority differs from the owned selection.");
                var head = EpochScalarHistory.Validate(_root, operation, _binding);
                if (head.Sequence != _head.Sequence || !head.ManifestHash.AsSpan().SequenceEqual(_head.ManifestHash) || !head.WalHash.AsSpan().SequenceEqual(_head.WalHash))
                    throw new InvalidDataException("Epoch backup head differs from the owned selection.");
                var current = EpochAuthorityCodec.EncodeCurrent(new(_binding, head.Sequence, head.ManifestHash, head.WalHash));
                if (!BinaryEnvelope.ReadFile(Path.Combine(_root, ".transactions", "CURRENT")).AsSpan().SequenceEqual(current))
                    throw new InvalidDataException("Capture requires canonical CURRENT at the exact head; reopen before retrying.");
                var names = EpochBackupStorage.FileSet(_root, Identity.DocumentId, head.Sequence);
                EpochBackupStorage.ValidateSourceLayout(_root, names);
                checkpoint?.Invoke(EpochBackupStage.Captured);
                BackupStorage.Preflight(destination, _storage);
                var workspace = EpochBackupStorage.Workspace(destination, _storage);
                var artifact = Path.Combine(workspace, "artifact"); var data = Path.Combine(artifact, "data");
                var entries = BackupStorage.Copy(_root, data, names, _storage);
                var inventory = new EpochBackupInventory(Guid.NewGuid(), _binding, head.Sequence, head.ManifestHash, head.WalHash, entries);
                EpochBackupStorage.ValidateData(data, inventory);
                checkpoint?.Invoke(EpochBackupStage.Copied);
                EpochBackupStorage.VerifyCopies(data, workspace, inventory, _storage, checkpoint);
                var bytes = EpochBackupCodec.EncodeInventory(inventory);
                TransactionCodec.WriteFlushed(Path.Combine(artifact, "inventory.bin"), bytes, _storage);
                checkpoint?.Invoke(EpochBackupStage.InventoryFlushed);
                TransactionCodec.WriteFlushed(Path.Combine(artifact, "COMPLETE"), EpochBackupCodec.Complete(bytes), _storage);
                EpochBackupStorage.ReadArtifact(artifact);
                checkpoint?.Invoke(EpochBackupStage.Completed);
                TransactionCodec.PublishGeneration(artifact, destination, _storage);
                checkpoint?.Invoke(EpochBackupStage.Published);
                EpochBackupStorage.RemoveWorkspace(workspace, _storage);
                return new(inventory.BackupId, Identity, head.Sequence);
            }
            catch { _faulted = true; throw; }
        }
    }
}
