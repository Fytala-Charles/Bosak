// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Opens an immutable node directory and reads fragments lazily.
// SPECIAL NOTES        : Immutable M1 format; no transaction or crash recovery guarantee.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      | Charles Korthout | 0.2   | 26-10-2026     | Add pinned commit sequence and transactional-root guard
//                      | Charles Korthout | 0.3   | 26-10-2026     | Retain shared generation lease for snapshot lifetime
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.4   | 27-10-2026     | Integrate admission-owned read-only epoch snapshots
//                      | Charles Korthout | 0.5   | 27-10-2026     | Add explicit-profile empty-chain ownership and stable lease protection
//                      | Charles Korthout | 0.6   | 27-10-2026     | Support scalar epoch materializations and verified history selection
// ===========================================================================================================================================================

using System.Security.Cryptography;
using Bosak.XmlDb.Core;

namespace Bosak.XmlDb.Storage;

/// <summary>Opens an immutable node directory and reads fragments lazily.</summary>
/// <remarks>One snapshot is used by one evaluation thread; concurrent disposal is unsupported.</remarks>
public sealed class ImmutableXmlSnapshot : IDisposable
{
    private readonly string _root;
    private readonly Manifest _manifest;
    private readonly StorageNode[] _nodes;
    private readonly int _cacheLimit;
    private readonly Dictionary<ulong, byte[]> _cache = [];
    private readonly LinkedList<ulong> _recency = [];
    private int _cacheSize;
    private bool _disposed;
    private IDisposable? _readerLease;
    private ulong _commitSequence;
    private FragmentReadMetrics _metrics;

    private ImmutableXmlSnapshot(string root, Manifest manifest, StorageNode[] nodes, int cacheLimit, int directoryBytes)
    {
        _root = root;
        _manifest = manifest;
        _nodes = nodes;
        _cacheLimit = cacheLimit;
        DirectoryBytes = directoryBytes;
        ValidateDirectory();
    }

    /// <summary>Gets the pinned embedded commit sequence, or zero for the imported base.</summary>
    public ulong CommitSequence { get { ThrowIfDisposed(); return _commitSequence; } }

    /// <summary>Gets the logical document identity.</summary>
    public ulong DocumentId { get { ThrowIfDisposed(); return _manifest.DocumentId; } }
    /// <summary>Gets the stored document URI.</summary>
    public string DocumentUri { get { ThrowIfDisposed(); return _manifest.DocumentUri; } }
    /// <summary>Gets the number of metadata records, including namespace nodes.</summary>
    public int NodeCount { get { ThrowIfDisposed(); return _nodes.Length; } }
    /// <summary>Gets the serialized directory size; managed memory overhead is additional.</summary>
    public int DirectoryBytes { get; }
    /// <summary>Gets fragment I/O counters for this snapshot.</summary>
    public FragmentReadMetrics Metrics { get { ThrowIfDisposed(); return _metrics; } }

    /// <summary>Opens and validates metadata without reading fragment payloads.</summary>
    /// <param name="databaseRoot">Store root.</param>
    /// <param name="documentId">Document identity.</param>
    /// <param name="cacheBytes">Maximum retained decoded payload bytes.</param>
    /// <returns>An owned snapshot.</returns>
    /// <exception cref="InvalidDataException">Metadata is invalid.</exception>
    public static ImmutableXmlSnapshot Open(string databaseRoot, ulong documentId = 1, int cacheBytes = 8 * 1024 * 1024)
    {
        var root = Path.GetFullPath(databaseRoot);
        if (Directory.Exists(Path.Combine(root, ".transactions")) || File.Exists(Path.Combine(root, ".transactions")))
            throw new InvalidOperationException("This store uses transactions. Open EmbeddedXmlDatabase and call BeginRead for recovery and generation selection.");
        return OpenVersion(root, documentId, 0, cacheBytes);
    }

    internal static ImmutableXmlSnapshot OpenVersion(string databaseRoot, ulong documentId, ulong sequence, int cacheBytes = 8 * 1024 * 1024)
    {
        ArgumentOutOfRangeException.ThrowIfZero(documentId);
        ArgumentOutOfRangeException.ThrowIfNegative(cacheBytes);
        var root = Path.GetFullPath(databaseRoot);
        BinaryEnvelope.Decode(BinaryEnvelope.ReadFile(Path.Combine(root, "FORMAT")), "BXDB", reader =>
        {
            if (reader.ReadByte() != 0) throw new InvalidDataException("Unsupported store flags.");
            return true;
        });
        return OpenMetadata(root, documentId, sequence, cacheBytes, expectedManifestHash: null);
    }

    // Takes ownership of the child admission, including on failure. Legacy public paths never call this bypass.
    internal static ImmutableXmlSnapshot OpenEpoch(string databaseRoot, EpochAdmissionLease admission, byte[] manifestHash, int cacheBytes) =>
        OpenAdmittedEpoch(databaseRoot, admission, manifestHash, cacheBytes, EpochProfile.ImmutableSnapshot, null);

    internal byte[] ManifestIdentity { get { ThrowIfDisposed(); return SHA256.HashData(StoreCodec.WriteManifest(_manifest)); } }
    internal string MaterializationRoot => _root;

    internal static ImmutableXmlSnapshot OpenMutableEpochGeneration(string databaseRoot, ulong sequence, EpochAdmissionLease admission,
        byte[] manifestHash, int cacheBytes, IDisposable? generationLease) =>
        OpenAdmittedEpoch(databaseRoot, admission, manifestHash, cacheBytes, EpochProfile.ScalarWal, generationLease, sequence);

    internal static ImmutableXmlSnapshot OpenMutableEpochBase(string databaseRoot, EpochAdmissionLease admission, byte[] manifestHash, int cacheBytes, IDisposable? generationLease = null) =>
        OpenAdmittedEpoch(databaseRoot, admission, manifestHash, cacheBytes, EpochProfile.ScalarWal, generationLease);

    internal static ImmutableXmlSnapshot OpenMutableEpochStaging(string root, string staging, ulong sequence, EpochAdmissionLease admission, byte[] hash) =>
        OpenAdmittedEpoch(root, admission, hash, BinaryEnvelope.MaximumFileBytes, EpochProfile.ScalarWal, null, sequence, staging);

    private static ImmutableXmlSnapshot OpenAdmittedEpoch(string databaseRoot, EpochAdmissionLease admission, byte[] manifestHash, int cacheBytes,
        EpochProfile profile, IDisposable? generationLease, ulong sequence = 0, string? staging = null)
    {
        try
        {
            ArgumentOutOfRangeException.ThrowIfNegative(cacheBytes);
            admission.ThrowIfDisposed();
            var root = Path.GetFullPath(databaseRoot);
            var comparison = OperatingSystem.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;
            if (admission.IsExclusive || admission.Profile != profile || !string.Equals(root, admission.Root, comparison) || EpochAdmission.ReadIdentity(root, profile) != admission.Identity)
                throw new InvalidDataException("Snapshot does not own shared admission to this exact epoch root.");
            var data = sequence == 0 ? root : Path.Combine(root, ".transactions", "generations", EpochAuthorityCodec.GenerationName(sequence));
            if (staging is not null)
            {
                staging = Path.GetFullPath(staging);
                if (profile != EpochProfile.ScalarWal || sequence == 0 ||
                    !string.Equals(Path.GetDirectoryName(staging), Path.Combine(root, ".transactions", "staging"), comparison) ||
                    !Guid.TryParseExact(Path.GetFileName(staging), "N", out _)) throw new InvalidDataException("Invalid epoch staging path.");
                data = staging;
            }
            if (sequence > 0 && !BinaryEnvelope.ReadFile(Path.Combine(data, "FORMAT")).AsSpan().SequenceEqual(BinaryEnvelope.ReadFile(Path.Combine(root, "FORMAT"))))
                throw new InvalidDataException("Generation FORMAT differs from admitted epoch.");
            var snapshot = OpenMetadata(data, admission.Identity.DocumentId, sequence, cacheBytes, manifestHash);
            snapshot.AttachReaderLease(new EpochSnapshotLifetime(admission, generationLease));
            return snapshot;
        }
        catch { try { generationLease?.Dispose(); } finally { admission.Dispose(); } throw; }
    }

    private sealed class EpochSnapshotLifetime(EpochAdmissionLease admission, IDisposable? generation) : IDisposable
    {
        public void Dispose() { try { generation?.Dispose(); } finally { admission.Dispose(); } }
    }

    private static ImmutableXmlSnapshot OpenMetadata(string root, ulong documentId, ulong sequence, int cacheBytes, byte[]? expectedManifestHash)
    {
        var documentPath = Path.Combine(root, "documents", documentId.ToString(System.Globalization.CultureInfo.InvariantCulture));
        var manifestBytes = BinaryEnvelope.ReadFile(Path.Combine(documentPath, "manifest.bin"));
        if (expectedManifestHash is not null && !SHA256.HashData(manifestBytes).AsSpan().SequenceEqual(expectedManifestHash))
            throw new InvalidDataException("Snapshot manifest differs from the admitted descriptor.");
        var manifest = StoreCodec.ReadManifest(manifestBytes);
        if (manifest.DocumentId != documentId) throw new InvalidDataException("Document identity mismatch.");
        var directory = BinaryEnvelope.ReadFile(Path.Combine(documentPath, "directory.bin"));
        if (!SHA256.HashData(directory).AsSpan().SequenceEqual(manifest.DirectoryHash))
            throw new InvalidDataException("Directory does not match manifest.");
        return new(root, manifest, StoreCodec.ReadDirectory(directory), cacheBytes, directory.Length) { _commitSequence = sequence };
    }

    internal void AttachReaderLease(IDisposable lease)
    {
        ThrowIfDisposed();
        if (_readerLease is not null) throw new InvalidOperationException("Snapshot already owns a lifetime lease.");
        _readerLease = lease;
    }
    /// <summary>Gets immutable metadata by stable ID.</summary>
    /// <param name="id">Node identity.</param>
    /// <returns>The node metadata.</returns>
    public StorageNode GetNode(ulong id)
    {
        ThrowIfDisposed();
        if (id == 0 || id > (ulong)_nodes.Length) throw new ArgumentOutOfRangeException(nameof(id));
        return _nodes[(int)id - 1];
    }

    /// <summary>Reads one scalar value, loading only its containing fragment.</summary>
    /// <param name="id">Node identity; element/document values require aggregation by the adapter.</param>
    /// <returns>The UTF-8 decoded scalar value.</returns>
    public string ReadValue(ulong id)
    {
        var node = GetNode(id);
        if (node.FragmentId == 0) return "";
        var payload = ReadFragment(node.FragmentId);
        try { return BinaryEnvelope.Utf8.GetString(payload, node.ValueOffset, node.ValueLength); }
        catch (System.Text.DecoderFallbackException exception) { throw new InvalidDataException("Invalid UTF-8 value.", exception); }
    }

    /// <summary>Throws when the snapshot has been disposed.</summary>
    /// <exception cref="ObjectDisposedException">The snapshot is disposed.</exception>
    public void ThrowIfDisposed() => ObjectDisposedException.ThrowIf(_disposed, this);

    /// <inheritdoc />
    public void Dispose()
    {
        _disposed = true;
        _cache.Clear();
        _recency.Clear();
        _cacheSize = 0;
        var lease = _readerLease;
        _readerLease = null;
        lease?.Dispose();
    }

    private byte[] ReadFragment(ulong id)
    {
        ThrowIfDisposed();
        if (_cache.TryGetValue(id, out var cached))
        {
            _metrics = _metrics with { CacheHits = _metrics.CacheHits + 1 };
            _recency.Remove(id);
            _recency.AddLast(id);
            return cached;
        }
        var entry = _manifest.Fragments[(int)id - 1];
        var bytes = BinaryEnvelope.ReadFile(Path.Combine(_root, "fragments", id.ToString(System.Globalization.CultureInfo.InvariantCulture) + ".bin"));
        _metrics = _metrics with
        {
            PhysicalFragmentReads = _metrics.PhysicalFragmentReads + 1,
            BytesRead = _metrics.BytesRead + bytes.Length,
            HeaderFragmentReads = _metrics.HeaderFragmentReads + (id == 1 ? 1 : 0),
            LineFragmentReads = _metrics.LineFragmentReads + (id == 1 ? 0 : 1),
        };
        if (!SHA256.HashData(bytes).AsSpan().SequenceEqual(entry.Hash))
            throw new InvalidDataException("Fragment does not match manifest.");
        var payload = BinaryEnvelope.Decode(bytes, "BXFG", reader =>
        {
            if (reader.ReadUInt64() != id || reader.ReadUInt64() != _manifest.DocumentId || reader.ReadByte() != 0)
                throw new InvalidDataException("Invalid fragment identity or codec.");
            var length = BinaryEnvelope.ReadCount(reader, BinaryEnvelope.MaximumFileBytes - 65);
            if (length != entry.Length) throw new InvalidDataException("Fragment length mismatch.");
            return reader.ReadBytes(length);
        });
        if (payload.Length <= _cacheLimit)
        {
            while (_cacheSize > _cacheLimit - payload.Length && _recency.First is { } oldest)
            {
                _cacheSize -= _cache[oldest.Value].Length;
                _cache.Remove(oldest.Value);
                _recency.RemoveFirst();
            }
            _cache.Add(id, payload);
            _recency.AddLast(id);
            _cacheSize += payload.Length;
        }
        return payload;
    }

    private void ValidateDirectory()
    {
        if (_nodes.Length == 0 || _nodes[0].Kind != StorageNodeKind.Document || _nodes[0].ParentId != 0)
            throw new InvalidDataException("Invalid document root.");
        var incoming = new int[_nodes.Length];
        var depths = new int[_nodes.Length];
        foreach (var node in _nodes)
        {
            if (node.Id != 1 && (node.ParentId == 0 || node.ParentId >= node.Id))
                throw new InvalidDataException("Invalid parent order.");
            if (node.ParentId != 0)
            {
                depths[(int)node.Id - 1] = depths[(int)node.ParentId - 1] + 1;
                if (depths[(int)node.Id - 1] > 258) throw new InvalidDataException("Node depth exceeds format limit.");
            }
            if (node.FragmentId == 0)
            {
                if (node.ValueOffset != 0 || node.ValueLength != 0 || node.Kind is not (StorageNodeKind.Document or StorageNodeKind.Element))
                    throw new InvalidDataException("Invalid structural value pointer.");
            }
            else if (node.FragmentId > (ulong)_manifest.Fragments.Length ||
                     (long)node.ValueOffset + node.ValueLength > _manifest.Fragments[(int)node.FragmentId - 1].Length)
                throw new InvalidDataException("Invalid fragment pointer.");
            if (node.Kind is not (StorageNodeKind.Document or StorageNodeKind.Element) &&
                (node.Children.Count != 0 || node.Attributes.Count != 0 || node.Namespaces.Count != 0))
                throw new InvalidDataException("Scalar node has structural links.");
            if (node.Kind != StorageNodeKind.Element && (node.Attributes.Count != 0 || node.Namespaces.Count != 0))
                throw new InvalidDataException("Only elements may own attributes or namespaces.");
            if (node.Kind is StorageNodeKind.Document or StorageNodeKind.Element && node.FragmentId != 0)
                throw new InvalidDataException("Structural nodes must not have scalar pointers.");
            CheckLinks(node, node.Children, 0);
            CheckLinks(node, node.Attributes, StorageNodeKind.Attribute);
            CheckLinks(node, node.Namespaces, StorageNodeKind.Namespace);
        }
        if (incoming[0] != 0 || incoming.Skip(1).Any(count => count != 1) ||
            _nodes[0].Children.Count(id => GetNode(id).Kind == StorageNodeKind.Element) != 1)
            throw new InvalidDataException("Disconnected or invalid XML tree.");

        var pending = new Stack<ulong>();
        pending.Push(1);
        ulong next = 1;
        while (pending.TryPop(out var id))
        {
            if (id != next++) throw new InvalidDataException("Node IDs must follow canonical preorder.");
            var node = _nodes[(int)id - 1];
            foreach (var child in node.Children.Reverse()) pending.Push(child);
            foreach (var attribute in node.Attributes.Reverse()) pending.Push(attribute);
            foreach (var ns in node.Namespaces.Reverse()) pending.Push(ns);
        }
        void CheckLinks(StorageNode owner, IReadOnlyList<ulong> ids, StorageNodeKind required)
        {
            ulong previous = 0;
            foreach (var id in ids)
            {
                if (id <= previous || id <= owner.Id || id > (ulong)_nodes.Length)
                    throw new InvalidDataException("Invalid node link or order.");
                var linked = _nodes[(int)id - 1];
                if (linked.ParentId != owner.Id || (required == 0
                    ? linked.Kind is StorageNodeKind.Attribute or StorageNodeKind.Namespace or StorageNodeKind.Document
                    : linked.Kind != required))
                    throw new InvalidDataException("Invalid node link kind or parent.");
                incoming[(int)id - 1]++;
                previous = id;
            }
        }
    }
}




