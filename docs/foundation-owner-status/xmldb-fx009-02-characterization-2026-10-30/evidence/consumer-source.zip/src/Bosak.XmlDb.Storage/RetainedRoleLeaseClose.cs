// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 30 October 2026
// PURPOSE              : Confirms injected lifetime role closure without creating release or replay authority.
// SPECIAL NOTES        : ER-003 internal test seam; production close delegation and frozen/public contracts are unchanged.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 30-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.XmlDb.Storage;

/// <summary>Injects a close outcome on actual lifetime-owned roles for internal qualification only.</summary>
internal interface IRetainedRoleLeaseClose
{
    /// <summary>Closes the actual supplied stream or injects an unconfirmed close outcome.</summary>
    /// <param name="stream">Original acquired role stream; never a reconstructed descriptor.</param>
    void Close(FileStream stream);
}

/// <summary>Confirms injected lifetime role closure without creating release or replay authority.</summary>
internal static class RetainedRoleRelease
{
    internal static void Close(FileStream stream, IRetainedRoleLeaseClose? close)
    {
        if (close is null) { stream.Dispose(); return; }
        var original = stream.SafeFileHandle;
        close.Close(stream);
        if (!original.IsClosed) throw new IOException("Lifetime role close was not confirmed: " + Path.GetFileName(stream.Name));
    }
}
