// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 26 October 2026
// PURPOSE              : Defines file and directory persistence operations for transactions.
// SPECIAL NOTES        : Experimental M2 scalar transactions; process-crash recovery only.
//
// COPYRIGHT            : Fytala
// LICENSE              : LICENSE.md
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 26-10-2026     | Creation
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.4   | 27-10-2026     | Add backup publication stages and owned-workspace cleanup seam
// ===========================================================================================================================================================

using System.ComponentModel;
using System.Runtime.InteropServices;

namespace Bosak.XmlDb.Storage;

/// <summary>Selects the filesystem barriers requested by an embedded coordinator.</summary>
public enum DurabilityMode
{
    /// <summary>Flushes file content; validated for process crashes without a power-loss promise.</summary>
    ProcessCrash = 0,
    /// <summary>Also requests directory fsync on Linux; filesystem/hardware power-loss validation is still required.</summary>
    FileAndDirectoryFlush = 1,
}

internal interface ITransactionFile : IDisposable
{
    void Write(ReadOnlySpan<byte> bytes);
    void FlushToDisk();
}

internal interface ITransactionStorage
{
    DurabilityMode Durability { get; }
    ITransactionFile CreateFile(string path);
    void CreateDirectory(string path);
    void MoveFile(string source, string destination, bool overwrite);
    void MoveDirectory(string source, string destination);
    void DeleteFile(string path);
    void DeleteDirectory(string path);
    void SyncDirectory(string path);
    void SyncFile(string path);
}

internal sealed class LocalTransactionStorage : ITransactionStorage
{
    public DurabilityMode Durability { get; }

    internal LocalTransactionStorage(DurabilityMode durability = DurabilityMode.ProcessCrash)
    {
        if (!Enum.IsDefined(durability)) throw new ArgumentOutOfRangeException(nameof(durability));
        if (durability == DurabilityMode.FileAndDirectoryFlush && !OperatingSystem.IsLinux())
            throw new PlatformNotSupportedException("Explicit directory fsync is implemented only on Linux; no fallback to weaker durability is allowed.");
        Durability = durability;
    }

    public ITransactionFile CreateFile(string path)
    {
        if (File.Exists(path)) BinaryEnvelope.RejectLinks(path);
        BinaryEnvelope.RejectLinks(Path.GetDirectoryName(path)!);
        return new LocalFile(new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None, bufferSize: 1));
    }

    public void CreateDirectory(string path) => Directory.CreateDirectory(path);
    public void MoveFile(string source, string destination, bool overwrite) => File.Move(source, destination, overwrite);
    public void MoveDirectory(string source, string destination) => Directory.Move(source, destination);
    public void DeleteFile(string path) => File.Delete(path);
    public void DeleteDirectory(string path) { BinaryEnvelope.RejectLinks(path); Directory.Delete(path, true); }

    public void SyncFile(string path)
    {
        BinaryEnvelope.RejectLinks(path);
        using var file = new FileStream(path, FileMode.Open, FileAccess.Write, FileShare.Read, bufferSize: 1);
        file.Flush(true);
    }
    public void SyncDirectory(string path)
    {
        BinaryEnvelope.RejectLinks(path);
        if (!Directory.Exists(path)) throw new DirectoryNotFoundException(path);
        if (Durability == DurabilityMode.ProcessCrash) return;
        if (!OperatingSystem.IsLinux()) throw new PlatformNotSupportedException("Directory fsync requires Linux.");
        var descriptor = OpenDirectory(path, 0); // O_RDONLY: Linux permits opening a directory for fsync.
        if (descriptor < 0) throw NativeError("open directory", path);
        Exception? failure = null;
        try
        {
            if (Fsync(descriptor) != 0) failure = NativeError("fsync directory", path);
        }
        finally
        {
            if (Close(descriptor) != 0 && failure is null) failure = NativeError("close directory", path);
        }
        if (failure is not null) throw failure;
    }

    private static IOException NativeError(string operation, string path)
    {
        var error = Marshal.GetLastPInvokeError();
        return new IOException($"Cannot {operation} '{path}' (errno {error}).", new Win32Exception(error));
    }

    [DllImport("libc", EntryPoint = "open", SetLastError = true)]
    private static extern int OpenDirectory([MarshalAs(UnmanagedType.LPUTF8Str)] string path, int flags);
    [DllImport("libc", EntryPoint = "fsync", SetLastError = true)]
    private static extern int Fsync(int descriptor);
    [DllImport("libc", EntryPoint = "close", SetLastError = true)]
    private static extern int Close(int descriptor);

    private sealed class LocalFile(FileStream stream) : ITransactionFile
    {
        public void Write(ReadOnlySpan<byte> bytes) => stream.Write(bytes);
        public void FlushToDisk() => stream.Flush(true);
        public void Dispose() => stream.Dispose();
    }
}

