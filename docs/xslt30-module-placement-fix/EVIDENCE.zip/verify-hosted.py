"""Retain and replay subsequent hosted gate receipts without replacing earlier evidence."""
import argparse,hashlib,importlib.util,json,subprocess,zipfile,io
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--run',required=True);parser.add_argument('--head',required=True);parser.add_argument('--label',required=True);args=parser.parse_args()
packet=Path(__file__).resolve().parent
root=Path('D:/Development/Bosak/.worktrees/Bosak.ModulePlacementErrors')
repo='Fytala-Charles/Bosak'
def gh(*argv):return subprocess.check_output(['gh',*argv])
workflow=json.loads(gh('api',f'repos/{repo}/actions/runs/{args.run}'))
assert workflow['status']=='completed' and workflow['conclusion']=='success' and workflow['head_sha']==args.head
artifact=next(a for a in json.loads(gh('api',f'repos/{repo}/actions/runs/{args.run}/artifacts'))['artifacts'] if a['name']=='xslt30-pinned-gate')
path=packet/(args.label+'.zip');assert not path.exists()
data=gh('api',f'repos/{repo}/actions/artifacts/{artifact["id"]}/zip');path.write_bytes(data)
assert 'sha256:'+hashlib.sha256(data).hexdigest()==artifact['digest']
spec=importlib.util.spec_from_file_location('gate',root/'tools/xslt30_gate.py');gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
policy,_,inputs,skips=gate.baseline()
with zipfile.ZipFile(io.BytesIO(data)) as archive:
 read=lambda name:json.loads(archive.read(name))
 result,run,plan=read('GATE.json'),read('RUN.json'),read('PLAN.json')
 assert result['success'] and run['success'] and result['counts']==policy['counts']
 assert not any(result['corpusDifferences'].values()) and result['sourceCorpusUnchanged'] and result['runtimeUnchanged']
 assert read('CORPUS-BEFORE.json')==inputs==read('CORPUS-AFTER.json')
 assert run['timeoutSeconds']==1200 and run['memoryLimitBytes']==8589934592
 for name in ['stdout.log','stderr.log']:assert hashlib.sha256(archive.read(name)).hexdigest()==run[name+'Sha256']
 rows=gate.reconcile(plan,run,archive.read('stdout.log').decode('utf-8-sig'),skips,policy);assert len(rows)==14601
 source=json.loads(gh('api',f'repos/{repo}/git/commits/{run["sourceCommit"]}'))
 head=json.loads(gh('api',f'repos/{repo}/git/commits/{args.head}'))
 assert source['tree']['sha']==head['tree']['sha']
 receipt=dict(success=True,runId=args.run,head=args.head,counts=result['counts'],totalCases=len(rows),
   sourceCommit=run['sourceCommit'],sourceTree=source['tree']['sha'],sourceTreeMatchesHead=True,
   elapsedSeconds=run['elapsedSeconds'],corpusUnchanged=True,runtimeUnchanged=True,artifact=artifact)
(packet/(args.label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k!='artifact'},indent=2))
