﻿from pathlib import Path
import subprocess,json,hashlib
p=Path('D:/Development/Bosak/.guard-tmp/xslt30-module-placement-fix-20261113');root=Path('D:/Development/Bosak/.worktrees/Bosak.ModulePlacementErrors')
assert not subprocess.check_output(['git','diff','50c9fd76','b435fcc5','--','src','tests','tools','.github'],cwd=root)
(p/'BASELINE-SOURCE-PARITY.json').write_bytes((json.dumps(dict(baselineBinarySource='50c9fd762fb12704dbd670b8f49f1415d70d2bfa',currentBase='b435fcc5d9c0f7261f539ade0db857c4e6f6e185',allEngineTestToolWorkflowSourcesIdentical=True),indent=2)+'\n').encode())
old=root/'docs/xslt30-analyze-string-fix/verify.py';s=old.read_text(encoding='utf-8')
for a,b in [('reported-code-exact\':447','reported-code-exact\':449'),('reported-code-mismatch\':29','reported-code-mismatch\':27'),('error-1140a','error-0170b'),('error-1145a','error-0190b'),('XTDE1140','XTSE0170'),('XTDE1145','XTSE0190'),('AnalyzeStringErrorCodeTests.cs','ModulePlacementErrorCodeTests.cs'),('allNineMatchQualified1815','allNineMatchQualified1816'),('BASELINE-IDENTITY.json','BASELINE-IDENTITY-2.json'),('BASELINE-TEST.log','BASELINE-TEST-2.log'),('Failed:\\s+4, Passed:\\s+10','Failed:\\s+8, Passed:\\s+13'),('Passed:\\s+14, Skipped','Passed:\\s+21, Skipped'),('26373','26394'),('8348','8369'),('50c9fd762fb12704dbd670b8f49f1415d70d2bfa','7584295ddaecd20a09eb22ad270f06d87af0cd86')]:s=s.replace(a,b)
start=s.index(" assert tests['allCasesPassAcrossRetainedOriginalAndDatabaseRetry']")
end=s.index(" assert re.search(r'Failed:\\s+0, Passed:\\s+90",start)
s=s[:start]+''' assert tests['allCasesPassInSingleSolutionInvocation']
 unit=transcript('UNIT.log');projects=re.findall(r'(Passed!|Failed!)\\s+- Failed:\\s+(\\d+), Passed:\\s+(\\d+), Skipped:\\s+(\\d+), Total:\\s+(\\d+).*?- ([\\w.]+)\\.dll',unit)
 assert len(projects)==10 and sum(int(r[4]) for r in projects)==26394
 assert all(r[0]=='Passed!' and r[1]=='0' and r[3]=='0' for r in projects)
'''+s[end:]
start=s.index(" for label in ['HOSTED-PR480','HOSTED-MAIN-PR480']:")
end=s.index(" assert read('ADOPTION.json')",start)
s=s[:start]+s[end:]
s=s.replace("print('Verified 14 reporting tests and failing baseline; 26,373 solution cases across localhost retry; 90 LSP; exact frozen gates; unchanged 14,601-case standalone gate; two original cases report exact local codes without aliases.')","print('Verified 21 reporting tests and 8-failure/13-pass baseline; all 26,394 solution cases and 90 LSP; exact frozen gates; unchanged 14,601-case standalone gate; two original cases report specific codes without aliases.')")
s=s.replace('Remaining 29 code differences','Remaining 27 code differences')
(root/'docs/xslt30-module-placement-fix/verify.py').write_bytes(s.encode('utf-8'))
print('Prepared baseline source-parity receipt and scoped read-only verifier.')
