﻿from pathlib import Path
import csv,json,hashlib,xml.etree.ElementTree as E
p=Path('D:/Development/Bosak/.guard-tmp/xslt30-module-placement-fix-20261113');old=p.parent/'xslt30-analyze-string-fix-20261113'
a={r['test']:r for r in csv.DictReader((p/'outcomes.csv').open(encoding='utf-8'))};b={r['test']:r for r in csv.DictReader((old/'outcomes.csv').open(encoding='utf-8'))}
changed=[n for n in a if any(a[n][k]!=b[n][k] for k in ['actual_code','identity_kind','identity_origin','catalog_code_assessment','legacy_branch'])]
expected={'error-0010x','error-0010z','error-0170a','error-0170b','error-0190a','error-0190b'};assert set(changed)==expected
assert all(a[n]['status']==b[n]['status'] and a[n]['reason']==b[n]['reason'] for n in a)
aligned=[n for n in changed if a[n]['catalog_code_assessment']!=b[n]['catalog_code_assessment']];assert set(aligned)=={'error-0170b','error-0190b'}
for n in expected-set(aligned):assert a[n]['catalog_code_assessment']==b[n]['catalog_code_assessment']=='reported-code-exact' and a[n]['legacy_branch']==b[n]['legacy_branch']=='message-code-substring'
record=dict(onlyChangedReportedIdentities=changed,casesNewlyMatchingWithoutAliases=aligned,alreadyAcceptedAlternativeCases=sorted(expected-set(aligned)),all579StatusesAndSkipReasonsUnchanged=True,remainingCodeDifferences=27,remainingUncodedReports=23,remainingToleranceBranches=50,namespaceProof='Compile-time leading local codes only; namespace identity is not independently proved.',cases=[dict(test=n,before={k:b[n][k] for k in ['actual_code','catalog_code_assessment','legacy_branch']},after={k:a[n][k] for k in ['actual_code','catalog_code_assessment','legacy_branch']},allowedErrorCodes=a[n]['allowed_error_codes']) for n in changed])
(p/'CASE-COMPARISON.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
corpus=p/'measurement/corpus/tests/misc/error';review=dict(date='2026-11-13',postImplementationFixtureReview=True,scope='Four additional cases traverse the same adopted rejection path; each already permits both generic and specific codes. No implementation/adoption scope expansion.',fixtures={n:dict(sha256=hashlib.sha256((corpus/(n+'.xsl')).read_bytes()).hexdigest(),allowedCodes=a[n]['allowed_error_codes']) for n in expected-set(aligned)})
(p/'RELATED-CASES-REVIEW.json').write_bytes((json.dumps(review,indent=2)+'\n').encode())
f=Path('D:/Development/Bosak/.worktrees/Bosak.ModulePlacementErrors/docs/xslt30-module-placement-fix/verify.py');s=f.read_text(encoding='utf-8');needle="{'error-0170b','error-0190b'}";s=s.replace(needle,"{'error-0010x','error-0010z','error-0170a','error-0170b','error-0190a','error-0190b'}");f.write_bytes(s.encode())
print(json.dumps(record,indent=2))
