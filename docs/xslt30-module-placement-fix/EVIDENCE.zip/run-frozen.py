from pathlib import Path
import subprocess,os,json,time,re
root=Path(r'D:/Development/Bosak/.worktrees/Bosak.ModulePlacementErrors');packet=Path(__file__).resolve().parent
checks=[]
for gate,args in [('QT3',['dotnet','run','--project','tests/Bosak.XPath.Conformance','-c','Release']),('QT4',['dotnet','run','--project','tests/Bosak.XPath.Conformance40','-c','Release','--','tests/qt4tests'])]:
 env=os.environ.copy();env['BOSAK_'+gate+'_DUMP_SKIPS']=str(packet/(gate+'-SKIPS.txt'))
 if gate=='QT4':env['BOSAK_QT4_GATE_ONLY']='1'
 print('Starting '+gate,flush=True);start=time.time()
 with (packet/(gate+'.log')).open('xb') as log:r=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 checks.append(dict(gate=gate,exitCode=r.returncode,seconds=time.time()-start));print(checks[-1],flush=True)
 assert r.returncode==0
 def parse(path):
  result={}
  for count,reason,body in re.findall(r'=== (\d+) skipped: (.*?) ===\r?\n(.*?)(?=^===|\Z)',path.read_text(encoding='utf-8-sig'),re.M|re.S):
   names=[n for n in body.splitlines() if n.strip()];assert len(names)==int(count)
   for name in names:assert name not in result;result[name]=reason
  return result
 actual=parse(packet/(gate+'-SKIPS.txt'));assert len(actual)==({'QT3':424,'QT4':1918}[gate])
 assert actual==parse(root/('docs/conformance/evidence/'+gate.lower()+'-skips.txt'))
 checks[-1].update(skipCount=len(actual),allSkipNamesAndReasonsUnchanged=True)
 (packet/'FROZEN-CHECKS.json').write_text(json.dumps(checks,indent=2))
