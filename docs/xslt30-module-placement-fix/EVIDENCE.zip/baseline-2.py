from pathlib import Path
import hashlib,json,subprocess,xml.etree.ElementTree as ET
packet=Path(__file__).resolve().parent;root=Path('D:/Development/Bosak/.worktrees/Bosak.ModulePlacementErrors')
directory=packet/'baseline-tests-2';directory.mkdir(exist_ok=False)
project=ET.Element('Project',Sdk='Microsoft.NET.Sdk');props=ET.SubElement(project,'PropertyGroup')
for key,value in [('TargetFramework','net10.0'),('ImplicitUsings','enable'),('Nullable','enable'),('IsPackable','false'),('AssemblyName','Bosak.Xslt.Tests')]:ET.SubElement(props,key).text=value
packages=ET.SubElement(project,'ItemGroup')
for name,version in [('Microsoft.NET.Test.Sdk','17.12.0'),('xunit','2.9.3'),('xunit.runner.visualstudio','3.0.2')]:ET.SubElement(packages,'PackageReference',Include=name,Version=version)
refs=ET.SubElement(project,'ItemGroup');prior=packet.parent/'xslt30-analyze-string-qualified-20261113'
known=json.loads((prior/'RUNTIME-HASHES.json').read_text());hashes={}
for path in sorted((prior/'runtime').glob('Bosak.*.dll')):
 if path.name=='Bosak.Xslt.Conformance.dll':continue
 digest=hashlib.sha256(path.read_bytes()).hexdigest();assert digest==known[path.name];hashes[path.name]=digest
 reference=ET.SubElement(refs,'Reference',Include=path.stem);ET.SubElement(reference,'HintPath').text=str(path)
assert len(hashes)==9
source=root/'tests/Bosak.Xslt.Tests/ModulePlacementErrorCodeTests.cs'
ET.SubElement(refs,'Compile',Include=str(source),Link='ModulePlacementErrorCodeTests.cs')
ET.indent(project);ET.ElementTree(project).write(directory/'Baseline.csproj',encoding='unicode')
with (packet/'BASELINE-TEST-2.log').open('xb') as stream:result=subprocess.run(['dotnet','test',str(directory/'Baseline.csproj'),'-c','Release'],stdout=stream,stderr=subprocess.STDOUT)
(packet/'BASELINE-IDENTITY-2.json').write_text(json.dumps(dict(engineHashes=hashes,allNineMatchQualified1816=True,regressionSourceSha256=hashlib.sha256(source.read_bytes()).hexdigest(),testExitCode=result.returncode),indent=2)+'\n',encoding='utf-8')
print('Recorded baseline result and exact test-source identity. Exit:',result.returncode)
