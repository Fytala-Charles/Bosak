﻿from pathlib import Path
import json
p=Path(__file__).resolve().parent;q=p.parent/'xslt30-module-placement-qualified-20261113';run=json.loads((q/'RUN.json').read_text(encoding='utf-8'));assert run['success'] and json.loads((q/'GATE.json').read_text(encoding='utf-8'))['success']
body=f'''The existing nested-module placement check reports generic XTSE0010 for `xsl:include` and `xsl:import`. Select XTSE0170/XTSE0190 on that rejection path, preserving every acceptance/rejection condition, other structural codes, package-parent exemptions, preprocessing and resolution behavior.

Twenty-one new regression tests cover compile-time errors before resource access, valid include/import loading and precedence, discarded directives/ancestors, foreign names and independent generic errors. Identical final sources against sealed 1.81.6 binaries give eight expected reporting failures and thirteen passes. Immutable specification adoption preceded implementation.

The 579-case error audit stays **513/0/66**. Six reports share this path: the two reviewed cases now match without aliases; four other cases already allow either code. Every status and raw skip reason is unchanged. No blanket verdict that generic codes are nonconformant and no case admission.

Validation: Release builds; **26,394 solution tests** in one invocation (8,369 XSLT included); 90 separate language-server tests; frozen QT3 **31,397/0/424** and selected qt4 **8,941/0/1,918**, with identical skip maps; complete pinned standalone **10,221/0/4,380**, all 14,601 identities replayed in {run['elapsedSeconds']:.3f}s, unchanged corpus/runtime bytes and 1,200-second/8 GiB limits. Sixteen classifier controls and seven historical dossiers verify. Full source/binary/fixture hashes, failing baseline and case ledgers are retained.

Development Core/server **1.81.7 is unpublished**. Public signatures, fixtures, skip policy, required gate/ruleset and published artifacts are unchanged. Remaining 27 code differences and 23 uncoded reports require separate review.

[Evidence dossier](https://github.com/Fytala-Charles/Bosak/blob/fix/xslt-module-placement-errors/docs/xslt30-module-placement-fix/README.md). Qualified semantic commit: `7584295ddaecd20a09eb22ad270f06d87af0cd86`; later delivery changes only documentation/evidence.
'''
(p/'PR-BODY.md').write_bytes(body.encode())
