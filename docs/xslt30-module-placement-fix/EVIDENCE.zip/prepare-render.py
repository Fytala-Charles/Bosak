﻿from pathlib import Path
p=Path('D:/Development/Bosak/.guard-tmp/xslt30-module-placement-fix-20261113');old=p.parent/'xslt30-analyze-string-fix-20261113'
s=(old/'render.cjs').read_text(encoding='utf-8').replace(str(old/'render').replace('\\','/'),str(p/'render').replace('\\','/')).replace('docs/xslt30-analyze-string-fix/DOCUMENTATION-CHECKS.json','docs/xslt30-module-placement-fix/DOCUMENTATION-CHECKS.json')
s=s.replace('const files = [',"const files = ['docs/xslt30-module-placement-fix/README.md', ",1)
needle="  if (file === 'docs/xslt30-analyze-string-fix/README.md') {"
s=s.replace(needle,"""  if (file === 'docs/xslt30-module-placement-fix/README.md') {
    if (tokens.filter(t=>t.type==='table_open').length !== 2) throw Error('Module placement tables missing');
    for (const value of ['XTSE0170','XTSE0190','26,394','8,369','10,221 passed / 0 failed / 4,380 excluded','521 attempts','not which placements','unpublished']) if (!rendered.includes(value)) throw Error('Module scope/result missing: '+value);
  }
"""+needle,1)
(p/'render.cjs').write_bytes(s.encode())
