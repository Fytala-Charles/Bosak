import subprocess,json,time
from pathlib import Path
root=Path(r'D:/Development/Bosak/.worktrees/Bosak.ModulePlacementErrors')
out=Path(r'D:/Development/Bosak/.guard-tmp/xslt30-module-placement-fix-20261113')
steps=[('BUILD',['dotnet','build','Bosak.sln','-c','Release']),('CONFORMANCE-BUILD',['dotnet','build','tests/Bosak.Xslt.Conformance','-c','Release']),('UNIT',['dotnet','test','Bosak.sln','-c','Release','--no-build']),('LSP',['dotnet','test','tests/Bosak.LanguageServer.Tests','-c','Release'])]
results=[]
for name,args in steps:
 print('Starting '+name,flush=True); start=time.time()
 with (out/(name+'.log')).open('wb') as log:r=subprocess.run(args,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(step=name,exitCode=r.returncode,seconds=time.time()-start))
 (out/'CHECKS.json').write_text(json.dumps(results,indent=2))
 print(results[-1],flush=True)
 if r.returncode:break
