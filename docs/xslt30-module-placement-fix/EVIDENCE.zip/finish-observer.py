from pathlib import Path
import json
p=Path(__file__).resolve().parent;old=p.parent/'xslt30-error-oracle-20261112'
s=(old/'validate-instrumentation.py').read_text().replace('Bosak.XsltErrorOracle','Bosak.ModulePlacementErrors');(p/'validate-instrumentation.py').write_text(s)
f=p/'REPORT.json';r=json.loads(f.read_text());r['scope']='Reported identities and entry-point call boundaries: public Compile, internal TransformObserved capture helper; not normative phases. Local code properties do not independently prove a namespace. Remaining catalog differences require fixture/spec review; no admission.';f.write_text(json.dumps(r,indent=2)+'\n')
