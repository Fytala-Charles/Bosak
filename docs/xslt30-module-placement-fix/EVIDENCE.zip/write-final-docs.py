from pathlib import Path
import json,csv,shutil
r=Path('D:/Development/Bosak/.worktrees/Bosak.ModulePlacementErrors');p=Path(__file__).resolve().parent;h=r/'docs/xslt30-module-placement-fix';q=p.parent/'xslt30-module-placement-qualified-20261113'
g=json.loads((q/'GATE.json').read_text(encoding='utf-8'));run=json.loads((q/'RUN.json').read_text(encoding='utf-8'));assert g['success'] and run['success']
summary=f'''The [module-placement reporting correction](xslt30-module-placement-fix/README.md) chooses XTSE0170/XTSE0190 only where the existing validator rejects nested include/import declarations. Other structural codes, acceptance paths, use-package/override parent exemptions, preprocessing, module resolution and legacy matching stay unchanged. Twenty-one focused tests pass; identical sources against sealed 1.81.6 binaries give eight expected reporting failures and thirteen protective passes. All 26,394 solution tests pass in one invocation, including 8,369 XSLT cases; 90 separate language-server tests pass. Frozen QT3 stays 31,397/0/424 and gated qt4 stays 8,941/0/1,918 (including 11 experimental passes), with identical skip names/reasons. The complete pinned standalone gate stays 10,221/0/4,380 in {run['elapsedSeconds']:.3f} seconds, all 14,601 case identities accounted for and unchanged corpus/runtime bytes under the original 1,200-second/8 GiB limits.

The same 579-case error audit remains 513/0/66. Six leading-code reports change on the shared placement path: error-0170b/0190b now match without aliases; four related cases already allow either the generic or specific code. Only two catalog-code assessments improve; no new pass or admission is claimed. Remaining 27 reported-code differences, 23 uncoded reports and 55 overlapping static-label/execute-call observations still require review. Specific diagnostics are chosen without blanket normative defect verdicts; generic/specific rules can overlap. Development Core/server 1.81.7 remains unpublished; no public signature, fixture, exclusion, gate-budget or ruleset change.

'''
for name in ['ARCHITECTURE','INTEGRATION','FEATURE_REQUESTS']:
 f=r/('docs/'+name+'.md');data=f.read_bytes();start=data.index(b'The [module-placement reporting correction]');end=data.index(b'\n\n',start);assert b'pending' in data[start:end];data=data[:start]+summary.rstrip().encode()+data[end:];data=data.replace(b'Module-placement reporting checkpoint',b'Module-placement reporting qualification',1)
 if name=='ARCHITECTURE':data=data.replace(b'Core/server development metadata is now **1.81.6**, an unpublished follow-up for the [scoped analyze-string reporting correction](xslt30-analyze-string-fix/README.md).',b'Core/server development metadata is now **1.81.7**, an unpublished follow-up for the [module-placement reporting correction](xslt30-module-placement-fix/README.md).',1)
 if name=='INTEGRATION':data=data.replace(b'Core/server development metadata is 1.81.6 for the unpublished [scoped analyze-string reporting correction](xslt30-analyze-string-fix/README.md);',b'Core/server development metadata is 1.81.7 for the unpublished [module-placement reporting correction](xslt30-module-placement-fix/README.md);',1)
 f.write_bytes(data)
for name in ['AGENT_HANDOVER','IMPLEMENTATION_STATUS','DEVELOPMENT_HISTORY']:
 f=r/('docs/'+name+'.md');data=f.read_bytes();lines=data.splitlines(keepends=True);prefix=b''.join(lines[:6]);assert b'pending' in prefix
 f.write_bytes(('# Module-placement reporting qualification — 13 November 2026\n\n'+summary+'Clean semantic source `7584295ddaecd20a09eb22ad270f06d87af0cd86`, based on PR #481 merge `b435fcc5d9c0f7261f539ade0db857c4e6f6e185`; worktree `.worktrees/Bosak.ModulePlacementErrors`. Later delivery changes only documentation/evidence. Preserve the original dirty owner checkout and all sealed historical dossiers.\n\n').encode()+data[len(prefix):])
f=r/'docs/CONFORMANCE.md';data=f.read_bytes();needle=b'## Scoped analyze-string reporting follow-up';assert needle in data;f.write_bytes(data.replace(needle,('## Scoped module-placement reporting follow-up\n\n'+summary).encode()+needle,1))
f=r/'docs/DOCUMENTATION_RENDERER_TEST.md';f.write_bytes(('# Module-placement renderer check — 13 November 2026\n\nThe [scoped reporting receipt](xslt30-module-placement-fix/DOCUMENTATION-CHECKS.json) checks rendered case/verification tables, exclusion links and unchanged historical/Fytala content. No screenshot/PDF acceptance is asserted.\n\n').encode()+f.read_bytes())
comparison=json.loads((p/'CASE-COMPARISON.json').read_text(encoding='utf-8'))
rows='\n'.join('| '+item['test']+' | '+item['before']['actual_code']+' | '+item['after']['actual_code']+' | '+('New direct match; alias no longer needed' if item['test'] in comparison['casesNewlyMatchingWithoutAliases'] else 'Both reports already allowed by catalog')+' |' for item in comparison['cases'])
readme=f'''# Scoped module-placement reporting — 13 November 2026

The existing validator now reports `XTSE0170` for rejected nested `xsl:include` and `XTSE0190` for rejected nested `xsl:import`. This changes the selected error code, not which placements are accepted or rejected. Other structural errors keep `XTSE0010`; existing use-package/override parent exemptions and earlier checks remain unchanged. Preprocessing, module acquisition, legacy matching and public signatures are unchanged.

[Adoption evidence](ADOPTION.json) was recorded before implementation and pins [XSLT 3.0 Recommendation 8 June 2017](https://www.w3.org/TR/2017/REC-xslt-30-20170608/), sections 2.14, 3.11.2, 3.11.3 and 3.13. The original fixtures contain nested module directives in ordinary named templates. Specific placement codes are explicitly defined, but generic context rules overlap and some catalogs allow both. This is a scoped reporting alignment, not a blanket verdict that generic reports are nonconformant. No intentional specification deviation is adopted.

| Original pinned case | Before | After | Assessment |
|---|---|---|---|
{rows}

All six cases still fail at the public compile call as before. Their leading local error codes are observed; namespace identity is not independently proved. The complete original error-set measurement remains **513 passed / 0 failed / 66 excluded** across all 579 identities, with identical raw skip reasons. Only two catalog-code assessments improve. Four additional matcher attempts are expected because four allowed-alternative cases now try their second listed code: the unchanged matcher records 521 attempts, 504 exceptions and 9 normal results. Observer removal exactly restores production runner source; its nine candidate engine DLLs match the qualified runtime.

| Verification | Result |
|---|---|
| Identical final tests against sealed 1.81.6 binaries | 8 expected reporting failures; 13 protective/happy-path passes |
| Candidate focused tests | 21 passed; no failures/skips |
| Complete solution, ten projects | 26,394 passed in one invocation, including 8,369 XSLT cases |
| Separate language-server tests | 90 passed |
| Frozen QT3 | 31,397 passed / 0 failed / 424 excluded; exact skip map unchanged |
| Selected qt4 | 8,941 passed / 0 failed / 1,918 excluded; includes 11 experimental passes; exact skip map unchanged |
| Complete pinned standalone XSLT 3.0 | **10,221 passed / 0 failed / 4,380 excluded**, all 14,601 identities accounted for |
| Independent classifier controls | 16 passed |

The solution build has zero errors, eight pre-existing code warnings and two NU1900 warnings because package advisory metadata could not be fetched. No warning points to the changed source or new tests. Original logs are retained.

Tests cover direct/deep/unused-template placement and rejection before resolver access; valid include/import acquisition and import precedence; use-when removal of directives/ancestors; foreign-namespace literal elements; unrelated structural declarations and missing top-level href. An initial test-fixture attempt had seven extra XML-declaration expectation failures (15 failed/6 passed); explicit serialization corrected those before the identical final baseline/candidate comparison. The initial source/log/identity remain retained. Its console-print encoding error also remains recorded separately from the actual caught test results.

Clean source commit **7584295ddaecd20a09eb22ad270f06d87af0cd86** is based on merged PR #481 **b435fcc5d9c0f7261f539ade0db857c4e6f6e185**. Corpus `w3c/xslt30-test@fddf1cf920087e791f13315d68dfbe874d97dc56`, Windows/Release, Legacy/Xslt30, basic/non-schema-aware. The full gate completes in **{run['elapsedSeconds']:.3f} seconds**, under unchanged 1,200-second/8 GiB bounds, with no missing/unselected cases and unchanged owned/source corpus and runtime bytes. Timing is diagnostic, not performance acceptance. Runtime binaries remain in the local qualified packet; hashes, transcripts, case ledgers and source snapshots are archived. Later delivery changes only documentation/evidence.

Development Core/server **1.81.7 remains unpublished**. Published Core 1.81.2 and extension 0.2.6 are unchanged. All [4,380 named exclusions and reasons](skips.csv) remain unchanged; the 579-case error set is still excluded from the required gate. The [prior skip explanation table](../xslt30-error-audit/README.md) describes the same 66 targeted exclusions. Remaining 27 reported-code differences and 23 uncoded reports (50 tolerance branches), plus 55 overlapping static-label/execute-call observations, require separate review. Public `Compile` and internal `TransformObserved` call boundaries are not normative phase verdicts. No admission, fixture/skip/ruleset change, publication or complete-conformance claim.

[Results](RESULTS.json), [six-case comparison](CASE-COMPARISON.json), [related-fixture review](RELATED-CASES-REVIEW.json), [evidence](EVIDENCE.zip), [manifest](MANIFEST.json), [renderer receipt](DOCUMENTATION-CHECKS.json). Run `python docs/xslt30-module-placement-fix/verify.py` to replay the baseline, all original error outcomes, controls, frozen gates and all 14,601 standalone cases. Earlier sealed dossiers, including failed hosted attempts, remain unchanged.
'''
(h/'README.md').write_bytes(readme.encode('utf-8'))
shutil.copyfile(p/'FINAL-verify.py',h/'verify.py')
for name in ['REPORT.json','CASE-COMPARISON.json','RELATED-CASES-REVIEW.json']:shutil.copyfile(p/name,h/name)
results=dict(date='2026-11-13',sourceCommit=run['sourceCommit'],sourceBaseCommit='b435fcc5d9c0f7261f539ade0db857c4e6f6e185',developmentVersion='1.81.7',published=False,counts=g['counts'],totalCases=14601,elapsedSeconds=run['elapsedSeconds'],solutionTests=26394,xsltTestsIncluded=8369,languageServerTests=90,focusedTests=21,baselineExpectedFailures=8,baselinePasses=13,targetedErrorCounts={'Passed':513,'Failed':0,'Skipped':66},reportedCodesChanged=6,catalogCodeAssessmentsImproved=2,admittedCases=0)
(h/'RESULTS.json').write_bytes((json.dumps(results,indent=2)+'\n').encode())
rows=list(csv.DictReader((q/'outcomes.csv').open(encoding='utf-8')))
with (h/'skips.csv').open('w',newline='',encoding='utf-8') as stream:
 writer=csv.DictWriter(stream,fieldnames=list(rows[0]),lineterminator='\n');writer.writeheader();writer.writerows(row for row in rows if row['status']=='Skipped')
print('Final measured documentation synchronized.')
