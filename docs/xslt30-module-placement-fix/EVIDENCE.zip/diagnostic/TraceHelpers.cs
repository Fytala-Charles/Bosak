// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 12 November 2026
// PURPOSE              : Records diagnostic error identities and call boundaries without changing test decisions.
// SPECIAL NOTES        : Diagnostic-only observer; not part of the production conformance runner.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 12-11-2026     | Creation                                                                                 |
//                      | Charles Korthout | 0.2   | 12-11-2026     | Match the existing runner namespace for the diagnostic partial class.                    |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

namespace Bosak.Xslt.Conformance;

partial class Program
{
    private static string _auditCase = "";
    private static string _auditPhase = "unselected";

    private static object AuditError(Exception error)
    {
        string? Property(string name)
        {
            try { return error.GetType().GetProperty(name)?.GetValue(error) as string; }
            catch (Exception) { return null; }
        }
        return new { type = error.GetType().FullName, message = error.Message,
            codeLocalName = Property("CodeLocalName"), codeNamespaceUri = Property("CodeNamespaceUri"),
            errorCode = Property("ErrorCode") };
    }

    private static void AuditWrite(string kind, object data)
    {
        try { Console.Error.WriteLine("AUDIT " + System.Text.Json.JsonSerializer.Serialize(
            new { kind, caseName = _auditCase, phase = _auditPhase, data })); }
        catch (Exception) { /* An observation failure must not change the legacy decision. */ }
    }

    private static void AuditException(Exception error)
    {
        try
        {
            var chain = new List<object>();
            Exception? current = error;
            while (current != null && chain.Count < 16)
            {
                chain.Add(AuditError(current));
                current = current.InnerException;
            }
            AuditWrite("exception", new { chain, truncated = current != null });
        }
        catch (Exception) { /* Preserve the original exception-handling path. */ }
    }

    private static bool AuditMatch(string? expected, Exception error, string branch, bool accepted)
    {
        try { AuditWrite("match", new { expected, branch, accepted, error = AuditError(error) }); }
        catch (Exception) { /* Return the original decision even if tracing fails. */ }
        return accepted;
    }

    private static void AuditRunControls()
    {
        const string standard = "http://www.w3.org/2005/xqt-errors";
        var controls = new (string Name, string Expected, Exception Error, bool Legacy, string Exact)[]
        {
            ("leading-exact", "XTSE0010", new InvalidOperationException("XTSE0010: invalid content"), true, "reported-code-exact"),
            ("leading-wrong", "XTSE0010", new InvalidOperationException("XTSE0090: invalid attribute"), false, "reported-code-mismatch"),
            ("coded-alias", "XTSE0650", new InvalidOperationException("XTDE0040: missing template"), true, "reported-code-mismatch"),
            ("uncoded-alias", "XTSE0150", new InvalidOperationException("Expected xsl:stylesheet or xsl:transform"), true, "uncoded"),
            ("mentioned-expected", "XTSE0010", new InvalidOperationException("XTSE0090: description mentions XTSE0010"), true, "reported-code-mismatch"),
            ("wrong-namespace", "XTSE0010", new Bosak.XPath.Runtime.Vm.XPathErrorException("urn:wrong", "XTSE0010", null, "wrong namespace"), true, "qname-mismatch"),
            ("structured-exact", "FOER0000", new Bosak.XPath.Runtime.Vm.XPathErrorException(standard, "FOER0000", null, "correct identity"), true, "qname-exact"),
            ("structured-description", "XTSE0010", new Bosak.XPath.Runtime.Vm.XPathErrorException(standard, "FOER0000", null, "description mentions XTSE0010"), true, "qname-mismatch"),
            ("uncoded-unrelated", "XTSE0010", new InvalidOperationException("uncoded unrelated failure"), false, "uncoded"),
            ("wildcard", "*", new InvalidOperationException("any error"), true, "wildcard"),
            ("custom-qname", "Q{urn:custom}BOOM00", new Bosak.XPath.Runtime.Vm.XPathErrorException("urn:custom", "BOOM00", null, "custom identity"), true, "qname-exact"),
            ("retired-code", "XTSE0800", new InvalidOperationException("XTSE0085: reserved namespace"), true, "reported-code-mismatch"),
            ("recoverable-code", "XTRE0270", new InvalidOperationException("XTSE0270: conflicting rules"), true, "reported-code-mismatch"),
            ("known-parser-wrapper", "XPST0003", new Bosak.XPath.Parser.XPathParseException("invalid syntax", 4), true, "reported-code-exact"),
            ("fake-parser-wrapper", "XPST0003", new InvalidOperationException("Parse error at position 4: XPST0003: invalid syntax"), true, "uncoded"),
            ("unspecified-code", "XXXX9999", new InvalidOperationException("any error"), true, "wildcard")
        };
        int failures = 0;
        foreach (var control in controls)
        {
            _auditCase = control.Name;
            _auditPhase = "control";
            bool accepted = ErrorCodeMatches(control.Expected, control.Error);
            AuditWrite("control", new { expected = control.Expected, legacyExpected = control.Legacy,
                legacyActual = accepted, exactExpected = control.Exact, error = AuditError(control.Error) });
            if (accepted != control.Legacy) failures++;
        }
        Console.WriteLine($"Oracle observation controls: {controls.Length - failures} passed / {failures} failed");
        Environment.ExitCode = failures == 0 ? 0 : 1;
    }
}
