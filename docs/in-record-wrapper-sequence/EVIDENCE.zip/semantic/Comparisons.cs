// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 15 November 2026
// PURPOSE              : Compares wrapping errors, identities, mutation and record-pump lifetime behavior
// SPECIAL NOTES        : Unit tests verifying correctness of the underlying implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 15-11-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using System.Reflection;
using System.Xml.Linq;
using Bosak.XPath.Core.Xdm;

internal static class Comparisons {
    internal static int Run(){
        int cases=0;
        foreach(int shape in new[]{0,1,2,3})foreach(bool marked in new[]{false,true})foreach(string fault in new[]{"none","acquire","move","current","null"}){
            var left=Trace(false,shape,marked,fault);var right=Trace(true,shape,marked,fault);
            Equal(left,right,$"trace/{shape}/{marked}/{fault}");cases++;
        }
        foreach(string scenario in new[]{"children","all-children","attributes","named-attribute","namespaces","mutate-children","mutate-attributes","after-advance","after-finish","second-record","partial-advance","reader-owner"}){
            Equal(Lifetime(false,scenario),Lifetime(true,scenario),scenario);cases++;
        }
        return cases;
    }
    private static string Trace(bool candidate,int shape,bool marked,string fault){
        using var f=new Fixture();var children=f.Children();
        XdmValue[] values=shape switch{0=>Array.Empty<XdmValue>(),1=>new[]{children[0]},2=>new[]{XdmValue.FromString("skip"),children[0],XdmValue.FromBoolean(true),children[1]},_=>new[]{children[0],XdmValue.FromNode(f.Record)}};
        Source source=marked?new MarkedSource(values,fault):new Source(values,fault);
        var input=XdmSequence.FromSource(source);var seq=candidate?f.Candidate(input):f.Baseline(input);var log=new List<string>();
        string Stamp()=>$"{source.Gets},{source.Moves},{source.Reads},{source.Disposals}";
        log.Add("made:"+Stamp()+":marked="+(seq is ISinglePassSequence));log.Add("length:"+seq.TryGetLength(out int len)+":"+len);
        var e=seq.GetEnumerator();log.Add("acquired:"+Stamp()+":"+Describe(e.Current,f));
        for(int i=0;i<6;i++)try{log.Add("move:"+e.MoveNext()+":"+Describe(e.Current,f)+":"+Stamp());}catch(Exception error){log.Add("error:"+Error(error)+":"+Describe(e.Current,f)+":"+Stamp());}
        var second=seq.GetEnumerator();log.Add("second-current:"+Describe(second.Current,f));
        for(int i=0;i<3;i++)try{log.Add("second:"+second.MoveNext()+":"+Describe(second.Current,f)+":"+Stamp());}catch(Exception error){log.Add("second-error:"+Error(error)+":"+Stamp());}
        return string.Join("|",log);
    }
    private static string Lifetime(bool candidate,string scenario){
        using var f=new Fixture();Func<XdmSequence,IXdmSequence> make=candidate?f.Candidate:f.Baseline;var record=f.Record;var inner=f.Inner;
        if(scenario=="second-record"){
            Fixture.Require(f.Advance(),"second record");record=f.CurrentRecord;
            inner=(IXdmNode)record.GetType().GetField("_inner",BindingFlags.NonPublic|BindingFlags.Instance)!.GetValue(record)!;
        }
        var input=scenario switch{
            "attributes" or "mutate-attributes"=>inner.Attributes(),"named-attribute"=>inner.Attributes("id",""),
            "namespaces"=>inner.Axis(XdmAxis.Namespace),"all-children"=>inner.Children(XdmNodeKind.All),_=>inner.Children(XdmNodeKind.Element)};
        var seq=scenario=="second-record"?Fixture.ForRecord(record,input,candidate):make(input);
        if(scenario=="mutate-children")f.Element.Add(new XElement("late","new"));
        if(scenario=="mutate-attributes")f.Element.SetAttributeValue("late","new");
        if(scenario is "after-advance" or "after-finish")Fixture.Require(f.Advance(),"advance after construction");
        if(scenario=="after-finish")Fixture.Require(!f.Advance(),"finish pump");
        var values=Pull(seq);var snapshots=values.Select(v=>Describe(v,f)).ToList();
        foreach(var value in values)Fixture.Require(Fixture.RecordIndex(value.NodeValue)==(scenario=="second-record"?1:0),"captured record index");
        var replay=Pull(seq);Fixture.Require(values.Count==replay.Count,"replay count");
        for(int i=0;i<values.Count;i++){
            bool sameReference=ReferenceEquals(values[i].NodeValue,replay[i].NodeValue),sameNode=values[i].NodeValue.IsSameNode(replay[i].NodeValue);
            snapshots.Add("replay-identity:"+sameReference+":"+sameNode);
            if(scenario!="namespaces")Fixture.Require(sameReference&&sameNode,"cached wrapper and node identity");
        }
        // Compare ordinary public axis results for the unmutated real record cases.
        if(scenario is "children" or "all-children" or "attributes" or "named-attribute" or "namespaces"){
            var publicSequence=scenario switch{"attributes"=>record.Attributes(),"named-attribute"=>record.Attributes("id",""),"namespaces"=>record.Axis(XdmAxis.Namespace),"all-children"=>record.Children(XdmNodeKind.All),_=>record.Children(XdmNodeKind.Element)};
            var actual=new List<XdmValue>();foreach(var v in publicSequence)actual.Add(v);
            Fixture.Require(values.Count==actual.Count,"public axis count");
            for(int i=0;i<values.Count;i++){
                bool sameReference=ReferenceEquals(values[i].NodeValue,actual[i].NodeValue),sameNode=values[i].NodeValue.IsSameNode(actual[i].NodeValue);
                snapshots.Add("public-identity:"+sameReference+":"+sameNode);
                if(scenario!="namespaces")Fixture.Require(sameReference&&sameNode,"public cached identity");
            }
        }
        if(scenario is "after-advance" or "after-finish" or "second-record"){
            try{foreach(var v in values[0].NodeValue.Axis(scenario=="second-record"?XdmAxis.Preceding:XdmAxis.Following))snapshots.Add("navigation:"+Describe(v,f));}
            catch(Exception error){snapshots.Add("navigation-error:"+Error(error));}
        }
        if(scenario=="partial-advance"){
            var partial=seq.GetEnumerator();Fixture.Require(partial.MoveNext(),"partial pull");Fixture.Require(f.Advance(),"reader remains usable after abandoned in-record enumeration");
            snapshots.Add("reader-advance:"+f.CurrentRecord.LocalName);
        }
        if(scenario=="reader-owner"){f.DisposeReader();Fixture.Require(f.StreamOpen,"CloseInput=false");snapshots.Add("stream-open");}
        return string.Join("|",snapshots);
    }
    private static List<XdmValue> Pull(IXdmSequence sequence){var list=new List<XdmValue>();var e=sequence.GetEnumerator();while(e.MoveNext())list.Add(e.Current);return list;}
    private static string Describe(XdmValue value,Fixture f){if(!value.IsNode)return value.Kind.ToString();var n=value.NodeValue;return $"{n.NodeKind}:{{{n.NamespaceUri}}}{n.LocalName}={n.StringValue}:index={Fixture.RecordIndex(n)}:doc={ReferenceEquals(n.Document,f.Document)}:parent={n.Parent?.LocalName}";}
    private static string Error(Exception e)=>e.GetType().FullName+":"+e.Message;
    private static void Equal(string a,string b,string name){if(a!=b)throw new InvalidOperationException("Mismatch "+name+"\nBASE "+a+"\nPROTO "+b);}
}
