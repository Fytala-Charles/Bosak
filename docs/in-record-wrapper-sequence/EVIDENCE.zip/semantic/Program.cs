// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 15 November 2026
// PURPOSE              : Measures and compares qualified provider wrapping with a direct XDM prototype
// SPECIAL NOTES        : Unit tests verifying correctness of the underlying implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 15-11-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using System.Reflection;
using System.Text.Json;
using System.Xml.Linq;
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Providers.Xml;
using Bosak.XPath.Runtime.Vm;

internal static class Program {
    /// <summary>Runs the diagnostic with engine types loaded inside the error guard.</summary>
    /// <returns>Zero after success, otherwise two.</returns>
    public static int Main(){try{var t=typeof(Program).Assembly.GetType("Rows",true)!;Console.WriteLine(JsonSerializer.Serialize(t.GetMethod("Run",BindingFlags.Public|BindingFlags.Static)!.Invoke(null,null)));return 0;}catch(Exception e){Console.Error.WriteLine(e);return 2;}}
}
internal static class Rows {
    private const int Warm=10000,N=100000;
    private static IXdmSequence? _sequenceSink;
    private static XdmValue _valueSink;
    private static readonly List<object> Results=new();
    /// <summary>Measures wrapping stages and compares fixed behavior scenarios.</summary>
    /// <returns>Measured rows and behavior comparison counts.</returns>
    public static object Run(){
        var comparisons=Comparisons.Run();
        return new{success=true,engine=typeof(EvaluationContext).Assembly.GetName().Version!.ToString(),runtime=Environment.Version.ToString(),warmup=Warm,iterations=N,comparisonCases=comparisons,rows=Results};
    }
    private static int Count(IXdmSequence source){int n=0;var e=source.GetEnumerator();while(e.MoveNext()){_valueSink=e.Current;n++;}return n;}
    private static void First(string name,Func<IXdmSequence> make,bool cross,int size){
        var prepared=new IXdmSequence[Warm+N];for(int i=0;i<prepared.Length;i++)prepared[i]=make();int index=0;
        if(!cross){Measure(name,()=>Count(prepared[index++]),size);return;}
        Exception? error=null;int creator=Environment.CurrentManagedThreadId;
        var thread=new Thread(()=>{try{Fixture.Require(Environment.CurrentManagedThreadId!=creator,"different thread");Measure(name,()=>Count(prepared[index++]),size);}catch(Exception e){error=e;}});
        thread.Start();if(!thread.Join(30000))throw new TimeoutException("Cross-thread enumeration");if(error is not null)throw new InvalidOperationException("Caught cross-thread error",error);
    }
    private static void Measure(string name,Func<int> call,int expected){
        for(int i=0;i<Warm;i++)Fixture.Require(call()==expected,"warm outcome");
        long start=GC.GetAllocatedBytesForCurrentThread();int count=0;for(int i=0;i<N;i++)count+=call();long bytes=GC.GetAllocatedBytesForCurrentThread()-start;
        Fixture.Require(count==expected*N,"measured outcome");Results.Add(new{name,allocatedBytes=bytes,bytesPerCall=bytes/(double)N,expectedItems=expected,count,measuredThread=Environment.CurrentManagedThreadId});
    }
}
