// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 15 November 2026
// PURPOSE              : Builds guarded provider fixtures and cached qualified wrapper delegates
// SPECIAL NOTES        : Unit tests verifying correctness of the underlying implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 15-11-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Providers.Streaming;
using Bosak.XPath.Providers.Xml;

internal sealed class Fixture : IDisposable
{
    private static readonly Func<IEnumerable<XdmValue>,IXdmSequence> Adapt=CompileAdapter();
    private readonly MemoryStream _stream;
    private readonly XmlReader _reader;
    private XdmSequence.Enumerator _records;
    private readonly Func<XdmSequence,IEnumerable<XdmValue>> _wrapEach;
    private readonly Func<XDocumentNode,int,IXdmNode> _wrapNode;
    private readonly int _record;
    internal readonly IXdmNode Document,Root,Record,Inner;
    internal readonly XElement Element;
    internal Fixture() {
        _stream=new MemoryStream(Encoding.UTF8.GetBytes("<root xmlns:p='urn:p'><record id='one' p:code='x' xmlns:q='urn:q'><a>alpha</a><!--inside--><?pi value?>text<b/></record><record id='two'><c/></record></root>"));
        _reader=XmlReader.Create(_stream,new XmlReaderSettings{CloseInput=false});
        Document=XmlStreamingProvider.Load(_reader);
        var roots=Document.Children(XdmNodeKind.Element).GetEnumerator(); Require(roots.MoveNext(),"root");Root=roots.Current.NodeValue;
        _records=Root.Children(XdmNodeKind.Element).GetEnumerator(); Require(_records.MoveNext(),"record");Record=_records.Current.NodeValue;
        var type=Record.GetType();
        Inner=(IXdmNode)type.GetField("_inner",BindingFlags.NonPublic|BindingFlags.Instance)!.GetValue(Record)!;
        Element=(XElement)((XDocumentNode)Inner).UnderlyingObject;
        _record=(int)type.GetField("_recordIndex",BindingFlags.NonPublic|BindingFlags.Instance)!.GetValue(Record)!;
        var source=type.GetField("_source",BindingFlags.NonPublic|BindingFlags.Instance)!.GetValue(Record)!;
        _wrapEach=type.GetMethod("WrapEach",BindingFlags.NonPublic|BindingFlags.Instance)!.CreateDelegate<Func<XdmSequence,IEnumerable<XdmValue>>>(Record);
        _wrapNode=source.GetType().GetMethod("Wrap",BindingFlags.NonPublic|BindingFlags.Instance)!.CreateDelegate<Func<XDocumentNode,int,IXdmNode>>(source);
    }
    internal IXdmSequence Baseline(XdmSequence input)=>Adapt(_wrapEach(input));
    internal IXdmSequence Candidate(XdmSequence input){
        var method=Record.GetType().GetMethod("WrapInRecord",BindingFlags.NonPublic|BindingFlags.Instance);
        return method is null?new WrapperSequence(input,_wrapNode,_record):XdmValue.FromSequence(method.CreateDelegate<Func<XdmSequence,XdmSequence>>(Record)(input)).SequenceValue!;
    }
    internal XdmValue[] Children() { var list=new List<XdmValue>();foreach(var x in Inner.Children(XdmNodeKind.Element))list.Add(x);return list.ToArray(); }
    internal static IXdmSequence ForRecord(IXdmNode record,XdmSequence input,bool candidate){
        var t=record.GetType();var source=t.GetField("_source",BindingFlags.NonPublic|BindingFlags.Instance)!.GetValue(record)!;
        int index=RecordIndex(record);
        var direct=t.GetMethod("WrapInRecord",BindingFlags.NonPublic|BindingFlags.Instance);
        if(candidate&&direct is not null)return XdmValue.FromSequence(direct.CreateDelegate<Func<XdmSequence,XdmSequence>>(record)(input)).SequenceValue!;
        if(candidate)return new WrapperSequence(input,source.GetType().GetMethod("Wrap",BindingFlags.NonPublic|BindingFlags.Instance)!.CreateDelegate<Func<XDocumentNode,int,IXdmNode>>(source),index);
        return Adapt(t.GetMethod("WrapEach",BindingFlags.NonPublic|BindingFlags.Instance)!.CreateDelegate<Func<XdmSequence,IEnumerable<XdmValue>>>(record)(input));
    }
    internal bool Advance()=>_records.MoveNext();
    internal IXdmNode CurrentRecord=>_records.Current.NodeValue;
    internal bool StreamOpen=>_stream.CanRead;
    internal void DisposeReader()=>_reader.Dispose();
    /// <inheritdoc/>
    public void Dispose(){_reader.Dispose();_stream.Dispose();}
    internal static int RecordIndex(IXdmNode node)=>(int)node.GetType().GetField("_recordIndex",BindingFlags.NonPublic|BindingFlags.Instance)!.GetValue(node)!;
    private static Func<IEnumerable<XdmValue>,IXdmSequence> CompileAdapter(){
        var t=typeof(XdmSequence).Assembly.GetType("Bosak.XPath.Core.Xdm.EnumerableXdmSequence",true)!;
        var p=Expression.Parameter(typeof(IEnumerable<XdmValue>),"items");
        return Expression.Lambda<Func<IEnumerable<XdmValue>,IXdmSequence>>(Expression.New(t.GetConstructor(new[]{typeof(IEnumerable<XdmValue>)})!,p),p).Compile();
    }
    internal static void Require(bool ok,string name){if(!ok)throw new InvalidOperationException("Check failed: "+name);}
}

internal class Source : IXdmSequence
{
    internal readonly XdmValue[] Values;
    internal readonly string Fault;
    internal int Gets,Moves,Reads,Disposals;
    internal Source(XdmValue[] values,string fault="none"){Values=values;Fault=fault;}
    /// <inheritdoc/>
    public bool TryGetLength(out int length){length=0;return false;}
    /// <inheritdoc/>
    public virtual IXdmSequenceEnumerator GetEnumerator(){Gets++;if(Fault=="acquire")throw new InvalidOperationException("acquire-marker");return Fault=="null"?null!:new Enumerator(this);}
    private sealed class Enumerator : IXdmSequenceEnumerator,IDisposable {
        private readonly Source _s;private int _i=-1;
        internal Enumerator(Source s)=>_s=s;
        /// <inheritdoc/>
        public XdmValue Current{get{_s.Reads++;if(_s.Fault=="current"&&_i==1)throw new InvalidOperationException("current-marker");return _s.Values[_i];}}
        /// <inheritdoc/>
        public bool MoveNext(){_s.Moves++;_i++;if(_s.Fault=="move"&&_i==1)throw new InvalidOperationException("move-marker");return _i<_s.Values.Length;}
        /// <inheritdoc/>
        public void Dispose()=>_s.Disposals++;
    }
}
internal sealed class MarkedSource : Source,ISinglePassSequence {
    private int _taken;
    internal MarkedSource(XdmValue[] values,string fault="none"):base(values,fault){}
    /// <inheritdoc/>
    public override IXdmSequenceEnumerator GetEnumerator(){if(Interlocked.Exchange(ref _taken,1)!=0)throw new InvalidOperationException("source-taken");return base.GetEnumerator();}
}
