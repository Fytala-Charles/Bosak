// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 15 November 2026
// PURPOSE              : Prototypes direct XDM wrapping of in-record provider node sequences
// SPECIAL NOTES        : Unit tests verifying correctness of the underlying implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 15-11-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Providers.Xml;

internal sealed class WrapperSequence : IXdmSequence
{
    private readonly IXdmSequence? _source;
    private readonly Func<XDocumentNode, int, IXdmNode> _wrap;
    private readonly int _record;
    internal WrapperSequence(XdmSequence input, Func<XDocumentNode, int, IXdmNode> wrap, int record)
    { _source = XdmValue.FromSequence(input).SequenceValue; _wrap = wrap; _record = record; }
    /// <inheritdoc/>
    public bool TryGetLength(out int length) { length = 0; return false; }
    /// <inheritdoc/>
    public IXdmSequenceEnumerator GetEnumerator() => new Enumerator(_source, _wrap, _record);
    private sealed class Enumerator : IXdmSequenceEnumerator
    {
        private readonly IXdmSequence? _source;
        private readonly Func<XDocumentNode, int, IXdmNode> _wrap;
        private readonly int _record;
        private IXdmSequenceEnumerator? _inner;
        private XdmValue _current;
        private int _state;
        internal Enumerator(IXdmSequence? source, Func<XDocumentNode, int, IXdmNode> wrap, int record)
        { _source=source; _wrap=wrap; _record=record; }
        /// <inheritdoc/>
        public XdmValue Current => _current;
        /// <inheritdoc/>
        public bool MoveNext()
        {
            if (_state==2) return false;
            try {
                if (_state==0) { _state=1; _inner=_source?.GetEnumerator(); }
                while (_inner is not null && _inner.MoveNext()) {
                    var item=_inner.Current;
                    if (item.IsNode) {
                        _current=XdmValue.FromNode(_wrap((XDocumentNode)item.NodeValue!,_record));
                        return true;
                    }
                }
                _state=2; return false;
            } catch { _state=2; throw; }
        }
    }
}
