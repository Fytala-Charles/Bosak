// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 05 November 2026
// PURPOSE              : Retains provider admissions through actual in-flight calls and raw completion.
// SPECIAL NOTES        : Part of the register-based virtual machine execution engine.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 05-11-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.2 | 05-11-2026     | Guard source-free construction and operation-local capture (1.66.0). |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using Bosak.XPath.Core.Schema;

namespace Bosak.XPath.Runtime.Vm;

/// <summary>Serializes optional provider work and retains its real admission through raw completion.</summary>
internal sealed class QueryProviderOperationScope(Action checkRaw, CancellationToken cancellation)
{
    private readonly object _gate = new();
    private bool _closed;
    private bool _busy;
    private IQueryOperationLifetime? _provider;
    private IQueryOperationLease? _admission;
    private TaskCompletionSource? _idle;
    private TaskCompletionSource? _completion;

    internal void CheckActive()
    {
        lock (_gate) ObjectDisposedException.ThrowIf(_closed, this);
        cancellation.ThrowIfCancellationRequested();
    }

    // No provider delegate, admission check or release runs under _gate.
    internal T Call<T>(IQueryOperationLifetime provider, Func<Action, T> work, Action<Action>? beforeEnter = null)
    {
        ArgumentNullException.ThrowIfNull(provider);
        ArgumentNullException.ThrowIfNull(work);
        lock (_gate)
        {
            ObjectDisposedException.ThrowIf(_closed, this);
            cancellation.ThrowIfCancellationRequested();
            if (_busy) throw new InvalidOperationException("Overlapping provider work is not supported within one operation.");
            if (_provider is not null && !ReferenceEquals(_provider, provider))
                throw new ArgumentException("Provider admission belongs to another advisor.", nameof(provider));
            _provider = provider;
            _busy = true;
            _idle = new(TaskCreationOptions.RunContinuationsAsynchronously);
        }
        try
        {
            Check();
            beforeEnter?.Invoke(Check);
            Check();
            _admission ??= provider.Enter(cancellation)
                ?? throw new InvalidOperationException("Provider returned no operation admission.");
            Check();
            var result = work(Check);
            Check();
            return result;
        }
        finally
        {
            TaskCompletionSource idle;
            lock (_gate) { _busy = false; idle = _idle!; }
            idle.TrySetResult();
        }
    }

    private void Check()
    {
        CheckActive();
        checkRaw();
        _admission?.ThrowIfUnavailable(cancellation);
        checkRaw();
        CheckActive();
    }

    internal Task CompleteAsync(Func<List<Exception>> releaseRaw, Exception? primary = null)
    {
        Task wait;
        TaskCompletionSource completion;
        lock (_gate)
        {
            if (_completion is not null) return _completion.Task;
            _closed = true;
            completion = _completion = new(TaskCreationOptions.RunContinuationsAsynchronously);
            wait = _busy ? _idle!.Task : Task.CompletedTask;
        }
        // This task catches every failure and settles the shared completion; no detached exception.
        _ = ReleaseAsync(wait, releaseRaw, primary, completion);
        return completion.Task;
    }

    private async Task ReleaseAsync(Task wait, Func<List<Exception>> releaseRaw, Exception? primary, TaskCompletionSource completion)
    {
        await wait.ConfigureAwait(false);
        List<Exception> errors = [];
        if (primary is not null) errors.Add(primary);
        try { _admission?.Dispose(); } catch (Exception error) { errors.Add(error); }
        finally { _admission = null; }
        try { errors.AddRange(releaseRaw()); }
        catch (Exception error) { errors.Add(error); }
        if (errors.Count == 0) completion.TrySetResult();
        else if (errors.Count == 1) completion.TrySetException(errors[0]);
        else completion.TrySetException(new AggregateException("Operation work and admission cleanup failures.", errors));
    }
}
