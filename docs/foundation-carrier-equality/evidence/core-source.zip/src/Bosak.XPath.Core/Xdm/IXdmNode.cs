// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 19 mei 2026
// PURPOSE              : Abstract representation of a node in the XQuery Data Model. Implementations adapt concrete XML AP...
// SPECIAL NOTES        : Part of the Bosak XPath 3.1 implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 19-05-2026     | Creation                                                                                 |
//                      | Charles Korthout | 0.2   | 19-05-2026     | Added ToXmlString for fn:serialize                                                     |
//                      | Charles Korthout | 0.3   | 19-05-2026     | Added BaseUri property for fn:base-uri and fn:document-uri                             |
//                      | Charles Korthout | 0.4   | 25-06-2026     | Added DocumentUri property separate from BaseUri                                       |
//                      | Charles Korthout | 0.5   | 18-07-2026     | Added DTD properties for fn:id/fn:idref DTD support                                      |
//                      | Charles Korthout | 0.6   | 19-07-2026     | Added IsId accessor for schema-validated ID nodes                                        |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.7   | 20-07-2026     | Added HasNoTypedValue accessor for FOTY0012 in fn:data()                                 |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.8   | 21-08-2026     | Added SchemaElementDeclaration, SchemaAttributeDeclaration, and IsNilled accessors          |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.9   | 21-08-2026     | Added IsIdref accessor for schema-validated IDREF nodes                                  |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.10  | 23-08-2026     | Added IsConstructedElement accessor for XQuery-constructed element type annotations |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.11  | 23-08-2026     | Added IsComplexType accessor for schema-aware element type comparison |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.12  | 29-08-2026     | Added TryGetUnparsedEntity for DTD unparsed entity support                                |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
namespace Bosak.XPath.Core.Xdm;

/// <summary>
/// Abstract representation of a node in the XQuery Data Model.
/// Implementations adapt concrete XML APIs (XDocument, XmlDocument, streaming, etc.)
/// without copying into a proprietary DOM.
/// </summary>
public interface IXdmNode
{
    /// <summary>Gets the kind of this node.</summary>
    XdmNodeKind NodeKind { get; }

    /// <summary>Gets the local name of this node, or empty string if unnamed.</summary>
    string LocalName { get; }

    /// <summary>
    /// Gets the local name in the form used for internal storage.
    /// For XML 1.1 documents this may be an encoded representation of <see cref="LocalName"/>.
    /// </summary>
    string EncodedLocalName => LocalName;

    /// <summary>Gets the namespace URI of this node, or empty string if none.</summary>
    string NamespaceUri { get; }

    /// <summary>Gets the namespace prefix of this node, or empty string if none.</summary>
    string Prefix { get; }

    /// <summary>
    /// Gets the prefix in the form used for internal storage.
    /// For XML 1.1 documents this may be an encoded representation of <see cref="Prefix"/>.
    /// </summary>
    string EncodedPrefix => Prefix;

    /// <summary>Gets the string value of this node per XDM rules.</summary>
    string StringValue { get; }

    /// <summary>Gets the typed value if available, otherwise the string value.</summary>
    XdmValue TypedValue { get; }

    /// <summary>
    /// Gets a value indicating whether this node has no typed value per XDM
    /// (e.g., an element whose schema type is a complex type with element-only
    /// or empty content). When true, <c>fn:data()</c> must raise FOTY0012.
    /// </summary>
    bool HasNoTypedValue => false;

    /// <summary>
    /// Gets a value indicating whether the schema type annotation of this node
    /// is a complex type (including complex types with simple, mixed, element-only,
    /// or empty content). Returns <c>false</c> for simple types and for nodes that
    /// have no schema type annotation.
    /// </summary>
    bool IsComplexType => false;

    /// <summary>
    /// Gets a value indicating whether this node has the XDM is-id property
    /// (its typed value is a single xs:ID atomic value, or it is an ID-typed attribute).
    /// </summary>
    bool IsId => false;

    /// <summary>
    /// Gets a value indicating whether this node has the XDM is-idrefs property
    /// (its typed value contains one or more xs:IDREF atomic values, or it is an IDREF-typed attribute).
    /// </summary>
    bool IsIdref => false;

    /// <summary>
    /// Gets the schema type annotation of this node as an expanded QName, or null when the
    /// node is untyped (e.g. an unvalidated document or a node constructed without schema
    /// validation). The namespace URI is empty for nodes without a schema type.
    /// </summary>
    (string NamespaceUri, string LocalName)? SchemaTypeAnnotation => null;

    /// <summary>
    /// Gets the name of the schema element declaration that validated this element node,
    /// or null when the node is not schema-validated. Substitution-group members return
    /// their own declaration name; the consumer can walk the substitution group to the head.
    /// </summary>
    (string NamespaceUri, string LocalName)? SchemaElementDeclaration => null;

    /// <summary>
    /// Gets the name of the schema attribute declaration that validated this attribute node,
    /// or null when the node is not schema-validated.
    /// </summary>
    (string NamespaceUri, string LocalName)? SchemaAttributeDeclaration => null;

    /// <summary>
    /// Gets a value indicating whether this element node is nilled (<c>xsi:nil="true"</c>)
    /// according to its schema element declaration.
    /// </summary>
    bool IsNilled => false;

    /// <summary>
    /// Gets a value indicating whether this element node was created by an XQuery element
    /// constructor. Constructed elements have the XDM type annotation <c>xs:anyType</c> when
    /// they are not schema-validated, while elements parsed from an unvalidated document have
    /// the type annotation <c>xs:untyped</c>.
    /// </summary>
    bool IsConstructedElement => false;

    /// <summary>Gets the parent node, or null if this is the root.</summary>
    IXdmNode? Parent { get; }

    /// <summary>Gets the document node containing this node, or null.</summary>
    IXdmNode? Document { get; }

    /// <summary>Returns a lazy sequence of children filtered by node kind.</summary>
    XdmSequence Children(XdmNodeKind kind = XdmNodeKind.All);

    /// <summary>Returns a lazy sequence of attributes, optionally filtered by name.</summary>
    XdmSequence Attributes(string? localName = null, string? namespaceUri = null);

    /// <summary>Returns a lazy sequence along the specified axis.</summary>
    XdmSequence Axis(XdmAxis axis);

    /// <summary>Returns true if this node and <paramref name="other"/> are the same node.</summary>
    bool IsSameNode(IXdmNode other);

    /// <summary>Gets the document order index of this node, or 0 if unknown.</summary>
    long DocumentOrder { get; }

    /// <summary>Gets the base URI of this node, or empty string if none.</summary>
    string BaseUri { get; }

    /// <summary>Gets the document URI of this node, or empty string if none.</summary>
    string DocumentUri { get; }

    /// <summary>Gets a value indicating whether the containing document has a document type declaration.</summary>
    bool HasDocumentType => false;

    /// <summary>Gets the name of the document type declaration, or empty string if none.</summary>
    string DocumentTypeName => string.Empty;

    /// <summary>Gets the public identifier of the document type declaration, or empty string if none.</summary>
    string PublicId => string.Empty;

    /// <summary>Gets the system identifier of the document type declaration, or empty string if none.</summary>
    string SystemId => string.Empty;

    /// <summary>Gets the internal subset of the document type declaration, or empty string if none.</summary>
    string InternalSubset => string.Empty;

    /// <summary>
    /// Looks up an unparsed entity declaration by name in the document that contains this node.
    /// When found, <paramref name="systemId"/> receives the absolute system identifier
    /// (resolved against the document base URI) and <paramref name="publicId"/> receives the
    /// public identifier if one was declared. Returns <c>false</c> when no such entity exists.
    /// </summary>
    bool TryGetUnparsedEntity(string name, out string? systemId, out string? publicId)
    {
        systemId = null;
        publicId = null;
        return false;
    }

    /// <summary>Returns the XML serialization of this node.</summary>
    string ToXmlString();
}
