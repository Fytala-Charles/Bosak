// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 15 November 2026
// PURPOSE              : Compares a specialized lazy filter prototype against qualified VM behavior
// SPECIAL NOTES        : Unit tests verifying correctness of the underlying implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 15-11-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Xml;
using System.Xml.Linq;
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Runtime.Vm;
using Bosak.XPath.Providers.Streaming;
using Bosak.XPath.Providers.Xml;

internal static class Program
{
    /// <summary>Runs the diagnostic with engine loading inside the error guard.</summary>
    /// <returns>Zero for success, otherwise two.</returns>
    public static int Main()
    {
        try
        {
            var t = typeof(Program).Assembly.GetType("Rows", true)!;
            Console.WriteLine(JsonSerializer.Serialize(t.GetMethod("Run", BindingFlags.Public | BindingFlags.Static)!.Invoke(null, null)));
            return 0;
        }
        catch (Exception e) { Console.Error.WriteLine(e); return 2; }
    }
}

internal static class Rows
{
    private const int Warm = 10000, Iterations = 100000;
    private static XdmValue _valueSink;
    private static IEnumerable<XdmValue>? _enumerableSink;
    private static int _countSink;
    private static string _variant="";
    private static readonly Func<IXdmNode, bool> Accept = static _ => true;
    private static readonly List<object> Measurements = new();
    private static readonly List<string> Checks = new();
    private static Func<XdmValue, Func<IXdmNode, bool>, XdmValue> Filter = null!;

    /// <summary>Measures immutable fixtures and checks lazy sequence behavior.</summary>
    /// <returns>Allocation rows and completed semantic checks.</returns>
    public static object Run()
    {
        var vm = typeof(EvaluationContext).Assembly.GetType("Bosak.XPath.Runtime.Vm.VmEngine", true)!;
        Filter = vm.GetMethod("FilterNodesLazy", BindingFlags.NonPublic | BindingFlags.Static)!
            .CreateDelegate<Func<XdmValue, Func<IXdmNode, bool>, XdmValue>>();
        using var stream = new MemoryStream(Encoding.UTF8.GetBytes("<root><record><a>one</a><b>two</b></record><record><c/></record></root>"));
        using var reader = XmlReader.Create(stream, new XmlReaderSettings { CloseInput = false });
        var document = XmlStreamingProvider.Load(reader);
        var roots = document.Children(XdmNodeKind.Element).GetEnumerator(); Require(roots.MoveNext(), "root");
        var records = roots.Current.NodeValue.Children(XdmNodeKind.Element).GetEnumerator(); Require(records.MoveNext(), "record");
        var record = records.Current.NodeValue;
        var inner = (IXdmNode)record.GetType().GetField("_inner", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(record)!;
        var wrap = record.GetType().GetMethod("WrapEach", BindingFlags.NonPublic | BindingFlags.Instance)!
            .CreateDelegate<Func<XdmSequence, IEnumerable<XdmValue>>>(record);
        var values = new List<XdmValue>(); foreach (var v in inner.Children(XdmNodeKind.Element)) values.Add(v);
        Require(values.Count == 2, "two fixture nodes");
        foreach (var _ in wrap(Sequence(new TestSequence(values)))) { } // Warm cached wrapper identities.

        var baseline=Filter;
        var comparisonCases=ProbeComparisons.Check(baseline,Prototype.Filter,values);
        Filter=baseline; Semantics(values,wrap);
        Filter=Prototype.Filter; Semantics(values,wrap);
        Filter=baseline;
        // Separate provider ownership checks: XDM enumerators themselves have no Dispose contract.
        using (var partial = wrap(Sequence(new TestSequence(values))).GetEnumerator()) Require(partial.MoveNext(), "partial wrapper");
        Require(records.MoveNext() && records.Current.NodeValue.LocalName == "record", "wrapper disposal leaves record reader usable");
        Checks.Add("partial wrapper disposal leaves caller-owned reader usable");
        reader.Dispose(); Require(stream.CanRead, "CloseInput=false leaves stream open");
        Checks.Add("caller reader disposal preserves CloseInput=false stream ownership");
        return new { success = true, comparisonCases, engine = vm.Assembly.GetName().Version!.ToString(), runtime = Environment.Version.ToString(),
            warmup = Warm, iterations = Iterations, rows = Measurements, checks = Checks };
    }

    private static void Semantics(List<XdmValue> values, Func<XdmSequence, IEnumerable<XdmValue>> wrap)
    {
        int predicates = 0;
        var source = new TestSequence(values);
        var filtered = Filter(Value(source), _ => { predicates++; return true; });
        Require(source.Gets == 0 && predicates == 0, "no eager pulls");
        var e = filtered.SequenceValue!.GetEnumerator(); Require(source.Gets == 0 && predicates == 0, "GetEnumerator stays lazy");
        Require(e.MoveNext() && ReferenceEquals(e.Current.NodeValue, values[0].NodeValue), "filter identity");
        Checks.Add("filter construction and GetEnumerator defer pulls/predicates; node identity preserved");
        var thrown = Filter(Value(new TestSequence(values)), static _ => throw new InvalidOperationException("deferred-marker"));
        var failing = thrown.SequenceValue!.GetEnumerator();
        Expect<InvalidOperationException>(() => failing.MoveNext(), "deferred-marker");
        Checks.Add("predicate failure deferred to MoveNext and caught inside diagnostic");
        var mutable = new List<XdmValue> { values[0] }; var changed = Filter(Value(new TestSequence(mutable)), Accept);
        mutable.Add(values[1]); Require(Count(changed) == 2, "mutation before first enumeration");
        mutable.RemoveAt(0); Require(Count(changed) == 1, "mutation before replay");
        Checks.Add("ordinary source mutations visible before first and repeated enumeration");
        var element = new XElement("n", "before");
        var node = XdmValue.FromNode(new XDocumentNode(element));
        var live = Filter(Value(new TestSequence(new List<XdmValue> { node })), static n => n.StringValue == "after");
        element.Value = "after"; Require(Count(live) == 1, "XML value mutation visibility");
        Checks.Add("predicate observes XML value changes made after filter construction");
        foreach (bool partial in new[] { false, true })
        {
            var once = Filter(Value(new MarkedSequence(values)), Accept);
            Require(once.SequenceValue is ISinglePassSequence, "single-pass marker retained");
            var first = once.SequenceValue.GetEnumerator(); if (partial) Require(first.MoveNext(), "partial marked pull");
            Expect<StreamingException>(() => once.SequenceValue.GetEnumerator());
        }
        Checks.Add("single-pass marker and refusal preserved after acquisition and partial pull");
        var firstWrappers = wrap(Sequence(new TestSequence(values))).ToArray();
        var secondWrappers = wrap(Sequence(new TestSequence(values))).ToArray();
        for (int i = 0; i < values.Count; i++)
            Require(ReferenceEquals(firstWrappers[i].NodeValue, secondWrappers[i].NodeValue)
                && firstWrappers[i].NodeValue.IsSameNode(values[i].NodeValue), "wrapper identity cache");
        Checks.Add("wrapper reference identity and underlying node identity stable across enumeration");
    }

    private static void First(string name, Func<XdmValue> make, bool cross, int expected)
    {
        var prepared = new XdmValue[Warm + Iterations]; for (int i = 0; i < prepared.Length; i++) prepared[i] = make();
        int index = 0; Func<int> read = () => Count(prepared[index++]);
        OnThread(cross, () => Measure(name, read, expected));
    }
    private static void FirstWrap(string name, Func<IEnumerable<XdmValue>> make, bool cross, int expected)
    {
        var prepared = new IEnumerable<XdmValue>[Warm + Iterations]; for (int i = 0; i < prepared.Length; i++) prepared[i] = make();
        int index = 0; Func<int> read = () => Count(prepared[index++]);
        OnThread(cross, () => Measure(name, read, expected));
    }
    private static void OnThread(bool cross, Action action)
    {
        if (!cross) { action(); return; }
        int creator = Environment.CurrentManagedThreadId; Exception? error = null;
        var thread = new Thread(() => { try { Require(Environment.CurrentManagedThreadId != creator, "different thread"); action(); } catch (Exception e) { error = e; } });
        thread.Start(); if (!thread.Join(30000)) throw new TimeoutException("Cross-thread diagnostic watchdog");
        if (error is not null) throw new InvalidOperationException("Caught cross-thread diagnostic error", error);
    }
    private static void Measure(string name, Func<int> call, int expected)
    {
        for (int i = 0; i < Warm; i++) Require(call() == expected, "warm outcome");
        long before = GC.GetAllocatedBytesForCurrentThread(); int count = 0;
        for (int i = 0; i < Iterations; i++) count += call();
        long bytes = GC.GetAllocatedBytesForCurrentThread() - before; _countSink = count;
        Require(count == expected * Iterations, "measured outcome");
        Measurements.Add(new { name=_variant+"/"+name, allocatedBytes = bytes, bytesPerCall = bytes / (double)Iterations, expectedItems = expected,
            count, measuredThread = Environment.CurrentManagedThreadId });
    }
    private static int Count(XdmValue value) => Count(Sequence(value.SequenceValue!));
    private static int Count(XdmSequence sequence) { int count = 0; foreach (var _ in sequence) count++; return count; }
    private static int Count(IEnumerable<XdmValue> sequence) { int count = 0; foreach (var _ in sequence) count++; return count; }
    private static XdmSequence Sequence(IXdmSequence source) => XdmSequence.FromSource(source);
    private static XdmValue Value(IXdmSequence source) => XdmValue.FromSequence(Sequence(source));
    private static void Require(bool ok, string name) { if (!ok) throw new InvalidOperationException("Check failed: " + name); }
    private static void Expect<T>(Action action, string? message = null) where T : Exception
    {
        try { action(); } catch (T e) { if (message is not null) Require(e.Message == message, "exception text"); return; }
        throw new InvalidOperationException("Expected caught " + typeof(T).Name);
    }
    private class TestSequence : IXdmSequence
    {
        private readonly List<XdmValue> _items;
        internal int Gets;
        internal TestSequence(List<XdmValue> items) => _items = items;
        /// <inheritdoc/>
        public bool TryGetLength(out int length) { length = 0; return false; }
        /// <inheritdoc/>
        public virtual IXdmSequenceEnumerator GetEnumerator() { Gets++; return new Enumerator(_items); }
        private sealed class Enumerator : IXdmSequenceEnumerator
        {
            private readonly List<XdmValue> _items; private int _index = -1;
            internal Enumerator(List<XdmValue> items) => _items = items;
            /// <inheritdoc/>
            public XdmValue Current => _items[_index];
            /// <inheritdoc/>
            public bool MoveNext() => ++_index < _items.Count;
        }
    }
    private sealed class MarkedSequence : TestSequence, ISinglePassSequence
    {
        private int _taken;
        internal MarkedSequence(List<XdmValue> items) : base(items) { }
        /// <inheritdoc/>
        public override IXdmSequenceEnumerator GetEnumerator()
        {
            if (Interlocked.Exchange(ref _taken, 1) != 0) throw new StreamingException("Diagnostic source consumed");
            return base.GetEnumerator();
        }
    }
}
