// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 15 November 2026
// PURPOSE              : Compares filter results, deferred errors and enumeration state against the qualified VM
// SPECIAL NOTES        : Unit tests verifying correctness of the underlying implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 15-11-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Providers.Streaming;

internal static class ProbeComparisons
{
    internal static int Check(Func<XdmValue, Func<IXdmNode, bool>, XdmValue> baseline,
        Func<XdmValue, Func<IXdmNode, bool>, XdmValue> candidate, List<XdmValue> nodes)
    {
        int cases = 0;
        var mixed = new List<XdmValue> { XdmValue.FromString("skip"), nodes[0], XdmValue.FromBoolean(true), nodes[1] };
        foreach (var items in new[] { new List<XdmValue>(), new List<XdmValue> { nodes[0] }, mixed })
        foreach (bool marked in new[] { false, true })
        foreach (string mode in new[] { "all", "none", "a", "throw" })
        foreach (string fault in new[] { "none", "acquire", "move", "current", "null" })
        {
            var left = Trace(baseline, items, marked, mode, fault);
            var right = Trace(candidate, items, marked, mode, fault);
            if (left != right) throw new InvalidOperationException($"Trace mismatch size={items.Count} marked={marked} mode={mode} fault={fault}\nBASE {left}\nPROTO {right}");
            cases++;
        }
        foreach (var input in new[] { default(XdmValue), XdmValue.FromString("scalar"), XdmValue.FromBoolean(true),
            nodes[0], XdmValue.FromSequence(default), XdmValue.FromSequence(XdmSequence.Empty) })
        foreach (string mode in new[] { "all", "none", "throw" })
        {
            if (Scalar(baseline, input, mode) != Scalar(candidate, input, mode))
                throw new InvalidOperationException("Scalar mismatch " + input.Kind + "/" + mode);
            cases++;
        }
        Race(baseline, nodes); Race(candidate, nodes); cases++;
        return cases;
    }

    private static string Trace(Func<XdmValue, Func<IXdmNode, bool>, XdmValue> filter,
        List<XdmValue> items, bool marked, string mode, string fault)
    {
        FaultSource source = marked ? new MarkedFaultSource(items, fault) : new FaultSource(items, fault);
        int calls = 0;
        var value = filter(XdmValue.FromSequence(XdmSequence.FromSource(source)), n => { calls++; return Predicate(n, mode); });
        var seq = value.SequenceValue!; var log = new List<string>();
        string Stamp() => $"{source.Gets},{source.Moves},{source.Reads},{source.Disposals},{calls}";
        log.Add("new:" + Stamp() + ":marked=" + (seq is ISinglePassSequence));
        log.Add("length:" + seq.TryGetLength(out int length) + ":" + length + ":" + Stamp());
        var e = seq.GetEnumerator(); log.Add("acquired:" + Stamp() + ":" + Snapshot(e.Current));
        for (int i = 0; i < 6; i++)
        {
            try { log.Add("move:" + e.MoveNext() + ":" + Snapshot(e.Current) + ":" + Stamp()); }
            catch (Exception error) { log.Add("error:" + Error(error) + ":current=" + Snapshot(e.Current) + ":" + Stamp()); }
        }
        try { var second = seq.GetEnumerator(); log.Add("second:" + Snapshot(second.Current) + ":" + Stamp()); }
        catch (Exception error) { log.Add("second-error:" + Error(error) + ":" + Stamp()); }
        return string.Join("|", log);
    }
    private static string Scalar(Func<XdmValue, Func<IXdmNode, bool>, XdmValue> filter, XdmValue input, string mode)
    {
        int calls = 0;
        try
        {
            var value = filter(input, n => { calls++; return Predicate(n, mode); }); var seq = value.SequenceValue!;
            var log = new List<string> { "constructed:" + calls, "length:" + seq.TryGetLength(out int n) + ":" + n };
            var e = seq.GetEnumerator();
            for (int i = 0; i < 3; i++) log.Add(e.MoveNext() + ":" + Snapshot(e.Current));
            return string.Join("|", log) + ":calls=" + calls;
        }
        catch (Exception error) { return Error(error) + ":calls=" + calls; }
    }
    private static void Race(Func<XdmValue, Func<IXdmNode, bool>, XdmValue> filter, List<XdmValue> nodes)
    {
        var source = new MarkedFaultSource(nodes, "none");
        var output = filter(XdmValue.FromSequence(XdmSequence.FromSource(source)), static _ => true).SequenceValue!;
        using var ready = new CountdownEvent(2); using var start = new ManualResetEventSlim();
        int accepted = 0, refused = 0; Exception? unexpected = null;
        var threads = Enumerable.Range(0, 2).Select(_ => new Thread(() =>
        {
            try { ready.Signal(); start.Wait(); output.GetEnumerator(); Interlocked.Increment(ref accepted); }
            catch (StreamingException) { Interlocked.Increment(ref refused); }
            catch (Exception error) { unexpected = error; }
        })).ToArray();
        foreach (var t in threads) t.Start();
        if (!ready.Wait(10000)) throw new TimeoutException("Race startup"); start.Set();
        foreach (var t in threads) if (!t.Join(10000)) throw new TimeoutException("Race completion");
        if (unexpected is not null || accepted != 1 || refused != 1 || source.Gets != 0)
            throw new InvalidOperationException("Single-pass acquisition race changed", unexpected);
    }
    private static bool Predicate(IXdmNode node, string mode) => mode switch
    { "all" => true, "none" => false, "a" => node.LocalName == "a", _ => throw new InvalidOperationException("predicate-marker") };
    private static string Snapshot(XdmValue value) => value.IsNode ? "node:" + value.NodeValue.LocalName : value.Kind.ToString();
    private static string Error(Exception e) => e.GetType().FullName + ":" + e.Message;

    private class FaultSource : IXdmSequence
    {
        internal readonly List<XdmValue> Items;
        internal readonly string Fault;
        internal int Gets, Moves, Reads, Disposals;
        internal FaultSource(List<XdmValue> items, string fault) { Items = items; Fault = fault; }
        /// <inheritdoc/>
        public bool TryGetLength(out int length) { length = 0; return false; }
        /// <inheritdoc/>
        public IXdmSequenceEnumerator GetEnumerator()
        {
            Gets++; if (Fault == "acquire") throw new InvalidOperationException("acquire-marker");
            return Fault == "null" ? null! : new Enumerator(this);
        }
        private sealed class Enumerator : IXdmSequenceEnumerator, IDisposable
        {
            private readonly FaultSource _owner; private int _index = -1;
            internal Enumerator(FaultSource owner) => _owner = owner;
            /// <inheritdoc/>
            public XdmValue Current
            {
                get { _owner.Reads++; if (_owner.Fault == "current" && _index == 1) throw new InvalidOperationException("current-marker"); return _owner.Items[_index]; }
            }
            /// <inheritdoc/>
            public bool MoveNext()
            {
                _owner.Moves++; _index++;
                if (_owner.Fault == "move" && _index == 1) throw new InvalidOperationException("move-marker");
                return _index < _owner.Items.Count;
            }
            /// <inheritdoc/>
            public void Dispose() => _owner.Disposals++;
        }
    }
    private sealed class MarkedFaultSource : FaultSource, ISinglePassSequence
    {
        internal MarkedFaultSource(List<XdmValue> items, string fault) : base(items, fault) { }
    }
}
