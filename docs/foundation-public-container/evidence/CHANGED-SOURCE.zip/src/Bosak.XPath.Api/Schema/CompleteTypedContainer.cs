// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 06 November 2026
// PURPOSE              : Delivers complete borrowed typed containers with plain cells and guarded metadata.
// SPECIAL NOTES        : Public surface API for compiling and evaluating XPath 3.1 expressions.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 06-11-2026     | Creation; complete ordinary typed-container delivery (1.79.0).                            |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================
using System.Collections;
using Bosak.XPath.Core.Schema;
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Runtime.Vm;

namespace Bosak.XPath.Api.Schema;

/// <summary>Delivers complete borrowed typed containers with plain cells and guarded metadata.</summary>
internal sealed class CompleteTypedContainer : ISchemaTypedValue, IEnumerable<SchemaAtomicItem>
{
    private readonly QueryTypedContainer _source;
    private readonly ISchemaComponentHandle _governing;
    private readonly bool _list;
    private readonly SchemaAtomicItem[] _items;
    private CompleteTypedContainer(QueryTypedContainer source)
    {
        _source=source;var captured=source.Capture();_governing=captured.Governing;_list=captured.List;
        _items=new SchemaAtomicItem[captured.Cells.Length];
        for(int i=0;i<_items.Length;i++)_items[i]=new(captured.Cells[i].Value,new Evidence(this,i));
    }
    internal static SchemaResult<ISchemaTypedValue> Create(QueryTypedContainer source)
    {
        var captured=source.Capture();bool supported=true;
        foreach(var cell in captured.Cells)
        {
            if(cell.Value.Kind==XdmValueKind.String&&cell.Value.StringValue is null)throw new ArgumentException("String payload is null.");
            supported &= cell.Value.Kind is XdmValueKind.String or XdmValueKind.Boolean or XdmValueKind.Integer or XdmValueKind.Decimal;
        }
        if(!supported)return SchemaQuerySession.UnsupportedTyped<ISchemaTypedValue>();
        var result=new CompleteTypedContainer(source);result.Check();return SchemaQuerySession.Supported<ISchemaTypedValue>(result);
    }
    private void Check()=>_ = _source.Capture();
    ISchemaComponentHandle ISchemaTypedValue.GoverningType {get{Check();return _governing;}}
    bool ISchemaTypedValue.IsList {get{Check();return _list;}}
    IEnumerable<SchemaAtomicItem> ISchemaTypedValue.AtomicItems {get{Check();return this;}}
    bool ISchemaTypedValue.TryGetSingleAtomic(out SchemaAtomicItem item)
    {Check();item=_items.Length==1?_items[0]:default;return _items.Length==1;}
    IEnumerator<SchemaAtomicItem> IEnumerable<SchemaAtomicItem>.GetEnumerator(){Check();return new Cursor(this);}
    IEnumerator IEnumerable.GetEnumerator()=>((IEnumerable<SchemaAtomicItem>)this).GetEnumerator();
    private sealed class Evidence(CompleteTypedContainer owner,int index):ISchemaAtomicProvenance
    {
        ISchemaComponentHandle ISchemaAtomicProvenance.DeclaredType=>owner._source.GetAtomic(index).DeclaredType;
        ISchemaComponentHandle ISchemaAtomicProvenance.ActualType=>owner._source.GetAtomic(index).ActualType;
        ISchemaAssessmentOrigin? ISchemaAtomicProvenance.OriginalAssessment=>owner._source.GetAtomic(index).OriginalAssessment;
    }
    private sealed class Cursor(CompleteTypedContainer owner):IEnumerator<SchemaAtomicItem>
    {
        private int _index=-1;
        private bool _closed;
        private void Check(){owner.Check();ObjectDisposedException.ThrowIf(_closed,this);}
        /// <inheritdoc/>
        public SchemaAtomicItem Current
        {
            get{Check();if((uint)_index>=(uint)owner._items.Length)throw new InvalidOperationException("Cursor is not positioned on an item.");return owner._items[_index];}
        }
        object IEnumerator.Current=>Current;
        /// <inheritdoc/>
        public bool MoveNext(){Check();if(_index<owner._items.Length)_index++;return _index<owner._items.Length;}
        /// <inheritdoc/>
        public void Reset(){Check();throw new NotSupportedException("Reset is unavailable.");}
        /// <inheritdoc/>
        public void Dispose()=>_closed=true;
    }
}
