<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="4.0">
<xsl:template name="xsl:initial-template"><out><xsl:iterate select="1 to 1000000">
<xsl:param name="total" select="0"/><xsl:on-completion select="$total"/>
<xsl:next-iteration><xsl:with-param name="total" select="$total + ."/></xsl:next-iteration>
</xsl:iterate></out></xsl:template></xsl:stylesheet>