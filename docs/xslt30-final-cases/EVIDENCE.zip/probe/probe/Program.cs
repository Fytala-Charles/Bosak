// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 12 November 2026
// PURPOSE              : Diagnose the final XSLT failures against unchanged qualified assemblies.
// SPECIAL NOTES        : Caught read-only diagnostic; secondary output is captured, never delivered to files.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 12-11-2026     | Creation                                                                                 |
//                      | Charles Korthout | 0.2   | 12-11-2026     | Resolve the runner's fully qualified diagnostic type name.                               |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Reflection;
using System.Text.Json;
using System.Xml.Linq;
using Bosak.XPath.Api;
using Bosak.XPath.Core.Xdm;
using Bosak.XPath.Providers.Xml;
using Bosak.XPath.Runtime.Vm;
using Bosak.Xslt.Api;
using Bosak.Xslt.Runtime;

try
{
    var root = args[0];
    var directory = Path.Combine(root, "tests/insn/try");
    var setPath = Path.Combine(directory, "_try-test-set.xml");
    XNamespace ns = "http://www.w3.org/2012/10/xslt-test-catalog";
    var testCase = XDocument.Load(setPath).Root!.Elements(ns + "test-case").Single(e => (string?)e.Attribute("name") == "try-022");
    var runner = Assembly.LoadFrom(args[1]).GetType("Bosak.Xslt.Conformance.Program")!;
    var runCase = runner.GetMethod("RunTestCase", BindingFlags.NonPublic | BindingFlags.Static)!;
    var runnerResult = runCase.Invoke(null, new object[] { testCase, new Dictionary<string, XElement>(), directory, setPath, root, ns, "try" });
    Console.WriteLine("Runner result: " + runnerResult);
    var runnerOutputs = (IReadOnlyDictionary<string, XdmValue>?)runner.GetField("_capturedSecondaryResults", BindingFlags.Static | BindingFlags.NonPublic)!.GetValue(null);
    Console.WriteLine("Runner secondary keys: " + JsonSerializer.Serialize(runnerOutputs?.Keys));

    var captured = new Dictionary<string, XdmValue>();
    var executable = new XsltCompiler().Compile(File.ReadAllText(Path.Combine(directory, "try-022.xsl")), new Uri(Path.Combine(directory, "try-022.xsl")).AbsoluteUri);
    var principal = executable.TransformObserved(null, null, new EvaluationContext(), "main", null, null, null,
        false, null, null, (uri, value, properties) =>
        {
            ResultTreeSerializer.Serialize(value, properties);
            captured[uri] = value;
        });
    Console.WriteLine("Principal: " + principal.StringValue);
    var node = XDocumentNode.Wrap(Xml11Loader.Parse(principal.StringValue, LoadOptions.PreserveWhitespace));
    foreach (var assertion in testCase.Element(ns + "result")!.Element(ns + "all-of")!.Elements(ns + "assert"))
    {
        try
        {
            var value = XPath31Expression.Compile(assertion.Value).Evaluate(node);
            Console.WriteLine("Principal assertion: " + assertion.Value + " => " + value.GetEffectiveBooleanValue());
        }
        catch (Exception error) { Console.WriteLine("Principal assertion error: " + error); }
    }
    foreach (var (uri, value) in captured)
    {
        Console.WriteLine("Observed secondary: " + uri);
        var answer = XPath31Expression.Compile("/output").Evaluate(value.NodeValue!);
        Console.WriteLine("Secondary /output: " + answer.GetEffectiveBooleanValue());
    }

    var adaptive = Path.Combine(root, "tests/decl/output/output-0707.xsl");
    var adaptiveExecutable = new XsltCompiler().Compile(File.ReadAllText(adaptive), new Uri(adaptive).AbsoluteUri);
    try
    {
        var value = adaptiveExecutable.Transform(null, initialTemplate: "{http://www.w3.org/1999/XSL/Transform}initial-template", rawResult: true);
        Console.WriteLine("Adaptive raw principal: " + ResultTreeSerializer.Serialize(value, adaptiveExecutable.OutputProperties));
    }
    catch (Exception error) { Console.WriteLine("Caught adaptive diagnostic: " + error); }
}
catch (Exception error)
{
    Console.Error.WriteLine(error);
    Environment.ExitCode = 1;
}
