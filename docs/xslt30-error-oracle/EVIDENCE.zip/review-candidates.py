from pathlib import Path
import csv,hashlib,json,shutil
packet=Path(__file__).resolve().parent;prior=packet.parent/'xslt30-static-errors-20261112'
rows=list(csv.DictReader((packet/'outcomes.csv').open(encoding='utf-8',newline='')))
potential={v['test'] for v in json.loads((prior/'ORACLE-REVIEW.json').read_text())['reviewCandidates']}
confirmed={r['test'] for r in rows if r['legacy_branch'] in ['legacy-code-alias','legacy-message-label']}
assert len(potential)==71 and len(confirmed)==54 and confirmed<=potential
record=dict(previousPotentialCandidates=71,observedAliasOrLabelBranches=54,previousCandidatesNotUsingThoseBranches=17,
 confirmedNames=sorted(confirmed),remainingNames=sorted(potential-confirmed),
 limitation='Observed branch use is not a normative defect verdict; 23 uncoded reports and 31 differing reported codes require separate review.')
(packet/'CANDIDATE-RESOLUTION.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
exceptions=json.loads((packet/'exceptions.json').read_text())
review=[]
for name,expected,actual in [('error-1140a','XTDE1140','FORX0002'),('error-1145a','XTDE1145','FORX0001')]:
 row=next(r for r in rows if r['test']==name);event=next(e for e in exceptions if e['test']==name)
 assert row['actual_code']==actual and row['allowed_error_codes']==expected and row['api_boundary']=='execute-call'
 path=packet/'measurement/corpus/tests/misc/error'/(name+'.xsl')
 shutil.copyfile(path,packet/(name+'.xsl'))
 review.append(dict(test=name,expected=expected,observed=actual,apiBoundary=row['api_boundary'],
    legacyBranch=row['legacy_branch'],fixtureSha256=hashlib.sha256(path.read_bytes()).hexdigest(),exception=event['exceptionChain'][0]))
record=dict(date='2026-11-12',reviewOnly=True,implementationStarted=False,
 immutableSpecification=dict(url='https://www.w3.org/TR/2017/REC-xslt-30-20170608/',revision='W3C Recommendation 8 June 2017',sections=['2.14 Error Handling','17.1 The xsl:analyze-string Instruction'],errors=['XTDE1140','XTDE1145']),
 cases=review,sourceObservation='ExecuteAnalyzeString passes regex/flags preparation through XPath RegexHelper without translating these two observed FORX codes.',
 proposedNext='Correct only the xsl:analyze-string regex/flags preparation boundary; preserve FORX errors from XPath functions, attribute-value-template evaluation and matching/non-matching child evaluation.',
 scope='Two simple fixture/reporting discrepancies reviewed; no verdict for the other 29 reported-code differences or the 55 late static-label observations. No engine change or admission.')
(packet/'REGEX-REVIEW.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(prior/'skips.csv',packet/'skips.csv')
shutil.copyfile(prior/'ORACLE-REVIEW.json',packet/'PRIOR-POTENTIAL-CANDIDATES.json')
print('Resolved 71 potential cases into 54 observed tolerance branches and 17 ordinary branches; reviewed two regex-reporting cases.')
