from pathlib import Path
import difflib,hashlib,json,shutil,subprocess,xml.etree.ElementTree as ET
packet=Path(__file__).resolve().parent
root=Path('D:/Development/Bosak/.worktrees/Bosak.XsltErrorOracle')
prior=packet.parent/'xslt30-static-errors-20261112'
assert json.loads((packet/'ADOPTION.json').read_text())['beforeDiagnosticImplementation']
diag=packet/'diagnostic';diag.mkdir(exist_ok=False)
original=(prior/'RUNNER-SOURCE.cs').read_text(encoding='utf-8')
assert original.replace('\r\n','\n')==(root/'tests/Bosak.Xslt.Conformance/Program.cs').read_text(encoding='utf-8')
source=original
def replace(before,after):
 global source
 assert source.count(before)==1,before
 source=source.replace(before,after,1)
replace('class Program\n{','partial class Program\n{')
replace('    static void Main(string[] args)\n    {','    static void Main(string[] args)\n    {\n        if (args.Length == 1 && args[0] == "--oracle-controls") { AuditRunControls(); return; }')
start=source.index('    static TestResult RunTestCase(')
end=source.index('    private static bool ErrorCodeMatches(',start)
body=source[start:end]
def alter(before,after):
 global body
 assert body.count(before)==1,before
 body=body.replace(before,after,1)
alter('        var name = testCase.Attribute("name")?.Value ?? "unknown";', '        var name = testCase.Attribute("name")?.Value ?? "unknown";\n        _auditCase = name;\n        _auditPhase = "adapter-setup";')
alter('            var executable = compiler.Compile(xslDoc, baseUri);','            _auditPhase = "compile-call";\n            var executable = compiler.Compile(xslDoc, baseUri);\n            _auditPhase = "post-compile-setup";')
alter('            var observedResult = executable.TransformObserved(sourceNode,','            _auditPhase = "execute-call";\n            var observedResult = executable.TransformObserved(sourceNode,')
alter('            // Compare with expected result','            _auditPhase = "assertion";\n            // Compare with expected result')
alter('            if (compareOk)\n            {','            if (compareOk)\n            {\n                AuditWrite("normal-result", new { accepted = true });')
alter('        catch (Exception ex)\n        {\n            // Check if an error was expected.', '        catch (Exception ex)\n        {\n            AuditException(ex);\n            // Check if an error was expected.')
source=source[:start]+body+source[end:]
start=source.index('    private static bool ErrorCodeMatches(')
end=source.index('    // Error-code-shaped tokens',start)
body=source[start:end]
assert body.count('return true;')==7 and body.count('return false;')==3 and body.count('return matches;')==1
for branch in ['wildcard','unspecified-code','message-code-substring','legacy-retired-code','legacy-recoverable-code','legacy-message-label','legacy-code-alias']:
 body=body.replace('return true;',f'return AuditMatch(expectedCode, ex, "{branch}", true);',1)
for branch in ['unresolved-prefix-exact-mode','exact-mode-no-match','no-match']:
 body=body.replace('return false;',f'return AuditMatch(expectedCode, ex, "{branch}", false);',1)
body=body.replace('return matches;','return AuditMatch(expectedCode, ex, "structured-local-or-qname", matches);')
source=source[:start]+body+source[end:]
history='//                      | Charles Korthout | 3.82  | 12-11-2026     | Diagnostic-only phase/identity/branch tracing; original decisions remain unchanged.        |\n'
marker='//                      | Charles Korthout | 3.81'
line_end=source.index('\n',source.index(marker))+1
source=source[:line_end]+history+source[line_end:]
(diag/'Program.cs').write_text(source,encoding='utf-8')
shutil.copyfile(packet/'TraceHelpers.cs',diag/'TraceHelpers.cs')
(packet/'DIAGNOSTIC.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),source.splitlines(True),fromfile='sealed-production-Program.cs',tofile='diagnostic-Program.cs')),encoding='utf-8')
project=ET.Element('Project',Sdk='Microsoft.NET.Sdk');props=ET.SubElement(project,'PropertyGroup')
for key,value in [('OutputType','Exe'),('TargetFramework','net10.0'),('AssemblyName','Bosak.Xslt.Conformance'),('ImplicitUsings','enable'),('Nullable','enable'),('GenerateDocumentationFile','true')]:ET.SubElement(props,key).text=value
refs=ET.SubElement(project,'ItemGroup');engine={}
prior_hashes=json.loads((prior/'RUNTIME-HASHES.json').read_text())
for path in sorted((prior/'runtime').glob('Bosak.*.dll')):
 if path.name=='Bosak.Xslt.Conformance.dll':continue
 digest=hashlib.sha256(path.read_bytes()).hexdigest();assert digest==prior_hashes[path.name];engine[path.name]=digest
 reference=ET.SubElement(refs,'Reference',Include=path.stem);ET.SubElement(reference,'HintPath').text=str(path)
assert len(engine)==9
ET.indent(project);ET.ElementTree(project).write(diag/'Diagnostic.csproj',encoding='unicode')
with (packet/'DIAGNOSTIC-BUILD.log').open('xb') as stream:result=subprocess.run(['dotnet','build',str(diag/'Diagnostic.csproj'),'-c','Release'],stdout=stream,stderr=subprocess.STDOUT)
assert result.returncode==0
output=diag/'bin/Release/net10.0'
assert all(hashlib.sha256((output/name).read_bytes()).hexdigest()==digest for name,digest in engine.items())
record=dict(engineSourceCommit='df16de7f39a556c6f9afea3eee9f61ef9bbc602e',diagnosticWorktreeBase=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),
 engineHashes=engine,engineBinariesUnchanged=True,processorAndCatalogFlagsUnchanged=True,legacyMatcherReturnValuesPreserved=True,
 originalRunnerSourceSha256=hashlib.sha256((prior/'RUNNER-SOURCE.cs').read_bytes()).hexdigest(),
 diagnosticSources={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in diag.glob('*.cs')},
 scope='Diagnostic-only observer and caught synthetic matcher controls; no production source, profile, fixture, gate or acceptance changes')
(packet/'DIAGNOSTIC-IDENTITY.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print('Built diagnostic-only observer against nine unchanged sealed engine assemblies.')
