from pathlib import Path
import hashlib,importlib.util,json,shutil
packet=Path(__file__).resolve().parent;prior=packet.parent/'xslt30-static-errors-20261112'
root=Path('D:/Development/Bosak/.worktrees/Bosak.XsltErrorOracle')
measurement=packet/'measurement';measurement.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('gate',root/'tools/xslt30_gate.py');gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
plan=json.loads((prior/'PLAN.json').read_text());inputs=json.loads((prior/'CORPUS-BEFORE.json').read_text())
assert gate.inventory(prior/'corpus')==inputs
shutil.copytree(prior/'corpus',measurement/'corpus')
shutil.copytree(packet/'diagnostic/bin/Release/net10.0',measurement/'runtime')
engine=json.loads((packet/'DIAGNOSTIC-IDENTITY.json').read_text())['engineHashes']
assert all(gate.digest(measurement/'runtime'/name)==digest for name,digest in engine.items())
plan.update(sourceCommit=None,sourceBaseCommit='065db051f18b6b427c7fab83e840f4ce7547f11c',engineSourceCommit='df16de7f39a556c6f9afea3eee9f61ef9bbc602e',
 sourceIdentity='Diagnostic-only observer outside production tree; exact sources and nine unchanged engine DLL hashes retained',
 selection='Same original 579-case error set, same Legacy/Xslt30 profile and acceptance; trace only')
for name,value in [('PLAN.json',plan),('CORPUS-BEFORE.json',inputs),('RUNTIME-HASHES.json',gate.runtime_hashes(measurement/'runtime'))]:gate.write_json(measurement/name,value)
shutil.copyfile(prior/'run-selected.py',packet/'run-selected.py')
print('Prepared fresh observational packet; nine engine DLLs and all original corpus bytes match.')
