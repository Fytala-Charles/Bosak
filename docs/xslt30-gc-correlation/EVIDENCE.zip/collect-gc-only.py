"""One separately reviewed GC-verbose experiment, using unchanged sealed stack-controller functions."""
from pathlib import Path
import importlib.util,json,hashlib
source=Path('D:/Development/Bosak/.worktrees/Bosak.CpuProfile/tools/xslt30_stack_profile.py')
spec=importlib.util.spec_from_file_location('support',source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
output=Path('D:/Development/Bosak/.guard-tmp/xslt30-gc-only-run-20261113')
profiler=Path('D:/Development/Bosak/.guard-tmp/xslt30-cpu-profile-20261113/profiler/.store/dotnet-trace/10.0.745401/dotnet-trace/10.0.745401/tools/net8.0/any/dotnet-trace.dll')
m.prepare(Path('D:/Development/Bosak/.guard-tmp/xslt30-case-cost-run-20261113'),Path('D:/Development/Bosak/.guard-tmp/xslt30-final-retry-20261112/corpus'),profiler,output)
plan,pin=m.validate(output);tool,command=m.commands(output,plan,pin)
old=command[command.index('--profile')+1];assert old=='dotnet-common,dotnet-sampled-thread-time'
command[command.index('--profile')+1]='gc-verbose'
m.write(output/'EXPERIMENT.json',dict(kind='One GC-verbose-only capture, not retry or qualification',originalProfile=old,actualProfile='gc-verbose',supportSourceSha256=m.sha(source),experimentSourceSha256=m.sha(Path(__file__)),targetBinaryChanges=False))
work=output/'work';work.mkdir()
r=m.bounded(command,work,output/'COLLECT',180,output/'raw.nettrace')
assert r['success'], 'Original failed attempt retained; never retry automatically'
rows=[json.loads(s) for s in (work/'case-costs.jsonl').read_text().splitlines()];m.validate_cases(rows,plan['policy']['expectedResults'])
end=json.loads((work/'case-cost-end.json').read_text());assert end['rows']==54 and not end['errors']
native=json.loads((work/'case-cost-runtime.json').read_text());assert native['frameworkVersion']=='10.0.11'
for n,v in pin['nativeFiles'].items():assert native['modules'][n]['sha256']==v['sha256']
m.validate(output)
gate=m.module('gate_after',m.ROOT/'tools/xslt30_gate.py');m.write(output/'CORPUS-AFTER.json',gate.inventory(output/'corpus'));assert json.loads((output/'CORPUS-BEFORE.json').read_text())==json.loads((output/'CORPUS-AFTER.json').read_text())
m.write(output/'RUNTIME-AFTER.json',m.inventory(output/'runtime'));m.write(output/'TARGET-FRAMEWORK-AFTER.json',m.inventory(Path(pin['frameworkDirectory'])))
collector=json.loads((output/'COLLECTOR-FRAMEWORK.json').read_text());m.write(output/'COLLECTOR-FRAMEWORK-AFTER.json',m.inventory(Path(collector['path'])))
m.write(output/'PROFILER-AFTER.json',{n:m.sha(profiler.parent/n) for n in plan['profilerFiles']})
m.write(output/'RESULTS.json',dict(diagnosticOnly=True,qualification=False,selectedCases=len(rows),passed=sum(x['result']=='Pass' for x in rows),skipped=sum(x['result']=='Skip' for x in rows),caseWallSeconds=sum(x['wallSeconds'] for x in rows),caseCpuSeconds=sum(x['cpuSeconds'] for x in rows),traceSha256=m.sha(output/'raw.nettrace'),noStackSampler=True,inventoryUnchanged=True))
print((output/'RESULTS.json').read_text())
