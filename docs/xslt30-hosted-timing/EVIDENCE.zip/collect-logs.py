from pathlib import Path
import json,subprocess,concurrent.futures
p=Path('D:/Development/Bosak/.guard-tmp/xslt30-hosted-timing-20261113');root=Path('D:/Development/Bosak/.worktrees/Bosak.TimingReview');rows=json.loads((root/'docs/xslt30-hosted-timing/SOURCES.json').read_text(encoding='utf-8'))
def collect(row):
 label=row['id'];run=row['run'];attempt=str(row['attempt'])
 for name,args in [('workflow',['gh','api',f'repos/Fytala-Charles/Bosak/actions/runs/{run}/attempts/{attempt}']),('log',['gh','run','view',run,'--attempt',attempt,'--log'])]:
  path=(p/'metadata'/(label+'-workflow.json')) if name=='workflow' else (p/'logs'/(label+'.log'))
  assert not path.exists();path.write_bytes(subprocess.check_output(args))
 w=json.loads((p/'metadata'/(label+'-workflow.json')).read_text(encoding='utf-8'));assert w['status']=='completed' and w['run_attempt']==row['attempt'];return dict(id=label,conclusion=w['conclusion'])
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 futures=[pool.submit(collect,row) for row in rows]
 for f in concurrent.futures.as_completed(futures):print(json.dumps(f.result()),flush=True)
print('Retained all seven workflow-attempt metadata records and raw logs.',flush=True)
