from pathlib import Path
import json,importlib.util,copy
r=Path('D:/Development/Bosak/.worktrees/Bosak.TimingReview');h=r/'docs/xslt30-hosted-timing';p=Path('D:/Development/Bosak/.guard-tmp/xslt30-hosted-timing-20261113')
s=importlib.util.spec_from_file_location('analysis',h/'analyze.py');a=importlib.util.module_from_spec(s);s.loader.exec_module(a)
base=dict(checkoutCommit='commit-a',sourceTree='tree-a',applicationFingerprint='payload-a',corpusFingerprint='corpus-a',caseInventoryFingerprint='cases-a',profile='profile-a',timeoutSeconds=1200,memoryLimitBytes=8589934592)
controls=[]
for name,change,expected in [('same-checkout-payload',{},'same-checkout-and-payload'),('same-checkout-rebuilt',{'applicationFingerprint':'payload-b'},'same-checkout-different-payload'),('equivalent-tree-payload',{'checkoutCommit':'commit-b'},'equivalent-tree-and-payload'),('equivalent-tree-rebuilt',{'checkoutCommit':'commit-b','applicationFingerprint':'payload-b'},'equivalent-tree-different-payload'),('different-source',{'checkoutCommit':'commit-b','sourceTree':'tree-b'},'different-source-cohorts')]+[(key, {key:'different' if isinstance(base[key],str) else 1},'not-comparable-policy-or-inputs') for key in ['corpusFingerprint','caseInventoryFingerprint','profile','timeoutSeconds','memoryLimitBytes']]:
 right=base|change;actual=a.comparison(base,right);assert actual==expected;controls.append(dict(name=name,left=base,right=right,expected=expected,actual=actual,success=True))
try:a.comparison(base,base|dict(sourceTree='contradictory'))
except ValueError:controls.append(dict(name='contradictory-checkout-refused',left=base,right=base|dict(sourceTree='contradictory'),expectedException='ValueError',success=True))
else:raise AssertionError('Contradictory identity accepted')
for name,text in [('nonmonotonic-progress','Elapsed 0s; current test: a\nElapsed 20s; current test: b\nElapsed 10s; current test: c'),('missing-start','Elapsed 20s; current test: a')]:
 try:a.progress(text)
 except AssertionError:controls.append(dict(name=name,text=text,expectedException='AssertionError',success=True))
 else:raise AssertionError(name)
record=dict(success=all(c['success'] for c in controls),count=len(controls),controls=controls,scope='Synthetic comparison/sampling refusal controls; no .NET execution or gate modification.')
(h/'CONTROLS.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
report=a.analyze(r,json.loads((h/'SOURCES.json').read_text(encoding='utf-8')),lambda name:(p/name).read_bytes());(h/'REPORT.json').write_bytes((json.dumps(report,indent=2)+'\n').encode());print('Thirteen comparison/sampling controls and all seven original artifact checks passed.')
