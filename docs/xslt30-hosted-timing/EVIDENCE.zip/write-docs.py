﻿from pathlib import Path
import json
r=Path('D:/Development/Bosak/.worktrees/Bosak.TimingReview');p=Path('D:/Development/Bosak/.guard-tmp/xslt30-hosted-timing-20261113');h=r/'docs/xslt30-hosted-timing';report=json.loads((h/'REPORT.json').read_text(encoding='utf-8'));rows=report['attempts']
labels={'df16-timeout':'df16 original main','df16-success':'df16 fresh same-commit run','pr481-attempt1':'PR481 attempt 1','pr481-attempt2':'PR481 attempt 2','pr482':'PR482','main482-timeout':'PR482 post-merge main','pr483':'PR483'}
runrows=[];samples=[]
for row in rows:
 link=f"[{labels[row['id']]}](https://github.com/Fytala-Charles/Bosak/actions/runs/{row['runId']}/attempts/{row['attempt']})"
 result='Completed: 10,221 / 0 / 4,380' if not row['rightCensored'] else 'Timed out; incomplete, not a pass'
 last=row['lastCase'] if row['rightCensored'] else '—'
 runrows.append(f"| {link} | {row['elapsedSeconds']:,.3f} | {result} | {last} | {row['platform']['region']} |")
 vals=[str(row['firstObservedMilestones'][key]['seconds']) if row['firstObservedMilestones'][key] else '—' for key in ['sf-','si-','sx-']]
 samples.append('| '+labels[row['id']]+' | '+' | '.join(vals)+' |')
readme='''# Hosted XSLT gate timing investigation — 13 November 2026

Two retained comparisons show a successful run and a timeout on the **same checkout commit with identical SHA-256 manifests for all 32 application-payload files**, including nine engine assemblies. A semantic code change is therefore not necessary for a timeout to occur. This establishes execution-time variation in the retained sample; it does **not establish its cause**.

This is a selected historical sample, not a randomized experiment or a failure-rate estimate. Three incomplete attempts remain failed. No diagnostic or benchmark execution was launched to produce this analysis; ordinary post-merge/PR CI is separate. Engine, runner, workflow, versions, limits, exclusions and assertions are unchanged.

## Retained attempts

All seven use the same immutable `w3c/xslt30-test@fddf1cf920087e791f13315d68dfbe874d97dc56`, 234-set/14,601-case inventory, Legacy/Xslt30 basic/non-schema-aware profile and 1,200-second/8 GiB limits. The four completed artifacts independently replay **10,221 passed / 0 failed / 4,380 excluded**. Corpus and runtime-integrity receipts match in all seven. No FAIL lines are observed in the incomplete transcripts; this does not establish that their unexecuted work would pass.

| Attempt | Observed elapsed seconds | Outcome | Last recorded case on timeout | Reported region |
|---|---:|---|---|---|
'''+ '\n'.join(runrows)+'''

Timeout elapsed values are **right-censored observations**: the controller stopped the process, so its eventual completion time is unknown. They are not complete durations and must not be included as successful 1,200-second benchmark results. `last_test.txt` names the last recorded case; it is not a stack trace or proof that the named test hung.

## Controlled comparisons and limits

| Comparison | Source/payload relationship | What can be concluded |
|---|---|---|
| df16 original timeout vs fresh success | Same checkout `df16de7f`; identical 32-file application manifest and nine-engine-assembly manifest | One payload completed in 1,079.563s; another attempt exceeded the 1,200s cap. |
| PR481 attempts 1 vs 2 | Same checkout `dc477572`; identical 32-file application manifest and nine-engine-assembly manifest | One payload completed in 1,133.657s; another attempt exceeded the cap. |
| PR482 vs its post-merge main | Same source tree `6331a223`; different checkout commits and application manifests | Context only. This is not an exact-binary A/B comparison and cannot attribute a timing difference to source changes. |

“Application payload” means the 32 files listed by the retained manifest. It does **not include the external dotnet host, shared runtime/JIT, OS, CPU allocation, process state or I/O/cache conditions**. The logged image revision is `windows-2025-vs2026` / `20261103.298.1` throughout, but regions vary. Central US appears in both a timeout and the fastest retained success; region alone is not an established explanation.

## Sampled progress

These are the first **observed** `sf-*`, `si-*` and `sx-*` case prefixes in approximately 20-second watchdog samples, not exact phase starts or individual test durations. No missing sample is interpreted as zero time. Full case names and samples are retained in [the report](REPORT.json).

| Attempt | First sampled sf-* (s) | First sampled si-* (s) | First sampled sx-* (s) |
|---|---:|---:|---:|
'''+ '\n'.join(samples)+'''

The two identical-payload timeout comparisons show slower sampled progress before their terminal recorded cases. That is consistent with accumulated slower execution rather than evidence for one universal final-test hang; it is not a causal CPU, GC or I/O diagnosis. The three timeouts end at different recorded cases. The original date-020 fixture deliberately loops one million times to test stable current-dateTime, but these data do not justify blaming, shortening or excluding that case.

## Proposed next diagnostic step

Keep the production gate unchanged. Prepare a separate, explicitly labelled diagnostic lane before another semantic slice:

1. Capture host `dotnet --info`, OS/image, CPU count/affinity and job allocation, then sample the unchanged child's elapsed/CPU time, working/committed memory, process I/O and last-test marker. Bind the exact 32-file payload and immutable full corpus. Keep the same bounds and retain every attempt, including incomplete ones.
2. If case-level attribution is still needed, use a diagnostic-only runner copy to record per-case wall/CPU and compile/execute boundaries. Retain unchanged nine-engine DLL hashes and the observer diff; prove case-status and exclusion parity. Declare the different runner binary and instrumentation overhead rather than treating it as an untouched performance measurement.
3. Use those measurements to separate host/runtime/I/O effects from expensive engine paths before proposing optimization or a reviewed budget change. No automatic retry, timeout increase, shortened fixture, exclusion or gate admission is proposed here.

No new lane or execution is implemented by this PR. Existing artifacts do not contain per-case durations, process CPU, GC/heap or I/O measurements, so root cause remains open. SDK10.0.301 is the recorded qualification pin; the exact external runtime/JIT binary is not hash-bound by the application manifest.

## Provenance and replay

[SOURCES.json](SOURCES.json) identifies every original artifact by digest and run/attempt. Existing sealed repository archives are referenced without rewriting or duplicating them; three previously local original artifacts are retained under `artifacts/`. [EVIDENCE.zip](EVIDENCE.zip) contains the raw workflow logs, attempt metadata, Git commit/tree identities and original receipts. [MANIFEST.json](MANIFEST.json) seals every new file and evidence entry. The source tree must match the corresponding workflow head before a record is compared.

Run `python docs/xslt30-hosted-timing/verify.py` for offline replay of the seven original artifacts, all four complete case ledgers and exclusion inventories, exact-payload vs equivalent-tree comparisons, sampled progress/platform fields and thirteen synthetic refusal/comparison controls. [Renderer receipt](DOCUMENTATION-CHECKS.json). No .NET qualification is rerun for this documentation-only analysis.

PR #483 was merged at `04eea7317ab2f71f7f3644b1ebcc30076b9dbdaf` after its six checks and independent hosted replay passed. Its successful receipt does not replace any earlier timeout. Core/server1.81.8 remains unpublished; published Core1.81.2 and extension0.2.6 stay unchanged. No complete-conformance or performance-acceptance claim follows.
'''
(h/'README.md').write_bytes(readme.encode())
summary='The [hosted XSLT timing investigation](xslt30-hosted-timing/README.md) replays seven retained attempts without new diagnostic execution or gate changes. Two same-checkout comparisons have identical32-file application manifests yet include both a success and a1200-second timeout. Four complete runs each replay10,221/0/4,380; three incomplete timeouts remain failed. Equivalent-tree/different-payload comparisons are separate. Twenty-second progress samples show earlier delay, but cannot identify CPU/GC/I/O causes or individual test durations. No failure rate, regional cause or performance acceptance is inferred. Next prepare separate host/process telemetry under unchanged bounds before another semantic slice. PR483 merged04eea731 after all six checks and hosted replay passed; parent timeouts remain original evidence.\n\n'
for name in ['IMPLEMENTATION_STATUS','AGENT_HANDOVER','DEVELOPMENT_HISTORY']:
 f=r/('docs/'+name+'.md');f.write_bytes(('# Hosted XSLT timing evidence — 13 November 2026\n\n'+summary+'Documentation-only worktree `.worktrees/Bosak.TimingReview`, branch `docs/xslt30-hosted-timing`, base04eea731. Engine/source versions, runner/workflows, exclusions and1200-second/8GiB bounds unchanged. Core/server1.81.8 remains unpublished. Preserve original owner checkout and every sealed dossier.\n\n').encode()+f.read_bytes())
f=r/'docs/CONFORMANCE.md';data=f.read_bytes();needle=b'## Scoped named-template prefix reporting follow-up';assert needle in data;f.write_bytes(data.replace(needle,('## Hosted gate timing evidence\n\n'+summary).encode()+needle,1))
f=r/'docs/DOCUMENTATION_RENDERER_TEST.md';f.write_bytes(('# Hosted timing renderer check — 13 November 2026\n\nThe [timing receipt](xslt30-hosted-timing/DOCUMENTATION-CHECKS.json) checks retained-attempt, controlled-comparison and sampled-progress tables; incomplete-result warnings; links and unchanged Fytala/historical content. No screenshot/PDF acceptance is asserted.\n\n').encode()+f.read_bytes())
print('Timing findings, limitations and a separate diagnostic proposal are documented; canonical status/handover/history synchronized.')
