from pathlib import Path
import json,zipfile,io,subprocess,concurrent.futures
r=Path('D:/Development/Bosak/.worktrees/Bosak.TimingReview');p=Path('D:/Development/Bosak/.guard-tmp/xslt30-hosted-timing-20261113');rows=json.loads((r/'docs/xslt30-hosted-timing/SOURCES.json').read_text(encoding='utf-8'));commits=set()
for row in rows:
 data=(r/row['source']).read_bytes()
 if row['nested']:
  with zipfile.ZipFile(io.BytesIO(data)) as z:data=z.read(row['nested'])
 with zipfile.ZipFile(io.BytesIO(data)) as z:commits.add(json.loads(z.read('RUN.json'))['sourceCommit'])
 commits.add(json.loads((p/'metadata'/(row['id']+'-workflow.json')).read_text(encoding='utf-8'))['head_sha'])
def collect(sha):
 data=subprocess.check_output(['gh','api','repos/Fytala-Charles/Bosak/git/commits/'+sha]);(p/'metadata'/('commit-'+sha+'.json')).write_bytes(data);return sha
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for sha in pool.map(collect,sorted(commits)):print(sha,flush=True)
