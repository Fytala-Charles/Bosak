"""Hold a temporary system-idle reservation only while the recorded qualification child lives."""
import ctypes
from ctypes import wintypes
import json
from pathlib import Path
import time

packet = Path(__file__).resolve().parent
run = json.loads((packet / 'RUN.json').read_text())
if run['status'] != 'Running':
    raise ValueError('No active recorded qualification child')
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel.OpenProcess.restype = wintypes.HANDLE
kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel.SetThreadExecutionState.argtypes = [wintypes.DWORD]
kernel.SetThreadExecutionState.restype = wintypes.DWORD
kernel.CloseHandle.argtypes = [wintypes.HANDLE]
handle = kernel.OpenProcess(0x100000, False, run['processId'])
if not handle:
    raise ctypes.WinError(ctypes.get_last_error())
receipt = dict(processId=run['processId'], scope='Temporary helper-thread ES_SYSTEM_REQUIRED reservation; no display or persistent power setting change', success=False)
started = time.monotonic()
try:
    if not kernel.SetThreadExecutionState(0x80000001):
        raise ctypes.WinError(ctypes.get_last_error())
    print('Temporary idle-sleep reservation active for qualification child', run['processId'], flush=True)
    while time.monotonic() - started < 1300:
        status = kernel.WaitForSingleObject(handle, 1000)
        if status == 0:
            receipt['success'] = True
            break
        if status != 258:
            raise ctypes.WinError(ctypes.get_last_error())
finally:
    receipt['reservationReleased'] = bool(kernel.SetThreadExecutionState(0x80000000))
    kernel.CloseHandle(handle)
    receipt['elapsedSeconds'] = round(time.monotonic() - started, 3)
    (packet / 'HOST-AWAKE.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('Temporary reservation released', flush=True)
