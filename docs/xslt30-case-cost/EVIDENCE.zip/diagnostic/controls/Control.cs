// Generated contained diagnostic controls; no unhandled negative cases.
using System.Text.Json;
internal static class Control
{
    static int Main(string[] args)
    {
        try
        {
            if (!CaseCosts.Initialize(args[0])) return 1;
            var first = CaseCosts.Begin();
            double checksum = 0; for (int i=1;i<100000;i++) checksum += Math.Sqrt(i);
            CaseCosts.End(first,"control","positive","Pass");
            var second = CaseCosts.Begin();
            CaseCosts.End(second,"control","fast-skip","Skip");
            CaseCosts.Close();
            if (checksum <= 0 || CaseCosts.Initialize(args[1])) return 1;
            Environment.ExitCode = 0;
            Console.WriteLine("Positive timing, fast skip and caught native-version refusal passed.");
            return 0;
        }
        catch (Exception error) { Console.Error.WriteLine(error); return 1; }
    }
}
