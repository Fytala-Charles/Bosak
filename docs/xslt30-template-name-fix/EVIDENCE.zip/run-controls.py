from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys,time
packet=Path(__file__).resolve().parent
root=Path('D:/Development/Bosak/.worktrees/Bosak.TemplateNameErrors')
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
control=module('bounded',root/'docs/xslt30-qualification/run.py');classifier=module('classifier',packet/'classifier.py')
assert not (packet/'CONTROLS.json').exists()
command=['dotnet',str(packet/'diagnostic/bin/Release/net10.0/Bosak.Xslt.Conformance.dll'),'--oracle-controls']
work=packet/'control-work';work.mkdir(exist_ok=False)
job=control.BoundedJob(8589934592)
started=time.monotonic();process=None
try:
 with (packet/'CONTROLS.stdout.log').open('xb') as stdout,(packet/'CONTROLS.stderr.log').open('xb') as stderr:
  with control.process_error_mode():process=subprocess.Popen(command,cwd=work,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
  job.assign(process)
  try:process.wait(timeout=120)
  except subprocess.TimeoutExpired:job.terminate();process.wait(timeout=15)
finally:job.close()
events=[json.loads(s[6:]) for s in (packet/'CONTROLS.stderr.log').read_text(encoding='utf-8-sig').splitlines() if s.startswith('AUDIT ')]
rows=[]
for event in events:
 if event['kind']!='control':continue
 data=event['data'];actual=classifier.compare(data['expected'],data['error'])
 rows.append(dict(name=event['caseName'],legacyExpected=data['legacyExpected'],legacyActual=data['legacyActual'],
    exactExpected=data['exactExpected'],exactActual=actual,success=data['legacyExpected']==data['legacyActual'] and data['exactExpected']==actual))
success=process.returncode==0 and len(rows)==16 and all(r['success'] for r in rows)
receipt=dict(success=success,command=command,exitCode=process.returncode,elapsedSeconds=round(time.monotonic()-started,3),
 timeoutSeconds=120,memoryLimitBytes=8589934592,errorModeScope='Runner and child only; no unhandled negative .NET cases',controls=rows,
 hashes={n:hashlib.sha256((packet/n).read_bytes()).hexdigest() for n in ['CONTROLS.stdout.log','CONTROLS.stderr.log']})
(packet/'CONTROLS.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,indent=2));raise SystemExit(0 if success else 1)
