from pathlib import Path
import subprocess,sys,json,time,hashlib
p=Path(__file__).resolve().parent;q=p.parent/'xslt30-template-name-qualified-20261113';root=Path('D:/Development/Bosak/.worktrees/Bosak.TemplateNameErrors')
while not (q/'GATE.json').exists():time.sleep(5)
assert json.loads((q/'GATE.json').read_text(encoding='utf-8'))['success']
for name,args in [('write-final-docs.py',[]),('seal.py',[])]:
 print('Starting '+name,flush=True);subprocess.run([sys.executable,str(p/name),*args],cwd=root,check=True)
subprocess.run(['node',str(p/'render.cjs')],cwd=root,check=True)
h=root/'docs/xslt30-template-name-fix';f=h/'MANIFEST.json';m=json.loads(f.read_text(encoding='utf-8'));m['files']={v.name:dict(bytes=v.stat().st_size,sha256=hashlib.sha256(v.read_bytes()).hexdigest()) for v in h.iterdir() if v.is_file() and v.name!='MANIFEST.json'};f.write_bytes((json.dumps(m,indent=2)+'\n').encode())
subprocess.run([sys.executable,str(h/'verify.py')],cwd=root,check=True)
subprocess.run([sys.executable,str(p/'write-pr-body.py')],cwd=root,check=True)
print('All local qualification, dossier replay and renderer checks passed.',flush=True)
