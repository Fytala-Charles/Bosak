﻿from pathlib import Path
p=Path('D:/Development/Bosak/.guard-tmp/xslt30-template-name-fix-20261113');old=p.parent/'xslt30-module-placement-fix-20261113'
s=(old/'seal.py').read_text(encoding='utf-8-sig')
for a,b in [('Bosak.ModulePlacementErrors','Bosak.TemplateNameErrors'),("q=p.parent/'xslt30-module-placement-qualified-20261113'","q=p.parent/'xslt30-template-name-qualified-20261113'"),("h=r/'docs/xslt30-module-placement-fix'","h=r/'docs/xslt30-template-name-fix'"),("old=p.parent/'xslt30-analyze-string-fix-20261113'","old=p.parent/'xslt30-module-placement-fix-20261113'"),("qualified=p.parent/'xslt30-analyze-string-qualified-20261113'","qualified=p.parent/'xslt30-module-placement-qualified-20261113'"),('7584295ddaecd20a09eb22ad270f06d87af0cd86','de15d03c18884b4951fa9b9883fce42512fdeba0'),('ModulePlacementErrorCodeTests.cs','TemplateNameErrorCodeTests.cs'),('HOSTED-PARENT-MAIN','HOSTED-PARENT-PR'),("'.txt','.cs'","'.txt','.cs','.diff'"),("['error-0010x','error-0010z','error-0170a','error-0170b','error-0190a','error-0190b']","['error-0280d','error-0280f']")]:s=s.replace(a,b)
needle=" for name in ['Program.cs','TraceHelpers.cs','Diagnostic.csproj']:add(z,'diagnostic/'+name,(p/'diagnostic'/name).read_bytes())";assert needle in s;s=s.replace(needle,needle+"\n for name in ['Program.cs','Probe.csproj']:add(z,'caught-probe/'+name,(p/'caught-probe'/name).read_bytes())")
(p/'seal.py').write_bytes(s.encode())
s=(old/'render.cjs').read_text(encoding='utf-8').replace(str(old/'render').replace('\\','/'),str(p/'render').replace('\\','/')).replace('docs/xslt30-module-placement-fix/DOCUMENTATION-CHECKS.json','docs/xslt30-template-name-fix/DOCUMENTATION-CHECKS.json')
s=s.replace('const files = [',"const files = ['docs/xslt30-template-name-fix/README.md', ",1);needle="  if (file === 'docs/xslt30-module-placement-fix/README.md') {";assert needle in s
s=s.replace(needle,"""  if (file === 'docs/xslt30-template-name-fix/README.md') {
    if (tokens.filter(t=>t.type==='table_open').length !== 2) throw Error('Template-name tables missing');
    for (const value of ['XTSE0280','26,422','8,397','10,221 passed / 0 failed / 4,380 excluded','28 passed','inner cause','unpublished']) if (!rendered.includes(value)) throw Error('Template-name result/scope missing: '+value);
  }
"""+needle,1)
(p/'render.cjs').write_bytes(s.encode());print('Prepared complete evidence seal and renderer checks.')
