// Generated caught diagnostic; not production source.
using Bosak.Xslt.Api;
try {
 new XsltCompiler().Compile("<xsl:stylesheet xmlns:xsl='http://www.w3.org/1999/XSL/Transform' version='3.0'><xsl:template name='missing:entry'/></xsl:stylesheet>");
 System.Console.WriteLine("Unexpected success");
} catch (System.Exception error) { System.Console.WriteLine(error.ToString()); }
