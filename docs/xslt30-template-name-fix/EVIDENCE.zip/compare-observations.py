﻿from pathlib import Path
import csv,json
p=Path('D:/Development/Bosak/.guard-tmp/xslt30-template-name-fix-20261113');old=p.parent/'xslt30-module-placement-fix-20261113'
a={r['test']:r for r in csv.DictReader((p/'outcomes.csv').open(encoding='utf-8'))};b={r['test']:r for r in csv.DictReader((old/'outcomes.csv').open(encoding='utf-8'))}
changed=[n for n in a if any(a[n][k]!=b[n][k] for k in ['actual_code','identity_kind','identity_origin','catalog_code_assessment','legacy_branch'])];assert set(changed)=={'error-0280d','error-0280f'}
assert all(a[n]['status']==b[n]['status'] and a[n]['reason']==b[n]['reason'] for n in a)
chains={r['test']:r['exceptionChain'] for r in json.loads((p/'exceptions.json').read_text(encoding='utf-8'))}
for name in changed:
 assert a[name]['actual_code']=='XTSE0280' and a[name]['catalog_code_assessment']=='reported-code-exact' and a[name]['legacy_branch']=='message-code-substring'
 assert len(chains[name])==2 and chains[name][1]['message'].startswith('XPST0081:')
r=dict(onlyChangedReportedIdentities=changed,casesNewlyMatchingWithoutAliases=changed,alreadyAcceptedAlternativeCases=[],all579StatusesAndSkipReasonsUnchanged=True,originalCausesPreserved=True,remainingCodeDifferences=25,remainingUncodedReports=23,remainingToleranceBranches=48,namespaceProof='Leading local compile-time codes only; no independent namespace proof.',cases=[dict(test=n,before={k:b[n][k] for k in ['actual_code','catalog_code_assessment','legacy_branch']},after={k:a[n][k] for k in ['actual_code','catalog_code_assessment','legacy_branch']}) for n in changed])
(p/'CASE-COMPARISON.json').write_bytes((json.dumps(r,indent=2)+'\n').encode());print(json.dumps(r,indent=2))
