﻿from pathlib import Path
import json
p=Path(__file__).resolve().parent;q=p.parent/'xslt30-template-name-qualified-20261113';run=json.loads((q/'RUN.json').read_text(encoding='utf-8'));assert run['success'] and json.loads((q/'GATE.json').read_text(encoding='utf-8'))['success']
body=f'''Well-formed unbound prefixes in principal-module `xsl:template/@name` currently report XPath XPST0081 before later XSLT name validation runs. Translate that specific failure to XTSE0280 only around name expansion in named-template binding collection, preserving the original exception as its inner cause. Shared QName expansion and namespace lookup stay unchanged; malformed-name diagnostic precedence, EQNames, reserved names, preprocessing and XPath diagnostics retain their existing behavior.

The two original fixtures `error-0280d`/`error-0280f` now match directly without aliases. All 579 original error statuses and 66 raw skip reasons remain unchanged (**513/0/66**); no other primary identity changes. The independent classifier still separates local-code evidence from namespace proof. Immutable adoption and the revised implementation review precede their respective code changes.

Validation:

- **28 focused tests pass**. Identical sources against sealed 1.81.7 binaries give ten expected reporting failures and eighteen protective passes, including module-local namespaces and unchanged XPath authoring diagnostics.
- Release solution/runner builds; **26,422 solution tests** in one invocation (8,397 XSLT included); **90** separate language-server tests.
- Frozen QT3 **31,397/0/424** and selected qt4 **8,941/0/1,918**, including 11 experimental passes; every skip name/reason matches.
- Complete pinned standalone **10,221/0/4,380**, all 14,601 identities replayed in {run['elapsedSeconds']:.3f}s, unchanged corpus/runtime and original 1,200-second/8 GiB limits.
- Sixteen classifier controls and eight historical dossiers verify. Original failed guard/caught stack, failing baseline, source/runtime/fixture seals and complete ledgers are retained.

A separate post-merge parent-main run 43416044519 timed out at 1,200.219s. Its original artifact remains failed and retained; no rerun or limit change. The successful parent PR gate and this candidate qualification are separate evidence.

Development Core/server **1.81.8 remains unpublished**. No public signature, fixture, skip/admission, gate/ruleset or publication change. Remaining 25 code differences and 23 uncoded reports need separate review.

[Evidence dossier](https://github.com/Fytala-Charles/Bosak/blob/fix/xslt-template-name-errors/docs/xslt30-template-name-fix/README.md). Clean semantic qualification commit `de15d03c18884b4951fa9b9883fce42512fdeba0`; later delivery changes only documentation/evidence.
'''
(p/'PR-BODY.md').write_bytes(body.encode())
