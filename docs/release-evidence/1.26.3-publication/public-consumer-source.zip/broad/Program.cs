// Generated release verification consumer; not a shipped source file.

using System.Xml.Linq;

using Bosak.XPath.Api;

using Bosak.XPath.Runtime.Vm;

using Bosak.XPath.Providers.Xml;

using System.Text;

using System.Text.Json;

using Bosak.Xslt.Authoring;

var packageMetadata = Directory.GetFiles(AppContext.BaseDirectory,"Bosak.*.dll").Order().Select(path =>

{

    var assembly = System.Reflection.Assembly.LoadFrom(path);

    var info = assembly.GetCustomAttributes(typeof(System.Reflection.AssemblyInformationalVersionAttribute),false)

        .Cast<System.Reflection.AssemblyInformationalVersionAttribute>().Single().InformationalVersion;

    if(info != "1.26.3+08fbdc31ac79baac04cf00f4773ec6d0b2dd247f") throw new Exception("Wrong exact revision: "+path);

    return new { id=assembly.GetName().Name, informationalVersion=info,sha256=Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(path))).ToLowerInvariant() };

}).ToArray();

if(packageMetadata.Length!=10) throw new Exception("Expected all ten Bosak assemblies");

File.WriteAllText(Path.Combine(Environment.GetEnvironmentVariable("BOSAK_RELEASE_RECEIPT_DIR") ?? throw new Exception("Missing receipt directory"), "broad-inline-metadata.json"),JsonSerializer.Serialize(packageMetadata));

var checks=0;

foreach (var count in new[] {1,2,80})

foreach (var indent in new[] {false,true})

foreach (var format in new[] {"utf8","utf8bom","utf16le","utf16be"})

{

    Encoding enc = format switch {"utf8" => new UTF8Encoding(false,true), "utf8bom" => new UTF8Encoding(true,true), "utf16le" => new UnicodeEncoding(false,true,true), _ => new UnicodeEncoding(true,true,true)};

    var declaration = format.StartsWith("utf16") ? "<?xml version=\"1.0\" encoding=\"UTF-16\"?>\r\n" : "";

    var group = indent ? "<group id=\"{0}\">\r\n<nested>\r\n<xsl:value-of select=\"/input/name\"/>\r\n</nested>\r\n</group>" : "<group id=\"{0}\"><nested><xsl:value-of select=\"/input/name\"/></nested></group>";

    var text = declaration + "<xsl:stylesheet xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" version=\"3.0\">\r\n<xsl:template match=\"/\">\r\n<result>\r\n" + string.Join("\r\n",Enumerable.Range(0,count).Select(i=>string.Format(group,i))) + "\r\n</result>\r\n</xsl:template>\r\n</xsl:stylesheet>";

    var bytes=enc.GetPreamble().Concat(enc.GetBytes(text)).ToArray();

    var created=AuthoringSource.TryCreate(bytes,new Uri("file:///C:/req127/probe.xsl"),out var source,out var failure);

    var result=created ? XsltAuthoring.Inspect(source!,options:new AuthoringInspectionOptions {AttemptCompilation=false}) : null;

    if (!created || result?.IsSuccess != true || !source!.OriginalBytes.Span.SequenceEqual(bytes)) throw new Exception($"Inspection/fidelity: {count}/{indent}/{format}");

    var groups=Flatten(result.Snapshot!.PrincipalModule.Root).Where(n=>n.ElementName?.LocalName=="group").ToArray();

    if(groups.Length!=count || !result.Snapshot.ExportOriginal(source.BaseUri).SequenceEqual(bytes)) throw new Exception("Count/export");

    for(var i=0;i<count;i++) {

        var node=groups[i]; var lexical=enc.GetString(bytes.AsSpan((int)node.Range.StartByteOffset,(int)node.Range.ByteLength));

        if(lexical!=string.Format(group,i)) throw new Exception("Wrong group lexical extent");

        var slot=Flatten(node).Single(n=>n.ElementName?.LocalName=="value-of").Attributes.Single(a=>a.Name=="select");

        if(enc.GetString(bytes.AsSpan((int)slot.ValueRange.StartByteOffset,(int)slot.ValueRange.ByteLength))!="/input/name") throw new Exception("Wrong slot extent");

    }

    checks++;

}



foreach(var format in new[]{"utf8","utf8bom","utf16le","utf16be"}) {

    Encoding enc=format switch {"utf8"=>new UTF8Encoding(false,true),"utf8bom"=>new UTF8Encoding(true,true),"utf16le"=>new UnicodeEncoding(false,true,true),_=>new UnicodeEncoding(true,true,true)};

    var declaration=format.StartsWith("utf16")?"<?xml version=\"1.0\" encoding=\"UTF-16\"?>":"";

    var text=declaration+"<xsl:stylesheet xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" version=\"3.0\"><xsl:template match=\"/\"><r>"+string.Concat(Enumerable.Range(0,3).Select(i=>$"<g id=\"{i}\"><nested><xsl:value-of select=\"/input/name\"/></nested></g>"))+"</r></xsl:template></xsl:stylesheet>";

    var bytes=enc.GetPreamble().Concat(enc.GetBytes(text)).ToArray(); var uri=new Uri("file:///req127/edit.xsl");

    if(!AuthoringSource.TryCreate(bytes,uri,out var source,out var failure)) throw new Exception(failure?.ToString());

    var inspection=XsltAuthoring.Inspect(source!,options:new AuthoringInspectionOptions{AttemptCompilation=false});

    if(!inspection.IsSuccess)throw new Exception(inspection.Failure?.ToString());

    var snapshot=inspection.Snapshot!; var values=Flatten(snapshot.PrincipalModule.Root).Where(n=>n.ElementName?.LocalName=="value-of").ToArray(); var slot=values[1].Attributes.Single(a=>a.Name=="select");

    var edit=snapshot.ProposeExpressionEdit(new AuthoringEditProposal(values[1].Id,"select","/input/identifier"));

    if(!edit.IsSuccess)throw new Exception(edit.Failure?.ToString());

    var range=slot.ValueRange; var expected=bytes[..(int)range.StartByteOffset].Concat(enc.GetBytes("/input/identifier")).Concat(bytes[(int)(range.StartByteOffset+range.ByteLength)..]).ToArray();

    if(!edit.Candidate!.EmittedSource.Span.SequenceEqual(expected)||!snapshot.ExportOriginal(uri).SequenceEqual(bytes)||!edit.Candidate.Snapshot.ExportOriginal(uri).SequenceEqual(expected))throw new Exception("Isolated edit fidelity");

    var updated=Flatten(edit.Candidate.Snapshot.PrincipalModule.Root).Where(n=>n.ElementName?.LocalName=="value-of").Select(n=>n.Attributes.Single(a=>a.Name=="select").ExpandedValue);

    if(!updated.SequenceEqual(new[]{"/input/name","/input/identifier","/input/name"}))throw new Exception("Sibling isolation");

    checks++;

}

var badBytes=Encoding.UTF8.GetBytes("<r><g></r>");

if(!AuthoringSource.TryCreate(badBytes,new Uri("file:///req127/bad.xml"),out var badSource,out _))throw new Exception("Bad XML envelope");

var bad=XsltAuthoring.Inspect(badSource!,options:new AuthoringInspectionOptions{AttemptCompilation=false});

if(bad.IsSuccess||bad.Snapshot is not null||bad.Failure?.Kind!=AuthoringFailureKind.Structure||!badSource!.OriginalBytes.Span.SequenceEqual(badBytes))throw new Exception("Malformed refusal");

checks++;



Console.WriteLine(typeof(XsltAuthoring).Assembly.FullName);

static IEnumerable<AuthoringNodeDescriptor> Flatten(AuthoringNodeDescriptor node) {

    yield return node;

    foreach(var child in node.Children)foreach(var descendant in Flatten(child))yield return descendant;

}



string Evaluate(string expression) => XPath31Expression.Compile(expression,

    new CompileOptions { Compatibility = XPathCompatibility.XPath40 }).Evaluate(new EvaluationContext()).ToString();

var cases = new (string Expression, string Expected)[] {

    ("count(map:entries(map{'a':1,'b':2}))", "2"),

    ("empty(map:entries(map{}))", "true"),

    ("string-join(map:items(map{'a':(1,2),'b':3}), ',')", "1,2,3"),

    ("empty(map:items(map{'a':(),'b':()}))", "true"),

    ("map:items(map{'a':[1,2],'b':map{'nested':3}})[2] instance of map(*)", "true"),

    ("count(function-lookup(xs:QName('map:entries'),1)(map{'a':1,'b':2}))", "2")

};

foreach (var item in cases)

    if (Evaluate(item.Expression) != item.Expected) throw new Exception(item.Expression);

    else checks++;

foreach (var name in new[] { "entries", "items" }) {

    bool refused = false;

    try { XPath31Expression.Compile($"map:{name}(map{{'a':1}})"); }

    catch (Exception ex) when (ex.Message.Contains("XPST0017")) { refused = true; }

    if (!refused) throw new Exception("XPath31 exposed " + name);

    checks++;

}



string Transform(string body, string source = "<root/>", string extra = "") => XElement.Parse(

    new Bosak.Xslt.Api.XsltCompiler().Compile("<xsl:stylesheet version='4.0' xmlns:xsl='http://www.w3.org/1999/XSL/Transform' xmlns:xs='http://www.w3.org/2001/XMLSchema' xmlns:array='http://www.w3.org/2005/xpath-functions/array' xmlns:t='urn:types' exclude-result-prefixes='#all' " + extra + ">" + body + "</xsl:stylesheet>")

    .TransformToString(new XDocumentNode(XDocument.Parse(source)))).Value;

var features = new (string Body, string Expected)[] {

    ("<xsl:template match='/'><out><xsl:select>'hello'</xsl:select></out></xsl:template>", "hello"),

    ("<xsl:template match='/'><xsl:variable name='a' as='array(*)'><xsl:array><xsl:array-member select='(1,2)'/></xsl:array></xsl:variable><out><xsl:value-of select='array:size($a)'/></out></xsl:template>", "1"),

    ("<xsl:template match='/'><out><xsl:switch select='2'><xsl:when test='1' select='&quot;one&quot;'/><xsl:when test='2' select='&quot;two&quot;'/></xsl:switch></out></xsl:template>", "two"),

    ("<xsl:item-type name='t:value' as='xs:integer'/><xsl:template match='/'><out><xsl:variable name='v' as='t:value' select='7'/><xsl:value-of select='$v instance of t:value'/></out></xsl:template>", "true"),

    ("<xsl:record-type name='t:line' constructor='yes'><xsl:field name='sku' as='xs:string'/><xsl:field name='quantity' as='xs:integer'/></xsl:record-type><xsl:template match='/'><out><xsl:variable name='r' as='t:line' select='t:line(&quot;A&quot;,2)'/><xsl:value-of separator='|' select='($r?sku,$r?quantity,$r instance of t:line)'/></out></xsl:template>", "A|2|true")

};

foreach (var feature in features) { if (Transform(feature.Body) != feature.Expected) throw new Exception("Feature: " + feature.Body); checks++; }

if (Transform("<xsl:template match='/'><out><xsl:apply-templates select='/*'/></out></xsl:template><xsl:template match='n:root' xmlns:n='urn:wrong'>M</xsl:template><xsl:template match='.' priority='-2'>F</xsl:template>", "<root xmlns='urn:nodes'/>", "fixed-namespaces='#standard n=urn:nodes'") != "M") throw new Exception("Fixed pattern binding"); checks++;

if (Transform("<xsl:template match='/'><out><xsl:apply-templates select='/*'/></out></xsl:template><xsl:template match='self::root intersect self::root'>M</xsl:template><xsl:template match='.' priority='-2'>F</xsl:template>") != "M") throw new Exception("Axis set focus"); checks++;

var rejected=false;

try {new Bosak.Xslt.Api.XsltCompiler().Compile("<xsl:stylesheet version='4.0' xmlns:xsl='http://www.w3.org/1999/XSL/Transform' xmlns:n='urn:native' fixed-namespaces='#standard'><xsl:template match='n:root'/></xsl:stylesheet>");}

catch (Exception ex) when (ex.Message.Contains("XPST0081")) {rejected=true;}

if(!rejected)throw new Exception("Compile-time prefix rejection");checks++;

if (System.Reflection.Assembly.Load("Bosak.XPath.Api").GetName().Version != new Version(1,26,3,0)) throw new Exception("Assembly version: Bosak.XPath.Api");

if (System.Reflection.Assembly.Load("Bosak.XPath.Compiler").GetName().Version != new Version(1,26,3,0)) throw new Exception("Assembly version: Bosak.XPath.Compiler");

if (System.Reflection.Assembly.Load("Bosak.XPath.Core").GetName().Version != new Version(1,26,3,0)) throw new Exception("Assembly version: Bosak.XPath.Core");

if (System.Reflection.Assembly.Load("Bosak.XPath.Parser").GetName().Version != new Version(1,26,3,0)) throw new Exception("Assembly version: Bosak.XPath.Parser");

if (System.Reflection.Assembly.Load("Bosak.XPath.Providers").GetName().Version != new Version(1,26,3,0)) throw new Exception("Assembly version: Bosak.XPath.Providers");

if (System.Reflection.Assembly.Load("Bosak.XPath.Providers.Database").GetName().Version != new Version(1,26,3,0)) throw new Exception("Assembly version: Bosak.XPath.Providers.Database");

if (System.Reflection.Assembly.Load("Bosak.XPath.Runtime").GetName().Version != new Version(1,26,3,0)) throw new Exception("Assembly version: Bosak.XPath.Runtime");

if (System.Reflection.Assembly.Load("Bosak.XPath.Standard").GetName().Version != new Version(1,26,3,0)) throw new Exception("Assembly version: Bosak.XPath.Standard");

if (System.Reflection.Assembly.Load("Bosak.XQuery").GetName().Version != new Version(1,26,3,0)) throw new Exception("Assembly version: Bosak.XQuery");

if (System.Reflection.Assembly.Load("Bosak.Xslt").GetName().Version != new Version(1,26,3,0)) throw new Exception("Assembly version: Bosak.Xslt");

string PatchSheet(string body, string bindings = "#standard p=urn:fixed q=urn:fixed") =>

    "<xsl:stylesheet version='4.0' xmlns:xsl='http://www.w3.org/1999/XSL/Transform' xmlns:p='urn:native' exclude-result-prefixes='#all' fixed-namespaces='" + bindings + "'>" + body + "</xsl:stylesheet>";

XElement PatchDoc(string text, string input = "<root/>") => XElement.Parse(new Bosak.Xslt.Api.XsltCompiler().Compile(text, "file:///release121/main.xsl").TransformToString(new XDocumentNode(XDocument.Parse(input))));

void CheckPatch(string body, string expected, string input = "<root/>") {

    if (PatchDoc(PatchSheet(body), input).Value != expected) throw new Exception("Patch regression: " + body);

    checks++;

}

CheckPatch("<xsl:variable version='3.0' name='p:v' select='7'/><xsl:template match='/'><out><xsl:value-of select='$q:v'/></out></xsl:template>", "7");

CheckPatch("<xsl:template version='3.0' name='p:t'>7</xsl:template><xsl:template match='/'><out><xsl:call-template version='3.0' name='q:t'/></out></xsl:template>", "7");

var keywordBody = "<xsl:function version='3.0' name='p:f'><xsl:param name='q:value'/><xsl:sequence select='$q:value'/></xsl:function><xsl:template match='/'><out><xsl:value-of select='q:f(q:value := 7)'/></out></xsl:template>";

CheckPatch(keywordBody, "7");

CheckPatch("<xsl:mode version='3.0' name='p:m'/><xsl:template match='/' mode='#unnamed'><out><xsl:apply-templates version='3.0' select='/*' mode='q:m'/></out></xsl:template><xsl:template version='3.0' match='root' mode='p:m'>7</xsl:template>", "7");

CheckPatch("<xsl:key version='3.0' name='p:k' match='root' use='@id'/><xsl:template match='/'><out><xsl:value-of select=\"count(key('q:k','a'))\"/></out></xsl:template>", "1", "<root id='a'/>");

foreach (var version in new[] { "3.0", "4.0" }) {

    CheckPatch("<xsl:key version='" + version + "' name='k' match='p:item' use='@q:id'/><xsl:template match='/'><out><xsl:value-of select=\"count(key('k','a'))\"/></out></xsl:template>", "1", "<root xmlns:i='urn:fixed'><i:item i:id='a'/></root>");

}

var namespaceResult = PatchDoc(PatchSheet("<xsl:template name='child' xmlns:p='urn:other'><hit>fixed</hit></xsl:template><xsl:template match='/'><out><xsl:call-template name='child'/></out></xsl:template>"));

if (namespaceResult.Element("hit")?.GetNamespaceOfPrefix("p")?.NamespaceName != "urn:other" || namespaceResult.GetNamespaceOfPrefix("p") is not null) throw new Exception("Owner-scoped #all namespace copying"); checks++;



var patchUri = new Uri("file:///release121/authoring.xsl");

var keywordText = PatchSheet(keywordBody);

var keywordBytes = Encoding.UTF8.GetBytes(keywordText);

if (!AuthoringSource.TryCreate(keywordBytes, patchUri, out var keywordSource, out _)) throw new Exception("Keyword source");

var keywordSnapshot = XsltAuthoring.Inspect(keywordSource!, options: new AuthoringInspectionOptions { AttemptCompilation = false }).Snapshot!;

if (Bosak.Xslt.Validation.XsltValidation.Validate(keywordSnapshot).Outcome != Bosak.Xslt.Validation.XsltValidationOutcome.Valid || !keywordSnapshot.ExportOriginal(patchUri).SequenceEqual(keywordBytes)) throw new Exception("Captured keyword validation/source fidelity"); checks++;

var keywordNode = Flatten(keywordSnapshot.PrincipalModule.Root).Single(n => n.ElementName?.LocalName == "value-of");

var keywordSlot = keywordNode.Attributes.Single(a => a.LocalName == "select");

var patchEdit = keywordSnapshot.ProposeExpressionEdit(new AuthoringEditProposal(keywordNode.Id, "select", "q:f(q:value := 8)"));

if (!patchEdit.IsSuccess || PatchDoc(Encoding.UTF8.GetString(patchEdit.Candidate!.EmittedSource.Span)).Value != "8") throw new Exception("Retained-context keyword expression edit"); checks++;

var patchRange = keywordSlot.ValueRange;

var patchExpected = keywordBytes[..(int)patchRange.StartByteOffset].Concat(Encoding.UTF8.GetBytes("q:f(q:value := 8)")).Concat(keywordBytes[(int)(patchRange.StartByteOffset + patchRange.ByteLength)..]).ToArray();

if (!patchEdit.Candidate!.EmittedSource.Span.SequenceEqual(patchExpected) || !keywordSnapshot.ExportOriginal(patchUri).SequenceEqual(keywordBytes)) throw new Exception("Patch edit splice isolation"); checks++;



var typedText = PatchSheet("<xsl:item-type name='q:positive' as='xs:integer'/><xsl:record-type name='q:line' constructor='yes'><xsl:field name='id' as='q:positive'/></xsl:record-type><xsl:template match='/'><out><xsl:value-of select='q:line(7)?id'/></out></xsl:template>");

if (Bosak.Xslt.Validation.XsltValidation.Validate(Encoding.UTF8.GetBytes(typedText), patchUri).Outcome != Bosak.Xslt.Validation.XsltValidationOutcome.Valid || PatchDoc(typedText).Value != "7") throw new Exception("Captured named/record field type validation"); checks++;

foreach (var body in new[] { "<xsl:key version='3.0' name='p:k' match='root' use='@id'/>", "<xsl:template version='3.0' name='p:t'/>", "<xsl:variable version='3.0' name='p:v' select='7'/>" }) {

    var refusedPatch = false;

    var badPatch = PatchSheet(body, "#standard");

    if (!Bosak.Xslt.Validation.XsltValidation.Validate(Encoding.UTF8.GetBytes(badPatch), patchUri).Diagnostics.Any(d => d.Code == "XTSE0280")) throw new Exception("Source-local omitted-prefix diagnostic");

    try { new Bosak.Xslt.Api.XsltCompiler().Compile(badPatch); } catch (Exception error) when (error.Message.Contains("XTSE0280")) { refusedPatch = true; }

    if (!refusedPatch) throw new Exception("Omitted-prefix compilation refusal"); checks++;

}



string OptionalSheet(string call, string type = "xs:string?", string defaultValue = "'B'", string version = "4.0") =>

    "<xsl:stylesheet version='" + version + "' xmlns:xsl='http://www.w3.org/1999/XSL/Transform' xmlns:xs='http://www.w3.org/2001/XMLSchema' xmlns:f='urn:optional' exclude-result-prefixes='#all'><xsl:function name='f:f'><xsl:param name='a' as='xs:string'/><xsl:param name='b' as='" + type + "' required='no' select=\"" + defaultValue + "\"/><xsl:sequence select='concat($a, &quot;|&quot;, string($b))'/></xsl:function><xsl:template match='/'><out><xsl:value-of select=\"" + call + "\"/></out></xsl:template></xsl:stylesheet>";

foreach (var call in new[] { "f:f('A')", "f:f(a := 'A')", "'A' => f:f()", "(f:f#1)('A')", "function-lookup(QName('urn:optional','f'),1)('A')", "let $f := f:f(?) return $f('A')" }) {

    if (PatchDoc(OptionalSheet(call)).Value != "A|B") throw new Exception("Optional omission: " + call); checks++;

}

if (PatchDoc(OptionalSheet("f:f('A',())")).Value != "A|") throw new Exception("Explicit empty is supplied"); checks++;

if (PatchDoc(OptionalSheet("f:f('A',7)", "xs:integer", "'invalid'")).Value != "A|7") throw new Exception("Supplied argument skips invalid default"); checks++;

void ExpectReleaseError(string sheet, string errorCode) {

    try { PatchDoc(sheet); } catch (Exception ex) when (ex.Message.Contains(errorCode)) { checks++; return; }

    throw new Exception("Expected " + errorCode);

}

ExpectReleaseError(OptionalSheet("f:f('A')", "xs:integer", "'invalid'"), "XPTY0004");

ExpectReleaseError(OptionalSheet("f:f('A')", "xs:integer", "1e7"), "XPTY0004");

foreach (var pair in new[] { ("xs:decimal", "1.25e0"), ("xs:decimal", "xs:float(1.25)"), ("xs:float", "1.25e0"), ("xs:float", "1.25"), ("xs:double", "1.25"), ("xs:double", "xs:float(1.25)") }) {

    if (PatchDoc(OptionalSheet("f:f('A'," + pair.Item2 + ")", pair.Item1)).Value != "A|1.25") throw new Exception("Numeric cast " + pair); checks++;

}

if (PatchDoc(OptionalSheet("f:f('A')", "xs:decimal", "1.25e0")).Value != "A|1.25") throw new Exception("Numeric default"); checks++;

ExpectReleaseError(OptionalSheet("f:f('A')", "xs:decimal", "xs:double('INF')"), "FOCA0002");

var earlierSheet = OptionalSheet("f:f('A',1.25e0)", "xs:decimal").Replace("version='4.0'", "version='3.0'").Replace("required='no' select=\"'B'\"", "");

ExpectReleaseError(earlierSheet, "XPTY0004");



string PrivateSheet(string declarations, string call, string version = "4.0") =>

    "<xsl:stylesheet version='" + version + "' xmlns:xsl='http://www.w3.org/1999/XSL/Transform' xmlns:fn='http://www.w3.org/2005/xpath-functions' xmlns:xs='http://www.w3.org/2001/XMLSchema' exclude-result-prefixes='#all'>" + declarations + "<xsl:template match='/'><out><xsl:value-of select=\"" + call + "\"/></out></xsl:template></xsl:stylesheet>";

const string PrivateDivide = "<xsl:function name='divide' visibility='private'><xsl:param name='dividend'/><xsl:param name='divisor'/><xsl:sequence select='$dividend div $divisor'/></xsl:function>";

var privateUri = new Uri("file:///release140/private.xsl");

void CheckPrivate(string declarations, string call, string expected) {

    var sheet = PrivateSheet(declarations, call);

    if (Bosak.Xslt.Validation.XsltValidation.Validate(Encoding.UTF8.GetBytes(sheet), privateUri).Outcome != Bosak.Xslt.Validation.XsltValidationOutcome.Valid || PatchDoc(sheet).Value != expected) throw new Exception("Private function: " + call);

    checks++;

}

foreach (var call in new[] { "divide(9,3)", "9 => divide(3)", "divide(divisor := 3, dividend := 9)", "9 => divide(divisor := 3)", "Q{}divide(9,3)", "Q{}divide(divisor := 3, dividend := 9)", "(divide#2)(9,3)", "(Q{}divide#2)(9,3)", "function-lookup(QName('', 'divide'),2)(9,3)", "let $f := divide(?,3) return $f(9)", "let $f := divide(?, divisor := 3) return $f(9)" }) CheckPrivate(PrivateDivide, call, "3");

const string PrivateSum = "<xsl:function name='sum'><xsl:param name='a'/><xsl:param name='b'/><xsl:param name='c'/><xsl:sequence select='$a+$b+$c'/></xsl:function>";

CheckPrivate(PrivateSum, "sum(sum(10,11,12),0)", "33");

CheckPrivate(PrivateSum, "(sum#2)((sum#3)(10,11,12),0)", "33");

const string PrivateCount = "<xsl:function name='Q{}count'><xsl:param name='items'/><xsl:sequence select='7'/></xsl:function>";

foreach (var pair in new[] { ("count((1,2))", "7"), ("Q{}count((1,2))", "7"), ("fn:count((1,2))", "2"), ("Q{http://www.w3.org/2005/xpath-functions}count((1,2))", "2"), ("(count#1)((1,2))", "7"), ("(fn:count#1)((1,2))", "2") }) CheckPrivate(PrivateCount, pair.Item1, pair.Item2);

const string PrivateGreet = "<xsl:function name='greet'><xsl:param name='a'/><xsl:param name='b' required='no' select=\"'B'\"/><xsl:sequence select='concat($a,$b)'/></xsl:function>";

foreach (var call in new[] { "greet('A')", "greet(a := 'A')", "(greet#1)('A')", "function-lookup(QName('', 'greet'),1)('A')", "let $f := greet(?, b := 'B') return $f('A')" }) CheckPrivate(PrivateGreet, call, "AB");

foreach (var profile in new[] { ("3.0", ""), ("2.0", ""), ("4.0", "version='3.0'"), ("4.0", "visibility='public'"), ("4.0", "visibility='final'"), ("4.0", "visibility='abstract'") }) {

    var sheet = PrivateSheet("<xsl:function name='divide' " + profile.Item2 + "/>", "1", profile.Item1);

    if (!Bosak.Xslt.Validation.XsltValidation.Validate(Encoding.UTF8.GetBytes(sheet), privateUri).Diagnostics.Any(d => d.Code == "XTSE0740")) throw new Exception("Private visibility/profile validation");

    ExpectReleaseError(sheet, "XTSE0740");

}

ExpectReleaseError(PrivateSheet("", "Q{}count((1,2))"), "XPST0017");

ExpectReleaseError(PrivateSheet("", "(Q{}count#1)((1,2))"), "XPST0017");

CheckPrivate(PrivateDivide, "(function-available('divide',2),function-available('Q{}divide',2),exists(function-lookup(QName('', 'divide'),2)))", "false true true");

var privateBytes = Encoding.UTF8.GetBytes(PrivateSheet(PrivateDivide, "divide(9,3)"));

if (!AuthoringSource.TryCreate(privateBytes, privateUri, out var privateSource, out _)) throw new Exception("Private authoring source");

var privateSnapshot = XsltAuthoring.Inspect(privateSource!, options: new AuthoringInspectionOptions { AttemptCompilation = false }).Snapshot!;

var privateNode = Flatten(privateSnapshot.PrincipalModule.Root).Single(n => n.ElementName?.LocalName == "value-of");

var privateSlot = privateNode.Attributes.Single(a => a.LocalName == "select");

const string PrivateReplacement = "divide(divisor := 3, dividend := 12)";

var privateEdit = privateSnapshot.ProposeExpressionEdit(new AuthoringEditProposal(privateNode.Id, "select", PrivateReplacement));

var privateRange = privateSlot.ValueRange;

var privateExpectedBytes = privateBytes[..(int)privateRange.StartByteOffset].Concat(Encoding.UTF8.GetBytes(PrivateReplacement)).Concat(privateBytes[(int)(privateRange.StartByteOffset + privateRange.ByteLength)..]).ToArray();

if (!privateEdit.IsSuccess || PatchDoc(Encoding.UTF8.GetString(privateEdit.Candidate!.EmittedSource.Span)).Value != "4" || !privateEdit.Candidate.EmittedSource.Span.SequenceEqual(privateExpectedBytes) || !privateSnapshot.ExportOriginal(privateUri).SequenceEqual(privateBytes)) throw new Exception("Private signature edit and isolated bytes"); checks++;

var privateInclude = PrivateSheet(PrivateDivide, "1").Replace("<xsl:template match='/'><out><xsl:value-of select=\"1\"/></out></xsl:template>", "");

var privateIncludedExecutable = new Bosak.Xslt.Api.XsltCompiler { UriResolver = new ReleaseTextResolver(privateInclude) }.Compile(PrivateSheet("<xsl:include href='library.xsl'/>", "divide(9,3)"), "file:///release140/main.xsl");

if (XElement.Parse(privateIncludedExecutable.TransformToString(new XDocumentNode(XDocument.Parse("<root/>")))).Value != "3") throw new Exception("Included private function"); checks++;

const string PrivatePackageName = "urn:release140-private-package";

var privatePackage = "<xsl:package xmlns:xsl='http://www.w3.org/1999/XSL/Transform' xmlns:p='urn:exports' name='" + PrivatePackageName + "' package-version='1.0' version='4.0'>" + PrivateDivide + "<xsl:function name='p:answer' visibility='public'><xsl:sequence select='divide(9,3)'/></xsl:function></xsl:package>";

foreach (var scenario in new[] { (PrivateDivide.Replace("$dividend div $divisor", "42"), "(p:answer(),divide(9,3))", "3 42"), ("", "(p:answer(),empty(function-lookup(QName('', 'divide'),2)))", "3 true") }) {

    Bosak.Xslt.Api.XsltFunctionLibrary.RegisterPackage(PrivatePackageName, "1.0", "file:///release140/library.xsl");

    try {

        var caller = PrivateSheet("<xsl:use-package name='" + PrivatePackageName + "' package-version='1.0'/>" + scenario.Item1, scenario.Item2).Replace("xmlns:fn=", "xmlns:p='urn:exports' xmlns:fn=");

        var executable = new Bosak.Xslt.Api.XsltCompiler { UriResolver = new ReleaseTextResolver(privatePackage) }.Compile(caller);

        if (XElement.Parse(executable.TransformToString(new XDocumentNode(XDocument.Parse("<root/>")))).Value != scenario.Item3) throw new Exception("Private package isolation"); checks++;

    } finally { Bosak.Xslt.Api.XsltFunctionLibrary.ClearPackages(); }

}

var privatePattern = PrivateSheet("<xsl:function name='accept'><xsl:param name='node'/><xsl:sequence select='true()'/></xsl:function>", "1").Replace("match='/'", "match='root[accept(.)]'");

if (PatchDoc(privatePattern).Value != "1") throw new Exception("Private pattern predicate"); checks++;

if (PatchDoc(PrivateSheet(PrivateDivide, "1").Replace("<out>", "<out value='{divide(9,3)}'>")).Attribute("value")?.Value != "3") throw new Exception("Private AVT"); checks++;

var privateConditional = PrivateSheet("<xsl:function name='count' use-when=\"system-property('xsl:version') = '4.0'\"><xsl:param name='items'/><xsl:sequence select='7'/></xsl:function>", "count((1,2))");

if (Bosak.Xslt.Validation.XsltValidation.Validate(Encoding.UTF8.GetBytes(privateConditional), privateUri).Outcome != Bosak.Xslt.Validation.XsltValidationOutcome.UnsupportedCoverage) throw new Exception("Conditional private authoring coverage"); checks++;

var privateFocus = "<xsl:stylesheet version='4.0' xmlns:xsl='http://www.w3.org/1999/XSL/Transform'><xsl:function name='code'><xsl:param name='node' required='no' select='current()'/><xsl:sequence select='$prefix || ($node ! @code)'/></xsl:function><xsl:variable name='prefix' select=\"'%'\"/><xsl:template match='root'><out><xsl:value-of select='code()'/></out></xsl:template></xsl:stylesheet>";

if (PatchDoc(privateFocus, "<root code='blue'/>").Value != "%blue") throw new Exception("Private optional caller focus and global default"); checks++;

var packageChecks = new Bosak.Xslt.Tests.Validation.Xslt40UsedPackageOptionalFunctionTests();

packageChecks.PublicFunctionCallPaths("p:f('A')","A|B|C"); checks++;

packageChecks.PublicFunctionCallPaths("p:f('A','X')","A|X|C"); checks++;

packageChecks.PublicFunctionCallPaths("p:f('A','X','Y')","A|X|Y"); checks++;

packageChecks.PublicFunctionCallPaths("p:f(a := 'A', c := 'Y')","A|B|Y"); checks++;

packageChecks.PublicFunctionCallPaths("'A' => p:f(c := 'Y')","A|B|Y"); checks++;

packageChecks.PublicFunctionCallPaths("(p:f#1)('A')","A|B|C"); checks++;

packageChecks.PublicFunctionCallPaths("function-lookup(QName('urn:functions','f'),1)('A')","A|B|C"); checks++;

packageChecks.PublicFunctionCallPaths("let $f := p:f(?, 'X') return $f('A')","A|X|C"); checks++;

packageChecks.PublicFunctionCallPaths("let $f := p:f#2 return $f('A','X')","A|X|C"); checks++;

packageChecks.LookupExposesExactlyTheRange(); checks++;

packageChecks.DefaultsUseDeclaringGlobals(); checks++;

packageChecks.DirectDefaultsUseCallerFocus(); checks++;

packageChecks.NamedReferenceCapturesCreationFocus(); checks++;

packageChecks.ConstructorDefaultUsesCallerFocus(); checks++;

packageChecks.DefaultTypeErrorIsPreserved(); checks++;

packageChecks.PrivateOptionalHelperIsIsolated(); checks++;

packageChecks.AcceptUpperBoundAsPrivateKeepsRange(); checks++;

packageChecks.HiddenComponentHidesRange(); checks++;

packageChecks.AcceptReducedArityIsRejected(); checks++;

packageChecks.ExposeUpperBoundExportsRange(); checks++;

packageChecks.FinalOptionalFunctionExecutes(); checks++;

packageChecks.EarlierCallerUsesLibraryDefaults(); checks++;

packageChecks.NestedUsedPackageDefaultsExecute(); checks++;

packageChecks.OptionalOverrideExecutes(); checks++;

packageChecks.PrivateHelperIsAbsentFromCallerLookup(); checks++;

packageChecks.KeywordUsesDeclaringNamespace(); checks++;

packageChecks.AvtAndPredicateUseOptionalFunction(); checks++;

packageChecks.ConflictingUsedPackageRangesAreRejected(); checks++;

packageChecks.LocalOverlapWithUsedPackageRangeIsRejected(); checks++;

packageChecks.HiddenOverlappingFamilyDoesNotConflict(); checks++;

packageChecks.NonoverlappingFamiliesExecute(); checks++;

packageChecks.CallerLocalDoesNotSupplyDefaultVariable(); checks++;

packageChecks.NestedOptionalOverrideExecutes(); checks++;

Console.WriteLine($"Record release candidate verification: {checks} checks passed; all ten assembly versions are 1.26.3.0");



sealed class ReleaseTextResolver(string text) : Bosak.Xslt.Api.IXsltUriResolver

{

    /// <summary>Returns the supplied in-memory module for the release verification consumer.</summary>

    /// <param name="href">The requested module URI.</param>

    /// <param name="baseUri">The referring module URI.</param>

    /// <returns>The supplied module document.</returns>

    public XDocument Resolve(string href, string? baseUri) => XDocument.Parse(text);

}





