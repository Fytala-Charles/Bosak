// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 24 October 2026
// PURPOSE              : Verifies independent changed-order proof, ownership and NoChange refusal.
// SPECIAL NOTES        : No XML parsing or source rewriting; only engine-issued bytes may be accepted.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 24-10-2026     | Creation                                                                                 |
//                      | Charles Korthout | 0.3   | 26-10-2026     | Verify exact-source unsigned 1.26.1 package candidate.                                    |
// ===========================================================================================================================================================
//                      | Charles Korthout | 0.2   | 25-10-2026     | Verify unsigned exact-merge package candidate. |
//                      | Charles Korthout | 0.4   | 26-10-2026     | Verify exact-source unsigned 1.26.2 package candidate.                                    |
// ===========================================================================================================================================================
//                      | Charles Korthout | 0.5   | 26-10-2026     | Verify exact-source unsigned 1.26.3 package candidate.                                    |
// ===========================================================================================================================================================

using System.Text;
using System.Reflection;
using Bosak.Xslt.Authoring;
using Xunit;
public sealed class BraidConditionalProbes
{
    private static readonly Uri Uri=new("file:///consumer/conditional.xsl");
    private static string Sheet(string body)=>"<s:stylesheet xmlns:s='http://www.w3.org/1999/XSL/Transform' xmlns:z='http://www.w3.org/1999/XSL/Transform' version='3.0'><s:template match='/'><out>"+body+"</out></s:template></s:stylesheet>";
    private static IEnumerable<AuthoringNodeDescriptor> Nodes(AuthoringNodeDescriptor n)=>new[]{n}.Concat(n.Children.SelectMany(Nodes));
    private static AuthoringSnapshot Inspect(string body,int encoding=0)
    {
        Encoding e=encoding switch{0=>new UTF8Encoding(false,true),1=>new UTF8Encoding(true,true),2=>new UnicodeEncoding(false,true,true),_=>new UnicodeEncoding(true,true,true)};
        var text="<?xml version='1.0' encoding='"+(encoding<2?"utf-8":encoding==2?"utf-16le":"utf-16be")+"'?>"+Sheet(body);byte[] bytes=[..e.GetPreamble(),..e.GetBytes(text)];Assert.True(AuthoringSource.TryCreate(bytes,Uri,out var source,out _));var r=XsltAuthoring.Inspect(source!,options:new(){AttemptCompilation=false});Assert.True(r.IsSuccess);return r.Snapshot!;
    }
    private static void Verify(AuthoringConditionalCandidate c)
    {
        var old=c.InputSnapshot.ExportOriginal(Uri);var bytes=c.ExportSource();var replay=old.ToList();foreach(var e in c.SourceEdits.Reverse()){replay.RemoveRange((int)e.OriginalRange.StartByteOffset,(int)e.OriginalRange.ByteLength);replay.InsertRange((int)e.OriginalRange.StartByteOffset,bytes.Skip((int)e.ReplacementRange.StartByteOffset).Take((int)e.ReplacementRange.ByteLength));}Assert.Equal(bytes,replay.ToArray());
        var originals=Nodes(c.InputSnapshot.PrincipalModule.Root).ToArray();var fresh=Nodes(c.Snapshot.PrincipalModule.Root).ToArray();var fragments=c.MergedTextGroups.SelectMany(g=>g.Fragments.Select(f=>f.OriginalNode)).ToArray();Assert.Equal(originals.Length,c.NodeCorrespondence.Count+c.RemovedNodes.Count+fragments.Length);Assert.Equal(fresh.Length,c.NodeCorrespondence.Count+c.CreatedNodes.Count+c.MergedTextGroups.Count);Assert.Equal(originals.Length,c.NodeCorrespondence.Keys.Concat(c.RemovedNodes).Concat(fragments).Distinct().Count());Assert.Equal(fresh.Length,c.NodeCorrespondence.Values.Concat(c.CreatedNodes).Concat(c.MergedTextGroups.Select(g=>g.CandidateNode)).Distinct().Count());
    }
    [Theory][InlineData(0,false)][InlineData(1,false)][InlineData(2,false)][InlineData(3,false)][InlineData(0,true)][InlineData(1,true)][InlineData(2,true)][InlineData(3,true)]
    public void Lifecycle_PublicExactReplayAndActualSelection(int encoding,bool paired)
    {
        var s=Inspect(paired?"<item a='&amp;'><child/><s:text>payload</s:text></item><item/>":"<item a='&amp;'/><item/>",encoding);var original=s.ExportOriginal(Uri);var selected=Nodes(s.PrincipalModule.Root).First(n=>n.ElementName?.LocalName=="item");
        var t=s.GetConditionalWrapTarget(selected);Assert.True(t.IsSuccess,t.Failure?.Message);var r=s.ProposeConditionalWrap(new(t.Target!,"true()"));Assert.True(r.IsSuccess,r.Failure?.Message);var wrapped=r.Candidate!;Verify(wrapped);Assert.Same(selected,Assert.Single(wrapped.Reparenting).OriginalNode);Assert.Equal("if",wrapped.CandidateSelection.ElementName!.LocalName);Assert.Same(wrapped.CandidateTest,Assert.Single(wrapped.CandidateSelection.Attributes));
        var equal=wrapped.Snapshot.ProposeExpressionEdit(new(wrapped.CandidateSelection.Id,"test","true()"),CancellationToken.None);Assert.True(equal.IsSuccess);Assert.Equal(wrapped.ExportSource(),equal.Candidate!.EmittedSource.ToArray());
        var edited=wrapped.Snapshot.ProposeExpressionEdit(new(wrapped.CandidateSelection.Id,"test","false()"),CancellationToken.None);Assert.True(edited.IsSuccess,edited.Failure?.Message);var current=edited.Candidate!.Snapshot;var wrapper=Nodes(current.PrincipalModule.Root).Single(n=>n.Id==edited.Candidate.NodeCorrespondence[wrapped.CandidateSelection.Id]);var target=current.GetConditionalUnwrapTarget(wrapper);Assert.True(target.IsSuccess);var unwrapped=current.ProposeConditionalUnwrap(new(target.Target!));Assert.True(unwrapped.IsSuccess,unwrapped.Failure?.Message);Verify(unwrapped.Candidate!);Assert.Equal(original,unwrapped.Candidate!.ExportSource());Assert.Equal("item",unwrapped.Candidate.CandidateSelection.ElementName!.LocalName);
    }
    [Theory][InlineData(0)][InlineData(1)][InlineData(2)][InlineData(3)]
    public void TwoSeams_PublicFragmentBytesAndNormalizedValues(int encoding)
    {
        var s=Inspect("\r<s:if test='true()'>\n<item a='A'/>\r</s:if>\n",encoding);var node=Nodes(s.PrincipalModule.Root).Single(n=>n.ElementName?.LocalName=="if");var r=s.ProposeConditionalUnwrap(new(s.GetConditionalUnwrapTarget(node).Target!));Assert.True(r.IsSuccess,r.Failure?.Message);var c=r.Candidate!;Verify(c);Assert.Equal(2,c.MergedTextGroups.Count);foreach(var group in c.MergedTextGroups){Assert.Equal("\n",group.CandidateNode.Text);Assert.Equal(2,group.Fragments.Count);var raw=group.Fragments.SelectMany(f=>c.ExportOriginalRange(f.OriginalRange)).ToArray();var bytes=c.ExportSource();Assert.Equal(raw,bytes.Skip((int)group.CandidateNode.Range.StartByteOffset).Take((int)group.CandidateNode.Range.ByteLength).ToArray());}
    }
    [Theory][InlineData(0)][InlineData(1)][InlineData(2)][InlineData(3)]
    public async Task ConcurrentProposals_PublicIsolationAndCancellation(int encoding)
    {
        var s=Inspect("<item/>",encoding);var n=Nodes(s.PrincipalModule.Root).Single(n=>n.ElementName?.LocalName=="item");var target=s.GetConditionalWrapTarget(n).Target!;var original=s.ExportOriginal(Uri);var results=await Task.WhenAll(Task.Run(()=>s.ProposeConditionalWrap(new(target,"true()"))),Task.Run(()=>s.ProposeConditionalWrap(new(target,"false()"))));Assert.All(results,r=>Assert.True(r.IsSuccess,r.Failure?.Message));Assert.NotSame(results[0].Candidate!.Snapshot,results[1].Candidate!.Snapshot);Assert.Equal(original,s.ExportOriginal(Uri));Assert.Equal(AuthoringConditionalFailureKind.Cancelled,s.ProposeConditionalWrap(new(target,"true()"),new CancellationToken(true)).Failure!.Kind);
    }
    [Fact]
    public void PublicTypesAndLegacySurface_AreAdditive()
    {
        Assert.Empty(typeof(AuthoringConditionalWrapTarget).GetConstructors());Assert.Empty(typeof(AuthoringConditionalUnwrapTarget).GetConstructors());var methods=typeof(AuthoringSnapshot).GetMethods().Where(m=>m.Name=="ProposeExpressionEdit").ToArray();Assert.Contains(methods,m=>m.GetParameters().Length==1);Assert.Contains(methods,m=>m.GetParameters().Length==2&&m.GetParameters()[1].ParameterType==typeof(CancellationToken)&&!m.GetParameters()[1].IsOptional);Assert.StartsWith("1.26.3+08fbdc31ac79baac04cf00f4773ec6d0b2dd247f",typeof(AuthoringSnapshot).Assembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>()!.InformationalVersion);
    }
}
