// Generated local NuGet signature-content verification utility.
using NuGet.Packaging;
using System.Text.Json;
var rows = Directory.GetFiles(args[0], "*.nupkg").Order().Select(path => {
 using var reader = new PackageArchiveReader(path);
 return new { archive=Path.GetFileName(path), contentHash=reader.GetContentHash(CancellationToken.None) };
}).ToArray();
File.WriteAllText(args[1],JsonSerializer.Serialize(rows,new JsonSerializerOptions { WriteIndented=true }));
Console.WriteLine($"NuGet PackageArchiveReader content hashes: {rows.Length}");
