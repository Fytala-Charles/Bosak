// Generated metadata verification utility; no engine/project/package references.
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
var rows = new List<object>();
foreach (var file in Directory.GetFiles(Path.GetFullPath(args[0]), "Bosak.*.dll").Where(f => !f.EndsWith(".Tests.dll")))
{
    var a = Assembly.LoadFile(file);
    rows.Add(new { id = a.GetName().Name, version = a.GetName().Version!.ToString(), informationalVersion = a.GetCustomAttribute<AssemblyInformationalVersionAttribute>()!.InformationalVersion, sha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(file))).ToLowerInvariant() });
}
File.WriteAllText(args[1], JsonSerializer.Serialize(rows, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"Verified metadata for {rows.Count} library outputs.");
