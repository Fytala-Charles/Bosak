// ===========================================================================================================================================================
// AUTHOR               : Charles Korthout
// CREATE DATE          : 20 October 2026
// PURPOSE              : Verify physical bounds, cancellation and malformed attribute correspondence.
// SPECIAL NOTES        : Unit tests verifying correctness of the underlying implementation.
//
// COPYRIGHT            : Fytala
// LICENSE              : license.md (Apache-2.0)
// SPDX-License-Identifier: Apache-2.0
// ===========================================================================================================================================================
// Change History:      |==================|=======|================|=========================================================================================
//                      |     Author       |Version|  Date          | Notes                                                                                    |
//                      |==================|=======|================|=========================================================================================
//                      | Charles Korthout | 0.1   | 20-10-2026     | Creation                                                                                 |
//                      |==================|=======|================|=========================================================================================
// ===========================================================================================================================================================

using System.Text;
using System.Collections;
using Bosak.Xslt.Authoring;
using Xunit;

namespace Bosak.Xslt.Tests.Authoring;

/// <summary>Physical boundary, cancellation and source-only proof controls for REQ-135.</summary>
public partial class AuthoringLiteralAttributeLifecycleTests
{
    private static byte[] Sized(string body, int variant, int wanted)
    {
        var s = Sheet("<!---->" + body); var baseline = Encode(s, variant); var unit = variant < 2 ? 1 : 2;
        Assert.Equal(0, (wanted - baseline.Length) % unit);
        return Encode(s.Replace("<!---->", "<!--" + new string('p', (wanted - baseline.Length) / unit) + "-->"), variant);
    }
    /// <summary>Original/final bounds, escaping growth and NoChange are checked independently.</summary>
    /// <param name="variant">Physical encoding variant.</param>
    [Theory][InlineData(0)][InlineData(1)][InlineData(2)][InlineData(3)]
    public void PhysicalBounds(int variant)
    {
        const int limit = 8_388_608; var unit = variant < 2 ? 1 : 2;
        // UTF-8 BOM and declaration lengths can have either parity; UTF-16 is always even.
        var exact = Inspect(Sized("<out status='&#39;'/>", variant, limit));
        var ct = exact.GetLiteralAttributeCreationTarget(Owner(exact)); Assert.True(ct.IsSuccess, ct.Failure?.Message);
        Assert.Equal(AuthoringLiteralAttributeFailureKind.SizeLimit, exact.ProposeLiteralAttributeCreation(new(ct.Target!, "new", "v")).Failure!.Kind);
        var ut = exact.GetLiteralAttributeUpdateTarget(Owner(exact), Attribute(exact)).Target!;
        Assert.Equal(AuthoringLiteralAttributeUpdateOutcome.NoChange, exact.ProposeLiteralAttributeUpdate(new(ut, "'")).Outcome);
        Assert.Equal(AuthoringLiteralAttributeFailureKind.SizeLimit, exact.ProposeLiteralAttributeUpdate(new(ut, "&&&&")).Failure!.Kind);
        var shrunk = Update(exact, ""); Assert.True(shrunk.ExportSource().Length < limit);
        var removed = Delete(exact); Assert.True(removed.ExportSource().Length < limit);
        var over = Inspect(Sized("<out status='ok'/>", variant, limit + unit));
        Assert.Equal(AuthoringLiteralAttributeFailureKind.SizeLimit, over.GetLiteralAttributeCreationTarget(Owner(over)).Failure!.Kind);
        Assert.Equal(AuthoringLiteralAttributeFailureKind.SizeLimit, over.GetLiteralAttributeUpdateTarget(Owner(over), Attribute(over)).Failure!.Kind);
        Assert.Equal(AuthoringLiteralAttributeFailureKind.SizeLimit, over.GetLiteralAttributeDeletionTarget(Owner(over), Attribute(over)).Failure!.Kind);
        var name = "status"; var insertionLength = Encoding.UTF8.GetByteCount(" " + name + "=\"v\"") * unit;
        var fits = Inspect(Sized("<out/>", variant, limit - insertionLength));
        Assert.Equal(limit, Create(fits, "v").ExportSource().Length);
        var updateFits = Inspect(Sized("<out status=''/>", variant, limit - 6 * unit));
        Assert.Equal(limit, Update(updateFits, "'").ExportSource().Length);
    }

    /// <summary>Unicode names, exact case and XMLNS remain ordinary distinct attributes.</summary>
    /// <param name="name">Valid no-namespace name.</param>
    [Theory][InlineData("État")][InlineData("状態")][InlineData("XMLNS")][InlineData("Status")][InlineData("e\u0301")]
    public void UnicodeNames(string name)
    { var c = Create(Inspect(Sheet("<out status='old'/>")), "value", name); Assert.Equal("value", (string?)Run(c.ExportSource()).Attribute(name)); }

    /// <summary>Both source spellings of the XSLT namespace and effective versions work.</summary>
    /// <param name="defaultNamespace">Whether XSLT uses a default namespace.</param>
    /// <param name="version">Supported effective version.</param>
    [Theory][InlineData(false,"3.0")][InlineData(false,"4.0")][InlineData(true,"3.0")][InlineData(true,"4.0")]
    public void NamespaceAliases(bool defaultNamespace, string version)
    {
        var text = defaultNamespace ? $"<stylesheet xmlns='{Xsl}' version='{version}'><template match='/'><out xmlns='' keep='K'/></template></stylesheet>"
            : Sheet("<out/>", version:version).Replace("xsl:", "t:").Replace("xmlns:xsl", "xmlns:t");
        var c = Create(Inspect(text), "{literal}"); Assert.Equal("{literal}", (string?)Run(c.ExportSource()).Attribute("status"));
    }

    /// <summary>Unsupported inspection encodings do not become edit-capable.</summary>
    [Fact]
    public void UnsupportedEncoding()
    {
        var bytes = Encoding.Latin1.GetBytes("<?xml version='1.0' encoding='iso-8859-1'?>" + Sheet("<out status='ok'/>"));
        var s = Inspect(bytes); Assert.Equal(AuthoringLiteralAttributeFailureKind.UnsupportedEncoding, s.GetLiteralAttributeCreationTarget(Owner(s)).Failure!.Kind);
    }

    /// <summary>Returned evidence collections have no mutable backing exposure.</summary>
    [Fact]
    public void ImmutableEvidence()
    {
        var c = Create(Inspect(Sheet("<out keep='K'/>")), "literal");
        var map = Assert.IsAssignableFrom<IDictionary<AuthoringNodeDescriptor, AuthoringNodeDescriptor>>(c.NodeCorrespondence);
        Assert.Throws<NotSupportedException>(() => map.Clear());
        var attrs = Assert.IsAssignableFrom<IList<AuthoringLiteralAttributeCorrespondence>>(c.AttributeCorrespondence);
        Assert.Throws<NotSupportedException>(() => attrs.Clear());
        var edits = Assert.IsAssignableFrom<IList<AuthoringInsertionSourceEdit>>(c.SourceEdits);
        Assert.Throws<NotSupportedException>(() => edits.Clear());
        var owner = c.AttributeCorrespondence.Single(x => ReferenceEquals(x.OriginalOwner, c.OriginalOwner));
        var survivors = Assert.IsAssignableFrom<IDictionary<AuthoringAttributeDescriptor, AuthoringAttributeDescriptor>>(owner.Survivors);
        Assert.Throws<NotSupportedException>(() => survivors.Clear());
    }

    private sealed class CountingResolver : IAuthoringModuleResolver
    {
        internal int Calls;
        /// <inheritdoc />
        public AuthoringSource? ResolveModule(Uri absoluteUri, Uri referencingModuleUri)
        {
            Calls++;
            Assert.True(AuthoringSource.TryCreate(Encoding.UTF8.GetBytes($"<xsl:stylesheet xmlns:xsl='{Xsl}' version='3.0'/>"), absoluteUri, out var source, out _));
            return source;
        }
    }
    /// <summary>Existing inspection resolver authority is never reused by lifecycle proposals.</summary>
    [Fact]
    public void DependencyDeniedBeforeAcquisition()
    {
        var xml = Sheet("<out status='old'/>").Replace("<xsl:output", "<xsl:include href='dependency.xsl'/><xsl:output");
        Assert.True(AuthoringSource.TryCreate(Encoding.UTF8.GetBytes(xml), Module, out var source, out _));
        var resolver = new CountingResolver(); var inspected = XsltAuthoring.Inspect(source!, resolver, new() { AttemptCompilation=false });
        Assert.True(inspected.IsSuccess); Assert.True(resolver.Calls > 0); resolver.Calls=0;
        var s=inspected.Snapshot!; var o=Owner(s); var a=Attribute(s);
        Assert.Equal(AuthoringLiteralAttributeFailureKind.UnsupportedModule,s.GetLiteralAttributeCreationTarget(o).Failure!.Kind);
        Assert.Equal(AuthoringLiteralAttributeFailureKind.UnsupportedModule,s.GetLiteralAttributeUpdateTarget(o,a).Failure!.Kind);
        Assert.Equal(AuthoringLiteralAttributeFailureKind.UnsupportedModule,s.GetLiteralAttributeDeletionTarget(o,a).Failure!.Kind);
        Assert.Equal(0,resolver.Calls);
    }
}
